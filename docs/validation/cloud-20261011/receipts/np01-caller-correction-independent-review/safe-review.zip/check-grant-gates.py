"""Actual grant function controls with entirely virtual files/import/native hooks."""
import ast
import datetime
import json
from pathlib import Path
import re
from types import SimpleNamespace

OWN=Path(__file__).resolve().parent
C=Path('/workspace/scratch/rct-validation/np01_broker_sensitivity_caller_correction')
O=Path('/workspace/scratch/rct-validation/np01_broker_sensitivity_sourceprep')
tree=ast.parse((C/'run-stage.py').read_text())
function=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='grant_input')
main=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='main')
early=next(n for n in main.body if isinstance(n,ast.If) and 'args.child and' in ast.unparse(n.test))
procedure=json.loads((C/'native-procedure.safe.json').read_text())
source=json.loads((O/'sourceprep.safe.json').read_text())
now=datetime.datetime.now(datetime.timezone.utc)
base='eb0e02aaf6c7cfb3b80db2d3a3c81b8a2dd79553'
guard='b78c61293568d9941692e0b92ee34fd0b84db6d532b4a2c9a5ad42ccbf2204a0'
review='c61b4647f8467726d2fdc308c2fb046fa1e3552c99e2b2294f1c8524c1c6fb36'
driver='afb5a9fdbf420a24399168384817d06c7e6faeb6debcbef25fd9770fade8fdce'
boundary='bdc061d878ba852bf757ae6cc1b861d090af4c4b948e208abe1e5d90a1831cd3'
digests={'GRANT':'0'*64,'DRIVER':driver,'HERE/native-procedure.safe.json':'6302a3c501d1caacb3c336a5d39d45b875604c4a10884a7fcfefa12b9ed11ab8',
 'ORIGINAL/sourceprep.safe.json':'400475378dbe33e37201f665c3598279710cd65ff800a6ffa0bde5617f568734',
 'GUARD':guard,'GUARD_REVIEW':review,'HERE/caller-boundary.py':boundary}
template={'authorized':True,'phase':'compile','source_base':base,'driver_sha256':driver,
 'procedure_sha256':digests['HERE/native-procedure.safe.json'],'sourceprep_sha256':digests['ORIGINAL/sourceprep.safe.json'],
 'guard_sha256':guard,'boundary_sha256':boundary,'guard_review_manifest_sha256':review,
 'caller_source_review_approved':True,'caller_source_review_sha256':'1'*64,
 'issued_utc':(now-datetime.timedelta(seconds=10)).isoformat(),
 'expires_utc':(now+datetime.timedelta(seconds=1000)).isoformat(),
 'limits':{'disk_delta_cap_bytes':2*1024**3,'workspace_floor_bytes':4*1024**3,
 'shared_growth_cap_bytes':4*1024**3,'shared_stop_bytes':15*1024**3,
 'shared_reserve_bytes':1024**3,'owned_tree_rss_cap_bytes':4*1024**3,
 'cleanup_margin_seconds':60,'deadline_seconds':600}}
state={}; events=[]; cases=[]
class VirtualPath:
    def __init__(self,name):self.name=str(name)
    def __truediv__(self,name):return VirtualPath(self.name+'/'+str(name))
    def is_symlink(self):return False
    def resolve(self):return self
    @property
    def parents(self):return ['ROOT_RECEIPTS']
    def stat(self):return SimpleNamespace(st_mode=0o600)
    def exists(self):return False
    def read_text(self):
        if self.name=='GRANT':return json.dumps(state['grant'])
        if self.name=='HERE/native-procedure.safe.json':return json.dumps(procedure)
        if self.name=='ORIGINAL/sourceprep.safe.json':return json.dumps(source)
        raise AssertionError('No other content reads allowed')
fake_boundary=SimpleNamespace(source_preflight=lambda *a:events.append('SOURCE_PREFLIGHT_STUB'))
loader=SimpleNamespace(exec_module=lambda *a:events.append('BOUNDARY_IMPORT_STUB'))
fake_importlib=SimpleNamespace(util=SimpleNamespace(
 spec_from_file_location=lambda *a:SimpleNamespace(loader=loader),module_from_spec=lambda *a:fake_boundary))
ns={'ROOT_RECEIPTS':'ROOT_RECEIPTS','digest':lambda p:state['digests'][p.name],
 'json':json,'HERE':VirtualPath('HERE'),'ORIGINAL':VirtualPath('ORIGINAL'),'Path':VirtualPath,
 '__file__':'DRIVER','GUARD':VirtualPath('GUARD'),'GUARD_SHA':guard,
 'GUARD_REVIEW':VirtualPath('GUARD_REVIEW'),'GUARD_REVIEW_SHA':review,
 'BASE':base,'GIB':1024**3,'datetime':datetime,'utc':lambda:now,'re':re,'importlib':fake_importlib,
 'WT':VirtualPath('WT')}
exec(compile(ast.Module(body=[function],type_ignores=[]),'<actual-grant-input-virtual>','exec'),ns)
def run(label,grant=None,altered_digest=None,expected=True,before_import=False):
    events.clear();state['grant']=template.copy() if grant is None else grant
    state['digests']=digests|({} if altered_digest is None else altered_digest)
    try:ns['grant_input'](VirtualPath('GRANT'),'0'*64,'compile');accepted=True
    except (ValueError,KeyError,TypeError):accepted=False
    assert accepted==expected,label
    if before_import:assert not events,label+' executed helper stub before rejection'
    cases.append({'id':label,'accepted':accepted,'expected_accepted':expected,
                  'reject_before_helper_execution':before_import})
run('valid_Root_source_attestation_with_closed_virtual_inputs')
for key,bad in [('authorized',False),('phase','fault'),('source_base','0'*40),
 ('driver_sha256','0'*64),('procedure_sha256','0'*64),('sourceprep_sha256','0'*64),
 ('guard_sha256','0'*64),('boundary_sha256','0'*64),('guard_review_manifest_sha256','0'*64),
 ('caller_source_review_approved',False),('caller_source_review_sha256','bad')]:
    run('reject_grant_'+key,template|{key:bad},expected=False,before_import=True)
for key in ['DRIVER','GUARD','GUARD_REVIEW','HERE/caller-boundary.py','HERE/native-procedure.safe.json','ORIGINAL/sourceprep.safe.json']:
    run('reject_actual_source_digest_'+key,altered_digest={key:'f'*64},expected=False,before_import=True)
run('reject_expired_grant',template|{'expires_utc':(now-datetime.timedelta(seconds=1)).isoformat()},expected=False,before_import=True)
run('reject_not_yet_issued_grant',template|{'issued_utc':(now+datetime.timedelta(seconds=1)).isoformat()},expected=False,before_import=True)
run('reject_no_cleanup_margin',template|{'expires_utc':(now+datetime.timedelta(seconds=20)).isoformat()},expected=False)
for limits_key,bad in [('disk_delta_cap_bytes',3*1024**3),('workspace_floor_bytes',3*1024**3),
 ('shared_growth_cap_bytes',5*1024**3),('shared_stop_bytes',16*1024**3),('shared_reserve_bytes',0),
 ('owned_tree_rss_cap_bytes',5*1024**3),('cleanup_margin_seconds',59),('deadline_seconds',601)]:
    run('reject_resource_'+limits_key,template|{'limits':template['limits']|{limits_key:bad}},expected=False)
for value,label in [({},'missing_nonce'),({'NP01_CALLER_NONCE':''},'empty_nonce')]:
    try:
        exec(compile(ast.Module(body=[early],type_ignores=[]),'<actual-early-child>','exec'),
             {'args':SimpleNamespace(child=True),'os':SimpleNamespace(environ=value)})
        denied=False
    except ValueError:denied=True
    assert denied,label
    cases.append({'id':'actual_early_child_reject_'+label,'accepted':False,'expected_accepted':False,
                  'reject_before_grant_or_helper_execution':True})
result={'status':'PASS_SOURCE_ONLY','controls':cases,'controls_count':len(cases),
 'helper_imports':False,'native_or_runtime_execution':False,'real_private_grant_or_nonce_reads':False,
 'qualification':'Actual grant_input and early --child code with virtual files/digests/import stubs. External Root review is an explicit grant attestation, not a fabricated independent verdict.'}
path=OWN/'independent-grant-gates.safe.json'
with path.open('x') as f:json.dump(result,f,indent=2);f.write('\n')
path.chmod(0o600)
print(json.dumps({'status':'PASS_SOURCE_ONLY','controls':len(cases),'native':'NOT_RUN'}))
