import datetime,json,subprocess
from pathlib import Path
OUT=Path(__file__).parent;PROJECT='rct-client-host-config-20261012'
p=subprocess.run(['docker','container','ls','-aq','--no-trunc','--filter','label=com.docker.compose.project='+PROJECT],stdout=subprocess.PIPE,stderr=subprocess.DEVNULL,timeout=10);assert p.returncode==0
ids=p.stdout.decode().splitlines();rows=[]
for ident in ids:
 template='{"id":{{json .Id}},"service":{{json (index .Config.Labels "com.docker.compose.service")}},"project":{{json (index .Config.Labels "com.docker.compose.project")}},"image":{{json .Image}},"status":{{json .State.Status}},"pid":{{json .State.Pid}},"exit":{{json .State.ExitCode}},"oom":{{json .State.OOMKilled}},"health":{{if .State.Health}}{{json .State.Health.Status}}{{else}}null{{end}},"RootFs_logical_bytes":{{json .SizeRootFs}},"Rw_logical_bytes":{{json .SizeRw}}}'
 p=subprocess.run(['docker','inspect','--size',ident,'--format',template],stdout=subprocess.PIPE,stderr=subprocess.DEVNULL,timeout=25);assert p.returncode==0
 row=json.loads(p.stdout);assert row['project']==PROJECT and row['id']==ident;rows.append(row)
 (OUT/'container-status-size.partial.safe.json').write_text(json.dumps({'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'rows':rows},indent=2)+'\n')
report={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'rows':rows,'sizes_are_logical_not_allocated_VFS_blocks':True,'Config_ENV_and_log_HealthLog_not_read':True}
(OUT/'container-status-size.safe.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'states':{r['service']:r['status'] for r in rows},'Mongo':[{k:v for k,v in r.items() if k in ['exit','oom','health']} for r in rows if r['service']=='mongo-attendance']}))
