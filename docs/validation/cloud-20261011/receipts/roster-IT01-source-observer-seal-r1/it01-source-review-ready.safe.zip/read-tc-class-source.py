"""Read cached SDK classfile references only; does not load Java or call Docker."""
from pathlib import Path
import struct
import zipfile


def source(b, selected):
    def u2(o): return struct.unpack_from('>H', b, o)[0]
    def u4(o): return struct.unpack_from('>I', b, o)[0]
    o = 10; cp = {}; i = 1
    while i < u2(8):
        slot = i; t = b[o]; o += 1
        if t == 1:
            l = u2(o); o += 2; v = b[o:o+l].decode('utf8', 'replace'); o += l
        elif t in [7, 8, 16, 19, 20]: v = u2(o); o += 2
        elif t in [9, 10, 11, 12, 17, 18]: v = (u2(o), u2(o+2)); o += 4
        elif t in [3, 4]: v = b[o:o+4].hex(); o += 4
        elif t in [5, 6]: v = b[o:o+8].hex(); o += 8; i += 1
        elif t == 15: v = (b[o], u2(o+1)); o += 3
        else: raise ValueError('Classfile CP kind')
        cp[slot] = (t, v); i += 1
    def sym(idx):
        t, v = cp[idx]
        if t == 1: return v
        if t in [7, 8]: return sym(v)
        if t in [9, 10, 11, 12]: return '::'.join(sym(x) for x in v)
        return str(v)
    o += 6; o += 2 + u2(o)*2
    result = {}
    for kind in ['fields', 'methods']:
        count = u2(o); o += 2
        for _ in range(count):
            flags, name, desc, attrs = struct.unpack_from('>HHHH', b, o); o += 8
            for _ in range(attrs):
                attr = u2(o); size = u4(o+2); o += 6
                if kind == 'methods' and selected(sym(name)) and sym(attr) == 'Code':
                    code = b[o+8:o+8+u4(o+4)]; k = 0; refs = []
                    while k < len(code):
                        op = code[k]; width = 1
                        if op in [0x10,0x12,*range(0x15,0x1a),*range(0x36,0x3b),0xa9,0xbc]: width = 2
                        elif op in [0x11,0x13,0x14,0x84,*range(0x99,0xa9),*range(0xb2,0xb9),0xbb,0xbd,0xc0,0xc1,0xc6,0xc7]: width = 3
                        elif op == 0xc5: width = 4
                        elif op in [0xb9,0xba,0xc8,0xc9]: width = 5
                        elif op == 0xc4: width = 6 if code[k+1] == 0x84 else 4
                        elif op in [0xaa,0xab]:
                            aligned = (k+4)&~3
                            if op == 0xaa:
                                low, high = struct.unpack_from('>ii',code,aligned+4); width = aligned-k+12+4*(high-low+1)
                            else: width = aligned-k+8+8*struct.unpack_from('>i',code,aligned+4)[0]
                        if op == 0x12: refs.append([k,sym(code[k+1])])
                        elif op in [0x13,0x14,*range(0xb2,0xba),0xbb,0xbd,0xc0,0xc1]: refs.append([k,sym(struct.unpack_from('>H',code,k+1)[0])])
                        k += width
                    assert k == len(code)
                    result[sym(name)+sym(desc)] = refs
                o += size
    return result

if __name__ == '__main__':
    import hashlib, json
    result = {'qualification': 'Static classfile instruction references only, no Java loading/Docker. Actual Gradle resolved SDK version UNKNOWN.', 'jars': {}}
    names = ['org/testcontainers/DockerClientFactory.class','org/testcontainers/utility/ResourceReaper.class','org/testcontainers/utility/RyukContainer.class','org/testcontainers/utility/RyukResourceReaper.class','org/testcontainers/containers/GenericContainer.class','org/testcontainers/utility/TestcontainersConfiguration.class','org/testcontainers/dockerclient/DockerClientConfigUtils.class','org/testcontainers/dockerclient/DockerClientProviderStrategy.class','org/testcontainers/utility/MountableFile.class','org/testcontainers/containers/ContainerDef.class']
    for p in sorted(Path('/workspace/.gradle/caches/modules-2/files-2.1/org.testcontainers/testcontainers').rglob('*.jar')):
        with zipfile.ZipFile(p) as z:
            result['jars'][p.name] = {'jar_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'classes': {n: source(z.read(n),lambda method: method in ['<clinit>','client','runInsideDocker','checkMountableFile','checkDiskSpace','markerLabels','environmentSupportsReuse','getEnvVarOrUserProperty','getLabels','maybeStart','register','doStart','tryStart','isFileMountingSupported','getDefaultGateway','getDockerHostIpAddress','createTempDirectory','extractClassPathResourceToTempLocation','applyTo'] or (n.endswith(('RyukContainer.class','DockerClientFactory.class','DockerClientConfigUtils.class')) and (method == '<init>' or method.startswith('lambda$')))) for n in names}}
    out = Path(__file__).with_name('it-testcontainers-sdk-source.safe.json');out.write_text(json.dumps(result,indent=2)+'\n')
    print('Closed static SDK source receipt',hashlib.sha256(out.read_bytes()).hexdigest())
