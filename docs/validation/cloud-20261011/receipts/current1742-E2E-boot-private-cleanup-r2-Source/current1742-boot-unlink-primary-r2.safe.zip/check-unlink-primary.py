"""Selected full cleanup lifecycle RAM only; no files/logs/syscalls."""
import ast,datetime,hashlib,json,os,re,stat,sys,types
from pathlib import Path
OWN=Path(__file__).parent
OLD=OWN.with_name('current1742_e2e_boot_diagnostic_source_r1')/'closed-boot-parser.py'
NEW=OWN/'closed-boot-parser.py'
results=[]
for with_primary in [True,False]:
    row={'case':'PRIMARY_AND_UNLINK_FAILURE' if with_primary else 'CLEANUP_ONLY_UNLINK_FAILURE'}
    for label,path in [('r1',OLD),('r2',NEW)]:
        tree=ast.parse(path.read_text());env={'dt':datetime,'re':re,'stat':stat,'sys':sys}
        nodes=[n for n in tree.body if isinstance(n,(ast.FunctionDef,ast.ClassDef,ast.Assign))]
        exec(compile(ast.Module(body=nodes,type_ignores=[]),str(path),'exec'),env)
        binding={'repo':'DITEKmax/rutcampustrack','head':env['HEAD'],'run_id':env['RUN'],'run_attempt':1,
            'job_id':env['JOB'],'job_name':'Playwright E2E auth flow','step_number':9,'step_name':env['STEP'],
            'step_conclusion':'failure','step_started_at':'2026-10-13T11:03:00Z','step_completed_at':'2026-10-13T11:04:00Z','metadata_verified':True}
        data=b'2026-10-13T11:03:10Z Container rct-e2e-redis-1 Healthy\n'
        st=types.SimpleNamespace(st_mode=0o100600,st_uid=1000,st_nlink=1,st_size=len(data),st_dev=1,st_ino=2,st_mtime_ns=3,st_ctime_ns=4)
        primary=OSError('SYNTHETIC_PRIMARY');cleanup=PermissionError('SYNTHETIC_CLEANUP')
        counts={'read':0,'close':0,'unlink':0}
        def read(fd,n):
            counts['read']+=1
            if with_primary:raise primary
            return data
        def close(fd):counts['close']+=1
        def unlink(*a,**k):
            counts['unlink']+=1
            raise cleanup
        env['os']=types.SimpleNamespace(O_RDONLY=os.O_RDONLY,O_NOFOLLOW=os.O_NOFOLLOW,
            open=lambda *a,**k:20,fstat=lambda _:st,stat=lambda *a,**k:st,read=read,close=close,unlink=unlink)
        caught=None
        try:env['consume_private'](10,binding)
        except BaseException as error:caught=error
        assert counts=={'read':1,'close':1,'unlink':1}
        assert caught is (primary if label=='r2' and with_primary else cleanup)
        if label=='r2' and with_primary:assert caught.__notes__==['PRIVATE_CAPTURE_CLEANUP_RECONCILIATION_REQUIRED']
        row[label]={'denied':True,'primary_preserved':caught is primary,'cleanup_only_error_preserved':caught is cleanup,'real_effects':False}
    results.append(row)
print(json.dumps({'state':'TARGETED_RAM_PASS','cases':results,'source_sha256':{x:hashlib.sha256(p.read_bytes()).hexdigest() for x,p in [('r1',OLD),('r2',NEW)]},'actual_private_log_native':False}))
