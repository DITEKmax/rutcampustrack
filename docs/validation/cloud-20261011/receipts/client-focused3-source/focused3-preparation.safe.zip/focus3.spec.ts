import { test } from '/workspace/rutcampustrack/tests/e2e/fixtures/mobile-dataset';
import { FocusObserver } from './observer';

let observer: FocusObserver | undefined;

// Register against the SAME protected test object before loading the unchanged source tests.
test.beforeEach(async ({ page, dataset }, info) => {
  observer = new FocusObserver(page, dataset, info);
  observer.start();
});

test.afterEach(async ({}, info) => {
  const current = observer;
  observer = undefined;
  if (current) await current.finish(info);
});

// Runtime require preserves hook registration order. No test/assertion body is copied or replaced.
require('/workspace/rutcampustrack/tests/e2e/specs/mobile-real-server.spec.ts');
