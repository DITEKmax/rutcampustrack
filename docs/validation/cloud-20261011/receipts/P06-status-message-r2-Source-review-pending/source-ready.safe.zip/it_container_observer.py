"""Finite IT derivative of reviewed NP01 selected-metadata observer; no env/data inspection."""
import datetime
import json
import hashlib
import os
import stat
from pathlib import Path
import re
import subprocess
import time
import uuid


class ContainerObserver:
    def __init__(self, scope, images, environment, cleanup_allowed, deadline, probe_class_hashes):
        self.started = datetime.datetime.now(datetime.timezone.utc)
        self.scope = scope
        self.images = images
        self.allowed = {row['id']: role for role, rows in images.items() for row in rows}
        self.probe_class_hashes = probe_class_hashes
        if len(self.allowed) != sum(len(rows) for rows in images.values()):
            raise ValueError('Distinct exact image IDs required')
        self.env = environment
        self.cleanup_allowed = cleanup_allowed
        self.deadline = deadline
        self.known = {}
        self.sessions = set()
        self.failure = None
        self.previous = 0.0
        self.commands = 0
        self.client_pids = []
        self.foreign = self.containers()
        self.volumes = set(self.call(['volume', 'ls', '-q']).split())
        self.networks = set(self.call(['network', 'ls', '-q', '--no-trunc']).split())
        for role, rows in images.items():
            for row in rows:
                actual = json.loads(self.call(['image', 'inspect', '--format', '{"id":{{json .Id}},"size":{{json .Size}}}', row['tag']]))
                if actual['id'] != row['id'] or actual['size'] != row['size']:
                    raise ValueError('Pre-existing exact image required; no pull authorized')
        self.save()

    def call(self, arguments):
        remaining = (self.deadline-datetime.datetime.now(datetime.timezone.utc)).total_seconds()
        if remaining <= 0:
            raise RuntimeError("Absolute metadata/cleanup stop reached")
        child = subprocess.Popen(
            ['docker', '--host=unix:///var/run/docker.sock', *arguments],
            env=self.env, stdin=subprocess.DEVNULL, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
        )
        self.client_pids.append(child.pid)
        try:
            output, _ = child.communicate(timeout=min(3, remaining))
        except BaseException:
            child.kill()
            child.wait(timeout=2)
            raise
        self.commands += 1
        if child.returncode:
            raise RuntimeError('Native selected metadata command failed')
        return output.decode()

    def containers(self):
        ids = self.call(['ps', '-aq', '--no-trunc']).split()
        template = '{"id":{{json .Id}},"image":{{json .Image}},"created":{{json .Created}},"name":{{json .Name}},"lang":{{json (index .Config.Labels "org.testcontainers.lang")}},"sdk_version":{{json (index .Config.Labels "org.testcontainers.version")}},"session":{{json (index .Config.Labels "org.testcontainers.sessionId")}},"testcontainers":{{json (index .Config.Labels "org.testcontainers")}},"pid":{{json .State.Pid}},"running":{{json .State.Running}},"mounts":{{json .Mounts}}}'
        if not ids:
            return {}
        try:
            values = self.call(['inspect', '--format', template, *ids])
        except RuntimeError:
            current = self.call(['ps', '-aq', '--no-trunc']).split()
            if not (set(ids) - set(current)).issubset(self.known):
                raise
            if not current:
                return {}
            values = self.call(['inspect', '--format', template, *current])
        return {row['id']: row for row in map(json.loads, values.splitlines())}

    def accept(self, value):
        created = datetime.datetime.fromisoformat(value['created'])
        if not (created.tzinfo and self.started <= created <= self.deadline):
            raise ValueError('Container created inside fresh finite phase required')
        role = self.allowed.get(value['image'])
        session = value['session']
        if role == 'ryuk':
            name = value['name']
            prefix = '/testcontainers-ryuk-'
            if not name.startswith(prefix) or (session and session != name[len(prefix):]):
                raise ValueError('Standard Ryuk session name required')
            session = name[len(prefix):]
        if (role is None or value['testcontainers'] != 'true' or value['lang'] != 'java'
                or value['sdk_version'] not in self.probe_class_hashes or str(uuid.UUID(session)) != session):
            raise ValueError('New resource exact image/default session labels required')
        if role == 'ryuk':
            expected_tag = {'1.20.4': 'testcontainers/ryuk:0.11.0', '1.21.4': 'testcontainers/ryuk:0.12.0'}[value['sdk_version']]
            if not any(row['id'] == value['image'] and row['tag'] == expected_tag for row in self.images['ryuk']):
                raise ValueError('Standard image/default SDK version mismatch')
        if value['id'] in self.known and value != self.known[value['id']]['metadata']:
            previous = self.known[value['id']]['metadata']
            if any(value[key] != previous[key] for key in ['id', 'image', 'created', 'name', 'lang', 'sdk_version', 'session', 'testcontainers', 'mounts']):
                raise ValueError('Owned resource identity changed')
        destinations = {'postgres': {'/var/lib/postgresql/data'}, 'mongo': {'/data/db', '/data/configdb'},
                        'rabbitmq': {'/var/lib/rabbitmq'}, 'redis': {'/data'}, 'ryuk': {'/var/run/docker.sock'}, 'probe': {'/dummy'}}
        for mount in value['mounts']:
            if mount['Destination'] not in destinations[role]:
                raise ValueError('Unexpected mount destination')
            if role == 'ryuk':
                if mount['Type'] != 'bind' or mount['Source'] != '/var/run/docker.sock':
                    raise ValueError('Only standard Ryuk socket bind allowed')
            elif role == 'probe' and value['id'] not in self.known:
                source = Path(mount['Source'])
                private_tmp = self.scope / 'private-tmp'
                if (mount['Type'] != 'bind' or mount['RW'] is not False or not source.is_relative_to(private_tmp)
                        or source.resolve() != source.absolute() or not source.is_file()):
                    raise ValueError('Only own SDK read-only classpath probe bind allowed')
                descriptor = os.open(source, os.O_RDONLY | os.O_NOFOLLOW)
                with os.fdopen(descriptor, 'rb') as stream:
                    info = os.fstat(stream.fileno())
                    if not stat.S_ISREG(info.st_mode) or info.st_size > 65536:
                        raise ValueError('Bounded public SDK class file required')
                    class_sha = hashlib.sha256(stream.read(65537)).hexdigest()
                if class_sha != self.probe_class_hashes[value['sdk_version']]:
                    raise ValueError('Exact public SDK ResourceReaper.class probe required')
            elif role == 'probe':
                pass
            elif mount['Type'] != 'volume' or not re.fullmatch('[0-9a-f]{64}', mount['Name']) or mount['Name'] in self.volumes:
                raise ValueError('Only fresh anonymous data volumes allowed')
        candidate_sessions = self.sessions | {session}
        birth = None
        if value['pid']:
            try:
                fields = Path('/proc', str(value['pid']), 'stat').read_text().rsplit(')', 1)[1].split()
                birth = int(fields[19])
            except FileNotFoundError:
                pass
        candidate_known = {**self.known, value['id']: {'role': role, 'metadata': value, 'process_birth_ticks': birth,
            'ownership_basis': 'foreign baseline/exclusive Root Docker creation lease/reviewed fixtures/default JVM-random session labels/exact images; PID-to-UUID not directly observed'}}
        if len(candidate_sessions) > 2 or len(candidate_known) > 10:
            raise ValueError('Finite resource/session cardinality exceeded')
        for namespace in candidate_sessions:
            probes = sum(row['role'] == 'probe' and row['metadata']['session'] == namespace for row in candidate_known.values())
            if probes > 2:
                raise ValueError('At most cached mount+gateway probe per JVM namespace')
        counts = {role: sum(row['role'] == role for row in candidate_known.values()) for role in self.images}
        if any(count > (2 if role == 'ryuk' else 4 if role == 'probe' else 1) for role, count in counts.items()):
            raise ValueError('Finite per-image cardinality exceeded')
        self.sessions = candidate_sessions
        self.known = candidate_known

    def save(self, active=None, settled=None):
        record = {'utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'failure': self.failure,
                  'foreign_container_metadata': self.foreign, 'foreign_volume_names': sorted(self.volumes),
                  'foreign_network_ids': sorted(self.networks), 'known_owned_resources': self.known,
                  'session_namespaces': sorted(self.sessions), 'active_owned_ids': active,
                  'settled': settled, 'native_metadata_commands': self.commands,
                  'metadata_client_pids_waited': self.client_pids, 'environment_or_data_inspected': False}
        target = self.scope / 'containers.safe.json'
        temporary = target.with_suffix('.json.next')
        temporary.write_text(json.dumps(record, indent=2) + '\n')
        temporary.replace(target)

    def sample(self, force=False):
        if self.failure:
            return self.failure
        now = time.monotonic()
        if not force and now-self.previous < 5:
            return None
        self.previous = now
        try:
            values = self.containers()
            if any(values.get(key) != expected for key, expected in self.foreign.items()):
                raise ValueError('Foreign resource metadata changed')
            for key, value in values.items():
                if key not in self.foreign:
                    self.accept(value)
            if set(self.call(['network', 'ls', '-q', '--no-trunc']).split()) != self.networks:
                raise ValueError('Unexpected network creation')
            volumes = set(self.call(['volume', 'ls', '-q']).split())
            if not self.volumes.issubset(volumes):
                raise ValueError('Unexpected volume creation/removal')
            self.save(active=sorted(set(values)-set(self.foreign)))
        except BaseException as failure:
            self.failure = 'IT_METADATA_' + type(failure).__name__
            self.save()
        return self.failure

    def settle(self):
        # Normal Testcontainers/Ryuk cleanup first; no daemon process is a b78 child.
        # Preserve an observation failure while still settling only already admitted IDs.
        for _ in range(3):
            values = self.containers()
            if not (set(values) & set(self.known)):
                break
            time.sleep(1)
        remaining = set(values) & set(self.known)
        if remaining:
            if not self.cleanup_allowed:
                self.failure = self.failure or 'OWNED_CONTAINER_CLEANUP_NOT_AUTHORIZED'
                self.save(active=sorted(remaining), settled=False)
                return False
            for key in sorted(remaining):
                # Re-observe exact ID/session/image/mounts immediately before own-ID removal.
                value = self.containers().get(key)
                if value is None:
                    continue
                self.accept(value)
                self.call(['rm', '-fv', key])
        values = self.containers()
        okay = (values == self.foreign and set(self.call(['volume', 'ls', '-q']).split()) == self.volumes
                and set(self.call(['network', 'ls', '-q', '--no-trunc']).split()) == self.networks)
        self.save(active=sorted(set(values)-set(self.foreign)), settled=okay)
        return okay
