const fs = require('node:fs'), path = require('node:path'), crypto = require('node:crypto'), cp = require('node:child_process');
const ts = require('/workspace/rutcampustrack/frontends/node_modules/typescript/lib/typescript.js');
const W = '/workspace/rct-worktrees/client-ci-first3/tests/e2e';
const marker = 'RCT_PUBLIC_HINT_WORKER_' + crypto.randomUUID();
const output = process.env.RCT_SAFE_FAILURE_CONTROL_OUTPUT;
const child = cp.spawnSync(process.execPath, ['--max-old-space-size=512', W + '/node_modules/playwright/cli.js', 'test', '--config', __dirname + '/worker-control.config.ts'], { cwd: W, encoding: 'utf8', timeout: 60000, env: { ...process.env, RCT_SAFE_FAILURE_CONTROL_MARKER: marker } });
function files(dir) { return fs.readdirSync(dir, { withFileTypes: true }).flatMap(x => x.isDirectory() ? files(path.join(dir, x.name)) : [path.join(dir, x.name)]); }
let report = null; try { report = JSON.parse(fs.readFileSync(path.join(output, 'safe-results.json'), 'utf8')); } catch {}
const artifacts = fs.existsSync(output) ? files(output) : [];
const markerAbsent = [child.stdout || '', child.stderr || '', ...artifacts.map(p => fs.readFileSync(p).toString())].every(text => !text.includes(marker));
const bodiesNotStarted = !artifacts.some(p => p.endsWith('body-started.safe.json'));
const rows = Array.isArray(report?.results) ? report.results : [];
const source = fs.readFileSync(W + '/fixtures/safe-reporter.ts', 'utf8');
const parserDiagnosticCount = ts.createSourceFile('safe-reporter.ts', source, ts.ScriptTarget.ES2022, true).parseDiagnostics.length;
const box = { exports: {} };
new Function('require', 'module', 'exports', '__dirname', ts.transpileModule(source, { compilerOptions: { target: ts.ScriptTarget.ES2022, module: ts.ModuleKind.CommonJS } }).outputText)(require, box, box.exports, W + '/fixtures');
const validStatuses = new Set(['passed', 'failed', 'timedOut', 'skipped', 'interrupted']);
const caseCodes = { 9: 'EARLY_CLASS', 23: 'LATE_FABRICATED_FRAME', 29: 'MULTILINE_UNKNOWN' };
const retainedRows = rows.slice(0, 3).map(row => {
  const annotations = (Array.isArray(row.diagnostics) ? row.diagnostics : []).slice(0, 8).map(value => ({ type: box.exports.safeFailureAnnotation, description: typeof value?.cause === 'string' && value.cause.length <= 64 && Number.isSafeInteger(value.httpStatus) ? value.cause + ':' + value.httpStatus : '' }));
  return {
    caseCode: row.file === 'reported-hints.control.spec.ts' && Object.hasOwn(caseCodes, row.line) ? caseCodes[row.line] : 'UNKNOWN',
    sourceLine: Object.hasOwn(caseCodes, row.line) ? row.line : 0,
    status: validStatuses.has(row.status) ? row.status : 'UNKNOWN',
    expectedStatus: validStatuses.has(row.expectedStatus) ? row.expectedStatus : 'UNKNOWN',
    errorCount: Number.isSafeInteger(row.errorCount) && row.errorCount >= 0 && row.errorCount <= 32 ? row.errorCount : 0,
    diagnostics: box.exports.safeFailureDiagnostics(annotations, row.errorCount > 0),
  };
});
const diagnostics = code => retainedRows.find(row => row.caseCode === code)?.diagnostics ?? [];
const has = (code, cause) => diagnostics(code).some(value => value.cause === cause);
const earlyClassTransported = has('EARLY_CLASS', 'REPORTED_CLASS_TYPE_ERROR');
const lateReportedFrameTransported = has('LATE_FABRICATED_FRAME', 'REPORTED_CLASS_ERROR') && has('LATE_FABRICATED_FRAME', 'REPORTED_FRAME_DATASET_CALL');
const multilineRemainsUnknown = diagnostics('MULTILINE_UNKNOWN').length === 1 && has('MULTILINE_UNKNOWN', 'UNKNOWN');
const failedTestsRetained = rows.length === 3 && rows.every(row => row.status === 'failed' && row.expectedStatus === 'failed' && row.errorCount > 0);
const noProvenStageOrHttp = retainedRows.every(row => row.diagnostics.length > 0 && row.diagnostics.every(value => value.stage === 'UNKNOWN' && value.httpStatus === 0));
const result = { pass: child.status === 0 && markerAbsent && bodiesNotStarted && failedTestsRetained && earlyClassTransported && lateReportedFrameTransported && multilineRemainsUnknown && noProvenStageOrHttp && parserDiagnosticCount === 0 && report?.runnerErrors === 0 && report?.unsafeArtifact === false, childNativeExit: child.status, caseCount: rows.length, failedTestsRetained, markerAbsent, bodiesNotStarted, earlyClassTransported, lateReportedFrameTransported, multilineRemainsUnknown, noProvenStageOrHttp, parserDiagnosticCount, retainedRows, omittedRowCount: Math.max(0, rows.length - retainedRows.length), reportedHintsUntrusted: true, noBrowserApi: true, actualCIcause: 'UNKNOWN' };
// Save closed rows before the existing outer supervisor removes public control artifacts.
fs.writeFileSync(process.env.RCT_SAFE_DIAGNOSTIC_RECEIPT, JSON.stringify(result, null, 2) + '\n', { mode: 0o600 });
process.exitCode = result.pass ? 0 : 1;
