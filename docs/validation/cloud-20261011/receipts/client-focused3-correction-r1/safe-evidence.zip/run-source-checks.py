"""Serial source-adapter red/green, types, closed-field and list checks; fresh Root grant required."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import stat
import sys
import types

BASE = Path('/workspace/scratch/rct-validation/client_real_acceptance/focused3-preparation-5ced-r1')
ROOT = Path('/workspace/rutcampustrack')
GUARD = Path('/workspace/scratch/rct-validation/guard_proc_race_correction/bounded-child.py')
UTC = datetime.timezone.utc


def digest(path):
    value = hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(2097152), b''):
            value.update(chunk)
    return value.hexdigest()


def require(value, stage):
    if not value:
        raise RuntimeError(stage)


def atomic(path, value):
    temporary = path.with_suffix(path.suffix + '.next')
    with temporary.open('x', encoding='utf-8') as stream:
        json.dump(value, stream, indent=2)
        stream.write('\n')
    temporary.chmod(0o600)
    temporary.replace(path)


def main():
    os.umask(0o077)
    require(len(sys.argv) == 2, 'ROOT_NODE_GRANT_REQUIRED')
    grant_path = Path(sys.argv[1])
    require(grant_path.is_absolute() and grant_path.parent == BASE / 'private', 'GRANT_PATH_INVALID')
    info = grant_path.lstat()
    require(stat.S_ISREG(info.st_mode) and not grant_path.is_symlink()
            and stat.S_IMODE(info.st_mode) == 0o600, 'GRANT_MODE_INVALID')
    grant = json.loads(grant_path.read_text())
    ready_path = BASE / 'READY.safe.json'
    ready = json.loads(ready_path.read_text())
    now = datetime.datetime.now(UTC)
    stop = datetime.datetime.fromisoformat(grant['absolute_stop_at'].replace('Z', '+00:00'))
    issued = datetime.datetime.fromisoformat(grant['issued_at'].replace('Z', '+00:00'))
    expires = datetime.datetime.fromisoformat(grant['expires_at'].replace('Z', '+00:00'))
    require(stop.tzinfo is not None and issued.tzinfo is not None and expires.tzinfo is not None
            and issued <= now < stop <= expires, 'GRANT_EXPIRED')
    require(grant['authorized'] is True and grant['scope'] == 'focused3-node-source-checks'
            and grant['phases'] == ['lifetime-red', 'lifetime-green', 'types', 'fields', 'list']
            and grant['browser_api_network_authorized'] is False, 'NODE_ONLY_SCOPE_REQUIRED')
    require(grant['ready_sha256'] == digest(ready_path)
            and grant['prepared_source_sha'] == ready['prepared_source_sha'], 'READY_CHANGED')
    require(bool(ready['root_source_hashes']) and bool(ready['own_source_hashes'])
            and set(grant['expected_root_source_paths']) == set(ready['root_source_hashes']), 'SOURCE_LEDGER_INCOMPLETE')
    for name, sha in ready['root_source_hashes'].items():
        require(digest(ROOT / name) == sha, 'ROOT_SOURCE_CHANGED')
    for name, sha in ready['own_source_hashes'].items():
        require(digest(BASE / name) == sha, 'OWN_SOURCE_CHANGED')
    for name, sha in ready['runtime_hashes'].items():
        require(digest(Path(name)) == sha, 'PINNED_RUNTIME_SOURCE_CHANGED')
    for name, source in ready['third_party_links'].items():
        path = ROOT / 'tests/e2e/node_modules' / name
        require(path.is_symlink() and str(path.resolve()) == source['resolved_path']
                and digest(path / 'package.json') == source['package_sha256'], 'THIRD_PARTY_LINK_CHANGED')
    for name, sha in ready['clock_hashes'].items():
        require(digest(Path(name)) == sha, 'TEACHING_CLOCK_CHANGED')
    require(digest(GUARD) == ready['guard_sha256'] == grant['guard_sha256'], 'GUARD_CHANGED')
    require(grant['node_heap_mib'] == 512 and grant['owned_total_rss_stop_bytes'] <= 1073741824
            and grant['cache_stop_bytes'] <= 134217728 and grant['disk_floor_bytes'] >= 4294967296
            and grant['shared_stop_bytes'] <= 16106127360
            and grant['shared_memory_reserve_bytes'] >= 1073741824
            and 0 < grant['deadline_seconds'] <= 180, 'RESOURCE_SCOPE_INVALID')
    runs = BASE / 'runs'
    runs.mkdir(mode=0o700, exist_ok=True)
    require(stat.S_IMODE(runs.stat().st_mode) == 0o700 and not runs.is_symlink()
            and runs.stat().st_uid == os.geteuid(), 'RUN_PARENT_INVALID')
    require(grant['attempt'] in ['attempt-90', 'attempt-91', 'attempt-92'], 'SOURCE_ATTEMPT_INVALID')
    run = runs / grant['attempt']
    run.mkdir(mode=0o700, exist_ok=False)
    for name in ['artifacts', 'supervision', 'private-tmp', 'transform-cache']:
        (run / name).mkdir(mode=0o700)
    supervision = run / 'supervision'
    guard = types.ModuleType('reviewed_owned_guard')
    guard.__file__ = str(GUARD)
    exec(compile(GUARD.read_bytes(), str(GUARD), 'exec'), guard.__dict__)
    latest = {}
    active_phase = 'lifetime-red'
    peaks = {'owned_rss_bytes': 0, 'run_allocated_bytes': 0, 'shared_memory_bytes': 0}

    def status(value):
        child = guard.process_table().get(value['child_pid'])
        if child is not None:
            value = {**value, 'direct_birth': child['start_ticks']}
        latest.clear()
        latest.update(value)
        atomic(supervision / (active_phase + '-process.safe.json'), value)

    def observe():
        if datetime.datetime.now(UTC) >= stop:
            return 'ABSOLUTE_DEADLINE'
        for filesystem in ['/workspace', '/tmp']:
            value = os.statvfs(filesystem)
            if value.f_bavail * value.f_frsize < grant['disk_floor_bytes']:
                return 'DISK_FLOOR'
        used = int(Path('/sys/fs/cgroup/memory.current').read_text())
        limit = int(Path('/sys/fs/cgroup/memory.max').read_text())
        peaks['shared_memory_bytes'] = max(peaks['shared_memory_bytes'], used)
        if used >= grant['shared_stop_bytes'] or limit - used < grant['shared_memory_reserve_bytes']:
            return 'SHARED_MEMORY_STOP'
        table = guard.process_table()
        rss = next((int(line.split()[1]) * 1024 for line in Path('/proc/self/status').read_text().splitlines()
                    if line.startswith('VmRSS:')), 0)
        for row in latest.get('members_including_Z', []):
            current = table.get(row['pid'])
            if current is None or current['start_ticks'] != row['start_ticks']:
                continue
            try:
                lines = Path('/proc', str(row['pid']), 'status').read_text().splitlines()
            except FileNotFoundError:
                continue
            rss += next((int(line.split()[1]) * 1024 for line in lines if line.startswith('VmRSS:')), 0)
        peaks['owned_rss_bytes'] = max(peaks['owned_rss_bytes'], rss)
        if rss > grant['owned_total_rss_stop_bytes']:
            return 'OWN_TOTAL_RSS_STOP'
        allocated = sum(path.lstat().st_blocks * 512 for path in run.rglob('*')
                        if path.is_file() and not path.is_symlink())
        peaks['run_allocated_bytes'] = max(peaks['run_allocated_bytes'], allocated)
        return 'OWN_CACHE_STOP' if allocated > grant['cache_stop_bytes'] else None

    env = {name: os.environ[name] for name in ['PATH', 'LANG', 'LC_ALL', 'TZ'] if name in os.environ}
    env.update(CI='true', RCT_E2E_SYNTHETIC_SEED='true', E2E_BASE_URL='https://localhost:8443',
               PLAYWRIGHT_NO_COPY_PROMPT='1', RCT_FOCUS3_RUN=str(run),
               RCT_FOCUS3_OBSERVATIONS=str(supervision / 'observations.safe.json'),
               RCT_FOCUS3_LIST_OUTPUT=str(supervision / 'list.safe.json'),
               RCT_FOCUS3_TYPES_OUTPUT=str(supervision / 'types.safe.json'),
               RCT_FOCUS3_FIELDS_OUTPUT=str(supervision / 'fields.safe.json'),
               PWTEST_CACHE_DIR=str(run / 'transform-cache'),
               TMPDIR=str(run / 'private-tmp'), TMP=str(run / 'private-tmp'), TEMP=str(run / 'private-tmp'))
    node = ['node', '--max-old-space-size=512']
    phases = [
        ('lifetime-red', node + [str(BASE / 'check-observer-lifetime.cjs'), 'old']),
        ('lifetime-green', node + [str(BASE / 'check-observer-lifetime.cjs'), 'new']),
        ('types', node + [str(BASE / 'typecheck-safe.cjs')]),
        ('fields', node + [str(BASE / 'check-observer-fields.cjs')]),
        ('list', node + [str(ROOT / 'tests/e2e/node_modules/playwright/cli.js'), 'test', '--list',
                         '--config', str(BASE / 'source-discovery.config.ts'), '--project=chromium']),
    ]
    results = []
    for active_phase, argv in phases:
        seconds = min(grant['deadline_seconds'], int((stop - datetime.datetime.now(UTC)).total_seconds()))
        require(seconds > 0, 'GRANT_EXPIRED_BETWEEN_PHASES')
        atomic(supervision / (active_phase + '-launch.safe.json'), {'phase': active_phase, 'argv': argv,
               'ready_sha256': digest(ready_path), 'deadline_seconds': seconds, 'absolute_stop_at': stop.isoformat()})
        env['RCT_FOCUS3_LIFETIME_OUTPUT'] = str(supervision / (active_phase + '.safe.json'))
        result = guard.run_owned(argv, str(ROOT / 'tests/e2e'), env, deadline_seconds=seconds,
                                 observe=observe, status=status)
        accepted = result['phase_success']
        safe_path = supervision / (active_phase + '.safe.json')
        safe = json.loads(safe_path.read_text()) if safe_path.exists() else {}
        if active_phase == 'lifetime-red':
            accepted = result['native_exit'] == 1 and result['terminal_reason'] == 'NATIVE_TERMINAL' and result['settled'] and result['all_owned_processes_reaped'] and result['supervision_error_type'] is None and safe.get('expectedCounterexample') is True and safe.get('facts') == {'oldCounterexample': True, 'responseDisposeUsed': True}
        result.update(phase=active_phase, accepted_phase=accepted, peaks=peaks.copy())
        atomic(supervision / (active_phase + '-terminal.safe.json'), result)
        results.append(result)
        if not accepted:
            break
        if not safe.get('pass'):
            break
    settled = all(item['settled'] and item['all_owned_processes_reaped'] for item in results)
    passed = len(results) == 5 and all(item['accepted_phase'] for item in results)
    safe_passes = [(supervision / (name + '.safe.json')).exists() and
                   json.loads((supervision / (name + '.safe.json')).read_text()).get('pass') is True
                   for name in ['lifetime-red', 'lifetime-green', 'types', 'fields', 'list']]
    passed = passed and all(safe_passes)
    temporary_removed = False
    if settled:
        import shutil
        temporary = run / 'private-tmp'
        require(not temporary.is_symlink() and temporary.stat().st_uid == os.geteuid()
                and stat.S_IMODE(temporary.stat().st_mode) == 0o700, 'PRIVATE_TMP_INVALID')
        shutil.rmtree(temporary)
        temporary_removed = True
    atomic(supervision / 'SOURCE-CHECKS.safe.json', {'state': 'PASS_SOURCE_CHECKS' if passed else 'FAILED_SOURCE_CHECKS',
           'settled': settled, 'completed_phase_count': len(results), 'pass': passed,
           'browser_api_network_started': False, 'private_tmp_removed': temporary_removed, 'peaks': peaks})
    print(json.dumps({'stage': 'NODE_SOURCE_CHECKS', 'settled': settled, 'pass': passed, 'phase_count': len(results)}))
    return 0 if passed and settled else 1


if __name__ == '__main__':
    try:
        raise SystemExit(main())
    except Exception:
        print('{"state":"BLOCKED","stage":"NODE_SOURCE_PREFLIGHT_OR_SUPERVISION"}')
        raise SystemExit(2)
