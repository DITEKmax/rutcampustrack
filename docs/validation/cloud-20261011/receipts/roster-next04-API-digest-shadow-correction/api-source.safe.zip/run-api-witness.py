from pathlib import Path
import datetime,hashlib,json,os,shlex,shutil,stat,subprocess,sys,types
BASE=Path('/workspace/scratch/rct-validation/client_real_acceptance/roster-witness-correction-r2/api-next04-correction')
NATIVE=BASE;GRANT=Path(sys.argv[1])
gs=GRANT.lstat();assert not GRANT.is_symlink() and stat.S_ISREG(gs.st_mode) and stat.S_IMODE(gs.st_mode)==0o600 and gs.st_uid==os.geteuid()
g=json.loads(GRANT.read_text());plan=json.loads((NATIVE/'NATIVE-PLAN.safe.json').read_text())
assert g['authorized_by_root'] is True and g['scope']==plan['scope'] and g['allow_format_write'] is False
assert GRANT.parent==BASE/'private' and stat.S_IMODE(GRANT.stat().st_mode)==0o600
assert hashlib.sha256((NATIVE/'NATIVE-PLAN.safe.json').read_bytes()).hexdigest()==g['native_plan_sha256']
run=Path(g['scope_new_own_run']);supervision=run/'supervision';UTC=datetime.timezone.utc;stop=datetime.datetime.fromisoformat(g['stop_utc'])
grant={'disk_floor_bytes':g['workspace_floor'],'shared_stop_bytes':g['shared_stop'],'shared_memory_reserve_bytes':g['shared_reserve'],'owned_total_rss_stop_bytes':g['owned_RSS_cap'],'cache_stop_bytes':g['own_tmp_cache_cap']}
GUARD=Path('/workspace/scratch/rct-validation/guard_proc_race_correction/bounded-child.py')
assert hashlib.sha256(GUARD.read_bytes()).hexdigest()==g['guard_sha256']
guard=types.ModuleType('reviewed_owned_guard');guard.__file__=str(GUARD);exec(compile(GUARD.read_bytes(),str(GUARD),'exec'),guard.__dict__)
def atomic(path,value):
 temporary=path.with_suffix(path.suffix+'.next');temporary.write_text(json.dumps(value,indent=2)+'\n');temporary.chmod(0o600);temporary.replace(path)

def digest(path):
    value = hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(2097152), b''):
            value.update(chunk)
    return value.hexdigest()

def require(condition, stage):
    if not condition:
        raise RuntimeError(stage)

def instant(value):
    result = datetime.datetime.fromisoformat(value.replace('Z', '+00:00'))
    require(result.tzinfo is not None, 'GRANT_CLOCK_INVALID')
    return result.astimezone(UTC)

def private_directory(path):
    value = path.lstat()
    require(stat.S_ISDIR(value.st_mode) and not path.is_symlink()
            and stat.S_IMODE(value.st_mode) == 0o700
            and value.st_uid == os.geteuid(), 'PRIVATE_DIRECTORY_INVALID')

def fresh_preflight(grant, stop):
    for filesystem in ['/workspace', '/tmp']:
        value = os.statvfs(filesystem)
        require(value.f_bavail * value.f_frsize >= grant['disk_floor_bytes'], 'DISK_FLOOR_AT_USE')
    used = int(Path('/sys/fs/cgroup/memory.current').read_text())
    limit = int(Path('/sys/fs/cgroup/memory.max').read_text())
    require(used < grant['shared_stop_bytes'] and limit - used >= grant['shared_memory_reserve_bytes'], 'SHARED_MEMORY_AT_USE')
    rss = next((int(line.split()[1]) * 1024 for line in Path('/proc/self/status').read_text().splitlines() if line.startswith('VmRSS:')), 0)
    require(rss <= grant['owned_total_rss_stop_bytes'], 'OWN_RSS_AT_USE')
    issued = instant(grant['issued_at'])
    require(issued <= datetime.datetime.now(UTC) < stop, 'GRANT_EXPIRED_AT_USE')

def fresh_cohort(grant, ready):
    bound = Path(grant['stand_ready_receipt'])
    require(digest(bound) == grant['stand_ready_receipt_sha256'], 'COHORT_BIND_CHANGED')
    value = json.loads(bound.read_text())
    require(value['schema'] == 'RCT_FOCUS3_CURRENT96_COHORT_BIND_V1'
            and value['cohort'] == grant['cohort'] and value['cohort'] != 'restart-20261012-next01'
            and value['ready_sha256'] == digest(BASE / 'READY.safe.json')
            and value['execution_checkout_sha'] == grant['execution_checkout_sha']
            and value['current_academic_source_sha256'] == ready['current_academic_source']['sha256']
            and value['current_academic_payload_source_verified'] is True
            and value['critical_TLS_Admin_FULL_edge_directspoof'] is True,
            'CURRENT_COHORT_UNBOUND')
    require(instant(value['host_cleanup_dispatch_at']) == instant(grant['stand_cleanup_at']), 'HOST_STOP_UNBOUND')
    require(set(value['receipts']) == {'artifact_source', 'runtime_mapping', 'critical_readiness', 'host_live8'}, 'COHORT_RECEIPTS_INCOMPLETE')
    for row in value['receipts'].values():
        require(Path(row['path']).is_absolute() and digest(Path(row['path'])) == row['sha256'], 'COHORT_RECEIPT_CHANGED')
    rows = value['live8']
    require(len(rows) == 8 and {row['service'] for row in rows} == {'mongo','academic','auth','schedule','attendance','bff','gateway','notification'}, 'LIVE8_INCOMPLETE')
    identities = [(row[kind + '_pid'], row[kind + '_birth_ticks']) for row in rows for kind in ['wrapper', 'child']]
    require(len(set(identities)) == 16 and len({pid for pid, birth in identities}) == 16, 'LIVE16_DISTINCT_REQUIRED')
    for row in rows:
        for kind in ['wrapper', 'child']:
            fields = Path('/proc', str(row[kind + '_pid']), 'stat').read_text().rsplit(')', 1)[1].split()
            require(int(fields[19]) == row[kind + '_birth_ticks'] and fields[0] != 'Z', 'STAND_BIRTH_NOT_LIVE')
            if kind == 'child':
                require(int(fields[1]) == row['wrapper_pid'], 'STAND_CHILD_PARENT_MISMATCH')

latest={};active_phase='witness';peaks={'owned_rss_bytes':0,'run_allocated_bytes':0,'shared_memory_bytes':0}
def status(value):
    child = guard.process_table().get(value['child_pid'])
    if child is not None:
        value = {**value, 'direct_birth': child['start_ticks']}
    latest.clear()
    latest.update(value)
    atomic(supervision / (active_phase + '-process.safe.json'), value)

def observe():
    if datetime.datetime.now(UTC) >= stop:
        return 'ABSOLUTE_DEADLINE'
    for filesystem in ['/workspace', '/tmp']:
        value = os.statvfs(filesystem)
        if value.f_bavail * value.f_frsize < grant['disk_floor_bytes']:
            return 'DISK_FLOOR'
    used = int(Path('/sys/fs/cgroup/memory.current').read_text())
    limit = int(Path('/sys/fs/cgroup/memory.max').read_text())
    peaks['shared_memory_bytes'] = max(peaks['shared_memory_bytes'], used)
    if used >= grant['shared_stop_bytes'] or limit - used < grant['shared_memory_reserve_bytes']:
        return 'SHARED_MEMORY_STOP'
    table = guard.process_table()
    rss = next((int(line.split()[1]) * 1024 for line in Path('/proc/self/status').read_text().splitlines()
                if line.startswith('VmRSS:')), 0)
    for row in latest.get('members_including_Z', []):
        current = table.get(row['pid'])
        if current is None or current['start_ticks'] != row['start_ticks']:
            continue
        try:
            lines = Path('/proc', str(row['pid']), 'status').read_text().splitlines()
        except FileNotFoundError:
            continue
        rss += next((int(line.split()[1]) * 1024 for line in lines if line.startswith('VmRSS:')), 0)
    peaks['owned_rss_bytes'] = max(peaks['owned_rss_bytes'], rss)
    if rss > grant['owned_total_rss_stop_bytes']:
        return 'OWN_TOTAL_RSS_STOP'
    allocated = sum(path.lstat().st_blocks * 512 for path in run.rglob('*')
                    if path.is_file() and not path.is_symlink())
    peaks['run_allocated_bytes'] = max(peaks['run_allocated_bytes'], allocated)
    return 'OWN_CACHE_STOP' if allocated > grant['cache_stop_bytes'] else None



for filename,expected_sha in plan['immutablePins'].items():
 assert hashlib.sha256(Path(filename).read_bytes()).hexdigest()==expected_sha
for filename,expected_sha in plan['mutableOnlyAfterExplicitFormatGrant'].items():
 path=Path(filename);assert not path.is_symlink() and path.stat().st_nlink==1 and hashlib.sha256(path.read_bytes()).hexdigest()==expected_sha
assert g['format_write_scope']==[] and all(row['name']!='format-write' for row in plan['commands'])
assert os.access(plan['commands'][0]['argv'][0],os.X_OK)
require(os.getuid()==os.getgid()==1000 and Path('/').lstat().st_uid==Path('/').lstat().st_gid==0,'APPROVED_CONTEXT_REQUIRED')
private_directory(BASE/'private')
api_ready=json.loads((BASE/'READY.safe.json').read_text())
require(g['approved_network_IPC_context'] is True and g['base_url']=='https://localhost:8443' and g['single_roster_get'] is True and g['auth_admission_logout_allowed'] is True and g['read_initial_password_ram_allowed'] is True and g['domain_write_reset_seed_allowed'] is False, 'API_SCOPE_INVALID')
require(g['execution_checkout_sha']==api_ready['execution_checkout_sha'] and subprocess.check_output(['git','-C','/workspace/rutcampustrack','rev-parse','HEAD'],stderr=subprocess.DEVNULL).decode().strip()==g['execution_checkout_sha'], 'EXECUTION_HEAD_INVALID')
require(g['ready_sha256']==digest(BASE/'READY.safe.json') and instant(g['stand_cleanup_at'])-stop>=datetime.timedelta(seconds=30) and 0<g['per_phase_seconds']<=60, 'API_SOURCE_TIME_INVALID')
require(g['disk_floor_bytes']==g['workspace_floor'] and g['shared_stop_bytes']==g['shared_stop'] and g['shared_memory_reserve_bytes']==g['shared_reserve'] and g['owned_total_rss_stop_bytes']==g['owned_RSS_cap'], 'RESOURCE_ALIAS_MISMATCH')
for name,sha in api_ready['root_source_hashes'].items():
 p=Path('/workspace/rutcampustrack')/name;require(p.is_file() and not p.is_symlink() and digest(p)==sha,'ROOT_SOURCE_CHANGED')
for name,sha in api_ready['clock_hashes'].items():require(digest(Path(name))==sha,'CLOCK_CHANGED')
require(not run.exists() and not run.is_symlink() and run.parent==Path('/tmp') and run.name=='rct-roster-witness-api-next04-attempt01','PRIVATE_NEW_RUN_INVALID')
fresh_cohort(g,api_ready)
fresh_preflight(g,stop)
# Existing resources first, clock LAST before the first own directory allocation.
for filesystem in ['/workspace','/tmp']:
 value=os.statvfs(filesystem);assert value.f_bavail*value.f_frsize>=g['workspace_floor']
used=int(Path('/sys/fs/cgroup/memory.current').read_text());limit=int(Path('/sys/fs/cgroup/memory.max').read_text());assert used<g['shared_stop'] and limit-used>=g['shared_reserve']
now=datetime.datetime.now(UTC);assert datetime.datetime.fromisoformat(g['not_before_utc'])<=now<stop
os.umask(0o077);run.mkdir(mode=0o700);private_directory(run)
for name in ['supervision','private-tmp','transform-cache','worker-artifacts']:(run/name).mkdir(mode=0o700)
s=guard.process_table()[os.getpid()];atomic(supervision/'supervisor.safe.json',s);print(json.dumps({'stage':'PREOBSERVER_NODE_STARTED','pid':s['pid'],'birth':s['start_ticks']}),flush=True)
env=plan['explicitEnv'].copy();env.update(TMPDIR=str(run/'private-tmp'),TMP=str(run/'private-tmp'),TEMP=str(run/'private-tmp'),PWTEST_CACHE_DIR=str(run/'transform-cache'),RCT_FOCUS3_TYPES_OUTPUT=str(supervision/'types.safe.json'),RCT_FOCUS3_RUN=str(run),RCT_FOCUS3_OBSERVATIONS=str(supervision/'observations.safe.json'),RCT_SAFE_FAILURE_CONTROL_OUTPUT=str(run/'worker-artifacts'))
results=[]
for phase in plan['commands']:
 active_phase=phase['name'];assert observe() is None
 phaseEnv=env.copy();receipt=supervision/(active_phase+'.safe.json');phaseEnv['RCT_SAFE_DIAGNOSTIC_RECEIPT']=str(receipt);phaseEnv['RCT_WITNESS_CONTROL_RECEIPT']=str(receipt)
 if active_phase=='privacy':phaseEnv['RCT_E2E_CONTROL_RECEIPT_PATH']=str(receipt)
 argv=phase['argv'];actual=argv;diagnostic=run/'private-tmp/formatter-public-source.private.log'
 if active_phase in ['format-write','format-check']:actual=['/usr/bin/bash','-c','exec '+shlex.join(argv)+' >'+shlex.quote(str(diagnostic))+' 2>&1']
 fresh_cohort(g,api_ready);fresh_preflight(g,stop)
 seconds=min(g['per_phase_seconds'],int((stop-datetime.datetime.now(UTC)).total_seconds()));assert seconds>0
 atomic(supervision/(active_phase+'-launch.safe.json'),{'phase':active_phase,'argv':argv,'deadlineSeconds':seconds,'expectedNativeExit':phase['expectedNativeExit']})
 result=guard.run_owned(actual,'/workspace/rct-worktrees/client-ci-first3/tests/e2e',phaseEnv,deadline_seconds=seconds,observe=observe,status=status)
 row=json.loads(receipt.read_text()) if receipt.exists() else {};accepted=result['phase_success']
 if active_phase=='witness':
  witness=run/'witness.safe.json'
  row=json.loads(witness.read_text()) if witness.is_file() and not witness.is_symlink() and stat.S_IMODE(witness.stat().st_mode)==0o600 else {}
  closed_status={'200','401','403','404','409','422','500','502','503','504','OTHER'}
  closed_boundary={'GATEWAY_ISSUER','ATTENDANCE_DEPENDENCY','OTHER'}
  closed_dependency={'ACADEMIC','SCHEDULE','OTHER'}
  closed_rpc={'CANCELLED','UNKNOWN','INVALID_ARGUMENT','DEADLINE_EXCEEDED','NOT_FOUND','ALREADY_EXISTS','PERMISSION_DENIED','RESOURCE_EXHAUSTED','FAILED_PRECONDITION','ABORTED','OUT_OF_RANGE','UNIMPLEMENTED','INTERNAL','UNAVAILABLE','DATA_LOSS','UNAUTHENTICATED'}
  allowed_keys={'stage','status','boundary','dependency','rpc','operationHint','problemBodyState','actorRecovery','singleRosterGet','noReseedOrDomainWrites','clientAcceptance','failedClosed','cleanup','cleanupConfirmed'}
  closed=row.get('status') in closed_status and row.get('boundary') in closed_boundary and row.get('dependency') in closed_dependency and row.get('rpc') in closed_rpc and set(row)<=allowed_keys
  closed=closed and row.get('operationHint') in {'UNKNOWN','GET_SEMESTER_STATE_SHAPE','GET_GROUP_MEMBERS_SHAPE','GET_LESSON_BY_ID_SHAPE'} and row.get('problemBodyState') in {'UNKNOWN','CLASSIFIED','EMPTY','OVERSIZE','INVALID_LENGTH','MALFORMED','UNAVAILABLE','NOT_503'}
  owners=row.get('cleanup',[])
  closed=closed and row.get('stage') in {'START','ADMIN_ADMISSION','EXISTING_ACTOR_LOOKUP','EXISTING_ACTOR_CREDENTIAL_VIEW','EXISTING_HEADMAN_ADMISSION','EXISTING_LESSON_LOOKUP','ONE_ROSTER_GET','CLASSIFIED'} and row.get('actorRecovery') in {'NOT_RUN','SOURCE_QUALIFIED_FIRST_WORKER_CHRONOLOGY'}
  closed=closed and isinstance(owners,list) and len(owners)<=2 and all(isinstance(item,dict) and set(item)=={'owner','logoutStatus','logoutConfirmed','contextDisposed'} and item.get('owner') in {'ADMIN','HEADMAN'} and item.get('logoutStatus') in {'204','401','403','409','500','502','503','504','OTHER','UNCONFIRMED','NOT_NEEDED'} and type(item.get('logoutConfirmed')) is bool and type(item.get('contextDisposed')) is bool for item in owners)
  cleanup=closed and len(owners)==2 and {item.get('owner') for item in owners}=={'ADMIN','HEADMAN'} and all(set(item)=={'owner','logoutStatus','logoutConfirmed','contextDisposed'} and item.get('logoutStatus')=='204' and item.get('logoutConfirmed') is True and item.get('contextDisposed') is True for item in owners)
  accepted=accepted and closed and cleanup and row.get('stage')=='CLASSIFIED' and row.get('actorRecovery')=='SOURCE_QUALIFIED_FIRST_WORKER_CHRONOLOGY' and row.get('singleRosterGet') is True and row.get('noReseedOrDomainWrites') is True and row.get('clientAcceptance') is False and row.get('failedClosed') is not True and row.get('cleanupConfirmed') is True
  if closed: atomic(supervision/'witness.safe.json',row)
 elif active_phase=='worker':
  accepted=accepted and row.get('pass') is True and row.get('childNativeExit')==0 and row.get('caseCount')==3 and all(row.get(k) is True for k in ['failedTestsRetained','markerAbsent','earlyWorkerCauseTransported','lateFixtureCauseTransported','unknownFallbackTransported','bodiesNotStarted'])
  accepted=accepted and len(row.get('retainedRows',[]))==3 and {item.get('caseCode') for item in row.get('retainedRows',[])}=={'EARLY_WORKER','LATE_FIXTURE','UNKNOWN_SETUP'} and row.get('omittedRowCount')==0
 elif active_phase=='privacy':accepted=accepted and row.get('state')=='PRIVACY_BOUNDARIES_PASSED' and all(row.get(k) is True for k in ['markerAbsent','expectedFailureRetained','interruptionPassed','missingGuardRejectedBeforeOperation'])
 elif active_phase=='types':accepted=accepted and row.get('pass') is True and row.get('error_count')==0
 elif active_phase in ['format-write','format-check']:
  text=diagnostic.read_text() if diagnostic.exists() else '';row={'publicDiagnosticBytes':len(text.encode()),'styleDifference':'Code style issues found' in text,'parserError':'[error]' in text};diagnostic.unlink(missing_ok=True)
  if active_phase=='format-write':row['afterSourceHashes']={name:hashlib.sha256(Path(name).read_bytes()).hexdigest() for name in plan['mutableOnlyAfterExplicitFormatGrant']}
 facts={'phase':active_phase,'nativeExit':result['native_exit'],'accepted':accepted,'expectedNativeExit':phase['expectedNativeExit']};atomic(supervision/(active_phase+'-outcome.safe.json'),facts)
 result.update(phase=active_phase,accepted=accepted,peaks=peaks.copy());atomic(supervision/(active_phase+'-terminal.safe.json'),result);results.append(result);print(json.dumps(facts),flush=True)
 if active_phase=='format-write':atomic(supervision/'formatted-source.safe.json',row)
 if not accepted:break
settled=all(value['settled'] and value['all_owned_processes_reaped'] for value in results)
if settled:
 for name in ['private-tmp','transform-cache','worker-artifacts']:
  path=run/name;assert not path.is_symlink() and path.stat().st_uid==os.geteuid() and stat.S_IMODE(path.stat().st_mode)==0o700;shutil.rmtree(path)
passed=len(results)==len(plan['commands']) and all(value['accepted'] for value in results)
atomic(supervision/'OUTCOME.safe.json',{'pass':passed,'settled':settled,'completedPhases':len(results),'peaks':peaks,'ownedTempArtifactsRemoved':settled,'nativeClientAcceptance':False,'actualCIcause':'UNKNOWN','sampledSoftMonitoring':True})
print(json.dumps({'stage':'PREOBSERVER_NODE_TERMINAL','pass':passed,'settled':settled}),flush=True)
raise SystemExit(0 if passed and settled else 1)
