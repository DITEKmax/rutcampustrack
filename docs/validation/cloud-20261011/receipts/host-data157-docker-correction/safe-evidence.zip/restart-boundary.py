"""Exact new restart grant and metadata gates; no secret or DB contents read."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import re
import stat
PLAN = Path('/workspace/scratch/rct-validation/current_host_restart_plan')
CORRECTION = Path(__file__).parent
BASE = Path('/workspace/scratch/rct-validation/current_host_config_v5')
DB = Path('/tmp/rct-native-mongo-20261012/fresh-db')
KEY = Path('/tmp/rct-native-mongo-20261012/runtime/replica-key')

def verify_execution_actor():
    if os.getuid()!=1000 or os.getgid()!=1000:
        raise RuntimeError('Exact approved execution actor1000 required')

def regular(path):
    path = Path(path)
    if not path.is_absolute() or '..' in path.parts:
        raise RuntimeError('Absolute lexical path required')
    for parent in reversed(path.parents):
        if not stat.S_ISDIR(parent.lstat().st_mode):
            raise RuntimeError('Symlink ancestor denied')
    if not stat.S_ISREG(path.lstat().st_mode):
        raise RuntimeError('Regular exact input required')
    return path

def sha(path):
    return hashlib.sha256(regular(path).read_bytes()).hexdigest()

def validate_restart_fields(grant, now):
    if (grant.get('durable_restart_authorized') is not True
            or grant.get('launch_authorized') is not True
            or grant.get('native_mongo_authorized') is not True
            or grant.get('reuse_existing_mongo_db') != str(DB)
            or grant.get('reuse_existing_mongo_key') != str(KEY)
            or grant.get('repeat_bootstrap_authorized') is not False
            or grant.get('data_reset_authorized') is not False
            or not re.fullmatch(r'restart-[a-z0-9-]{1,48}', str(grant.get('cohort_name', '')))):
        raise RuntimeError('New exact durable restart grant required')
    seconds = grant.get('deadline_seconds')
    if type(seconds) is not int or not 1 <= seconds <= 1800:
        raise RuntimeError('Bounded deadline required')
    started = datetime.datetime.fromisoformat(grant['not_before_utc'])
    stop = datetime.datetime.fromisoformat(grant['stop_utc'])
    if (started.utcoffset() != datetime.timedelta(0) or stop.utcoffset() != datetime.timedelta(0)
            or not started <= now < stop or not 0 < (stop-started).total_seconds() <= 1800):
        raise RuntimeError('Fresh finite UTC grant required')
    return min(seconds, (stop-now).total_seconds())

def verify_restart(grant, source):
    verify_execution_actor()
    if grant.get('execution_actor_uid')!=1000 or grant.get('execution_actor_gid')!=1000:
        raise RuntimeError('NEW exact approved actor grant required')
    remaining = validate_restart_fields(grant, datetime.datetime.now(datetime.timezone.utc))
    load_existing_data_fence(grant)
    manifest_path = PLAN / 'manifest.json'
    if sha(manifest_path) != grant.get('restart_manifest_sha256'):
        raise RuntimeError('New exact restart seal required')
    manifest = json.loads(manifest_path.read_text())
    correction_path = CORRECTION / 'manifest.json'
    if sha(correction_path) != grant.get('restart_ancestor_correction_manifest_sha256'):
        raise RuntimeError('New exact ancestor correction seal required')
    correction = json.loads(correction_path.read_text())
    source = regular(Path(source).absolute())
    if not any(row['path'] == str(source) and sha(source) == row['sha256'] for row in correction['files']):
        raise RuntimeError('Actual corrected restart source must be sealed')
    for row in correction['files']:
        if sha(row['path']) != row['sha256']:
            raise RuntimeError('Ancestor correction input changed')
    for row in manifest['files']:
        if sha(row['path']) != row['sha256']:
            raise RuntimeError('Restart input changed')
    prior_source_seal = Path('/workspace/scratch/rct-validation/current_host_restart_ancestor_correction_v2/manifest.json')
    if sha(prior_source_seal) != '9ce528ac02bf076952f99fdcf2df2580518833c18abf57ab0672a1822cea1c4d':
        raise RuntimeError('Original immutable context source seal changed')
    for row in json.loads(prior_source_seal.read_text())['files']:
        if sha(row['path']) != row['sha256']:
            raise RuntimeError('Original immutable context input changed')
    review = regular(grant['restart_review_manifest'])
    if sha(review) != grant['restart_review_manifest_sha256']:
        raise RuntimeError('Fresh independent restart review required')
    for row in json.loads((PLAN / 'prior-seals.safe.json').read_text())['seals']:
        if sha(row['path']) != row['sha256']:
            raise RuntimeError('Prior exact config/artifact/guard seal changed')
    return PLAN / 'runtime' / grant['cohort_name'], remaining

DATA_FENCE = CORRECTION / 'stopped-native-data-fence157.safe.json'
DATA_FENCE_SHA = 'd368d1d211b71f0d364f86bb71ac5f79bfe0170a7f155e893fbd257d9e16e11f'
PRIOR_CONTEXT_MANIFEST = Path('/workspace/scratch/rct-validation/current_host_restart_context_correction/manifest.json')
PRIOR_CONTEXT_SHA = '7c03e6cb7cb1c200c7e788e8b7c28b0d6cabb8b5b8bfc29d37f906739ad68236'

def load_existing_data_fence(grant):
    verify_execution_actor()
    if (grant.get('stopped_mongo_data_fence_path') != str(DATA_FENCE)
            or grant.get('stopped_mongo_data_fence_sha256') != DATA_FENCE_SHA):
        raise RuntimeError('NEW exact stopped157 metadata grant binding required')
    if sha(DATA_FENCE) != DATA_FENCE_SHA:
        raise RuntimeError('Exact canonical157 stopped metadata changed')
    if sha(PRIOR_CONTEXT_MANIFEST) != PRIOR_CONTEXT_SHA:
        raise RuntimeError('Original approved context source changed')
    for row in json.loads(PRIOR_CONTEXT_MANIFEST.read_text())['files']:
        if sha(row['path']) != row['sha256']:
            raise RuntimeError('Original immutable context member changed')
    fence = json.loads(DATA_FENCE.read_text())
    nodes = fence['stopped_db_metadata_nodes']
    if len(nodes) != 157 or len({row['path'] for row in nodes}) != 157:
        raise RuntimeError('Exact157 unique metadata nodes required')
    return fence

def metadata(path):
    path = Path(path)
    for parent in reversed(path.parents):
        if not stat.S_ISDIR(parent.lstat().st_mode):
            raise RuntimeError('Data symlink ancestor denied')
    s = path.lstat()
    kind = 'directory' if stat.S_ISDIR(s.st_mode) else 'regular' if stat.S_ISREG(s.st_mode) else 'denied'
    if kind == 'denied' or s.st_uid != os.getuid() or (kind == 'regular' and s.st_nlink != 1):
        raise RuntimeError('Own unaliased data identity required')
    return dict(path=str(path),device=s.st_dev,inode=s.st_ino,uid=s.st_uid,gid=s.st_gid,
                mode=stat.S_IMODE(s.st_mode),bytes=s.st_size,nlink=s.st_nlink,
                mtime_ns=s.st_mtime_ns,ctime_ns=s.st_ctime_ns,kind=kind)

def matching(expected, actual):
    return all(actual.get(key) == value for key, value in expected.items())

def verify_existing_data(fence, stopped):
    if not matching(fence['root_directory'], metadata('/tmp/rct-native-mongo-20261012')):
        raise RuntimeError('Native root identity changed')
    if not matching(fence['runtime_directory_identity'], metadata(KEY.parent)):
        raise RuntimeError('Native runtime identity changed')
    if not matching(fence['exact_key_metadata'], metadata(KEY)):
        raise RuntimeError('Existing key metadata changed')
    if stopped:
        current = [metadata(DB)]
        def fail(error):
            raise error
        for parent, dirs, files in os.walk(DB, followlinks=False, onerror=fail):
            current.extend(metadata(Path(parent)/name) for name in sorted(dirs+files))
        expected = {row['path']:row for row in fence['stopped_db_metadata_nodes']}
        if len(current) != len(expected) or {row['path']:row for row in current} != expected:
            raise RuntimeError('Stopped DB metadata fence changed')
    else:
        expected = fence['stopped_db_metadata_nodes'][0]
        identity = {key:expected[key] for key in ['path','device','inode','uid','gid','mode','kind']}
        if not matching(identity, metadata(DB)):
            raise RuntimeError('Live existing DB directory identity changed')


def dir_identity(metadata, uid):
    if not stat.S_ISDIR(metadata.st_mode) or metadata.st_uid != uid:
        raise RuntimeError('Exact owned non-symlink directory required')
    if metadata.st_mode & 0o022:
        raise RuntimeError('Group/other writable runtime ancestor denied')
    return dict(device=metadata.st_dev, inode=metadata.st_ino, uid=metadata.st_uid,
                gid=metadata.st_gid, mode=stat.S_IMODE(metadata.st_mode))

class CohortDirectory:
    """Pinned exact runtime ancestors, relative creation and receipt writes only."""
    def __init__(self, path, create=False):
        verify_execution_actor()
        self.path = Path(path)
        self.fds = []
        self.identities = []
        if (self.path.parent != PLAN / 'runtime'
                or not re.fullmatch(r'restart-[a-z0-9-]{1,48}', self.path.name)):
            raise RuntimeError('Exact unique runtime cohort path required')
        anchors = json.loads((CORRECTION / 'runtime-ancestor-anchors.safe.json').read_text())['anchors']
        paths = list(reversed(PLAN.parents)) + [PLAN]
        if [row['path'] for row in anchors] != [str(p) for p in paths]:
            raise RuntimeError('Exact complete runtime ancestor anchors required')
        flags = os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW | os.O_CLOEXEC
        try:
            for p, expected in zip(paths, anchors):
                before = dir_identity(p.lstat(), expected['uid'])
                if before != {key:value for key,value in expected.items() if key != 'path'}:
                    raise RuntimeError('Runtime ancestor identity changed')
                if self.fds:
                    fd = os.open(p.name, flags, dir_fd=self.fds[-1])
                else:
                    fd = os.open(str(p), flags)
                self.fds.append(fd)
                if dir_identity(os.fstat(fd), expected['uid']) != before:
                    raise RuntimeError('Runtime ancestor switched during open')
                self.identities.append((p, before))
            for p, must_create in [(PLAN / 'runtime', False), (self.path, create)]:
                self.assert_current()
                if must_create:
                    # Atomic unique mkdir; preexisting regular/dir/link is denied by EEXIST.
                    os.mkdir(p.name, 0o700, dir_fd=self.fds[-1])
                else:
                    try:
                        current = os.stat(p.name, dir_fd=self.fds[-1], follow_symlinks=False)
                    except FileNotFoundError:
                        if not create or p != PLAN / 'runtime':
                            raise RuntimeError('Existing exact runtime directory required')
                        os.mkdir(p.name, 0o700, dir_fd=self.fds[-1])
                        current = os.stat(p.name, dir_fd=self.fds[-1], follow_symlinks=False)
                    dir_identity(current, os.getuid())
                current = os.stat(p.name, dir_fd=self.fds[-1], follow_symlinks=False)
                expected = dir_identity(current, os.getuid())
                if expected['mode'] != 0o700:
                    raise RuntimeError('Own runtime/cohort700 required')
                fd = os.open(p.name, flags, dir_fd=self.fds[-1])
                self.fds.append(fd)
                if dir_identity(os.fstat(fd), os.getuid()) != expected:
                    raise RuntimeError('Runtime directory switched during open')
                self.identities.append((p, expected))
                self.assert_current()
        except BaseException:
            self.close()
            raise

    def assert_current(self):
        if len(self.identities) != len(self.fds):
            raise RuntimeError('Ambiguous runtime descriptor identities')
        for (path, expected), fd in zip(self.identities, self.fds):
            if (dir_identity(path.lstat(), expected['uid']) != expected
                    or dir_identity(os.fstat(fd), expected['uid']) != expected):
                raise RuntimeError('Pinned runtime ancestor replaced')

    def write_json(self, name, value):
        self.assert_current()
        if not re.fullmatch(r'[A-Za-z0-9_-]+(?:\.[A-Za-z0-9_-]+)*\.json', name):
            raise RuntimeError('Safe exact receipt basename required')
        fd = os.open(name, os.O_WRONLY | os.O_CREAT | os.O_NOFOLLOW | os.O_CLOEXEC,
                     0o600, dir_fd=self.fds[-1])
        try:
            info = os.fstat(fd)
            if (not stat.S_ISREG(info.st_mode) or info.st_uid != os.getuid()
                    or stat.S_IMODE(info.st_mode) != 0o600 or info.st_nlink != 1):
                raise RuntimeError('Own unaliased regular600 receipt required')
            self.assert_current()
            os.ftruncate(fd, 0)
            with os.fdopen(fd, 'w') as stream:
                fd = None
                stream.write(json.dumps(value, indent=2) + '\n')
        finally:
            if fd is not None:
                os.close(fd)

    def close(self):
        for fd in reversed(self.fds):
            os.close(fd)
        self.fds.clear()
        self.identities.clear()
