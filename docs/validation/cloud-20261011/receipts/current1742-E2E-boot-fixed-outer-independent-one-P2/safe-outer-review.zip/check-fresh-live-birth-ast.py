import ast,datetime,hashlib,json,os,stat,sys,types
from pathlib import Path
OWN=Path(__file__).parent
AUTHOR=Path('/workspace/scratch/rct-validation/current1742_e2e_boot_outer_caller_source')
SOURCE=AUTHOR/'read-existing-boot.py'
# Reuse author's public RAM adapters, select only the entry-scenario function;
# replace module loading with Source AST definitions to avoid author pycache.
adapter=(AUTHOR/'check-caller-ram.py').read_text()
adapter=adapter.replace("proc_active[0]=False\n            failed=", "proc_active[0] = case == 'LIVE_KNOWN_BIRTH_AFTER_RETURN'\n            failed=",1)
adapter=adapter.replace("elif case=='EXPIRE_BEFORE_PRIVATE_READ':assert native==1", "elif case=='LIVE_KNOWN_BIRTH_AFTER_RETURN':assert native==1 and counts['private_reads']==0 and counts['unlink']==1 and not leaf[0]\n    elif case=='EXPIRE_BEFORE_PRIVATE_READ':assert native==1",1)
tree=ast.parse(adapter)
def source_module(path,name):
    env={'Path':Path,'dt':datetime,'datetime':datetime,'hashlib':hashlib,'json':json,'os':os,'stat':stat,'sys':sys,'__file__':str(path)}
    public_nodes=[n for n in ast.parse(path.read_bytes()).body if isinstance(n,(ast.FunctionDef,ast.ClassDef,ast.Assign))]
    # parser uses datetime as dt and re; capture has resource only in unused main.
    import re
    env['re']=re
    result=types.ModuleType(name)
    result.__dict__.update(env)
    exec(compile(ast.Module(body=public_nodes,type_ignores=[]),str(path),'exec'),result.__dict__)
    return result
env={'ast':ast,'Path':Path,'datetime':datetime,'hashlib':hashlib,'json':json,'os':os,'stat':stat,'types':types,'OWN':AUTHOR,'SOURCE':SOURCE,'raw':SOURCE.read_bytes(),'nodes':[n for n in ast.parse(SOURCE.read_bytes()).body if isinstance(n,(ast.FunctionDef,ast.ClassDef,ast.Assign))],'load':source_module,'checks':[]}
run=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='run')
exec(compile(ast.Module(body=[run],type_ignores=[]),'PUBLIC_RAM_ADAPTER_ONLY','exec'),env)
env['run']('LIVE_KNOWN_BIRTH_AFTER_RETURN')
row=env['checks'][0]
assert row['counts']['capture']==1 and row['counts']['private_reads']==0 and row['counts']['unlink']==1
r={'schema':'RCT_BOOT_OUTER_FRESH_LIVE_BIRTH_SELECTED_AST_V1','caller_sha256':hashlib.sha256(SOURCE.read_bytes()).hexdigest(),'actual_caller_AST_unchanged':True,'case':'LIVE_KNOWN_BIRTH_AFTER_RETURN','caller_fails_closed_parse':True,'known_birth_freshly_still_present':True,'cleanup_unlink_count':row['counts']['unlink'],'private_read_count':0,'actual_log_FS_API_native_child_effects':False,'counterexample':'Fresh absence rejection blocks parser but capture-stage exception cleanup unlinks despite same known child birth still present'}
(OWN/'fresh-live-birth-counterexample.safe.json').write_text(json.dumps(r,indent=2)+'\n')
print(json.dumps(r))
env['run']('SUCCESS')
env['run']('FAILED_CAPTURE')
env['run']('PRIMARY_AND_CLEANUP_FAIL')
extra={'schema':'RCT_BOOT_OUTER_SELECTED_FLOW_POSITIVES_V1','caller_sha256':r['caller_sha256'],'cases':[{'code':x['case'],'simulated_caller_exit':x['native'],'counts':x['counts'],'private_canaries_absent':x['privacy_canaries_absent'],'actual_log_FS_API_native_effects':False} for x in env['checks'][1:]],'unchanged_parser_suite_NOT_RERUN':True}
(OWN/'selected-flow-positives.safe.json').write_text(json.dumps(extra,indent=2)+'\n')
