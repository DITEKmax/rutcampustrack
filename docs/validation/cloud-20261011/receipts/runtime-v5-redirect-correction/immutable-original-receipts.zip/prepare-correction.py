"""Only the two redirect query suffixes and an exact Compose bind overlay."""
import hashlib
import json
from pathlib import Path

OWN = Path(__file__).parent
BASE = OWN.parent / 'current_host_config_v5'
BASE_SHA = 'e3b6e2c80d819e758bd54722a0d348764dcee5ce64a1ede0cd20df16adc96378'

def main():
    assert hashlib.sha256((BASE / 'launch-manifest.json').read_bytes()).hexdigest() == BASE_SHA
    old = (BASE / 'edge-default.conf').read_text()
    new = old
    for name in ['app', 'mini-app']:
        before = 'location = /' + name + ' { return 301 /' + name + '/; }'
        after = 'location = /' + name + ' { return 301 /' + name + '/$is_args$args; }'
        assert old.count(before) == 1
        new = new.replace(before, after)
    target = OWN / 'edge-default.conf'
    target.write_text(new)
    target.chmod(0o644)
    overlay = '''services:
  nginx:
    volumes:
    - type: bind
      source: ''' + str(target) + '''
      target: /etc/nginx/conf.d/default.conf
      read_only: true
      bind:
        create_host_path: false
'''
    (OWN / 'edge-overlay.compose.yml').write_text(overlay)
    (OWN / 'edge-overlay.compose.yml').chmod(0o644)
    print(json.dumps({'redirect_suffix_changes': 2, 'private_reads': 0, 'applications_started': 0}))

if __name__ == '__main__':
    main()
