"""Focused RAM controls for this fixed caller; no Docker, key, or test runtime."""

import ast
import hashlib
import json
from pathlib import Path
import re
from types import SimpleNamespace

SOURCE = Path(__file__).with_name("prove-key-volume.py")
tree = ast.parse(SOURCE.read_text())
functions = {node.name: node for node in ast.walk(tree) if isinstance(node, ast.FunctionDef)}
events = []
free = {"/workspace": 8 * 1024**3, "/tmp": 8 * 1024**3}
cgroup = {"/sys/fs/cgroup/memory.current": str(5 * 1024**3), "/sys/fs/cgroup/memory.max": str(16 * 1024**3)}
now = [100.0]
responses = []
observed = []


def statvfs(path):
    events.append(path)
    value = free[path]
    if isinstance(value, BaseException):
        raise value
    return SimpleNamespace(f_bavail=value, f_frsize=1)


class CgroupPath:
    def __init__(self, path):
        self.path = path

    def read_text(self):
        events.append(self.path)
        value = cgroup[self.path]
        if isinstance(value, BaseException):
            raise value
        return value


def clock():
    events.append("UTC_LAST")
    return now[0]


def native(argv, **kwargs):
    events.append("EFFECT")
    observed.append((argv, kwargs))
    return responses.pop(0)


namespace = {"os": SimpleNamespace(statvfs=statvfs), "Path": CgroupPath,
             "time": SimpleNamespace(time=clock), "subprocess": SimpleNamespace(run=native),
             "re": re, "DOCKER": ["docker", "--host=unix:///var/run/docker.sock"], "ENV": {},
             "initial_free": free.copy(), "deadline": 280.0,
             "IMAGE": "sha256:" + "a" * 64, "LABEL": "io.rutcampustrack.p07-isolation=20261013-01",
             "created_containers": {}}
for name in ("free_bytes", "resource_gate", "run", "container_id", "inspect_container", "container"):
    exec(compile(ast.Module(body=[functions[name]], type_ignores=[]), str(SOURCE), "exec"), namespace)

cases = []


def check(name, action, expected_error=None):
    events.clear()
    observed.clear()
    responses.clear()
    if expected_error:
        try:
            action()
        except expected_error:
            assert "EFFECT" not in events
        else:
            raise AssertionError(name)
    else:
        action()
    cases.append({"case": name, "status": "PASS"})


gate = lambda cleanup=False: namespace["resource_gate"](namespace["initial_free"], 280.0, cleanup)
check("both_disks_cgroup_then_utc_last", lambda: (gate(), events[-1] == "UTC_LAST"))
assert events == ["/workspace", "/tmp", "/sys/fs/cgroup/memory.current", "/sys/fs/cgroup/memory.max", "UTC_LAST"]
for path in free:
    original = free[path]
    free[path] = 4 * 1024**3 - 1
    check(path + "_floor_blocks", gate, RuntimeError)
    free[path] = original - 32 * 1024**2 - 1
    check(path + "_growth_blocks", gate, RuntimeError)
    free[path] = OSError()
    check(path + "_probe_failure_blocks", gate, OSError)
    free[path] = original

cgroup["/sys/fs/cgroup/memory.current"] = str(15 * 1024**3)
check("shared_exact_15GiB_with_1GiB_reserve", gate)
cgroup["/sys/fs/cgroup/memory.current"] = str(15 * 1024**3 + 1)
check("shared_over_15GiB_blocks", gate, RuntimeError)
cgroup["/sys/fs/cgroup/memory.current"] = str(5 * 1024**3)
cgroup["/sys/fs/cgroup/memory.max"] = str(6 * 1024**3 - 1)
check("shared_under_1GiB_reserve_blocks", gate, RuntimeError)
cgroup["/sys/fs/cgroup/memory.max"] = "max"
check("nonfinite_cgroup_limit_blocks", gate, ValueError)
cgroup["/sys/fs/cgroup/memory.max"] = str(16 * 1024**3)
cgroup["/sys/fs/cgroup/memory.current"] = OSError()
check("cgroup_probe_failure_blocks", gate, OSError)
cgroup["/sys/fs/cgroup/memory.current"] = str(5 * 1024**3)
now[0] = 250.0
check("cleanup_reserve_blocks_new_effect", gate, RuntimeError)
check("cleanup_can_use_reserved_30s", lambda: gate(True))
now[0] = 280.0
check("expiry_blocks_cleanup", lambda: gate(True), RuntimeError)
now[0] = 100.0


def absent():
    responses.append(SimpleNamespace(returncode=0, stdout=b""))
    assert namespace["container_id"]("own-new") == ""
    argv, kwargs = observed[-1]
    assert argv[-2:] == ["--format", "{{.ID}}"]
    assert events[-2:] == ["UTC_LAST", "EFFECT"]
    assert kwargs["timeout"] == 30


check("absence_requires_successful_ID_only_listing", absent)
responses.append(SimpleNamespace(returncode=1, stdout=b""))
try:
    namespace["container_id"]("own-new")
except RuntimeError:
    cases.append({"case": "daemon_exit1_never_becomes_absence", "status": "PASS"})
else:
    raise AssertionError("daemon exit1 treated absent")


def identity_drift():
    responses.append(SimpleNamespace(returncode=0, stdout=("b" * 64).encode()))
    try:
        namespace["inspect_container"]("own-new", "a" * 64)
    except RuntimeError:
        assert len(observed) == 1 and "rm" not in observed[0][0]
    else:
        raise AssertionError("changed ID accepted")


check("cleanup_changed_ID_blocks_before_removal", identity_drift)


def label_drift():
    identity = "a" * 64
    responses.extend([SimpleNamespace(returncode=0, stdout=identity.encode()),
                      SimpleNamespace(returncode=0, stdout=(identity + " " + namespace["IMAGE"] + " foreign").encode())])
    try:
        namespace["inspect_container"]("own-new", identity)
    except RuntimeError:
        assert len(observed) == 2 and all("rm" not in argv for argv, _ in observed)
        assert observed[-1][0][-2] == '{{.Id}} {{.Config.Image}} {{index .Config.Labels "io.rutcampustrack.p07-isolation"}}'
    else:
        raise AssertionError("foreign label accepted")


check("cleanup_foreign_label_blocks_before_removal", label_drift)

# Every inspect call is explicitly formatted; neither old full-inspect probe remains.
assert '["container", "inspect", name]' not in SOURCE.read_text()
assert '["volume", "inspect", VOLUME]' not in SOURCE.read_text()
for node in ast.walk(tree):
    if isinstance(node, ast.List):
        literals = [child.value for child in node.elts if isinstance(child, ast.Constant)]
        if "inspect" in literals:
            assert "--format" in literals
cases.append({"case": "all_inspect_argv_use_public_formats", "status": "PASS"})

receipt = {"state": "RAM_SOURCE_CONTROLS_PASS_NATIVE_NOT_RUN", "source_sha256": hashlib.sha256(SOURCE.read_bytes()).hexdigest(), "cases": cases}
Path(__file__).with_name("caller-r1-controls.safe.json").write_text(json.dumps(receipt, indent=2) + "\n")
print(json.dumps({"state": receipt["state"], "controls": len(cases)}))
