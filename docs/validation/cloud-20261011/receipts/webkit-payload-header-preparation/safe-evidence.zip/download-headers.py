"""Exact11 public downloads and tar headers only, blocked without NEW Root grant."""
import argparse
import datetime
import hashlib
import json
import os
from pathlib import Path
import re
import stat
import types
import urllib.parse

OWN = Path(__file__).parent
PLAN = OWN.parent / 'browser_webkit_signed_plan'
REVIEW = OWN.parent / 'webkit_dependency_independent_review/manifest.json'
PLAN_SHA = '82a2775335737cbf8fe0bd40e612f2302f2cd5e73ea2663be3e489aa2a8cb3ac'
REVIEW_SHA = '4ee15dc1ccc77f77b451810d1aef8523c0418616a17004bd53ceb6ad4a801fa5'
GUARD = OWN.parent / 'guard_proc_race_correction/bounded-child.py'
GUARD_SHA = 'b78c61293568d9941692e0b92ee34fd0b84db6d532b4a2c9a5ad42ccbf2204a0'
PAYLOAD_CAP = 16777216
RSS_CAP = 201326592

def sha(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as stream:
        for chunk in iter(lambda:stream.read(1048576),b''):h.update(chunk)
    return h.hexdigest()

def regular(path, mode=None):
    raw=str(path);path=Path(raw)
    if not path.is_absolute() or '..' in path.parts or str(path)!=raw:
        raise RuntimeError('Canonical absolute path required')
    for parent in reversed(path.parents):
        if not stat.S_ISDIR(parent.lstat().st_mode):raise RuntimeError('Symlink ancestor denied')
    s=path.lstat()
    if not stat.S_ISREG(s.st_mode) or (mode is not None and stat.S_IMODE(s.st_mode)!=mode):
        raise RuntimeError('Exact regular file required')
    return path

def validate_grant(grant, now):
    if (grant.get('payload_download_headers_authorized') is not True
            or grant.get('library_extraction_authorized') is not False
            or grant.get('browser_launch_authorized') is not False
            or grant.get('signed_plan_manifest_sha256')!=PLAN_SHA
            or grant.get('source_review_manifest_sha256')!=REVIEW_SHA
            or grant.get('reviewed_guard_sha256')!=GUARD_SHA
            or grant.get('exact_archive_bytes')!=6284816
            or grant.get('payload_namespace_allocated_cap')!=PAYLOAD_CAP
            or grant.get('driver_rss_stop_bytes')!=RSS_CAP):
        raise RuntimeError('NEW exact headers-only Root grant required')
    namespace=grant.get('payload_namespace','')
    if not re.fullmatch(r'/tmp/rct-webkit-payloads-20261012-[a-z0-9-]{1,24}',namespace):
        raise RuntimeError('Unique exact own tmp namespace required')
    start=datetime.datetime.fromisoformat(grant['not_before_utc'])
    stop=datetime.datetime.fromisoformat(grant['stop_utc'])
    if start.utcoffset()!=datetime.timedelta(0) or stop.utcoffset()!=datetime.timedelta(0) or not start<=now<stop or not 0<(stop-start).total_seconds()<=600:
        raise RuntimeError('Fresh600-second UTC window required')
    return Path(namespace),stop

class Namespace:
    def __init__(self,path):
        self.path=path
        self.fds=[];self.identities=[]
        anchors=json.loads((OWN/'namespace-anchors.safe.json').read_text())['anchors']
        try:
            for expected in anchors:
                p=Path(expected['path']);s=p.lstat()
                identity=self.identity(s)
                if identity!=expected['identity']:raise RuntimeError('Tmp ancestor changed')
                fd=os.open(str(p) if not self.fds else p.name,os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW|os.O_CLOEXEC,dir_fd=None if not self.fds else self.fds[-1])
                self.fds.append(fd)
                if self.identity(os.fstat(fd))!=identity:raise RuntimeError('Tmp ancestor switched')
                self.identities.append((p,identity))
            self.check()
            os.mkdir(path.name,0o700,dir_fd=self.fds[-1])
            fd=os.open(path.name,os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW|os.O_CLOEXEC,dir_fd=self.fds[-1])
            self.fds.append(fd);identity=self.identity(os.fstat(fd))
            if identity['uid']!=os.getuid() or identity['mode']!=0o700:raise RuntimeError('Own namespace700 required')
            self.identities.append((path,identity));self.check()
        except BaseException:
            self.close();raise
    @staticmethod
    def identity(s):
        if not stat.S_ISDIR(s.st_mode):raise RuntimeError('Non-symlink directory required')
        return {'device':s.st_dev,'inode':s.st_ino,'uid':s.st_uid,'gid':s.st_gid,'mode':stat.S_IMODE(s.st_mode)}
    def check(self):
        if len(self.fds)!=len(self.identities):raise RuntimeError('Ambiguous namespace identities')
        for fd,(p,expected) in zip(self.fds,self.identities):
            if self.identity(p.lstat())!=expected or self.identity(os.fstat(fd))!=expected:raise RuntimeError('Pinned namespace changed')
    def create(self,name):
        self.check()
        if not re.fullmatch(r'[A-Za-z0-9_.+-]{1,180}',name) or name in {'.','..'}:raise RuntimeError('Safe own basename required')
        fd=os.open(name,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW|os.O_CLOEXEC,0o600,dir_fd=self.fds[-1]);os.close(fd)
        return self.path/name
    def save(self,name,value):
        self.check()
        if not re.fullmatch(r'[A-Za-z0-9_.+-]{1,180}',name):raise RuntimeError('Safe receipt basename required')
        fd=os.open(name,os.O_WRONLY|os.O_CREAT|os.O_NOFOLLOW|os.O_CLOEXEC,0o600,dir_fd=self.fds[-1])
        try:
            s=os.fstat(fd)
            if not stat.S_ISREG(s.st_mode) or s.st_uid!=os.getuid() or s.st_nlink!=1 or stat.S_IMODE(s.st_mode)!=0o600:raise RuntimeError('Own unaliased receipt600 required')
            self.check();os.ftruncate(fd,0)
            with os.fdopen(fd,'w') as stream:
                fd=None;stream.write(json.dumps(value,indent=2)+'\n')
        finally:
            if fd is not None:os.close(fd)
    def allocated(self):
        self.check();total=0
        for p in self.path.iterdir():
            s=p.lstat()
            if not stat.S_ISREG(s.st_mode) or s.st_uid!=os.getuid() or s.st_nlink!=1:raise RuntimeError('Only own regular namespace files required')
            total+=s.st_blocks*512
        return total
    def close(self):
        for fd in reversed(self.fds):os.close(fd)
        self.fds.clear();self.identities.clear()

def resources():
    result={}
    for base in ['/workspace','/tmp']:
        fs=os.statvfs(base);result[base+'_available']=fs.f_bavail*fs.f_frsize
    result['shared_memory']=int(Path('/sys/fs/cgroup/memory.current').read_text())
    result['shared_limit']=int(Path('/sys/fs/cgroup/memory.max').read_text())
    lines=Path('/proc/self/status').read_text().splitlines()
    result['driver_rss']=next((int(line.split()[1])*1024 for line in lines if line.startswith('VmRSS:')),0)
    return result

def resource_stop(value):
    if any(value[base+'_available']<4294967296 for base in ['/workspace','/tmp']):return 'DISK_FLOOR'
    if value['shared_memory']>=16106127360 or value['shared_limit']-value['shared_memory']<1073741824:return 'SHARED_MEMORY_STOP'
    if value['driver_rss']>RSS_CAP:return 'OWN_RSS_STOP'
    return None

def network_env(grant):
    env={'PATH':'/usr/bin:/bin','LANG':'C','LC_ALL':'C'}
    proxy=grant.get('public_session_proxy_url')
    if proxy is not None:
        parsed=urllib.parse.urlsplit(proxy)
        if parsed.scheme not in {'http','https'} or not parsed.hostname or parsed.username is not None or parsed.password is not None or parsed.query or parsed.fragment or parsed.path not in {'','/'}:
            raise RuntimeError('Only declared noncredential normal session proxy route allowed')
        env.update({'https_proxy':proxy,'http_proxy':proxy})
    return env

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--grant',required=True);args=parser.parse_args()
    grant_path=regular(args.grant,0o600)
    if OWN/'private' not in grant_path.parents or grant_path.stat().st_uid!=os.getuid() or grant_path.stat().st_size>65536:raise RuntimeError('Exact own Root grant600 required')
    grant=json.loads(grant_path.read_text())
    namespace_path,stop=validate_grant(grant,datetime.datetime.now(datetime.timezone.utc))
    if sha(OWN/'manifest.json')!=grant.get('driver_manifest_sha256'):raise RuntimeError('Exact sealed payload driver required')
    manifest=json.loads((OWN/'manifest.json').read_text())
    if not any(row['path']==str(Path(__file__).absolute()) and row['sha256']==sha(__file__) for row in manifest['files']):raise RuntimeError('Actual driver source must be sealed')
    for row in manifest['files']:
        if sha(regular(row['path']))!=row['sha256']:raise RuntimeError('Driver helper/source input changed')
    for path,expected in [(PLAN/'manifest.json',PLAN_SHA),(REVIEW,REVIEW_SHA),(GUARD,GUARD_SHA)]:
        if sha(regular(path))!=expected:raise RuntimeError('Accepted plan/review/guard changed')
    for row in json.loads((PLAN/'manifest.json').read_text())['files']:
        if sha(regular(row['path']))!=row['sha256']:raise RuntimeError('Signed source input changed')
    before=resources()
    if resource_stop(before) or before['/tmp_available'] < 4294967296 + PAYLOAD_CAP:
        raise RuntimeError('Fresh resource floor plus namespace allocation budget required')
    tools=json.loads((OWN/'public-tool-identity.safe.json').read_text())
    if sha(regular('/usr/bin/curl'))!=tools['curl_sha256']:
        raise RuntimeError('Exact ordinary public curl tool required')
    headers=types.ModuleType('public_headers');headers.__file__=str(OWN/'public-headers.py')
    exec(compile((OWN/'public-headers.py').read_bytes(),headers.__file__,'exec'),headers.__dict__)
    guard=types.ModuleType('reviewed_guard');guard.__file__=str(GUARD)
    exec(compile(GUARD.read_bytes(),str(GUARD),'exec'),guard.__dict__)
    rows=json.loads((OWN/'approved-packages.safe.json').read_text())['packages']
    approved=json.loads((PLAN/'package-closure-plan.safe.json').read_text())['closure']
    if rows!=approved or len(rows)!=11 or sum(r['download_bytes'] for r in rows)!=6284816:raise RuntimeError('Exact authenticated11 package table required')
    curl_env=network_env(grant)
    ns=Namespace(namespace_path)
    completed=[];global_paths={};global_links=set();stream_bytes=0;stage='STARTED';current=None;latest={}
    def observe():
        ns.check();r=resources()
        if datetime.datetime.now(datetime.timezone.utc)>=stop:return 'GRANT_DEADLINE'
        reason=resource_stop(r)
        if reason:return reason
        table=guard.process_table();charged=r['driver_rss']
        for member in latest.get('members_including_Z',[]):
            if table.get(member['pid'],{}).get('start_ticks')!=member['start_ticks']:continue
            try:lines=Path('/proc/'+str(member['pid'])+'/status').read_text().splitlines()
            except OSError as caught:
                if caught.errno in (2,3):continue
                raise
            charged+=next((int(line.split()[1])*1024 for line in lines if line.startswith('VmRSS:')),0)
        if charged>RSS_CAP:return 'OWN_COMBINED_RSS_STOP'
        if ns.allocated()>PAYLOAD_CAP:return 'OWN_PAYLOAD_NAMESPACE_CAP'
        return None
    def child_status(value):
        latest.clear();latest.update(value)
        ns.save('curl-'+current+'-process.safe.json',value)
    ns.save('launch.safe.json',{'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'driver_identity':guard.process_table()[os.getpid()],'grant_path':str(grant_path),'signed_plan':PLAN_SHA,'source_review':REVIEW_SHA,'resources_before':before,'download_or_headers_only':True,'proxy_values_not_published':True})
    try:
        for row in rows:
            current=row['package'];stage='BEFORE_DOWNLOAD'
            if observe():raise RuntimeError('Resource or time stop')
            pool=row['official_pool_filename']
            if not re.fullmatch(r'pool/[A-Za-z0-9_+./~-]+\.deb',pool) or '..' in Path(pool).parts:raise RuntimeError('Official bounded pool filename required')
            url='https://deb.debian.org/debian/'+urllib.parse.quote(pool,safe='/+_.~-')
            archive=ns.create(row['package']+'.deb')
            argv=['/usr/bin/curl','--fail','--proto','=https','--silent','--show-error','--max-time','40','--max-filesize',str(row['download_bytes']),'--output',str(archive),url]
            ns.save('CURRENT.safe.json',{'stage':stage,'package':current,'driver_pid':os.getpid(),'completed':len(completed),'library_extraction_or_browser':False})
            result=guard.run_owned(argv,str(namespace_path),curl_env,deadline_seconds=min(45,(stop-datetime.datetime.now(datetime.timezone.utc)).total_seconds()),observe=observe,status=child_status)
            ns.save('curl-'+current+'-terminal.safe.json',result)
            if not result['phase_success'] or not result['settled']:raise RuntimeError('Native bounded curl failed')
            stage='ARCHIVE_IDENTITY'
            s=regular(archive,0o600).stat()
            if s.st_uid!=os.getuid() or s.st_nlink!=1 or s.st_size!=row['download_bytes'] or sha(archive)!=row['package_sha256']:raise RuntimeError('Exact signed archive bytes/hash required')
            stage='PUBLIC_HEADERS_ONLY'
            inspected=headers.inspect_deb(archive.read_bytes())
            stream_bytes+=inspected['control']['logical_tar_stream_bytes']+inspected['data']['logical_tar_stream_bytes']
            if stream_bytes>100663296:raise RuntimeError('Cumulative public tar stream cap')
            for member in inspected['data']['rows']:
                name=member['name'];previous=global_paths.get(name)
                if previous is not None and (member['kind']!='directory' or previous['kind']!='directory' or member['mode']!=previous['mode']):raise RuntimeError('Cross-package nondirectory/header-mode collision')
                global_paths[name]=member
                if member['kind'] in {'symlink','hardlink'}:global_links.add(name)
            for name in global_paths:
                parts=name.split('/')[:-1]
                if any('/'.join(parts[:i]) in global_links for i in range(1,len(parts)+1)):raise RuntimeError('Cross-package link ancestor')
            ns.save(current+'-headers.safe.json',inspected)
            external=[r['name'] for r in inspected['data']['rows'] if r.get('link',{}).get('class','').startswith('DOCUMENTATION_')]
            completed.append({'package':current,'version':row['version'],'archive_bytes':s.st_size,'archive_allocated_bytes':s.st_blocks*512,'archive_sha256':row['package_sha256'],'control_header_count':inspected['control']['header_count'],'data_header_count':inspected['data']['header_count'],'data_declared_regular_bytes':inspected['data']['regular_declared_bytes'],'data_type_counts':inspected['data']['type_counts'],'documentation_external_links_header_only':external,'actual_extraction_or_ABI':'NOT_RUN'})
            ns.save('partial.safe.json',{'completed':completed,'namespace_allocated':ns.allocated(),'resources':resources(),'extraction':False})
            if observe():raise RuntimeError('Resource or time stop')
        ns.save('terminal.safe.json',{'status':'PASS_EXACT11_ARCHIVE_AND_PUBLIC_HEADERS','completed':completed,'actual_archive_allocated_bytes':sum(r['archive_allocated_bytes'] for r in completed),'namespace_allocated_bytes':ns.allocated(),'data_declared_regular_bytes':sum(r['data_declared_regular_bytes'] for r in completed),'unique_data_headers':len(global_paths),'resources':resources(),'extracted_allocated_blocks':'UNKNOWN','library_loader_GLES_x264_or_browser':'NOT_RUN'})
        print(json.dumps({'status':'EXACT11_HEADERS_COMPLETE','namespace':str(namespace_path),'completed':len(completed),'extraction_or_browser':False}));return 0
    except BaseException as caught:
        ns.save('error.safe.json',{'status':'PARTIAL_STOPPED','stage':stage,'package':current,'completed':len(completed),'error_type':type(caught).__name__,'private_values_or_raw_output_published':False,'extraction_or_browser':False,'resources':resources()})
        print(json.dumps({'status':'PARTIAL_STOPPED','stage':stage,'error_type':type(caught).__name__,'completed':len(completed)}));return 1
    finally:ns.close()

if __name__=='__main__':
    raise SystemExit(main())
