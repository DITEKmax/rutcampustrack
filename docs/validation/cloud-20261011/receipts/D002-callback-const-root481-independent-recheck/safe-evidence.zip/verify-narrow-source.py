"""Exact const inverse and public Git/source compatibility; no TS/Node/native execution."""
from pathlib import Path
import hashlib,json,os,subprocess
A=Path('/workspace/scratch/rct-validation/client_session_offline_acceptance/d002-step-diagnostic/callback-const-root481')
OUT=Path(__file__).parent
ROOT=Path('/workspace/rutcampustrack')
old=(A/'closed-step-observer.before.ts').read_bytes();new=(A/'closed-step-observer.after.ts').read_bytes()
assert hashlib.sha256(old).hexdigest()=='27e5d2348f993310b89cdd532151ec25e2d7d754034dd5dd3211e4f68d924510'
assert hashlib.sha256(new).hexdigest()=='cf11c5268fdbfd839be408cbeb37cbef2f7ae713c56ba755dc9c1e0cc064c076'
inverse=new.replace(b'  const failureCallback = errorHandler.value;\n',b'').replace(b'failureCallback.call(receiver,',b'errorHandler.value.call(receiver,');assert inverse==old
assert new.index(b"if (!errorHandler || typeof errorHandler.value !== 'function')")<new.index(b'const failureCallback = errorHandler.value;')<new.index(b'failureCallback.call(receiver,')
assert (ROOT.parent/'rct-worktrees/client-session-offline/tests/e2e/d002-step-specs/closed-step-observer.ts').read_bytes()==new
before=json.loads((A/'READY.before.safe.json').read_text());after=json.loads((A/'READY.current.safe.json').read_text())
changes=[p for p in before['root_source_hashes'] if before['root_source_hashes'][p]!=after['root_source_hashes'][p]]
expected={'tests/e2e/fixtures/artifact-privacy.ts','tests/e2e/fixtures/safe-reporter.ts'}
assert set(changes)==expected and len(after['root_source_hashes'])==19
git=lambda *args:subprocess.check_output(['git','-C',str(ROOT),*args],timeout=10)
base='6576bd1f0d0181f90ebb40f6293de1a05f60625e';head='48124f576f51cc62fbdd95c7908b61d587f9e36d'
assert set(git('diff','--name-only',base,head).decode().splitlines())==expected
for p in set(before['root_source_hashes'])-expected:
    assert git('ls-tree',base,'--',p)==git('ls-tree',head,'--',p)
raw={}
for p in expected:
    b=git('show',base+':'+p).decode();a=git('show',head+':'+p).decode();assert hashlib.sha256(a.encode()).hexdigest()==after['root_source_hashes'][p] and (ROOT/p).read_text()==a;raw[p]=(b,a)
def section(text,start):
    i=text.index(start);j=text.index('\n}\n',i)+3;return text[i:j]
oldp,newp=raw['tests/e2e/fixtures/artifact-privacy.ts']
guard=section(oldp,'export function requirePrivateArtifacts(')==section(newp,'export function requirePrivateArtifacts(');assert guard
oldwipe=section(oldp,'export function sanitizeTestErrors(');newwipe=section(newp,'export function sanitizeTestErrors(')
oldcore=oldwipe[oldwipe.index('    const record ='):];newcore=newwipe[newwipe.index('    const record ='):];assert oldcore==newcore
oldr,newr=raw['tests/e2e/fixtures/safe-reporter.ts']
oldclass=oldr[oldr.index('export default class SafeReporter'):];newclass=newr[newr.index('export default class SafeReporter'):]
newclass=newclass.replace('      diagnostics: safeFailureDiagnostics(result.annotations, result.errors.length > 0),\n','');assert newclass==oldclass
assert 'onStepBegin' not in newr and 'onStepEnd' not in newr
v={'verdict':'APPROVE_SOURCE','observer_inverse_whole_bytes_exact':True,'guard_before_function_alias':True,'same_closed_callback_receiver_message':True,'Root_changed_paths':sorted(changes),'other17_committed_blob_mode_exact':True,'private_fixture_bodies':'Not read; committed blob identities compared for unchanged17. Future exact source admission still mandatory.','guard_whole_bytes_exact':guard,'old_sanitizer_wipe_core_exact':True,'old_reporter_class_exact_except_previously_reviewed_diagnostics_row':True,'onError_preserved_step_callbacks_absent':True,'native_TS18048_line':'NOT_CAPTURED; source-nullable-symbol address only','new_types_discovery':'NOT_RUN','actual367_stage':'UNKNOWN'}
fd=os.open(OUT/'narrow-source.safe.json',os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
with os.fdopen(fd,'w') as f:json.dump(v,f,indent=2);f.write('\n')
print(json.dumps({'verdict':'APPROVE_SOURCE','inverse':True,'Root2_only':True,'other17_Git_blob_mode_equal':True,'core_preserved':True,'Node_native_API':False}))
