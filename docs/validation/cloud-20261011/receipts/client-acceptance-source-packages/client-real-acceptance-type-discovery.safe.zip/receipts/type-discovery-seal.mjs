import fs from 'node:fs'
import crypto from 'node:crypto'
import ts from '/workspace/rutcampustrack/frontends/node_modules/typescript/lib/typescript.js'
const root='/workspace/rct-worktrees/client-real-acceptance'
const out='/workspace/scratch/rct-validation/client_real_acceptance'
const old=fs.readFileSync(out+'/support-a847.original.ts','utf8')
const current=fs.readFileSync(root+'/tests/e2e/fixtures/cloud-accepted-support.ts','utf8')
const typeOnly=fs.readFileSync(out+'/support-099-type-only.original.ts','utf8')
const emitted=value=>ts.transpileModule(value,{fileName:'cloud-accepted-support.ts',compilerOptions:{target:ts.ScriptTarget.ES2022,module:ts.ModuleKind.CommonJS,removeComments:true}}).outputText
if(emitted(old)!==emitted(typeOnly))throw new Error('Unexpected executable type-only helper change')
const digest=value=>crypto.createHash('sha256').update(value).digest('hex')
const revision=fs.readFileSync(out+'/source-revision.txt','utf8').trim()
const explicit=JSON.parse(fs.readFileSync(out+'/discovery-hooks-after.safe.json','utf8'))
const defaults=JSON.parse(fs.readFileSync(out+'/discovery-default-attempt2.safe.json','utf8'))
const plan={
 'cloud-accepted-admin-grants.spec.ts':['CRA-ADMIN-GRANT-01'],
 'cloud-accepted-helper-capabilities.spec.ts':['CRA-HELPER-VIEW-01','CRA-HELPER-HW-01','CRA-HELPER-CANCEL-01','CRA-HELPER-EXCUSE-01'],
 'cloud-accepted-registry-export.spec.ts':['CRA-EXPORT-FULL-01','CRA-EXPORT-LIMITED-01'],
 'cloud-accepted-role-authority.spec.ts':['CRA-ROLE-01'],
 'cloud-accepted-tma-proof.spec.ts':['CRA-TMA-MISSING-01','CRA-TMA-NON-NUMERIC-01','CRA-TMA-OVERFLOW-01','CRA-TMA-FUTURE-01','CRA-TMA-EXPIRED-01','CRA-TMA-UNBIND-01'],
}
const mappings=[]
for(const project of ['chromium','webkit'])for(const [file,ids]of Object.entries(plan)){
 const tests=explicit.tests.filter(row=>row.project===project&&row.file.endsWith('/'+file))
 if(tests.length!==ids.length)throw new Error('Unexpected discovery slice count')
 tests.forEach((test,index)=>mappings.push({...test,sourceCaseId:ids[index],execution:'NOT_RUN'}))
}
const sources=['fixtures','specs'].flatMap(dir=>fs.readdirSync(root+'/tests/e2e/'+dir).filter(file=>/^cloud-accepted-.*\.ts$/.test(file)).map(file=>'tests/e2e/'+dir+'/'+file)).sort().map(file=>({file,sha256:digest(fs.readFileSync(root+'/'+file)),bytes:fs.statSync(root+'/'+file).size}))
const receipt={
 revision,base:'cd3f237acffd4f0b9dd2a74babb2ee822376f0cb',
 sourceContext:{ownAuthoredCommit:revision,foreignDefaultConfigCommit:'1b4d8bdafe59e227bfc26cd8fd6eeed98e10f099',configSha256:digest(fs.readFileSync(root+'/tests/e2e/playwright.config.ts'))},
 typecheck:{command:'node --max-old-space-size=512 /workspace/rutcampustrack/frontends/node_modules/typescript/bin/tsc --noEmit --project '+out+'/tsconfig.current.json',nativeExit:0,diagnostics:0,attempt1NativeExit:2,correction:'NEW test-only closed five-code union; remove NodeNext→Bundler product type import; existing fixture function returns open string[]',moduleMode:'existing E2E NodeNext unchanged',typeGateWeakening:false,proof:'actual-type-resolution.safe.json'},
 correctionExecutableEquivalence:{scope:'a847→099 type-only correction, final privacy registration intentionally changes runtime hook wiring',equal:true,compiler:'TypeScript5.9.3',options:'ES2022/CommonJS/removeComments',outputSha256:digest(emitted(typeOnly))},
 privacyCorrection:{id:'PRIV-HOOK01',beforeSource:'099585ffe3e19b04b890c96d30438961ab39f8c4',beforeRegistration:'first spec1 afterEach; other4spec0',afterNativeListExit:0,afterRegistration:'every new spec1 afterEach; all28 cases registered',beforeReceipt:'discovery-hooks.safe.json',afterReceipt:'discovery-hooks-after.safe.json',actualBrowserArtifactValidation:'NOT_RUN'},
 explicitDiscovery:{nativeExit:0,total:28,finiteCasesPerProject:14,projects:['chromium','webkit'],mappings},
 defaultDiscovery:{nativeExit:0,total:defaults.count,newOptinCases:0,existingMobileOptinCases:0,firstNativeExit:1,firstLoadErrors:8,correction:'same-lock third-party @axe-core/playwright4.11.2/axe-core4.11.3 required by actual existing default imports'},
 reporter:'scratch metadata-only discovery reporter; no titles/errors/bodies; actual credential runtime safe reporter/trace policy unchanged',
 sources,independentReview:'PENDING',browser:'NOT_RUN',backend:'NOT_RUN',faultSensitivity:'PLANNED_NOT_RUN',angularMutations:0,
}
fs.writeFileSync(out+'/current-type-discovery-final.safe.json',JSON.stringify(receipt,null,2)+'\n')
process.stdout.write(JSON.stringify({revision,typecheckNativeExit:0,explicit:28,default:defaults.count,defaultNewOptin:0,typeOnlyHelperEmittedJsEqual:true,allPrivateHooksRegistered:true,browser:'NOT_RUN'})+'\n')
