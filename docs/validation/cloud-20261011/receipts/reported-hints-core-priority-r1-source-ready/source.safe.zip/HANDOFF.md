Исправление HINTS-CORE-CAP-EVICTION — только SOURCE

Исходный пакет 0229/810a и ZIP ece3 сохранены. Изменены только OWN artifact-privacy.ts и safe-reporter.ts. Core recorder считает прежний лимит 8 по core-диагностикам. Если новый core приходит при заполненных восьми местах, удаляется одна разрешённая reported-only annotation, затем записывается core. Core-аннотации никогда не удаляются.

Decoder отдельно собирает core и подсказки в первых 32 аннотациях. Он возвращает сначала core, затем подсказки на свободных местах, всего максимум 8. При штатной записи собственный канал аннотаций также остаётся в пределах 8; повторные и поздние ошибки не накапливают лишние подсказки. Максимум одна class и одна frame.

Десять фактических проверок исходников подтверждают сохранение classifier15, 14 статусов, guard, sanitizer wipe, полей/вывода reporter и ограниченного reader. Core recorder и decoder намеренно изменены: прежнее заявление об их byte identity к этой revision не применяется. Все reported hints остаются неподтверждёнными UNKNOWN/0. Class/frame и clock END не доказывают причину, операцию или успех hook.

Подготовлен один публичный regression helper с пятью порядками: core перед hints; hints перед core; повторные hints перед поздними core; чередование; прямой decoder. Для старого 0229/810a ожидаются четыре causal FAIL из пяти и потеря 8→6 core; для исправления — пять PASS, все восемь исходных core, лимит 8, отсутствие маркера и сохранение ошибок. Автор Node не запускал. Прямой decoder-контроль проверяет приоритет независимо от recorder.

Новый Node-план: priority RED/GREEN, прежние reported RED/GREEN, настоящий browser-free worker3, прежние privacy producer/interruption/missingguard, форматирование OWN2 с проверкой и scoped strict TS. Девять последовательных фаз, общий бюджет 900 секунд плюс 60 cleanup, до 180 секунд на фазу. Existing b78 и callbacks status/observe совпадают побайтно. Только новые параметры, pins и две проверки результатов priority. V8 managed heap512; RSS1GiB и owned TMP32MiB контролируются мягким sampled monitoring. Нет API, браузера, seed, login, сервисов, сети или Root writes.

Все native-контроли этой коррекции NOT_RUN; actual CI cause UNKNOWN. Следующий шаг — узкий независимый recheck, затем свежий Root grant. Команда после grant:

/usr/bin/python3 /workspace/scratch/rct-validation/client_real_acceptance/ci-reported-hints-core-priority-r1/native-plan/run-approved-node.py /workspace/scratch/rct-validation/client_real_acceptance/ci-reported-hints-core-priority-r1/private/root-node-grant-01.json

Root9176 execution / 481 Source producer, OWN0dc. Общие документы, config, CI, protocol fields, locks и Angular не изменялись. Native-процессов автора нет.
