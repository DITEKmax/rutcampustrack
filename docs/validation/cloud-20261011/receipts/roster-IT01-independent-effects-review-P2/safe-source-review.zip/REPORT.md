CHANGES_REQUESTED — one P2: IT-ADMISSION-LEDGER-COMMIT-BEFORE-LIMITS.

Observer ac671 commits sessions/known at lines127/135 before limits137–145. Selected actual-class RAM controls confirm denied duplicate commits its ID, denied third session commits its namespace, and settle203 raises before any removal of an already admitted valid ID. Validate staged candidates before commit; preserve all existing bounds and unknown resources.

Current b022 READY/5b27 parent and every pinned checking source match. New immediate pre-exec two-line check reverses exactly to old parent. Supplement8 matches; selected5 classes total11 methods. Existing semantic/formatter/44unit proof reused. No other bounded source-effects blocker found.

No Docker/native/private data/probe/grant/XML/log access or mutation. Source review does not authorize runtime; fresh resources/grant, actual11 XML cases and owned cleanup remain external requirements.
