import copy
import datetime
import hashlib
import json
import pathlib
import re
import subprocess

from jsonschema import Draft202012Validator, FormatChecker

WORKTREE = pathlib.Path('/workspace/rct-worktrees/np01-contract')
OUT = pathlib.Path('/workspace/scratch/rct-validation/np01_common_review')
AUTHOR = '9757742e9c6baf75760c6cb5174fbdd0fd491a0c'
BASE = '2bca095380f72e8908a2511f2b10f0e795607f05'
ACCEPTED = '3908fad9624f97aec8891fc79338ceb6b0616bf3'
MIGRATIONS = 'services/academic-service/academic-app/src/main/resources/db/migration/'
TEST = 'services/academic-service/academic-app/src/test/java/ru/rutcampustrack/academic/migration/BotCredentialLifecycleMigrationIT.java'
PATHS = ['proto/academic.proto', 'event-schemas/password.changed.json',
         MIGRATIONS + 'V57__bot_credential_message_lifecycle.sql', TEST]

def git(*args):
    return subprocess.check_output(['git', '-C', str(WORKTREE), *args])

def blob(revision, path):
    return git('show', revision + ':' + path)

def identity(data):
    return {'sha256': hashlib.sha256(data).hexdigest(), 'bytes': len(data)}

def write(name, value):
    (OUT / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')

inventory = [{'path': path, 'revision': AUTHOR, **identity(blob(AUTHOR, path))} for path in PATHS]
old_migrations = []
for line in git('ls-tree', '-r', '--name-only', BASE, '--', MIGRATIONS).decode().splitlines():
    a, b = blob(BASE, line), blob(AUTHOR, line)
    old_migrations.append({'path': line, 'base': identity(a), 'author': identity(b), 'unchanged': a == b})
accepted_migrations = []
for line in git('ls-tree', '-r', '--name-only', ACCEPTED, '--', MIGRATIONS).decode().splitlines():
    a, b = blob(ACCEPTED, line), blob(AUTHOR, line)
    accepted_migrations.append({'path': line, 'unchanged': a == b})

old_proto = blob(BASE, 'proto/academic.proto').decode()
new_proto = blob(AUTHOR, 'proto/academic.proto').decode()
rpc_addition = '''  // Dedicated notification-bot TLS/directed-identity capability; generic profiles remain redacted.
  rpc GetOwnBotInitialCredentials (BotOwnInitialCredentialsRequest)
      returns (BotOwnInitialCredentialsResponse);

  // Closed metadata-only lifecycle for exact own initial-credential cards.
  rpc ManageOwnBotCredentialMessages (BotCredentialMessagesRequest)
      returns (BotCredentialMessagesResponse);

'''
subtracted = new_proto.split('// UNKNOWN/absent modes')[0].replace(rpc_addition, '')
assert subtracted.rstrip() == old_proto.rstrip()
assert new_proto.count(rpc_addition) == 1
enum_sets = {}
for name, body in re.findall(r'enum (BotCredential\w+) \{(.*?)\n\}', new_proto, re.S):
    vals = [(n, int(v)) for n, v in re.findall(r'(BOT_CREDENTIAL_\w+)\s*=\s*(\d+);', body)]
    assert vals and vals[0][0].endswith('_UNSPECIFIED') and vals[0][1] == 0
    assert len({v for _, v in vals}) == len(vals)
    enum_sets[name] = dict(vals)
assert len(enum_sets) == 6

old_schema = json.loads(blob(BASE, 'event-schemas/password.changed.json'))
new_schema = json.loads(blob(AUTHOR, 'event-schemas/password.changed.json'))
Draft202012Validator.check_schema(new_schema)
v1 = new_schema['oneOf'][0]['properties']
assert v1['event_version'] == old_schema['properties']['event_version']
assert v1['payload'] == old_schema['properties']['payload']
assert new_schema['required'] == old_schema['required']
assert new_schema['additionalProperties'] == old_schema['additionalProperties']
for key in ['event_type', 'event_id', 'occurred_at', 'trace_id', 'source']:
    assert new_schema['properties'][key] == old_schema['properties'][key]
validator = Draft202012Validator(new_schema, format_checker=FormatChecker())
envelope = dict(event_type='password.changed', event_id='00000000-0000-4000-8000-000000000001',
                occurred_at='2026-10-12T02:00:00Z', trace_id='synthetic-review', source='auth-service')
cases = []
def check(name, version, payload, valid):
    event = copy.deepcopy(envelope)
    event.update(event_version=version, payload=payload)
    actual = validator.is_valid(event)
    cases.append({'case': name, 'expected_valid': valid, 'actual_valid': actual, 'pass': actual == valid})
    assert actual == valid, name

check('v1-existing-positive', 1, {'telegram_id': 71101}, True)
check('v1-legacy-no-int64-upper-limit-preserved', 1, {'telegram_id': 9223372036854775808}, True)
check('v1-cannot-silently-add-v2-metadata', 1, {'telegram_id': 71101, 'user_id': 1}, False)
for value, name in [(None, 'null'), (0, 'zero'), (-1, 'negative'), (True, 'boolean'), ('1', 'string')]:
    check('v1-telegram-' + name, 1, {'telegram_id': value}, False)
payload = {'user_id': 1, 'credentials_version': 2, 'telegram_binding_version': 3}
check('v2-unlinked-cleanup', 2, payload, True)
check('v2-bound-snapshot', 2, {**payload, 'telegram_id': 71101}, True)
check('v2-int64-upper-bound', 2, {k: 9223372036854775807 for k in payload}, True)
for key in payload:
    check('v2-missing-' + key, 2, {k: v for k, v in payload.items() if k != key}, False)
    for value, name in [(None, 'null'), (0, 'zero'), (-1, 'negative'), (True, 'boolean'),
                        ('1', 'string'), (9223372036854775808, 'overflow')]:
        check('v2-' + key + '-' + name, 2, {**payload, key: value}, False)
for version in [0, 3, None, True, '2']:
    check('unknown-or-malformed-version-' + str(version), version, payload, False)
check('v2-null-optional-telegram', 2, {**payload, 'telegram_id': None}, False)
check('v2-unknown-payload-field', 2, {**payload, 'unknown': 1}, False)
check('v2-secret-field-denied', 2, {**payload, 'initial_password': 'synthetic-review-marker'}, False)
assert all(x['unchanged'] for x in old_migrations)
assert all(x['unchanged'] for x in accepted_migrations)

test_names = re.findall(r'@Test void (\w+)\(', blob(AUTHOR, TEST).decode())
assert len(test_names) == 14
write('source-inventory.safe.json', {'timestamp': datetime.datetime.now(datetime.timezone.utc).isoformat(),
      'requested_model': 'gpt-6.1-sol', 'requested_effort': 'xhigh', 'actual_model_effort': 'UNKNOWN',
      'read_only_source': True, 'accepted_baseline': ACCEPTED, 'integration_base': BASE,
      'reviewed_author': AUTHOR, 'source_paths': inventory})
write('compatibility-checks.safe.json', {'revision': AUTHOR, 'status': 'PASS',
      'qualification': 'Independent light source/schema checks only; no runtime, generated descriptor or TLS/provider proof',
      'old_proto_after_exact_additions_removed': 'IDENTICAL', 'old_v1_payload_and_envelope_constraints': 'IDENTICAL',
      'enum_explicit_codes': enum_sets, 'schema_cases': cases, 'retained_database_test_names': test_names,
      'old_integration_migrations': old_migrations, 'accepted_baseline_migrations': accepted_migrations})
print(json.dumps({'status': 'PASS', 'schema_cases': len(cases), 'retained_DB_cases': len(test_names),
                  'old_base_migrations_identical': len(old_migrations),
                  'accepted_baseline_migrations_identical': len(accepted_migrations),
                  'enum_domains': len(enum_sets)}))
