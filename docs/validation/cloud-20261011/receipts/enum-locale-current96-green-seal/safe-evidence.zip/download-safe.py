"""One approved bounded SAFE JSON archive only; no raw reports/logs/values."""
from pathlib import Path,PurePosixPath
import collections
import hashlib
import io
import json
import os
import re
import urllib.request
import zipfile
import traceback
OUT=Path(__file__).parent
INPUT=OUT/'.download-input.private.json'
HEAD='96c7aee0a114e978ce3ed2976127a2a59c1a69e3'
NAME='safe-integration-outcomes-academic-service-1'
METHOD='enumDatabaseAndHttpBoundaryRemainCanonicalUnderTurkishLocale'
SOURCE='services/academic-service/academic-app/src/test/java/ru/rutcampustrack/academic/integration/AcademicGrpcIT.java'
HASH='dd0c466926911d99879fcdb59dd94641ca810bb714992d8fda7bc470b409010d'
STATUSES={'PASSED','FAILED','ERROR','SKIPPED','NOT_EXECUTED'}
OLD=OUT.parent/'ci_c16_receipts'
baseline=json.loads((OLD/(NAME+'.json')).read_text())
casekeys=set().union(*(set(c) for p in OLD.glob('safe-*-outcomes-*.json') for c in json.loads(p.read_text())['cases']))
def save(n,b):
    fd=os.open(OUT/n,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
    with os.fdopen(fd,'wb') as f:f.write(b)
try:
    artifact=json.loads(INPUT.read_text())
    assert artifact['name']==NAME and 0<artifact['size_in_bytes']<=1048576
    private_archive=OUT/'.download-safe.private.zip'
    if private_archive.exists():data=private_archive.read_bytes()
    else:
        with urllib.request.urlopen(artifact['url'],timeout=30) as response:data=response.read(1048577)
    assert len(data)==artifact['size_in_bytes']<=1048576
    digest=hashlib.sha256(data).hexdigest();assert artifact['digest']=='sha256:'+digest
    if not private_archive.exists():save(private_archive.name,data)
    with zipfile.ZipFile(io.BytesIO(data)) as z:
        assert z.testzip() is None and len(z.infolist())==1
        member=z.infolist()[0];assert member.file_size<=1048576 and member.filename.endswith('.json')
        value=json.loads(z.read(member))
    assert set(value)==set(baseline) and value['schemaVersion']==1
    assert set(value['metadata'])==set(baseline['metadata'])
    meta=value['metadata']
    assert meta['prHeadSha']==HEAD and meta['runId']=='38302629034' and meta['event']=='pull_request' and meta['runAttempt']=='1'
    assert meta['service']=='academic-service' and meta['task']=='integrationTest' and re.fullmatch('[0-9a-f]{40}',meta['checkoutSha'])
    assert value['collection']==baseline['collection'] and value['acceptance']==baseline['acceptance']
    cases=value['cases'];counts=collections.Counter(c['status'] for c in cases);xmlcounts=collections.Counter()
    for x in value['xml']:
        assert set(x)<=set(baseline['xml'][0]) and x['state']=='PARSED'
        for suite in x['suites']:
            assert set(suite)==set(baseline['xml'][0]['suites'][0]) and suite['countsConsistent'] is True
            assert set(suite['observed'])==STATUSES;xmlcounts.update(suite['observed'])
    for c in cases:
        assert set(c)<=casekeys and c['status'] in STATUSES and c['identity'] in {'SOURCE_METHOD','ORDINAL_ONLY'}
        assert c['classname'] is None or re.fullmatch(r'[A-Za-z0-9_.$]+',c['classname'])
        if c.get('source'):
            p=PurePosixPath(c['source']);assert not p.is_absolute() and '..' not in p.parts and re.fullmatch('[0-9a-f]{64}',c['sourceSha256'])
        if c['identity']=='SOURCE_METHOD':assert c['classname'] is not None and re.fullmatch(r'[A-Za-z_$][A-Za-z0-9_$]*',c['method'])
        else:assert c['method'] is None or re.fullmatch(r'[A-Za-z_$][A-Za-z0-9_$]*',c['method'])
    assert all(counts[s]==value['summary'][s]==xmlcounts[s] for s in STATUSES)
    targets=[c for c in cases if c.get('method')==METHOD and c['classname']=='ru.rutcampustrack.academic.integration.AcademicGrpcIT']
    assert len(targets)==1
    target=targets[0];assert target['identity']=='SOURCE_METHOD' and target['source']==SOURCE and target['sourceSha256']==HASH
    failures=[c for c in cases if c['status'] in {'FAILED','ERROR'}]
    others=[c for c in failures if c!=target]
    result={'producer':HEAD,'artifact_id':artifact['id'],'archive_bytes':len(data),'archive_digest':digest,'metadata':meta,'counts':value['summary'],
        'xml_summary_case_counts_consistent':True,'target':target,'failure_cases':failures,'other_failures':others,'current_target_source_hash':HASH,
        'raw_XML_logs_messages_request_personal_secret_values_read':False,'acceptance':'NOT_PROMOTED',
        'DB_HTTP_execution':('Full unchanged source method completed, including real configured JDBC/HTTP assertions; runtime/container provenance qualified by configured job and prior source review' if target['status']=='PASSED' else 'Failure identifies current method only; reached assertion/phase and all required DB/HTTP positive checks require a separately approved minimal closed diagnostic.')}
    save(NAME+'.zip',data)
    save(NAME+'.json',(json.dumps(value,indent=2)+'\n').encode())
    save('target-outcome.safe.json',(json.dumps(result,indent=2)+'\n').encode())
    private_archive.unlink()
    print(json.dumps({'status':'SAFE_NATIVE_VERIFIED','metadata':meta,'counts':value['summary'],'target':target,'total_failure_count':len(failures),'other_failure_count':len(others)}))
except Exception as error:
    print(json.dumps({'status':'SAFE_COLLECTION_BLOCKED','safe_error_type':type(error).__name__,'http_status':getattr(error,'code',None),'own_line':next((f.lineno for f in reversed(traceback.extract_tb(error.__traceback__)) if f.filename==__file__),None)}))
    raise SystemExit(1)
finally:INPUT.unlink(missing_ok=True)
