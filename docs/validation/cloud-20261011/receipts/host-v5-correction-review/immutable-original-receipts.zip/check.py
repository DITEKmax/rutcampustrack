from pathlib import Path
import ast,hashlib,json,zipfile,stat,difflib,datetime
P=Path('/workspace/scratch/rct-validation');O=P/'hostcfg_v5_independent_recheck/correction_recheck';B=P/'current_host_config_v5';R=P/'current_host_config_v5_redirect_query_correction';I=P/'current_host_config_v5_mongo_identity_correction'
checks=[]
def check(n,v):
 checks.append({'name':n,'pass':bool(v)})
 if not v:raise AssertionError(n)
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
seals=[(B,'launch-manifest.json','e3b6e2c80d819e758bd54722a0d348764dcee5ce64a1ede0cd20df16adc96378','safe-evidence.zip','03ae75b7bb3ec600b06efaf95316e588c5801b4595bf34f122e05f81aeac7cc6'),(R,'manifest.json','75e4107b7053de13feb12d5cdbecfdae67124b1cdd01fee1ab52140c0439ab73','safe-evidence.zip','208fda04dfe6c905c5bc1a3fa6f61ae6e960dcddf4cf076057794e37cc95ab43'),(I,'manifest.json','077de277ed0dd9182e36da132c0e82611d65504382a9e45692d07ffe9d0a0e95','safe-evidence.zip','abb26a26744d8e68ce185dbed8de79f09d909159a97d694e85660cbdf9cf45b3'),(I,'launch-schema-addendum-manifest.json','b3c273ecf189f33c484945513dd5fd8ccc1bc20257b768da51e695a57c5846ec','launch-schema-addendum.safe.zip','72cd6b787e330b5c8db3c7279691797cc47a1aa46bfb50f5e4c7eb6c1496a90c')]
for root,m,msha,z,zsha in seals:
 label=root.name+'/'+m;check(label+'_digest',sha(root/m)==msha);check(label+'_ZIPdigest',sha(root/z)==zsha);rows=json.loads((root/m).read_text())['files']
 check(label+'_source_entries',all(Path(x['path']).is_relative_to(root) and stat.S_ISREG(Path(x['path']).lstat().st_mode) and Path(x['path']).stat().st_size==x['bytes'] and sha(x['path'])==x['sha256'] for x in rows))
 with zipfile.ZipFile(root/z) as f:
  check(label+'_CRC',f.testzip() is None);check(label+'_archive_names',set(f.namelist())=={x['relative_path'] for x in rows}|{m});check(label+'_archive_bytes',all(hashlib.sha256(f.read(x['relative_path'])).hexdigest()==x['sha256'] for x in rows))
check('original_review_manifest_preserved',sha(P/'hostcfg_v5_independent_recheck/manifest.json')=='afb29cb4ddd980b381b77735d74e4639d23305a1e3ee8e9ae1f14080d0ad7732')
check('original_review_ZIP_preserved',sha(P/'hostcfg_v5_independent_recheck/safe-review.zip')=='8bf5c2ce7e41ab80f7f9727f0cad056b26c1bc6d890de359f0e1d69de429a9d1')
old=(B/'run-mongo.py').read_text();new=(I/'run-mongo.py').read_text();tree=ast.parse(new);helper=next(x for x in tree.body if isinstance(x,ast.FunctionDef) and x.name=='exact_live_child');scope={};exec(compile(ast.Module(body=[helper],type_ignores=[]),'<sealed-exact-helper>','exec'),scope)
gate=next(x for x in ast.walk(tree) if isinstance(x,ast.If) and isinstance(x.test,ast.BoolOp) and any(isinstance(c,ast.UnaryOp) and isinstance(c.operand,ast.Call) and isinstance(c.operand.func,ast.Name) and c.operand.func.id=='exact_live_child' for c in x.test.values));expression=compile(ast.Expression(gate.test.values[0]),'<sealed-main-gate>','eval')
oldnode=next(x for x in ast.walk(ast.parse(old)) if isinstance(x,ast.Assign) and any(isinstance(a,ast.Name) and a.id=='owned' for a in x.targets));oldexpr=compile(ast.Expression(oldnode.value),'<sealed-old-expression>','eval')
c={'pid':101,'start_ticks':1001,'state':'S'};d={'pid':102,'start_ticks':1002,'state':'S'};rec={'child_pid':101,'members_including_Z':[c,d]};cases=[]
def case(name,r,t,expected):
 actual=scope['exact_live_child'](r,t);reject=eval(expression,dict(scope,record=r,table=t));previous=bool(eval(oldexpr,{'record':r,'table':t}));check(name,actual is expected and reject is (not expected));cases.append({'name':name,'expected_accepts':expected,'new_accepts':actual,'old_accepts':previous})
case('child_live',rec,{101:c,102:d},True)
for state in ['Z','X','x','?']:case('child_state_'+state,rec,{101:c|{'state':state},102:d},False)
for state in ['R','D','T','t','I','W']:case('allowed_live_state_'+state,rec,{101:c|{'state':state},102:d},True)
case('child_absent',rec,{102:d},False);case('child_reused',rec,{101:c|{'start_ticks':9001},102:d},False);case('all_absent',rec,{},False)
case('child_row_missing',rec|{'members_including_Z':[d]},{101:c,102:d},False);case('ambiguous_child',rec|{'members_including_Z':[c,c|{'start_ticks':2001},d]},{101:c,102:d},False)
case('child_pid_missing',{'members_including_Z':[c,d]},{101:c,102:d},False)
for value in [None,False,0,-1,'101',101.0]:case('invalid_pid_'+str(type(value).__name__)+str(len(cases)),rec|{'child_pid':value},{101:c,102:d},False)
for value in [None,False,0,-1,'1001',1001.0]:case('invalid_birth_'+str(type(value).__name__)+str(len(cases)),rec|{'members_including_Z':[c|{'start_ticks':value},d]},{101:c,102:d},False)
case('current_pid_wrong',rec,{101:c|{'pid':102},102:d},False)
# Reverse only reviewed narrow modifications, requiring exact original bytes.
reconstructed=new.replace("CORRECTION = Path(__file__).parent\nOWN = Path("+repr(str(B))+")",'OWN = Path(__file__).parent',1)
helpertext=ast.get_source_segment(new,helper)+'\n\n';reconstructed=reconstructed.replace(helpertext,'',1)
newgate="        if not exact_live_child(record, table) or not db.is_dir() or db.is_symlink() or not runtime.is_dir() or runtime.is_symlink():"
oldgate="        owned = [r for r in record.get('members_including_Z', []) if table.get(r['pid'], {}).get('start_ticks') == r['start_ticks']\n                 and table[r['pid']]['state'] != 'Z']\n        if not owned or not db.is_dir() or db.is_symlink() or not runtime.is_dir() or runtime.is_symlink():"
reconstructed=reconstructed.replace(newgate,oldgate,1)
start=reconstructed.index("    if digest(CORRECTION / 'manifest.json')")
end=reconstructed.index("    spec = json.loads((OWN / 'mongo-spec.json').read_text())",start)
correctionblock=reconstructed[start:end];reconstructed=reconstructed[:start]+reconstructed[end:]
check('runner_exact_allowed_delta',reconstructed==old)
check('guard_gate_before_private_ENV_or_allocations',new.index("digest(CORRECTION / 'manifest.json')")<new.index('workspace_runtime.mkdir')<new.index('credentials = dict'))
check('self_source_exact_regular',"corrected_source = exact_regular(Path(__file__).absolute())" in correctionblock)
check('self_row_exact_path_and_hash',"row['path'] == str(corrected_source)" in correctionblock and "self_row is None or digest(corrected_source) != self_row['sha256']" in correctionblock)
check('all_correction_sources_verified',"digest(exact_regular(row['path'])) != row['sha256']" in correctionblock)
# Actual selected digest-grant condition against harmless metadata only.
condition=next(x.test for x in ast.walk(tree) if isinstance(x,ast.If) and "mongo_identity_correction_manifest_sha256" in ast.unparse(x.test));code=compile(ast.Expression(condition),'<sealed-correction-grant-condition>','eval');ctx={'CORRECTION':I,'digest':lambda p:'ACTUAL_PUBLIC_MANIFEST_DIGEST'}
for label,grant,expect in [('exact',{'mongo_identity_correction_manifest_sha256':'ACTUAL_PUBLIC_MANIFEST_DIGEST'},False),('missing',{},True),('old',{'mongo_identity_correction_manifest_sha256':'OLD'},True),('false',{'mongo_identity_correction_manifest_sha256':False},True)]:check('correction_grant_'+label,eval(code,dict(ctx,grant=grant)) is expect)
launch=json.loads((I/'effective-launch-inputs-v2.json').read_text());redirect=json.loads((R/'effective-launch-inputs.json').read_text());base=json.loads((B/'launch-commands-v5.json').read_text())
check('authoritative_Docker_exact_two_file',launch['docker_argv']==redirect['docker_argv'])
for phase in ['server','bootstrap']:
 expected=base['mongo_'+phase+'_argv'].copy();expected[1]=str(I/'run-mongo.py');check('corrected_native_'+phase,launch['mongo_'+phase+'_argv']==expected)
check('Java_commands_unchanged',launch['host_argv_schema']==base['host_argv_schema'])
check('addendum_core_binding',json.loads((I/'launch-schema-addendum-manifest.json').read_text())['core_manifest_sha256']==seals[2][2])
# Official upstream evidence is read from sealed fragments; no network replay/vendor equivalence claim.
ref=json.loads((I/'official-replica-source.safe.json').read_text());fragments='\n'.join(x['fragment'] for x in ref['sources'])
check('official_default_horizon_exception_fragment','mapping.first == SplitHorizon::kDefaultHorizon' in fragments and 'continue;' in fragments and 'forwardMapping.emplace(SplitHorizon::kDefaultHorizon, host)' in fragments and 'newConfig.validate()' in fragments)
bootstrap=(B/'mongo-bootstrap.js').read_text();check('no_custom_horizon_or_disable_parameter','horizons' not in bootstrap and 'disableSplitHorizonIPCheck' not in old+new+bootstrap)
check('vendor_mapping_honestly_unknown',ref['native_source_byte_equivalence']=='UNKNOWN' and ref['native_git']!=ref['official_tag_commit'])
(O/'checks.safe.json').write_text(json.dumps({'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'PASS_SOURCE_ONLY','checks':checks,'count':len(checks),'failed':0,'identity_cases':cases,'identity_cases_count':len(cases),'private_inputs_read':False,'runtime_or_network':False,'upstream_source_evidence':'sealed author-fetched official version-tag fragments only; public vendor byte mapping remains UNKNOWN'},indent=2)+'\n')
(O/'runner-delta.safe.diff').write_text(''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='base-v5/run-mongo.py',tofile='identity-correction/run-mongo.py')))
print(json.dumps({'checks':len(checks),'identity_cases':len(cases),'failed':0,'runtime_or_network':False}))
