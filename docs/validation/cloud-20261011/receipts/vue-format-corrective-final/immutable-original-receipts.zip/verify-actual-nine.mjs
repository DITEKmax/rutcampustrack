import fs from 'node:fs'
import { spawnSync } from 'node:child_process'
import { createHash } from 'node:crypto'
process.argv[2]='library'
const {vue,firstDelta}=await import('../prettier-final/verify-meaning.mjs')
const scratch='/workspace/scratch/rct-validation/authored_format_current/vue-eslint-correction'
const root='/workspace/rct-worktrees/ci-academic-heap'
const code=fs.readFileSync(`${scratch}/probe-block-pipeline.mjs`,'utf8')
const section=code.slice(code.indexOf('function foldConstantDisplay'),code.indexOf('const rows='))
const {normalizeConstantDisplay}=new Function(section+';return {normalizeConstantDisplay}')()
const actual=JSON.parse(fs.readFileSync(`${scratch}/actual-candidate-equality-attempt2.safe.json`,'utf8'))
const rows=[]
const hash=v=>createHash('sha256').update(typeof v==='string'?v:JSON.stringify(v)).digest('hex')
for(const path of actual.candidate_mismatches) {
 const native=spawnSync('git',['show',`cd3f237acffd4f0b9dd2a74babb2ee822376f0cb:${path}`],{cwd:root,encoding:'utf8'})
 if(native.status!==0)throw new Error('BASELINE')
 const source=fs.readFileSync(`${root}/${path}`,'utf8')
 const before=normalizeConstantDisplay(await vue(native.stdout,path)),after=normalizeConstantDisplay(await vue(source,path))
 const delta=firstDelta(before,after)
 rows.push({path,originalMeaningHash:hash(before),actualMeaningHash:hash(after),actualSourceHash:hash(source),meaningEqual:delta===null,firstDelta:delta})
}
const result={finiteActualFiles:rows.length,meaningFailures:rows.filter(r=>!r.meaningEqual).length,
 reusedExactPriorFiles:127-rows.length,qualification:'Only nine actual source hash differences replayed; all other118 exact prior reviewed candidate bytes. Same explicit constant-only Vue helper normalization/controls.',rows}
fs.writeFileSync(`${scratch}/actual-nine-meaning.safe.json`,JSON.stringify(result,null,2)+'\n',{mode:0o600})
console.log(JSON.stringify({files:rows.length,meaningFailures:result.meaningFailures,reusedExactPriorFiles:result.reusedExactPriorFiles}))
if(result.meaningFailures)process.exitCode=1
