from pathlib import Path
import ast,datetime,hashlib,json,os,stat,types,zipfile,copy,errno
from unittest.mock import patch
P=Path('/workspace/scratch/rct-validation/current_host_restart_plan');A=P.parent/'current_host_restart_ancestor_correction';C=P.parent/'current_host_restart_ancestor_correction_v2';O=P.parent/'current_host_restart_review/correction_recheck';checks=[]
def check(n,v):
 checks.append({'name':n,'pass':bool(v)})
 if not v:raise AssertionError(n)
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
for root,msha,zsha in [(P,'3b02e82b61409f7118bf434afcd888f5ae556504067913527d673d673d421537','f05c922802abcbd8fb07608b05890cfe040f9b5c8ccd86ee0c3f16cb461a2383'),(A,'ad0b7d42314db89a53e40bbef461993e6536909ddbe3cc93bca766820ab4bc11','f987760014aba23f0979275055099bb1d4b04e436bf40da52a63c560e020c8b0'),(C,'9ce528ac02bf076952f99fdcf2df2580518833c18abf57ab0672a1822cea1c4d','bd1153e468b449ddf6d4e8c1c7ff836b8deb47634dbb0c5818c8b78b4742730a')]:
 check(root.name+'_manifest',sha(root/'manifest.json')==msha);check(root.name+'_ZIP',sha(root/'safe-evidence.zip')==zsha);rows=json.loads((root/'manifest.json').read_text())['files'];check(root.name+'_source_rows',all(Path(r['path']).is_relative_to(root) and stat.S_ISREG(Path(r['path']).lstat().st_mode) and sha(r['path'])==r['sha256'] and Path(r['path']).stat().st_size==r['bytes'] for r in rows))
 with zipfile.ZipFile(root/'safe-evidence.zip') as z:check(root.name+'_ZIP_CRC_members',z.testzip() is None and set(z.namelist())=={r['name'] for r in rows}|{'manifest.json'});check(root.name+'_ZIP_source_bytes',all(hashlib.sha256(z.read(r['name'])).hexdigest()==r['sha256'] for r in rows))
check('original_review_manifest_preserved',sha(O.parent/'manifest.json')=='ec5186fe66d182690c5e834d20f5a32231e8134679e36985b72d061128c6d9bd');check('original_review_ZIP_preserved',sha(O.parent/'safe-review.zip')=='87666a913025f3fdd4ccd7ed8937b62f131e6a06ab930c45a52c1d87633de50d')
check('v2_helper_exact_ad0b_bytes',(C/'restart-boundary.py').read_bytes()==(A/'restart-boundary.py').read_bytes())
for name in ['docker-up-restart.py','run-mongo-restart.py','run-service-restart.py']:
 old=(A/name).read_text();new=(C/name).read_text();tree=ast.parse(new);main=next(x for x in tree.body if isinstance(x,ast.FunctionDef) and x.name=='main');fileassign=next(x for x in main.body if isinstance(x,ast.Assign) and any(isinstance(t,ast.Attribute) and t.attr=='__file__' for t in x.targets));line=ast.get_source_segment(new,fileassign);check(name+'_v2_only_file_context_delta',new.replace('    '+line+'\n','',1)==old)
 # Execute only actual ModuleType construction/file assignment/helper exec statements.
 ctor=next(x for x in main.body if isinstance(x,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='boundary' for t in x.targets));load=next(x for x in main.body if isinstance(x,ast.Expr) and isinstance(x.value,ast.Call) and isinstance(x.value.func,ast.Name) and x.value.func.id=='exec');ctx={'types':types,'CORRECTION':C,'ANCESTOR_CORRECTION':C};exec(compile(ast.Module(body=[ctor,fileassign,load],type_ignores=[]),'<selected-source-import>','exec'),ctx);check(name+'_actual_import_success_context',ctx['boundary'].CORRECTION==C and ctx['boundary'].PLAN==P and ctx['boundary'].__file__==str(C/'restart-boundary.py'))
 gate=next(x for x in main.body if (isinstance(x,ast.If) and 'restart_ancestor_correction_manifest_sha256' in ast.unparse(x.test)) or (isinstance(x,ast.Assert) and 'restart_ancestor_correction_manifest_sha256' in ast.unparse(x.test)))
 check(name+'_self_helper_seal_precedes_helper_exec',main.body.index(gate)<main.body.index(ctor)<main.body.index(fileassign)<main.body.index(load) and 'Path(__file__).absolute()' in new[:new.index('boundary = types.ModuleType')])
 cond=gate.test;expression=compile(ast.Expression(cond),'<selected-seal-condition>','eval');base={'digest':lambda p:'PUBLIC_EXACT_CORRECTION_SHA','manifest_path':C/'manifest.json','restart_manifest_path':C/'manifest.json'}
 for label,value,correct in [('matching','PUBLIC_EXACT_CORRECTION_SHA',True),('missing',None,False),('old','OLD_AD0B_SHA',False)]:
  truth=eval(expression,dict(base,grant={'restart_ancestor_correction_manifest_sha256':value}));check(name+'_correction_gate_'+label,truth is (correct if isinstance(gate,ast.Assert) else not correct))
 check(name+'_no_old_unsafe_receipt_writes',all(t not in new for t in ['OUT.parent.mkdir','OUT.mkdir(','safe_write(','write_text(json.dumps']))
 check(name+'_current_checks_before_launch_and_in_observer',new.rfind('cohort.assert_current()',0,new.index('result = guard.run_owned'))>new.index('cohort = boundary.CohortDirectory') and 'def observe():\n        cohort.assert_current()' in new)
# Public definitions only; metadata checks read no contents of DB/key/ENV.
ns={'__file__':str(C/'restart-boundary.py')};exec(compile((C/'restart-boundary.py').read_bytes(),'<public-corrected-boundary>','exec'),ns)
basefns={n.name:ast.dump(n,include_attributes=False) for n in ast.parse((P/'restart-boundary.py').read_text()).body if isinstance(n,ast.FunctionDef)};newfns={n.name:ast.dump(n,include_attributes=False) for n in ast.parse((C/'restart-boundary.py').read_text()).body if isinstance(n,ast.FunctionDef)}
check('six_original_grant_data_functions_AST_exact',all(basefns[n]==newfns[n] for n in ['regular','sha','validate_restart_fields','metadata','matching','verify_existing_data']))
fence=json.loads((P/'stopped-native-data-fence.safe.json').read_text());ns['verify_existing_data'](fence,True);check('actual156_stopped_metadata_preserved',len(fence['stopped_db_metadata_nodes'])==156)
anchors=json.loads((C/'runtime-ancestor-anchors.safe.json').read_text())['anchors'];check('actual_ancestor_metadata_pins_current',all(ns['dir_identity'](Path(r['path']).lstat(),r['uid'])=={k:v for k,v in r.items() if k!='path'} for r in anchors))
cohort=P/'runtime/restart-independent-control'
def info(mode,uid,ino,gid=1000,nlink=1,dev=27):return types.SimpleNamespace(st_mode=mode,st_uid=uid,st_gid=gid,st_dev=dev,st_ino=ino,st_nlink=nlink)
model={r['path']:info(stat.S_IFDIR|r['mode'],r['uid'],r['inode'],r['gid'],dev=r['device']) for r in anchors};model[str(P/'runtime')]=info(stat.S_IFDIR|0o700,1000,901);model[str(cohort)]=info(stat.S_IFDIR|0o700,1000,902)
class FakeOS:
 O_RDONLY=os.O_RDONLY;O_WRONLY=os.O_WRONLY;O_DIRECTORY=os.O_DIRECTORY;O_NOFOLLOW=os.O_NOFOLLOW;O_CLOEXEC=os.O_CLOEXEC;O_CREAT=os.O_CREAT
 def __init__(self,table,swap=None):self.table=copy.deepcopy(table);self.fds={};self.serial=10;self.events=[];self.swap=swap
 def getuid(self):return 1000
 def open(self,path,flags,mode=None,dir_fd=None):
  assert flags & os.O_NOFOLLOW and flags & os.O_CLOEXEC
  target=str(Path(self.fds[dir_fd][0])/path) if dir_fd is not None else str(path)
  assert dir_fd is not None or target=='/'
  if self.swap==target:self.table[target]=info(stat.S_IFDIR|0o700,1000,8888);self.swap=None
  row=self.table.get(target)
  if row is None:
   if not flags & os.O_CREAT:raise FileNotFoundError(target)
   assert mode==0o600;row=info(stat.S_IFREG|mode,1000,9900);self.table[target]=row;self.events.append('create_receipt')
  if stat.S_ISLNK(row.st_mode):raise OSError(errno.ELOOP,'synthetic nofollow')
  if flags & os.O_DIRECTORY and not stat.S_ISDIR(row.st_mode):raise OSError(errno.ENOTDIR,'synthetic directory')
  self.serial+=1;self.fds[self.serial]=(target,copy.copy(row));return self.serial
 def stat(self,name,dir_fd=None,follow_symlinks=True):
  assert dir_fd is not None and not follow_symlinks;target=str(Path(self.fds[dir_fd][0])/name)
  if target not in self.table:raise FileNotFoundError(target)
  return self.table[target]
 def fstat(self,fd):return self.fds[fd][1]
 def mkdir(self,name,mode,dir_fd=None):
  assert dir_fd is not None and mode==0o700;target=str(Path(self.fds[dir_fd][0])/name)
  if target in self.table:raise FileExistsError(target)
  self.table[target]=info(stat.S_IFDIR|mode,1000,10000+len(self.events));self.events.append('relative_unique_mkdir')
 def close(self,fd):self.fds.pop(fd)
 def ftruncate(self,fd,length):assert length==0;self.events.append('truncate')
 def fdopen(self,fd,mode):
  assert mode=='w';outer=self
  class Stream:
   def __enter__(self):return self
   def write(self,value):outer.events.append('write')
   def __exit__(self,*args):outer.close(fd)
  return Stream()
def run(name,table,expected=False,create=False,swap=None,mutate=None,receipt='current.safe.json'):
 fake=FakeOS(table,swap);ns['os']=fake;obj=None;accepted=False
 def lstat(path):
  if str(path) not in fake.table:raise FileNotFoundError(str(path))
  return fake.table[str(path)]
 with patch.object(Path,'lstat',lstat):
  try:
   obj=ns['CohortDirectory'](cohort,create=create)
   if mutate:mutate(fake,obj)
   obj.write_json(receipt,{'stage':'public'});accepted=True
  except (RuntimeError,OSError):pass
  finally:
   if obj:obj.close()
 check(name,accepted is expected and not fake.fds and (expected or 'write' not in fake.events and 'truncate' not in fake.events))
run('existing_owned_700_receipt_positive',model,True)
unique=copy.deepcopy(model);unique.pop(str(cohort));run('atomic_new_cohort_positive',unique,True,create=True);unique.pop(str(P/'runtime'));run('new_runtime_relative_creation_positive',unique,True,create=True);run('preexisting_cohort_denied_create',model,create=True)
for path in [str(P),str(P/'runtime'),str(cohort)]:
 for label,value in [('symlink',info(stat.S_IFLNK|0o777,1000,1)),('foreign',info(stat.S_IFDIR|0o700,999,1)),('not_dir',info(stat.S_IFREG|0o600,1000,1)),('writable',info(stat.S_IFDIR|0o777,1000,1))]:
  altered=copy.deepcopy(model);altered[path]=value;run(label+'_'+path.split('/')[-1],altered)
for path in [str(P),str(P/'runtime'),str(cohort)]:run('swapped_during_open_'+path.split('/')[-1],model,swap=path)
run('ancestor_replaced_before_write_denied',model,mutate=lambda f,o:f.table.__setitem__(str(P/'runtime'),info(stat.S_IFLNK|0o777,1000,4)))
# Ambiguity must fail; preserve all original descriptor references for cleanup.
run('ambiguous_identity_count_denied',model,mutate=lambda f,o:o.identities.pop())
for label,row in [('receipt_symlink',info(stat.S_IFLNK|0o777,1000,4)),('receipt_foreign',info(stat.S_IFREG|0o600,999,4)),('receipt_alias',info(stat.S_IFREG|0o600,1000,4,nlink=2)),('receipt_wrongmode',info(stat.S_IFREG|0o644,1000,4)),('receipt_notregular',info(stat.S_IFDIR|0o700,1000,4))]:
 altered=copy.deepcopy(model);altered[str(cohort/'current.safe.json')]=row;run(label,altered)
for name in ['../foreign.json','a/b.json','.hidden.json','a..b.json']:run('receipt_bad_basename_'+name,model,receipt=name)
launch=json.loads((C/'effective-launch-inputs.json').read_text());orig=json.loads((P/'effective-launch-inputs.json').read_text());check('unchanged_Docker_exact_argv',launch['docker_exact_argv']==orig['docker_exact_argv'])
for key,name in [('docker_guarded_command','docker-up-restart.py'),('mongo_server_command','run-mongo-restart.py'),('mongo_readiness_command','run-mongo-restart.py'),('host_command_schema','run-service-restart.py')]:
 expected=orig[key].copy();expected[1]=str(C/name);check('only_v2_command_'+key,launch[key]==expected)
check('new_grant_additional_correction_field','restart_ancestor_correction_manifest_sha256' in json.dumps(launch))
for n in ['run-mongo-restart.py','run-service-restart.py']:
 oldtree=ast.parse((P/n).read_text());newtree=ast.parse((C/n).read_text())
 for fn in (['exact_live_child','owned_private','exact_regular'] if n.startswith('run-mongo') else ['safe_owned']):
  get=lambda t:next(x for x in t.body if isinstance(x,ast.FunctionDef) and x.name==fn)
  check(n+'_preserved_'+fn,ast.dump(get(oldtree),include_attributes=False)==ast.dump(get(newtree),include_attributes=False))
(O/'checks.safe.json').write_text(json.dumps({'status':'PASS_SOURCE_ONLY','count':len(checks),'checks':checks,'private_ENV_key_data_contents_read':False,'data_metadata_nodes':156,'actual_links_foreign_writes_children_or_runtime':False,'same_UID_hard_isolation':False},indent=2)+'\n')
print(json.dumps({'checks':len(checks),'failed':0,'actual_links_foreign_writes_children_or_runtime':False}))
