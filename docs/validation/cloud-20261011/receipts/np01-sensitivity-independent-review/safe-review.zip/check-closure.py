"""Independent actual evidence closure: SAFE/source/metadata only, no native replay."""
import ast,hashlib,json,os,re,stat,subprocess,zipfile,datetime
from pathlib import Path
OWN=Path(__file__).resolve().parent
B=Path('/workspace/scratch/rct-validation')
O=B/'np01_broker_sensitivity_sourceprep';F=B/'np01_broker_sensitivity_caller_correction'
RED=F/'np01-fault-20261012-attempt01';G=B/'np01_broker_sensitivity_green_caller';N=B/'np01_broker_sensitivity_green_native'
W=Path('/workspace/rct-worktrees/np01-broker-sensitivity');ROOT=Path('/workspace/rutcampustrack')
checks=[];seals=[]
def check(name,value):
 assert value,name
 checks.append({'id':name,'passed':True})
def sha(p):
 h=hashlib.sha256()
 with p.open('rb')as f:
  while b:=f.read(32768):h.update(b)
 return h.hexdigest()
def save(n,x):
 with(OWN/n).open('x')as f:json.dump(x,f,indent=2);f.write('\n')
 (OWN/n).chmod(0o600)
def seal(path,m,z,expected_m,expected_z):
 if expected_m:check('manifest_'+str(path),sha(path/m)==expected_m)
 d=json.loads((path/m).read_text())
 names={x['path']for x in d['entries']}
 check('safe_unique_names_'+str(path),len(names)==len(d['entries'])and not any(x.startswith('/')or '..'in Path(x).parts or 'raw.private'in x or 'native.raw'in x for x in names))
 for x in d['entries']:
  s=(path/x['path']).lstat()
  check('sealed_member_'+str(path)+'/'+x['path'],stat.S_ISREG(s.st_mode)and stat.S_IMODE(s.st_mode)==0o600 and s.st_size==x['bytes']and sha(path/x['path'])==x['sha256'])
 if expected_z:check('archive_'+str(path),sha(path/z)==expected_z)
 with zipfile.ZipFile(path/z)as a:
  check('CRC_'+str(path),a.testzip()is None)
  check('zip_member_set_'+str(path),len(a.namelist())==len(names)+1 and set(a.namelist())==names|{m})
  for x in d['entries']:check('zip_digest_'+str(path)+'/'+x['path'],hashlib.sha256(a.read(x['path'])).hexdigest()==x['sha256'])
 seals.append({'path':str(path/m),'sha256':sha(path/m),'zip':str(path/z),'zip_sha256':sha(path/z),'entries':len(names),'CRC':True})
seal(N,'manifest.safe.json','safe-native-green-closure.zip','09dd9b0a71e944a85fe7ce2fab6dafc7e41517888f671e710ae7dfc0c8301b44','ce27f9a84902a6c7404e2406dbee68f95a198e87362945d8aaa429beb6a0e514')
seal(O,'manifest.safe.json','safe-sourceprep.zip','37a7a45b6567a5ea23190e8a61e1a443942a41c0e1ce985b3f8618e5134d2ee9','8384a33ae7cdaf43a7036d4fc0409cd96c412824ffab48c77834033c5771d313')
seal(F,'manifest.safe.json','safe-caller-correction.zip','e1fd1f85bbd7afa727a036f920a61701140f262fe0cd3dd58873cf98e32cc61c','075a2b77ee06a8e5d051aba98ca1348c08d62e4595052a93f2fb4a1b105da9cc')
seal(RED,'safe-fault-manifest.json','safe-native-fault-restoration.zip',None,'c41ae9bc1ce06735c7283ace40deda64f93d6429ceae848cf02ef4a564695695')
seal(G,'manifest.safe.json','safe-green-caller-source.zip','886c5ce8f68aa3aff26b71ce4425f88d9a60fe96eb02557c3eec18e998e5158e','baf78c4f8ca5c7f71aca66220fbc19cdb634c1df2b58c26a5ae79478cc92c765')
for path,msha,zsha in [(B/'np01_native_caller_review/correction_recheck','37d25c7b51cddd4450e91385e182658015d5550baed564e23245641fca364b3c','82b84fd0e342ff444467e602a3fb1cf826e40ed0af6b5963c68e9623bc858da2'),(B/'np01_native_caller_review/green_caller_review','524448438d9c2a1876bea0d58351923c9d591d97a72b7d22578ae10b59456b6e','101837addbe752aa59727b4885ffa316616dc3a0b24c510da612846a6aee3d0b')]:seal(path,'manifest.json','safe-review.zip',msha,zsha)
save('sealed-inputs.safe.json',{'seals':seals,'private_bodies_read':False,'native_replay':False})

red=json.loads((RED/'native-causal-red.safe.json').read_text());redterm=json.loads((RED/'terminal-process.safe.json').read_text());redclean=json.loads((RED/'post-fault-cleanup.safe.json').read_text());restore=json.loads((RED/'restoration.safe.json').read_text())
green=json.loads((N/'native-green-chronology.safe.json').read_text());gt=json.loads((N/'native-terminal.safe.json').read_text());gc=json.loads((N/'post-native-cleanup-before-volume-disposal.safe.json').read_text());pre=json.loads((N/'pre-native-docker-volume-inventory.safe.json').read_text());observer=json.loads((N/'observer-terminal.safe.json').read_text());post=json.loads((N/'post-green-source-capacity.safe.json').read_text());cl=json.loads((N/'actual-restored-class.safe.json').read_text())
case=red['selected_case'];gcase=green['native_green']['case'];gg=green['native_green']
method='actualProducerBrokerClaimAckRetryRestartAndDlqPreserveExactCards(Path)'
check('same_one_JUnit_method',case['name']==gcase['name']==method and case['classname']==gcase['classname'])
check('causal_RED_one_assertion',case['tests']==1 and case['failures']==1 and case['errors']==case['skipped']==0 and case['assertion_type']=='org.opentest4j.AssertionFailedError' and case['same_existing_child_exit_assertion']and case['expected_native_python_exit']==0 and case['actual_native_python_exit']==1)
marker='NP01_BR_T01 stage=np01_br_t01_new_foreign_removed_before_exact_card_assert qualified=false failures=1 workers_reaped=true'
check('RED_exact_unique_witness',case['safe_marker']==marker)
check('RED_not_infra',redterm['native_exit']==1 and redterm['terminal_reason']=='NATIVE_TERMINAL'and redterm['signal_count']==0 and redterm['supervision_error_type']is None and redterm['settled']and redterm['all_owned_processes_reaped']and not redterm['all_members_including_Z_after'])
check('RED_cleanup_before_restore',not redclean['container_ids_remaining']and not redclean['owned_births_remaining']and redclean['known_child_and_container_births_checked']==11 and len(redclean['observed_owned_container_ids'])==4 and all(x==0 for x in redclean['shared_bridge_endpoint_counts'].values())and not redclean['manual_cleanup_actions'])
check('GREEN_one_PASS',gcase['tests']==1 and gcase['failures']==gcase['errors']==gcase['skipped']==0 and gg['native_python_exit']==0 and gg['qualified'])
check('GREEN_native_clean_terminal',gt['native_exit']==0 and gt['terminal_reason']=='NATIVE_TERMINAL'and gt['signal_count']==0 and gt['supervision_error_type']is None and gt['phase_success']and gt['settled']and gt['all_owned_processes_reaped']and not gt['all_members_including_Z_after'])
summary=gg['closed_native_summary']
check('unchanged_default300_observed_bounds',gg['default_held_lease_seconds']==300 and 270000<summary['held_lease_initial_pttl_ms']<=300000 and summary['held_lease_elapsed_ms']>=summary['held_lease_initial_pttl_ms']-2000 and summary['held_lease_redeliveries']>=2 and summary['worker_restarts']==2)
parse=lambda x:datetime.datetime.fromisoformat(x.replace('Z','+00:00'))
times=green['chronology'];keys=['red_terminal_utc','red_cleanup_utc','exact_restore_utc','native_green_direct_child_start_utc_from_proc_birth','restored_class_mtime_utc','native_green_JUnit_producer_utc','native_green_XML_mtime_utc','native_green_terminal_utc','native_green_cleanup_utc']
check('strict_all_chronology',[parse(times[k])for k in keys]==sorted(parse(times[k])for k in keys)and len({parse(times[k])for k in keys})==len(keys))
check('old_RED_timestamps_bound',times['red_terminal_utc']==redterm['utc']==red['native_terminal_utc']and times['red_cleanup_utc']==redclean['utc']and times['exact_restore_utc']==restore['utc'])
check('new_GREEN_timestamps_bound',times['native_green_terminal_utc']==gt['utc']and times['native_green_cleanup_utc']==gc['utc']and times['restored_class_mtime_utc']==cl['new_class_mtime_utc'])
check('exact_new_classes_and_tasks',gg['restored_class_sha256']==cl['new_class_sha256']!=cl['previous_mutant_class_sha256']and gg['class_changed_from_mutant']and gg['compileTestJava_actually_executed']and gg['selected_integrationTest_actually_executed'])
check('actual_selected_tasks_not_UPTODATE',gg['native_tasks'].count('> Task :services:academic-service:academic-app:compileTestJava')==1 and gg['native_tasks'].count('> Task :services:academic-service:academic-app:integrationTest')==1)
check('native_build44_2executed_not_global_rerun','44 actionable tasks: 2 executed, 42 up-to-date'in gg['native_build_markers']and 'BUILD SUCCESSFUL in 7m 50s'in gg['native_build_markers'])

frames=[json.loads(line)for line in(N/'docker-native-observations.safe.ndjson').read_text().splitlines()]
samples=[f for f in frames if'container_ids'in f];cf=[f for f in frames if'container'in f]
captured={f['container']['id']:f['container']for f in cf}
check('observer_exact4_identity_capture',len(captured)==4 and set(captured)==set(observer['captured_container_ids'])==set(gc['captured_containers']))
check('observer_no_errors_and_settlement',observer['snapshots']==len(samples)==73 and not observer['errors']and observer['native_terminal_observed']and not samples[-1]['container_ids']and samples[-1]['terminal_exists'])
check('captured_container_metadata_matches_cleanup_receipt',captured==gc['captured_containers'])
data=[c for c in captured.values()if c['owner']];ryuk=[c for c in captured.values()if c['image'].startswith('testcontainers/ryuk:')]
check('data_exactimages_owner_session',len(data)==3 and {c['image']for c in data}=={'postgres:16-alpine','rabbitmq:3.13-management-alpine','redis:7-alpine'}and len({c['owner']for c in data})==1 and len({c['session']for c in data})==1 and all(c['testcontainers']=='true'for c in data))
session=data[0]['session']
check('Ryuk_exact_session_name',len(ryuk)==1 and ryuk[0]['name']=='/testcontainers-ryuk-'+session and ryuk[0]['testcontainers']=='true')
check('data_loopback_all_exposed_ports',all(v['HostIp']=='127.0.0.1'for c in data for values in c['ports'].values()if values for v in values))
check('cleanup_exact14_births',len({(x['pid'],x['start_ticks'])for x in gt['known_owned_identities']}|{(c['host_pid'],c['host_process_birth'])for c in captured.values()}|{(observer['observer_pid'],observer['observer_birth'])})==gc['known_native_container_observer_births_checked']==14 and not gc['owned_births_remaining'])
check('cleanup_allIDs_bridge_endpoints',not gc['docker_ids_remaining']and all(x==0 for x in gc['shared_bridge_endpoint_counts'].values())and not gc['manual_container_cleanup'])
vols={m['name']for c in data for m in c['mounts']if m['type']=='volume'}
check('new3_volumes_exact_bound_and_distinct_old11',len(vols)==3 and vols==set(gc['exact_new3_own_mount_bound_volume_names'])and not vols&set(pre['volume_names'])and len(pre['volumes'])==len(pre['volume_names'])==11 and not pre['docker_container_ids'])
check('old11_metadata_retention_and_own3_native_absence',gc['preexisting_11_volume_metadata_unchanged']and gc['original5_named_volumes_present_unchanged']and gc['preexisting6anonymous_volumes_not_deleted']and not gc['new_own_volume_metadata']and not gc['new_volume_names_not_own']and not gc['volume_disposal_actions_yet']and green['cleanup']['exact_new3_owned_volumes_absent_after_native_finally'])
minfree=min(s['workspace_available_bytes']for s in samples);maxshared=max(s['shared_memory_bytes']for s in samples)
check('recorded_sample_extrema_exact',minfree==green['resource_qualification']['observed_sample_min_workspace_bytes']and maxshared==green['resource_qualification']['observed_sample_max_shared_memory_bytes'])
check('sampled_cohort_limits_qualify_not_peak',minfree>4*1024**3 and post['Root_explicit_fresh_green_cohort_workspace_initial_bytes']-minfree<2*1024**3 and maxshared-post['Root_explicit_fresh_green_cohort_shared_initial_bytes']<4*1024**3 and maxshared<15*1024**3 and gt['peak_owned_rss_bytes']<4*1024**3)

ledger=json.loads((O/'complete-sparse-baseline.safe.json').read_text());protected={'.env.prod.example','services/notification-bot/.env.example','services/notification-service/notification-app/src/test/resources/test-public.pem'}
env={'PATH':'/usr/local/bin:/usr/bin:/bin','LANG':'C.UTF-8','LC_ALL':'C.UTF-8','GIT_OPTIONAL_LOCKS':'0'}
git=lambda *a:subprocess.check_output(['git','-C',str(W),*a],env=env,stderr=subprocess.DEVNULL,timeout=15)
check('actual_current_EB_HEAD',git('rev-parse','HEAD').strip().decode()==green['producer_base']==ledger['base'])
index=git('ls-files','--stage','-z');check('actual_index_scope',hashlib.sha256(index).hexdigest()==post['logical_index_sha256'])
indexed=[x.split(b'\t',1)[1].decode()for x in index.split(b'\0')if x];present=[x for x in indexed if os.path.lexists(W/x)]
check('current_populated1945_exact',len(present)==1945 and set(present)=={x['path']for x in ledger['entries']})
check('current_nonignored_untracked_empty',not git('ls-files','--others','--exclude-standard','-z'))
bodycount=0
for row in ledger['entries']:
 p=W/row['path'];s=p.lstat()
 check('current_source_metadata_'+row['path'],stat.S_ISREG(s.st_mode)and stat.S_IMODE(s.st_mode)==0o600 and s.st_nlink==1 and s.st_uid==os.getuid()and s.st_size==row['bytes']and not any(a.is_symlink()for a in p.parents))
 if row['path']in protected:continue
 check('current_BASE_body_'+row['path'],sha(p)==row['sha256']);bodycount+=1
check('current1942_body_only',bodycount==1942)
for name,expected in green['normal2_SOURCE'].items():check('Root_and_WT_normal2_'+name,sha(ROOT/name)==sha(W/name)==expected==post['normal2_hashes'][name]==post['Root_normal2_hashes'][name])
klass=W/'services/academic-service/academic-app/build/classes/java/test/ru/rutcampustrack/academic/botcredentials/BotCredentialBrokerBridgeIT.class'
check('actual_normal_class_hash_fresh',sha(klass)==cl['new_class_sha256'])
check('actual_class_mtime_fresh',abs(klass.stat().st_mtime-parse(times['restored_class_mtime_utc']).timestamp())<0.00001)
# Private XML is deliberately metadata-only in this assignment. No hash/body read.
originalxml=W/'services/academic-service/academic-app/build/test-results/integrationTest/TEST-ru.rutcampustrack.academic.botcredentials.BotCredentialBrokerBridgeIT.xml'
copiedxml=N/'native-green-junit.raw.private.xml';private_meta=[]
for path in [originalxml,copiedxml,RED/'native-junit.raw.private.xml']:
 s=path.lstat();check('private_XML_metadata_only_'+str(path),stat.S_ISREG(s.st_mode)and stat.S_IMODE(s.st_mode)==0o600 and s.st_nlink==1 and s.st_uid==os.getuid())
 private_meta.append({'path':str(path),'bytes':s.st_size,'mtime_ns':s.st_mtime_ns,'mode':'0600','body_or_fresh_hash_read':False})
check('fresh_original_XML_mtime',abs(originalxml.stat().st_mtime-parse(times['native_green_XML_mtime_utc']).timestamp())<0.00001)
check('normal_XML_copy_size_match',originalxml.stat().st_size==copiedxml.stat().st_size==green['raw_private_artifacts']['normal_XML']['bytes'])

plan=json.loads((B/'np01_broker_sensitivity_plan_correction_canonical/PLAN.safe.json').read_text())
py=(W/plan['fault']['path']).read_text();j=(W/plan['diagnostic']['path']).read_text();anchor=plan['fault']['original_anchor'];line='            require_exact_card(provider.cards, new_foreign_key, new_foreign_text)\n';replacement=anchor[:-len(line)]+plan['fault']['insert']+line
check('canonical_py_mutant_exact',py.count(anchor)==1 and hashlib.sha256(py.replace(anchor,replacement,1).encode()).hexdigest()=='a77a873948fd3108fd52acb7c90c2610c4a70495126ebad0eba19ca7b669ef52')
diag=plan['diagnostic']['proposed_statement'];check('canonical_Java_diag_mutant_exact',j.count(plan['diagnostic']['original'])==1 and hashlib.sha256(j.replace(plan['diagnostic']['original'],diag,1).encode()).hexdigest()=='defa0228ebf2d582b19c96c6b0b403f4fc122e7b7d8ec70e30fad33c6190f164')
check('Java_expectation_never_weakened',diag.startswith('assertThat(child.exitValue())')and diag.rstrip().endswith('.isZero();')and 'assertThat(child.exitValue()).isZero();'in j)
t=ast.parse(py);helper=next(x for x in t.body if isinstance(x,ast.FunctionDef)and x.name=='require_exact_card')
check('actual_exact_key_fulltext_oracle',ast.dump(helper.body[-1],include_attributes=False)==ast.dump(ast.parse('check(key in cards and cards[key] == text)').body[0],include_attributes=False))
check('normal_no_fault_stage_or_delete',plan['fault']['expected_unique_stage']not in py and plan['fault']['expected_unique_stage']not in j)
check('unchanged_default_and_elapsed_oracles','check(BotIdempotencyGuard.DEFAULT_TTL_SECONDS == 300)'in py and 'check(_held_lease_elapsed_ms >= held_pttl - 2_000)'in py and 'assertThat(heldPttl).isGreaterThan(270_000).isLessThanOrEqualTo(300_000)'in j)
save('critical-source-causality.safe.json',{'normal2':green['normal2_SOURCE'],'canonical_py_mutant_hash_reconstructed_exact':True,'canonical_Java_mutant_hash_reconstructed_exact':True,'mutant_bodies_written':False,'unchanged_key_plus_fulltext_oracle':True,'same_original_Java_zero_exit_expectation':True,'sourcequality_scope':'NEW foreign card preservation under old original-UID cleanup/rebinding; not all causes of loss/earlyACK or product family.'})
save('finite-native-readback.safe.json',{'red':{'case':case,'native_exit':1,'cleanup_births':11},'green':{'case':gcase,'summary':summary,'native_exit':0,'class_sha256':cl['new_class_sha256'],'cleanup_births':14},'chronology':times,'captured_container_ids':sorted(captured),'exact_new3_volume_names':sorted(vols),'old11_volume_metadata_retention':'SEALED_PRODUCER_ASSERTION_WITH_COMPLETE_PREINVENTORY','samples':{'count':len(samples),'min_workspace':minfree,'max_shared_memory':maxshared,'qualification':'5second samples and periodic b78 soft observer; not exact peaks or hard cgroup enforcement.'},'private_XML_metadata_only':private_meta,'source_metadata_count':1945,'fresh_BASE_body_hashes':bodycount,'protected3_body_reads':False,'reviewer_native_replay':False,'limits':['Three data containers bound loopback; Ryuk published wildcard ephemeral port/session-bound name, so no all-container loopback isolation claim.','NativeMongo/key bodies untouched by owner are an attestation; this review never reads data/key contents.','No rawprivateXML/stdout/grant/nonce reads; native XML details rely on exact sealed SAFE extraction, not reviewer raw parsing.','Old11 after-metadata equality is recorded by sealed producer; no Docker/native reobservation performed.']})
save('independent-checks.safe.json',{'verdict':'APPROVE_FINITE_EVIDENCE','checks':checks,'count':len(checks),'source_only_reviewer':True,'runtime_or_native_replay':False,'private_XML_stdout_grant_nonce_reads':False,'protected3_body_reads':False,'whole_product_acceptance':'NOT_ASSESSED','parent_family_promotions':0})
print(json.dumps({'verdict':'APPROVE_FINITE_EVIDENCE','checks':len(checks),'same_native_case':'RED_THEN_GREEN','source_metadata':1945,'BASE_body_hashes':1942,'private_XML_bodies_read':False,'reviewer_native_replay':False}))
