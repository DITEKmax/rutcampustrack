"""Pure exact-AST ownership counterexamples: no processes or signals created."""
import ast
import copy
import hashlib
import json
from pathlib import Path

OWN=Path(__file__).parent
OLD=Path('/workspace/scratch/rct-validation/current_artifact_corrections/bounded-child.py')
NEW=OWN/'bounded-child.py'


def functions(path,names):
    tree=ast.parse(path.read_text())
    body=[node for node in tree.body if isinstance(node,ast.FunctionDef) and node.name in names]
    namespace={}
    exec(compile(ast.Module(body=body,type_ignores=[]),str(path),'exec'),namespace)
    return namespace


old=functions(OLD,{'owned_records'})['owned_records']
new=functions(NEW,{'owned_records','remember_identities'})
parent,group=200,100
known={100:10}
foreign={100:{'pid':100,'state':'S','ppid':999,'pgrp':100,'session':100,'start_ticks':20}}
before=old(copy.deepcopy(foreign),parent,group,copy.deepcopy(known))
assert list(before)==[100]
after=new['owned_records'](copy.deepcopy(foreign),parent,group,known)
assert after=={} and known=={100:10}
# Unknown foreign member of the same numeric group is also inadmissible.
unknown={101:{'pid':101,'state':'S','ppid':999,'pgrp':100,'session':100,'start_ticks':21}}
assert new['owned_records'](unknown,parent,group,known)=={}
# Neither direct-parent likeness nor ancestry can redeem a changed birth tick.
direct_mismatch={100:{**foreign[100],'ppid':parent}}
assert new['owned_records'](direct_mismatch,parent,group,known)=={}
owned={100:{'pid':100,'state':'S','ppid':parent,'pgrp':100,'session':100,'start_ticks':10},
       300:{'pid':300,'state':'S','ppid':100,'pgrp':300,'session':300,'start_ticks':12},
       400:{'pid':400,'state':'Z','ppid':parent,'pgrp':400,'session':400,'start_ticks':15},
       500:{'pid':500,'state':'S','ppid':400,'pgrp':500,'session':500,'start_ticks':16},
       101:unknown[101]}
selected=new['owned_records'](owned,parent,group,known)
assert set(selected)=={100,300,400,500}
new['remember_identities'](selected,known)
assert known=={100:10,300:12,400:15,500:16}
recorded_after_exit={300:{**owned[300],'ppid':parent},400:owned[400]}
assert set(new['owned_records'](recorded_after_exit,parent,group,known))=={300,400}
snapshot=known.copy()
try:new['remember_identities']({100:foreign[100]},known)
except RuntimeError:pass
else:raise AssertionError('known birth overwritten')
assert known==snapshot
# A changed known descendant must not become an ancestry anchor for outsiders.
poisoned={300:{**owned[300],'start_ticks':22,'ppid':999},
          600:{'pid':600,'state':'S','ppid':300,'pgrp':100,'session':100,'start_ticks':23}}
assert new['owned_records'](poisoned,parent,group,known)=={}
r={'native_exit':0,'kind':'PURE_ACTUAL_AST_NO_PROCESS_OR_SIGNAL',
   'old_helper_SHA':hashlib.sha256(OLD.read_bytes()).hexdigest(),'new_helper_SHA':hashlib.sha256(NEW.read_bytes()).hexdigest(),
   'old_exact_reviewer_foreign_chosen':before,'new_foreign_result':after,
   'unknown_numeric_group_foreign_rejected':True,'known_birth_mismatch_denied_even_direct_parent':True,
   'known_identity_never_overwritten':True,'changed_ancestor_doesnot_admit_foreign_child':True,
   'owned_positive_direct_ancestry_escaped_adopted_Z':[100,300,400,500],
   'original_reviewed_source_unchanged':True,'actual_PID_reuse_or_wrong_signal':'NOT_RUN'}
(OWN/'ownership-controls-result.json').write_text(json.dumps(r,indent=2)+'\n')
print(json.dumps({'native_exit':0,'old_foreign_admission_proved':True,'new_foreign_rejected_nooverwrite':True,'owned_escaped_adopted_Z_retained':True,'actual_processes_or_signals':0}))
