"""Selected old/new identity expressions against synthetic metadata only."""
import ast
import hashlib
import json
from pathlib import Path

OWN = Path(__file__).parent
BASE = OWN.parent / 'current_host_config_v5'
REDIRECT = OWN.parent / 'current_host_config_v5_redirect_query_correction'

def selected_old(record, table):
    tree = ast.parse((BASE / 'run-mongo.py').read_text())
    node = next(n for n in ast.walk(tree) if isinstance(n, ast.Assign)
                and any(isinstance(t, ast.Name) and t.id == 'owned' for t in n.targets))
    return bool(eval(compile(ast.Expression(node.value), str(BASE / 'run-mongo.py'), 'eval'),
                     {'record': record, 'table': table}))

def main():
    tree = ast.parse((OWN / 'run-mongo.py').read_text())
    helper = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == 'exact_live_child')
    gate = next(n for n in ast.walk(tree) if isinstance(n, ast.If)
                and isinstance(n.test, ast.BoolOp) and any(isinstance(c, ast.UnaryOp)
                and isinstance(c.operand, ast.Call) and isinstance(c.operand.func, ast.Name)
                and c.operand.func.id == 'exact_live_child' for c in n.test.values))
    assert isinstance(gate.test.values[0], ast.UnaryOp)
    scope = {}
    exec(compile(ast.Module(body=[helper], type_ignores=[]), str(OWN / 'run-mongo.py'), 'exec'), scope)
    child = {'pid': 100, 'start_ticks': 10, 'state': 'S'}
    descendant = {'pid': 101, 'start_ticks': 11, 'state': 'S'}
    record = {'child_pid': 100, 'members_including_Z': [child, descendant]}
    cases = [
        ('exact_child_live', record, {100: child, 101: descendant}, True),
        ('child_absent_descendant_live', record, {101: descendant}, False),
        ('child_reused_descendant_live', record, {100: dict(child, start_ticks=20), 101: descendant}, False),
        ('child_Z_descendant_live', record, {100: dict(child, state='Z'), 101: descendant}, False),
        ('child_X_descendant_live', record, {100: dict(child, state='X'), 101: descendant}, False),
        ('all_absent', record, {}, False),
        ('missing_recorded_child', dict(record, members_including_Z=[descendant]), {100: child, 101: descendant}, False),
        ('ambiguous_child_records', dict(record, members_including_Z=[child, dict(child, start_ticks=20), descendant]), {100: child, 101: descendant}, False),
        ('missing_child_pid', {'members_including_Z': [child, descendant]}, {100: child, 101: descendant}, False),
        ('exact_child_only_live', {'child_pid': 100, 'members_including_Z': [child]}, {100: child}, True),
        ('exact_child_T_live', record, {100: dict(child, state='T'), 101: descendant}, True),
        ('exact_child_D_live', record, {100: dict(child, state='D'), 101: descendant}, True),
    ]
    results = []
    for name, rec, table, expected in cases:
        old = selected_old(rec, table)
        actual = scope['exact_live_child'](rec, table)
        selected_reject = eval(compile(ast.Expression(gate.test.values[0]), str(OWN / 'run-mongo.py'), 'eval'),
                               dict(scope, record=rec, table=table))
        assert actual is expected and selected_reject is (not expected)
        results.append({'name': name, 'old_accepts': old, 'new_accepts': actual, 'expected': expected,
                        'selected_main_gate_rejects': selected_reject})
    preserved = []
    for root, manifest_name in [(BASE, 'launch-manifest.json'), (REDIRECT, 'manifest.json')]:
        manifest = json.loads((root / manifest_name).read_text())
        intact = all(hashlib.sha256(Path(row['path']).read_bytes()).hexdigest() == row['sha256'] for row in manifest['files'])
        assert intact
        preserved.append({'root': str(root), 'all_sealed_files_unchanged': intact})
    result = {'status': 'PASS_SOURCE_ONLY', 'cases': results, 'preserved': preserved,
              'synthetic_metadata_only': True, 'real_pid_reuse_signal_server_port': False,
              'private_inputs_read_or_changed': False, 'guard_changed': False, 'auth_replica_data_policy_changed': False}
    (OWN / 'validation.safe.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({'selected_controls': len(results), 'green_new': True,
                      'old_counterexamples': sum(r['old_accepts'] != r['expected'] for r in results), 'real_processes': 0}))

if __name__ == '__main__':
    main()
