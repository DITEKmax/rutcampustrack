# cf067 narrow recheck — APPROVE_SOURCE

Frozen correction `cf067a008d732ca77f385a3eb1f53e0a79234687` поверх original `8fe9fe946ded3174796778b33f84385c6f98473b`: четыре изменённых NEW paths, семь NEW paths всего. Reviewer independent/read-only, requested/selected Sol6.1/xhigh, actual metadata UNKNOWN. Blocking source findings отсутствуют. CRA-EXPORT-T01 и CRA-VIEWPORT-T02 закрыты на уровне source и соответствующих pure/source-registration controls. Этот результат разрешает Root source integration; actual14 browser acceptance требует отдельного текущего stand/grant.

Исходный original8fe CHANGES_REQUESTED review сохраняется immutable. Автор, другой от reviewer, исправил только NEW tests/harness. Продукт, API/schema/locks, старые fixtures и Angular не изменены. Чужой default config hunk 1b4d остаётся единственным unstaged existing read context, с исходным SHA; он имеет отдельного writer.

## CRA-EXPORT-T01 — CLOSED_SOURCE_AND_PURE_ORACLE_CONTROLS

Полностью прочитаны текущие `tests/e2e/fixtures/cloud-accepted-support.ts#registryHtmlBoundary` и `tests/e2e/specs/cloud-accepted-registry-export.spec.ts`. Новый тест создаёт known-nonmatching STUDENT в другой группе и target STUDENT+TEACHER с подтверждёнными ACTIVE grants, непустыми group/staff, связанной Telegram identity. FIO/login и реальные ожидаемые group/staff/binding значения поступают в oracle в памяти. Ожидания не копируются из скачанного HTML.

Оракул разбирает саму таблицу: ровно одно table opening, закрытая thead/tbody структура, шесть headers FULL/LIMITED common и только FULL седьмой Telegram ID, ровно одна body row, точное число и значения ячеек, отсутствие known-other login/displayName. Все assertions используют booleans. Existing doctype/MIME, password/recovery/TG negatives, actual future download/job/ticket, foreign actor и live revoke paths сохранены.

Независимо заново открыты actual current `AdminRegistryExportService.users`, `RegistryTableRenderer.html/xml` и `UserRoleGrantReader`: принятые D006/D007 headers и порядок, scoped query.search, роли/статусы из durable grants, group label, staff, binding и пять XML escapes соответствуют oracle. Grant reader сортирует по user/grant id; созданный STUDENT предшествует добавленному TEACHER. Это проверка accepted observable schema/данных, не утверждение о выполнении Java/DB/renderer.

Лично прочитаны AST-extraction probe и sealed actual controls/exit/log. 20 native source controls привязаны к точному current support SHA: два positives проходят; ignored-filter×2 падают на oneRow и knownNonmatchAbsent; ordinary-column-omission×8 — на columnsExact; ordinary-value-corruption×8 — на valuesExact. Те же 18 bad bodies проходили точные семь original8fe body expressions. Recheck валидировал каждый конкретный intended rejection, не только итоговый счётчик. Author probe attempt1 ошибочно выбрал MIME expression и завершился до oracle; corrected AST identifier selection/attempt2 и table-opening hardening/attempt3 квалифицированы. Старый false-green evidence не переписан.

Это реально исполненные автором harmless source-oracle controls над контролируемым HTML в памяти; реальные Vue/HTTP/export bytes/audit/browser/product mutation NOT_RUN. Reviewer не повторял все20 и не исполнял author script, пишущий author receipts. Существующий independent original counterexample и новый source/control proof достаточны для узкой correction.

## CRA-VIEWPORT-T02 — CLOSED_SOURCE_AND_ACTUAL_SOURCE_DISCOVERY

Полностью прочитан current NEW `cloud-accepted-playwright.ts`. Те же Chromium/WebKit projects теперь map после filter, сохраняют project/browser properties и задают `use.viewport=390×844` после `...project.use`. Текущий actual Playwright vendor merge `mergeObjects(config.use,projectConfig.use,CLIuse)` и overwrite logic независимо прочитаны; исправление стоит на правильном уровне.

Лично открыты/валидированы native safe --list before/after originals. Both project effective viewport1280×720→390×844; по14 registrations на проект, всего28/5spec files/errors0. Every suite chain имеет exactly1 afterEach; trace/video/screenshot off. Before run использовал original8fe config с current other3 WIP, что не влияет на merge use; это явно source-config receipt, не whole8fe runtime. Native layout/browser capability NOT_RUN.

## TMA date controls — достаточная source qualification

Каждый из пяти finite date negatives теперь сначала открывает отдельную page на том же origin/teacher identity/signing fixture, требует actual будущий POST/tma200, teacher owner и refresh cookie, закрывает control page и очищает только собственный browser context. Затем на основной page устанавливает отдельный signed bad-date host и требует401, `tma-validation-failed` type и branch-specific fixed detail. Initial date-parser slices ждут `Invalid auth_date in initData`; future/expired ждут `initData expired or not yet valid`. Role/navigation/cookie/refresh401 negatives сохранены; unlink/reuse case не ослаблен.

Заново открыт actual `TmaService`: HMAC guard предшествует parser/window и имеет другую fixed detail; date conditions совпадают с пятью ожиданиями. Current TMA validation advice/type был независимо прочитан original и byte-exact reused. Current `tma-session.ts` хранит bearer/profile только in-memory; `tma-auth.ts` отправляет реальные initData на Auth, App bootstrap сначала authenticateFor, потом profile. Separate control page не оставляет bearer/initData в persisted session owner основной страницы. Telegram host shim остаётся существующим external JS adapter; API не mocked.

Лично прочитаны source AST response-predicate probe и sealed native controls. Для каждой из пяти slices matching date problem принимается, wrong-HMAC detail отвергается именно detail predicate, unrelated401 problem — type predicate. Source SHA совпадает с frozen TMA spec. Эти пять matching/пять wrong-HMAC/пять unrelated401 controls не являются actual response receipts или native Telegram proof.

Prepared-v3 signer mismatch из original review не объявлен runtime закрытым. Root NEWv4 synthetic target/signer/clock alignment отдельно проверяет ci731; reviewer не читал private ENV/key values. Valid-before-negative controls обеспечат meaningful prerequisite failure на реальном пути, если live target по-прежнему несовместим. Source correction одобрена независимо от ещё отсутствующего stand readiness.

## Preservation и проверка receipts

Correction ZIP SHA256 `d1c1aaf8cb9540620c97e8e7fcdaefd2a38439c864d03048d27614fdd2fcc81f`,71849 bytes: независимо проверены45 members/unique safe paths/CRC/all bytes/SHA. Все семь actual worktree files равны frozen cf067 Git blobs и archive members; exact diff8fe→cf067 содержит лишь четыре разрешённых NEW paths. Три остальных spec files byte-exact reuse. Original independent10 receipts/manifest/ZIP и два original author ZIP сохранили bytes/SHA. Авторский WIP/Root docs не редактировались reviewer.

Лично открыты и проверены final actual type/format/list/native-oracle exit files/logs. TypeScript5.9.3 strict inherited E2E NodeNext/options неизменны относительно original sealed tsconfig; final Type+format exits0 и четыре checked source hashes совпадают с cf067. Default57/new0/old-mobile-optin0 остаётся прежним source discovery на exact1b4 и неизменных default-loaded inputs: excluded NEW files там не загружаются, повтор/новая runtime квалификация не изобретены. Ранее принятые28 public critical source refs повторно совпали по SHA/bytes; full broader review не дублировался.

Shared registerPrivateSuite и signedAuthDate тела byte-exact original; each of5 NEW specs имеет ровно один hook call. Reporter остаётся canonical safe runtime reporter; scratch discovery reporter экспортирует только allowlisted source/project/config/count/location metadata и отвергает test execution. Pure probes сохраняют booleans/source hashes, без raw HTML/credentials/identity/proof/cookie/body. Actual credential-bearing artifact/download/context cleanup PASS всё ещё требует реального запуска.

Reviewer actually executed только harmless Python ZIP/Git/hash/source-bridge/receipt checks; new Node/type/list/browser/server/API/DB/JVM/Gradle/Docker/network/signals/keys/children не запускались. Full current Root contract/state восстановлен; exact governing text был полностью лично прочитан в предыдущем review turn и full-byte SHA reread подтвердил неизменность, изменённые CURRENT/resources прочитаны полностью. Requested effort не выдаётся за measured actual.

## Следующая проверка

Root может интегрировать exact семь reviewed NEW files с отдельно принадлежащим formatter default-ignore hunk. До actual14 нужны reviewed current synthetic v4/TLS/clock/signer/artifact/source/resource readiness и отдельный runtime grant. На реальном finite Chromium/WebKit пути проверять новую таблицу, rendered mobile layout и TMA valid-before-negative; сохранять sanitized failure evidence и cleanup.

Source controls закрывают конкретные defects оракула. Для accepted critical behavior остаётся original narrow sensitivity plan: релевантный controlled date-age bypass должен показать ошибочный admission, выбранный revoked-grant bypass — ошибочную mutation/no-effect, download live-admission bypass — retained-capability exposure. Каждую mutation выполнять только отдельным authorized runtime owner в изолированном current source/данных и восстановить green. Не требуется repeat всех pure20, полный исторический backend suite или blanket campaign по всем stories.

Ни одна из11 CLIENT groups, пять export-format byte paths, audit DB, offline policy, native Telegram/Safari/device или full product acceptance этим source verdict не становится PASS. Source approval не исправляет отдельные current Root formatting/CI failures и не заменяет текущие runtime receipts.

Created own NEW correction_recheck only: CURRENT.json, attempts.ndjson, source-and-preservation.safe.json, native-source-receipts.safe.json, critical-source-reuse.safe.json, findings.safe.json, REPORT.md, HANDOFF.md и отдельные immutable manifest/ZIP/seal. Product/author/Root/original-review writes:0; deleted:0; retained processes/children:0.
