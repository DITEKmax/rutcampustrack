import pathlib,json,csv,hashlib,subprocess,re,datetime,collections
p=pathlib.Path('/workspace/scratch/rct-validation/current_server_acceptance_qualification')
root=pathlib.Path('/workspace/rutcampustrack');docs=root/'docs/validation/cloud-20261011'
native=pathlib.Path('/workspace/scratch/rct-validation/ci_e58_receipts')
partial=json.loads((p/'partial-proposals.json').read_text())
rows=partial['rows']+json.loads((p/'extended-proposals.json').read_text())['rows']
families={r['id']:r for r in csv.DictReader((docs/'scenarios.csv').open())}
bounds={r['id']:r for r in csv.DictReader((docs/'boundary-scenarios.csv').open())}
existing=list(csv.DictReader((docs/'verified-cases.csv').open()))
existing_ids={r['id'] for r in existing}
meta=json.loads((native/'metadata-final.json').read_text())
arts={a['name']:a for r in meta['runs'] for a in r['artifacts']}
collectors=[]
for f in sorted(native.glob('safe*.json')):
 d=json.loads(f.read_text())
 if 'cases' in d:
  task=d['metadata']['task'];service=d['metadata']['service']
  name='safe-'+('unit' if task=='test' else 'integration')+'-outcomes-'+service+'-1'
  collectors.append((f.name,d,arts[name]))
def method_block(text,name):
 lines=text.splitlines()
 found=[i for i,s in enumerate(lines) if re.search(r'\bvoid\s+'+re.escape(name)+r'\s*\(',s)]
 if len(found)!=1:return None
 start=found[0];depth=0;opened=False
 for end in range(start,len(lines)):
  opened |= '{' in lines[end];depth+=lines[end].count('{')-lines[end].count('}')
  if opened and depth==0 and end>=start:return {'start_line':start+1,'end_line':end+1,'text':'\n'.join(lines[start:end+1])}
 return None
source_cache={};proofs=[];csvrows=[];qualities=[]
def canonical_refs(value):
 try:
  parsed=json.loads(value)
 except json.JSONDecodeError:
  return [value] if value else []
 assert isinstance(parsed,list) and all(isinstance(x,str) for x in parsed)
 return parsed
for row in rows:
 assert row['id'] not in existing_ids
 for family in row['families']:assert family in families,(row['id'],family)
 for boundary in row['boundaries']:assert boundary in bounds,(row['id'],boundary)
 evidence=[];testfiles=[]
 for method in row['methods']:
  matches=[]
  for fname,d,a in collectors:
   for c in d['cases']:
    if c.get('method')==method and (c.get('classname') or '').split('.')[-1] in row['classes']:matches.append((fname,d,a,c))
  assert len(matches)==1,(row['id'],method,len(matches))
  fname,d,a,c=matches[0];assert c['status']=='PASSED' and c['identity']=='SOURCE_METHOD'
  path=c['source'];data=(root/path).read_bytes();sha=hashlib.sha256(data).hexdigest();assert sha==c['sourceSha256'],path
  block=method_block(data.decode(),method);assert block
  before=subprocess.run(['git','--no-optional-locks','-C',str(root),'show','3908fad9624f97aec8891fc79338ceb6b0616bf3:'+path],stdout=subprocess.PIPE,stderr=subprocess.DEVNULL)
  baseline=method_block(before.stdout.decode(),method) if before.returncode==0 else None
  unchanged=baseline is not None and block['text']==baseline['text']
  quality={'row':row['id'],'method':method,'baseline_method_present':baseline is not None,'baseline_method_byte_equal':unchanged,'quality':'UNCHANGED_BASELINE_ASSERTION_BODY' if unchanged else 'NEW_OR_CHANGED_METHOD_SENSITIVITY_REQUIRES_EXACT_EXISTING_RECEIPT_OR_SELECTIVE_CHECK'}
  qualities.append(quality)
  xml=next(x for x in d['xml'] if x['ordinal']==c['xmlOrdinal'])
  item={'producer':partial['native_producer'],'checkout':partial['native_checkout'],'run_id':int(d['metadata']['runId']),'run_attempt':int(d['metadata']['runAttempt']),'event':d['metadata']['event'],'artifact_id':a['id'],'artifact_digest':a['digest'],'safe_collector':fname,'safe_collector_sha256':hashlib.sha256((native/fname).read_bytes()).hexdigest(),'xml_sha256':xml['sha256'],'classname':c['classname'],'method':method,'status':'PASSED','identity':c['identity'],'xml_ordinal':c['xmlOrdinal'],'suite_ordinal':c['suiteOrdinal'],'case_ordinal':c['ordinal'],'source':path,'source_sha256':sha,'start_line':block['start_line'],'end_line':block['end_line'],'method_sha256':hashlib.sha256(block['text'].encode()).hexdigest(),'current_test_byte_equals_producer':True}
  evidence.append(item);testfiles.append(path);source_cache[path]={'path':path,'sha256':sha,'role':'test source and actual assertions reviewed','bytes':len(data)}
 implementation=[]
 for path in row['implementation']:
  data=(root/path).read_bytes();old=subprocess.check_output(['git','--no-optional-locks','-C',str(root),'show',partial['native_producer']+':'+path]);assert data==old,path
  item={'path':path,'sha256':hashlib.sha256(data).hexdigest(),'current_byte_equals_producer':True};implementation.append(item);source_cache[path]={'path':path,'sha256':item['sha256'],'role':'implementation rule/control reviewed','bytes':len(data)}
 source_refs=sorted(set(ref for f in row['families'] for ref in canonical_refs(families[f]['source'])))
 boundary_refs=sorted(set(ref for b in row['boundaries'] for ref in json.loads(bounds[b]['source_refs'])))
 source_refs+=boundary_refs
 proof={'id':row['id'],'status':'FINITE_PASS_PROPOSED','native':evidence,'implementation':implementation,'source_refs':sorted(set(source_refs)),'oracles':row['oracles'],'mode':row['mode'],'role':row['role'],'limits':row['limits']}
 proofs.append(proof)
 pending=[x['method'] for x in qualities if x['row']==row['id'] and not x['baseline_method_byte_equal']]
 quality_limit=(' New/changed critical methods need existing exact red/green receipt or selective meaningful mutation: '+','.join(pending)+'.') if pending else ' Test methods unchanged from accepted baseline; existing tests reused.'
 decisions=[]
 if row['id']=='CASE-SAQ-RESET-ATOMIC-PURPOSE':decisions=['T002 for metadata-only password.changed v2']
 if 'ADMIN-' in row['id']:decisions.append('2026-10-08-limited-administrators')
 if row['id'].startswith('CASE-SAQ-NOTIFICATION'):decisions.append('2026-10-02 durable preferences and authority')
 if row['id']=='CASE-SAQ-QR-EXCHANGE-AUTHORITY':decisions.append('2026-10-02-qr-login-backend-now')
 if row['id'].startswith('CASE-SAQ-EXPORT'):decisions.append('D006/D007 ordinary export boundaries only; no extra field/grant')
 csvrows.append({'id':row['id'],'kind':'finite_child_case','source':json.dumps(sorted(set(source_refs)),ensure_ascii=False),'decision':';'.join(decisions),'role_grants':row['role'],'client':row['mode'],'prestate':row['prestate'],'action':row['action'],'expected':json.dumps(row['oracles'],ensure_ascii=False),'forbidden':'No extra grant/effect implied beyond exact observed assertions','verification':'Independent source/assertion review + immutable native e58 PASS; bounded seam qualification','status':'PASS','revision':partial['native_producer'],'evidence':json.dumps(evidence,ensure_ascii=False),'blocking_scope':'Parent remaining boundaries and critical-test sensitivity recorded separately; no family promotion','exclusion':'','parent_family_ids':';'.join(row['families']),'parent_boundary_ids':';'.join(row['boundaries']),'limits':row['limits']+quality_limit})
fields=list(existing[0])
with (p/'proposed-verified-cases.csv').open('w',newline='') as f:
 w=csv.DictWriter(f,fieldnames=fields);w.writeheader();w.writerows(csvrows)
for name,data in [('native-proofs.json',proofs),('test-quality-provenance.json',qualities),('opened-source-ledger.json',sorted(source_cache.values(),key=lambda x:x['path'])),('all-proposals.json',rows)]:
 (p/name).write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n')
summary={'time':datetime.datetime.now(datetime.timezone.utc).isoformat(),'rows':len(rows),'native_case_identities':sum(len(r['methods']) for r in rows),'unique_native_methods':len(set(e['source']+'#'+e['method'] for pr in proofs for e in pr['native'])),'source_files':len(source_cache),'canonical_parent_family_count':len(set(f for r in rows for f in r['families'])),'boundary_count':len(set(b for r in rows for b in r['boundaries'])),'baseline_unchanged_methods':sum(q['baseline_method_byte_equal'] for q in qualities),'new_changed_methods':sum(not q['baseline_method_byte_equal'] for q in qualities),'whole_family_passes':0,'prior_finite_rows':len(existing),'prior_rows_copied_or_modified':0}
(p/'validation-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary))
print(json.dumps({'sensitivity_needed':[{'id':q['row'],'method':q['method']} for q in qualities if not q['baseline_method_byte_equal']]}))
