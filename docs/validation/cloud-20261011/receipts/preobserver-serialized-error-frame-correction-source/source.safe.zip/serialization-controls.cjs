const fs = require('node:fs'), path = require('node:path'), vm = require('node:vm'), crypto = require('node:crypto');
const ts = require('/workspace/rutcampustrack/frontends/node_modules/typescript/lib/typescript.js');
const W = '/workspace/rct-worktrees/client-ci-first3/tests/e2e';
const { serializeError } = require(W + '/node_modules/playwright/lib/util.js');
const marker = 'RCT_PUBLIC_SERIALIZATION_' + crypto.randomUUID();
let parserDiagnostics = 0;
function pair(dir) {
  const cache = {};
  function load(name) {
    if (cache[name]) return cache[name].exports;
    const file = path.join(dir, name + '.ts'), source = fs.readFileSync(file, 'utf8');
    parserDiagnostics += ts.createSourceFile(file, source, ts.ScriptTarget.ES2022, true).parseDiagnostics.length;
    const output = ts.transpileModule(source, { compilerOptions: { target: ts.ScriptTarget.ES2022, module: ts.ModuleKind.CommonJS } }).outputText;
    const box = { exports: {} }; cache[name] = box;
    const requireLocal = id => id === './safe-reporter' ? load('safe-reporter') : id === '@playwright/test' ? require(W + '/node_modules/@playwright/test') : require(id);
    vm.runInThisContext('(function(require,module,exports){' + output + '\n})', { filename: file })(requireLocal, box, box.exports);
    return box.exports;
  }
  return { privacy: load('artifact-privacy'), reporter: load('safe-reporter') };
}
const old = pair(__dirname + '/before'), current = pair(W + '/fixtures');
const rows = []; const check = (code, value) => rows.push({ code, passed: value === true });
function matches(pair, error, cause, httpStatus = 0) {
  const value = pair.reporter.classifySafeFailure(error);
  return value.cause === cause && value.httpStatus === httpStatus && !JSON.stringify(value).includes(marker);
}
const login = serializeError(new Error('Synthetic actor login: HTTP 401'));
const late = serializeError(new Error('Synthetic actor session: HTTP 503'));
check('PINNED_SERIALIZER_FIXED_ERROR_FRAME', login.message === 'Error: Synthetic actor login: HTTP 401');
check('OLD_ACTUAL_SERIALIZED_EARLY_CAUSE_MISSED', matches(old, login, 'UNKNOWN'));
check('OLD_ACTUAL_SERIALIZED_LATE_CAUSE_MISSED', matches(old, late, 'UNKNOWN'));
check('NEW_ACTUAL_SERIALIZED_EARLY_CAPTURED', matches(current, login, 'ACTOR_LOGIN_HTTP', 401));
check('NEW_ACTUAL_SERIALIZED_LATE_CAPTURED', matches(current, late, 'ACTOR_SESSION_HTTP', 503));
check('NEW_ACTUAL_SERIALIZED_GUARD_CAPTURED', matches(current, serializeError(new Error('Real-mobile credentials require trace/video/screenshots off')), 'ARTIFACT_CAPTURE_GUARD'));
const intrinsic = current.reporter.classifySafeFailure(serializeError(new RangeError('Invalid time value')));
check('RANGE_INTRINSIC_ONLY_UNKNOWN_STAGE', intrinsic.cause === 'INVALID_TIME_VALUE' && intrinsic.stage === 'UNKNOWN');
for (const [code, message] of [
  ['DOUBLE_FRAME', 'Error: Error: Synthetic actor login: HTTP 401'],
  ['DYNAMIC_FRAME', marker + ': Synthetic actor login: HTTP 401'],
  ['UNKNOWN_FRAME', 'TypeError: Synthetic actor login: HTTP 401'],
  ['PRIVATE_SUFFIX', 'Error: Synthetic actor login: HTTP 401 ' + marker],
  ['MULTILINE', 'Error: ' + marker + '\nSynthetic actor login: HTTP 401'],
  ['OVERSIZE', 'Error: Synthetic actor login: HTTP 401' + marker.repeat(30)],
  ['RANGE_PRIVATE_SUFFIX', 'RangeError: Invalid time value ' + marker],
  ['NESTED_RANGE_FRAME', 'Error: RangeError: Invalid time value'],
]) check(code + '_UNKNOWN', matches(current, { message }, 'UNKNOWN'));
let getters = 0;
const hostile = { toString() { getters++; return marker; } };
Object.defineProperty(hostile, 'message', { get() { getters++; return marker; } });
Object.defineProperty(hostile, 'name', { get() { getters++; return marker; } });
check('NO_DYNAMIC_GETTER_NAME_OR_CONVERSION', matches(current, hostile, 'UNKNOWN') && getters === 0);
const info = { annotations: [], errors: [login, late, serializeError(new Error(marker))], file: 'preobserver.control.spec.ts', line: 9 };
current.privacy.sanitizeTestErrors(info);
const reporter = new current.reporter.default();
reporter.onTestEnd({ location: { file: info.file, line: info.line }, parent: { project: () => ({ name: 'chromium' }) }, expectedStatus: 'failed' }, { status: 'failed', duration: 0, errors: info.errors, annotations: info.annotations, attachments: [] });
const row = reporter.results[0];
check('SERIALIZED_CAUSES_SURVIVE_SANITIZER_AND_REPORTER', row.status === 'failed' && row.errorCount === 3 && row.diagnostics.some(x => x.cause === 'ACTOR_LOGIN_HTTP' && x.httpStatus === 401) && row.diagnostics.some(x => x.cause === 'ACTOR_SESSION_HTTP' && x.httpStatus === 503) && row.diagnostics.some(x => x.cause === 'UNKNOWN'));
check('NO_PRIVATE_MARKER_IN_CLOSED_TRANSPORT_ROW', !JSON.stringify(row).includes(marker) && !JSON.stringify(info).includes(marker));
const receipt = { pass: rows.every(x => x.passed), count: rows.length, failed: rows.filter(x => !x.passed).length, parserDiagnosticCount: parserDiagnostics, oldActualSerializedCauseMissed: rows.filter(x => x.code.startsWith('OLD_ACTUAL_')).every(x => x.passed), controls: rows, qualification: 'Actual pinned Playwright serializeError/source sanitizer/reporter public adapters; not actual worker/browser/API/currentCIcause.' };
fs.writeFileSync(process.env.RCT_SAFE_DIAGNOSTIC_RECEIPT, JSON.stringify(receipt, null, 2) + '\n', { mode: 0o600 });
process.exitCode = receipt.pass && parserDiagnostics === 0 ? 0 : 1;
