import datetime
import hashlib
import json
import os
from pathlib import Path
import stat
import subprocess

OUT=Path(__file__).parent
ROOT=Path('/workspace/scratch/rct-validation')
d=json.loads((OUT/'strict-source-diagnosis.json').read_text())
rows=[]
reference_inodes={}
for scope in d['scopes']:
    base=Path('/workspace/rct-worktrees')/scope['scope']
    assert subprocess.check_output(['git','--no-optional-locks','rev-parse','HEAD'],cwd=base).decode().strip()==scope['head']
    assert not subprocess.check_output(['git','--no-optional-locks','status','--porcelain','--untracked-files=no'],cwd=base).strip()
    selected=json.loads((OUT/(scope['scope']+'-strict-candidates.json')).read_text())
    for row in selected:
        for item in [row['candidate'],row['reference']]:
            q=Path(item['path']);s=q.lstat()
            assert not any(p.is_symlink() for p in [q,*q.parents])
            assert (s.st_dev,s.st_ino,s.st_nlink,s.st_size,s.st_blocks*512,stat.S_IMODE(s.st_mode),s.st_uid,s.st_gid,s.st_mtime_ns,s.st_ctime_ns)==(item['device'],item['inode'],item['nlink'],item['bytes'],item['allocated_bytes'],int(item['mode'],8),item['uid'],item['gid'],item['mtime_ns'],item['ctime_ns'])
        a,b=row['candidate'],row['reference']
        assert a['nlink']==1 and a['inode']!=b['inode']
        assert all(a[k]==b[k] for k in ['device','sha256','bytes','mode','uid','gid'])
        key=(b['device'],b['inode'])
        if key not in reference_inodes:
            reference_inodes[key]={'device':b['device'],'inode':b['inode'],'baseline_nlink':b['nlink'],
                                   'baseline_mtime_ns':b['mtime_ns'],'baseline_ctime_ns':b['ctime_ns'],
                                   'reference_paths':[],'candidate_count':0,'sha256':b['sha256'],'mode':b['mode']}
        group=reference_inodes[key]
        assert group['baseline_nlink']==b['nlink'] and group['baseline_ctime_ns']==b['ctime_ns']
        group['reference_paths'].append(b['path'])
        group['candidate_count']+=1
    rows+=selected
assert len({(r['candidate']['device'],r['candidate']['inode']) for r in rows})==len(rows)
peer=json.loads(Path('/workspace/scratch/rct-validation/host_capacity_review/strict-selection-review.json').read_text())
oldpairs={(r['scope'],r['relative_path']) for r in peer['selected_pairs']}
overlap=[r for r in rows if (r['scope'],r['relative_path']) in oldpairs]
new=[r for r in rows if (r['scope'],r['relative_path']) not in oldpairs]
ref=[]
for group in reference_inodes.values():
    group['reference_paths']=sorted(set(group['reference_paths']))
    group['future_expected_nlink_formula']='baseline + verifiedsuccessfuldurablelinks + verifiedpendingownsealtmplinks'
    group['current_successful_links']=0
    group['current_pending_links']=0
    ref.append(group)
(OUT/'reference-link-ledger-template.json').write_text(json.dumps({'reference_inodes':ref,'actual_link_mutations':0,
    'future_mtime_inode_nlink_ctime_changes':'intentional and separately journaled; preserve SHA/path/mode/UID/GID only',
    'future_candidate_mtime':'takesreferenceoriginalmtime; originalcandidateinode retired afterexactatomicreplace',
    'future_reference_mtime':'unchanged; ctime/nlink change with everyownedlinkoperation','authorization':'NONE'},indent=2)+'\n')
preserved=[]
for rel in ['current_client_artifacts/manifest.json','host_runtime_prepare/manifest.json','host_runtime_prepare/renderer-addendum-manifest.json',
            'host_runtime_prepare/guard-corrections/manifest.json','host_capacity_plan/manifest.json','current_artifact_corrections/manifest.json']:
    p=ROOT/rel;m=json.loads(p.read_text());items=m.get('safe_files',m.get('files'))
    for item in items:
        q=Path(item['path']);assert q.stat().st_size==item['bytes']
        with q.open('rb') as stream:assert hashlib.file_digest(stream,'sha256').hexdigest()==item['sha256']
    preserved.append({'manifest':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'safe_files':len(items),'all_exact':True})
(OUT/'original-seals-preserved.json').write_text(json.dumps(preserved,indent=2)+'\n')
s=os.statvfs('/workspace');free=s.f_bavail*s.f_frsize
floor,final,transient,copies,growth=4294967296,201326592,134217728,2707241745,1073741824
stage=floor+final+transient
runtime=floor+final+copies+growth
peak=max(stage,runtime)
gain=d['unique_countable_allocated_bytes']
budget={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'actual_free_bytes':free,
        'memory_current':int(Path('/sys/fs/cgroup/memory.current').read_text()),'memory_max':int(Path('/sys/fs/cgroup/memory.max').read_text()),
        'cpu_max':Path('/sys/fs/cgroup/cpu.max').read_text().strip(),'staging_lane_required_bytes':stage,
        'runtime_lane_required_bytes':runtime,'max_sequential_phase_required_bytes':peak,
        'phase_components':{'floor':floor,'final192MiB':final,'staging_only_transient128MiB':transient,'runtime_only_nine_VFS_image_logical_copies':copies,'runtime_only_growth1GiB':growth},
        'no_overlap_rule':'Finishsealmeasure fullstage + releaseALLowntransient BEFOREanyDockerdata/appallocation. Noextractionwhileappactive.',
        'unique_candidate_allocated_bytes':gain,'actual_deficit_without_recovery_bytes':max(0,peak-free),
        'potential_headroom_bytes':free+gain-peak,'headroom_target256MiB_bytes':268435456,
        'meets256MiB_potential_target':free+gain-peak>=268435456,'actual_recovered_bytes':0,
        'actual_future_allocation':'UNKNOWN; remeasureeachphase; requiredpeak notstartupPASS','new_safe_scratch_allocated_bytes':sum(p.stat().st_blocks*512 for p in OUT.iterdir() if p.is_file())}
(OUT/'phase-budget.json').write_text(json.dumps(budget,indent=2)+'\n')
v={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'all10831_rows_current_metadata_exact':True,
   'unique_candidate_inodes':len(rows),'unique_reference_inodes':len(reference_inodes),'no_symlink_ancestry':True,
   'same_device_SHA_size_modes_UID_GID':True,'peer3575_overlap_rows':len(overlap),
   'peer3575_overlap_allocated_bytes':sum(r['candidate']['allocated_bytes'] for r in overlap),
   'new_nonoverlapping_rows':len(new),'new_nonoverlapping_allocated_bytes':sum(r['candidate']['allocated_bytes'] for r in new),
   'old_original36_and_peer3575_are_nonadditive':True,'all_original_safe_files_preserved':sum(r['safe_files'] for r in preserved),
   'actual_recovery':0,'resource_mutation':False}
(OUT/'final-identity-and-overlap.json').write_text(json.dumps(v,indent=2)+'\n')
print(json.dumps({'identity':v,'budget':budget},indent=2))
