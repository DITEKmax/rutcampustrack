const fs = require('node:fs'), path = require('node:path'), vm = require('node:vm'), crypto = require('node:crypto');
const ts = require('/workspace/rutcampustrack/frontends/node_modules/typescript/lib/typescript.js');
const W = '/workspace/rct-worktrees/first3-dataset-correction-20261013/tests/e2e';
const D = '/workspace/rct-worktrees/client-ci-first3/tests/e2e/node_modules';
const { serializeError } = require(D + '/playwright/lib/util.js');
const marker = 'RCT_PUBLIC_DATASET_CONTROL_' + crypto.randomUUID();
const oldMode = process.argv[2] === 'old';
let parserDiagnosticCount = 0;
const rows = [];
function check(code, passed) { rows.push({ code, passed: passed === true }); }
function pair(directory) {
  const cache = {};
  let byte = 0;
  function load(name) {
    if (cache[name]) return cache[name].exports;
    const file = path.join(directory, name + '.ts'), source = fs.readFileSync(file, 'utf8');
    parserDiagnosticCount += ts.createSourceFile(file, source, ts.ScriptTarget.ES2022, true).parseDiagnostics.length;
    const output = ts.transpileModule(source, { compilerOptions: { target: ts.ScriptTarget.ES2022, module: ts.ModuleKind.CommonJS } }).outputText;
    const box = { exports: {} }; cache[name] = box;
    const local = id => ['safe-reporter', 'artifact-privacy'].some(value => id === './' + value) ? load(id.slice(2)) : id === './users' ? { TEST_USERS: {} } : id === '@playwright/test' ? require(D + '/@playwright/test') : id === 'node:crypto' && name === 'mobile-dataset' ? { randomBytes: size => Buffer.alloc(size, size === 1 ? byte : 0), randomUUID: () => 'PUBLIC-DATASET-CONTROL' } : require(id);
    vm.runInThisContext('(function(require,module,exports,__dirname){' + output + '\n})', { filename: file })(local, box, box.exports, W + '/fixtures');
    return box.exports;
  }
  const privacy = load('artifact-privacy'), reporter = load('safe-reporter'), dataset = load('mobile-dataset');
  return { privacy, reporter, dataset, setByte: value => { byte = value; } };
}
const baseline = pair(__dirname + '/before'), current = pair(W + '/fixtures');
const selected = oldMode ? baseline : current;
const annotation = (cause, status) => ({ type: selected.reporter.safeFailureAnnotation, description: cause + ':' + status });
const unknown = value => value?.stage === 'UNKNOWN' && value?.cause === 'UNKNOWN' && value?.httpStatus === 0;
const validCode = code => typeof code === 'string' && /^[1-5]\d{2}$/.test(code) && [1,2,3,4,5,6,7,8,9].includes(Number(code[1])) && Number(code[0]) <= 4;
async function groupCode(p, byte) {
  p.setByte(byte);
  const sentinel = {}, captured = {};
  const admin = { call: async (method, route, data, statuses) => {
    if (method === 'GET' && route === '/api/academic/semesters?size=100') return { content: [{ id: 7, active: true, dateFrom: '2000-01-01', dateTo: '2099-12-31' }] };
    if (method === 'POST' && route === '/api/academic/groups/registry' && Array.isArray(statuses) && statuses.length === 1 && statuses[0] === 201) { captured.numeric = data.numericCode; captured.duration = data.trainingDurationYears; throw sentinel; }
    throw new Error('PUBLIC_CONTROL_UNEXPECTED_SETUP_OPERATION');
  } };
  const dataset = new p.dataset.MobileDataset({}, admin, new Date('2026-10-13T06:00:00Z'));
  try { await dataset.initialize(); } catch (error) { if (error !== sentinel) throw new Error('PUBLIC_GROUP_CAPTURE_FAILED'); }
  if (captured.duration !== 4) throw new Error('PUBLIC_GROUP_DURATION_CHANGED');
  return captured.numeric;
}
async function inspectCall(p, method, route, status = 400, expected = [201]) {
  let bodyReads = 0, thrown = false;
  const request = { fetch: async () => ({ status: () => status, json: () => { bodyReads++; return { private: marker }; } }) };
  const actor = new p.dataset.Actor(request, marker, {});
  const info = { annotations: [], errors: [], file: 'dataset.control.spec.ts', line: 1, status: 'failed' };
  try { await actor.call(method, route, { private: marker }, expected); } catch (error) { thrown = true; info.errors.push(serializeError(error)); }
  p.privacy.sanitizeTestErrors(info); p.privacy.sanitizeTestErrors(info);
  return { diagnostics: p.reporter.safeFailureDiagnostics(info.annotations, thrown), thrown, bodyReads, failureRetained: info.status === 'failed' && info.errors.length === 1, privateAbsent: !JSON.stringify(info).includes(marker) };
}
const routes = [
  ['SEMESTERS_READ','GET','/api/academic/semesters?size=100'], ['SEMESTER_CREATE','POST','/api/academic/semesters'],
  ['SEMESTER_ACTIVATE','PATCH','/api/academic/semesters/7/activate'], ['GROUP_CREATE','POST','/api/academic/groups/registry'],
  ['USER_CREATE','POST','/api/academic/users'], ['HEADMAN_SET','PUT','/api/academic/groups/7/headman'],
  ['SUBJECT_CREATE','POST','/api/academic/subjects'], ['SUBJECT_READ','GET','/api/academic/subjects/7'],
  ['LESSON_CREATE','POST','/api/schedule/one-off-lessons'], ['HOMEWORK_CREATE','POST','/api/academic/homeworks'],
  ['ASSISTANT_CREATE','POST','/api/academic/assistants']
];
async function main() {
  for (const byte of [0,100,200]) check('BYTE_' + byte + '_CANONICAL_VALID', validCode(await groupCode(selected, byte)));
  const group = await inspectCall(selected, 'POST', '/api/academic/groups/registry');
  check('GROUP400_CLOSED_DIAGNOSTIC', group.diagnostics.some(value => value.stage === 'DATASET_HTTP' && value.cause === 'DATASET_GROUP_CREATE_HTTP' && value.httpStatus === 400));
  check('ACTUAL_FAILURE_RETAINED', group.thrown && group.failureRetained && group.bodyReads === 0);
  const privateCall = await inspectCall(selected, 'POST', '/api/unknown/' + marker);
  check('PRIVATE_MARKER_ABSENT', privateCall.privateAbsent && privateCall.failureRetained && privateCall.bodyReads === 0);
  if (!oldMode) {
    const before = new Set(), after = new Set(); let allValid = true, oldInvalid = 0;
    for (let byte = 0; byte < 256; byte++) {
      const old = await groupCode(baseline, byte), next = await groupCode(current, byte);
      if (validCode(old)) before.add(old); else oldInvalid++;
      allValid &&= validCode(next); after.add(next);
    }
    check('ALL256_CURRENT_CODES_CANONICAL_VALID', allValid && oldInvalid === 3);
    check('ALL90_ACCEPTED_CODES_PRESERVED', before.size === 90 && after.size === 90 && [...before].every(value => after.has(value)));
    for (const [operation, method, route] of routes) {
      let known = true, safeUnknown = true;
      for (const status of [400,401,403,404,409,410,422,423,429,500,502,503,504]) {
        const actual = await inspectCall(current, method, route, status);
        known &&= actual.thrown && actual.failureRetained && actual.privateAbsent && actual.bodyReads === 0 && actual.diagnostics.some(value => value.cause === 'DATASET_' + operation + '_HTTP' && value.stage === 'DATASET_HTTP' && value.httpStatus === status);
      }
      for (const [badMethod, badRoute] of [['DELETE',route], [method,route + '/foreign'], [method,route + '\n'], [method,route + '\u2028']]) safeUnknown &&= unknown(current.reporter.classifySafeFailure(current.reporter.datasetHttpFailure(badMethod,badRoute,400)));
      check('KNOWN_' + operation + '_FINITE_HTTP', known); check('UNKNOWN_' + operation + '_METHOD_PATH', safeUnknown);
    }
    let statusUnknown = true;
    for (const status of [0,200,201,204,418,599,600,-1,NaN,Infinity,400.1,'400',null,undefined,{}]) statusUnknown &&= unknown(current.reporter.classifySafeFailure(current.reporter.datasetHttpFailure('POST','/api/academic/groups/registry',status)));
    check('UNKNOWN_STATUS_REJECTED_WITHOUT_COERCION', statusUnknown);
    const markerText = 'Reported synthetic dataset DATASET_GROUP_CREATE_HTTP: HTTP 400'; let messagesUnknown = true;
    for (const message of [markerText + '\n',markerText + '\u2028',markerText + '\u2029',markerText + '\0',markerText + ' suffix',markerText.replace('Reported ','').replace('HTTP 400','HTTP 200'),'x'.repeat(513),markerText.replace('DATASET_GROUP_CREATE_HTTP','__proto__'),markerText.replace('HTTP 400','HTTP 400.1')]) messagesUnknown &&= unknown(current.reporter.classifySafeFailure({ message }));
    check('UNKNOWN_PRIVATE_WRONG_PREFIX_AND_LONG_MARKERS', messagesUnknown);
    let reads = 0; const getter = {}; Object.defineProperty(getter,'message',{ get() { reads++; return markerText; } });
    const coercion = { toString() { reads++; return marker; } }, desc = { type: current.reporter.safeFailureAnnotation }; Object.defineProperty(desc,'description',{ get() { reads++; return 'DATASET_GROUP_CREATE_HTTP:400'; } });
    check('NO_GETTER_PROTOTYPE_OR_CONVERSION_READ', unknown(current.reporter.classifySafeFailure(getter)) && unknown(current.reporter.classifySafeFailure(Object.create({ message: markerText }))) && unknown(current.reporter.classifySafeFailure(current.reporter.datasetHttpFailure(coercion,coercion,400))) && unknown(current.reporter.safeFailureDiagnostics([desc],true)[0]) && reads === 0);
    const seven = ['ARTIFACT_REPORTER_GUARD','ARTIFACT_CAPTURE_GUARD','DATASET_TARGET_GUARD','DATASET_CREDENTIALS_MISSING','BROWSER_ROLE_DENIED','CLOCK_TARGET_GUARD','CLOCK_FORMAT_GUARD'];
    const hintInfo = { annotations: [...seven.map(value => annotation(value,0)),annotation('REPORTED_FRAME_DATASET_CALL',0)], errors: [serializeError(current.reporter.datasetHttpFailure('POST','/api/academic/groups/registry',400))], file:'dataset.control.spec.ts',line:1 };
    current.privacy.sanitizeTestErrors(hintInfo); const priority = current.reporter.safeFailureDiagnostics(hintInfo.annotations,true);
    check('NEW_CORE_EVICTS_ONLY_REPORTED_SLOT', priority.length === 8 && priority.some(value => value.cause === 'DATASET_GROUP_CREATE_HTTP') && !priority.some(value => value.cause === 'REPORTED_FRAME_DATASET_CALL'));
    const eight = [...seven,'CLOCK_WINDOW_GUARD']; const capped = current.reporter.safeFailureDiagnostics([annotation('REPORTED_CLASS_ERROR',0),...eight.map(value => annotation(value,0)),annotation('DATASET_GROUP_CREATE_HTTP',400)],true);
    check('EIGHT_ORIGINAL_CORE_FACTS_PRESERVED', capped.length === 8 && capped.map(value => value.cause).join() === eight.join());
    const beyond = Array.from({ length:32 }, () => ({ type:'other',description:'' })); beyond.push(annotation('DATASET_GROUP_CREATE_HTTP',400));
    check('FIRST32_ANNOTATIONS_ONLY', unknown(current.reporter.safeFailureDiagnostics(beyond,true)[0]));
    check('HTTP_CAUSE_STATUS_BOUNDARY', unknown(current.reporter.safeFailureDiagnostics([annotation('DATASET_GROUP_CREATE_HTTP',0)],true)[0]) && unknown(current.reporter.safeFailureDiagnostics([annotation('DATASET_TARGET_GUARD',400)],true)[0]) && unknown(current.reporter.safeFailureDiagnostics([annotation('REPORTED_FRAME_DATASET_CALL',400)],true)[0]));
    const unexpected200 = await inspectCall(current,'POST','/api/academic/groups/registry',200,[201]);
    check('EXPECTED_HTTP_NOT_WEAKENED', unexpected200.thrown && unexpected200.failureRetained && unexpected200.bodyReads === 0 && unexpected200.diagnostics.some(unknown));
    check('FORGED_MARKER_REPORTS_NO_ADMISSION_OR_SUCCESS', current.reporter.classifySafeFailure({ message:markerText }).cause === 'DATASET_GROUP_CREATE_HTTP' && unexpected200.failureRetained);
    check('THREE_DIAGNOSTIC_FIELDS_ONLY', group.diagnostics.every(value => Object.keys(value).sort().join() === 'cause,httpStatus,stage'));
  }
  const failed = rows.filter(row => !row.passed), causal = ['BYTE_0_CANONICAL_VALID','BYTE_100_CANONICAL_VALID','BYTE_200_CANONICAL_VALID','GROUP400_CLOSED_DIAGNOSTIC'];
  const expectedCausalRed = oldMode && rows.length === 6 && failed.length === 4 && failed.every(row => causal.includes(row.code)) && parserDiagnosticCount === 0;
  const receipt = { pass: failed.length === 0 && parserDiagnosticCount === 0, expectedCausalRed, count:rows.length, failed:failed.length, parserDiagnosticCount, controls:rows, reportedContextOnly:true, noBrowserApi:true, actualCIcause:'UNKNOWN' };
  fs.writeFileSync(process.env.RCT_SAFE_DIAGNOSTIC_RECEIPT,JSON.stringify(receipt,null,2)+'\n',{ mode:0o600 });
  process.exitCode = receipt.pass ? 0 : 1;
}
main().catch(() => { fs.writeFileSync(process.env.RCT_SAFE_DIAGNOSTIC_RECEIPT,JSON.stringify({ pass:false, expectedCausalRed:false, executionBlocked:true, code:'PUBLIC_CONTROL_EXECUTION_BLOCKED',parserDiagnosticCount,actualCIcause:'UNKNOWN' })+'\n',{mode:0o600});process.exitCode=1; });
