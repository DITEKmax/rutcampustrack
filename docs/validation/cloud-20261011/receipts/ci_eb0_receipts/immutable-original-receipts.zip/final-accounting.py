from pathlib import Path
import json,hashlib,collections
O=Path('/workspace/scratch/rct-validation/ci_eb0_receipts');R=Path('/workspace/rutcampustrack');p=O/'safe-integration-outcomes-academic-service-1.json';d=json.loads(p.read_text())
c=[c for c in d['cases'] if (c.get('classname') or '').endswith('BotCredentialBrokerBridgeIT')];assert len(c)==1 and c[0]['status']=='PASSED' and c[0]['identity']=='SOURCE_METHOD'
b=c[0];source=R/b['source'];assert hashlib.sha256(source.read_bytes()).hexdigest()==b['sourceSha256']
prior=Path('/workspace/scratch/rct-validation/ci_format65_receipts/broker-seven-current65-qualified.json');old=json.loads(prior.read_text())
print('prior broker proof keys',list(old))
(O/'broker-current-eb-native.json').write_text(json.dumps({'artifact_id':11750570586,'artifact_digest':'151787509826e6e911987fefe1deb0c3d9646e14f169aba9a8993bd428dce9ca','metadata':d['metadata'],'case':b,'actual_source_sha_matches_Root':True,'prior_source_qualified_broker_receipt':str(prior),'prior_receipt_sha256':hashlib.sha256(prior.read_bytes()).hexdigest(),'qualification':'Exact current method/source PASS; prior seven-phase/default300 natural-expiry assertion review inherited only where exact test source SHA matches. Native PTTL values/individual phase durations absent from SAFE collector. No real Telegram/product-level HTTP/fullstand PASS.'},indent=2)+'\n')
rows=[];skips=[]
for p in sorted(O.glob('safe-*-outcomes-*.json')):
 d=json.loads(p.read_text());cc=collections.Counter(c['status'] for c in d['cases']);obs=collections.Counter()
 for x in d['xml']:
  assert x['state']=='PARSED'
  for s in x['suites']:assert s['countsConsistent'];obs.update(s['observed'])
 assert all(cc[k]==d['summary'][k]==obs[k] for k in d['summary'])
 rows.append({'artifact':p.stem,'metadata':d['metadata'],'summary':d['summary'],'cases_summary_xml_consistent':True})
 skips.extend({'artifact':p.stem,**c} for c in d['cases'] if c['status']!='PASSED')
(O/'safe-native-accounting-final.json').write_text(json.dumps({'artifacts':rows,'totals':{k:sum(r['summary'][k] for r in rows) for k in ['PASSED','FAILED','ERROR','SKIPPED','NOT_EXECUTED']},'acceptance':'NOT_ASSESSED'},indent=2)+'\n')
metadata=json.loads((O/'metadata-final.json').read_text());jobrows=[]
for j in metadata['jobs']:
 matches=[r for r in rows if j['run_id']==38253595173 and ((j['name']=='Java unit — '+r['metadata']['service'] and r['metadata']['task']=='test')or(j['name']=='Java IT — '+r['metadata']['service'] and r['metadata']['task']=='integrationTest'))]
 logs=[l for l in metadata['narrow_log_projection'] if l['job_id']==j['id']]
 checkout=matches[0]['metadata']['checkoutSha'] if matches else (logs[0]['checkoutSha'][0] if logs and len(logs[0].get('checkoutSha',[]))==1 else None)
 jobrows.append({'job_id':j['id'],'name':j['name'],'run_id':j['run_id'],'status':j['status'],'conclusion':j['conclusion'],'actual_checkout_sha':checkout,'checkout_receipt':'SAFE_OUTCOME_ARTIFACT' if matches else ('NARROW_JOB_LOG_GIT_LOG' if checkout else 'NOT_EXECUTED' if j['conclusion']=='skipped' else 'UNKNOWN')})
(O/'all-job-checkouts-final.json').write_text(json.dumps({'jobs':jobrows,'executed_jobs':sum(j['conclusion']!='skipped' for j in jobrows),'actualcheckout_proven_jobs':sum(j['actual_checkout_sha'] is not None for j in jobrows),'no_blanket_inference':True},indent=2)+'\n')
print(json.dumps({'artifact_scopes':len(rows),'totals':{k:sum(r['summary'][k] for r in rows) for k in ['PASSED','FAILED','ERROR','SKIPPED','NOT_EXECUTED']},'broker_method':b['method'],'source_sha':b['sourceSha256'],'jobs_checkout_proven':sum(j['actual_checkout_sha'] is not None for j in jobrows)}))
