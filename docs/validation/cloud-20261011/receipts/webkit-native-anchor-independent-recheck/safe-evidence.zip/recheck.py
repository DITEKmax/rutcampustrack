"""Independent sealed-input review; selected ancestor loop only, no target imports."""
import ast
import copy
import hashlib
import json
import os
from pathlib import Path
import stat
import types
import zipfile
from unittest.mock import patch

REVIEW = Path(__file__).parent
NEW = REVIEW.parent / 'browser_webkit_native_anchor_correction'
OLD = REVIEW.parent / 'browser_webkit_native_publication_correction'
BLOCK = OLD / 'actual-native01' / 'terminal-seal'
def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
def verify(directory, expected):
    manifest = directory / 'manifest.json'
    assert sha(manifest) == expected
    rows = json.loads(manifest.read_text())['files']
    for row in rows:
        path = Path(row['path'])
        assert path.parent == directory and 'private' not in path.parts
        value = path.lstat()
        assert stat.S_ISREG(value.st_mode) and value.st_nlink == 1
        assert value.st_size == row['size'] and stat.S_IMODE(value.st_mode) == int(row['mode'], 0)
        assert sha(path) == row['sha256']
    return rows
newrows = verify(NEW, '6aed2f66ce5c1dcf0d78fcd534903523575b6ca82b6231606d9aa7ff5062eb3c')
oldrows = verify(OLD, '5de233d48c60770701384c5464df6a58d4bb5210632ac3146ec7afdffff46e9f')
blockrows = verify(BLOCK, 'c3b00378feca32ece193801209fcc2b6820fa4020919d06f13859c0ac60ccf22')
zip_path = NEW / 'nested-anchor-correction.source.safe.zip'
assert sha(zip_path) == '99459471d7e6e3cc2ccef66d03d6c91c1a190e27a7aeaec7494e299282bb7349'
with zipfile.ZipFile(zip_path) as archive:
    members = archive.infolist()
    assert len(members) == len(newrows) + 1 and archive.testzip() is None
    expected = {row['relative_path']: row['sha256'] for row in newrows}
    expected['manifest.json'] = sha(NEW / 'manifest.json')
    assert len({m.filename for m in members}) == len(members)
    for member in members:
        assert member.filename in expected and not member.filename.startswith('/') and '..' not in Path(member.filename).parts
        assert not stat.S_ISLNK(member.external_attr >> 16)
        assert hashlib.sha256(archive.read(member)).hexdigest() == expected[member.filename]
helpers = ['extract-selected.py', 'validate-native.py', 'native-probe.py', 'own-paths.py',
           'webkit-custom-exec.py', 'selection.py', 'custom-executable-proposal.py', 'use-gates.py']
helper_hashes = {}
for name in helpers:
    assert (NEW/name).read_bytes() == (OLD/name).read_bytes()
    assert stat.S_IMODE((NEW/name).stat().st_mode) == stat.S_IMODE((OLD/name).stat().st_mode)
    helper_hashes[name] = sha(NEW/name)
rows = json.loads((NEW/'runtime-anchors.safe.json').read_text())['anchors']
old_anchors = json.loads((OLD/'runtime-anchors.safe.json').read_text())['anchors']
assert all(set(r) == {'path', 'identity'} and set(r['identity']) == {'device', 'inode', 'uid', 'gid', 'mode'} for r in rows)
assert [r['path'] for r in rows] == [str(p) for p in list(reversed(NEW.parents)) + [NEW]]
assert rows[:-1] == old_anchors[:-1]
assert rows[-1]['identity']['inode'] == 1874444
assert old_anchors[-1]['identity']['inode'] == 1861717 and old_anchors[-1]['inode'] == 1874065
assert os.getuid() == os.getgid() == 1000
tree = ast.parse((NEW/'own-paths.py').read_text())
identity = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == 'identity')
cls = next(n for n in tree.body if isinstance(n, ast.ClassDef) and n.name == 'Output')
ctor = next(n for n in cls.body if isinstance(n, ast.FunctionDef) and n.name == '__init__')
block = next(n for n in ctor.body if isinstance(n, ast.Try))
loop = next(n for n in block.body if isinstance(n, ast.For) and ast.unparse(n.target) == 'row')
selected = compile(ast.Module(body=[identity, loop], type_ignores=[]), 'unchanged_selected_ancestor_loop', 'exec')
checks = []
def exercise(case, candidate, accepted, symlink=False):
    obj = types.SimpleNamespace(fds=[], identities=[])
    scope = dict(self=obj, rows=candidate, Path=Path, os=os, stat=stat,
                 flags=os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW|os.O_CLOEXEC)
    actual = Path.lstat
    def metadata(path):
        if symlink and str(path) == candidate[-1]['path']:
            return types.SimpleNamespace(st_mode=stat.S_IFLNK|0o777)
        return actual(path)
    result = False
    fd_metadata = []
    try:
        with patch.object(Path, 'lstat', metadata):
            exec(selected, scope)
        result = True
        fd_metadata = [{'path': str(p), 'identity': e, 'fstat': scope['identity'](os.fstat(fd))}
                       for fd, (p,e) in zip(obj.fds, obj.identities)]
    except RuntimeError:
        pass
    finally:
        for fd in reversed(obj.fds):
            os.close(fd)
    assert result == accepted, case
    checks.append(dict(case=case, pass_result=True, accepted=result, closed_FDs=True))
    return fd_metadata
exercise('old_stale_nested_own_inode_denied', old_anchors, False)
actual_metadata = exercise('new_all5_nested_lstat_and_relative_nofollow_FDs_match', rows, True)
for field in ['device','inode','uid','gid','mode']:
    mutated = copy.deepcopy(rows)
    mutated[-1]['identity'][field] += 1
    exercise('wrong_'+field+'_denied', mutated, False)
exercise('mocked_symlink_metadata_denied_without_alias', rows, False, True)
assert not (NEW/'runtime').exists()
launch = json.loads((NEW/'launch-schema.safe.json').read_text())
assert launch['no_old_grant_reuse'] is True
assert launch['native_validation_command'][1] == str(NEW/'validate-native.py')
assert launch['grant_templates']['native_only']['library_extraction_authorized'] is False
assert launch['grant_templates']['native_only']['browser_launch_authorized'] is False
assert launch['grant_templates']['native_only']['extraction_receipt_sha256'] == '55f4fe3e0e05bed1a2e66c337fbb532154513d1c0ee71e0b0000cf2c1c9ea2f4'
assert 'DO_NOT_REEXTRACT' in launch['extraction_command_status']
for row in json.loads((NEW/'prior-authorities.safe.json').read_text())['seals']:
    assert 'private' not in Path(row['path']).parts and sha(Path(row['path'])) == row['sha256']
result = dict(outcome='APPROVE_SOURCE', scope='Nested OWN anchor input binding only', actor=[os.getuid(),os.getgid()],
    context='approved require_escalated execution context; actor still1000; no network operation',
    source_manifest=sha(NEW/'manifest.json'), source_zip=sha(zip_path),
    verified_source_members=len(newrows), zip_members=len(members), original_source_members=len(oldrows), blocked_receipt_members=len(blockrows),
    all_eight_helpers_byte_mode_identical=helper_hashes, canonical_schema=True,
    controls=checks, actual_readonly_anchor_metadata=actual_metadata,
    runtime_output_absent=True, target_imports_native_probes_browser_network_calls=0,
    native_ABI_browser='NOT_RUN', fresh_Root_native_grant_required=True,
    author_claim_134_prior_plus_8_controls='Inspected; only own 8 selected read-only controls executed')
(REVIEW/'checks.safe.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:result[k] for k in ['outcome','source_manifest','verified_source_members','zip_members','actor','native_ABI_browser']}))
