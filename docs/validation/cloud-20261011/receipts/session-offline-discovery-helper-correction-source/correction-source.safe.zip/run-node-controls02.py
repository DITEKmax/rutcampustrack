"""Exactly three serial Node-only commands from the existing reviewed plan; no browser/API."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import shutil
import stat
import sys
import types

BASE = Path('/workspace/scratch/rct-validation/client_session_offline_acceptance')
ROOT = Path('/workspace/rutcampustrack')
GUARD = Path('/workspace/scratch/rct-validation/guard_proc_race_correction/bounded-child.py')
UTC = datetime.timezone.utc

def digest(path):
    value = hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(2097152), b''):
            value.update(chunk)
    return value.hexdigest()


def require(value, stage):
    if not value:
        raise RuntimeError(stage)


def atomic(path, value):
    temporary = path.with_suffix(path.suffix + '.next')
    with temporary.open('x', encoding='utf-8') as stream:
        json.dump(value, stream, indent=2)
        stream.write('\n')
    temporary.chmod(0o600)
    temporary.replace(path)



def main():
    os.umask(0o077)
    require(len(sys.argv) == 2 and Path(sys.argv[1]) == BASE / 'node-control-grant02.private.json', 'ROOT_NODE_GRANT_REQUIRED')
    grant_path = Path(sys.argv[1])
    info = grant_path.lstat()
    require(stat.S_ISREG(info.st_mode) and not grant_path.is_symlink() and stat.S_IMODE(info.st_mode) == 0o600, 'GRANT_MODE_INVALID')
    original_grant = json.loads(grant_path.read_text())
    grant = {**original_grant,
        'owned_total_rss_stop_bytes': original_grant['owned_RSS_cap'],
        'cache_stop_bytes': original_grant['own_tmp_cache_cap'],
        'disk_floor_bytes': original_grant['workspace_floor'],
        'shared_stop_bytes': original_grant['shared_stop'],
        'shared_memory_reserve_bytes': original_grant['shared_reserve']}
    stop = datetime.datetime.fromisoformat(grant['stop_utc'])
    issued = datetime.datetime.fromisoformat(grant['not_before_utc'])
    cleanup = datetime.datetime.fromisoformat(grant['cleanup_stop_utc'])
    require(issued <= datetime.datetime.now(UTC) < stop and cleanup - stop == datetime.timedelta(seconds=60), 'GRANT_EXPIRED')
    require(grant['scope'] == 'SESSION_OFFLINE_DISCOVERY_GATE_THREE_CONTROLS_ONLY'
            and grant['browser_API_seed_build_services_authorized'] is False
            and grant['source_write_authorized'] is False and grant['source_preserved'] is True, 'NODE_ONLY_SCOPE_REQUIRED')
    require(grant['node_heap_MiB'] == 512 and grant['owned_RSS_cap'] == 1073741824
            and grant['own_tmp_cache_cap'] == 33554432 and grant['per_phase_seconds'] == 30
            and grant['workspace_floor'] == grant['tmp_floor'] == 4294967296
            and grant['shared_stop'] == 16106127360 and grant['shared_reserve'] == 1073741824, 'CAPS_CHANGED')
    ready_path = BASE / 'READY.safe.json'
    ready = json.loads(ready_path.read_text())
    plan = json.loads((BASE / 'discovery-gate-correction/SOURCE-READY.safe.json').read_text())
    require(ready['prepared_source_sha'] == grant['source_commit'] and len(ready['root_source_hashes']) == 19, 'SOURCE_BINDING_INVALID')
    config = Path('/workspace/rct-worktrees/client-session-offline/tests/e2e/playwright.session-offline.config.ts')
    wrapper = config.parent / 'session-offline-specs/mobile-session-offline.spec.ts'
    require(digest(config) == grant['source_config_sha256'] and digest(wrapper) == grant['source_wrapper_sha256'], 'TWO_SOURCE_CHANGED')
    for name, sha in ready['root_source_hashes'].items():
        require(digest(ROOT / name) == sha, 'ROOT_SOURCE_CHANGED')
    for name, sha in ready['own_source_hashes'].items():
        require(digest(BASE / name) == sha, 'OWN_SOURCE_CHANGED')
    for name, sha in ready['runtime_hashes'].items():
        require(digest(Path(name)) == sha, 'PINNED_RUNTIME_SOURCE_CHANGED')
    for name, entry in ready['third_party_links'].items():
        path = ROOT / 'tests/e2e/node_modules' / name
        require(path.is_symlink() and str(path.resolve()) == entry['resolved_path']
                and digest(path / 'package.json') == entry['package_sha256'], 'THIRD_PARTY_LINK_CHANGED')
    for name, sha in ready['clock_hashes'].items():
        require(digest(Path(name)) == sha, 'TEACHING_CLOCK_CHANGED')
    require(digest(GUARD) == ready['guard_sha256'] == grant['guard_sha256'], 'GUARD_CHANGED')
    require(digest(Path(ready['provided_node_binary']['path'])) == ready['provided_node_binary']['sha256'], 'NODE_CHANGED')
    def fresh_preflight():
        for filesystem in ['/workspace', '/tmp']:
            value = os.statvfs(filesystem)
            require(value.f_bavail * value.f_frsize >= grant['disk_floor_bytes'], 'DISK_FLOOR_AT_USE')
        used = int(Path('/sys/fs/cgroup/memory.current').read_text())
        limit = int(Path('/sys/fs/cgroup/memory.max').read_text())
        require(used < grant['shared_stop_bytes'] and limit - used >= grant['shared_memory_reserve_bytes'], 'SHARED_MEMORY_AT_USE')
        require(issued <= datetime.datetime.now(UTC) < stop, 'GRANT_EXPIRED_AT_USE')
    require(grant['authorized'] is True, 'FRESH_ROOT_CONTROL_GRANT_REQUIRED')
    require(digest(BASE / 'discovery-gate-correction/SOURCE-READY.safe.json') == grant['correction_source_ready_sha256'], 'CORRECTION_READY_CHANGED')
    require(digest(BASE / 'discovery-gate-correction/controls.cjs') == grant['controls_sha256']
            and digest(BASE / 'discovery-gate-correction/discovery-reporter.before.cjs') == grant['before_sha256']
            and digest(BASE / 'discovery-reporter.cjs') == grant['after_sha256'], 'CONTROL_SOURCE_CHANGED')
    phases = plan['planned_argv']
    require(len(phases) == 2 and phases == grant['planned_argv'], 'PHASES_CHANGED')
    for index, argv in enumerate(phases):
        require(argv == [ready['provided_node_binary']['path'], '--max-old-space-size=512', str(BASE / 'discovery-gate-correction/controls.cjs'), ['before', 'after'][index]], 'CONTROL_ARGV_CHANGED')
    run = Path(grant['scope_new_own_run'])
    require(str(run) == plan['run_namespace'] and run == BASE / 'runs/attempt-91', 'RUN_SCOPE_CHANGED')
    runs = run.parent
    fresh_preflight()
    runs.mkdir(mode=0o700, exist_ok=True)
    require(not runs.is_symlink() and runs.stat().st_uid == os.geteuid() and stat.S_IMODE(runs.stat().st_mode) == 0o700, 'RUN_PARENT_INVALID')
    fresh_preflight()
    run.mkdir(mode=0o700, exist_ok=False)
    for name in ['artifacts', 'supervision', 'private-tmp', 'transform-cache']:
        fresh_preflight()
        (run / name).mkdir(mode=0o700)
    supervision = run / 'supervision'
    guard = types.ModuleType('reviewed_owned_guard')
    guard.__file__ = str(GUARD)
    exec(compile(GUARD.read_bytes(), str(GUARD), 'exec'), guard.__dict__)
    atomic(supervision / 'supervisor.safe.json', {'pid': os.getpid(), 'birth_ticks': guard.process_table()[os.getpid()]['start_ticks'], 'source': 'SESSION_OFFLINE_THREE_CONTROL_NODE_ONLY', 'stop_utc': stop.isoformat()})
    latest = {}
    active_phase = 'before'
    peaks = {'owned_rss_bytes': 0, 'run_allocated_bytes': 0, 'shared_memory_bytes': 0}
    def status(value):
        child = guard.process_table().get(value['child_pid'])
        if child is not None:
            value = {**value, 'direct_birth': child['start_ticks']}
        latest.clear()
        latest.update(value)
        atomic(supervision / (active_phase + '-process.safe.json'), value)

    def observe():
        if datetime.datetime.now(UTC) >= stop:
            return 'ABSOLUTE_DEADLINE'
        for filesystem in ['/workspace', '/tmp']:
            value = os.statvfs(filesystem)
            if value.f_bavail * value.f_frsize < grant['disk_floor_bytes']:
                return 'DISK_FLOOR'
        used = int(Path('/sys/fs/cgroup/memory.current').read_text())
        limit = int(Path('/sys/fs/cgroup/memory.max').read_text())
        peaks['shared_memory_bytes'] = max(peaks['shared_memory_bytes'], used)
        if used >= grant['shared_stop_bytes'] or limit - used < grant['shared_memory_reserve_bytes']:
            return 'SHARED_MEMORY_STOP'
        table = guard.process_table()
        rss = next((int(line.split()[1]) * 1024 for line in Path('/proc/self/status').read_text().splitlines()
                    if line.startswith('VmRSS:')), 0)
        for row in latest.get('members_including_Z', []):
            current = table.get(row['pid'])
            if current is None or current['start_ticks'] != row['start_ticks']:
                continue
            try:
                lines = Path('/proc', str(row['pid']), 'status').read_text().splitlines()
            except FileNotFoundError:
                continue
            rss += next((int(line.split()[1]) * 1024 for line in lines if line.startswith('VmRSS:')), 0)
        peaks['owned_rss_bytes'] = max(peaks['owned_rss_bytes'], rss)
        if rss > grant['owned_total_rss_stop_bytes']:
            return 'OWN_TOTAL_RSS_STOP'
        allocated = sum(path.lstat().st_blocks * 512 for path in run.rglob('*')
                        if path.is_file() and not path.is_symlink())
        peaks['run_allocated_bytes'] = max(peaks['run_allocated_bytes'], allocated)
        return 'OWN_CACHE_STOP' if allocated > grant['cache_stop_bytes'] else None


    env = {name: os.environ[name] for name in ['PATH', 'LANG', 'LC_ALL', 'TZ'] if name in os.environ}
    env.update(CI='true', RCT_E2E_SYNTHETIC_SEED='true', E2E_BASE_URL='https://localhost:8443',
               PLAYWRIGHT_NO_COPY_PROMPT='1', RCT_SESSION_OFFLINE_RUN=str(run),
               RCT_SESSION_OFFLINE_LIST_OUTPUT=str(supervision / 'list.safe.json'),
               RCT_SESSION_OFFLINE_TYPES_OUTPUT=str(supervision / 'types.safe.json'),
               PWTEST_CACHE_DIR=str(run / 'transform-cache'),
               TMPDIR=str(run / 'private-tmp'), TMP=str(run / 'private-tmp'), TEMP=str(run / 'private-tmp'))
    results = []
    for active_phase, argv in zip(['before', 'after'], phases):
        fresh_preflight()
        seconds = min(grant['per_phase_seconds'], int((stop - datetime.datetime.now(UTC)).total_seconds()))
        require(seconds > 0, 'GRANT_EXPIRED_BETWEEN_PHASES')
        atomic(supervision / (active_phase + '-launch.safe.json'), {'phase': active_phase, 'argv': argv, 'ready_sha256': digest(ready_path), 'deadline_seconds': seconds, 'absolute_stop_at': stop.isoformat()})
        result = guard.run_owned(argv, str(ROOT / 'tests/e2e'), env, deadline_seconds=seconds, observe=observe, status=status)
        safe_path = supervision / (active_phase + '-controls.safe.json')
        safe = json.loads(safe_path.read_text()) if safe_path.exists() else {}
        rows = safe.get('results', [])
        common = safe.get('count') == 3 and len(rows) == 3 and [row.get('code') for row in rows] == ['ZERO_CASES', 'ONE_CASE', 'WRONG_LINE'] and all(row.get('discoveryPass') is False for row in rows)
        if active_phase == 'before':
            accepted = (result['native_exit'] == 1 and result['terminal_reason'] == 'NATIVE_TERMINAL'
                        and result['settled'] and result['all_owned_processes_reaped']
                        and result['supervision_error_type'] is None and safe.get('knownBeforeCounterexample') is True
                        and safe.get('failedControls') == 3 and common)
        else:
            accepted = result['phase_success'] and safe.get('pass') is True and safe.get('failedControls') == 0 and common and all(row.get('rejected') is True for row in rows)
        result.update(phase=active_phase, accepted_phase=accepted, peaks=peaks.copy())
        atomic(supervision / (active_phase + '-terminal.safe.json'), result)
        results.append(result)
        if not accepted:
            break
    settled = all(item['settled'] and item['all_owned_processes_reaped'] for item in results)
    passed = len(results) == 2 and all(item['accepted_phase'] for item in results)
    temporary_removed = False
    if settled:
        for name in ['private-tmp', 'transform-cache']:
            temporary = run / name
            require(not temporary.is_symlink() and temporary.stat().st_uid == os.geteuid() and stat.S_IMODE(temporary.stat().st_mode) == 0o700, 'PRIVATE_TMP_INVALID')
            shutil.rmtree(temporary)
        temporary_removed = True
    source_intact = all(digest(ROOT / name) == sha for name, sha in ready['root_source_hashes'].items()) and all(digest(BASE / name) == sha for name, sha in ready['own_source_hashes'].items())
    atomic(supervision / 'DISCOVERY-CONTROLS.safe.json', {'state': 'PASS_DISCOVERY_GATE_CONTROLS' if passed else 'FAILED_DISCOVERY_GATE_CONTROLS', 'settled': settled, 'completed_phase_count': len(results), 'pass': passed, 'browser_api_network_started': False, 'private_tmp_transform_removed': temporary_removed, 'source_intact': source_intact, 'peaks': peaks})
    print(json.dumps({'stage': 'DISCOVERY_GATE_THREE_CONTROLS_ONLY', 'settled': settled, 'pass': passed, 'phase_count': len(results), 'source_intact': source_intact}))
    return 0 if passed and settled and source_intact else 1

if __name__ == '__main__':
    try:
        raise SystemExit(main())
    except Exception:
        print('{"state":"BLOCKED","stage":"NODE_SOURCE_PREFLIGHT_OR_SUPERVISION"}')
        raise SystemExit(2)
