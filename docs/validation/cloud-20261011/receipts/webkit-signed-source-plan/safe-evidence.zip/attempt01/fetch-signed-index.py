import datetime,email.utils,hashlib,json,lzma,os,re,subprocess
from pathlib import Path
OUT=Path(__file__).parent
META=Path('/tmp/rct-webkit-signed-metadata-20261012')
KEY=Path('/usr/share/keyrings/debian-archive-keyring.gpg')
ENV={'PATH':'/usr/bin:/bin','LANG':'C','LC_ALL':'C'}
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def save(n,v):(OUT/n).write_text(json.dumps(v,indent=2)+'\n')
def download(url,path,cap):
 r=subprocess.run(['/usr/bin/curl','--fail','--location','--proto','=https','--max-time','45','--max-filesize',str(cap),'--silent','--show-error','--output',str(path),'--write-out','%{http_code}',url],env=ENV,capture_output=True,text=True,timeout=50)
 receipt={'public_url':url,'native_exit':r.returncode,'http_status':r.stdout.strip() if r.stdout.strip().isdigit() else 'UNKNOWN','bytes':path.stat().st_size if path.exists() else 0,'sha256':sha(path) if path.exists() else None,'error_output_not_published':True}
 save(path.name+'.download.safe.json',receipt)
 if r.returncode!=0:raise RuntimeError('PUBLIC_METADATA_DOWNLOAD_FAILED')
 assert receipt['bytes']<=cap
release_url='https://deb.debian.org/debian/dists/trixie/InRelease'
inrelease=META/'InRelease';download(release_url,inrelease,1048576)
r=subprocess.run(['/usr/bin/sqv','--keyring',str(KEY),'--output',str(META/'Release.verified'),'--cleartext',str(inrelease)],env=ENV,capture_output=True,text=True,timeout=20)
receipt={'native_exit':r.returncode,'existing_keyring_path':str(KEY),'existing_keyring_sha256':sha(KEY),'sqv_path':'/usr/bin/sqv','sqv_sha256':sha('/usr/bin/sqv'),'verified_signer_fingerprints':re.findall(r'\b[A-F0-9]{40,64}\b',r.stdout),'new_keys_or_policy_override':False,'signed_InRelease_sha256':sha(inrelease)}
save('signature.safe.json',receipt)
if r.returncode!=0:raise RuntimeError('EXISTING_DEBIAN_KEYRING_VERIFICATION_FAILED')
release=(META/'Release.verified').read_text()
fields={}
for line in release.splitlines():
 if line and not line[0].isspace() and ':' in line:
  k,v=line.split(':',1);fields[k]=v.strip()
assert fields['Origin']=='Debian' and fields['Codename']=='trixie' and 'amd64' in fields['Architectures'].split()
now=datetime.datetime.now(datetime.timezone.utc)
assert email.utils.parsedate_to_datetime(fields['Date'])<=now
if 'Valid-Until' in fields:assert now<=email.utils.parsedate_to_datetime(fields['Valid-Until'])
section=release.split('\nSHA256:\n',1)[1].split('\nSHA512:',1)[0]
expected={m.group(3):(m.group(1),int(m.group(2))) for m in re.finditer(r'^\s*([0-9a-f]{64})\s+(\d+)\s+(\S+)',section,re.M)}
index='main/binary-amd64/Packages.xz';hashvalue,bytesvalue=expected[index]
assert bytesvalue<=16777216
packages=META/'Packages.xz';download('https://deb.debian.org/debian/dists/trixie/'+index,packages,bytesvalue)
assert packages.stat().st_size==bytesvalue and sha(packages)==hashvalue
lists=META/'lists';lists.mkdir(mode=0o700);(lists/'partial').mkdir(mode=0o700)
index_path=lists/'deb.debian.org_debian_dists_trixie_main_binary-amd64_Packages'
count=0
with lzma.open(packages,'rb') as source,index_path.open('xb') as dest:
 for block in iter(lambda:source.read(1048576),b''):
  count+=len(block);assert count<=100663296;dest.write(block)
plain='main/binary-amd64/Packages';assert count==expected[plain][1] and sha(index_path)==expected[plain][0]
(lists/'deb.debian.org_debian_dists_trixie_InRelease').write_bytes(inrelease.read_bytes())
(META/'sources.list').write_text('deb [signed-by=/usr/share/keyrings/debian-archive-keyring.gpg] https://deb.debian.org/debian trixie main\n')
save('signed-index-authenticity.safe.json',{'status':'PASS_PUBLIC_SIGNATURE_AND_INDEX_BYTES','origin':fields['Origin'],'codename':fields['Codename'],'suite':fields.get('Suite'),'date':fields['Date'],'valid_until':fields.get('Valid-Until','NOT_PRESENT_IN_SIGNED_STABLE_RELEASE'),'stable_release_valid_until_absence_qualified': 'Valid-Until' not in fields,'signed_release_sha256':sha(META/'Release.verified'),'index_xz':{'public_path':str(packages),'bytes':bytesvalue,'sha256':hashvalue},'verified_plain_index':{'path':str(index_path),'bytes':count,'sha256':sha(index_path)},'official_security_and_updates_indices':'NOT_SELECTED; exact7 metadata closure compatibility must pass or expand only if required','payload_download_extract_install_or_browser':False})
print(json.dumps({'signature_native_exit':r.returncode,'index_xz_bytes':bytesvalue,'index_plain_bytes':count,'signature_and_both_index_hashes':True,'browser_or_library_payload':False}))
