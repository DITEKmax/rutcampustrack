from pathlib import Path, PurePosixPath
import ast, collections, datetime, hashlib, json, os, re, stat, subprocess

OUT=Path('/workspace/scratch/rct-validation/host_capacity_correction_review')
PLAN=Path('/workspace/scratch/rct-validation/host_capacity_correction')
BASE=Path('/workspace/rct-worktrees');REF=BASE/'client-acceptance';cache={}
def digest(path,s):
    key=(s.st_dev,s.st_ino,s.st_size,s.st_mtime_ns,s.st_ctime_ns)
    if key not in cache:
        fd=os.open(path,os.O_RDONLY|os.O_NOFOLLOW)
        with os.fdopen(fd,'rb') as stream:
            initial=os.fstat(stream.fileno());h=hashlib.sha256()
            assert (initial.st_dev,initial.st_ino,initial.st_size,initial.st_mtime_ns,initial.st_ctime_ns)==key
            for block in iter(lambda:stream.read(1024*1024),b''):h.update(block)
            last=os.fstat(stream.fileno())
            assert (last.st_dev,last.st_ino,last.st_size,last.st_mtime_ns,last.st_ctime_ns)==key
        cache[key]=h.hexdigest()
    return cache[key]
def git(path,*args):return subprocess.check_output(['git','--no-optional-locks','-C',str(path),*args]).decode()
def inspect(item):
    path=Path(item['path']);assert path.is_absolute() and not any(p.is_symlink() for p in (path,*path.parents))
    s=path.lstat();assert stat.S_ISREG(s.st_mode)
    actual=(s.st_dev,s.st_ino,s.st_nlink,s.st_size,s.st_blocks*512,stat.S_IMODE(s.st_mode),s.st_uid,s.st_gid,s.st_mtime_ns,s.st_ctime_ns)
    expected=(item['device'],item['inode'],item['nlink'],item['bytes'],item['allocated_bytes'],int(item['mode'],8),item['uid'],item['gid'],item['mtime_ns'],item['ctime_ns'])
    assert actual==expected,(str(path),'metadata changed');return path,s
manifest=PLAN/'manifest.json';ms=manifest.lstat();manifest_sha=digest(manifest,ms)
assert manifest_sha=='4c2702f30182f291919b79d0d2b55bb8f917b94bd983f59f96bf7770b6485dcf'
m=json.loads(manifest.read_text());inputs=[]
for entry in m.get('files',m.get('safe_files')):
    path=Path(entry['path']);s=path.lstat();assert s.st_size==entry['bytes'] and digest(path,s)==entry['sha256']
    inputs.append({'file':path.name,'sha256':entry['sha256'],'bytes':entry['bytes']})
source=(PLAN/'strict-source-plan.py').read_text();tree=ast.parse(source)
names={'EXCLUDED','PRIVATE','EXECUTABLE_OUTPUT_SUFFIXES','GENERATED_HEADER'}
nodes=[n for n in tree.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id in names for t in n.targets)]
nodes += [n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='exclusion']
ns={'PurePosixPath':PurePosixPath,'re':re};exec(compile(ast.Module(body=nodes,type_ignores=[]),'readonly_filter','exec'),ns)
exclude=ns['exclusion'];generated=ns['GENERATED_HEADER']
peer=json.loads(Path('/workspace/scratch/rct-validation/host_capacity_review/strict-selection-review.json').read_text())
assert len(peer['excluded_paths'])==847 and all(exclude(r['relative_path']) is not None for r in peer['excluded_paths'])
diagnosis=json.loads((PLAN/'strict-source-diagnosis.json').read_text());rows=[];heads=[];seen=set();references={};header_checked=0
assert git(REF,'rev-parse','HEAD').strip()=='eec3e0a864626160d33ae29da2cf3b0640e30caa' and not git(REF,'status','--porcelain','--untracked-files=no').strip()
reftracked=set(git(REF,'ls-files','-z').split('\0'))
assert len(diagnosis['scopes'])==16
for scope in diagnosis['scopes']:
    root=BASE/scope['scope'];assert scope['scope'] not in {'np01-domain-bot','ci-academic-heap','client-format','client-runtime'}
    assert git(root,'rev-parse','HEAD').strip()==scope['head'] and not git(root,'status','--porcelain','--untracked-files=no').strip()
    tracked=set(git(root,'ls-files','-z').split('\0'));selected=json.loads((PLAN/(scope['scope']+'-strict-candidates.json')).read_text())
    for r in selected:
        rel=r['relative_path'];parts=PurePosixPath(rel).parts
        assert not rel.startswith('/') and '..' not in parts and '\\' not in rel and str(PurePosixPath(rel))==rel
        assert rel in tracked and rel in reftracked and exclude(rel) is None
        assert r['scope']==scope['scope'] and r['scope_head']==scope['head']
        assert r['candidate']['path']==str(root/rel) and r['reference']['path']==str(REF/rel)
        a,sa=inspect(r['candidate']);b,sb=inspect(r['reference'])
        assert sa.st_nlink==1 and sa.st_dev==sb.st_dev and sa.st_ino!=sb.st_ino and sa.st_size>=32768
        assert all(r['candidate'][k]==r['reference'][k] for k in ('device','sha256','bytes','mode','uid','gid'))
        inode=(sa.st_dev,sa.st_ino);assert inode not in seen;seen.add(inode)
        if a.suffix.lower() in {'.java','.ts','.js','.py'}:
            with a.open('rb') as stream:assert not generated.search(stream.read(8192))
            header_checked+=1
        assert digest(a,sa)==r['candidate']['sha256'] and digest(b,sb)==r['reference']['sha256']
        key=(sb.st_dev,sb.st_ino);ref=references.setdefault(key,{'baseline_nlink':sb.st_nlink,'mtime_ns':sb.st_mtime_ns,'ctime_ns':sb.st_ctime_ns,'candidate_count':0,'sha256':r['reference']['sha256'],'mode':r['reference']['mode'],'paths':set()})
        assert (ref['baseline_nlink'],ref['mtime_ns'],ref['ctime_ns'],ref['sha256'],ref['mode'])==(sb.st_nlink,sb.st_mtime_ns,sb.st_ctime_ns,r['reference']['sha256'],r['reference']['mode'])
        ref['candidate_count']+=1;ref['paths'].add(str(b))
    assert git(root,'rev-parse','HEAD').strip()==scope['head'] and not git(root,'status','--porcelain','--untracked-files=no').strip()
    rows+=selected;heads.append({'scope':scope['scope'],'head':scope['head'],'clean_before_after':True,'rows':len(selected),'allocated_bytes':sum(r['candidate']['allocated_bytes'] for r in selected)})
assert len(rows)==len(seen)==10831 and sum(r['candidate']['allocated_bytes'] for r in rows)==1519378432
ledger=json.loads((PLAN/'reference-link-ledger-template.json').read_text());assert len(ledger['reference_inodes'])==len(references)==714
for group in ledger['reference_inodes']:
    ref=references[(group['device'],group['inode'])]
    assert group['baseline_nlink']==ref['baseline_nlink'] and group['baseline_mtime_ns']==ref['mtime_ns'] and group['baseline_ctime_ns']==ref['ctime_ns']
    assert group['candidate_count']==ref['candidate_count'] and set(group['reference_paths'])==ref['paths']
    assert group['sha256']==ref['sha256'] and group['mode']==ref['mode'] and group['current_successful_links']==group['current_pending_links']==0
assert git(REF,'rev-parse','HEAD').strip()=='eec3e0a864626160d33ae29da2cf3b0640e30caa' and not git(REF,'status','--porcelain','--untracked-files=no').strip()
oldpairs={(r['scope'],r['relative_path']) for r in peer['selected_pairs']};overlap=[r for r in rows if (r['scope'],r['relative_path']) in oldpairs]
assert len(overlap)==3447 and sum(r['candidate']['allocated_bytes'] for r in overlap)==924459008
preserved=[]
(OUT/'candidate-checkpoint.json').write_text(json.dumps({'time':datetime.datetime.now(datetime.timezone.utc).isoformat(),'candidate_rows':len(rows),'unique_nlink1_candidates':len(seen),'independent_SHA_pairs':len(rows),'allocated_bytes':1519378432,'reference_inodes':len(references),'strict_filter_and_847rejects':True,'heads_clean':heads,'resource_mutations':False},indent=2)+'\n')
for record in json.loads((PLAN/'original-seals-preserved.json').read_text()):
    path=Path(record['manifest']);s=path.lstat();assert digest(path,s)==record['sha256'];m=json.loads(path.read_text());entries=m.get('safe_files',m.get('files'))
    for entry in entries:
        path=Path(entry['path'])
        if path.is_symlink():
            assert path==Path('/workspace/scratch/rct-validation/host_runtime_prepare/guard-corrections/synthetic-cases/symlink-public')
            target=Path('/workspace/scratch/rct-validation/host_runtime_prepare/guard-corrections/synthetic-cases/public.json')
            assert os.readlink(path)==str(target) and path.resolve()==target and not target.is_symlink()
            s=target.lstat();observed=digest(target,s)
        else:
            s=path.lstat();observed=digest(path,s)
        assert s.st_size==entry['bytes'] and observed==entry['sha256'],(str(path),s.st_size,entry['bytes'],observed,entry['sha256'])
    preserved.append({'manifest':record['manifest'],'sha256':record['sha256'],'files':len(entries),'unchanged':True})
assert sum(r['files'] for r in preserved)==131
for path,expected in [(Path('/workspace/scratch/rct-validation/host_capacity_review/safe-review.zip'),'01689b255a8ae580a6bd1582c197fe8ab40579cbc72f1594549fe16e24a7a212'),(Path('/workspace/scratch/rct-validation/ci731_receipts/safe-receipts.zip'),'1fb8fe681df8b632750b8e37b391d3139c82efaef338891c46865f74039069eb')]:assert digest(path,path.lstat())==expected
result={'time':datetime.datetime.now(datetime.timezone.utc).isoformat(),'verdict_checks':'PASS_READ_ONLY_EXACT_STRICT_SELECTION','input_manifest_sha256':manifest_sha,'input_safe_files_verified':len(inputs),'inputs':inputs,'scopes':heads,'reference_head':'eec3e0a864626160d33ae29da2cf3b0640e30caa','reference_clean_before_after':True,'candidate_rows':len(rows),'unique_nlink1_inodes':len(seen),'independent_SHA_pairs':len(rows),'potential_allocated_bytes':1519378432,'unique_reference_inodes':len(references),'dynamic_ledger_aliases_verified':True,'all847_peer_excluded_paths_rejected':True,'actual_strict_filter_allrows_verified':True,'generated_headers_checked':header_checked,'mode_UID_GID_size_device_equal':True,'all_metadata_mtime_ctime_nlink_unchanged':True,'symlink_traversal_nonregular_excluded':True,'peer_overlap_rows':len(overlap),'peer_overlap_allocated_bytes':924459008,'preserved_safe_files':131,'preserved_manifests':preserved,'original_peer_CI_archives_unchanged':True,'actual_reclaimed_bytes':0,'resource_mutations':False,'own_processes_after_exit':[]}
(OUT/'independent-check.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k not in {'inputs','scopes','preserved_manifests'}}))
