"""Independent bounded source audit. No native helper imports or launches."""
import ast
import copy
import hashlib
import hmac
import json
import os
from pathlib import Path, PurePosixPath
import re
import stat
import subprocess
from types import SimpleNamespace
import zipfile

OWN = Path(__file__).resolve().parent
C = Path('/workspace/scratch/rct-validation/np01_broker_sensitivity_caller_correction')
O = Path('/workspace/scratch/rct-validation/np01_broker_sensitivity_sourceprep')
W = Path('/workspace/rct-worktrees/np01-broker-sensitivity')
R = Path('/workspace/rutcampustrack')
BASE = 'eb0e02aaf6c7cfb3b80db2d3a3c81b8a2dd79553'
checks = []
def check(name, passed):
    assert passed, name
    checks.append({'id': name, 'passed': True})
def sha(path):
    h = hashlib.sha256()
    with path.open('rb') as stream:
        while chunk := stream.read(32768):
            h.update(chunk)
    return h.hexdigest()
def save(name, data):
    p=OWN/name
    payload=json.dumps(data,indent=2)+'\n'
    if p.exists():
        assert p.read_text()==payload, 'Existing own partial changed'
        return
    with p.open('x') as f: f.write(payload)
    p.chmod(0o600)
def seal(directory, manifest, expected, archive, zip_expected):
    check('seal_'+directory.name, sha(directory/manifest)==expected)
    m=json.loads((directory/manifest).read_text())
    for row in m['entries']:
        p=directory/row['path']; s=p.lstat()
        check('sealed_member_'+directory.name+'_'+row['path'],
              stat.S_ISREG(s.st_mode) and stat.S_IMODE(s.st_mode)==0o600 and
              s.st_size==row['bytes'] and sha(p)==row['sha256'])
    check('zip_digest_'+directory.name, sha(directory/archive)==zip_expected)
    with zipfile.ZipFile(directory/archive) as z:
        check('zip_crc_'+directory.name,z.testzip() is None)
        check('zip_exact_names_'+directory.name,
              set(z.namelist())=={x['path'] for x in m['entries']}|{manifest} and
              len(z.namelist())==len(m['entries'])+1)
        for row in m['entries']:
            check('zip_member_'+directory.name+'_'+row['path'],
                  hashlib.sha256(z.read(row['path'])).hexdigest()==row['sha256'])
    return m
correction = seal(C,'manifest.safe.json','e1fd1f85bbd7afa727a036f920a61701140f262fe0cd3dd58873cf98e32cc61c',
                  'safe-caller-correction.zip','075a2b77ee06a8e5d051aba98ca1348c08d62e4595052a93f2fb4a1b105da9cc')
original = seal(O,'manifest.safe.json','37a7a45b6567a5ea23190e8a61e1a443942a41c0e1ce985b3f8618e5134d2ee9',
                'safe-sourceprep.zip','8384a33ae7cdaf43a7036d4fc0409cd96c412824ffab48c77834033c5771d313')
review=OWN.parent
check('original_review_immutable',sha(review/'manifest.json')=='ecc8cf5f9e022b419ee5620a69a334fa94b7d61da92297bb8307b5b4cf9901f1')
check('original_review_zip_immutable',sha(review/'safe-review.zip')=='c8dbf89e3991b84696dea3015cabd1856521d3371d0a6e12d9df687a48998d4f')

# Extract only closed pure definitions, never import the source module/helper.
b_tree=ast.parse((C/'caller-boundary.py').read_text())
pure_names={'safe_relative','pathset_hash','validate_ledger','validate_manifest_shape',
            'validate_body_identities','validate_child_witness','file_metadata'}
ns={'hashlib':hashlib,'hmac':hmac,'json':json,'PurePosixPath':PurePosixPath,'re':re,
    'stat':stat,'os':SimpleNamespace(getuid=os.getuid)}
nodes=[n for n in b_tree.body if isinstance(n,ast.Assign) or isinstance(n,ast.FunctionDef) and n.name in pure_names]
exec(compile(ast.Module(body=nodes,type_ignores=[]),'<review-pure-boundary>','exec'),ns)
ledger=json.loads((O/'complete-sparse-baseline.safe.json').read_text())
source=json.loads((O/'sourceprep.safe.json').read_text())
selected={x['path']:x for x in source['changes']}
grant={k:ns[v] for k,v in [('sourceprep_manifest_sha256','MANIFEST_SHA'),('baseline_sha256','BASELINE_SHA'),
      ('baseline_entry_count','COUNT'),('baseline_pathset_sha256','PATHSET_SHA'),('index_scope_sha256','INDEX_SHA')]}
def accepts(fn,*args):
    try: fn(*args); return True
    except (ValueError,KeyError,TypeError,OSError): return False
check('authentic_ledger',accepts(ns['validate_ledger'],ledger,grant))
check('authentic_manifest_shape',accepts(ns['validate_manifest_shape'],original))
variants={
 'empty':{'base':BASE,'entries':[]},
 'selected_only':{'base':BASE,'entries':[x for x in ledger['entries'] if x['path'] in selected]},
 'missing':copy.deepcopy(ledger),'extra':copy.deepcopy(ledger),'duplicate':copy.deepcopy(ledger),
 'unsafe':copy.deepcopy(ledger),'wrong_base':copy.deepcopy(ledger),
}
variants['missing']['entries'].pop()
variants['extra']['entries'].append(copy.deepcopy(ledger['entries'][0]))
variants['duplicate']['entries'][-1]=copy.deepcopy(ledger['entries'][0])
variants['unsafe']['entries'][0]['path']='../unowned'
variants['wrong_base']['base']='0'*40
for name,data in variants.items():check('ledger_reject_'+name,not accepts(ns['validate_ledger'],data,grant))
for key in grant:
    bad=grant|{key:0 if isinstance(grant[key],int) else '0'*64}
    check('grant_reject_'+key,not accepts(ns['validate_ledger'],ledger,bad))
for unsafe in ['', '.', '/absolute', 'a/../b', 'a//b', 'a/./b','a\\b','a\x00b']:
    check('unsafe_relative_'+repr(unsafe),not ns['safe_relative'](unsafe))
for variant in [{'entries':[]},{'entries':original['entries'][:-1]},
                {'entries':original['entries'][:-1]+[original['entries'][0]]}]:
    check('manifest_reject_shape_'+str(len(checks)),not accepts(ns['validate_manifest_shape'],variant))

env={'PATH':'/usr/local/bin:/usr/bin:/bin','LANG':'C.UTF-8','LC_ALL':'C.UTF-8','GIT_OPTIONAL_LOCKS':'0'}
def git(*args):return subprocess.check_output(['git','-C',str(W),*args],env=env,stderr=subprocess.DEVNULL,timeout=15)
check('actual_detached_EB_HEAD',git('rev-parse','HEAD').strip().decode()==BASE)
detached=subprocess.run(['git','-C',str(W),'symbolic-ref','-q','HEAD'],env=env,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,timeout=15).returncode
check('actual_detached',detached==1)
index=git('ls-files','--stage','-z')
check('actual_logical_index_sha',hashlib.sha256(index).hexdigest()==ns['INDEX_SHA'])
indexed=[x.split(b'\t',1)[1].decode() for x in index.split(b'\0') if x]
present=[n for n in indexed if os.path.lexists(W/n)]
check('actual_populated_1945_unique_exact',len(present)==1945 and set(present)=={x['path'] for x in ledger['entries']})
check('actual_untracked_nonignored_empty',not git('ls-files','--others','--exclude-standard','-z'))
current={}; metadata=[]; protected=[]
for row in ledger['entries']:
    path=W/row['path']; s=path.lstat()
    check('metadata_'+row['path'],stat.S_ISREG(s.st_mode) and stat.S_IMODE(s.st_mode)==0o600 and
          s.st_nlink==1 and s.st_uid==os.getuid() and not any(p.is_symlink() for p in path.parents) and
          (row['path'] in selected or s.st_size==row['bytes']))
    metadata.append({'path':row['path'],'mode':'0600','nlink':s.st_nlink,'uid':s.st_uid,'bytes':s.st_size})
    if row['path'] in ns['METADATA_ONLY']:
        protected.append(metadata[-1]);continue
    actual=sha(path)
    expected=selected[row['path']]['candidate_sha256'] if row['path'] in selected else row['sha256']
    check('body_'+row['path'],actual==expected)
    current[row['path']]=actual
check('1942_actual_body_hashes',len(current)==1942)
check('three_metadata_only_no_body_read',len(protected)==3)
check('actual_complete_bodies_predicate',accepts(ns['validate_body_identities'],ledger['entries'],selected,current))
check('dirty_unselected_body_rejected',not accepts(ns['validate_body_identities'],ledger['entries'],selected,current|{'gradlew':'0'*64}))
for name,entry in selected.items():check('Root_selected_normal_unchanged_'+name,sha(R/name)==entry['base_sha256'])
procedure=json.loads((C/'native-procedure.safe.json').read_text())
old_procedure=json.loads((O/'native-procedure.safe.json').read_text())
check('native_compile_and_fault_commands_unchanged',procedure['commands']==old_procedure['commands'])
check('ignored_outputs_exact_7',len(procedure['generated_ignored_outputs'])==7 and
      all(not os.path.lexists(W/n) for n in procedure['generated_ignored_outputs']))
check('build_outputs_absent',not (W/'services/academic-service/academic-app/build').exists())
save('actual-source-closure.safe.json',{'status':'PASS_SOURCE_ONLY','metadata_count':len(metadata),'body_hash_count':len(current),
      'selected_mutants':[{k:e[k] for k in ('path','base_sha256','candidate_sha256')} for e in source['changes']],
      'protected_metadata_only':protected,'protected_body_or_fresh_hash_reads':False,'detached_EB':True,
      'logical_index_sha256':hashlib.sha256(index).hexdigest(),'source_mutation':False,'native':'NOT_RUN'})

# Exact corrected predicate, fixed public control token only. Never real nonce generation.
p={'pid':101,'birth':1001}; child={'pid':102,'birth':1002}; token='0'*64; driver='1'*64
witness={'guard_started':True,'parent_pid':101,'parent_birth':1001,'child_pid':102,'child_birth':1002,
         'nonce':token,'phase':'compile','driver_sha256':driver}
def admit(w=witness,parent=p,c=child,nonce=token,phase='compile',identity=driver,outer=True):
    return accepts(ns['validate_child_witness'],w,parent,c,nonce,phase,identity,outer)
check('valid_exact_parent_child_witness',admit())
for name,kwargs in [('empty',{'w':{}}),('missing_nonce',{'nonce':None}),('wrong_nonce',{'nonce':'2'*64}),
 ('parent_pid',{'parent':p|{'pid':103}}),('parent_birth',{'parent':p|{'birth':999}}),
 ('child_pid',{'c':child|{'pid':103}}),('child_birth',{'c':child|{'birth':999}}),
 ('not_STARTED',{'w':witness|{'guard_started':False}}),('wrong_phase',{'phase':'fault'}),
 ('driver_change',{'identity':'3'*64}),('internal_parent',{'outer':False})]:
    check('child_reject_'+name,not admit(**kwargs))

d_tree=ast.parse((C/'run-stage.py').read_text())
defs={n.name:n for n in d_tree.body if isinstance(n,ast.FunctionDef)}
main=defs['main']; early=next(n for n in main.body if isinstance(n,ast.If) and 'args.child and' in ast.unparse(n.test))
grant_call=next(n for n in ast.walk(main) if isinstance(n,ast.Call) and isinstance(n.func,ast.Name) and n.func.id=='grant_input')
check('missing_nonce_rejection_before_preflight',early.lineno<grant_call.lineno)
branch=next(n for n in main.body if isinstance(n,ast.If) and ast.unparse(n.test)=='args.child')
branch_text=ast.unparse(branch)
validate=next(n.lineno for n in ast.walk(branch) if isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute) and n.func.attr=='validate_child_witness')
consume=next(n.lineno for n in ast.walk(branch) if isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute) and n.func.attr=='unlink')
execute=next(n.lineno for n in ast.walk(branch) if isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute) and n.func.attr=='execvpe')
check('witness_admission_consume_before_exec',validate<consume<execute)
check('actual_getppid_getpid_and_live_proc_birth_source',all(s in branch_text for s in ['os.getppid()', 'os.getpid()', "fields[0] == 'Z'",'int(fields[19])',"b'--child' not in parent_argv"]))
check('witness_private_metadata_before_body',branch_text.index('boundary.file_metadata')<branch_text.index('witness_path.read_text'))
check('witness_bounded_2048_bytes','st_size > 2048' in branch_text)
environment_ns={}
exec(compile(ast.Module(body=[defs['environment']],type_ignores=[]),'<review-environment>','exec'),environment_ns)
check('closed_Gradle_ENV_strips_nonce','NP01_CALLER_NONCE' not in environment_ns['environment']('CONTROL_DIR'))
status=next(n for n in main.body if isinstance(n,ast.FunctionDef) and n.name=='status')
started=next(n for n in status.body if isinstance(n,ast.If))
check('witness_created_only_STARTED',ast.unparse(started.test)=="value['state'] == 'STARTED'")
check('STARTED_direct_parent_birth_fields',all(s in ast.unparse(started) for s in ['child[\'ppid\'] != os.getpid()',"parent['start_ticks']","child['start_ticks']"]))
guardtry=next(n for n in main.body if isinstance(n,ast.Try))
check('finally_unconsumed_witness_and_environment_cleanup',all(s in ast.unparse(guardtry.finalbody[0])+' '+ast.unparse(guardtry.finalbody[1]) for s in ['witness_path.unlink()',"launch_environment.pop('NP01_CALLER_NONCE', None)"]))
grant_source=ast.unparse(defs['grant_input'])
check('actual_self_source_grant_before_boundary_exec',grant_source.index("grant['driver_sha256']")<grant_source.index('exec_module'))
check('actual_boundary_hash_before_boundary_exec',grant_source.index("grant['boundary_sha256']")<grant_source.index('exec_module'))
check('b78_and_c61_digest_checks_before_boundary_exec',all(grant_source.index(s)<grant_source.index('exec_module') for s in ['digest(GUARD)', 'digest(GUARD_REVIEW)']))
check('fresh_review_Root_attestation_before_boundary_exec',grant_source.index("grant['caller_source_review_approved']")<grant_source.index('exec_module'))
check('guard_digest_b78_immutable',sha(Path('/workspace/scratch/rct-validation/guard_proc_race_correction/bounded-child.py'))=='b78c61293568d9941692e0b92ee34fd0b84db6d532b4a2c9a5ad42ccbf2204a0')
check('c61_review_immutable',sha(Path('/workspace/scratch/rct-validation/guard_vue_current_review/immutable-review-manifest.json'))=='c61b4647f8467726d2fdc308c2fb046fa1e3552c99e2b2294f1c8524c1c6fb36')

# Execute the actual child branch with all I/O/exec replaced by virtual stubs.
class VPath:
    def __init__(self,name):self.name=str(name)
    def __truediv__(self,name):return VPath(self.name+'/'+str(name))
    def resolve(self):return self
    def __str__(self):return self.name
    def is_dir(self):return True
    def stat(self):return SimpleNamespace(st_size=512)
    def read_text(self):
        if self.name.endswith('parent-handshake.private.json'):
            if not state['record']:raise FileNotFoundError()
            return json.dumps(witness)
        pid=int(self.name.split('/')[-2]);tick=1001 if pid==101 else 1002
        fields=['S','101']+['0']*17+[str(tick)]
        return str(pid)+' (control) '+' '.join(fields)
    def read_bytes(self):return b'python\x00CONTROL_DRIVER\x00compile\x00'
    def unlink(self):state['record']=False;state['events'].append('CONSUMED')
state={'record':True,'events':[]}
fake_os=SimpleNamespace(getppid=lambda:101,getpid=lambda:102,environ={'NP01_CALLER_NONCE':token},
 O_WRONLY=1,O_CREAT=2,O_EXCL=4,open=lambda *a:state['events'].append('LOG_OPEN') or 99,
 dup2=lambda *a:None,close=lambda *a:None,chdir=lambda *a:None,
 execvpe=lambda *a:state['events'].append('EXEC') or None)
fake_boundary=SimpleNamespace(file_metadata=lambda *a:None,validate_child_witness=ns['validate_child_witness'])
def child_branch():
    exec(compile(ast.Module(body=branch.body,type_ignores=[]),'<actual-child-with-virtual-IO>','exec'),
         {'directory':VPath('CONTROL_DIR'),'HERE':VPath('CONTROL_HERE'),'Path':VPath,'__file__':'CONTROL_DRIVER',
          'json':json,'os':fake_os,'boundary':fake_boundary,'args':SimpleNamespace(phase='compile'),
          'digest':lambda p:driver,'argv':['CONTROL_NATIVE'],'environment':environment_ns['environment'],'WT':'CONTROL_WT'})
child_branch()
check('actual_child_virtual_consumes_before_exec',state['events']==['CONSUMED','LOG_OPEN','EXEC'])
state['events']=[]
check('actual_child_virtual_replay_rejected',not accepts(child_branch))
check('actual_child_virtual_replay_no_exec',not state['events'])
save('independent-checks.safe.json',{'status':'PASS_SOURCE_ONLY','checks':checks,'check_count':len(checks),
     'helper_imports':False,'runtime_or_native_execution':False,'real_nonce_generated_read_or_hashed':False,
     'controls':'AST-extracted pure definitions and actual child branch with virtual I/O/exec; only readonly Git subprocesses.',
     'live_handshake':'NOT_RUN','same_UID':'Accidental-bypass containment only, no cryptographic/OS isolation.'})
print(json.dumps({'status':'PASS_SOURCE_ONLY','checks':len(checks),'metadata':1945,'fresh_body_hashes':1942,
                 'protected_body_reads':False,'native':'NOT_RUN'}))
