"""Actual old/new source evaluated with public RAM-only paths/proc/clock/resources; no target imports."""
import ast
import datetime
import json
from pathlib import Path
import stat
import types

OLD = Path('/workspace/scratch/rct-validation/client_real_acceptance/focused3-next96/run-focus3.py')
NEW = Path(__file__).with_name('run-focus3.py')
SERVICES = ['mongo', 'academic', 'auth', 'schedule', 'attendance', 'bff', 'gateway', 'notification']


def control(source, variant, parent_exists=False, full_namespace=False):
    tree = ast.parse(source.read_text())
    functions = {n.name: n for n in tree.body if isinstance(n, ast.FunctionDef)}
    rows = [{'service': name, 'wrapper_pid': 100 + i * 2, 'wrapper_birth_ticks': 1000 + i * 2,
             'child_pid': 101 + i * 2, 'child_birth_ticks': 1001 + i * 2} for i, name in enumerate(SERVICES)]
    if variant == 'duplicate':
        rows = [{**row, 'wrapper_pid': 100, 'wrapper_birth_ticks': 1000, 'child_pid': 101, 'child_birth_ticks': 1001} for row in rows]
    bound = {'schema': 'RCT_FOCUS3_CURRENT96_COHORT_BIND_V1', 'cohort': 'public-new', 'ready_sha256': 'public-sha',
             'execution_checkout_sha': 'public-revision', 'current_academic_source_sha256': 'public-academic',
             'current_academic_payload_source_verified': variant != 'bad-source', 'critical_TLS_Admin_FULL_edge_directspoof': True,
             'host_cleanup_dispatch_at': '2026-01-01T00:01:10Z', 'receipts': {k: {'path': '/public/' + k, 'sha256': 'public-sha'}
             for k in ['artifact_source', 'runtime_mapping', 'critical_readiness', 'host_live8']}, 'live8': rows}
    proc = {}
    for row in rows:
        for kind in ['wrapper', 'child']:
            fields = ['S', str(row['wrapper_pid'] if kind == 'child' else 1)] + ['0'] * 17 + [str(row[kind + '_birth_ticks'])]
            if variant == 'wrong-ppid' and kind == 'child':
                fields[1] = '999'
            if variant == 'zombie' and kind == 'child':
                fields[0] = 'Z'
            proc['/proc/' + str(row[kind + '_pid']) + '/stat'] = str(row[kind + '_pid']) + ' (public) ' + ' '.join(fields)
    events = {'mkdir': 0}

    class RAMPath:
        def __init__(self, *values):
            self.value = '/'.join(str(v) for v in values)
        def __truediv__(self, value):
            return RAMPath(self.value + '/' + value)
        def is_absolute(self):
            return self.value.startswith('/')
        def exists(self):
            return parent_exists
        def mkdir(self, **kwargs):
            events['mkdir'] += 1
        def lstat(self):
            return types.SimpleNamespace(st_mode=stat.S_IFDIR | 0o700, st_uid=1000)
        def is_symlink(self):
            return False
        def read_text(self):
            if self.value == '/public/bind':
                return json.dumps(bound)
            return proc.get(self.value, {'/sys/fs/cgroup/memory.current': '1', '/sys/fs/cgroup/memory.max': '17179869184',
                                       '/proc/self/status': 'VmRSS: 1 kB\n'}.get(self.value))

    class Clock(datetime.datetime):
        @classmethod
        def now(cls, zone):
            return datetime.datetime(2026, 1, 1, 0, 0, 9, tzinfo=zone)

    grant = {'stand_ready_receipt': '/public/bind', 'stand_ready_receipt_sha256': 'public-sha', 'cohort': 'public-new',
             'execution_checkout_sha': 'public-revision', 'stand_cleanup_at': '2026-01-01T00:01:10Z',
             'disk_floor_bytes': 4294967296, 'shared_stop_bytes': 16106127360, 'shared_memory_reserve_bytes': 1073741824,
             'owned_total_rss_stop_bytes': 1610612736, 'issued_at': '2026-01-01T00:00:00Z'}
    env = {'Path': RAMPath, 'json': json, 'digest': lambda p: 'public-sha', 'BASE': RAMPath('/public/base'),
           'datetime': types.SimpleNamespace(datetime=Clock), 'UTC': datetime.timezone.utc, 'stat': stat,
           'os': types.SimpleNamespace(geteuid=lambda: 1000, statvfs=lambda p: types.SimpleNamespace(f_bavail=17179869184, f_frsize=1)),
           'grant': grant, 'ready': {'current_academic_source': {'sha256': 'public-academic'}},
           'stop': datetime.datetime(2026, 1, 1, 0, 0, 10, tzinfo=datetime.timezone.utc), 'attempt': 'attempt-01'}
    selected = [functions[n] for n in ['require', 'instant', 'private_directory', 'fresh_preflight', 'fresh_cohort']]
    exec(compile(ast.fix_missing_locations(ast.Module(body=selected, type_ignores=[])), 'selected-source-functions', 'exec'), env)
    if full_namespace:
        body = functions['main'].body
        start = next(i for i, n in enumerate(body) if isinstance(n, ast.Assign) and isinstance(n.targets[0], ast.Name) and n.targets[0].id == 'runs')
        end = next(i for i, n in enumerate(body) if isinstance(n, ast.Assign) and isinstance(n.targets[0], ast.Name) and n.targets[0].id == 'supervision')
        selected_body = body[start:end]
    else:
        selected_body = ast.parse('fresh_cohort(grant, ready)').body
    deny = None
    try:
        exec(compile(ast.fix_missing_locations(ast.Module(body=selected_body, type_ignores=[])), 'selected-full-namespace-path', 'exec'), env)
    except RuntimeError as error:
        value = error.args[0] if len(error.args) == 1 else None
        deny = value if value in {'LIVE16_DISTINCT_REQUIRED', 'STAND_CHILD_PARENT_MISMATCH', 'STAND_BIRTH_NOT_LIVE', 'CURRENT_COHORT_UNBOUND'} else 'OTHER'
    return {'accepted': deny is None, 'denyStage': deny, 'mkdir': events['mkdir']}


def main():
    old_duplicate, new_duplicate = (control(p, 'duplicate') for p in [OLD, NEW])
    old_wrong, new_wrong = (control(p, 'wrong-ppid') for p in [OLD, NEW])
    old_existing, new_existing = (control(p, 'zombie', True, True) for p in [OLD, NEW])
    new_absent_dead = control(NEW, 'zombie', False, True)
    new_existing_valid = control(NEW, 'valid', True, True)
    new_absent_valid = control(NEW, 'valid', False, True)
    checks = {'oldDuplicateAccepted': old_duplicate['accepted'], 'newDuplicateDeniedSpecific': new_duplicate['denyStage'] == 'LIVE16_DISTINCT_REQUIRED',
              'oldWrongPPIDsAccepted': old_wrong['accepted'], 'newWrongPPIDsDeniedSpecific': new_wrong['denyStage'] == 'STAND_CHILD_PARENT_MISMATCH',
              'validDistinct16Accepted': control(NEW, 'valid')['accepted'], 'zombieStillDenied': control(NEW, 'zombie')['denyStage'] == 'STAND_BIRTH_NOT_LIVE',
              'badSourceStillDenied': control(NEW, 'bad-source')['denyStage'] == 'CURRENT_COHORT_UNBOUND',
              'oldExistingParentMutatesFive': old_existing['accepted'] and old_existing['mkdir'] == 5,
              'newExistingParentDeadDeniedZero': new_existing['denyStage'] == 'STAND_BIRTH_NOT_LIVE' and new_existing['mkdir'] == 0,
              'newAbsentParentDeadDeniedZero': new_absent_dead['denyStage'] == 'STAND_BIRTH_NOT_LIVE' and new_absent_dead['mkdir'] == 0,
              'newExistingParentValidFive': new_existing_valid['accepted'] and new_existing_valid['mkdir'] == 5,
              'newAbsentParentValidSix': new_absent_valid['accepted'] and new_absent_valid['mkdir'] == 6}
    print(json.dumps({'schema': 'RCT_F3_NEXT96_CORRECTION_SOURCE_CONTROLS_V1', 'checks': checks, 'passed': all(checks.values()),
                      'qualification': 'PURE_ACTUAL_SELECTED_FUNCTIONS_AND_FULL_NAMESPACE_PATH_RAM_ONLY', 'actual_stand_Node_browser_API': 'NOT_RUN'}))
    return 0 if all(checks.values()) else 1


if __name__ == '__main__':
    try:
        raise SystemExit(main())
    except Exception:
        print('{"state":"SOURCE_ADAPTER_CONTROL_FAILED","raw_error_emitted":false}')
        raise SystemExit(2)
