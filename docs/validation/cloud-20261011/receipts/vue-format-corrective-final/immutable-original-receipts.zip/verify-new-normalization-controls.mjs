import fs from 'node:fs'
import { createHash } from 'node:crypto'
import { createRequire } from 'node:module'
const require=createRequire('/workspace/rutcampustrack/frontends/package.json')
const {toDisplayString}=require('vue')
process.argv[2]='library'
const {vue,firstDelta}=await import('../prettier-final/verify-meaning.mjs')
const scratch='/workspace/scratch/rct-validation/authored_format_current/vue-eslint-correction'
const program=fs.readFileSync(`${scratch}/probe-block-pipeline.mjs`,'utf8')
const section=program.slice(program.indexOf('function foldConstantDisplay'),program.indexOf('const rows='))
const {normalizeConstantDisplay}=new Function(section+';return {normalizeConstantDisplay}')()
const compare=async(a,b)=>firstDelta(normalizeConstantDisplay(await vue(a,'control.vue')),normalizeConstantDisplay(await vue(b,'control.vue')))===null
const sfc=template=>`<template>${template}</template>`
const rows=[]
rows.push({name:'exact static constant preserves UTF-8 and boundary spaces',pass:await compare(sfc('<p> Помощник группы </p>'),sfc("<p>{{ ' Помощник группы ' }}</p>"))})
rows.push({name:'trimmed constant must change meaning',pass:!await compare(sfc('<p> Помощник группы </p>'),sfc("<p>{{ 'Помощник группы' }}</p>"))})
rows.push({name:'changed literal wording must change meaning',pass:!await compare(sfc('<p> Помощник группы </p>'),sfc("<p>{{ ' Староста группы ' }}</p>"))})
rows.push({name:'dynamic interpolation cannot fold',pass:!await compare(sfc('<p>Помощник</p>'),sfc('<p>{{ message }}</p>'))})
const ast=(source='vue',args=[{type:'StringLiteral',value:' x '}])=>({template:{render:{program:{body:[
 {type:'ImportDeclaration',source:{type:'StringLiteral',value:source},specifiers:[{type:'ImportSpecifier',local:{type:'Identifier',name:'display'},imported:{type:'Identifier',name:'toDisplayString'}}]},
 {type:'ExpressionStatement',expression:{type:'CallExpression',callee:{type:'Identifier',name:'display'},arguments:args}},
]}}}})
const expression=x=>x.template.render.program.body[1].expression
rows.push({name:'native Vue display helper string-only fold',pass:expression(normalizeConstantDisplay(ast())).type==='StringLiteral'})
rows.push({name:'other module helper cannot fold',pass:expression(normalizeConstantDisplay(ast('other'))).type==='CallExpression'})
rows.push({name:'two arguments cannot fold',pass:expression(normalizeConstantDisplay(ast('vue',[{type:'StringLiteral',value:'x'},{type:'StringLiteral',value:'y'}]))).type==='CallExpression'})
for(const type of ['Identifier','NumericLiteral','BooleanLiteral','ObjectExpression'])rows.push({name:`non-string ${type} cannot fold`,pass:expression(normalizeConstantDisplay(ast('vue',[{type,name:'value',value:1}]))).type==='CallExpression'})
const flag=ast();flag.template.render.program.body[1].expression={
 type:'CallExpression',callee:{type:'Identifier',name:'createElementVNode'},arguments:[
  {type:'StringLiteral',value:'p'},{type:'NullLiteral'},expression(flag),{type:'NumericLiteral',value:1},
 ]}
const flagChanged=structuredClone(flag);flagChanged.template.render.program.body[1].expression.arguments[3].value=0
rows.push({name:'render flags remain significant',pass:JSON.stringify(normalizeConstantDisplay(flag))!==JSON.stringify(normalizeConstantDisplay(flagChanged))})
const values=[' x ','Помощник группы',' → Архив','Учебные данные: ','28 сент.','%', '\u00a0'];
rows.push({name:'actual pinned Vue runtime preserves exact constant strings',pass:values.every(v=>toDisplayString(v)===v)})
const result={normalization_program_sha256:createHash('sha256').update(section).digest('hex'),controls:rows.length,passed:rows.filter(r=>r.pass).length,rows}
fs.writeFileSync(`${scratch}/new-normalization-controls.safe.json`,JSON.stringify(result,null,2)+'\n',{mode:0o600})
console.log(JSON.stringify({controls:result.controls,passed:result.passed}))
if(rows.some(r=>!r.pass))process.exitCode=1
