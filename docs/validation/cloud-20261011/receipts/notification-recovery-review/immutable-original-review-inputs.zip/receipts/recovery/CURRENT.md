# Recovery/P20 controlled failure boundaries

Updated 2026-10-11T22:24:54.791329+00:00. TEST_ONLY_SOURCE_READY_FOR_FRESH_REVIEW.

Assigned sole writer /workspace/rct-worktrees/recovery, branch codex/rct-validation-recovery-20261011, base232f0210ab65a6750b120e811d81f0e110b9e107, stable clean commitbd430a37e689a523a227ac85b7ac0c4018629efb. Prior DATA3 c115 immutable, untouched. Requested Sol6.1/high; actual metadata UNKNOWN.

Created only scripts/test-recovery-failure-boundaries.py. Product recovery.py unchanged SHA289df762c439a4f10c428f9ceb53b48b6424d3ed926754a6195618c4ccaab9c2; test SHA2b6096ac265b66bd2f59b5b2bb2c4926f90175164735f42eac1b816c78b0c1f5. Original prepared snapshots preserved. Narrow oracle corrections use actual check_targets with controlled metadata and separate Schedule/Mongo states; partial Schedule bytes retained.

LIGHT2 authorization completed: python3 scripts/test-recovery-failure-boundaries.py -v actual control and restored final exit0, 2 methods / three preflight subcases / no skips. Four selected in-memory mutations each fail on intended assertion, no infra errors; product source bytes unchanged. Repeat reason: final control after sensitivity. See light-run-1/run.json, light-final-1/run.json, light-sensitivity-1/run.json and review-packet.json. Raw stdout includes production PASS backup from controlled seam; this is NOT native backup acceptance.

Partial dump + absent manifest + same-path retry/no overwrite + new-path controlled bundle PASS at controlled-function level. Nonempty Schedule/Mongo/wrong-label refusal before native writes PASS at same level. No actual Docker/native tools/Gradle/apps used. Current native/schema/application readback remains UNKNOWN; RECOVERY1 lease queued. Genuine historical Oct3 app recovery retained, 5 unchanged tool source files reusable, 12 migrations/3 consumers require current readback.

All placeholder bundles including mutations retained under .agent/evidence/recovery-validation/guard-unit-*; safe paths/sizes/hashes in controlled-artifacts.json. No credentials read, no backup/data deletion, no live processes/ports/containers/networks/volumes owned. Normal git commit exit0; local pre-commit hook absent, root integration needs repository gates.

Next: root assigns fresh read-only reviewer from stable diff/review-packet; native or app execution only after separate measured RECOVERY1 admission. Do not infer family/global operational readiness from these controlled tests.
