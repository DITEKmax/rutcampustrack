"""One bounded public loader/dlopen check; only a recorded parent may invoke."""
import argparse
import ctypes
import hashlib
import json
import os
from pathlib import Path
import re
import stat
import subprocess
import types

OWN = Path(__file__).parent
CACHE = Path('/tmp/rct-validation-browsers-20261012/webkit-2272')
PREFIX = Path('/tmp/rct-webkit-native-deps-20261012')
X264 = Path('/usr/lib/x86_64-linux-gnu/libx264.so.164')

def sha(p):
    h=hashlib.sha256()
    with Path(p).open('rb') as f:
        for block in iter(lambda:f.read(1048576),b''):h.update(block)
    return h.hexdigest()

def start_ticks(pid):
    value = Path('/proc/' + str(pid) + '/stat').read_text()
    return int(value[value.rfind(')')+2:].split()[19])

def environment(variant):
    env = {'PATH': '/usr/bin:/bin', 'LANG': 'C', 'LC_ALL': 'C'}
    paths = [PREFIX / 'usr/lib/x86_64-linux-gnu']
    if variant in {'minibrowser-wpe', 'minibrowser-gtk'}:
        base = CACHE / variant
        paths = [base / 'lib', base / 'sys/lib', *paths]
    elif variant != 'package':
        raise ValueError('Exact native variant required')
    env['LD_LIBRARY_PATH'] = ':'.join(map(str, paths))
    return env

def classify_loader(completed):
    text = completed.stdout.decode('utf-8', errors='replace')
    if len(completed.stdout) > 262144:
        raise ValueError('Public loader output cap')
    missing = sorted(set(re.findall(r'([A-Za-z0-9_.+-]+)\s*=>\s*not found', text)+re.findall(r'error while loading shared libraries:\s*([A-Za-z0-9_.+-]+)',text)))
    versions_bad = 'no version information available' in text or bool(re.search(r'version[^\n]*not found', text))
    paths = []
    for match in re.finditer(r'([A-Za-z0-9_.+-]+)\s*=>\s*(/[^\s]+)\s*\(', text):
        name, raw = match.groups()
        path = Path(raw).resolve(strict=True)
        if not (str(path).startswith(('/usr/lib/', '/lib/', str(CACHE)+'/', str(PREFIX)+'/'))):
            raise ValueError('Unexpected nonpublic loader path')
        if not path.is_file():
            raise ValueError('Resolved regular public DSO required')
        paths.append({'soname': name, 'path': str(path), 'sha256': sha(path)})
    return {'pass': completed.returncode == 0 and bool(paths) and not missing and not versions_bad,
            'native_exit': completed.returncode, 'missing_sonames': missing,
            'version_error_or_warning': versions_bad, 'resolved_public_dsos': paths,
            'raw_output_not_saved_or_published': True}

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--kind', choices=['loader', 'gles', 'x264'], required=True)
    parser.add_argument('--target', required=True)
    parser.add_argument('--variant', required=True)
    parser.add_argument('--result', required=True)
    parser.add_argument('--parent-pid', type=int, required=True)
    parser.add_argument('--parent-ticks', type=int, required=True)
    parser.add_argument('--source-manifest-sha256', required=True)
    args = parser.parse_args()
    if (os.getuid() != 1000 or os.getgid() != 1000 or os.getppid() != args.parent_pid
            or start_ticks(args.parent_pid) != args.parent_ticks):
        raise RuntimeError('Exact live native caller parent required')
    output = Path(args.result)
    if (output.parent.parent != OWN / 'runtime' or not re.fullmatch(r'native-[a-z0-9-]{1,32}', output.parent.name)
            or not re.fullmatch(r'probe-[0-9]{2}\.safe\.json', output.name)):
        raise RuntimeError('Exact caller output namespace required')
    manifest=OWN/'manifest.json'
    if sha(manifest)!=args.source_manifest_sha256:
        raise RuntimeError('Exact native parent source authority required')
    source_rows=json.loads(manifest.read_text())['files']
    if not any(r['path']==str(Path(__file__).absolute()) and r['sha256']==sha(__file__) for r in source_rows):
        raise RuntimeError('Actual native child source must be sealed')
    for row in source_rows:
        if sha(row['path'])!=row['sha256']:
            raise RuntimeError('Native child helper source changed')
    paths = types.ModuleType('own_paths'); paths.__file__ = str(OWN/'own-paths.py')
    exec(compile((OWN/'own-paths.py').read_bytes(), paths.__file__, 'exec'), paths.__dict__)
    destination = paths.Output(output.parent)
    launch=json.loads((output.parent/'launch.safe.json').read_text())
    if (launch['parent_identity']['pid']!=args.parent_pid or launch['parent_identity']['start_ticks']!=args.parent_ticks
            or launch['source_manifest_sha256']!=args.source_manifest_sha256):
        destination.close()
        raise RuntimeError('Exact granted recorded native parent identity required')
    target = Path(args.target)
    try:
        if args.kind == 'loader':
            allowed = json.loads((OWN / 'native-validation-procedure.safe.json').read_text())['upstream25_ELF_4shell']
            selected = json.loads((OWN / 'selected-dso-headers.safe.json').read_text())['selected']
            targets = {r['path'] for r in allowed if r['elf']} | {str(PREFIX / r['name']) for r in selected if r['kind'] == 'regular'}
            if str(target) not in targets:
                raise RuntimeError('Exact25vendor or14package ELF required')
            result = subprocess.run(['/lib64/ld-linux-x86-64.so.2', '--list', str(target)],
                                    env=environment(args.variant), stdout=subprocess.PIPE,
                                    stderr=subprocess.STDOUT, timeout=15, check=False)
            value = classify_loader(result)
            versions=subprocess.run(['/usr/bin/readelf','--version-info','--wide',str(target)],env={'PATH':'/usr/bin:/bin','LANG':'C','LC_ALL':'C'},stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=5,check=False)
            if len(versions.stdout)>262144:raise ValueError('Public ELF versionmetadata cap')
            version_names=sorted(set(re.findall(r'Name:\s*([A-Za-z0-9_.+-]+)',versions.stdout.decode('utf-8',errors='replace'))))
            value.update({'ELF_version_metadata_native_exit':versions.returncode,'public_version_names':version_names})
            value['pass']=value['pass'] and versions.returncode==0
        else:
            expected = PREFIX / 'usr/lib/x86_64-linux-gnu/libGLESv2.so.2' if args.kind == 'gles' else X264
            if target != expected:
                raise RuntimeError('Exact public capability target required')
            handle = ctypes.CDLL(str(target), mode=os.RTLD_NOW | os.RTLD_LOCAL)
            symbol = 'glGetString' if args.kind == 'gles' else 'x264_encoder_open_164'
            value = {'pass': bool(getattr(handle, symbol)), 'actual_dlopen': True,
                     'public_symbol_present': symbol, 'GL_context_encoding_or_browser': 'NOT_RUN'}
    except (OSError,subprocess.TimeoutExpired,ValueError) as caught:
        value={'pass':False,'kind':args.kind,'error_type':type(caught).__name__,'raw_native_message_published':False}
    try:
        destination.save(output.name, value, new=True)
    finally:
        destination.close()

if __name__ == '__main__':
    main()
