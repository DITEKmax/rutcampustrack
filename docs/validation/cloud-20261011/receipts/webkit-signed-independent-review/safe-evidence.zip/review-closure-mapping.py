"""Read public dpkg status and exercise only the nonlaunching pure prototype."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess

OUT = Path(__file__).parent
PLAN = Path('/workspace/scratch/rct-validation/browser_webkit_signed_plan')
ENV = {'PATH':'/usr/bin:/bin', 'LANG':'C', 'LC_ALL':'C'}
closure = json.loads((PLAN/'package-closure-plan.safe.json').read_text())['closure']
r = subprocess.run(['/usr/bin/dpkg-query', '-W', '-f', '${binary:Package}\t${Version}\t${Architecture}\t${Status}\t${Provides}\n'], env=ENV, capture_output=True, text=True, timeout=10)
assert r.returncode == 0
available = {}
provides = set()
host = []
for line in r.stdout.splitlines():
    fields = line.split('\t')
    if len(fields) == 5 and fields[3] == 'install ok installed':
        name, version, arch, _, provided = fields
        available[name.split(':')[0]] = version
        provides.update(p.split(' ')[0] for p in provided.split(', ') if p)
        host.append({'package':name,'version':version,'architecture':arch})
old = json.loads((PLAN/'host-installed-public-package-versions.safe.json').read_text())['packages']
assert sorted(host, key=lambda x:x['package']) == sorted(old, key=lambda x:x['package'])
available.update({row['package']:row['version'] for row in closure})
dependency_checks = []
for row in closure:
    for field in ('depends','pre_depends'):
        if not row[field]: continue
        for clause in row[field].split(', '):
            matched = []
            for alternative in clause.split(' | '):
                m = re.fullmatch(r'([a-z0-9+.-]+)(?::[a-z0-9-]+)?(?: \((<<|<=|=|>=|>>) ([^)]+)\))?', alternative)
                assert m, alternative
                name, operator, version = m.groups()
                if name in available:
                    ok = not operator or subprocess.run(['/usr/bin/dpkg','--compare-versions',available[name],operator,version],env=ENV,capture_output=True,timeout=5).returncode == 0
                    if ok: matched.append(name)
                elif name in provides and not operator:
                    matched.append(name+'(installed provider)')
            assert matched, (row['package'],clause)
            dependency_checks.append({'package':row['package'],'requirement':clause,'satisfied_by':matched})

namespace = {'__name__':'review_nonlaunching_prototype'}
source = (PLAN/'custom-executable-proposal.py').read_text()
exec(compile(source,str(PLAN/'custom-executable-proposal.py'),'exec'),namespace)
prepare = namespace['prepare_child']
required = {'all_upstream_ELF_closure', 'version_symbols', 'GLES_actual_dlopen','x264_actual_capability','package_signature_hashes_modes','cache_byte_identity'}
synthetic = {key:True for key in required}
checks = []
parent = dict(os.environ)
for args in [ ['--inspector-pipe','--headless','--no-startup-window','--proxy=http://127.0.0.1:1234','--ignore-host=a b'], ['--inspector-pipe','--user-data-dir=/tmp/review-public-path','about:blank'], ['--inspector-pipe','--proxy=http://x--headless-y','--no-startup-window'] ]:
    declared = {'PATH':'/usr/bin:/bin','LANG':'C','HOME':'/tmp/review-public-home'}
    original_env = dict(declared)
    original_args = list(args)
    executable, argv, child = prepare(args, declared, synthetic)
    assert argv[1:] == args and args == original_args and declared == original_env
    assert child['LD_LIBRARY_PATH'].split(':')[:2] == [str(Path(executable).parent.parent/'lib'), str(Path(executable).parent.parent/'sys/lib')]
    expected = 'minibrowser-wpe' if '--headless' in ' '.join(args) else 'minibrowser-gtk'
    assert expected in executable
    checks.append({'control':'original args/substring variant/library priority/inputs','pass':True})
for key in required:
    for value in [None,False,'true',1]:
        candidate = dict(synthetic)
        if value is None: candidate.pop(key)
        else: candidate[key] = value
        try: prepare(['--inspector-pipe'],{},candidate)
        except ValueError: checks.append({'control':'deny invalid validation '+key+' '+repr(value),'pass':True})
        else: raise AssertionError('Accepted invalid validation')
for key in ['LD_PRELOAD','LD_LIBRARY_PATH','JAVA_TOOL_OPTIONS','UNRELATED_CREDENTIAL','PLAYWRIGHT_SKIP_VALIDATE_HOST_REQUIREMENTS']:
    try: prepare(['--inspector-pipe'],{key:'public-synthetic'},synthetic)
    except ValueError: checks.append({'control':'deny forbidden ENV name '+key,'pass':True})
    else: raise AssertionError('Accepted forbidden env')
assert parent == dict(os.environ)
cache = Path('/tmp/rct-validation-browsers-20261012/webkit-2272')
upstream = []
for variant in ['minibrowser-wpe','minibrowser-gtk']:
    root = cache/variant
    for directory in [root,root/'bin',root/'lib',root/'sys/lib']:
        for path in sorted(directory.iterdir()):
            if path.is_file() and ('.so.' in path.name.lower() or path.name.lower().endswith('.so') or os.access(path,os.X_OK)):
                with path.open('rb') as f: elf = f.read(4) == b'\x7fELF'
                upstream.append({'path':str(path),'elf':elf,'sha256':hashlib.sha256(path.read_bytes()).hexdigest()})
assert sum(row['elf'] for row in upstream) == 25
result = {'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'current_public_host_versions_equal_author_snapshot':True,'signed_selected_dependency_clauses':dependency_checks,'pure_prototype_controls':checks,'pure_control_count':len(checks),'native_validation_inputs':'SYNTHETIC ONLY; NOT_RUN','parent_environment_equal_without_values_published':True,'upstream_selected_paths':upstream,'upstream_selected_count':len(upstream),'upstream_WebKit_ELF_count':25,'upstream_non_ELF_shell_wrappers':len(upstream)-25,'actual_package_payload_loader_GLES_x264_browser':'NOT_RUN'}
(OUT/'closure-mapping.safe.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'dependency_clauses':len(dependency_checks),'pure_controls':len(checks),'upstream_paths':len(upstream),'WebKit_ELFs':25,'all_native_runtime':'NOT_RUN'}))
