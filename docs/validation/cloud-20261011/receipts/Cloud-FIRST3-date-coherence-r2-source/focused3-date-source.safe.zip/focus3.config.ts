import { defineConfig } from '/workspace/rutcampustrack/tests/e2e/node_modules/@playwright/test';
import existing from '/workspace/rutcampustrack/tests/e2e/playwright.real-mobile.config';
import { readTeachingInstant } from '/workspace/rutcampustrack/tests/e2e/fixtures/teaching-clock';
import { lstatSync } from 'node:fs';
import { dirname, join } from 'node:path';

process.env.PLAYWRIGHT_NO_COPY_PROMPT = '1';

const root = '/workspace/scratch/rct-validation/client_real_acceptance/focused3-next96-date-r2';
const runRoot = '/workspace/scratch/rct-validation/client_real_acceptance/focused3-next96-date-r2';
const run = process.env.RCT_FOCUS3_RUN;
if (!run || !new RegExp(`^${runRoot}/runs/attempt-[0-9]{2}$`).test(run)) {
  throw new Error('Focused diagnostic requires a reviewed private run namespace');
}
for (const path of [run, join(run, 'artifacts'), join(run, 'supervision')]) {
  const info = lstatSync(path);
  if (!info.isDirectory() || info.isSymbolicLink() || (info.mode & 0o777) !== 0o700) {
    throw new Error('Focused diagnostic namespace must be a private directory');
  }
}
if (dirname(process.env.RCT_FOCUS3_OBSERVATIONS ?? '') !== join(run, 'supervision')) {
  throw new Error('Focused diagnostic observations must stay outside Playwright outputDir');
}
const teachingInstant = readTeachingInstant(
  '/workspace/scratch/rct-validation/current_host_config_v4/teaching-clock',
);

export default defineConfig<{}, { teachingInstant: Date | undefined }>({
  ...existing,
  testDir: root,
  testMatch: 'focus3.spec.ts',
  testIgnore: [],
  grep: /(?:STUDENT completion persists and another group cannot mutate the homework|HEADMAN marks the real roster and TEACHER reads without acquiring write permission|STUDENT helper marks with its capability and revocation denies the same effect)$/,
  outputDir: join(run, 'artifacts'),
  reporter: [['/workspace/rutcampustrack/tests/e2e/fixtures/safe-reporter.ts']],
  fullyParallel: false,
  workers: 1,
  retries: 0,
  forbidOnly: true,
  use: {
    ...existing.use,
    trace: 'off',
    video: 'off',
    screenshot: 'off',
    timezoneId: 'Europe/Moscow',
    teachingInstant,
  },
  projects: existing.projects
    ?.filter((project) => project.name === 'chromium')
    .map((project) => ({
      ...project,
      use: {
        ...project.use,
        trace: 'off',
        video: 'off',
        screenshot: 'off',
        timezoneId: 'Europe/Moscow',
        teachingInstant,
      },
    })),
});
