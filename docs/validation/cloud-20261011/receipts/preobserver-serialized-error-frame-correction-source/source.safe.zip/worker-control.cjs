const fs = require('node:fs'), path = require('node:path'), crypto = require('node:crypto'), cp = require('node:child_process');
const ts = require('/workspace/rutcampustrack/frontends/node_modules/typescript/lib/typescript.js');
const W = '/workspace/rct-worktrees/client-ci-first3/tests/e2e';
const marker = 'RCT_PUBLIC_WORKER_' + crypto.randomUUID();
const output = process.env.RCT_SAFE_FAILURE_CONTROL_OUTPUT;
const child = cp.spawnSync(process.execPath, ['--max-old-space-size=512', W + '/node_modules/playwright/cli.js', 'test', '--config', __dirname + '/worker-control.config.ts'], { cwd: W, encoding: 'utf8', timeout: 60000, env: { ...process.env, RCT_SAFE_FAILURE_CONTROL_MARKER: marker } });
function files(dir) { return fs.readdirSync(dir, { withFileTypes: true }).flatMap(x => x.isDirectory() ? files(path.join(dir, x.name)) : [path.join(dir, x.name)]); }
let report = null; try { report = JSON.parse(fs.readFileSync(path.join(output, 'safe-results.json'), 'utf8')); } catch {}
const artifactFiles = fs.existsSync(output) ? files(output) : [];
const outputs = artifactFiles.map(p => fs.readFileSync(p).toString());
const bodiesNotStarted = !artifactFiles.some(p => p.endsWith('body-started.safe.json'));
const markerAbsent = [child.stdout || '', child.stderr || '', ...outputs].every(x => !x.includes(marker));
const rows = Array.isArray(report?.results) ? report.results : [];
const failed = rows.length === 3 && rows.every(x => x.status === 'failed' && x.expectedStatus === 'failed' && x.errorCount > 0);
const source = fs.readFileSync(W + '/fixtures/safe-reporter.ts', 'utf8');
const parserDiagnosticCount = ts.createSourceFile('safe-reporter.ts', source, ts.ScriptTarget.ES2022, true).parseDiagnostics.length;
const box = { exports: {} };
new Function('require', 'module', 'exports', ts.transpileModule(source, { compilerOptions: { target: ts.ScriptTarget.ES2022, module: ts.ModuleKind.CommonJS } }).outputText)(require, box, box.exports);
const validStatuses = new Set(['passed', 'failed', 'timedOut', 'skipped', 'interrupted']);
const caseCodes = { 9: 'EARLY_WORKER', 17: 'LATE_FIXTURE', 23: 'UNKNOWN_SETUP' };
const retainedRows = rows.slice(0, 3).map(row => {
  const annotations = (Array.isArray(row.diagnostics) ? row.diagnostics : []).slice(0, 8).map(value => ({ type: box.exports.safeFailureAnnotation, description: typeof value?.cause === 'string' && value.cause.length <= 64 && Number.isSafeInteger(value.httpStatus) ? value.cause + ':' + value.httpStatus : '' }));
  return {
    caseCode: row.file === 'preobserver.control.spec.ts' && Object.hasOwn(caseCodes, row.line) ? caseCodes[row.line] : 'UNKNOWN',
    sourceLine: Object.hasOwn(caseCodes, row.line) ? row.line : 0,
    status: validStatuses.has(row.status) ? row.status : 'UNKNOWN',
    expectedStatus: validStatuses.has(row.expectedStatus) ? row.expectedStatus : 'UNKNOWN',
    errorCount: Number.isSafeInteger(row.errorCount) && row.errorCount >= 0 && row.errorCount <= 32 ? row.errorCount : 0,
    diagnostics: box.exports.safeFailureDiagnostics(annotations, row.errorCount > 0),
  };
});
const diagnosticByCase = code => retainedRows.find(row => row.caseCode === code)?.diagnostics ?? [];
const early = diagnosticByCase('EARLY_WORKER').some(x => x.cause === 'ACTOR_LOGIN_HTTP' && x.httpStatus === 401);
const late = diagnosticByCase('LATE_FIXTURE').some(x => x.cause === 'ACTOR_SESSION_HTTP' && x.httpStatus === 503);
const unknown = diagnosticByCase('UNKNOWN_SETUP').some(x => x.cause === 'UNKNOWN' && x.httpStatus === 0);
const result = { pass: child.status === 0 && markerAbsent && failed && early && late && unknown && bodiesNotStarted && parserDiagnosticCount === 0, childNativeExit: child.status, caseCount: rows.length, failedTestsRetained: failed, markerAbsent, earlyWorkerCauseTransported: early, lateFixtureCauseTransported: late, unknownFallbackTransported: unknown, bodiesNotStarted, parserDiagnosticCount, retainedRows, omittedRowCount: Math.max(0, rows.length - retainedRows.length), noBrowserApi: true };
// Preserve validated closed rows before the outer supervisor removes public control artifacts.
fs.writeFileSync(process.env.RCT_SAFE_DIAGNOSTIC_RECEIPT, JSON.stringify(result, null, 2) + '\n', { mode: 0o600 });
process.exitCode = result.pass ? 0 : 1;
