"""RAM-only cost counts from recorded build receipt and selected copy function. No scans."""
import ast
import hashlib
import json
from pathlib import Path,PurePosixPath
import types

HERE=Path(__file__).parent
SRC=HERE.parent/'current_academic_refresh_pin_correction'
receipt=HERE.parent/'current_academic_refresh_prepare/actual-build01/build-result.safe.json'
raw=receipt.read_bytes()
assert hashlib.sha256(raw).hexdigest()=='08dd08de01d3c4fe5c0ebcea7cd53e22c41f36fb4d65e94b8d216b8aacda80ac'
rows=json.loads(raw)['regular_entries']
assert len(rows)==1797
source=(SRC/'stage-academic.py').read_bytes()
assert hashlib.sha256(source).hexdigest()=='f3495254e3ef0a1a14fa31b29b10587e1eb11123029aa3baee1679a30c545909'
tree=ast.parse(source)
fn=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='copy_member')
counts={'resource_gates':0,'mkdir_attempts':0,'writes':0,'directory_opens':0,'fsyncs':0,'namespace_checks':0}
class FakePath(PurePosixPath):
    def lstat(self):return None
class Sink:
    def __enter__(self):return self
    def __exit__(self,*args):return False
    def write(self,b):counts['writes']+=1
    def flush(self):pass
    def fileno(self):return 90
class Stream:
    def __init__(self,n):self.remaining=n
    def read(self,n):
        assert n==262144
        if self.remaining<=0:return b''
        self.remaining-=n
        return b'x'  # one representative RAM byte per actual logical chunk; no payload read
class MockOS:
    O_RDONLY=1;O_DIRECTORY=2;O_NOFOLLOW=4;O_CLOEXEC=8;O_WRONLY=16;O_CREAT=32;O_EXCL=64
    @staticmethod
    def mkdir(*args,**kw):counts['mkdir_attempts']+=1
    @staticmethod
    def stat(*args,**kw):return None
    @staticmethod
    def fstat(*args):return None
    @staticmethod
    def open(name,flags,*args,**kw):
        if flags & MockOS.O_DIRECTORY:counts['directory_opens']+=1
        return 90
    @staticmethod
    def fdopen(*args):return Sink()
    @staticmethod
    def close(*args):pass
    @staticmethod
    def fsync(*args):counts['fsyncs']+=1
def check():counts['namespace_checks']+=1
def use():counts['resource_gates']+=1
boundary=types.SimpleNamespace(PREFIX=FakePath('/tmp/NO_ACTUAL_ACCESS'),identity=lambda _:dict(uid=1000,gid=1000,mode=0o755))
ns=types.SimpleNamespace(fds=[90],check=check)
env={'Path':FakePath,'boundary':boundary,'os':MockOS}
exec(compile(ast.Module(body=[fn],type_ignores=[]),'<RAM copy_member only>','exec'),env)
for r in rows:env['copy_member'](ns,use,None,r['path'],Stream(r['bytes']))
formula=sum(len(PurePosixPath(r['path']).parts)+1+(r['bytes']+262143)//262144 for r in rows)
assert counts['resource_gates']==formula
parents={str(p) for r in rows for p in PurePosixPath(r['path']).parents if str(p)!='.'}
result={'scope':'SOURCE_COUNT_ONLY_FROM_RECORDED_SAFE_RECEIPT',
        'build_receipt_sha256':hashlib.sha256(raw).hexdigest(),'stage_source_sha256':hashlib.sha256(source).hexdigest(),
        'recorded_regular_files':len(rows),'recorded_logical_bytes':sum(r['bytes'] for r in rows),
        'distinct_member_parent_paths':len(parents),'copy_loop_counts':counts,'resource_gate_formula':formula,
        'full_prefix_walks_at_least':formula,'at_least_prior_copied_regular_lstat_sum':sum(range(len(rows))),
        'cost_model':'Every copy use invokes allocated(PREFIX), each full walk lstat root, listed child dirs/files, then child dirs again as visited parents; seen only avoids duplicate block accounting, not lstat',
        'measured_time_syscalls_or_actual_runtime':'NOT_MEASURED',
        'foreign_FS_scans_payload_reads_writes_children':0,'actual_stage_process_observation':'NOT_RUN',
        'pure_controls':'RAM mocks only; source path-depth/chunk formula independently equals selected exact function count'}
(HERE/'counts.safe.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
