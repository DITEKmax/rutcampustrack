# P06 format/compile — narrow independent Source review

APPROVE_FORMAT_SOURCE_COMPILE_TEMPLATE_UNBOUND. No concrete finding.

The format init narrows canonical Spotless7.0.4/GJF1.25.2/AOSP to exactly InternalSessionAdmissionIT.java, validates its actual target set and serially applies then checks. Four callbacks independently byte-match the reviewed backend originals. All12 READY files and semantic16 source pins match; current semantic478204/test64df is clean.

Actual formatting must still prove fixed marker count2/native0/all births settled, exact allowed inventory, protected hashes and original-versus-formatted token/string/text-block/import/filemode equivalence. Retain before/after hashes and mechanical commit, or explicit zero change.

Compile selects only Auth compileJava and compileTestJava with rerun/offline/oneworker; init adds only two fixed completion markers. Its absolute path is protected in both source checks. Dependencies may compile normally; no tests, fixtures, XML or PG run is selected. Current base/testSHA/manifestSHA/sourcecommit placeholders remain null, which deny dispatch before Gradle. Binding requires actual formatting evidence and a separate fresh Root grant.

Current grant/source/direct-parent/birth/clock/cleanup/cap guards are reused unchanged. Existing closed fixed-marker collection is a proposed future operation, not an executed native/log test. Inherited XML wording is not evidence of a test run. Sampled limits are not hard isolation.

Source-only/Python AST-data checks. No runner/import/Java/Gradle/Docker/PG/API/privatebody/log/XML execution/read. ParentP06 UNKNOWN; previous complete critical-test and cleanup review reused.
