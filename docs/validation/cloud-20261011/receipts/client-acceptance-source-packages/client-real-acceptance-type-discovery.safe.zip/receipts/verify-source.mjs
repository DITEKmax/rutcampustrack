import fs from 'node:fs'
import path from 'node:path'
import crypto from 'node:crypto'
import ts from '/workspace/rutcampustrack/frontends/node_modules/typescript/lib/typescript.js'
const root = '/workspace/rct-worktrees/client-real-acceptance'
const files = ['fixtures', 'specs'].flatMap(dir => fs.readdirSync(path.join(root, 'tests/e2e', dir)).filter(name => /^cloud-accepted-.*\.ts$/.test(name)).map(name => `tests/e2e/${dir}/${name}`)).sort()
const errors = []
const inventory = files.map(file => {
  const text = fs.readFileSync(path.join(root, file), 'utf8')
  const source = ts.createSourceFile(file, text, ts.ScriptTarget.ES2022, true, ts.ScriptKind.TS)
  const diagnostics = [...source.parseDiagnostics, ...(ts.transpileModule(text, {fileName:file, reportDiagnostics:true, compilerOptions:{target:ts.ScriptTarget.ES2022,module:ts.ModuleKind.NodeNext,isolatedModules:true}}).diagnostics ?? [])]
  for (const diagnostic of diagnostics) errors.push({file, code:diagnostic.code, message:ts.flattenDiagnosticMessageText(diagnostic.messageText, ' ')})
  for (const forbidden of [/\bpage\.route\s*\(/, /\btest\.(?:skip|fixme|fail|only)\s*\(/, /waitForTimeout\s*\(/, /\bconsole\.(?:log|error|warn)\s*\(/, /\battach\s*\(/]) if (forbidden.test(text)) errors.push({file, policy:String(forbidden)})
  for (const statement of source.statements) if (ts.isImportDeclaration(statement)) {
    const specifier = statement.moduleSpecifier.text
    if (specifier.startsWith('.')) {
      const resolved = path.resolve(path.dirname(path.join(root,file)),specifier)
      if (![resolved,resolved+'.ts',resolved+'.vue',path.join(resolved,'index.ts')].some(p => fs.existsSync(p))) errors.push({file, missingImport:specifier})
    }
  }
  return {file, bytes:Buffer.byteLength(text),sha256:crypto.createHash('sha256').update(text).digest('hex'),syntaxDiagnostics:diagnostics.length}
})
const result = {schema:1,base:'cd3f237acffd4f0b9dd2a74babb2ee822376f0cb',typescriptVersion:ts.version,sourceRoot:root,kind:'current-source syntax and policy inspection',fullTypecheck:'NOT_RUN; current E2E dependency namespace unavailable',browser:'NOT_RUN',backend:'NOT_RUN',errors,inventory}
fs.writeFileSync('/workspace/scratch/rct-validation/client_real_acceptance/source-verification.json',JSON.stringify(result,null,2)+'\n')
process.stdout.write(JSON.stringify({files:files.length,syntaxDiagnostics:inventory.reduce((sum,row)=>sum+row.syntaxDiagnostics,0),policyErrors:errors.length,fullTypecheck:result.fullTypecheck,browser:result.browser})+'\n')
if(errors.length) process.exitCode=1
