"""Selected real checking consumers in RAM only; no processes/prefix/private reads."""
import ast
import datetime
import hashlib
import io
import json
from pathlib import Path, PurePosixPath
import stat
import types
from unittest.mock import patch
import zipfile

OWN = Path(__file__).parent

def load(name):
    module = types.ModuleType(name.replace('-', '_'))
    module.__file__ = str(OWN / name)
    exec(compile((OWN / name).read_bytes(), str(OWN / name), 'exec'), module.__dict__)
    return module

boundary = load('refresh-boundary.py')
build = load('build-academic.py')
inspector = load('inspect-academic.py')
checks = []

def check(name, call, allowed=True):
    try:
        value = call()
        accepted = True
    except (RuntimeError, ValueError, KeyError, OSError, SystemExit):
        value = None
        accepted = False
    checks.append({'name': name, 'pass': accepted == allowed})
    assert checks[-1]['pass'], name
    return value

now = datetime.datetime(2026, 10, 13, 9, tzinfo=datetime.timezone.utc)
grant = {'academic_refresh_phase': 'BUILD', 'execution_actor_uid': 1000,
         'execution_actor_gid': 1000, 'new_tmp_prefix': str(boundary.PREFIX),
         'all_new_tmp_cap': 1610612736, 'workspace_floor': 4294967296,
         'tmp_floor_plus_mongo_growth': 5368709120, 'shared_stop': 16106127360,
         'shared_reserve': 1073741824, 'workspace_cache_growth_cap': 8388608,
         'product_start_authorized': False, 'tests_authorized': False,
         'frozen_source_revision': boundary.FIX_REVISION,
         'fixed_UserSpecifications_sha256': boundary.FIX_SHA,
         'heavy_leases_released': True, 'build_services': ['academic', 'attendance'],
         'not_before_utc': now.isoformat(),
         'stop_utc': (now + datetime.timedelta(seconds=960)).isoformat()}
check('actual BUILD fixed2tuple positive', lambda: boundary.validate_fields(grant, 'BUILD', now))
for key, value in [('build_services', ['academic', 'auth']),
                   ('frozen_source_revision', '96c7aee0a114e978ce3ed2976127a2a59c1a69e3'),
                   ('product_start_authorized', True), ('tests_authorized', True),
                   ('heavy_leases_released', False), ('all_new_tmp_cap', 1610612737)]:
    check('actual grant denies ' + key, lambda key=key, value=value:
          boundary.validate_fields({**grant, key: value}, 'BUILD', now), False)
check('no STAGE phase authority', lambda: boundary.validate_fields(grant, 'STAGE', now), False)
check('exact2 standard argv only', lambda: None if tuple(boundary.BUILD_ARGV[-2:]) == boundary.TASKS
      and boundary.TASKS == (':services:academic-service:academic-app:bootJar',
                             ':services:attendance-service:attendance-app:bootJar') else (_ for _ in ()).throw(RuntimeError()))
for module in ['academic', 'attendance']:
    check('selected ' + module + ' app main', lambda module=module:
          None if boundary.selected('services/' + module + '-service/' + module + '-app/src/main/java/Public.java') else (_ for _ in ()).throw(RuntimeError()))
for path in ['services/auth-service/auth-app/src/main/java/Public.java', 'frontends/pwa-vue/src/Public.ts',
             'services/attendance-service/attendance-app/src/test/java/PublicIT.java', '.agent/evidence.json']:
    check('excluded source ' + path, lambda path=path:
          None if not boundary.selected(path) else (_ for _ in ()).throw(RuntimeError()))
check('selected lexical traversal denied', lambda: boundary.selected('proto/../private.proto'), False)

resource = {'workspace_free': 8000000000, 'tmp_free': 7000000000, 'shared': 5000000000,
            'maximum': 17179869184, 'new_tmp_allocated': 1000000}
for key, value in [('workspace_free', 4294967295), ('tmp_free', 5368709119),
                   ('shared', 16106127360), ('maximum', 6000000000),
                   ('new_tmp_allocated', 1610612737), ('workspace_free', 8000000000-8388609)]:
    check('actual resource denial ' + key, lambda key=key, value=value:
          boundary.require_resources(grant, 8000000000, {**resource, key: value}), False)
check('actual resource positive', lambda: boundary.require_resources(grant, 8000000000, resource))
sample = {'tick': 0.0, 'calls': 0, 'allocated': 1000000}
class CgroupPath:
    def __init__(self, value): self.value = str(value)
    def read_text(self): return '5000000000' if self.value.endswith('memory.current') else '17179869184'
def inventory(path):
    sample['calls'] += 1
    return sample['allocated']
boundary._allocation_sample = {'value': None, 'at': None, 'count': 0}
with patch.object(boundary, 'allocated', inventory), patch.object(boundary, 'Path', CgroupPath), \
        patch.object(boundary.os, 'statvfs', lambda path: types.SimpleNamespace(f_bavail=8000000000, f_frsize=1)), \
        patch('time.monotonic', lambda: sample['tick']):
    boundary.resource_snapshot(force=True)
    sample['tick'] = 0.25
    boundary.resource_snapshot()
    assert sample['calls'] == 1
    check('actual sampler avoids repeated expensive within1s', lambda: None)
    sample['tick'] = 1.1
    boundary.resource_snapshot()
    assert sample['calls'] == 2
    check('actual sampler refreshes once due1s', lambda: None)
    sample['tick'] = 1.2
    boundary.resource_snapshot(force=True)
    assert sample['calls'] == 3
    check('actual forced final inventory ignorescached cadence', lambda: None)
    sample['allocated'] = 1610612737
    check('forced final allocation cap denial',
          lambda: boundary.require_resources(grant, 8000000000, boundary.resource_snapshot(force=True)), False)
delayed = {'now': now + datetime.timedelta(seconds=899)}
class Clock:
    @staticmethod
    def now(zone): return delayed['now']
def delayed_resources(g, baseline):
    delayed['now'] += datetime.timedelta(seconds=2)
    return resource
with patch.object(boundary, 'require_resources', delayed_resources), \
        patch.object(boundary.datetime, 'datetime', Clock):
    check('allocation-preflight delay crosses cleanup gate before effect',
          lambda: boundary.gate(grant, now+datetime.timedelta(seconds=960), 8000000000), False)

library = [{'path': 'BOOT-INF/lib/a.jar'}, {'path': 'BOOT-INF/lib/spring-boot-jarmode-tools-3.5.16.jar'}]
check('derived library count positive not hardcoded182',
      lambda: inspector.library_order(['- "BOOT-INF/lib/a.jar"'], library, '3.5.16'))
for lines, entries, name in [(['- "BOOT-INF/lib/a.jar"']*2, library, 'duplicate'),
                            (['- "BOOT-INF/lib/missing.jar"'], library, 'missing'),
                            (['- "BOOT-INF/lib/../foreign.jar"'], library, 'traversal'),
                            (['- "BOOT-INF/lib/a.jar"'], library+[{'path':'BOOT-INF/lib/foreign.jar'}], 'unindexedforeign')]:
    check('actual library deny ' + name,
          lambda lines=lines, entries=entries: inspector.library_order(lines, entries, '3.5.16'), False)

fs = {'files': {}, 'symlinks': set(), 'owner': 1000, 'nlink': 1, 'mode': 0o644}
class RamPath:
    def __init__(self, value): self.value = PurePosixPath(str(value))
    def __str__(self): return str(self.value)
    def __truediv__(self, value): return RamPath(self.value / value)
    @property
    def parts(self): return self.value.parts
    @property
    def parents(self): return [RamPath(x) for x in self.value.parents]
    def is_absolute(self): return self.value.is_absolute()
    def exists(self): return True
    def lstat(self):
        raw = str(self)
        data = fs['files'].get(raw)
        kind = stat.S_IFLNK if raw in fs['symlinks'] else stat.S_IFREG if data is not None else stat.S_IFDIR
        return types.SimpleNamespace(st_mode=kind | fs['mode'], st_uid=fs['owner'], st_gid=1000,
                                     st_nlink=fs['nlink'], st_size=len(data or b''), st_blocks=8,
                                     st_dev=33, st_ino=abs(hash(raw)))
    def read_bytes(self): return fs['files'][str(self)]
    def open(self, mode): return io.BytesIO(self.read_bytes())

class SealPath(RamPath):
    @property
    def parents(self): return [SealPath(x) for x in self.value.parents]
    @property
    def parent(self): return SealPath(self.value.parent)
    def absolute(self): return self
    def is_relative_to(self, other): return self.value.is_relative_to(str(other))
    def __eq__(self, other): return str(self) == str(other)
    def __truediv__(self, value): return SealPath(self.value / value)
    def read_text(self): return self.read_bytes().decode()

# The actual package schema and self-source rows are joined through the full consumer.
actual = json.loads((OWN / 'manifest.json').read_text())
for row in actual['files']: fs['files'][row['path']] = Path(row['path']).read_bytes()
manifest_bytes = (OWN / 'manifest.json').read_bytes()
fs['files'][str(OWN / 'manifest.json')] = manifest_bytes
tools = json.loads((OWN / 'tool-inputs.safe.json').read_text())
for row in tools['files']: fs['files'][row['path']] = Path(row['path']).read_bytes()
review = str(OWN.parent / 'source-control-public-review.safe.json')
fs['files'][review] = b'public RAM review identity control, not an actual approval'
seal_grant = {'academic_refresh_manifest_sha256': hashlib.sha256(manifest_bytes).hexdigest(),
              'academic_refresh_review_manifest': review,
              'academic_refresh_review_manifest_sha256': hashlib.sha256(fs['files'][review]).hexdigest()}
with patch.object(boundary, 'Path', SealPath):
    check('whole actual frozenmanifest/selfsource/package consumer',
          lambda: boundary.verify_package(seal_grant, str(OWN/'build-academic.py')))
    check('whole package wrongmanifest pin denied',
          lambda: boundary.verify_package({**seal_grant,'academic_refresh_manifest_sha256':'0'*64},str(OWN/'build-academic.py')),False)
    check('whole package executingforeign source denied',
          lambda: boundary.verify_package(seal_grant,str(OWN/'foreign.py')),False)
    saved = fs['files'][str(OWN/'build-academic.py')]
    fs['files'][str(OWN/'build-academic.py')] = saved+b'changed'
    check('whole package changedselfsource denied',
          lambda: boundary.verify_package(seal_grant,str(OWN/'build-academic.py')),False)
    fs['files'][str(OWN/'build-academic.py')] = saved
checkout = RamPath('/tmp/public-checkout')
fs['files']['/tmp/public-checkout/public-file'] = b'public metadata control'
def walked(path, followlinks=False, onerror=None):
    return [('/tmp/public-checkout', [], ['public-file'])]
with patch.object(boundary, 'Path', RamPath), patch.object(boundary.os, 'walk', walked):
    check('actual allocation walk public positive', lambda: boundary.allocated(checkout))
    for field, bad in [('owner',999),('nlink',2)]:
        saved=fs[field];fs[field]=bad
        check('allocation walk denies foreign '+field,lambda:boundary.allocated(checkout),False)
        fs[field]=saved
    fs['symlinks'].add('/tmp/public-checkout/public-file')
    check('allocation walk symlink denied',lambda:boundary.allocated(checkout),False)
    fs['symlinks'].clear()
def walk_error(path, followlinks=False, onerror=None):
    onerror(OSError('public RAM metadata failure'))
with patch.object(boundary.os,'walk',walk_error):
    check('allocation IO error failclosed not skipped',lambda:boundary.allocated(checkout),False)
source = b'public source\n'
fs['files']['/tmp/public-checkout/proto/public.proto'] = source
row = {'path':'proto/public.proto','git_blob':hashlib.sha1(b'blob '+str(len(source)).encode()+b'\0'+source).hexdigest(),
       'git_mode':'100644','bytes':len(source)}
with patch.object(boundary, 'Path', RamPath), patch.object(build, 'boundary', boundary):
    check('full actual checkout consumer public positive', lambda: build.verify_checkout(checkout, [row]))
    for field, bad in [('owner',999),('nlink',2),('mode',0o600)]:
        saved=fs[field]; fs[field]=bad
        check('full checkout denies '+field, lambda: build.verify_checkout(checkout,[row]),False)
        fs[field]=saved
    fs['symlinks'].add('/tmp/public-checkout/proto')
    check('full checkout parent symlink denied',lambda:build.verify_checkout(checkout,[row]),False)
    fs['symlinks'].clear()
    check('full checkout changedGitblob denied',lambda:build.verify_checkout(checkout,[{**row,'git_blob':'0'*40}]),False)

original_zip = zipfile.ZipFile
fixture = Path('/workspace/rutcampustrack/tests/e2e/backend-clock/verify-jar-isolation.py').read_bytes()
def jar(service, producer, rpc=True):
    raw=io.BytesIO()
    nested=io.BytesIO()
    with original_zip(nested,'w'): pass
    manifest={'Main-Class':'org.springframework.boot.loader.launch.JarLauncher','Start-Class':inspector.SERVICES[service],
              'Spring-Boot-Version':'3.5.16','Build-Jdk-Spec':'21','Spring-Boot-Classes':'BOOT-INF/classes/',
              'Spring-Boot-Lib':'BOOT-INF/lib/','Spring-Boot-Classpath-Index':'BOOT-INF/classpath.idx',
              'Spring-Boot-Layers-Index':'BOOT-INF/layers.idx'}
    with original_zip(raw,'w') as z:
        z.writestr('META-INF/MANIFEST.MF','\n'.join(k+': '+v for k,v in manifest.items()))
        z.writestr('BOOT-INF/classes/'+inspector.SERVICES[service].replace('.','/')+'.class',b'public-layout-control')
        z.writestr('BOOT-INF/classes/git.properties','git.commit.id='+producer+'\n')
        z.writestr('BOOT-INF/classpath.idx','- "BOOT-INF/lib/a.jar"\n')
        z.writestr('BOOT-INF/layers.idx','public layout control')
        z.writestr('BOOT-INF/lib/a.jar',nested.getvalue())
        z.writestr('BOOT-INF/lib/spring-boot-jarmode-tools-3.5.16.jar',nested.getvalue())
        if rpc:
            z.writestr('BOOT-INF/classes/ru/rutcampustrack/academic/grpc/HeadmanJournalSemesterStateRequest.class',b'public-layout-control')
            z.writestr('BOOT-INF/classes/ru/rutcampustrack/academic/grpc/AcademicGrpcServiceGrpc.class',b'public-layout-control')
            target='ru/rutcampustrack/academic/grpc/AcademicGrpcServiceImpl' if service=='academic' else 'ru/rutcampustrack/attendance/grpc/AcademicGrpcClient'
            z.writestr('BOOT-INF/classes/'+target+'.class',b'getHeadmanJournalSemesterState')
    return raw.getvalue()
fs['files']['/tmp/public-checkout/tests/e2e/backend-clock/verify-jar-isolation.py']=fixture
def memory_zip(path):
    return original_zip(path if isinstance(path,io.BytesIO) else io.BytesIO(path.read_bytes()))
with patch.object(inspector.zipfile,'ZipFile',memory_zip):
    for service in ['academic','attendance']:
        target='/tmp/public-checkout/services/'+service+'-service/'+service+'-app/build/libs/'+service+'-app-0.1.0.jar'
        fs['files'][target]=jar(service,boundary.FIX_REVISION)
        proof=check('full archive consumer layout positive '+service,lambda service=service:inspector.inspect(checkout,boundary.FIX_REVISION,service))
        assert proof['application_index_library_count']==1
        fs['files'][target]=jar(service,'96c7aee0a114e978ce3ed2976127a2a59c1a69e3')
        check('false future producer rejected '+service,lambda service=service:inspector.inspect(checkout,boundary.FIX_REVISION,service),False)
        fs['files'][target]=jar(service,boundary.FIX_REVISION,rpc=False)
        check('old RPC payload falselycurrent rejected '+service,lambda service=service:inspector.inspect(checkout,boundary.FIX_REVISION,service),False)
    check('foreign application tuple rejected beforepath',lambda:inspector.inspect(checkout,boundary.FIX_REVISION,'auth'),False)

# Execute the actual nested lifecycle consumer with a guard-result metadata fixture.
# This proves denied publication does not erase settlement in safe output, not actual reaping.
tree=ast.parse((OWN/'build-academic.py').read_text());main=next(x for x in tree.body if isinstance(x,ast.FunctionDef) and x.name=='main')
run=next(x for x in main.body if isinstance(x,ast.FunctionDef) and x.name=='run')
result={'native_exit':-9,'settled':True,'phase_success':False,'all_owned_processes_reaped':True,
        'known_owned_identities':[{'pid':100,'start_ticks':10}],'all_members_including_Z_after':[],
        'terminal_reason':'SHARED_MEMORY_STOP'}
phases=[]
class DeniedPublication:
    def check(self): pass
    def save(self,*args,**kwargs): raise RuntimeError('RESOURCE_PUBLICATION_DENIED')
scope={'latest':{},'ns':DeniedPublication(),'use':lambda:None,'stop':datetime.datetime.now(datetime.timezone.utc)+datetime.timedelta(seconds=960),
       'datetime':datetime,'guard':types.SimpleNamespace(run_owned=lambda *a,**kw:result),'env':{},'observe':lambda:None,
       'phases':phases,'json':json}
exec(compile(ast.Module(body=[run],type_ignores=[]),'<selected real lifecycle consumer>','exec'),scope)
with patch('sys.stdout',io.StringIO()):
    check('resource publication denial after settled lifecycle',lambda:scope['run']('public-bootjar',['public'],RamPath('/tmp/public')),False)
assert phases==[{'phase':'public-bootjar','native_exit':-9,'settled':True,'phase_success':False}]
check('all checking sources syntax',lambda:[ast.parse(x.read_text()) for x in OWN.glob('*.py')])
print(json.dumps({'selected_RAM_checks':len(checks),'all_pass':all(x['pass'] for x in checks),
                  'no_process_checkout_native_or_prefix_read':True,
                  'RAM_layout_controls_not_real_JVM_artifact_or_reaping':True,'checks':checks},indent=2))
