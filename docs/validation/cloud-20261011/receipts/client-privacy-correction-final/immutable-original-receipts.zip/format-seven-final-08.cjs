'use strict';
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const ts = require('/workspace/rutcampustrack/frontends/node_modules/typescript/lib/typescript.js');
const own = __dirname;
const wt = '/workspace/rct-worktrees/client-privacy-boundary-eb';
const root = '/workspace/rutcampustrack';
const granted = JSON.parse(fs.readFileSync(path.join(own, 'root-node-correction-grant-02.json'))).source_hashes;
const hash = (x) => crypto.createHash('sha256').update(x).digest('hex');
const exactGrouping = (node, parent) => ts.isParenthesizedExpression(node) &&
  parent && ts.isConditionalExpression(parent) && parent.condition === node &&
  ts.isBinaryExpression(node.expression) && node.expression.operatorToken.kind === ts.SyntaxKind.BarBarToken &&
  ts.isIdentifier(node.expression.left) && node.expression.left.text === 'red' &&
  ts.isIdentifier(node.expression.right) && node.expression.right.text === 'interrupted';
const canonical = (source, file, normalize) => {
  const ast = ts.createSourceFile(file, source, ts.ScriptTarget.ES2022, true);
  let normalized = 0;
  const visit = (node, parent) => {
    if (normalize && exactGrouping(node, parent)) { normalized++; return visit(node.expression, parent); }
    const children = [];
    ts.forEachChild(node, (child) => { children.push(visit(child, node)); });
    return { kind: node.kind, text: ts.isSourceFile(node) ? undefined : node.text,
      optionalChain: Boolean(node.flags & ts.NodeFlags.OptionalChain), children };
  };
  return { parseErrorCodes: ast.parseDiagnostics.map((x) => x.code), tree: JSON.stringify(visit(ast)), normalized };
};
const comments = (source) => {
  const scanner = ts.createScanner(ts.ScriptTarget.ES2022, false, ts.LanguageVariant.Standard, source);
  const result = [];
  for (let kind = scanner.scan(); kind !== ts.SyntaxKind.EndOfFileToken; kind = scanner.scan())
    if (kind === ts.SyntaxKind.SingleLineCommentTrivia || kind === ts.SyntaxKind.MultiLineCommentTrivia)
      result.push(scanner.getTokenText());
  return JSON.stringify(result);
};
const emit = (source, fileName, module, normalize) => {
  let normalized = 0;
  const transformer = (context) => {
    const visit = (node, parent) => {
      if (normalize && exactGrouping(node, parent)) { normalized++; return visit(node.expression, parent); }
      return ts.visitEachChild(node, (child) => visit(child, node), context);
    };
    return (file) => visit(file);
  };
  const text = ts.transpileModule(source, {
    fileName,
    compilerOptions: { target: ts.ScriptTarget.ES2022, module, removeComments: true },
    transformers: normalize ? { before: [transformer] } : undefined,
  }).outputText;
  return { text, normalized };
};
const tokens = (text) => {
  const file = ts.createSourceFile('emission.mjs', text, ts.ScriptTarget.ES2022, true);
  if (file.parseDiagnostics.length) throw new Error('Emitted token parse failed');
  const result = [];
  const visit = (node) => {
    const children = node.getChildren(file);
    if (children.length) { for (const child of children) visit(child); }
    else if (node.kind !== ts.SyntaxKind.EndOfFileToken && node.kind <= ts.SyntaxKind.LastToken)
      result.push({ kind: node.kind, text: node.getText(file) });
  };
  visit(file);
  return result;
};

let stage = 'INITIAL';
(async () => {
  const prettier = await import('/workspace/rct-worktrees/client-current-artifacts/frontends/node_modules/prettier/index.mjs');
  const rows = []; const planned = [];
  for (const { path: relative, sha256 } of granted) {
    stage = relative;
    const filename = path.join(wt, relative);
    const logical = path.join(root, relative);
    const before = fs.readFileSync(path.join(own, 'before-grant02', relative), 'utf8');
    if (hash(before) !== sha256) throw new Error('Original granted bytes changed');
    const config = await prettier.resolveConfig(logical);
    const after = await prettier.format(before, { ...config, filepath: logical });
    const current = fs.readFileSync(filename, 'utf8');
    if (hash(current) !== sha256 && current !== after) throw new Error('Unexpected owned source delta');
    const mjs = relative === 'tests/e2e/check-artifact-privacy.mjs';
    const a = canonical(before, relative, mjs); const b = canonical(after, relative, mjs);
    const strictA = canonical(before, relative, false); const strictB = canonical(after, relative, false);
    const astEqual = a.tree === b.tree && a.parseErrorCodes.length === 0 && b.parseErrorCodes.length === 0;
    const commentsEqual = comments(before) === comments(after);
    if (!astEqual || !commentsEqual || a.normalized !== (mjs ? 1 : 0) || b.normalized !== 0)
      throw new Error('Exact semantic AST/comment proof failed');
    const emissions = [];
    for (const [name, module] of [['ESNext', ts.ModuleKind.ESNext], ['CommonJS', ts.ModuleKind.CommonJS]]) {
      const rawA = emit(before, relative, module, false); const rawB = emit(after, relative, module, false);
      const normalizedA = emit(before, relative, module, mjs); const normalizedB = emit(after, relative, module, mjs);
      const emittedA = canonical(normalizedA.text, relative, false);
      const emittedB = canonical(normalizedB.text, relative, false);
      const tokensA = tokens(normalizedA.text); const tokensB = tokens(normalizedB.text);
      const completeTokensEqual = JSON.stringify(tokensA) === JSON.stringify(tokensB);
      const emittedAstEqual = emittedA.tree === emittedB.tree && emittedA.parseErrorCodes.length === 0 && emittedB.parseErrorCodes.length === 0;
      if (!emittedAstEqual || !completeTokensEqual || normalizedA.normalized !== (mjs ? 1 : 0) || normalizedB.normalized !== 0 || (!mjs && rawA.text !== rawB.text))
        throw new Error('Exact emitted AST/complete-token proof failed');
      emissions.push({ mode: name, directByteEqual: rawA.text === rawB.text,
        directBeforeSha256: hash(rawA.text), directAfterSha256: hash(rawB.text),
        normalizedByteEqual: normalizedA.text === normalizedB.text,
        normalizedBeforeSha256: hash(normalizedA.text), normalizedAfterSha256: hash(normalizedB.text),
        strictEmittedASTEqual: emittedAstEqual, emittedParseCodesBefore: emittedA.parseErrorCodes,
        emittedParseCodesAfter: emittedB.parseErrorCodes, completeTokenKindTextEqual: completeTokensEqual,
        tokenCountBefore: tokensA.length, tokenCountAfter: tokensB.length,
        completeTokenSha256: hash(JSON.stringify(tokensA)),
        normalizedBeforeCount: normalizedA.normalized, normalizedAfterCount: normalizedB.normalized,
        qualification: mjs ? 'Exact Boolean grouping removed; actual emitted AST and every terminal token equal; raw bytes retain printer whitespace difference' : 'Direct emitted bytes equal' });
    }
    const formatted = await prettier.check(after, { ...config, filepath: logical });
    if (!formatted) throw new Error('Pinned formatter check failed');
    rows.push({ path: relative, beforeSha256: sha256, afterSha256: hash(after), strictAstEqual: strictA.tree === strictB.tree, semanticAstEqual: astEqual, normalizationBefore: a.normalized, normalizationAfter: b.normalized, parseErrorCodesBefore: a.parseErrorCodes, parseErrorCodesAfter: b.parseErrorCodes, commentsEqual, emissions, formatted });
    planned.push({ filename, after });
  }
  // Validate all seven before writing any, retaining complete original snapshots.
  for (const { filename, after } of planned) fs.writeFileSync(filename, after);
  fs.writeFileSync(path.join(own, 'format-final-08.safe.json'), JSON.stringify({ state: 'SCOPED_FORMAT_SEMANTICS_PASSED', prettierVersion: prettier.version, typescriptToolVersion: ts.version, actualRootConfigSha256: hash(fs.readFileSync(path.join(root, '.prettierrc.json'))), normalization: 'Only exact (red || interrupted) Boolean conditional condition; no other grouping/literal/operator/name removed', rows }, null, 2) + '\n');
})().catch((error) => {
  fs.writeFileSync(path.join(own, 'format-final-08.safe.json'), JSON.stringify({ state: 'FORMAT_PROOF_FAILED', stage, errorType: ['Error','TypeError','ReferenceError'].includes(error?.name) ? error.name : 'Other', rawErrorSuppressed: true }) + '\n'); process.exit(1);
});
