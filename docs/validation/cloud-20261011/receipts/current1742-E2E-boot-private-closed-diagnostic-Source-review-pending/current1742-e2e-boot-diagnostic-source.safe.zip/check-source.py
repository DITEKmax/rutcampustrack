"""Synthetic RAM only. No job log, API, child, private grant or data read."""
import importlib.util
import json
from pathlib import Path

ROOT = Path(__file__).parent
spec = importlib.util.spec_from_file_location('closed', ROOT / 'closed-boot-parser.py')
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)
b = {'repo': 'DITEKmax/rutcampustrack', 'head': m.HEAD, 'run_id': m.RUN,
    'run_attempt': 1, 'job_id': m.JOB, 'job_name': 'Playwright E2E auth flow',
    'step_number': 9, 'step_name': m.STEP, 'step_conclusion': 'failure',
    'step_started_at': '2026-10-13T11:03:00Z',
    'step_completed_at': '2026-10-13T11:04:00Z', 'metadata_verified': True}
checks = []
def case(name, operation, blocked=False):
    try:
        value = operation()
        assert not blocked
        checks.append({'name': name, 'passed': True})
        return value
    except m.Blocked:
        assert blocked
        checks.append({'name': name, 'passed': True})
def line(s):
    return ('2026-10-13T11:03:10.0000000Z ' + s + '\n').encode()

v = case('canonical service reported wait-failure', lambda: m.parse(line(
    'dependency failed to start: container rct-e2e-academic-service-1 is unhealthy'), b))
assert v['hints'] == [{'phase': 'WAIT', 'service': 'academic-service', 'state': 'Unhealthy', 'code': None}]
assert v['cause'] == 'UNKNOWN' and v['actual_checkout'] == 'UNKNOWN'
case('canonical container status', lambda: m.parse(line(' Container rct-e2e-redis-1  Healthy'), b))
case('closed exitcode', lambda: m.parse(line('##[error]Process completed with exit code 1.'), b))
canary = 'PRIVATE_CANARY password=example user@example.invalid /private/location 0123456789abcdef'
for name, payload in [('private unknown line', canary),
    ('private suffixed status', 'Container rct-e2e-redis-1 Healthy ' + canary),
    ('private BuildKit message', 'failed to solve: ' + canary)]:
    v = case(name, lambda payload=payload: m.parse(line(payload), b))
    assert canary not in json.dumps(v) and 'example' not in json.dumps(v)
case('malformed utf8', lambda: m.parse(line('public') + b'\xff', b), True)
case('NUL', lambda: m.parse(line('public\x00'), b), True)
case('ANSI', lambda: m.parse(line('\x1b[31mpublic'), b), True)
case('control byte', lambda: m.parse(line('public\x07'), b), True)
case('unknown service enum', lambda: m.parse(line('Container rct-e2e-private-1 Healthy'), b), True)
case('unknown state enum', lambda: m.parse(line('Container rct-e2e-redis-1 Password'), b), True)
case('unknown code enum', lambda: m.parse(line('##[error]Process completed with exit code 998.'), b), True)
case('malformed timestamp', lambda: m.parse(b'bad public\n', b), True)
case('oversize line', lambda: m.parse(line('x' * 65537), b), True)
case('out-of-step-only', lambda: m.parse(b'2026-10-13T11:05:00Z Container rct-e2e-redis-1 Error\n', b), True)
v = case('outside step not joined', lambda: m.parse(line('public') + b'2026-10-13T11:05:00Z Container rct-e2e-redis-1 Error\n', b))
assert v['hints'] == []
for key, value in [('head', '0' * 40), ('run_id', 1), ('run_attempt', 2),
    ('job_id', 2), ('step_number', 8), ('step_name', 'other'),
    ('metadata_verified', False), ('step_conclusion', 'success')]:
    case('false binding ' + key, lambda key=key,value=value: m.parse(line('public'), dict(b, **{key: value})), True)
case('unexpected binding field', lambda: m.parse(line('public'), dict(b, unsafe='private')), True)
case('boolean run rejected', lambda: m.parse(line('public'), dict(b, run_id=True)), True)
case('reverse window', lambda: m.parse(line('public'), dict(b, step_started_at=b['step_completed_at'])), True)
print(json.dumps({'state': 'SOURCE_RAM_CHECKS_PASS', 'checks': checks,
    'actual_API_or_log_read': False, 'native_children': 0, 'actual_cause': 'UNKNOWN'}))
