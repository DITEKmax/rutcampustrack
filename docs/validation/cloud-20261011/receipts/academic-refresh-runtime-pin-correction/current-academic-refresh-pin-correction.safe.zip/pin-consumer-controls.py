"""Pure exact selected pin→actual helper load→mocked boundary call; no launch/ENV."""
import ast
import builtins
import hashlib
import json
from pathlib import Path
import types

OWN = Path(__file__).parent
BASE = OWN.parent / 'current_academic_refresh_prepare'


def selected(source):
    tree = ast.parse(source.read_text())
    main = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == 'main')
    start = next(i for i, n in enumerate(main.body) if isinstance(n, ast.Assign)
                 and any(isinstance(t, ast.Name) and t.id == 'helper' for t in n.targets))
    end = next(i for i, n in enumerate(main.body[start:], start) if isinstance(n, ast.Assign)
               and any(isinstance(t, ast.Name) and t.id == 'specs' for t in n.targets))
    return ast.Module(body=main.body[start:end + 1], type_ignores=[])


def consumer(source, helper_dir, wrong_digest=False):
    events = []
    loaded = []
    def helper_exec(code, namespace):
        # Actual immutable helper bytes, bootstrap digest, imports and function definitions execute.
        # Only its metadata/native readiness boundary call is mocked, outside the pin finding.
        builtins.exec(code, namespace)
        assert namespace['verify'].__name__ == 'verify'
        loaded.append(hashlib.sha256((helper_dir / 'runtime-binding.py').read_bytes()).hexdigest())
        def mock_verify(grant, actual_source):
            assert actual_source == str(source)
            events.append('ACTUAL_HELPER_VERIFY_CALLED_MOCK_ONLY')
            return 'PURE_SOURCE_SENTINEL'
        namespace['verify'] = mock_verify
    namespace = {'REFRESH': helper_dir, 'types': types, 'grant': {}, '__file__': str(source),
                 'digest': lambda p: '0' * 64 if wrong_digest else hashlib.sha256(p.read_bytes()).hexdigest(),
                 'exec': helper_exec}
    try:
        builtins.exec(compile(selected(source), str(source), 'exec'), namespace)
    except RuntimeError as e:
        assert events == [] and loaded == []
        return {'accepted': False, 'helper_loads': 0, 'mock_boundary_calls': 0, 'error_type': type(e).__name__}
    assert namespace['specs'] == 'PURE_SOURCE_SENTINEL' and len(loaded) == 1 and len(events) == 1
    return {'accepted': True, 'helper_loads': len(loaded), 'mock_boundary_calls': len(events),
            'actual_helper_sha256': loaded[0]}


old = BASE / 'run-academic-restart.py'
new = OWN / 'run-academic-restart.py'
old_pin = 'e65d7f3bbf4c01671ea682c9a32152ba2f0744d533085769050ebda35f831bf3'
actual = hashlib.sha256((BASE / 'runtime-binding.py').read_bytes()).hexdigest()
assert actual == '7e7579ce554d6a94aaf79d331aeaccfa6611a989def97fa3ec2be7f261028d07'
assert new.read_text() == old.read_text().replace(old_pin, actual)
assert hashlib.sha256((OWN / 'runtime-binding.py').read_bytes()).hexdigest() == actual
results = {'original_exact_consumer_actual_helper': consumer(old, BASE),
           'corrected_exact_consumer_actual_helper': consumer(new, OWN),
           'corrected_consumer_wrong_helper_digest': consumer(new, OWN, wrong_digest=True)}
assert results['original_exact_consumer_actual_helper']['accepted'] is False
assert results['corrected_exact_consumer_actual_helper']['accepted'] is True
assert results['corrected_consumer_wrong_helper_digest']['accepted'] is False
result = {'scope': 'PURE_SELECTED_FULL_PIN_CONSUMER', 'passed': 3, 'results': results,
          'source_delta': 'One exact helper-pin literal only; all18 other content mirrored unchanged',
          'child_processes': 0, 'private_ENV_or_grant_reads': False,
          'native_metadata_boundary_call': 'MOCKED; actual helper definitions/bootstrap loaded',
          'checkout_build_stage_runtime': 'NOT_RUN'}
(OWN / 'pin-consumer-controls.safe.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({'pure_full_consumer_controls': 3, 'old_actual': False, 'corrected_actual': True,
                  'wrong_helper': False, 'native': False}))
