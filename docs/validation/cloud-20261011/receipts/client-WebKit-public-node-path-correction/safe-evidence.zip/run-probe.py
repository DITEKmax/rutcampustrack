"""Public-only supported custom WebKit boot probe. Requires a NEW Root grant; never loads specs or starts a stand."""
import datetime
import errno
import hashlib
import json
import os
from pathlib import Path
import shutil
import stat
import subprocess
import sys
import types

BASE = Path('/workspace/scratch/rct-validation/client_real_acceptance/webkit-public-boot-r2')
R1 = Path('/workspace/scratch/rct-validation/client_real_acceptance/focused3-preparation-5ced-r1')
ROOT = Path('/workspace/rutcampustrack')
GUARD = Path('/workspace/scratch/rct-validation/guard_proc_race_correction/bounded-child.py')
CACHE = Path('/tmp/rct-validation-browsers-20261012')
WRAPPER_BASE = Path('/workspace/scratch/rct-validation/browser_webkit_native_anchor_correction')
NODE = Path('/opt/codex/runtimes/codex-primary-runtime/dependencies/node/bin/node')
SOURCE = '5ced48c466b02097876f4f8aeee6e5c8da92ce1b'
UTC = datetime.timezone.utc


def digest(path):
    value = hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(2097152), b''):
            value.update(chunk)
    return value.hexdigest()


def require(condition, stage):
    if not condition:
        raise RuntimeError(stage)


def instant(value):
    result = datetime.datetime.fromisoformat(value.replace('Z', '+00:00'))
    require(result.tzinfo is not None, 'GRANT_CLOCK_INVALID')
    return result.astimezone(UTC)


def private_directory(path):
    value = path.lstat()
    require(stat.S_ISDIR(value.st_mode) and not path.is_symlink()
            and stat.S_IMODE(value.st_mode) == 0o700
            and value.st_uid == os.geteuid(), 'PRIVATE_DIRECTORY_INVALID')


def atomic(path, value):
    temporary = path.with_suffix(path.suffix + '.next')
    with temporary.open('x', encoding='utf-8') as stream:
        json.dump(value, stream, indent=2)
        stream.write('\n')
    temporary.chmod(0o600)
    temporary.replace(path)


def fresh_preflight(grant, stop):
    # Last clock read follows every potentially delayed resource read.
    for filesystem in ['/workspace', '/tmp']:
        value = os.statvfs(filesystem)
        require(value.f_bavail * value.f_frsize >= grant['disk_floor_bytes'], 'DISK_FLOOR_AT_USE')
    used = int(Path('/sys/fs/cgroup/memory.current').read_text())
    limit = int(Path('/sys/fs/cgroup/memory.max').read_text())
    require(used < grant['shared_stop_bytes'] and limit - used >= grant['shared_memory_reserve_bytes'],
            'SHARED_MEMORY_AT_USE')
    rss = next((int(line.split()[1]) * 1024 for line in Path('/proc/self/status').read_text().splitlines()
                if line.startswith('VmRSS:')), 0)
    require(rss <= grant['owned_total_rss_stop_bytes'], 'OWN_RSS_AT_USE')
    issued = instant(grant['issued_at'])
    require(issued <= datetime.datetime.now(UTC) < stop, 'GRANT_EXPIRED_AT_USE')


def main():
    os.umask(0o077)
    require(os.getuid() == 1000 and os.getgid() == 1000
            and Path('/').lstat().st_uid == 0 and Path('/').lstat().st_gid == 0, 'NATIVE_CONTEXT_IDENTITY_DENIED')
    require(len(sys.argv) == 2, 'ROOT_GRANT_REQUIRED')
    grant_path = Path(sys.argv[1])
    require(grant_path.is_absolute() and grant_path.parent == BASE / 'private', 'GRANT_PATH_INVALID')
    grant_stat = grant_path.lstat()
    require(stat.S_ISREG(grant_stat.st_mode) and not grant_path.is_symlink()
            and stat.S_IMODE(grant_stat.st_mode) == 0o600, 'GRANT_MODE_INVALID')
    grant = json.loads(grant_path.read_text())
    ready_path = BASE / 'READY.safe.json'
    own_ready = json.loads(ready_path.read_text())
    r1_ready_path = R1 / 'READY.safe.json'
    require(digest(r1_ready_path) == own_ready['r1_ready_sha256'], 'R1_READY_CHANGED')
    ready = json.loads(r1_ready_path.read_text())
    for name, sha in own_ready['own_source_hashes'].items():
        require(digest(BASE / name) == sha, 'PROBE_SOURCE_CHANGED')
    for name, sha in own_ready['pinned_source_hashes'].items():
        require(digest(Path(name)) == sha, 'CONFIG_LOADER_SOURCE_CHANGED')
    require(grant['authorized'] is True and grant['scope'] == 'webkit-public-boot'
            and grant['project'] == 'webkit' and grant['case_count'] == 0
            and grant['API_login_dataset_seed_authorized'] is False
            and grant['native_context_actor_uid'] == 1000 and grant['native_context_root_uid'] == 0, 'GRANT_SCOPE_INVALID')
    require(grant['prepared_source_sha'] == SOURCE
            and grant['ready_sha256'] == digest(ready_path), 'GRANT_SOURCE_INVALID')
    now = datetime.datetime.now(UTC)
    stop = instant(grant['absolute_stop_at'])
    require(instant(grant['issued_at']) <= now < stop
            and stop <= instant(grant['expires_at']), 'GRANT_EXPIRED')
    actual_head = subprocess.check_output(['git', '-C', str(ROOT), 'rev-parse', 'HEAD'], stderr=subprocess.DEVNULL).decode().strip()
    require(actual_head == grant['execution_checkout_sha'], 'EXECUTION_HEAD_INVALID')
    require(bool(ready['root_source_hashes']) and bool(ready['own_source_hashes'])
            and set(ready['root_source_hashes']) == set(grant['expected_root_source_paths']), 'SOURCE_LEDGER_INCOMPLETE')
    for name, sha in ready['root_source_hashes'].items():
        path = ROOT / name
        require(path.is_file() and not path.is_symlink() and digest(path) == sha, 'ROOT_SOURCE_BYTES_CHANGED')
    for name, sha in ready['own_source_hashes'].items():
        path = R1 / name
        require(path.is_file() and not path.is_symlink() and digest(path) == sha, 'OWN_SOURCE_BYTES_CHANGED')
    require(digest(GUARD) == ready['guard_sha256'] == grant['guard_sha256'], 'GUARD_SOURCE_CHANGED')
    require(grant['browser_cache'] == str(CACHE), 'CACHE_INVALID')
    require(grant['node_heap_mib'] == 512 and grant['owned_total_rss_stop_bytes'] <= 1610612736
            and grant['cache_stop_bytes'] <= 33554432 and grant['disk_floor_bytes'] >= 4294967296
            and grant['shared_stop_bytes'] <= 16106127360
            and grant['shared_memory_reserve_bytes'] >= 1073741824
            and 0 < grant['deadline_seconds'] <= 60, 'RESOURCE_SCOPE_INVALID')
    for name, source in ready['third_party_links'].items():
        path = ROOT / 'tests/e2e/node_modules' / name
        require(path.is_symlink() and str(path.resolve()) == source['resolved_path'], 'THIRD_PARTY_LINK_CHANGED')
        package = path / 'package.json'
        require(digest(package) == source['package_sha256']
                and json.loads(package.read_text())['version'] == source['version'], 'THIRD_PARTY_VERSION_CHANGED')
    for name, sha in ready['browser_manifest_hashes'].items():
        require(digest(CACHE / name) == sha, 'BROWSER_MANIFEST_CHANGED')
    for name, sha in ready['browser_binary_hashes'].items():
        require(digest(CACHE / name) == sha, 'BROWSER_BINARY_CHANGED')
    for name, sha in ready['runtime_hashes'].items():
        require(digest(Path(name)) == sha, 'PINNED_RUNTIME_SOURCE_CHANGED')
    for name, sha in ready['clock_hashes'].items():
        require(digest(Path(name)) == sha, 'TEACHING_CLOCK_CHANGED')
    node_identity = own_ready['provided_node_binary']
    node_metadata = NODE.lstat()
    require(str(NODE) == node_identity['path'] and stat.S_ISREG(node_metadata.st_mode)
            and not NODE.is_symlink() and os.access(NODE, os.X_OK), 'PROVIDED_NODE_UNREACHABLE')
    require({'bytes': node_metadata.st_size, 'mode': stat.S_IMODE(node_metadata.st_mode),
             'uid': node_metadata.st_uid, 'gid': node_metadata.st_gid, 'device': node_metadata.st_dev,
             'inode': node_metadata.st_ino, 'nlink': node_metadata.st_nlink} == node_identity['metadata']
            and digest(NODE) == node_identity['sha256'], 'PROVIDED_NODE_IDENTITY_CHANGED')
    attempt = grant['attempt']
    require(isinstance(attempt, str) and len(attempt) == 10 and attempt == 'attempt-01', 'ATTEMPT_INVALID')
    runs = BASE / 'runs'
    if not runs.exists():
        fresh_preflight(grant, stop)
        runs.mkdir(mode=0o700)
    private_directory(runs)
    run = runs / attempt
    fresh_preflight(grant, stop)
    run.mkdir(mode=0o700, exist_ok=False)
    for name in ['supervision', 'private-tmp', 'browser-config', 'browser-cache']:
        fresh_preflight(grant, stop)
        (run / name).mkdir(mode=0o700)
        private_directory(run / name)
    private_directory(run)
    supervision = run / 'supervision'
    guard = types.ModuleType('reviewed_owned_guard')
    guard.__file__ = str(GUARD)
    exec(compile(GUARD.read_bytes(), str(GUARD), 'exec'), guard.__dict__)
    latest = {}
    peaks = {'owned_rss_bytes': 0, 'run_allocated_bytes': 0, 'shared_memory_bytes': 0}

    def status(value):
        child = guard.process_table().get(value['child_pid'])
        if child is not None:
            value = {**value, 'direct_birth': child['start_ticks']}
        latest.clear()
        latest.update(value)
        atomic(supervision / 'process.safe.json', value)

    def observe():
        for filesystem in ['/workspace', '/tmp']:
            value = os.statvfs(filesystem)
            if value.f_bavail * value.f_frsize < grant['disk_floor_bytes']:
                return 'DISK_FLOOR'
        used = int(Path('/sys/fs/cgroup/memory.current').read_text())
        limit = int(Path('/sys/fs/cgroup/memory.max').read_text())
        peaks['shared_memory_bytes'] = max(peaks['shared_memory_bytes'], used)
        if used >= grant['shared_stop_bytes'] or limit - used < grant['shared_memory_reserve_bytes']:
            return 'SHARED_MEMORY_STOP'
        table = guard.process_table()
        rss = next((int(line.split()[1]) * 1024 for line in Path('/proc/self/status').read_text().splitlines()
                    if line.startswith('VmRSS:')), 0)
        for row in latest.get('members_including_Z', []):
            current = table.get(row['pid'])
            if current is None or current['start_ticks'] != row['start_ticks']:
                continue
            try:
                lines = Path('/proc', str(row['pid']), 'status').read_text().splitlines()
            except OSError as caught:
                if caught.errno in (errno.ENOENT, errno.ESRCH):
                    continue
                raise
            rss += next((int(line.split()[1]) * 1024 for line in lines if line.startswith('VmRSS:')), 0)
        peaks['owned_rss_bytes'] = max(peaks['owned_rss_bytes'], rss)
        if rss > grant['owned_total_rss_stop_bytes']:
            return 'OWN_TOTAL_RSS_STOP'
        allocated = sum(path.lstat().st_blocks * 512 for path in run.rglob('*')
                        if path.is_file() and not path.is_symlink())
        peaks['run_allocated_bytes'] = max(peaks['run_allocated_bytes'], allocated)
        if allocated > grant['cache_stop_bytes']:
            return 'OWN_CACHE_STOP'
        return 'ABSOLUTE_DEADLINE' if datetime.datetime.now(UTC) >= stop else None

    # Wrapper grant remains Root-owned. Read and bind only its reviewed public schema.
    browser_grant_path = WRAPPER_BASE / 'private/browser-grant.json'
    metadata = browser_grant_path.lstat()
    require(stat.S_ISREG(metadata.st_mode) and not browser_grant_path.is_symlink()
            and stat.S_IMODE(metadata.st_mode) == 0o600 and metadata.st_uid == 1000
            and metadata.st_nlink == 1 and metadata.st_size <= 65536, 'WRAPPER_GRANT_METADATA_INVALID')
    require(digest(browser_grant_path) == grant['wrapper_grant_sha256'], 'WRAPPER_GRANT_UNBOUND')
    browser_grant = json.loads(browser_grant_path.read_text())
    expected_browser_env = {'PATH': '/usr/bin:/bin', 'LANG': 'C', 'LC_ALL': 'C',
                            'TMPDIR': str(run / 'private-tmp'), 'XDG_CONFIG_HOME': str(run / 'browser-config'),
                            'XDG_CACHE_HOME': str(run / 'browser-cache')}
    require(browser_grant['declared_browser_environment'] == expected_browser_env
            and browser_grant['browser_launch_authorized'] is True
            and browser_grant['library_extraction_authorized'] is False
            and browser_grant['native_validation_authorized'] is False
            and browser_grant['execution_actor_uid'] == 1000 and browser_grant['execution_actor_gid'] == 1000,
            'WRAPPER_SCOPE_ENV_INVALID')
    require(browser_grant['source_manifest_sha256'] == own_ready['wrapper_source_sha256']
            and browser_grant['source_review_manifest'] == own_ready['wrapper_review_manifest']
            and browser_grant['source_review_manifest_sha256'] == own_ready['wrapper_review_sha256']
            and browser_grant['native_validation_receipt'] == own_ready['native_proof_path']
            and browser_grant['native_validation_receipt_sha256'] == own_ready['native_proof_sha256'],
            'WRAPPER_PROOF_SOURCE_INVALID')
    require(instant(browser_grant['not_before_utc']) <= datetime.datetime.now(UTC) < stop
            and stop == instant(browser_grant['stop_utc']), 'WRAPPER_GRANT_EXPIRED')
    env = {'PATH': '/usr/bin:/bin', 'LANG': 'C', 'LC_ALL': 'C',
           'PLAYWRIGHT_BROWSERS_PATH': str(CACHE), 'RCT_PUBLIC_WEBKIT_RUN': str(run),
           'RCT_PUBLIC_WEBKIT_CHILD_ENV': json.dumps(expected_browser_env),
           'TMPDIR': str(run / 'private-tmp'), 'TMP': str(run / 'private-tmp'), 'TEMP': str(run / 'private-tmp')}
    argv = [str(NODE), '--max-old-space-size=512', str(BASE / 'probe.cjs')]
    seconds = min(grant['deadline_seconds'], int((stop - datetime.datetime.now(UTC)).total_seconds()))
    require(seconds > 0, 'GRANT_EXPIRED_BEFORE_LAUNCH')
    atomic(supervision / 'launch.safe.json', {
        'state': 'LAUNCHING', 'prepared_source_sha': SOURCE, 'execution_checkout_sha': actual_head,
        'ready_sha256': digest(ready_path), 'grant_sha256': digest(grant_path),
        'issued_at': now.isoformat(), 'absolute_stop_at': stop.isoformat(), 'deadline_seconds': seconds,
        'project': 'webkit', 'case_count': 0, 'phases': ['PUBLIC_WEBKIT_BROWSER_ONLY'], 'argv': argv,
        'no_API_login_dataset_seed': True, 'requested_tool_context': 'actor1000 root0 native context; require_escalated if masked', 'own_driver_pid': os.getpid(),
        'own_driver_birth': guard.process_table()[os.getpid()]['start_ticks'],
    })
    fresh_preflight(grant, stop)
    result = guard.run_owned(argv, str(ROOT / 'tests/e2e'), env, deadline_seconds=seconds,
                             observe=observe, status=status)
    temporary_removed = False
    # Cleanup only the exact fresh own namespace after pidfd/birth-aware settlement.
    # SIGKILL/power loss of THIS supervisor cannot run finally; producer protection is primary.
    if result['settled'] and result['all_owned_processes_reaped']:
        private_directory(run / 'private-tmp')
        shutil.rmtree(run / 'private-tmp')
        temporary_removed = True
    result.update(peaks=peaks, private_tmp_removed=temporary_removed, case_count=0, project='webkit',
                  prepared_source_sha=SOURCE, execution_checkout_sha=actual_head)
    atomic(supervision / 'terminal.safe.json', result)
    print(json.dumps({'settled': result['settled'], 'native_exit': result['native_exit'],
                      'terminal_reason': result['terminal_reason'], 'private_tmp_removed': temporary_removed}))
    return 0 if result['settled'] and result['supervision_error_type'] is None else 1


if __name__ == '__main__':
    try:
        raise SystemExit(main())
    except Exception:
        # No raw exception/body/credential/path is emitted by the supervisor.
        print('{"state":"BLOCKED","stage":"PREFLIGHT_OR_SUPERVISION"}')
        raise SystemExit(2)
