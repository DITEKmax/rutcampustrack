# ENUM-ROW-EQUALITY developer preparation

State: **SOURCE_PREPARED_HYPOTHESIS_NATIVE_NOT_RUN**. This package is a minimal two-file candidate for independent review and a later authorized native before/after check. It is not a confirmed defect, an independent approval of the author's candidate, or acceptance evidence. RESEARCH-L04 remains UNKNOWN.

Frozen Root4c3745f2febdd4b9bcdd39a4e5f1fc9b3199fab1, executable producer c16a2995a3a830e5c0c4a0acf9cba4073aa212a2 / prepared5ced48c466b02097876f4f8aeee6e5c8da92ce1b; baseline3908fad9624f97aec8891fc79338ceb6b0616bf3. Both actual current targets were independently checked against frozen Git blobs and remain unchanged. Only NEW /workspace/scratch/rct-validation/enum_filtered_locale_developer was written; no tracked Root file, Git worktree, build, dependency, runtime, API, Docker, JVM, browser, Angular, private ENV/key/actual credential or child activity.

## Accepted source semantics and hypothesis

UserApi listUsers accepts String role/roleStatus and documents uppercase role=STUDENT. Current UserService.validateRoleFilter normalizes trim/toUpperCase(Locale.ROOT), explicitly permits ADMIN/admin, and permits ACTIVE/active for ADMIN. It passes the raw strings to UserSpecifications.matchesGrant. This is existing acceptance, not an invented alias. Current WebConfig already accepts account status=active/ACTIVE using Locale.ROOT, rejects unknown enum codes. Durable grant fields are ordinary String codes; the seed derives lowercase admin/active and assigns ADMIN_ID1 the FULL profile. AcademicTestAdminRequest selects the existing active admin grant and creates only its own temporary session.

The actual matchesGrant currently uses role.toLowerCase() and status.toLowerCase() with JVM default locale. Turkish folding of ASCII I in accepted ADMIN/ACTIVE can produce a noncanonical string while validation succeeds. This is a source-supported hypothesis; no native query, failing result or product defect was collected. Candidate production change is only a Locale import and Locale.ROOT on those two calls. Free-text search, validation, grant ownership, null handling, enum catalogue, DB/wire representation, API and architecture remain byte-identical outside those calls/import/linewraps.

## Exact candidate

1. services/academic-service/academic-app/src/test/java/ru/rutcampustrack/academic/integration/AcademicGrpcIT.java: extend the existing enumDatabaseAndHttpBoundaryRemainCanonicalUnderTurkishLocale method, add two private projection helpers/records and three existing-dependency imports. Preserve original JPA ADMIN/ACTIVE assertions, ResourceLock, one selected current session/JWT, unknown status400 and finally prior-locale restoration/delete only that session.
2. services/academic-service/academic-app/src/main/java/ru/rutcampustrack/academic/user/UserSpecifications.java: narrow two-call normalization candidate only.

candidate-inventory.safe.json binds exact before/candidate byte SHA and target mappings. The ready-to-review full candidates are candidate/AcademicGrpcIT.java and candidate/UserSpecifications.java. test.public.diff permits a future test-only BEFORE stage; fix.public.diff is the subsequent correction; candidate.public.diff combines exactly two paths. All were generated from the frozen current bytes. No patch has been applied to a tracked source.

The test keeps one unchanged headers/session/claims fixture for every pair. It explicitly requests page0,size100,sort=id,asc under Locale.ROOT then tr-TR for: account status=active; status=active with uppercase role=ADMIN; lowercase role=admin with uppercase grant roleStatus=ACTIVE. The third query omits account status so it makes no assertion about combined scalar/grant filter policy.

Each pair computes SQL-expected ordered ID/status rows for that exact predicate, requires nonempty/ADMIN_ID1 inclusion/archivedUserId exclusion and <=100 rows. The ROOT HTTP200 body must match those rows and page.totalElements/returnedCount. Turkish HTTP200 projected ID/status/count must equal ROOT. Unknown400 is checked before SoftAssertions.assertAll. Aggregate equality records allow both role and grant-status divergence to be reported by one selected test, rather than stopping before the second witness. A valid empty HATEOAS page can omit _embedded: the helper represents it as empty and the nonempty/equality oracle catches it. Two equally empty pages cannot pass.

The projection contains only synthetic IDs, wire status strings and counts. It does not compare, print or retain registry names/login/Telegram/password/personal bodies or credential headers. Expected status names follow the existing plain enum/Jackson wire source; the mandatory ROOT SQL-positive gate must succeed before any failure is classified as the hypothesized locale bug.

## Verification and smallest next runtime

Current checks are harmless byte/text preservation and input identity only. They prove the old test file is identical outside this method extension and three imports, the product candidate reverts exactly to original bytes after removing the two arguments/import/linewraps, and the same selected-session/negative/finally logic remains. Java parser/compiler/formatter/test execution is NOT_RUN. The independent missing-oracle input manifesta22a/ZIPecad identities were checked and used as evidence, not new product policy. One initial guessed manifest filename was corrected to the actual manifest.json before ledger/plan completion; this was a read-pointer error, not native or product failure.

After live stand cleanup and a fresh Root disk/memory/time/source/ownership grant, materialize an assigned isolated checkout and run ONLY:

./gradlew :services:academic-service:academic-app:integrationTest --tests ru.rutcampustrack.academic.integration.AcademicGrpcIT.enumDatabaseAndHttpBoundaryRemainCanonicalUnderTurkishLocale --no-daemon --max-workers=1

The method uses genuine Academic HTTP/JPA + fresh owned PostgreSQL16 and internal-signed actor seam; it requires no full suite, real Auth/Rabbit delivery, native Renderer or browser. Rabbit remains the existing Mockito seam. Root must choose measured test/Gradle heap/RSS/floor/cleanup caps and fresh execution/class/XML identities; this plan does not grant or predict sufficient runtime capacity. Do not build/materialize while the current live stand lacks reserve.

BEFORE uses the unchanged production predicate plus the test extension only. Meaningful expected RED: canonical SQL/body positives pass, baseline scalar active pair remains equal, all accepted HTTP responses are200 and unknown400, while the two tr-TR grant variants lose the seeded admin row/count and fail named ENUM_ROW_EQUALITY projections. Compiler, fixture/body schema, admission, timeout or infrastructure failure does not confirm this hypothesis. Stop and classify those distinctly.

Only if that native RED confirms the locus, apply the exact two-call candidate and run the SAME test bytes. GREEN_AFTER must be one selected JUnit PASS with zero failures/errors/skips, all three exact nonempty projections/negative400/locale-session cleanup, and all owned runtime reaped/restored source recorded. The intra-run same-session promise is distinct from the two separate fresh before/after fixture runs. Old CI or earlier status-only tests cannot supply new green.

No broad enum, migration, security, admin or client family is closed by this plan or even its future finite row witness. Root is sole shared-doc integrator; ci731_reconcile must independently review this author's stable candidate and later evidence. Requested/selected inherited Sol6.1/xhigh; actual UNKNOWN. PLAN.safe.json contains the nine-field handoff and exact future stage constraints.
