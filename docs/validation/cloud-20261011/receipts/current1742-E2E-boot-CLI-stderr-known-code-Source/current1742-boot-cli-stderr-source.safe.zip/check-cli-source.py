"""Finite synthetic CLI cases + exact old/new descriptor redirection in RAM."""
import ast,datetime,hashlib,importlib.util,json,os,re,resource,stat,sys,types
from pathlib import Path

OWN=Path(__file__).parent
spec=importlib.util.spec_from_file_location('cli',OWN/'closed-cli-failure.py')
cli=importlib.util.module_from_spec(spec);spec.loader.exec_module(cli)
checks=[]
def case(name,fn,deny=False):
    try:
        result=fn();assert not deny
        assert 'PRIVATE_CANARY' not in json.dumps(result)
    except cli.Blocked:
        assert deny
    checks.append({'case':name,'passed':True})
case('HTTP403 message/address discarded',lambda:cli.parse(b'gh: PRIVATE_CANARY https://private.invalid (HTTP 403)\n',1))
case('TLS authority message/address discarded',lambda:cli.parse(b'Get PRIVATE_CANARY: x509: certificate signed by unknown authority\n',1))
case('proxy transport context discarded',lambda:cli.parse(b'proxyconnect tcp: PRIVATE_CANARY: connection refused\n',1))
case('auth marker only',lambda:cli.parse(b'To get started with GitHub CLI, please run: gh auth login\nPRIVATE_CANARY\n',4))
case('unknown message staysUNKNOWN',lambda:cli.parse(b'PRIVATE_CANARY unknown\n',1))
case('unknown HTTPcode denied',lambda:cli.parse(b'gh: PRIVATE_CANARY (HTTP 998)\n',1),True)
case('malformedUTF8 denied',lambda:cli.parse(b'\xff',1),True)
case('ANSI denied',lambda:cli.parse(b'\x1b[31mPRIVATE_CANARY',1),True)
case('NUL denied',lambda:cli.parse(b'PRIVATE_CANARY\0',1),True)
case('longline denied',lambda:cli.parse(b'x'*65537,1),True)
case('helperpreexec2 notGHdiag',lambda:cli.parse(b'public',2),True)
case('success notfailurediag',lambda:cli.parse(b'public',0),True)
base={'settled':True,'all_owned_processes_reaped':True,'supervision_error_type':None,
    'terminal_reason':'NATIVE_TERMINAL','signal_count':0,'native_exit':1}
assert cli.eligible(base)
for patch in [{'settled':False},{'native_exit':2},{'native_exit':-15},{'signal_count':1},
    {'terminal_reason':'RESOURCE_GUARD'},{'supervision_error_type':'UNKNOWN'}]:
    assert not cli.eligible(dict(base,**patch))
checks.append({'case':'onlysettlednative1or4_NATIVETERMINAL_nosignal_eligible','passed':True})

mapping=[]
for label,path in [('old',OWN.with_name('current1742_e2e_boot_diagnostic_source_r2')/'capture-job-private.py'),
    ('new',OWN/'capture-job-private.py')]:
    tree=ast.parse(path.read_text());env={'Path':Path,'dt':datetime,'hashlib':hashlib,
        'json':json,'stat':stat,'__file__':str(path)}
    nodes=[n for n in tree.body if isinstance(n,(ast.FunctionDef,ast.ClassDef,ast.Assign))]
    exec(compile(ast.Module(body=nodes,type_ignores=[]),str(path),'exec'),env)
    now=datetime.datetime.now(datetime.timezone.utc)
    g={'authorized':True,'scope':'EXACT1742_JOB_LOG_READ_ONLY','head':'1742d1e806faa5c39c6d182a3554daa8f4239801',
        'run_id':38387263916,'job_id':115262001797,'run_attempt':1,
        'capture_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'max_bytes':33554432,'phase_seconds':45,
        'not_before':now.isoformat(),'cleanup_gate':(now+datetime.timedelta(seconds=90)).isoformat(),
        'hard_stop':(now+datetime.timedelta(seconds=120)).isoformat(),'private_directory_identity':[1,2,1000,1000,0o700]}
    env['sys']=types.SimpleNamespace(argv=[str(path),'--grant',str(path.parent/'private/read-grant.json')])
    env['private_read']=lambda *a:json.dumps(g).encode()
    env['fresh']=lambda _:None  # Unchanged accepted fresh predicate not rerun.
    fdmap={};calls=[]
    def open_(name,*a,**k):return 100 if str(name)=='job.log.private' else 200 if str(name)=='/dev/null' else 10
    def dup2(source,target):fdmap[target]=source
    class ExecReached(Exception):pass
    def execv(program,argv):
        assert program=='/usr/bin/gh' and argv==['gh','api','--method','GET',env['ENDPOINT']]
        raise ExecReached()
    env['os']=types.SimpleNamespace(O_RDONLY=os.O_RDONLY,O_DIRECTORY=os.O_DIRECTORY,
        O_NOFOLLOW=os.O_NOFOLLOW,O_WRONLY=os.O_WRONLY,O_CREAT=os.O_CREAT,O_EXCL=os.O_EXCL,
        O_RDWR=os.O_RDWR,getuid=lambda:1000,open=open_,close=lambda _:None,
        fstat=lambda _:types.SimpleNamespace(st_dev=1,st_ino=2,st_uid=1000,st_gid=1000,st_mode=0o40700),
        dup2=dup2,execv=execv)
    env['resource']=types.SimpleNamespace(RLIMIT_FSIZE=resource.RLIMIT_FSIZE,
        setrlimit=lambda key,value:calls.append((key,value)))
    try:env['main']()
    except ExecReached:pass
    assert calls==[(resource.RLIMIT_FSIZE,(33554432,33554432))]
    assert fdmap[1]==100 and fdmap[0]==200
    assert fdmap[2]==(200 if label=='old' else 100)
    mapping.append({'source':label,'stdout_private':True,'stderr_private':label=='new',
        'combined_hard_bytes':33554432,'actual_syscalls_native':False})
checks.append({'case':'exactactualhelperoldDEVNULL_newsameprivateFD_CAPunchanged','passed':True})
print(json.dumps({'state':'CLI_SOURCE_RAM_PASS','checks':checks,'FD_mapping':mapping,
    'actual_API_log_native':False,'historicalnative1cause':'UNKNOWN'}))
