from pathlib import Path
import collections, hashlib, json, os, zipfile
P=Path(__file__).parent
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
meta=json.loads((P/'metadata-terminal.safe.json').read_text())
assert all(r['run']['status']=='completed' for r in meta['runs'])
counts=collections.defaultdict(collections.Counter); rows=[];targets=[];broker=[];checkouts=set()
for p in sorted(P.glob('safe-*-outcomes-*.safe.json')):
 v=json.loads(p.read_text());rows.append({'artifact_id':v['artifact_id'],'name':v['name'],'archive_sha256':v['archive_sha256'],'archive_bytes':v['archive_bytes']})
 for r in v['results']:
  m=r['metadata'];counts[(m['runId'],m['task'])].update(r['counts']);checkouts.add(m['checkoutSha'])
  assert r['collection']=='RESULTS' and r['xml_case_summary_consistent'] and r['declared_consistent']
  if r['target']:targets.append({'run_id':m['runId'],**r['target']})
for p in sorted(P.glob('*-integrationTest.json')):
 v=json.loads(p.read_text())
 broker.extend({'run_id':v['metadata']['runId'],**c} for c in v['cases'] if 'BrokerBridgeIT' in (c.get('classname') or ''))
assert len(rows)==18 and len(checkouts)==1
for id in ['38340987190','38340987005']:
 assert counts[(id,'test')]['PASSED']==1485 and counts[(id,'integrationTest')]['PASSED']==1111
 assert counts[(id,'integrationTest')]['SKIPPED']==3 and counts[(id,'test')]['SKIPPED']==0
 assert all(counts[(id,t)][k]==0 for t in ['test','integrationTest'] for k in ['FAILED','ERROR','NOT_EXECUTED'])
browser=json.loads((P/'first3-safe-1.safe.json').read_text())
result={'producer':meta['producer'],'gates':[{k:r['run'][k] for k in ['id','name','event','run_attempt','status','conclusion','head_sha','updated_at']} for r in meta['runs']],
 'actual_java_checkout':next(iter(checkouts)),'java_safe_artifact_count':18,'counts':[{'run_id':k[0],'task':k[1],**v} for k,v in sorted(counts.items())],
 'targets':targets,'broker_current_native_case_rows':broker,'browser':browser,
 'job_steps':[{ 'run_id':r['run']['id'],'job_id':j['id'],'job':j['name'],'status':j['status'],'conclusion':j['conclusion'],'non_success_steps':[s for s in j['steps'] if s['conclusion']!='success']} for r in meta['runs'] for j in r['jobs']],
 'limits':['Browser SAFE does not prove actual browser checkout SHA; Java checkout is independently source-bound.', 'FIRST3 all3 fast FAIL; diagnostics UNKNOWN/httpStatus0; all3 observer files missing; no503/body/assertion-stage cause inferred.', 'Native Java counts are distinct workflow executions, not summed unique product cases or matrix-parent acceptance.', 'Historical96 CAP failure cause stays UNKNOWN; current CAP PASS does not establish flaky history.', 'Current BrokerBridgeIT single method is PASS in both workflows; no seven independent test-method claim or post-mutation green substitution.', 'Conditional and legacy steps retain explicit skipped outcomes; Security built-image scan skip is not scan PASS.'],
 'raw_logs_XML_read':False,'product_acceptance':'NOT_PROMOTED'}
os.umask(0o077)
with (P/'final-outcome.safe.json').open('x') as f:json.dump(result,f,indent=2);f.write('\n')
report='Current481: CI FAIL; Coverage/Security/OpenAPI SUCCESS.\n\nEach Java workflow:1485 unit+1111 integration PASS/3 SKIP/0 failures/errors/not-executed; actual checkout0f7ba8b1fe11550c746ed4d540f51445b7f2180a, producer48124. Locale dd0c and CAP b40d methods PASS in both. BrokerBridgeIT actual same single method/sourceac58 PASS in both. FIRST3 lines14/61/142 FAIL63/54/53ms; each new closed diagnostic UNKNOWN/UNKNOWN/0, declaration-only errorLocations, all3 observers missing. No503 or stage cause proved. Historical96CAPcause UNKNOWN.\n\nMetadata+19 exact SAFE archives only; no rawJUnit/log/private body. Canonical reporter41c0/privacy262c and strict optional diagnostics source prep0c413/c419 unchanged. No matrix/client family promotion.\n'
with (P/'HANDOFF.md').open('x') as f:f.write(report)
files=[p for p in P.iterdir() if p.is_file() and not p.name.startswith('.')]
manifest={'producer':meta['producer'],'scope':'CURRENT_NORMAL_ACTIONS_SAFE_ONLY','files':[{'path':p.name,'bytes':p.stat().st_size,'sha256':sha(p)} for p in sorted(files)],'raw_XML_logs_private_fields':False}
with (P/'manifest.safe.json').open('x') as f:json.dump(manifest,f,indent=2);f.write('\n')
with zipfile.ZipFile(P/'safe-current-evidence.zip','x',zipfile.ZIP_DEFLATED) as z:
 for p in sorted(files)+[P/'manifest.safe.json']:z.write(p,p.name)
with zipfile.ZipFile(P/'safe-current-evidence.zip') as z:assert z.testzip() is None;members=len(z.infolist())
print(json.dumps({'manifest_sha256':sha(P/'manifest.safe.json'),'ZIP_sha256':sha(P/'safe-current-evidence.zip'),'ZIP_bytes':(P/'safe-current-evidence.zip').stat().st_size,'members':members,'safe_file_count':len(files),'crc_errors':0,'gate_outcomes':['CI_FAIL','COVERAGE_SUCCESS','SECURITY_SUCCESS','OPENAPI_SUCCESS']}))
