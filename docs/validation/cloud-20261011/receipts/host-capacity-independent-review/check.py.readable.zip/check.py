from pathlib import Path
import collections, datetime, hashlib, json, os, re, stat, subprocess

ROOT = Path('/workspace/scratch/rct-validation/host_capacity_review')
PLAN = Path('/workspace/scratch/rct-validation/host_capacity_plan')
BASE = Path('/workspace/rct-worktrees')
REF = BASE / 'client-acceptance'
deny = re.compile(r'(^|/)(\.env[^/]*|\.npmrc|\.aws|\.codex|secrets?|certs?|certificates?|keys?)(/|$)|\.(pem|key|p12|pfx|jks|keystore)$', re.I)
cache = {}
def digest(path, expected):
    key=(expected.st_dev,expected.st_ino,expected.st_size,expected.st_mtime_ns)
    if key in cache: return cache[key]
    fd=os.open(path,os.O_RDONLY|os.O_NOFOLLOW)
    with os.fdopen(fd,'rb') as stream:
        first=os.fstat(stream.fileno());h=hashlib.sha256()
        assert (first.st_dev,first.st_ino,first.st_size,first.st_mtime_ns)==key
        for block in iter(lambda:stream.read(1024*1024),b''):h.update(block)
        final=os.fstat(stream.fileno())
        assert (final.st_dev,final.st_ino,final.st_size,final.st_mtime_ns)==key
    cache[key]=h.hexdigest();return cache[key]
def git(root,*args):
    env=dict(os.environ);env['GIT_OPTIONAL_LOCKS']='0'
    return subprocess.check_output(['git','-C',str(root),*args],env=env).decode()
def category(rel):
    if rel.startswith('.agent/evidence/'): return 'excluded_historical_agent_evidence'
    if any(p in rel.split('/') for p in ('build','dist','node_modules','.gradle')):return 'excluded_derived_outputs'
    return 'remaining_subject_to_Root_boundary'
def inspect(item):
    path=Path(item['path']);assert path.is_absolute()
    assert not any(p.is_symlink() for p in (path,*path.parents))
    s=path.lstat();assert stat.S_ISREG(s.st_mode)
    actual=(s.st_dev,s.st_ino,s.st_size,s.st_mtime_ns,s.st_nlink,s.st_blocks*512,stat.S_IMODE(s.st_mode),s.st_uid,s.st_gid)
    claimed=(item['device'],item['inode'],item['bytes'],item['mtime_ns'],item['nlink'],item['allocated_bytes'],int(item['mode'],8),item['uid'],item['gid'])
    assert actual==claimed,(str(path),'metadata differs')
    return path,s
manifest=json.loads((PLAN/'manifest.json').read_text());input_results=[]
for row in manifest['files']:
    p=Path(row['path']);s=p.lstat();assert s.st_size==row['bytes']
    sha=digest(p,s);assert sha==row['sha256']
    input_results.append({'path':p.name,'sha256':sha,'bytes':s.st_size})
assert len(input_results)==36
d=json.loads((PLAN/'source-diagnosis.json').read_text());rows=[];heads=[]
assert 'ci-academic-heap' not in [s['scope'] for s in d['scopes']]
assert 'np01-domain-bot' not in [s['scope'] for s in d['scopes']]
for scope in d['scopes']:
    root=BASE/scope['scope'];assert git(root,'rev-parse','HEAD').strip()==scope['head']
    assert not git(root,'status','--porcelain','--untracked-files=no').strip()
    tracked=set(git(root,'ls-files','-z').split('\0'))
    rs=json.loads((PLAN/(scope['scope']+'-candidates.json')).read_text())
    assert all(r['relative_path'] in tracked for r in rs)
    rows+=rs;heads.append({'scope':scope['scope'],'head':scope['head'],'tracked_clean':True})
assert git(REF,'rev-parse','HEAD').strip()=='eec3e0a864626160d33ae29da2cf3b0640e30caa'
assert not git(REF,'status','--porcelain','--untracked-files=no').strip()
reftracked=set(git(REF,'ls-files','-z').split('\0'))
seen=set();totals=collections.defaultdict(lambda:{'rows':0,'allocated_bytes':0});mismatches=[];hash_count=0
for r in rows:
    rel=r['relative_path'];assert rel in reftracked
    assert rel and not rel.startswith('/') and '..' not in Path(rel).parts and '\\' not in rel
    assert not deny.search(rel) and not rel.startswith('docs/validation/')
    assert r['candidate']['path']==str(BASE/r['scope']/rel)
    assert r['reference']['path']==str(REF/rel)
    a,sa=inspect(r['candidate']);b,sb=inspect(r['reference'])
    assert sa.st_nlink==1 and sa.st_dev==sb.st_dev and sa.st_ino!=sb.st_ino
    assert all(r['candidate'][k]==r['reference'][k] for k in ('sha256','bytes','mode','uid','gid','device'))
    inode=(sa.st_dev,sa.st_ino);assert inode not in seen;seen.add(inode)
    cat=category(rel);totals[cat]['rows']+=1;totals[cat]['allocated_bytes']+=sa.st_blocks*512
    if cat=='remaining_subject_to_Root_boundary':
        assert digest(a,sa)==r['candidate']['sha256']
        assert digest(b,sb)==r['reference']['sha256'];hash_count+=1
result={'time':datetime.datetime.now(datetime.timezone.utc).isoformat(),'input_manifest_sha256':hashlib.sha256((PLAN/'manifest.json').read_bytes()).hexdigest(),'all36_input_hashes_verified':True,'input_files':input_results,'scopes':heads,'reference_head':git(REF,'rev-parse','HEAD').strip(),'reference_tracked_clean':True,'rows_metadata_verified':len(rows),'globally_unique_nlink1_candidates':len(seen),'potential_all_rows_allocated_bytes':sum(v['allocated_bytes'] for v in totals.values()),'category_totals':dict(totals),'independent_sha_pairs_verified':hash_count,'hash_cache_unique_inodes':len(cache),'secret_evidence_derived_contents_not_opened':True,'path_traversal_symlink_checks':True,'mode_UID_GID_device_size_equal':True,'metadata_and_inodes_unchanged':True,'mtime_before_differs_from_reference_count':sum(r['candidate']['mtime_ns']!=r['reference']['mtime_ns'] for r in rows),'actual_reclaimed_bytes':0,'resource_mutations':False,'own_processes_after_exit':[]}
(ROOT/'independent-candidate-check.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k not in ('input_files','scopes')}))
