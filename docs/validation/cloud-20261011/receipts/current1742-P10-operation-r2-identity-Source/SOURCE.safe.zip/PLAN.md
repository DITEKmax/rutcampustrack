# P10 operation r2 — Source only

Only the reviewed exception lookup P2 is corrected: fixed19 tuple and type identity comparisons replace class-hashing/equality dictionary lookup. Two exact selected-catch AST/RAM counterexamples now refuse unknown hooks and yield OTHER/status0/BOUNDARY_UNKNOWN. The19 ordinary enums,8 status cases,15 static stages, parentc5af/b78/caps and18 pins are reused from review97e9. Whole-file inverse is exact outside this one mapping block. Original2701/57a9 stays immutable; frozen5dac104e remains clean. Source edit helper AST field-call checking failure is retained, corrected before child write; no runtime defect.

No env or transport change. A separate public-key/string policy proposal describes forwarding only ordinary urllib proxy and SSL CA context if Root later grants technical scope; no actual environment keypresence/value or URL probe. Actual02/currentP10 causes stay UNKNOWN. Existing actual02 response remains private RAM. No native/API/test/privateXML/log/B013 operation.

READY.safe.json holds exact Source pins/false template/argv. Narrow same-reviewer recheck and a new Root grant remain required.
