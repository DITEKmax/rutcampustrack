"""Read-only native/cache observations. No JVM, Gradle, app, or container start."""

from pathlib import Path
import datetime
import hashlib
import importlib.metadata
import json
import os
import subprocess
import time

HERE = Path(__file__).resolve().parent
ROOT = Path('/workspace/rutcampustrack')
ENV = {'PATH': '/usr/local/bin:/usr/bin:/bin', 'LANG': 'C.UTF-8', 'LC_ALL': 'C.UTF-8', 'TZ': 'UTC', 'PYTHONDONTWRITEBYTECODE': '1'}


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write(name, obj):
    p = HERE / name
    assert not p.exists()
    p.write_text(json.dumps(obj, indent=2) + '\n')
    p.chmod(0o600)


commands = [
    ('docker-images', ['/usr/local/bin/docker', 'image', 'inspect', 'postgres:16-alpine', 'rabbitmq:3.13-management-alpine', 'redis:7-alpine', 'testcontainers/ryuk:0.11.0', '--format', '{"id":{{json .Id}},"tags":{{json .RepoTags}},"digests":{{json .RepoDigests}},"logical_bytes":{{json .Size}},"arch":{{json .Architecture}},"os":{{json .Os}}}']),
    ('docker-containers', ['/usr/local/bin/docker', 'ps', '--all', '--format', '{"id":{{json .ID}},"image":{{json .Image}},"state":{{json .State}},"name":{{json .Names}},"ports":{{json .Ports}}}']),
    ('docker-engine', ['/usr/local/bin/docker', 'info', '--format', '{"version":{{json .ServerVersion}},"driver":{{json .Driver}}}']),
    ('python-version', ['/workspace/rct-cloud-setup/bot-venv/bin/python3.12', '-I', '-B', '-S', '-c', 'import sys,json; print(json.dumps({"version":sys.version.split()[0],"executable":sys.executable}))']),
]
results = {}
for name, argv in commands:
    started = time.monotonic()
    done = subprocess.run(argv, env=ENV, capture_output=True, text=True, timeout=20)
    for suffix, value in [('stdout', done.stdout), ('stderr', done.stderr)]:
        p = HERE / (name + '.' + suffix + '.private.log')
        assert not p.exists()
        p.write_text(value)
        p.chmod(0o600)
    results[name] = {'argv': argv, 'exit': done.returncode, 'elapsed_seconds': round(time.monotonic() - started, 3), 'rows': [json.loads(line) for line in done.stdout.splitlines()] if done.returncode == 0 else [], 'stderr_bytes': len(done.stderr.encode())}

site = Path('/workspace/rct-cloud-setup/bot-venv/lib/python3.12/site-packages')
packages = []
for dist in importlib.metadata.distributions(path=[str(site)]):
    packages.append({'name': dist.metadata['Name'], 'version': dist.version, 'metadata_sha256': hashlib.sha256((dist.read_text('METADATA') or '').encode()).hexdigest()})
versions = {row['name'].lower().replace('_', '-'): row['version'] for row in packages}
pins = []
for line in (ROOT / 'services/notification-bot/requirements.txt').read_text().splitlines():
    value = line.split('#')[0].strip()
    if '==' not in value:
        continue
    name, version = value.split('==')
    name = name.split('[')[0].lower().replace('_', '-')
    pins.append({'name': name, 'required': version, 'installed': versions.get(name), 'matches': versions.get(name) == version})

disks = {}
for path in ['/workspace', '/tmp']:
    stat = os.statvfs(path)
    disks[path] = {'available_bytes': stat.f_bavail * stat.f_frsize, 'total_bytes': stat.f_blocks * stat.f_frsize, 'device': Path(path).stat().st_dev}
cgroup = {name: (Path('/sys/fs/cgroup') / name).read_text().strip() for name in ['memory.current', 'memory.max', 'memory.peak', 'cpu.max', 'pids.current']}
heavy = []
zombies = 0
for proc in Path('/proc').iterdir():
    if not proc.name.isdigit():
        continue
    try:
        comm = (proc / 'comm').read_text().strip()
        stat = (proc / 'stat').read_text().rsplit(')', 1)[1].split()
        if comm in {'java', 'node', 'mongod', 'postgres', 'redis-server', 'beam.smp', 'chrome', 'chromium', 'firefox', 'MiniBrowser'}:
            if stat[0] == 'Z':
                zombies += 1
            else:
                heavy.append({'pid': int(proc.name), 'comm': comm, 'state': stat[0], 'birth_ticks': int(stat[19])})
    except (OSError, ValueError):
        pass
write('native-metadata.safe.json', {'utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'native_readonly_commands': results, 'python_runtime_pins': pins, 'python_installed_packages': sorted(packages, key=lambda row: row['name'].lower()), 'disk': disks, 'cgroup': cgroup, 'active_heavy': heavy, 'foreign_zombie_heavy_count': zombies, 'qualifications': ['No JVM/Gradle/import of bot/server/tests/container start.', 'Metadata versions/pins verified; product imports and current offline resolution NOT_RUN.', 'Snapshot only; final grant requires fresh samples and explicit sole lease.'], 'environment_names': list(ENV), 'environment_dump': False})
print(json.dumps({'read_only_exits': {name: row['exit'] for name, row in results.items()}, 'runtime_pin_count': len(pins), 'all_pins_match': all(row['matches'] for row in pins), 'active_heavy': heavy, 'workspace_available': disks['/workspace']['available_bytes'], 'shared_memory': cgroup['memory.current']}))
