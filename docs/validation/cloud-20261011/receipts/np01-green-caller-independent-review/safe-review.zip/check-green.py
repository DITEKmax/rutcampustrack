"""Independent green-only source review; no helper imports/native runtime."""
import ast, copy, hashlib, hmac, json, os, re, stat, struct, subprocess, zipfile
from pathlib import Path, PurePosixPath
from types import SimpleNamespace
OWN=Path(__file__).resolve().parent
G=Path('/workspace/scratch/rct-validation/np01_broker_sensitivity_green_caller')
F=Path('/workspace/scratch/rct-validation/np01_broker_sensitivity_caller_correction')
O=Path('/workspace/scratch/rct-validation/np01_broker_sensitivity_sourceprep')
W=Path('/workspace/rct-worktrees/np01-broker-sensitivity')
R=F/'np01-fault-20261012-attempt01'
checks=[]
def check(name,truth):
    assert truth,name
    checks.append({'id':name,'passed':True})
def sha(p):
    h=hashlib.sha256()
    with p.open('rb') as s:
        while b:=s.read(32768):h.update(b)
    return h.hexdigest()
def save(n,x):
    with(OWN/n).open('x')as f:json.dump(x,f,indent=2);f.write('\n')
    (OWN/n).chmod(0o600)
def seal(root,manifest,archive,expected_manifest,expected_archive):
    if expected_manifest:check('manifest_'+root.name,sha(root/manifest)==expected_manifest)
    d=json.loads((root/manifest).read_text())
    for row in d['entries']:
        p=root/row['path'];s=p.lstat()
        check('sealed_'+root.name+'_'+row['path'],stat.S_ISREG(s.st_mode)and stat.S_IMODE(s.st_mode)==0o600 and s.st_size==row['bytes']and sha(p)==row['sha256'])
    check('archive_'+root.name,sha(root/archive)==expected_archive)
    with zipfile.ZipFile(root/archive)as z:
        check('archive_CRC_'+root.name,z.testzip()is None)
        check('archive_exact_members_'+root.name,set(z.namelist())=={x['path']for x in d['entries']}|{manifest}and len(z.namelist())==len(d['entries'])+1)
        for row in d['entries']:check('archive_body_'+root.name+'_'+row['path'],hashlib.sha256(z.read(row['path'])).hexdigest()==row['sha256'])
    return d
seal(G,'manifest.safe.json','safe-green-caller-source.zip','886c5ce8f68aa3aff26b71ce4425f88d9a60fe96eb02557c3eec18e998e5158e','baf78c4f8ca5c7f71aca66220fbc19cdb634c1df2b58c26a5ae79478cc92c765')
seal(F,'manifest.safe.json','safe-caller-correction.zip','e1fd1f85bbd7afa727a036f920a61701140f262fe0cd3dd58873cf98e32cc61c','075a2b77ee06a8e5d051aba98ca1348c08d62e4595052a93f2fb4a1b105da9cc')
original=seal(O,'manifest.safe.json','safe-sourceprep.zip','37a7a45b6567a5ea23190e8a61e1a443942a41c0e1ce985b3f8618e5134d2ee9','8384a33ae7cdaf43a7036d4fc0409cd96c412824ffab48c77834033c5771d313')
seal(R,'safe-fault-manifest.json','safe-native-fault-restoration.zip',None,'c41ae9bc1ce06735c7283ace40deda64f93d6429ceae848cf02ef4a564695695')
check('prior37d_approval_immutable',sha(OWN.parent/'correction_recheck/manifest.json')=='37d25c7b51cddd4450e91385e182658015d5550baed564e23245641fca364b3c')
check('restoration_receipt_exact',sha(R/'restoration.safe.json')=='306daff687a98acb9ca2ac2142228d02c2fce98b8865e1f77a3aa96907e70791')

gt=ast.parse((G/'caller-boundary.py').read_text());ft=ast.parse((F/'caller-boundary.py').read_text())
gd=ast.parse((G/'run-stage.py').read_text());fd=ast.parse((F/'run-stage.py').read_text())
dump=lambda x:ast.dump(x,include_attributes=False)
func=lambda t:{n.name:n for n in t.body if isinstance(n,ast.FunctionDef)}
gb,fb,gr,fr=func(gt),func(ft),func(gd),func(fd)
for name in fb:
    if name not in {'validate_body_identities','source_preflight'}:check('boundary_unchanged_'+name,dump(gb[name])==dump(fb[name]))
for name in ['digest','utc','output','environment']:check('driver_unchanged_'+name,dump(gr[name])==dump(fr[name]))
newmain=copy.deepcopy(gr['main']);oldmain=fr['main']
phase_call=next(n for n in ast.walk(newmain)if isinstance(n,ast.Call)and isinstance(n.func,ast.Attribute)and n.func.attr=='add_argument'and n.args and isinstance(n.args[0],ast.Constant)and n.args[0].value=='phase')
choices=next(k for k in phase_call.keywords if k.arg=='choices')
check('CLI_green_ONLY',ast.literal_eval(choices.value)==['green'])
choices.value=ast.parse("['compile','fault']",mode='eval').body
check('complete_main_protocol_unchanged_except_phase',dump(newmain)==dump(oldmain))
oldlimit=next(n for n in fr['grant_input'].body if isinstance(n,ast.If)and 'bounded resource specification' in ast.unparse(n))
newlimit=copy.deepcopy(next(n for n in gr['grant_input'].body if isinstance(n,ast.If)and 'bounded resource specification' in ast.unparse(n)))
deadlinecmp=next(n for n in ast.walk(newlimit)if isinstance(n,ast.Compare)and ast.unparse(n.left)=='0'and any("deadline_seconds"in ast.unparse(x)for x in n.comparators))
deadlinecmp.comparators[-1]=ast.parse("600 if phase == 'compile' else 900",mode='eval').body
check('all_resource_caps_unchanged_except_green_900',dump(newlimit)==dump(oldlimit))
oldgrant=fr['grant_input'].body;newgrant=gr['grant_input'].body
oldpre=next(i for i,n in enumerate(oldgrant)if 'boundary.source_preflight' in ast.unparse(n))
newpre=next(i for i,n in enumerate(newgrant)if 'boundary.source_preflight' in ast.unparse(n))
check('self_helper_guard_review_and_preflight_prefix_unchanged',dump(ast.Module(body=newgrant[:newpre+1],type_ignores=[]))==dump(ast.Module(body=oldgrant[:oldpre+1],type_ignores=[])))
boundarytext=ast.unparse(gb['source_preflight'])
check('green_size_all1945_before_body_hash',"size = row['bytes']"in boundarytext and boundarytext.index('file_metadata(path')<boundarytext.index('current_hashes ='))

names={'safe_relative','pathset_hash','validate_ledger','validate_manifest_shape','validate_body_identities','validate_child_witness','file_metadata'}
pure=[n for n in gt.body if isinstance(n,ast.Assign)or isinstance(n,ast.FunctionDef)and n.name in names]
ns={'hashlib':hashlib,'hmac':hmac,'json':json,'PurePosixPath':PurePosixPath,'re':re,'stat':stat,'os':SimpleNamespace(getuid=os.getuid)}
exec(compile(ast.Module(body=pure,type_ignores=[]),'<green-pure-boundary>','exec'),ns)
ledger=json.loads((O/'complete-sparse-baseline.safe.json').read_text())
selected={x['path']:x for x in json.loads((O/'sourceprep.safe.json').read_text())['changes']}
grant={k:ns[v] for k,v in [('sourceprep_manifest_sha256','MANIFEST_SHA'),('baseline_sha256','BASELINE_SHA'),('baseline_entry_count','COUNT'),('baseline_pathset_sha256','PATHSET_SHA'),('index_scope_sha256','INDEX_SHA')]}
def admit(l,current):
    try:rows=ns['validate_ledger'](l,grant);ns['validate_body_identities'](rows,selected,current);return True
    except(ValueError,KeyError,TypeError):return False
BASE=ns['BASE'];env={'PATH':'/usr/local/bin:/usr/bin:/bin','LANG':'C.UTF-8','LC_ALL':'C.UTF-8','GIT_OPTIONAL_LOCKS':'0'}
def git(*args):return subprocess.check_output(['git','-C',str(W),*args],env=env,stderr=subprocess.DEVNULL,timeout=15)
check('actual_EB_HEAD',git('rev-parse','HEAD').strip().decode()==BASE)
check('actual_detached',subprocess.run(['git','-C',str(W),'symbolic-ref','-q','HEAD'],env=env,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,timeout=15).returncode==1)
index=git('ls-files','--stage','-z');check('logical_index_exact',hashlib.sha256(index).hexdigest()==ns['INDEX_SHA'])
indexed=[x.split(b'\t',1)[1].decode()for x in index.split(b'\0')if x]
present=[x for x in indexed if os.path.lexists(W/x)]
check('actual_1945_populated_exact',len(present)==1945 and set(present)=={x['path']for x in ledger['entries']})
check('no_nonignored_untracked',not git('ls-files','--others','--exclude-standard','-z'))
current={};protected=[]
for row in ledger['entries']:
    path=W/row['path'];s=path.lstat()
    check('metadata_'+row['path'],stat.S_ISREG(s.st_mode)and stat.S_IMODE(s.st_mode)==0o600 and s.st_nlink==1 and s.st_uid==os.getuid()and s.st_size==row['bytes']and not any(p.is_symlink()for p in path.parents))
    if row['path']in ns['METADATA_ONLY']:
        protected.append({'path':row['path'],'bytes':s.st_size,'mode':'0600','nlink':s.st_nlink,'uid':s.st_uid});continue
    current[row['path']]=sha(path);check('BASE_body_'+row['path'],current[row['path']]==row['sha256'])
check('restored_BASE_1942_admitted',len(current)==1942 and admit(ledger,current))
check('exact3_protected_metadata_only',len(protected)==3)
for name,entry in selected.items():check('remaining_mutant_rejected_'+name,not admit(ledger,current|{name:entry['candidate_sha256']}))
check('both_mutants_rejected',not admit(ledger,current|{n:x['candidate_sha256']for n,x in selected.items()}))
for name,data in [('empty',{'base':BASE,'entries':[]}),('minimal',{'base':BASE,'entries':ledger['entries'][:1]}),('missing',{'base':BASE,'entries':ledger['entries'][:-1]}),('extra',{'base':BASE,'entries':ledger['entries']+[ledger['entries'][0]]})]:check('reject_'+name,not admit(data,current))
for name,entry in selected.items():check('Root_normal_unchanged_'+name,sha(Path('/workspace/rutcampustrack')/name)==entry['base_sha256'])

# Private XML is authorized hash-only streaming: no parse, raw output/copy or logs.
xml=W/'services/academic-service/academic-app/build/test-results/integrationTest/TEST-ru.rutcampustrack.academic.botcredentials.BotCredentialBrokerBridgeIT.xml'
klass=W/'services/academic-service/academic-app/build/classes/java/test/ru/rutcampustrack/academic/botcredentials/BotCredentialBrokerBridgeIT.class'
redhash='eba9a69dbc7bb3f1bbfc25d565a18ea01620860ea40a87a558d7352699d7a03b';classhash='ec889b58577188c9be1482eea3e44d514af2ef5dfd551bcd1e06d970de3f6a04'
provenance=[]
for path,anchor,expected in [(R/'native-junit.raw.private.xml',R,redhash),(xml,W,redhash),(klass,W,classhash)]:
    ns['file_metadata'](path,anchor,0o600);actual=sha(path);check('private_hash_only_'+path.name,actual==expected)
    s=path.stat();provenance.append({'path':str(path),'sha256':actual,'bytes':s.st_size,'mode':'0600','nlink':s.st_nlink,'mtime_ns':s.st_mtime_ns,'raw_body_parsed_or_published':False})
save('restored-source-provenance.safe.json',{'metadata_count':1945,'fresh_BASE_body_hashes':1942,'protected_metadata_only':protected,'protected3_body_read':False,'retained_outputs_hash_only':provenance,'source_writes':False,'green':'NOT_RUN'})

# Execute only the NEW provenance gate AST against virtual paths and digests.
start=next(i for i,n in enumerate(newgrant)if isinstance(n,ast.If)and 'original_red_seal_sha256'in ast.unparse(n))
end=next(i for i,n in enumerate(newgrant)if isinstance(n,ast.Assign)and 'limits'in ast.unparse(n.targets[0]))
gate=ast.Module(body=newgrant[start:end],type_ignores=[])
class VirtualPath:
    def __init__(self,name):self.name=str(name)
    def __truediv__(self,name):return VirtualPath(self.name+'/'+str(name))
    def __hash__(self):return hash(self.name)
    def __eq__(self,other):return isinstance(other,VirtualPath)and other.name==self.name
redseal='c41ae9bc1ce06735c7283ace40deda64f93d6429ceae848cf02ef4a564695695';restore='306daff687a98acb9ca2ac2142228d02c2fce98b8865e1f77a3aa96907e70791'
authority={'original_red_seal_sha256':redseal,'restoration_receipt_sha256':restore,'preserved_red_xml_sha256':redhash,'previous_mutant_class_sha256':classhash}
expected={'R/safe-native-fault-restoration.zip':redseal,'R/restoration.safe.json':restore,'R/native-junit.raw.private.xml':redhash,
 'W/services/academic-service/academic-app/build/test-results/integrationTest/TEST-ru.rutcampustrack.academic.botcredentials.BotCredentialBrokerBridgeIT.xml':redhash,
 'W/services/academic-service/academic-app/build/classes/java/test/ru/rutcampustrack/academic/botcredentials/BotCredentialBrokerBridgeIT.class':classhash}
def gate_accept(g=authority,d=expected,missing=None):
    def meta(path,*unused):
        if path.name==missing:raise ValueError('virtual absent/private metadata failure')
    scope={'grant':g,'RED_SEAL_SHA':redseal,'RESTORATION_SHA':restore,'RED_XML_SHA':redhash,'MUTANT_CLASS_SHA':classhash,
     'RED_DIRECTORY':VirtualPath('R'),'WT':VirtualPath('W'),'boundary':SimpleNamespace(file_metadata=meta),'digest':lambda p:d[p.name]}
    try:exec(compile(gate,'<actual-new-provenance-virtual>','exec'),scope);return True
    except(ValueError,KeyError):return False
check('authentic_green_provenance_gate_admits',gate_accept())
for key in authority:check('reject_provenance_grant_'+key,not gate_accept(g=authority|{key:'0'*64}))
for key in expected:
    check('reject_provenance_changed_'+key,not gate_accept(d=expected|{key:'0'*64}))
    check('reject_provenance_missing_'+key,not gate_accept(missing=key))
check('new_gate_before_guard_and_child_admission','grant, argv, deadline, boundary = grant_input' in ast.unparse(gr['main'])and gr['main'].body.index(next(n for n in gr['main'].body if isinstance(n,ast.Assign)and 'grant_input'in ast.unparse(n)))<gr['main'].body.index(next(n for n in gr['main'].body if isinstance(n,ast.If)and ast.unparse(n.test)=='args.child')))

procedure=json.loads((G/'native-procedure.safe.json').read_text());oldproc=json.loads((F/'native-procedure.safe.json').read_text());cmd=procedure['commands']['green']
expectedcmd=oldproc['commands']['fault'].copy();expectedcmd.insert(3,'--rerun')
check('only_green_command',set(procedure['commands'])=={'green'})
check('only_exact_task_specific_rerun_added',cmd==expectedcmd and '--rerun-tasks'not in cmd)
check('external_fresh_compile_XML_cleanup_gates',all(any(s in q for q in procedure['native_green_acceptance'])for s in ['compileTestJava actually executed','class hash differs','mtime after run start','tests1/failures0/errors0/skipped0','All own birth identities','16:12:21.322306']))

# Read installed public Gradle JAR/class constant pool, not JVM/javap/Gradle.
proof=json.loads((G/'gradle-task-rerun.safe.json').read_text());jar=Path(proof['jar'])
check('pinned_public_Gradle812_JAR',sha(jar)==proof['jar_sha256'])
with zipfile.ZipFile(jar)as z:bytecode=z.read(proof['class'])
check('pinned_TaskOptionsGenerator_class',hashlib.sha256(bytecode).hexdigest()==proof['class_sha256'])
assert bytecode[:4]==b'\xca\xfe\xba\xbe'
size=struct.unpack_from('>H',bytecode,8)[0];cp=[None]*size;offset=10;i=1
while i<size:
    tag=bytecode[offset];offset+=1
    if tag==1:
        n=struct.unpack_from('>H',bytecode,offset)[0];offset+=2;cp[i]=(tag,bytecode[offset:offset+n].decode('utf-8'));offset+=n
    elif tag in {3,4}:cp[i]=(tag,);offset+=4
    elif tag in {5,6}:cp[i]=(tag,);offset+=8;i+=1
    elif tag in {7,8,16,19,20}:cp[i]=(tag,struct.unpack_from('>H',bytecode,offset)[0]);offset+=2
    elif tag in {9,10,11,12,17,18}:cp[i]=(tag,*struct.unpack_from('>HH',bytecode,offset));offset+=4
    elif tag==15:cp[i]=(tag,*struct.unpack_from('>BH',bytecode,offset));offset+=3
    else:raise ValueError('Unsupported public class CP tag')
    i+=1
utf={x[1]for x in cp if x and x[0]==1};refs=[]
for x in cp:
    if x and x[0]in{10,11}:
        owner=cp[cp[x[1]][1]][1];nt=cp[x[2]];refs.append({'owner':owner,'method':cp[nt[1]][1],'descriptor':cp[nt[2]][1]})
check('rerun_literal_and_description_in_exact_class',proof['builtin_literal']in utf and proof['description']in utf)
check('rerun_output_predicate_method_refs',all(x in refs for x in proof['related_method_refs']))
save('independent-Gradle812-CP.safe.json',{'jar_sha256':proof['jar_sha256'],'class_sha256':proof['class_sha256'],
 'builtin_literal_verified':True,'description_verified':True,'output_predicate_refs_verified':True,
 'qualification':'Exact installed 8.12 public constant-pool evidence; no JVM/Gradle/CLI-help invocation. Actual selected task execution remains native obligation.'})
save('independent-checks.safe.json',{'status':'PASS_SOURCE_ONLY','checks':checks,'count':len(checks),'helper_imports':False,'runtime':'NOT_RUN',
 'protocol':'Full main AST equal except green phase; all common boundary functions and self/helper/guard/review preflight prefix exact to37d approval.',
 'private_XML':'Only explicit authorized hash-only streaming/metadata; no parse/body output/archive.',
 'protected3_body_reads':False,'native_GREEN':'NOT_RUN'})
print(json.dumps({'status':'PASS_SOURCE_ONLY','checks':len(checks),'metadata':1945,'BASE_body_hashes':1942,'green':'NOT_RUN'}))
