"""Safe visible outcome supplement; same actual disabled client as retained COMPAT test."""
import asyncio
import json
import runpy
from types import SimpleNamespace
from unittest.mock import AsyncMock

from bot.grpc_client.bot_credentials_client import BotCredentialsGrpcClient
from bot.handlers.start import cmd_start
from bot.services.bot_credential_cards import BotCredentialCards


async def observe():
    factory = runpy.run_path("tests/test_bot_credential_cards.py")["profile"]
    client = BotCredentialsGrpcClient("academic.test", 19491)
    client.read = AsyncMock(wraps=client.read)
    provider = SimpleNamespace(edit_message_text=AsyncMock())
    message = SimpleNamespace(from_user=SimpleNamespace(id=42),
                              chat=SimpleNamespace(id=42, type="private"), answer=AsyncMock())
    public = factory()
    public.password_changed = True
    generic = SimpleNamespace(get_user_by_telegram_id=AsyncMock(return_value=public))
    await cmd_start(message, generic, SimpleNamespace(),
                    credential_cards=BotCredentialCards(bot=provider, client=client))
    text = message.answer.await_args.args[0]
    print(json.dumps({"ordinary_profile_visible": "ordinary" in text,
                      "safe_unavailable_visible": "Сервис временно недоступен" in text,
                      "protected_read_attempts": client.read.await_count,
                      "credential_provider_edits": provider.edit_message_text.await_count,
                      "generic_profile_reads": generic.get_user_by_telegram_id.await_count}))
    await client.close()


asyncio.run(observe())
