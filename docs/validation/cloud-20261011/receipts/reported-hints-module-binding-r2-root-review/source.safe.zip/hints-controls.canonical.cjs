const fs = require('node:fs'), path = require('node:path'), vm = require('node:vm'), crypto = require('node:crypto');
const ts = require('/workspace/rutcampustrack/frontends/node_modules/typescript/lib/typescript.js');
const W = '/workspace/rct-worktrees/client-ci-first3/tests/e2e';
const { serializeError } = require(W + '/node_modules/playwright/lib/util.js');
const marker = 'RCT_PUBLIC_REPORTED_HINT_' + crypto.randomUUID();
let parserDiagnosticCount = 0;
function pair(dir) {
  const cache = {};
  function load(name) {
    if (cache[name]) return cache[name].exports;
    const file = path.join(dir, name + '.ts'), source = fs.readFileSync(file, 'utf8');
    parserDiagnosticCount += ts.createSourceFile(file, source, ts.ScriptTarget.ES2022, true).parseDiagnostics.length;
    const output = ts.transpileModule(source, { compilerOptions: { target: ts.ScriptTarget.ES2022, module: ts.ModuleKind.CommonJS } }).outputText;
    const box = { exports: {} }; cache[name] = box;
    const local = id => id === './safe-reporter' ? load('safe-reporter') : id === '@playwright/test' ? require(W + '/node_modules/@playwright/test') : require(id);
    vm.runInThisContext('(function(require,module,exports,__dirname){' + output + '\n})', { filename: file })(local, box, box.exports, W + '/fixtures');
    return box.exports;
  }
  return { privacy: load('artifact-privacy'), reporter: load('safe-reporter') };
}
const old = pair(__dirname + '/before'), current = pair(W + '/fixtures');
const rows = [], check = (code, passed) => rows.push({ code, passed: passed === true });
const hints = (p, e) => typeof p.reporter.reportedFailureHints === 'function' ? p.reporter.reportedFailureHints(e) : [];
const zeroUnknown = values => values.every(value => value.stage === 'UNKNOWN' && value.httpStatus === 0);
const has = (values, cause) => values.some(value => value.cause === cause);
const privateError = new TypeError(marker);
privateError.stack = 'TypeError: ' + marker + '\n    at Actor.call (' + W + '/fixtures/mobile-dataset.ts:38:13)';
const serialized = serializeError(privateError);
const selected = process.argv[2] === 'old' ? old : current;
check('PINNED_SERIALIZER_STANDARD_PREFIX', serialized.message === 'TypeError: ' + marker);
const originalCause = selected.reporter.classifySafeFailure(serialized);
check('ORIGINAL_UNKNOWN_HTTP_ZERO_RETAINED', originalCause.cause === 'UNKNOWN' && originalCause.stage === 'UNKNOWN' && originalCause.httpStatus === 0);
check('REPORTED_CLASS_DELIVERED', has(hints(selected, serialized), 'REPORTED_CLASS_TYPE_ERROR'));
check('REPORTED_FRAME_DELIVERED', has(hints(selected, serialized), 'REPORTED_FRAME_DATASET_CALL'));
if (process.argv[2] !== 'old') {
  check('FABRICATED_MATCH_PROVES_NO_CAUSE_STAGE_OR_HTTP', zeroUnknown(hints(current, serialized)) && originalCause.cause === 'UNKNOWN');
  const expectedClasses = ['REPORTED_CLASS_ERROR', 'REPORTED_CLASS_TYPE_ERROR', 'REPORTED_CLASS_RANGE_ERROR', 'REPORTED_CLASS_REFERENCE_ERROR', 'REPORTED_CLASS_SYNTAX_ERROR', 'REPORTED_CLASS_TIMEOUT_ERROR'];
  const classNames = ['Error', 'TypeError', 'RangeError', 'ReferenceError', 'SyntaxError', 'TimeoutError'];
  check('SIX_STANDARD_REPORTED_CLASSES_CLOSED', classNames.every((name, index) => {
    const values = hints(current, { message: name + ': ' + marker });
    return values.length === 1 && values[0].cause === expectedClasses[index] && zeroUnknown(values);
  }));
  let reads = 0;
  const hostile = { toString() { reads++; return marker; } };
  for (const key of ['message', 'stack', 'name', 'constructor']) Object.defineProperty(hostile, key, { get() { reads++; return marker; } });
  const framedHostile = { message: 'TypeError: ' + marker, toString() { reads++; return marker; } };
  for (const key of ['stack', 'name', 'constructor']) Object.defineProperty(framedHostile, key, { get() { reads++; return marker; } });
  check('NO_GETTER_NAME_PROTOTYPE_OR_CONVERSION_READ', hints(current, hostile).length === 0 && hints(current, framedHostile).length === 1 && reads === 0);
  for (const [code, message] of [
    ['UNKNOWN_CLASS', marker + ': payload'], ['DOUBLE_CLASS', 'Error: Error: ' + marker],
    ['MULTILINE_MESSAGE', 'Error: ' + marker + '\nprivate'], ['CONTROL_MESSAGE', 'Error: ' + marker + '\u0000'],
    ['OVERSIZE_MESSAGE', 'Error: ' + marker.repeat(30)],
  ]) check(code + '_NO_PROMOTION', zeroUnknown(hints(current, { message })) && (code === 'DOUBLE_CLASS' || hints(current, { message }).length === 0) && (code !== 'CONTROL_MESSAGE' || ['\u0085','\u2028','\u2029'].every(control => hints(current, { message: 'Error: ' + marker + control }).length === 0)));
  const message = 'Error: ' + marker;
  const exact = '    at Actor.call (' + W + '/fixtures/mobile-dataset.ts:38:13)';
  const badFrames = [
    '    at Actor.call (/private/' + marker + ':38:13)',
    '    at Unknown.call (' + W + '/fixtures/mobile-dataset.ts:38:13)',
    '    at Actor.call (' + W + '/fixtures/mobile-dataset.ts:0:13)',
    '    at Actor.call ' + W + '/fixtures/mobile-dataset.ts:38:13',
    'garbage\n' + exact, exact + '\u0000', exact + '\u0085', exact + 'garbage', exact.repeat(100),
    Array(17).fill(exact).join('\n'),
  ];
  check('MALFORMED_PRIVATE_CONTROL_OVERSIZE_STACK_NO_FRAME', badFrames.every(frame => {
    const values = hints(current, { message, stack: message + '\n' + frame });
    return values.length === 1 && values[0].cause === 'REPORTED_CLASS_ERROR' && zeroUnknown(values);
  }));
  check('STACK_MESSAGE_MISMATCH_NO_FRAME', hints(current, { message, stack: 'Error: other\n' + exact }).length === 1);
  check('MULTIPLE_PUBLIC_FRAMES_RETAIN_ONLY_FIRST', hints(current, { message, stack: message + '\n' + exact + '\n    at MobileDataset.initialize (' + W + '/fixtures/mobile-dataset.ts:162:24)' }).length === 2);
  const annotation = cause => ({ type: current.reporter.safeFailureAnnotation, description: cause + ':0' });
  const decoder = current.reporter.safeFailureDiagnostics;
  check('ANNOTATION_HINTS_FORCE_UNKNOWN_ZERO', zeroUnknown(decoder(expectedClasses.map(annotation))));
  check('FORGED_HINT_HTTP_STATUS_REJECTED', decoder([{ type: current.reporter.safeFailureAnnotation, description: 'REPORTED_FRAME_DATASET_CALL:503' }])[0].cause === 'UNKNOWN');
  const many = Array(40).fill(annotation('REPORTED_CLASS_TYPE_ERROR')).concat(annotation('REPORTED_FRAME_DATASET_CALL'));
  check('ANNOTATION_32_SCAN_AND_DEDUP_BOUND_UNCHANGED', decoder(many).length === 1);
  const info = { annotations: [], errors: [serialized], file: 'reported-hints.control.spec.ts', line: 10 };
  current.privacy.sanitizeTestErrors(info);
  const first = JSON.stringify(info);
  current.privacy.sanitizeTestErrors(info);
  check('REPEATED_SANITIZER_NO_NEW_HINT_OR_PRIVATE_OUTPUT', first === JSON.stringify(info) && !first.includes(marker));
  info.errors.push(serializeError(new RangeError(marker)));
  current.privacy.sanitizeTestErrors(info);
  const diagnostics = decoder(info.annotations, true);
  check('LATE_ERRORS_KEEP_ONE_CLASS_ONE_FRAME_AND_UNKNOWN', diagnostics.length === 3 && diagnostics.filter(value => value.cause.startsWith('REPORTED_CLASS_')).length === 1 && diagnostics.filter(value => value.cause.startsWith('REPORTED_FRAME_')).length === 1 && zeroUnknown(diagnostics));
  const reporter = new current.reporter.default();
  reporter.onTestEnd({ location: { file: info.file, line: info.line }, parent: { project: () => ({ name: 'chromium' }) }, expectedStatus: 'failed' }, { status: 'failed', duration: 0, errors: info.errors, annotations: info.annotations, attachments: [] });
  const row = reporter.results[0];
  check('REPORTER_FAILURE_COUNT_FIELDS_RETAINED_MARKER_ABSENT', row.status === 'failed' && row.errorCount === 2 && row.diagnostics.length === 3 && zeroUnknown(row.diagnostics) && !JSON.stringify(row).includes(marker));
  const capped = { annotations: [401,403,404,409,410,422,423,429].map(status => ({ type: current.reporter.safeFailureAnnotation, description: 'ACTOR_LOGIN_HTTP:' + status })), errors: [serializeError(new Error(marker))], file: info.file, line: info.line };
  current.privacy.sanitizeTestErrors(capped);
  check('EXISTING_MAX_EIGHT_NO_HINT_EVICTION', decoder(capped.annotations).length === 8 && !decoder(capped.annotations).some(value => value.cause.startsWith('REPORTED_')));
  check('KNOWN_HTTP_CLASSIFIER_UNCHANGED', ['login','session','role STUDENT','role HEADMAN','role TEACHER','role ADMIN'].every(operation => [400,401,403,404,409,410,422,423,429,500,502,503,504].every(status => {
    const error = serializeError(new Error('Synthetic actor ' + operation + ': HTTP ' + status));
    return JSON.stringify(old.reporter.classifySafeFailure(error)) === JSON.stringify(current.reporter.classifySafeFailure(error));
  })));
}
const failed = rows.filter(value => !value.passed);
const expectedCausalRed = process.argv[2] === 'old' && failed.length === 2 && failed.every(value => ['REPORTED_CLASS_DELIVERED','REPORTED_FRAME_DELIVERED'].includes(value.code)) && parserDiagnosticCount === 0;
const receipt = { pass: rows.every(value => value.passed) && parserDiagnosticCount === 0, expectedCausalRed, count: rows.length, failed: failed.length, parserDiagnosticCount, controls: rows, reportedHintsUntrusted: true, nativeClientAcceptance: false, actualCIcause: 'UNKNOWN' };
fs.writeFileSync(process.env.RCT_SAFE_DIAGNOSTIC_RECEIPT, JSON.stringify(receipt, null, 2) + '\n', { mode: 0o600 });
process.exitCode = receipt.pass ? 0 : 1;
