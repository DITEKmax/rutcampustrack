"""Final selected-source/private-copy checks; no keys, apps or native children."""
import ast
import base64
import copy
import datetime
import hashlib
import json
import os
from pathlib import Path
import re
import secrets
import stat
import yaml

OWN = Path(__file__).parent
OLD = OWN.parent / 'current_host_config'
os.umask(0o077)
NAMES = {'ACADEMIC_TO_SCHEDULE_SERVICE_TOKEN', 'SCHEDULE_TO_ACADEMIC_SERVICE_TOKEN',
         'BOT_TO_ACADEMIC_SERVICE_TOKEN', 'BOT_TO_NOTIFICATION_SERVICE_TOKEN'}
def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def selected(path, name, namespace):
    source = path.read_text(); tree = ast.parse(source)
    fn = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == name)
    exec(compile(ast.Module(body=[copy.deepcopy(fn)], type_ignores=[]), str(path), 'exec'), namespace)
    return namespace[name]

generate = selected(OWN / 'prepare-directional-v3.py', 'generate_directional_token', {'base64': base64, 'secrets': secrets})
canonical = selected(Path('/workspace/rutcampustrack/services/notification-bot/bot/grpc_client/bot_service_credentials.py'), 'canonical_token', {'base64': base64, 're': re})
for unused in range(4):
    assert canonical(generate())
old_specs = json.loads((OLD / 'host-service-specs.json').read_text())
specs = json.loads((OWN / 'host-service-specs.json').read_text())
assert len(specs) == 7
pairs = {}; private_inventory = []
for path in sorted((OWN / 'private').iterdir()):
    st = path.lstat()
    assert stat.S_ISREG(st.st_mode) and stat.S_IMODE(st.st_mode) == 0o600 and st.st_uid == os.getuid()
    assert path.suffix in {'.json', '.env'}
    original = OLD / 'private' / path.name
    if path.suffix == '.json':
        old = json.loads(original.read_text()); new = json.loads(path.read_text())
        assert old.keys() == new.keys()
        changed = sorted(k for k in old if new[k] != old[k])
        assert changed == sorted(set(old) & NAMES)
        for name in changed:
            assert canonical(new[name]) and not canonical(old[name])
            pairs.setdefault(name, []).append(new[name])
    else:
        changed = []; assert path.read_bytes() == original.read_bytes()
    private_inventory.append({'path': str(path), 'names_changed_only': changed, 'bytes': st.st_size,
                              'mode': '600', 'uid': st.st_uid, 'gid': st.st_gid})
assert len(private_inventory) == 9 and set(pairs) == NAMES
assert all(len(set(v)) == 1 for v in pairs.values())
assert len({v[0] for v in pairs.values()}) == 4
for old, new in zip(old_specs, specs):
    restored = dict(new); restored['private_environment_file'] = old['private_environment_file']; assert restored == old
    assert Path(new['private_environment_file']).parent == OWN / 'private'
    assert set(json.loads(Path(new['private_environment_file']).read_text())) == set(new['required_private_names'])
for name in ['tool-provenance.json', 'data-renderer-edge.compose.yml', 'launch-grant.template.json']:
    assert (OWN / name).read_bytes() == (OLD / name).read_bytes()
assert len(yaml.safe_load((OWN / 'data-renderer-edge.compose.yml').read_text())['services']) == 9
source = (OWN / 'prepare-directional-v3.py').read_text()
assert "if path.suffix not in {'.json', '.env'}:" in source
assert "secrets.token_bytes(32)" in source
safe_owned = selected(OWN / 'run-service-v3.py', 'safe_owned', {'Path': Path, 'os': os, 'stat': stat})
assert safe_owned(str(OWN / 'private/auth.json'), OWN / 'private') == OWN / 'private/auth.json'
for raw in [str(OWN / 'private/../runtime/x'), str(OWN) + '/private//auth.json', str(OLD / 'private/auth.json')]:
    try:
        safe_owned(raw, OWN / 'private')
    except ValueError:
        pass
    else:
        raise AssertionError('Private scope escaped')
old_manifest = OLD / 'launch-manifest.json'
assert digest(old_manifest) == 'abc478d49ee558d8c42fed6368bb003e35b42b3031a820617dec7fed0709ba12'
for row in json.loads(old_manifest.read_text())['files']:
    assert digest(Path(row['path'])) == row['sha256']
assert digest(OWN.parent / 'guard_proc_race_correction/bounded-child.py') == 'b78c61293568d9941692e0b92ee34fd0b84db6d532b4a2c9a5ad42ccbf2204a0'
report = {'utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'finding': 'HOSTCFG-G01',
    'status': 'PASS_SOURCE_SYNTHETIC_INPUTS_READY_FOR_FRESH_RECHECK', 'selected_corrected_generator_AST_actual_checks': 4,
    'four_canonical32_tokens_sender_receiver_reserved_bot_match_and_distinct': True,
    'original39_manifest_and_safe_inputs_byte_equal': True, 'original_guard_b78_unchanged': True,
    'private_ENV_copy_count': 9, 'private_inventory_name_mode_only': private_inventory,
    'all_other_private_values_equal_no_digest_reported': True, 'original_privatekeys_not_read_in_final_check': True,
    'attempt01_VAPID_read_copy_qualification': 'See scope-correction.safe.json; exact NEW redundant copy removed, original preserved',
    'seven_public_specs_only_private_file_pointers_changed': True,
    'original_compose_tool_provenance_grant_template_byte_equal': True,
    'exact_privatepath_pure_positive': 1, 'exact_privatepath_negatives_rejected': 3,
    'JVM_Java_receiver_execution': 'NOT_RUN; actual Java rules source counterpart qualified in original correction receipt',
    'product_policy_or_validator_changed': False, 'credential_values_or_hashes_disclosed': False,
    'apps_Docker_JVM_network_children': 'NOT_RUN'}
(OWN / 'validation-ready-v3.safe.json').write_text(json.dumps(report, indent=2) + '\n')
print('Ready v3 PASS: exact NEW nine ENV copies, only four token values changed; canonical pairs/distinct; original39+b78 preserved; keys not read in final check')
