import { defineConfig } from '/workspace/rct-worktrees/client-ci-first3/tests/e2e/node_modules/@playwright/test';
process.env.PLAYWRIGHT_NO_COPY_PROMPT = '1';
export default defineConfig({
  testDir: '/workspace/scratch/rct-validation/first3_dataset_call_source/checking-plan/controls',
  testMatch: 'dataset-http.control.spec.ts',
  outputDir: process.env.RCT_SAFE_FAILURE_CONTROL_OUTPUT,
  reporter: [['/workspace/rct-worktrees/first3-dataset-correction-20261013/tests/e2e/fixtures/safe-reporter.ts']],
  workers: 1, retries: 0, timeout: 10000, forbidOnly: true,
  use: { trace: 'off', video: 'off', screenshot: 'off' },
});
