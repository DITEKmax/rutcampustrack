"""Bounded existing-data Mongo restart or finite authenticated readiness. No bootstrap."""
import argparse
import errno
import hashlib
import json
import os
from pathlib import Path
import socket
import stat
import types

CORRECTION = Path('/workspace/scratch/rct-validation/current_host_config_v5_mongo_identity_correction')
PLAN = Path('/workspace/scratch/rct-validation/current_host_restart_plan')
ANCESTOR_CORRECTION = Path(__file__).parent
OWN = Path('/workspace/scratch/rct-validation/current_host_config_v5')
NATIVE = Path('/tmp/rct-native-mongo-20261012')
GUARD = Path('/workspace/scratch/rct-validation/guard_proc_race_correction/bounded-child.py')
GUARD_SHA = 'b78c61293568d9941692e0b92ee34fd0b84db6d532b4a2c9a5ad42ccbf2204a0'

def digest(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()

def exact_regular(p, mode=None):
    p = Path(p)
    if not p.is_absolute() or '..' in p.parts:
        raise RuntimeError('Absolute lexical path required')
    for parent in reversed(p.parents):
        if not stat.S_ISDIR(parent.lstat().st_mode):
            raise RuntimeError('Symlink ancestor denied')
    s = p.lstat()
    if not stat.S_ISREG(s.st_mode) or (mode is not None and stat.S_IMODE(s.st_mode) != mode):
        raise RuntimeError('Exact regular file mode required')
    return p

def owned_private(p):
    raw = str(p)
    p = exact_regular(p, 0o600)
    if str(p) != raw or OWN / 'private' not in p.parents or p.stat().st_uid != os.getuid():
        raise RuntimeError('Own exact private600 path required')
    return p

def exact_live_child(record, table):
    pid = record.get('child_pid')
    if type(pid) is not int or pid <= 0:
        return False
    rows = [row for row in record.get('members_including_Z', []) if row.get('pid') == pid]
    if len(rows) != 1:
        return False
    birth = rows[0].get('start_ticks')
    if type(birth) is not int or birth <= 0:
        return False
    current = table.get(pid)
    return (current is not None and current.get('pid') == pid
            and current.get('start_ticks') == birth
            and current.get('state') in {'R', 'S', 'D', 'T', 't', 'I', 'W'})

def main():
    if os.getuid()!=1000 or os.getgid()!=1000:
        raise RuntimeError('Exact approved execution actor1000 required')
    parser = argparse.ArgumentParser()
    parser.add_argument('--phase', choices=['server', 'readiness'], required=True)
    parser.add_argument('--grant', required=True)
    args = parser.parse_args()
    grant = json.loads(owned_private(args.grant).read_text())
    if (grant.get('launch_authorized') is not True or grant.get('native_mongo_authorized') is not True
            or grant.get('reuse_existing_mongo_db') != str(NATIVE / 'fresh-db')
            or grant.get('reviewed_guard_sha256') != GUARD_SHA):
        raise RuntimeError('New exact Root native runtime grant required')
    if digest(OWN / 'launch-manifest.json') != grant.get('config_manifest_sha256'):
        raise RuntimeError('Exact sealed config required')
    if digest(grant['config_review_manifest']) != grant['config_review_manifest_sha256']:
        raise RuntimeError('Independent config review required')
    if digest(GUARD) != GUARD_SHA or digest(grant['guard_review_manifest']) != grant['guard_review_manifest_sha256']:
        raise RuntimeError('Independent unchanged guard required')
    if grant.get('heavy_leases_released') != {'NP01_BROKER1': True, 'FORMAT_JAVA': True, 'FORMAT_NODE': True}:
        raise RuntimeError('Other heavy leases must be released')
    manifest = json.loads((OWN / 'launch-manifest.json').read_text())
    for row in manifest['files']:
        if digest(exact_regular(row['path'])) != row['sha256']:
            raise RuntimeError('Sealed source input changed')
    if digest(CORRECTION / 'manifest.json') != grant.get('mongo_identity_correction_manifest_sha256'):
        raise RuntimeError('New exact reviewed Mongo identity correction grant required')
    correction_manifest = json.loads((CORRECTION / 'manifest.json').read_text())
    for row in correction_manifest['files']:
        if digest(exact_regular(row['path'])) != row['sha256']:
            raise RuntimeError('Sealed identity correction input changed')
    # Verify own executable and boundary bytes BEFORE executing the boundary module.
    restart_manifest_path = ANCESTOR_CORRECTION / 'manifest.json'
    if digest(restart_manifest_path) != grant.get('restart_ancestor_correction_manifest_sha256'):
        raise RuntimeError('New exact restart seal required before helper import')
    restart_manifest = json.loads(restart_manifest_path.read_text())
    for source in [Path(__file__).absolute(), ANCESTOR_CORRECTION / 'restart-boundary.py']:
        row = next((row for row in restart_manifest['files'] if row['path'] == str(source)), None)
        if row is None or digest(source) != row['sha256']:
            raise RuntimeError('Exact executing source and boundary required')
    boundary = types.ModuleType('restart_boundary')
    boundary.__file__ = str(ANCESTOR_CORRECTION / 'restart-boundary.py')
    exec(compile((ANCESTOR_CORRECTION / 'restart-boundary.py').read_bytes(), str(ANCESTOR_CORRECTION / 'restart-boundary.py'), 'exec'), boundary.__dict__)
    workspace_runtime, remaining = boundary.verify_restart(grant, __file__)
    fence = json.loads((PLAN / 'stopped-native-data-fence.safe.json').read_text())
    boundary.verify_existing_data(fence, stopped=args.phase == 'server')
    spec = json.loads((OWN / 'mongo-spec.json').read_text())
    public = json.loads((OWN / 'feasibility/native-version-ELF.safe.json').read_text())['results']
    for result in public:
        binary = exact_regular(spec[result['name']], 0o755)
        if digest(binary) != result['binary_sha256']:
            raise RuntimeError('Native binary changed')
        for library in result['effective_host_dependencies']:
            if digest(library['effective_public_library']) != library['public_sha256']:
                raise RuntimeError('Qualified effective host DSO changed')
    if NATIVE.is_symlink() or not NATIVE.is_dir() or NATIVE.stat().st_uid != os.getuid():
        raise RuntimeError('Own native root required')
    for base in ['/workspace', '/tmp']:
        fs = os.statvfs(base)
        needed = 4294967296 + (1073741824 if args.phase == 'server' else 0)
        if fs.f_bavail * fs.f_frsize < needed:
            raise RuntimeError('Fresh floor and planned tmp growth reserve required')
    runtime = NATIVE / 'runtime'
    db = NATIVE / 'fresh-db'
    keyfile = runtime / 'replica-key'
    cohort = boundary.CohortDirectory(workspace_runtime, create=False)
    env = {'PATH': '/usr/bin:/bin', 'LANG': 'C.UTF-8', 'LC_ALL': 'C.UTF-8',
           'HOME': str(runtime), 'XDG_CONFIG_HOME': str(runtime), 'TMPDIR': str(runtime),
           'MONGOSH_FORCE_DISABLE_TELEMETRY': 'true'}
    guard = types.ModuleType('reviewed_native_guard')
    guard.__file__ = str(GUARD)
    exec(compile(GUARD.read_bytes(), str(GUARD), 'exec'), guard.__dict__)
    latest = {}
    phase = args.phase
    if phase == 'server':
        if (workspace_runtime / 'mongo-server-process.safe.json').exists():
            raise RuntimeError('One native server launch per new cohort only')
        # Metadata-proven existing data/key only. No mkdir, key generation, reset or role bootstrap.
        with socket.socket() as probe:
            probe.bind(('127.0.0.1', 28417))
        argv = [spec['mongod'], '--dbpath', str(db), '--bind_ip', '127.0.0.1', '--port', '28417',
                '--replSet', 'rs0', '--auth', '--keyFile', str(keyfile), '--wiredTigerCacheSizeGB', '0.25']
        deadline = remaining
    else:
        cohort.assert_current()
        record = json.loads((workspace_runtime / 'mongo-server-process.safe.json').read_text())
        table = guard.process_table()
        if not exact_live_child(record, table) or not db.is_dir() or db.is_symlink() or not runtime.is_dir() or runtime.is_symlink():
            raise RuntimeError('Exact live own server identity required for readiness')
        credentials = dict(line.split('=', 1) for line in owned_private(OWN / 'private/docker.env').read_text().splitlines()
                           if line and not line.startswith('#'))
        private = {name: credentials[name] for name in spec['required_private_names']}
        public_script = str(PLAN / 'mongo-restart-readiness.js')
        argv = [spec['mongosh'], '--norc', '--quiet', 'mongodb://127.0.0.1:28417/admin?directConnection=true', public_script]
        private.pop('MONGODB_REPLICA_SET_KEY')
        env.update(private)
        env['RCT_RESTART_READINESS_OUTPUT'] = str(workspace_runtime / 'mongo-protocol.safe.json')
        del private, credentials
        deadline = min(120, remaining)

    def status(value):
        latest.clear()
        latest.update(value)
        cohort.write_json('mongo-' + phase + '-process.safe.json', value)

    def observe():
        cohort.assert_current()
        for base in ['/workspace', '/tmp']:
            fs = os.statvfs(base)
            if fs.f_bavail * fs.f_frsize < 4294967296:
                return 'DISK_FLOOR'
        used = int(Path('/sys/fs/cgroup/memory.current').read_text())
        limit = int(Path('/sys/fs/cgroup/memory.max').read_text())
        if used >= 16106127360 or limit - used < 1073741824:
            return 'SHARED_MEMORY_STOP'
        charged = 0
        for parent, directories, files in os.walk(db, followlinks=False):
            for name in directories + files:
                node = Path(parent) / name
                try:
                    metadata = node.lstat()
                except OSError as caught:
                    if caught.errno in (errno.ENOENT, errno.ESRCH):
                        continue
                    raise
                if stat.S_ISLNK(metadata.st_mode):
                    return 'OWN_DATA_SYMLINK_DENIED'
                charged += metadata.st_blocks * 512
        if charged > spec['tmp_growth_reserve_bytes']:
            return 'OWN_TMP_DATA_GROWTH_STOP'
        table = guard.process_table()
        for row in latest.get('members_including_Z', []):
            if table.get(row['pid'], {}).get('start_ticks') != row['start_ticks']:
                continue
            try:
                lines = Path('/proc/' + str(row['pid']) + '/status').read_text().splitlines()
            except OSError as caught:
                if caught.errno in (errno.ENOENT, errno.ESRCH):
                    continue
                raise
            rss = next((int(s.split()[1]) * 1024 for s in lines if s.startswith('VmRSS:')), 0)
            if rss > spec['rss_stop_bytes']:
                return 'OWN_RSS_STOP'
        return None

    cohort.assert_current()
    result = guard.run_owned(argv, str(runtime), env, deadline_seconds=min(deadline, boundary.validate_restart_fields(grant, boundary.datetime.datetime.now(boundary.datetime.timezone.utc))), observe=observe, status=status)
    result['meaning'] = 'Native lifecycle only. Existing-data recovery and authenticated protocol readiness are separate; no bootstrap is repeated.'
    cohort.write_json('mongo-' + phase + '-terminal.safe.json', result)
    print(json.dumps({'phase': phase, 'native_exit': result['native_exit'], 'settled': result['settled'],
                      'terminal_reason': result['terminal_reason'], 'runtime_acceptance': 'SEPARATE'}))
    cohort.close()
    return 0 if result['settled'] and result['supervision_error_type'] is None and (
        result['phase_success'] or (phase == 'server' and result['terminal_reason'] in ('STOP_REQUEST', 'BOUNDED_DEADLINE'))) else 1

if __name__ == '__main__':
    raise SystemExit(main())
