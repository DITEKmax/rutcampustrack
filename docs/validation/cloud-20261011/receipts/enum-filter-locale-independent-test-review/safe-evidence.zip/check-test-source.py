"""Bounded source/synthetic oracle review; no Java compiler or native test."""
from pathlib import Path
import hashlib,json,os,stat,subprocess,zipfile
OWN=Path(__file__).resolve().parent
ROOT=Path('/workspace/rutcampustrack');WT=Path('/workspace/rct-worktrees/enum-filter-locale')
PREP=Path('/workspace/scratch/rct-validation/enum_filtered_locale_developer');STAGE=PREP/'writer_stage'
TEST='services/academic-service/academic-app/src/test/java/ru/rutcampustrack/academic/integration/AcademicGrpcIT.java'
PROD='services/academic-service/academic-app/src/main/java/ru/rutcampustrack/academic/user/UserSpecifications.java'
HEAD='4c3745f2febdd4b9bcdd39a4e5f1fc9b3199fab1'
checks=[]
def check(n,x):
 assert x,n
 checks.append({'id':n,'passed':True})
def sha(p):
 h=hashlib.sha256()
 with p.open('rb')as f:
  while b:=f.read(32768):h.update(b)
 return h.hexdigest()
def save(n,x):
 with(OWN/n).open('x')as f:json.dump(x,f,indent=2);f.write('\n')
 (OWN/n).chmod(0o600)
def seal(p,m,z,msha,zsha):
 check('manifest_'+str(p),sha(p/m)==msha);d=json.loads((p/m).read_text());rows=d.get('entries',d.get('files'))
 check('ZIP_'+str(p),sha(p/z)==zsha)
 for r in rows:
  name=r['path'];s=(p/name).lstat()
  check('sealed_member_'+str(p)+'/'+name,stat.S_ISREG(s.st_mode)and s.st_size==r['bytes']and sha(p/name)==r['sha256'])
 with zipfile.ZipFile(p/z)as a:
  check('CRC_'+str(p),a.testzip()is None)
  check('ZIP_exact_names_'+str(p),set(a.namelist())=={r['path']for r in rows}|{m}and len(a.namelist())==len(rows)+1)
  for r in rows:check('ZIP_member_'+r['path'],hashlib.sha256(a.read(r['path'])).hexdigest()==r['sha256'])
 return d
seal(PREP,'manifest.safe.json','source-preparation.safe.zip','9fe7e36aada78c8a27460b691d11d16c76fef62aa51d6876adc416d8485a2a1d','b32f72aea31fd18877fe1fa37ea3321ca53347bdf6f34ed39ebe912a0c2a0313')
seal(STAGE,'manifest.safe.json','test-source-stage.safe.zip','c46a329b51c362bc53f39fc1d185779a46f4f59d5a05df7a921e39c2877565d9','91874d061bfaaca8763b389764e44008d15afb0d9b0a39e217253caec673e93f')
check('original_gap_receipt_unchanged',sha(Path('/workspace/scratch/rct-validation/enum_row_equality_review/manifest.json'))=='a22a0a221bf71d6f7f79cdf56e681aadb64172fd92a4613d4cff01084e5960e7')
env={'PATH':'/usr/local/bin:/usr/bin:/bin','LANG':'C.UTF-8','LC_ALL':'C.UTF-8','GIT_OPTIONAL_LOCKS':'0'}
def git(*args):return subprocess.check_output(['git','-C',str(WT),*args],env=env,stderr=subprocess.DEVNULL,timeout=15)
check('actual_frozen_HEAD',git('rev-parse','HEAD').strip().decode()==HEAD)
check('actual_detached',subprocess.run(['git','-C',str(WT),'symbolic-ref','-q','HEAD'],env=env,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,timeout=15).returncode==1)
check('only_test_tracked_diff',git('diff','--name-only','HEAD','--').decode().splitlines()==[TEST])
check('no_untracked_nonignored_inputs',not git('ls-files','--others','--exclude-standard','-z'))
old=git('show',HEAD+':'+TEST).decode();oldprod=git('show',HEAD+':'+PROD).decode();new=(WT/TEST).read_text()
check('original_test_byte_identity',hashlib.sha256(old.encode()).hexdigest()=='88bb5c967d08f851ea9e827112ca7404ff444ebaa2ef760bd6c4ff3e31bc5df5')
check('exact_test_candidate',sha(WT/TEST)=='5a4a7ad3daceb99d16005bc555bbb460bb6088fbd92cb19e9f49e08970d56e0a'and new==(PREP/'candidate/AcademicGrpcIT.java').read_text())
check('original_production_untouched',sha(WT/PROD)==hashlib.sha256(oldprod.encode()).hexdigest()=='4f62d5ac9724c9524697145734577954fbdf54c68162bd1af5e0166f376e98f9')
check('Root_two_original_files_untouched',sha(ROOT/TEST)==hashlib.sha256(old.encode()).hexdigest()and sha(ROOT/PROD)==sha(WT/PROD))
for name in [TEST,PROD]:
 s=(WT/name).lstat();check('own_regular_unaliased_'+name,stat.S_ISREG(s.st_mode)and stat.S_IMODE(s.st_mode)==0o600 and s.st_nlink==1 and s.st_uid==os.getuid())
def method(src,marker):
 start=src.index(marker);b=src.index('{',start);i=b+1;depth=1
 while depth:
  if src[i]=='{':depth+=1
  if src[i]=='}':depth-=1
  i+=1
 return start,i,src[start:i]
marker='void enumDatabaseAndHttpBoundaryRemainCanonicalUnderTurkishLocale()'
ob,oe,om=method(old,marker);nb,ne,nm=method(new,marker)
hbegin=new.index('    private void assertFilteredUsersEqualUnderLocales(')
hend=new.index('\n    // =====================================================================',hbegin)
restored=new[:hbegin]+new[hend:];restored=restored.replace(nm,om,1)
for line in ['import com.fasterxml.jackson.databind.JsonNode;\n','import java.util.ArrayList;\n','import org.assertj.core.api.SoftAssertions;\n']:restored=restored.replace(line,'',1)
# Helper removal leaves one additional separator newline; no Java token outside scope changed.
restored=restored.replace(om+'\n\n\n',om+'\n\n',1)
check('outside_method_import_helpers_byte_exact',restored==old)
check('same_original_method_annotations','@Test\n    @ResourceLock("java.util.Locale.default")\n    '+marker in new)
check('old_DB_assertions_preserved',all(x in nm for x in ['assertThat(admin.getRole()).isEqualTo(UserRole.ADMIN);','assertThat(admin.getStatus()).isEqualTo(AccountStatus.ACTIVE);']))
check('one_same_selected_session_and_JWT',nm.count('AcademicTestAdminRequest.selectedSession')==1 and nm.count('internalJwtTestFactory.validToken')==1 and nm.count('headers.set("X-Internal-Token", token)')==1 and nm.count('assertFilteredUsersEqualUnderLocales(')==3)
check('unknown400_then_assertAll',nm.index('assertThat(unknown.getStatusCode()).isEqualTo(HttpStatus.BAD_REQUEST);')<nm.index('localeEquality.assertAll();'))
check('same_finally_cleanup',nm[nm.index('} finally {'):]==om[om.index('} finally {'):])
_,_,helper=method(new,'private void assertFilteredUsersEqualUnderLocales(')
_,_,projection=method(new,'private FilteredUsers filteredUsers(')
check('hard_nonempty_positive_before_comparison',helper.index('isNotEmpty()')<helper.index('Locale.setDefault(Locale.ROOT)')and 'contains(ADMIN_ID)'in helper and 'doesNotContain(archivedUserId)'in helper and 'isLessThanOrEqualTo(100)'in helper)
check('independent_SQL_expected_constants','SELECT u.id, u.status::text FROM users u WHERE 'in helper and ' ORDER BY u.id'in helper and 'toUpperCase(Locale.ROOT)'in helper and 'UserSpecifications' not in helper)
check('hard_canonical_exact_rows_and_both_counts',all(x in helper for x in ['containsExactlyElementsOf(expected)','canonical.totalElements()','canonical.returnedCount()'])and helper.count('.isEqualTo(expected.size())')==2)
check('paired_ROOT_then_TR_same_header_URI',helper.index('Locale.setDefault(Locale.ROOT)')<helper.index('FilteredUsers canonical = filteredUsers(headers, uri)')<helper.index('Locale.setDefault(Locale.forLanguageTag("tr-TR"))')<helper.index('FilteredUsers turkish = filteredUsers(headers, uri)'))
check('aggregate_exact_closed_records',helper.index('.assertThat(turkish)')<helper.index('.isEqualTo(canonical)')and 'ENUM_ROW_EQUALITY tr-TR %s'in helper and 'private record FilteredUsers(List<FilteredUserRow> rows, long totalElements, int returnedCount) {}'in new and 'private record FilteredUserRow(long id, String status) {}'in new)
check('JSON_shape_and_projection_only',all(x in projection for x in ['rows.isMissingNode() || rows.isArray()','id.isIntegralNumber() && id.canConvertToLong()','status.isTextual()','total.isIntegralNumber() && total.canConvertToLong()','List.copyOf(projected)'])and all(x not in projection for x in ['System.out','fullName','login','password','telegram']))
check('all_HTTP200_are_hard', 'isEqualTo(HttpStatus.OK)'in projection and 'assertThat(response.getStatusCode())'in projection)
check('source_original_fold_hypothesis_still_present','role.toLowerCase()'in oldprod and 'status.toLowerCase()'in oldprod)
check('third_query_does_not_mix_account_status','/academic/users?role=admin&roleStatus=ACTIVE&page=0&size=100&sort=id,asc'in nm)
queries=['/academic/users?status=active&page=0&size=100&sort=id,asc','/academic/users?status=active&role=ADMIN&page=0&size=100&sort=id,asc','/academic/users?role=admin&roleStatus=ACTIVE&page=0&size=100&sort=id,asc']
check('only_three_exact_accepted_filter_queries',all(nm.count(q)==1 for q in queries))
deps=['services/academic-service/academic-app/src/main/java/ru/rutcampustrack/academic/user/UserService.java','services/academic-service/academic-api-contract/src/main/java/ru/rutcampustrack/academic/contract/api/UserApi.java','services/academic-service/academic-app/src/main/java/ru/rutcampustrack/academic/entity/User.java','services/academic-service/academic-app/src/main/java/ru/rutcampustrack/academic/config/WebConfig.java','services/academic-service/academic-api-contract/src/main/java/ru/rutcampustrack/academic/contract/enums/AccountStatus.java','services/academic-service/academic-app/src/test/java/ru/rutcampustrack/academic/integration/AcademicTestAdminRequest.java']
for name in deps:check('current_source_dependency_frozen_'+name,(WT/name).read_bytes()==git('show',HEAD+':'+name)==(ROOT/name).read_bytes())

# Synthetic record-equality counterexamples. Source interpretation only, no Java invocation.
expected=((1,'ACTIVE'),(2,'ACTIVE'));canonical=(expected,2,2)
def oracle(e,c,t):return bool(e)and 1 in [r[0]for r in e]and len(e)<=100 and c[0]==e and c[1]==len(e)and c[2]==len(e)and t==c
controls=[]
for name,e,c,t,want in [('correct_pair',expected,canonical,canonical,True),('both_empty',(),((),0,0),((),0,0),False),('canonical_missing_admin',((2,'ACTIVE'),),(((2,'ACTIVE'),),1,1),(((2,'ACTIVE'),),1,1),False),('tr_empty',expected,canonical,((),0,0),False),('tr_wrong_ID',expected,canonical,(((1,'ACTIVE'),(3,'ACTIVE')),2,2),False),('tr_wrong_status',expected,canonical,(((1,'ACTIVE'),(2,'SUSPENDED')),2,2),False),('tr_wrong_total',expected,canonical,(expected,1,2),False),('tr_wrong_count',expected,canonical,(expected,2,1),False),('canonical_wrong_total',expected,(expected,0,2),canonical,False)]:
 result=oracle(e,c,t);check('synthetic_oracle_'+name,result==want);controls.append({'id':name,'accepted':result,'expected':want})
save('independent-source-checks.safe.json',{'verdict':'APPROVE_SOURCE_TEST_ONLY','checks':checks,'count':len(checks),'synthetic_record_controls':controls,'Java_parser_compiler_or_native':'NOT_RUN','runtime_grant':False,'source_writes':False})
save('source-identity.safe.json',{'HEAD':HEAD,'test':{'path':TEST,'sha256':sha(WT/TEST),'mode':'0600','nlink':1},'production':{'path':PROD,'sha256':sha(WT/PROD),'state':'ORIGINAL'},'Root_two_unchanged':True,'scope':'ONLY test source staged; no production fix applied','method_lines':[new[:nb].count('\n')+1,new[:ne].count('\n')+1]})
print(json.dumps({'verdict':'APPROVE_SOURCE_TEST_ONLY','checks':len(checks),'synthetic_controls':len(controls),'prod':'ORIGINAL4f62','native':'NOT_RUN'}))
