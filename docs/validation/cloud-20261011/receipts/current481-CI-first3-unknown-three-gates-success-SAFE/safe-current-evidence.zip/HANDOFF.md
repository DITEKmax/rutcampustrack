Current481: CI FAIL; Coverage/Security/OpenAPI SUCCESS.

Each Java workflow:1485 unit+1111 integration PASS/3 SKIP/0 failures/errors/not-executed; actual checkout0f7ba8b1fe11550c746ed4d540f51445b7f2180a, producer48124. Locale dd0c and CAP b40d methods PASS in both. BrokerBridgeIT actual same single method/sourceac58 PASS in both. FIRST3 lines14/61/142 FAIL63/54/53ms; each new closed diagnostic UNKNOWN/UNKNOWN/0, declaration-only errorLocations, all3 observers missing. No503 or stage cause proved. Historical96CAPcause UNKNOWN.

Metadata+19 exact SAFE archives only; no rawJUnit/log/private body. Canonical reporter41c0/privacy262c and strict optional diagnostics source prep0c413/c419 unchanged. No matrix/client family promotion.
