"""Selected source/preservation and exact parameter inverse; no Node or helper imports."""
from pathlib import Path
import ast,hashlib,json,os,re
OUT=Path(__file__).parent
A=Path('/workspace/scratch/rct-validation/client_session_offline_acceptance/d002-step-diagnostic')
OLD=Path('/workspace/scratch/rct-validation/client_session_offline_acceptance/run-session-offline.py')
ROOT=Path('/workspace/rutcampustrack')
ready=json.loads((A/'READY.safe.json').read_text())
caller=(A/'run-d002-steps.py').read_bytes();old=OLD.read_bytes()
assert hashlib.sha256(caller).hexdigest()=='5f95fae4d75eba9151f250fa3146a8be32642ee32a9129e3147dff1a03c4a039'
assert hashlib.sha256(old).hexdigest()=='16e6dcfc082d72b616e873f573b6f63c9b1ffb28ffa04b0dd05360345fa84ab2'
delta=json.loads((A/'caller-parameter-diff.safe.json').read_text())
inverse=caller.decode()
for row in delta['changes']:
    assert row['after'] in inverse
    inverse=inverse.replace(row['after'],row['before'])
assert inverse.encode()==old and len(delta['changes'])==10
ast.parse(caller);ast.parse((A/'run-node-checks01.py').read_bytes())
observer=Path('/workspace/rct-worktrees/client-session-offline/tests/e2e/d002-step-specs/closed-step-observer.ts')
s=observer.read_text();controls=(A/'controls.cjs').read_text()
codes=re.findall(r"control\('([A-Z0-9_]+)'",controls)
assert len(codes)==len(set(codes))==11
assert s.count("                : 'OTHER';")==1
assert "source.replace(before, '                : (rawCategory as Category);')" in controls
assert "failedCodes.length === 1 && failedCodes[0] === 'PRIVATE_CATEGORY_CLOSED_UNKNOWN'" in controls
assert "if ('onStepBegin' in prototype || 'onStepEnd' in prototype)" in s
assert re.findall(r"Object\.defineProperty\(prototype, '([^']+)'",s)==['onStepBegin','onStepEnd']
assert "errorHandler.value.call(receiver, { message: 'D002 step observer failed' });" in s
assert "events.length >= 256" in s and 'Buffer.byteLength(data) > 65536' in s and 'unknownHooks >= 32' in s and 'ignored > 4096' in s
assert "const descriptor = Object.getOwnPropertyDescriptor(value, key)" in s and "descriptor && 'value' in descriptor" in s
paths=['tests/e2e/specs/mobile-real-server.spec.ts','tests/e2e/fixtures/artifact-privacy.ts','tests/e2e/fixtures/safe-reporter.ts','tests/e2e/fixtures/mobile-dataset.ts','tests/e2e/fixtures/pwa-auth.ts','tests/e2e/fixtures/teaching-clock.ts']
root_pins=[]
for name in paths:
    b=(ROOT/name).read_bytes();actual=hashlib.sha256(b).hexdigest();assert actual==ready['root_source_hashes'][name]
    root_pins.append({'path':name,'sha256':actual,'bytes':len(b)})
old_own=[('tests/e2e/playwright.session-offline.config.ts','5ded76799d09801b507ab3e83029d0d78fccb3693247c92007cbe015b4aa4039'),('tests/e2e/session-offline-specs/mobile-session-offline.spec.ts','971715457edc6353715cbeb3bdaabf819b51f87698ee6bc9b806a3ecf88d0714')]
for name,expected in old_own:
    assert hashlib.sha256((Path('/workspace/rct-worktrees/client-session-offline')/name).read_bytes()).hexdigest()==expected
v={'verdict':'APPROVE_SOURCE','caller_parameter_inverse_whole_bytes_exact':True,'parameter_change_count':10,'caller_Python_AST':'PASS_SOURCE_ONLY','new_public_callbacks_only':['onStepBegin','onStepEnd'],'caps':{'events':256,'utf8_bytes':65536,'unknown_hooks':32,'ignored':4096},'canonical_error_handler':'UNMODIFIED_CLOSED_SIGNAL_RUNNERERRORS_CONSUMER_MUST_REQUIRE_ZERO','planned_control_count':len(codes),'planned_control_codes':codes,'sensitivity':'Exactly one RAM unknown-category fallback changed; unique intended failed code plus parser/count/all other predicates required. Native NOT_RUN.','selected_Root_pins':root_pins,'old_two_own_sources':'EXACT_UNCHANGED','private_fixture_bodies':'users.ts/telegram.ts not read by reviewer; immutable prior Root19 preservation receipts and future runtime pins remain authoritative.','actual367_timeout_stage':'UNKNOWN','native_Node_TS_parser_formatter_discovery_browser_API':'NOT_RUN'}
fd=os.open(OUT/'source-bindings.safe.json',os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
with os.fdopen(fd,'w') as f:json.dump(v,f,indent=2);f.write('\n')
print(json.dumps({'verdict':v['verdict'],'caller_inverse':True,'controls_planned':11,'old_two_own_sources_unchanged':True,'actual367stage':'UNKNOWN','native':False}))
