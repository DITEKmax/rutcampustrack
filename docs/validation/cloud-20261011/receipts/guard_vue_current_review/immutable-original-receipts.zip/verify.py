"""Bounded read-only input, selected pure AST and public metadata review.

Writes only this NEW review directory. No production function with OS effects
is executed; the author pure control programs run against exact local copies.
"""
import ast
import datetime
import hashlib
import json
import os
from pathlib import Path
import stat
import zipfile

BASE = Path('/workspace/scratch/rct-validation')
OWN = BASE / 'guard_vue_current_review'
ROOT = Path('/workspace/rutcampustrack/docs/validation/cloud-20261011/receipts')


def sha(data):
    return hashlib.sha256(data).hexdigest()


def save(name, value):
    (OWN / name).write_text(json.dumps(value, indent=2) + '\n')


def meta(path):
    path = Path(path)
    s = path.lstat()
    return {'path': str(path), 'device': s.st_dev, 'inode': s.st_ino,
            'nlink': s.st_nlink, 'bytes': s.st_size,
            'allocated_bytes': s.st_blocks * 512,
            'mode': oct(stat.S_IMODE(s.st_mode)), 'uid': s.st_uid,
            'gid': s.st_gid, 'mtime_ns': s.st_mtime_ns, 'ctime_ns': s.st_ctime_ns}


inputs = []
for name, expected_manifest, archive, expected_archive, root_name in [
    ('guard_proc_race_correction', '2486f5f66ff9770af071e2792d3a37164c811dd6362d3311b479993d45577a39',
     'safe-guard-proc-race.zip', '3de1a747b0059ebf1b0bde959dfa9e7189949113445a7f3007aa06bfff27677d', 'guard-proc-race-source'),
    ('current_vue_stage', '59dc74c777dbbb6e5d074474e548b682d05dd523bd9817088cf32ed232cd05bf',
     'safe-current-vue-stage.zip', '50adcfeba202c01b6198ad3b94ce25e24eeae2d44b109447c9d10d0f9aa04d0d', 'current-vue-public-stage'),
]:
    directory = BASE / name
    manifest_data = (directory / 'manifest.json').read_bytes()
    assert sha(manifest_data) == expected_manifest
    manifest = json.loads(manifest_data)
    original_data = {'manifest.json': manifest_data}
    for row in manifest['files']:
        data = Path(row['path']).read_bytes()
        assert len(data) == row['bytes'] and sha(data) == row['sha256'], row['path']
        original_data[row['archive_path']] = data
    archive_path = directory / archive
    assert sha(archive_path.read_bytes()) == expected_archive
    with zipfile.ZipFile(archive_path) as z:
        assert z.testzip() is None
        assert len(z.namelist()) == len(original_data)
        assert set(z.namelist()) == set(original_data)
        for n, data in original_data.items():
            assert z.read(n) == data, n
    root_directory = ROOT / root_name
    root_archive = root_directory / 'immutable-original-receipts.zip'
    with zipfile.ZipFile(root_archive) as z:
        assert z.testzip() is None
        assert len(z.namelist()) == len(original_data)
        assert set(z.namelist()) == set(original_data)
        for n, data in original_data.items():
            assert z.read(n) == data, n
    index_path = root_directory / 'original-byte-index.json'
    index = json.loads(index_path.read_text())
    assert len(index['files']) == len(original_data)
    for row in index['files']:
        data = original_data[row['path']]
        assert sha(data) == row['original_sha256'] and len(data) == row['original_bytes']
    inputs.append({'source': str(directory), 'manifest_sha256': expected_manifest,
                   'manifest_bytes': len(manifest_data), 'safe_receipts': len(manifest['files']),
                   'author_archive': str(archive_path), 'author_archive_sha256': expected_archive,
                   'author_archive_bytes': archive_path.stat().st_size,
                   'author_and_Root_members_SHA_bytes_CRC_exact': len(original_data),
                   'Root_archive_sha256': sha(root_archive.read_bytes()),
                   'Root_archive_bytes': root_archive.stat().st_size,
                   'Root_archive_outer_bytes_equal': root_archive.read_bytes() == archive_path.read_bytes(),
                   'Root_index_original_rows_exact': len(index['files']),
                   'Root_readable_views_not_execution_source': True})
save('input-seal-verification.json', inputs)

author = BASE / 'guard_proc_race_correction'
old = BASE / 'current_artifact_corrections_v2/bounded-child.py'
old_data = old.read_bytes()
new_data = (author / 'bounded-child.py').read_bytes()
assert sha(old_data) == 'f539f126bb5591e89f1a9e1f6ac72fbb91ba0da39fccda02cd773ca515acf706'
assert sha(new_data) == 'b78c61293568d9941692e0b92ee34fd0b84db6d532b4a2c9a5ad42ccbf2204a0'
assert new_data.count(b'import errno\n') == 1
reverse = new_data.replace(b'import errno\n', b'', 1).replace(
    b'except OSError as caught:\n            if caught.errno not in (errno.ENOENT, errno.ESRCH):\n                raise\n            continue',
    b'except FileNotFoundError:\n            continue', 1)
assert reverse == old_data
old_tree, new_tree = ast.parse(old_data), ast.parse(new_data)
old_functions = {n.name: ast.dump(n, include_attributes=False) for n in old_tree.body if isinstance(n, ast.FunctionDef)}
new_functions = {n.name: ast.dump(n, include_attributes=False) for n in new_tree.body if isinstance(n, ast.FunctionDef)}
assert set(old_functions) == set(new_functions)
changed = [n for n in old_functions if old_functions[n] != new_functions[n]]
assert changed == ['process_table']
assert compile(new_tree, 'b78c-reference-only', 'exec')
used = Path(json.loads((author / 'actual-source-bindings.json').read_text())['exact_used_original_source'])
assert used.read_bytes() == old_data
provenance = (author / 'actual-error-provenance.safe.json').read_bytes()
bindings = json.loads((author / 'actual-source-bindings.json').read_text())
assert Path(bindings['safe_actual_provenance_source']).read_bytes() == provenance
assert sha(provenance) == 'af60bc13628a96d1840ff50785ae7181cc122cb23426637efd2b60d588dcc0c0'
(OWN / 'bounded-child.py').write_bytes(new_data)
controls = []
for name in ['proc-race-controls.py', 'ownership-controls.py']:
    data = (author / name).read_bytes()
    target = OWN / name
    target.write_bytes(data)
    # Already independently read: only actual selected process_table is called
    # with fake Path, or selected dictionary-only ownership functions.
    exec(compile(data, str(target), 'exec'), {'__file__': str(target), '__name__': '__pure_review__'})
    controls.append({'copied_exact_source': name, 'sha256': sha(data), 'execution': 'pure selected AST', 'native_driver_exit': 'recorded by enclosing command'})
proc_result = json.loads((OWN / 'proc-race-controls-result.json').read_text())
ownership_result = json.loads((OWN / 'ownership-controls-result.json').read_text())
assert len(proc_result['cases']) == 13
assert all(r['status'] == 'PASS' for r in proc_result['cases'])
assert proc_result['new_guard_sha256'] == sha(new_data)
assert ownership_result['new_helper_SHA'] == sha(new_data)
save('guard-source-proof.json', {
    'verdict': 'APPROVE_SOURCE_ONLY', 'old_source_sha256': sha(old_data), 'new_source_sha256': sha(new_data),
    'byte_reverse_patch_exact': True, 'changed_functions': changed,
    'unchanged_AST': [n for n in old_functions if n not in changed],
    'actual_used_guard_copy_exact_f539': True,
    'safe_provenance_sha256': sha(provenance),
    'historical_actual_frame_errno_pid': 'UNKNOWN; type-only original capture',
    'independently_reexecuted_controls': controls, 'proc_cases': 13,
    'review_actual_proc_reads_child_launches_signals': 0,
    'new_hash_native_child_runtime': 'NOT_RUN',
    'previous_f539_native_controls': 'retained old-hash evidence only'})

vue = BASE / 'current_vue_stage'
bundles = json.loads((BASE / 'current_client_artifacts/production-vue-bundles.json').read_text())
assert bundles['revision'] == '908fc8c27be82e4a0d7db7bf4d7b2c4a62225916'
copy_rows = json.loads((vue / 'copy-map.json').read_text())
preflight = json.loads((vue / 'preflight.json').read_text())
expected = {(b['workspace'], r['path']): r for b in bundles['bundles'] for r in b['files']}
assert set((r['workspace'], r['relative_path']) for r in copy_rows) == set(expected)
assert len(copy_rows) == 22
new_ids, old_ids, rows = set(), set(), []
for row in copy_rows:
    original = Path(row['source']['path'])
    destination = Path(row['destination'])
    actual_old, actual_new = meta(original), meta(destination)
    assert actual_old == row['source'], str(original)
    assert actual_new == row['staged'], str(destination)
    assert actual_old['mode'] == '0o600' and actual_new['mode'] == '0o644'
    assert stat.S_ISREG(original.lstat().st_mode) and stat.S_ISREG(destination.lstat().st_mode)
    assert actual_new['nlink'] == 1
    original_data, destination_data = original.read_bytes(), destination.read_bytes()
    accepted = expected[(row['workspace'], row['relative_path'])]
    assert original_data == destination_data
    assert len(destination_data) == row['bytes'] == accepted['bytes']
    assert sha(destination_data) == row['sha256'] == accepted['sha256']
    new_ids.add((actual_new['device'], actual_new['inode']))
    old_ids.add((actual_old['device'], actual_old['inode']))
    rows.append({'workspace': row['workspace'], 'relative_path': row['relative_path'],
                 'bytes': row['bytes'], 'sha256': row['sha256'],
                 'new_actual_metadata': actual_new, 'original_actual_metadata_exact': True})
assert len(new_ids) == 22 and new_ids.isdisjoint(old_ids)
assert len(old_ids) == 22
for original, recorded in preflight['original_parent_metadata'].items():
    assert meta(original) == recorded and recorded['mode'] == '0o700'
for original, recorded in preflight['JAR8_metadata'].items():
    assert meta(original) == recorded
directories = json.loads((vue / 'directory-modes.json').read_text())
for recorded in directories:
    assert meta(recorded['path']) == recorded and recorded['mode'] == '0o755'
expected_files = {r['destination'] for r in copy_rows}
actual_files, actual_dirs = set(), set()
for directory, names, filenames in os.walk(vue / 'frontend', followlinks=False):
    assert stat.S_ISDIR(Path(directory).lstat().st_mode)
    assert stat.S_IMODE(Path(directory).lstat().st_mode) == 0o755
    actual_dirs.add(str(Path(directory)))
    for name in names:
        assert not (Path(directory) / name).is_symlink()
    actual_files.update(str(Path(directory) / n) for n in filenames)
assert actual_files == expected_files
assert actual_dirs == {r['path'] for r in directories}
old_template = (BASE / 'host_runtime_prepare/data-renderer-edge.compose.template.yml').read_bytes()
new_template = (vue / 'data-renderer-edge.public-vue.compose.template.yml').read_bytes()
assert sha(old_template) == 'c2ae96c53bbfd4fcbaf8886d12d0fc3c7d66a19de25174bd30ec601c1554cea6'
assert sha(new_template) == '0c8694ad58c277c89152f2c190b8ba3d4fefaabf53bc242c34cd628c4ff69655'
changes = []
forward, reverse = old_template, new_template
for workspace in ['pwa-vue', 'tma-vue']:
    old_source = str(BASE / 'host_runtime_prepare/runtime/frontend' / workspace / 'dist').encode()
    new_source = str(vue / 'frontend' / workspace / 'dist').encode()
    assert forward.count(old_source) == reverse.count(new_source) == 1
    forward = forward.replace(old_source, new_source)
    reverse = reverse.replace(new_source, old_source)
    changes.append({'old_source': old_source.decode(), 'new_source': new_source.decode()})
assert forward == new_template and reverse == old_template
allocated, seen = 0, set()
for directory, names, files in os.walk(vue, followlinks=False):
    for path in [Path(directory)] + [Path(directory) / n for n in files]:
        s = path.lstat()
        assert not stat.S_ISLNK(s.st_mode)
        identity = (s.st_dev, s.st_ino)
        if identity not in seen:
            seen.add(identity)
            allocated += s.st_blocks * 512
    assert all(not (Path(directory) / n).is_symlink() for n in names)
assert allocated <= 12582912
copy_pid = json.loads((vue / 'RESULT.json').read_text())['pid']
assert not Path('/proc', str(copy_pid)).exists()
save('vue-actual-preservation-proof.json', {
    'verdict': 'APPROVE_SOURCE_AND_STAGE_PRESERVATION',
    'STAGE-PRE01': 'CLOSED_SOURCE_AND_ACTUAL_PUBLIC_FILES',
    'producer': bundles['revision'], 'files': rows, 'files_count': 22,
    'public_file_mode': '0644', 'public_directory_mode': '0755',
    'new_independent_inodes_nlink1': 22, 'old_inodes_disjoint': True,
    'original22_metadata_and_bytes_exact': True,
    'original_private_700_dist_assets_directories_metadata_exact': len(preflight['original_parent_metadata']),
    'original8JAR_metadata_exact': len(preflight['JAR8_metadata']),
    'original8JAR_full_hash': 'not redundantly repeated; author actual streaming full hashes and prior accepted evidence remain qualified',
    'exact_pathsets_noextra_missing_symlink_temp': True,
    'actual_new_directory_count': len(directories),
    'template_exact_two_replacements': changes, 'template_reverse_bytes_exact': True,
    'nginx_image_USER_targets_readonly_createhostfalse_API_routing_unchanged': True,
    'mounted_root_qualification': 'public 755 root/subdirs and644 files inside mount; host private ancestors not mounted and need no whole-host chmod; real daemon/nativeUID/http not executed',
    'actual_unique_allocation_bytes': allocated, 'cap_bytes': 12582912,
    'author_copy_native_exit': 0, 'author_copy_pid_absent_now': copy_pid,
    'copy_temps_now': 0, 'native_UID_HTTP_apps_TLS_browser': 'NOT_RUN',
    'runtime_launch_grant': 'NONE; separate reviewed configuration and fresh floor required',
    'freeze': 'NEW public files/directories COW identity journal before any future write/chmod/build/formatter'})
print(json.dumps({'status': 'PASS', 'guard_source': 'b78c', 'proc_cases': 13,
                  'ownership_counterexamples': 'PASS', 'Vue_files': 22,
                  'STAGE-PRE01': 'CLOSED_SOURCE_AND_ACTUAL_PUBLIC_FILES',
                  'runtime': 'NOT_RUN'}))
