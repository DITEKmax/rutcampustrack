"""Closed pure boundary predicates and read-only file/provenance validation."""

import hashlib
import hmac
import json
import os
from pathlib import Path, PurePosixPath
import re
import stat
import subprocess

BASE = 'eb0e02aaf6c7cfb3b80db2d3a3c81b8a2dd79553'
MANIFEST_SHA = '37a7a45b6567a5ea23190e8a61e1a443942a41c0e1ce985b3f8618e5134d2ee9'
BASELINE_SHA = 'c429daec5ffd100147a718d53e3e16779ee36d1df261ee34420812d2dccf7c07'
PATHSET_SHA = 'a86ad40f5bdffd75b05dcce3e872ae2c8f2941514dcb6d1374257fb03aff7fd8'
INDEX_SHA = 'c683923c0df224b357ff6d20bb750a274785a58e5cb5dee375564886b63f4342'
COUNT = 1945
MEMBERS = {
    'before-root.safe.json', 'checkout.safe.json', 'complete-sparse-baseline.safe.json',
    'sourceprep.safe.json', 'run-stage.py', 'native-procedure.safe.json',
    'actual-source-controls.safe.json', 'READY.safe.json',
}
SELECTED = {
    'services/notification-bot/tests/np01_broker_bridge_runner.py',
    'services/academic-service/academic-app/src/test/java/ru/rutcampustrack/academic/botcredentials/BotCredentialBrokerBridgeIT.java',
}
METADATA_ONLY = {
    '.env.prod.example', 'services/notification-bot/.env.example',
    'services/notification-service/notification-app/src/test/resources/test-public.pem',
}


def safe_relative(name):
    if not isinstance(name, str) or not name or '\\' in name or '\x00' in name:
        return False
    path = PurePosixPath(name)
    return bool(path.parts) and not path.is_absolute() and str(path) == name and all(p not in {'.', '..'} for p in path.parts)


def pathset_hash(paths):
    return hashlib.sha256(json.dumps(sorted(paths), ensure_ascii=False, separators=(',', ':')).encode()).hexdigest()


def validate_ledger(ledger, grant):
    rows = ledger.get('entries')
    if ledger.get('base') != BASE or not isinstance(rows, list) or len(rows) != COUNT:
        raise ValueError('complete baseline required')
    paths = [row.get('path') for row in rows]
    if not all(safe_relative(p) for p in paths) or len(set(paths)) != COUNT or pathset_hash(paths) != PATHSET_SHA:
        raise ValueError('unique exact safe baseline path set required')
    if not (grant['sourceprep_manifest_sha256'] == MANIFEST_SHA
            and grant['baseline_sha256'] == BASELINE_SHA
            and grant['baseline_entry_count'] == COUNT
            and grant['baseline_pathset_sha256'] == PATHSET_SHA
            and grant['index_scope_sha256'] == INDEX_SHA):
        raise ValueError('baseline grant identity mismatch')
    for row in rows:
        if row.get('mode') != '0o600' or type(row.get('nlink')) is not int or row['nlink'] != 1 or type(row.get('bytes')) is not int or row['bytes'] < 0:
            raise ValueError('baseline regular-file metadata required')
        if not isinstance(row.get('sha256'), str) or not re.fullmatch('[0-9a-f]{64}', row['sha256']):
            raise ValueError('baseline source identity required')
    return rows


def validate_manifest_shape(manifest):
    rows = manifest.get('entries')
    if not isinstance(rows, list) or len(rows) != len(MEMBERS):
        raise ValueError('complete sourceprep manifest required')
    names = [row.get('path') for row in rows]
    if not all(safe_relative(n) for n in names) or len(set(names)) != len(MEMBERS) or set(names) != MEMBERS:
        raise ValueError('exact unique sourceprep members required')
    return rows


def validate_body_identities(rows, selected, current_hashes):
    for row in rows:
        if row['path'] in METADATA_ONLY:
            continue
        expected = selected[row['path']]['candidate_sha256'] if row['path'] in SELECTED else row['sha256']
        if current_hashes.get(row['path']) != expected:
            raise ValueError('tracked source body changed')


def file_metadata(path, anchor, mode, size=None):
    if not anchor.is_absolute() or not path.is_relative_to(anchor):
        raise ValueError('owned absolute path required')
    for directory in path.parents:
        if directory.is_symlink():
            raise ValueError('ancestor symlink rejected')
    current = path.lstat()
    if not stat.S_ISREG(current.st_mode) or current.st_nlink != 1 or current.st_uid != os.getuid():
        raise ValueError('own regular unaliased file required')
    if current.st_mode & 0o777 != mode or size is not None and current.st_size != size:
        raise ValueError('file metadata changed')


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def source_preflight(original, worktree, grant):
    file_metadata(original / 'manifest.safe.json', original, 0o600)
    file_metadata(original / 'complete-sparse-baseline.safe.json', original, 0o600)
    if digest(original / 'manifest.safe.json') != MANIFEST_SHA or digest(original / 'complete-sparse-baseline.safe.json') != BASELINE_SHA:
        raise ValueError('authentic sourceprep closure required')
    manifest = json.loads((original / 'manifest.safe.json').read_text())
    for member in validate_manifest_shape(manifest):
        path = original / member['path']
        file_metadata(path, original, 0o600, member['bytes'])
        if digest(path) != member['sha256']:
            raise ValueError('sourceprep member changed')
    rows = validate_ledger(json.loads((original / 'complete-sparse-baseline.safe.json').read_text()), grant)
    env = {'PATH': '/usr/local/bin:/usr/bin:/bin', 'LANG': 'C.UTF-8', 'LC_ALL': 'C.UTF-8', 'GIT_OPTIONAL_LOCKS': '0'}
    def git(*args):
        return subprocess.check_output(['git', '-C', str(worktree), *args], env=env, stderr=subprocess.DEVNULL, timeout=15)
    if git('rev-parse', 'HEAD').strip().decode() != BASE:
        raise ValueError('exact detached EB HEAD required')
    if subprocess.run(['git', '-C', str(worktree), 'symbolic-ref', '-q', 'HEAD'], env=env,
                      stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=15).returncode != 1:
        raise ValueError('detached HEAD required')
    index = git('ls-files', '--stage', '-z')
    if hashlib.sha256(index).hexdigest() != INDEX_SHA:
        raise ValueError('logical index scope changed')
    indexed = [item.split(b'\t', 1)[1].decode() for item in index.split(b'\x00') if item]
    present = [name for name in indexed if os.path.lexists(worktree / name)]
    if set(present) != {row['path'] for row in rows} or len(present) != COUNT:
        raise ValueError('missing or extraneous populated tracked input')
    if git('ls-files', '--others', '--exclude-standard', '-z'):
        raise ValueError('untracked nonignored input rejected')
    source = json.loads((original / 'sourceprep.safe.json').read_text())
    selected = source.get('changes')
    if not isinstance(selected, list) or len(selected) != 2 or {e.get('path') for e in selected} != SELECTED:
        raise ValueError('exact two canonical source mutations required')
    by_path = {entry['path']: entry for entry in selected}
    for row in rows:
        path = worktree / row['path']
        # Protect the three ENV/public-key fixtures: metadata-only, no body/hash reread.
        size = None if row['path'] in SELECTED else row['bytes']
        file_metadata(path, worktree, 0o600, size)
    current_hashes = {row['path']: digest(worktree / row['path']) for row in rows if row['path'] not in METADATA_ONLY}
    validate_body_identities(rows, by_path, current_hashes)
    return source


def validate_child_witness(witness, actual_parent, actual_child, nonce, phase, driver_sha, parent_argv_matches):
    if not isinstance(nonce, str) or not re.fullmatch('[0-9a-f]{64}', nonce):
        raise ValueError('private parent nonce required')
    if not (witness.get('guard_started') is True and parent_argv_matches
            and witness.get('parent_pid') == actual_parent['pid']
            and witness.get('parent_birth') == actual_parent['birth']
            and witness.get('child_pid') == actual_child['pid']
            and witness.get('child_birth') == actual_child['birth']
            and witness.get('phase') == phase and witness.get('driver_sha256') == driver_sha
            and isinstance(witness.get('nonce'), str) and hmac.compare_digest(witness['nonce'], nonce)):
        raise ValueError('live foreground guard parent witness required')
