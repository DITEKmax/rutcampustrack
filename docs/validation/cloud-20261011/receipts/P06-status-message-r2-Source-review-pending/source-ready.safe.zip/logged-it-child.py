"""Existing NP01 private-Gradle-output pattern, narrowed to one coherent main/test compile and targeted unit invocation."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import stat
import subprocess
import sys

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def private_json(path):
    if path.resolve() != path.absolute():
        raise ValueError("No-follow private input required")
    descriptor = os.open(path, os.O_RDONLY | os.O_NOFOLLOW)
    with os.fdopen(descriptor, "rb") as stream:
        info = os.fstat(stream.fileno())
        if not stat.S_ISREG(info.st_mode) or info.st_mode & 0o777 != 0o600 or info.st_size > 65536:
            raise ValueError("Bounded mode600 private input required")
        return json.loads(stream.read(65537))

def identity(pid):
    fields = (Path("/proc") / str(pid) / "stat").read_text().rsplit(")", 1)[1].split()
    if fields[0] == "Z":
        raise ValueError("Live process required")
    return {"pid": pid, "ppid": int(fields[1]), "start_ticks": int(fields[19])}

def admit_child(scope):
    plan_path = scope / "it-plan.safe.json"
    plan = json.loads(plan_path.read_text())
    run = Path(plan["run"])
    if not (os.getcwd() == plan["worktree"] and run.resolve() == run.absolute()
            and run.is_dir() and run.stat().st_mode & 0o777 == 0o700):
        raise ValueError("Exact owned private run and worktree required")
    witness = private_json(run / "parent-authority.private.json")
    parent = identity(os.getppid())
    child = identity(os.getpid())
    driver = scope / "run-it-owned.py"
    if not (witness["parent"]["pid"] == parent["pid"]
            and witness["parent"]["start_ticks"] == parent["start_ticks"]
            and child["ppid"] == parent["pid"] and witness["run"] == str(run)
            and witness["driver_sha256"] == digest(driver)
            and witness["child_sha256"] == digest(Path(__file__))
            and witness["plan_sha256"] == digest(plan_path)):
        raise ValueError("Exact live direct parent and source witness required")
    expected_args = [str(driver).encode(), witness["grant_path"].encode(), witness["grant_sha256"].encode()]
    actual_args = (Path("/proc") / str(parent["pid"]) / "cmdline").read_bytes().split(b"\0")
    if actual_args[1:4] != expected_args or any(actual_args[4:]):
        raise ValueError("Exact granted parent caller required")
    grant_path = Path(witness["grant_path"])
    grant = private_json(grant_path)
    if not (digest(grant_path) == witness["grant_sha256"] and grant["authorized"] is True
            and grant["lease"] == plan["lease"] and grant["source_review_approved"] is True
            and grant["driver_sha256"] == witness["driver_sha256"]
            and grant["child_sha256"] == witness["child_sha256"]
            and grant["plan_sha256"] == witness["plan_sha256"]
            and grant["guard_sha256"] == plan["guard_sha256"]
            and digest(Path(plan["guard_path"])) == plan["guard_sha256"]
            and grant["test_sha256"] == plan["test_sha256"]
            and digest(Path(plan["worktree"]) / plan["test_path"]) == plan["test_sha256"]):
        raise ValueError("Fresh Root grant and exact source required")
    manifest_path = scope / plan["source_manifest"]
    if not (digest(manifest_path) == plan["source_manifest_sha256"]
            and grant["source_manifest_sha256"] == plan["source_manifest_sha256"]):
        raise ValueError("Pinned formatted source manifest required")
    manifest = json.loads(manifest_path.read_text())
    for path, expected in {**manifest["files"], **manifest["protected_files"]}.items():
        if digest(Path(plan["worktree"]) / path) != expected:
            raise ValueError("Formatted source manifest mismatch")
    for source, pin in [(scope / plan["container_observer"], plan["container_observer_sha256"]),
                        (scope / plan["source_supplement"], plan["source_supplement_sha256"])]:
        if digest(source) != pin:
            raise ValueError("Pinned IT observer/supplement required")
    for path, expected in json.loads((scope / plan["source_supplement"]).read_text())["files"].items():
        if digest(Path(plan["worktree"]) / path) != expected:
            raise ValueError("IT existing fixture/build source changed")
    mutation = plan["mutation"]
    if not (grant["source_mutation_authorized"] is True
            and grant["mutation_source_path"] == mutation["source_path"]
            and grant["mutation_before_sha256"] == mutation["before_sha256"]
            and grant["mutation_after_sha256"] == mutation["mutant_sha256"]
            and digest(scope / mutation["before_file"]) == mutation["before_sha256"]
            and digest(scope / mutation["mutant_file"]) == mutation["mutant_sha256"]):
        raise ValueError("Exact status-only Source mutation authorization required")
    issued = datetime.datetime.fromisoformat(grant["issued_utc"])
    stop = datetime.datetime.fromisoformat(grant["stop_utc"])
    now = datetime.datetime.now(datetime.timezone.utc)
    if not (issued.tzinfo and stop.tzinfo and issued <= now
            < stop-datetime.timedelta(seconds=grant["limits"]["cleanup_margin_seconds"])):
        raise ValueError("Current grant with cleanup margin required")
    if identity(parent["pid"]) != parent or identity(child["pid"]) != child:
        raise ValueError("Live parent/child identity changed")
    return plan, run

def closed_red_xml(plan, run, started, native_exit):
    import re
    import xml.etree.ElementTree as ET
    path = Path(plan["worktree"]) / plan["xml_path"]
    if path.resolve() != path.absolute():
        raise ValueError("No-follow selected XML required")
    descriptor = os.open(path, os.O_RDONLY | os.O_NOFOLLOW)
    with os.fdopen(descriptor, "rb") as stream:
        info = os.fstat(stream.fileno())
        if not (stat.S_ISREG(info.st_mode) and info.st_size <= 1024**2
                and info.st_mtime > started.timestamp()):
            raise ValueError("Fresh bounded selected XML required")
        body = stream.read(1024**2 + 1)
    private_copy = run / "mutant.raw.private.xml"
    with private_copy.open("xb") as stream:
        stream.write(body)
    private_copy.chmod(0o600)
    path.chmod(0o600)
    (run / "mutant-xml-check.safe.json").write_text(json.dumps({
        "schema": "RCT_P06_STATUS_XML_CHECK_V1", "causal_red_valid": False,
        "private_xml_retained_unhashed": True,
    }) + "\n")
    try:
        xml_text = body.decode("utf-8-sig")
    except UnicodeDecodeError:
        raise ValueError("Selected XML must be UTF-8") from None
    if "\x00" in xml_text or "<!DOCTYPE" in xml_text or "<!ENTITY" in xml_text:
        raise ValueError("Selected XML DTD/entities or invalid encoding rejected")
    if re.match(r"<\?xml(?:[ \t\r\n]|\?>)", xml_text):
        declaration = re.match(
            r"""<\?xml[ \t\r\n]+version[ \t\r\n]*=[ \t\r\n]*(['"])1\.0\1"""
            r"""(?:[ \t\r\n]+encoding[ \t\r\n]*=[ \t\r\n]*(['"])(?i:UTF-8)\2)?"""
            r"""(?:[ \t\r\n]+standalone[ \t\r\n]*=[ \t\r\n]*(['"])(?:yes|no)\3)?"""
            r"[ \t\r\n]*\?>",
            xml_text,
        )
        if declaration is None:
            raise ValueError("Selected XML declaration must match the UTF-8 JUnit producer")
    try:
        suite = ET.fromstring(xml_text)
        counts = {key: int(suite.attrib[key]) for key in ["tests", "failures", "errors", "skipped"]}
        cases = suite.findall("testcase")
        exact = (suite.tag == "testsuite" and suite.attrib.get("name") == plan["test_class"]
                 and counts == {"tests": 1, "failures": 1, "errors": 0, "skipped": 0}
                 and len(cases) == 1 and cases[0].get("classname") == plan["test_class"]
                 and cases[0].get("name") in {plan["test_method"], plan["test_method"] + "()"}
                 and cases[0].find("error") is None and cases[0].find("skipped") is None)
        failures = cases[0].findall("failure") if exact else []
        causal = (exact and len(failures) == 1
                  and failures[0].get("type") == "java.lang.AssertionError"
                  and failures[0].get("message") == "java.lang.AssertionError: Response status expected:<503> but was:<401>"
                  and plan["test_class"] + "." + plan["test_method"] in (failures[0].text or "")
                  and plan["test_class"] + ".assertDurabilityAdmission" in (failures[0].text or ""))
    except (ET.ParseError, KeyError, ValueError, IndexError):
        raise ValueError("Invalid selected causal XML") from None
    compiled = digest(Path(plan["worktree"]) / plan["compiled_class_path"])
    if not (native_exit == 1 and causal and compiled != plan["original_compiled_class_sha256"]
            and digest(Path(plan["worktree"]) / plan["mutation"]["source_path"])
                == plan["mutation"]["mutant_sha256"]):
        raise ValueError("Exact compiled503expected401actual causal RED required")
    (run / "mutant-xml-check.safe.json").write_text(json.dumps({
        "schema": "RCT_P06_STATUS_XML_CHECK_V1", "causal_red_valid": True,
        "private_xml_retained_unhashed": True,
    }) + "\n")
    receipt = {"schema": "RCT_P06_STATUS_CAUSAL_RED_V1", "native_exit": native_exit,
               "class": plan["test_class"], "method": plan["test_method"], "counts": counts,
               "fresh_after_stage": True, "causal_status_assertion": True,
               "expected_http_status": 503, "actual_http_status": 401,
               "compiled_class_differs": True, "mutation_source_exact": True,
               "no_private_body_hash_or_failure_export": True,
               "qualification": "RED stops at status assertion; noJWT/dataeffects are Source-qualified only. Restored separate GREEN executes full original effect oracles."}
    (run / "mutant.closed-xml.safe.json").write_text(json.dumps(receipt, indent=2) + "\n")
    return receipt


scope = Path(__file__).resolve().parent
plan, run = admit_child(scope)
mutation = plan["mutation"]
source_target = Path(plan["worktree"]) / mutation["source_path"]
if source_target.resolve() != source_target.absolute():
    raise ValueError("Exact regular owned Source required")
before = (scope / mutation["before_file"]).read_bytes()
mutant = (scope / mutation["mutant_file"]).read_bytes()
original_mode = source_target.stat().st_mode & 0o777
primary = None
red_pass = False
restore_pass = False
with (run / "native.raw.private.log").open("xb") as output:
    (run / "native.raw.private.log").chmod(0o600)
    try:
        source_target.write_bytes(mutant)
        started = datetime.datetime.now(datetime.timezone.utc)
        red = subprocess.run(["bash", "./gradlew", *plan["gradle_arguments"]],
                             stdin=subprocess.DEVNULL, stdout=output, stderr=subprocess.STDOUT)
        output.flush()
        closed_red_xml(plan, run, started, red.returncode)
        red_pass = True
    except BaseException as failure:
        primary = failure
        raise
    finally:
        source_target.write_bytes(before)
        source_target.chmod(original_mode)
        try:
            # Restore compiler is a separate fresh admission under the same exact Root grant.
            plan, run = admit_child(scope)
            restore = subprocess.run(["bash", "./gradlew", *plan["restore_compile_arguments"]],
                                     stdin=subprocess.DEVNULL, stdout=output, stderr=subprocess.STDOUT)
            output.flush()
            restore_pass = (restore.returncode == 0
                            and digest(source_target) == mutation["before_sha256"]
                            and digest(Path(plan["worktree"]) / plan["compiled_class_path"])
                                == plan["original_compiled_class_sha256"])
            (run / "restore-compiler.safe.json").write_text(json.dumps({
                "native_exit": restore.returncode, "source_exact": digest(source_target) == mutation["before_sha256"],
                "compiled_exact": digest(Path(plan["worktree"]) / plan["compiled_class_path"])
                    == plan["original_compiled_class_sha256"], "no_second_pg_test": True,
            }) + "\n")
            if not restore_pass:
                raise ValueError("Fresh exact compiled Source restore required")
        except BaseException as restoration_failure:
            if primary is None:
                raise
            (run / "restore-failure.safe.json").write_text(json.dumps({
                "primary_red_failure_preserved": True, "compiler_restore_failure_preserved": True,
                "outcome": "UNKNOWN", "raw_errors_exported": False,
            }) + "\n")
            raise primary from restoration_failure
(run / "child-exit.safe.json").write_text(json.dumps({
    "native_exit": 0, "mutant_causal503expected401actual": red_pass,
    "source_and_compiled_restored": restore_pass, "second_pg_test_executed": False,
}) + "\n")
raise SystemExit(0)
