#!/usr/bin/env python3
"""Root-authorized synthetic guards only: no JVM/service/network/parent env."""
import ast
import importlib.util
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import threading
import time
from types import SimpleNamespace

HERE = Path(__file__).parent
ROOT = HERE.parent
AREA = HERE / 'synthetic-cases'
ENV = {'PATH': '/usr/bin:/bin', 'LANG': 'C.UTF-8'}


def module(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    value = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(value)
    return value


def rejects(call):
    try:
        call()
    except ValueError:
        return True
    return False


def pid_absent(pid):
    return not Path('/proc/' + str(pid)).exists()


def harmless_child(label):
    ready = AREA / (label + '-ready.json')
    child = subprocess.Popen([sys.executable, '-I', '-S', '-B', str(HERE / 'harmless-child.py'),
                              str(ready)], cwd=AREA, env=ENV,
                             stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL,
                             stderr=subprocess.DEVNULL)
    deadline = time.monotonic() + 2
    while not ready.exists() and time.monotonic() < deadline:
        time.sleep(.01)
    if not ready.exists():
        child.kill()
        child.wait(timeout=2)
        raise AssertionError('synthetic child readiness')
    assert json.loads(ready.read_text())['pid'] == child.pid
    return child


def send_twice():
    time.sleep(.05)
    os.kill(os.getpid(), signal.SIGINT)
    time.sleep(.05)
    os.kill(os.getpid(), signal.SIGTERM)


def before_interrupt(old, tree):
    child = harmless_child('before')
    previous = {n: signal.getsignal(n) for n in [signal.SIGINT, signal.SIGTERM]}
    run = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == 'run')
    cleanup = next(n for n in run.body if isinstance(n, ast.Try)).finalbody
    cleanup_code = compile(ast.Module(body=cleanup, type_ignores=[]), '<exact-old-finally>', 'exec')
    main = next(n for n in tree.body if isinstance(n, ast.If))
    old_try = next(n for n in main.body if isinstance(n, ast.Try))
    interrupted = next(h for h in old_try.handlers if isinstance(h.type, ast.Name)
                       and h.type.id == 'KeyboardInterrupt')
    except_code = compile(ast.Module(body=interrupted.body, type_ignores=[]), '<exact-old-except>', 'exec')
    outputs = []
    ns = dict(child=child, service='auth', start=time.monotonic(), stop='DEADLINE', polls=0,
              ready=0, subprocess=subprocess, time=time, emit=lambda *a, **k: None,
              print=lambda text, **k: outputs.append(json.loads(text)))
    dispatch = threading.Thread(target=send_twice)
    native = None
    try:
        for n in previous:
            signal.signal(n, old.interrupted)
        dispatch.start()
        try:
            try:
                # Harmless stand-in for the active phase; exact ORIGINAL cleanup follows.
                time.sleep(1)
            finally:
                exec(cleanup_code, ns)
        except KeyboardInterrupt:
            try:
                exec(except_code, ns)
            except SystemExit as result:
                native = result.code
        still_alive = child.poll() is None
        claim = outputs == [{'state': 'INTERRUPTED_CHILD_SETTLED'}]
        assert native == 130 and claim and still_alive
        return {'old_native_status': native, 'old_claimed_settled': claim,
                'actual_child_still_alive_at_claim': still_alive, 'pid': child.pid}
    finally:
        for n in previous:
            signal.signal(n, signal.SIG_IGN)
        dispatch.join(timeout=1)
        if child.poll() is None:
            child.kill()
        child.wait(timeout=2)
        assert pid_absent(child.pid)
        for n, h in previous.items():
            signal.signal(n, h)


def after_interrupt(new):
    child = harmless_child('after')
    stop = new.StopRequest()
    dispatch = threading.Thread(target=send_twice)
    try:
        with new.stop_handlers(stop):
            dispatch.start()
            outcome = new.settle_child(child, stop, terminate_timeout=.3, kill_timeout=1)
            dispatch.join(timeout=1)
            second = new.settle_child(child, stop, terminate_timeout=.3, kill_timeout=1)
        assert stop.signal_count == 2 and outcome['settled'] is True
        assert outcome['exit'] == -signal.SIGKILL and second == outcome and pid_absent(child.pid)
        return {'signal_count': stop.signal_count, 'pid': child.pid, 'native_exit': child.returncode,
                'settled': outcome['settled'], 'idempotent_second_settlement': second == outcome,
                'actual_pid_absent': pid_absent(child.pid)}
    finally:
        if child.poll() is None:
            child.kill()
        child.wait(timeout=2)


def main():
    AREA.mkdir(mode=0o700)
    old = module(ROOT / 'safe-child-status.py', 'old_guard')
    new = module(HERE / 'safe-child-status.py', 'new_guard')
    tree = ast.parse((ROOT / 'safe-child-status.py').read_text())
    rows = {}
    # No foreign file content read; old helper/path predicates only.
    escape = ROOT / '..' / 'host_runtime_review' / 'CURRENT.json'
    accepted = old.owned(escape)
    assert accepted.is_relative_to(ROOT) and not accepted.resolve().is_relative_to(ROOT)
    assert rejects(lambda: new.owned(escape))
    positive = AREA / 'public.json'
    positive.write_text('{}\n')
    assert new.owned(positive) == positive.resolve()
    link = AREA / 'symlink-public'
    link.symlink_to(positive)
    assert rejects(lambda: new.owned(link))
    outside_link = AREA / 'symlink-outside'
    outside_link.symlink_to('/tmp/does-not-exist-guard-synthetic')
    assert rejects(lambda: new.owned(outside_link))
    rows['HOST-G01'] = {'before_lexical_escape_accepted': True,
                        'after_parent_traversal_rejected': True,
                        'inside_and_outside_symlinks_rejected': True,
                        'positive_resolved_owned_path': True, 'foreign_contents_read': False}

    parent = {'JAVA_TOOL_OPTIONS': '-Dsynthetic.override=true',
              'JDK_JAVA_OPTIONS': '-Dsynthetic.unreviewed=true',
              'SPRING_APPLICATION_JSON': '{"synthetic":"unreviewed"}',
              'AWS_SECRET_ACCESS_KEY': 'synthetic-unrelated',
              'HTTP_PROXY': 'http://synthetic-proxy.invalid:8080'}
    public = {'SPRING_PROFILES_ACTIVE': 'prod', 'SERVER_ADDRESS': '127.0.0.1'}
    private = {'GRPC_SECRET': 'synthetic-own-only'}
    env_file = AREA / 'synthetic-private.json'
    env_file.write_text(json.dumps(private))
    env_file.chmod(0o600)
    # Execute the EXACT old env-copy/update AST with a synthetic os.environ map.
    run = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == 'run')
    statements = [n for n in run.body if (isinstance(n, ast.Assign)
                  and any(isinstance(t, ast.Name) and t.id == 'env' for t in n.targets))
                  or (isinstance(n, ast.Expr) and isinstance(n.value, ast.Call)
                      and isinstance(n.value.func, ast.Attribute)
                      and isinstance(n.value.func.value, ast.Name)
                      and n.value.func.value.id == 'env')]
    ns = {'os': SimpleNamespace(environ=parent), 'json': json, 'env_path': env_file,
          'spec': {'public_environment': public}}
    exec(compile(ast.Module(body=statements, type_ignores=[]), '<old-synthetic-env>', 'exec'), ns)
    assert all(n in ns['env'] for n in parent)
    policy = {'parent_names': ['HTTP_PROXY'], 'public_names': list(public),
              'private_names': list(private)}
    clean = new.build_environment(parent, public, private, policy)
    assert clean['HTTP_PROXY'] == parent['HTTP_PROXY'] and clean['GRPC_SECRET'] == private['GRPC_SECRET']
    assert all(n not in clean for n in parent if n != 'HTTP_PROXY')
    assert rejects(lambda: new.build_environment(parent, {**public, 'SPRING_APPLICATION_JSON': '{}'},
                                                 private, {**policy, 'public_names': [*public, 'SPRING_APPLICATION_JSON']}))
    assert rejects(lambda: new.build_environment(parent, public, private,
                                                 {**policy, 'parent_names': ['AWS_SECRET_ACCESS_KEY']}))
    assert rejects(lambda: new.build_environment(parent, public, {**private, 'JAVA_TOOL_OPTIONS': '-Xmx1g'},
                                                 {**policy, 'private_names': [*private, 'JAVA_TOOL_OPTIONS']}))
    assert rejects(lambda: new.build_environment(parent, public, {**private, 'SERVER_ADDRESS': 'bad'},
                                                 {**policy, 'private_names': [*private, 'SERVER_ADDRESS']}))
    rows['HOST-G03'] = {'before_exact_copy_forwarded_synthetic_java_spring_unrelated_credential': True,
                        'after_parent_overrides_and_unrelated_credentials_absent': True,
                        'approved_proxy_and_own_synthetic_credential_retained': True,
                        'unreviewed_maps_channels_and_overlap_rejected': True,
                        'real_environment_values_read': False, 'secret_values_printed': False}

    rows['HOST-G02'] = {'before': before_interrupt(old, tree), 'after': after_interrupt(new)}
    class NeverTerminal:
        def poll(self):
            return None
        def terminate(self):
            pass
        def kill(self):
            pass
        def wait(self, timeout):
            raise subprocess.TimeoutExpired('synthetic-no-process', timeout)
    failed = new.settle_child(NeverTerminal(), new.StopRequest(), terminate_timeout=.01, kill_timeout=.01)
    assert failed == {'settled': False, 'exit': None}
    rows['HOST-G02']['failure_reports_unsettled'] = True

    false = subprocess.run([sys.executable, '-I', '-S', '-B', str(HERE / 'safe-child-status.py'),
                            '--spec', str(ROOT / 'auth-spec.validation-only.json'),
                            '--grant', str(ROOT / 'root-grant.template.json')],
                           env=ENV, stdin=subprocess.DEVNULL, capture_output=True, text=True, timeout=5)
    assert false.returncode == 2 and false.stderr == ''
    assert json.loads(false.stdout) == {'state': 'BLOCKED_SAFE_VALIDATION_OR_RUNTIME_FAILURE'}
    rows['false_grant'] = {'native_exit': false.returncode, 'safe_status_only': True,
                            'app_child_started': False}
    (HERE / 'controls-result.json').write_text(json.dumps({'status': 'PASS_SYNTHETIC_GUARDS_ONLY',
                                                           'rows': rows, 'no_network': True,
                                                           'JVM_app_browser': 'NOT_RUN'}, indent=2) + '\n')
    print(json.dumps({'status': 'PASS_SYNTHETIC_GUARDS_ONLY', 'findings': list(rows),
                      'actual_child_pids_terminal_and_absent': True, 'JVM_app_browser': 'NOT_RUN'}))


if __name__ == '__main__':
    main()
