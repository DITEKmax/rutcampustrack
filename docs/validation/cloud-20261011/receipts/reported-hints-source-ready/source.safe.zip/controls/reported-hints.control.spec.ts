import { writeFileSync } from 'node:fs';
import { test, sanitizeTestErrors } from '/workspace/rct-worktrees/client-ci-first3/tests/e2e/fixtures/artifact-privacy';

const marker = process.env.RCT_SAFE_FAILURE_CONTROL_MARKER!;
test.afterEach(async ({}, info) => sanitizeTestErrors(info));
const early = test.extend<{}, { publicEarly: void }>({
  publicEarly: [async () => { throw new TypeError(marker); }, { scope: 'worker' }],
});
early.fail('public reported class survives worker setup failure', async ({ publicEarly }, info) => {
  void publicEarly;
  writeFileSync(info.outputPath('body-started.safe.json'), JSON.stringify({ bodyStarted: true }));
  throw new Error('PUBLIC_BODY_MUST_NOT_START');
});
const late = test.extend<{ publicLate: void }>({
  publicLate: async ({}, use) => {
    await use();
    const error = new Error(marker);
    // An intentionally fabricated public frame proves transport only, never source authenticity.
    error.stack = `Error: ${marker}\n    at Actor.call (/workspace/rct-worktrees/client-ci-first3/tests/e2e/fixtures/mobile-dataset.ts:38:13)`;
    throw error;
  },
});
late.fail('fabricated reported frame retains failure and unknown facts', async ({ publicLate }) => {
  void publicLate;
});
const unknown = test.extend<{ publicUnknown: void }>({
  publicUnknown: [async () => { throw new Error(`${marker}\nSynthetic actor login: HTTP 401`); }, { auto: true }],
});
unknown.fail('multiline setup payload remains unknown and redacted', async ({}, info) => {
  writeFileSync(info.outputPath('body-started.safe.json'), JSON.stringify({ bodyStarted: true }));
  throw new Error('PUBLIC_BODY_MUST_NOT_START');
});
