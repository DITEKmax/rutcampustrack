from pathlib import Path
import ast,datetime,json,hashlib
P=Path('/workspace/scratch/rct-validation/current_host_restart_plan');O=Path('/workspace/scratch/rct-validation/current_host_restart_review')
ns={};exec(compile((P/'restart-boundary.py').read_bytes(),'<public-boundary-source>','exec'),ns)
class SyntheticPath:
 def __init__(self,path):self.path=str(path)
 def __fspath__(self):return self.path
 def __str__(self):return self.path
 def __truediv__(self,part):return SyntheticPath(Path(self.path)/part)
 @property
 def parent(self):return SyntheticPath(Path(self.path).parent)
 def read_text(self):return Path(self.path).read_text()  # public sealed source/ledger files only
 def is_symlink(self):return self.path==str(P/'runtime')
 def is_dir(self):return True
 def mkdir(self,mode=0o777,exist_ok=False):
  actions.append({'selected_call':'parent_mkdir' if self.path==str(P/'runtime') else 'cohort_mkdir','parent_symlink_present':True,'would_target':'FOREIGN_DIRECTORY_THROUGH_PARENT_ALIAS','exist_ok':exist_ok})
# The model alters only runtime-path metadata. Source/hash/regular-file validation remains actual.
ns['PLAN']=SyntheticPath(P)
now=datetime.datetime.now(datetime.timezone.utc)
review=O/'input-ledger.json'
g={'durable_restart_authorized':True,'launch_authorized':True,'native_mongo_authorized':True,'reuse_existing_mongo_db':str(ns['DB']),'reuse_existing_mongo_key':str(ns['KEY']),'repeat_bootstrap_authorized':False,'data_reset_authorized':False,'cohort_name':'restart-pure-path-control','deadline_seconds':900,'not_before_utc':(now-datetime.timedelta(seconds=1)).isoformat(),'stop_utc':(now+datetime.timedelta(seconds=900)).isoformat(),'restart_manifest_sha256':hashlib.sha256((P/'manifest.json').read_bytes()).hexdigest(),'restart_review_manifest':str(review),'restart_review_manifest_sha256':hashlib.sha256(review.read_bytes()).hexdigest()}
runtime,remaining=ns['verify_restart'](g,str(P/'docker-up-restart.py'))
assert runtime.parent.is_symlink() and not runtime.is_symlink()
actions=[]
t=ast.parse((P/'docker-up-restart.py').read_text());main=next(n for n in t.body if isinstance(n,ast.FunctionDef) and n.name=='main')
for n in main.body:
 if isinstance(n,ast.Expr) and isinstance(n.value,ast.Call) and isinstance(n.value.func,ast.Attribute) and n.value.func.attr=='mkdir':exec(compile(ast.Module(body=[n],type_ignores=[]),'<selected-mkdir>','exec'),{'OUT':runtime})
results=[]
for name,var in [('run-mongo-restart.py','workspace_runtime'),('run-service-restart.py','runtime')]:
 tree=ast.parse((P/name).read_text());condition=next(n.test for n in ast.walk(tree) if isinstance(n,ast.If) and var+'.is_dir()' in ast.unparse(n.test) and var+'.is_symlink()' in ast.unparse(n.test));reject=eval(compile(ast.Expression(condition),'<selected-cohort-leaf-condition>','eval'),{var:runtime});assert reject is False;results.append({'entry':name,'selected_leaf_gate_rejects':reject,'ancestor_symlink_present_in_model':True})
(O/'cohort-parent-counterexample.safe.json').write_text(json.dumps({'finding':'RESTART-COHORT-ANCESTOR','synthetic_path_metadata_only':True,'actual_symlinks_or_foreign_writes_created':False,'actual_selected_verify_restart_accepts':True,'selected_Docker_calls':actions,'selected_native_Java_leaf_checks':results,'no_private_ENV_key_data_contents':True,'qualification':'Mocks represent an existing directory symlink at PLAN/runtime and a new normal leaf below it; no filesystem alias, app, process or network was created.'},indent=2)+'\n')
print(json.dumps({'finding':'RESTART-COHORT-ANCESTOR','helper_accepts_alias_parent':True,'mkdir_calls_follow_alias_parent':len(actions),'native_Java_leaf_gates_accept':len(results),'actual_alias_or_runtime':False}))
