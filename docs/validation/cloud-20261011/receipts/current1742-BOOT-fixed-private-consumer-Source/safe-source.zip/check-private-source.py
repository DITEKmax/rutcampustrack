"""Selected changed functions in RAM adapters only; no real private/native helper."""
import ast
import hashlib
import json
from pathlib import Path
import stat
import sys
from types import ModuleType, SimpleNamespace

ROOT = Path(__file__).absolute().parent
tree = ast.parse((ROOT/'private-bridge.py').read_text())
names = {'Gate','need','identity','own_leaf','cleanup','save_new','read_once','frozen_module','admit'}
selected = ast.Module(body=[n for n in tree.body if isinstance(n,(ast.FunctionDef,ast.ClassDef))
                           and n.name in names], type_ignores=[])

class RAMOS:
    O_RDONLY=1; O_WRONLY=2; O_CREAT=4; O_EXCL=8; O_NOFOLLOW=16
    def __init__(self, fail_write=False, drift=None, unlink_error=False, close_error=False):
        self.leaf=None; self.unlinks=0; self.opens=0; self.closes=0; self.chunks=[]
        self.fail_write=fail_write; self.drift=drift; self.unlink_error=unlink_error
        self.close_error=close_error; self.primary=OSError(); self.closed_primary=PermissionError()
        self.write_attempted=False
    def open(self, name, flags, *args, **kw):
        self.opens+=1
        if flags & self.O_CREAT:
            if self.leaf is not None: raise FileExistsError()
            self.leaf=SimpleNamespace(st_dev=1,st_ino=2,st_uid=1000,st_gid=1000,
                st_mode=0o100600,st_nlink=1,st_size=0,st_mtime_ns=1,st_ctime_ns=1)
        return 7
    def fstat(self, fd): return self.leaf
    def stat(self, name, **kw):
        if self.drift and self.write_attempted:
            copy=SimpleNamespace(**vars(self.leaf)); setattr(copy,*self.drift); return copy
        return self.leaf
    def write(self, fd, data):
        self.write_attempted=True
        if self.fail_write: raise self.primary
        self.chunks.append(len(data)); self.leaf.st_size+=len(data); return len(data)
    def read(self, fd, count): return b'synthetic'
    def unlink(self, name, **kw):
        if self.unlink_error: raise self.closed_primary
        self.unlinks+=1; self.leaf=None
    def close(self, fd):
        self.closes+=1
        if self.close_error: raise self.closed_primary

def scope(os_adapter):
    ns={'os':os_adapter,'stat':stat,'sys':sys,'hashlib':hashlib,'Path':Path,
        'ModuleType':ModuleType,'dt':None,'OWN':ROOT,'PRIVATE':ROOT/'private','CAP':33554432,'PINS':{}}
    exec(compile(selected, 'selected-private-bridge', 'exec'),ns)
    return ns

rows=[]
def record(name, ok): rows.append({'name':name,'passed':ok is True})
def guard(active=True): return None

o=RAMOS(); n=scope(o)
n['save_new'](3,'job.log.private',b'x'*131073,guard)
record('UNBUFFERED64K_CHUNKS_AND_COMPLETE_WRITE',o.chunks==[65536,65536,1] and o.closes==1)

o=RAMOS(fail_write=True); n=scope(o)
try: n['save_new'](3,'job.log.private',b'x',guard)
except BaseException as error:
    record('PARTIAL_WRITE_PRIMARY_AND_OWN_CLEANUP',error is o.primary and o.unlinks==1 and o.closes==1)

for label,drift in [('MODE',('st_mode',0o100644)),('UID',('st_uid',42)),
                    ('NLINK',('st_nlink',2)),('INODE',('st_ino',9))]:
    o=RAMOS(fail_write=True,drift=drift); n=scope(o)
    try: n['save_new'](3,'job.log.private',b'x',guard)
    except BaseException as error:
        record('DRIFT_'+label+'_RETAIN_PRIMARY_NO_UNLINK',error is o.primary and o.unlinks==0
               and error.__notes__==['PRIVATE_BRIDGE_CLEANUP_RECONCILIATION_REQUIRED'])

o=RAMOS(fail_write=True,unlink_error=True,close_error=True); n=scope(o)
try: n['save_new'](3,'job.log.private',b'x',guard)
except BaseException as error:
    record('UNLINK_AND_CLOSE_ERROR_DO_NOT_MASK_PRIMARY',error is o.primary and o.unlinks==0
           and error.__notes__==['PRIVATE_BRIDGE_CLEANUP_RECONCILIATION_REQUIRED',
                                'PRIVATE_BRIDGE_CLOSE_RECONCILIATION_REQUIRED'])

o=RAMOS(); o.leaf=SimpleNamespace(); n=scope(o)
try: n['save_new'](3,'job.log.private',b'x',guard)
except FileExistsError:
    record('PREEXISTING_LEAF_NOT_ADOPTED_UNLINKED_OR_WRITTEN',o.unlinks==0 and o.chunks==[])

o=RAMOS(); n=scope(o); calls=[]
def deny_cleanup(active=True):
    calls.append(active)
    if not active: raise n['Gate']('DEADLINE')
o.fail_write=True
try: n['save_new'](3,'job.log.private',b'x',deny_cleanup)
except BaseException as error:
    record('EXPIRED_OR_UNKNOWN_CLEANUP_DENIED_PRESERVES_PRIMARY',error is o.primary
           and o.unlinks==0 and False in calls)

o=RAMOS(); n=scope(o); entered=[]
n['public_bytes']=lambda _:entered.append('public') or b'marker=True\n'
try: n['admit']({'authorized':False})
except n['Gate']:
    record('FALSE_GRANT_BEFORE_PUBLIC_HELPER_OR_PRIVATE_EFFECT',entered==[] and o.opens==0)

n=scope(RAMOS()); source=b'marker=True\n'; target=Path('/public/synthetic.py')
n['public_bytes']=lambda _:source; n['PINS']={str(target):'0'*64}
try: n['frozen_module'](target)
except n['Gate']:
    record('CHANGED_PUBLIC_HELPER_REFUSED_BEFORE_EXEC',True)
n['PINS']={str(target):hashlib.sha256(source).hexdigest()}
record('EXACT_PUBLIC_BUFFER_EXEC_HAS_FILE_IDENTITY',n['frozen_module'](target).marker is True)

calls=[n for n in ast.walk(tree) if isinstance(n,ast.Call)]
consume=[n for n in calls if isinstance(n.func,ast.Attribute) and n.func.attr=='consume_private']
record('SINGLE_EXACT_R2_CONSUME_CALL_SOURCE',len(consume)==1
       and [ast.unparse(x) for x in consume[0].args]==['fd','binding'])
record('NO_NETWORK_SUBPROCESS_OR_ENV_SOURCE',not any(isinstance(n,ast.Import)
       and any(x.name in {'subprocess','urllib','requests'} for x in n.names) for n in tree.body)
       and 'os.environ' not in (ROOT/'private-bridge.py').read_text())

assert len(rows)==14 and all(row['passed'] for row in rows), 'SOURCE_CONTROL_FAILURE'
(ROOT/'controls.safe.json').write_text(json.dumps({'source_only':True,'actual_native':False,
    'actual_private_files':False,'native_helper_imports':False,'groups':len(rows),'rows':rows},indent=2)+'\n')
print(json.dumps({'source_only':True,'groups':len(rows),'passed':True}))
