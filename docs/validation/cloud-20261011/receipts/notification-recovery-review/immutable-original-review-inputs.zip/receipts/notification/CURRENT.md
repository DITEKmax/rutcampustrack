# Notification/provider recovery

Updated 2026-10-11T22:42:29.915594+00:00. Stable clean author commit `fa02ce439dfb989fc28eaddcbf1a8840d16bf9ff` frozen e093. Six files(A4/M2), ONLY product otp_requested.py providerfailure safe propagation. NOTIFY3 RELEASED; all actual sessions terminal, no own Java/labelled containers/apps, foreign resources untouched. NP02 actual before90021silentloss→after25989 durableDLQ/releasedclaim/manualsameeventrecover/dedupPASS. NP03 fourHTTPPASS, NP04 actualAuth3PASS+separaterealSocket1PASS, OTP5PASS and finalcurrentPython9PASS0skip; overlap retained, not summed as unique progress. Ruff/format/scoped diffPASS.

NP01 actual30637accepted firststartinitial GAP unresolved; genericRPC redaction preserved. NO transport/product/proto/config assignment. Own2 redbridge/probe files byte-exact archived NP01-pending-source+NP01-pending-files.json, restoration explicit; safeproposal exactadditivecontract candidate only. Gateway2003948 immutableapproved.

Next: fresh independent review this stable commit then rootintegration/remotegates; author fixesfindings. Root handles NP01 safecommoncontract/caller/transport provisioning and furtheractualfeatureproof, not silently complete. Packet/manifest files here; exclude lint-venv/tool-cache from transfer.
