from pathlib import Path
import json,hashlib,collections,os
O=Path('/workspace/scratch/rct-validation/ci_c16_receipts')
P=Path('/workspace/scratch/rct-validation/ci_eb0_receipts')
HEAD='c16a2995a3a830e5c0c4a0acf9cba4073aa212a2'
CHECKOUT='8d51d55e95f65d0fa2f7f7d76af73150719c2d6a'
def save(name,value):
 with (O/name).open('x') as f:json.dump(value,f,indent=2);f.write('\n')
 (O/name).chmod(0o600)
artifacts=json.loads((O/'safe-native-partial.json').read_text())['artifacts']
rows=[]
for a in artifacts:
 d=json.loads((O/(a['name']+'.json')).read_text())
 assert d['collection']=='RESULTS' and d['metadata']['prHeadSha']==HEAD and d['metadata']['checkoutSha']==CHECKOUT
 assert d['metadata']['runAttempt']=='1' and d['metadata']['event']=='pull_request' and d['metadata']['testStepOutcome']=='success'
 cc=collections.Counter(c['status'] for c in d['cases']);obs=collections.Counter()
 for x in d['xml']:
  assert x['state']=='PARSED'
  for s in x['suites']:assert s['countsConsistent'];obs.update(s['observed'])
 assert all(cc[k]==d['summary'][k]==obs[k] for k in d['summary'])
 rows.append({'artifact_id':a['artifact_id'],'name':a['name'],'digest':a['digest'],'metadata':d['metadata'],
              'cases_summary_XML_consistent':True,'summary':d['summary']})
totals={k:sum(r['summary'][k] for r in rows) for k in ['PASSED','FAILED','ERROR','SKIPPED','NOT_EXECUTED']}
assert totals=={'PASSED':2596,'FAILED':0,'ERROR':0,'SKIPPED':3,'NOT_EXECUTED':0}
save('safe-native-accounting-final.json',{'producer':HEAD,'checkout':CHECKOUT,'artifacts':rows,'totals':totals,'whole_acceptance':'NOT_ASSESSED'})
m=json.loads((O/'metadata-final.json').read_text());jobrows=[];conditional=[]
for j in m['jobs']:
 logs=[x for x in m['narrow_log_projection'] if x['job_id']==j['id']]
 matches=[r for r in rows if j['run_id']==38272615834 and ((j['name']=='Java unit — '+r['metadata']['service'] and r['metadata']['task']=='test')or(j['name']=='Java IT — '+r['metadata']['service'] and r['metadata']['task']=='integrationTest'))]
 if j['conclusion']!='skipped':
  assert len(logs)==1 and logs[0]['checkoutSha']==[CHECKOUT]
  if matches:assert len(matches)==1 and matches[0]['metadata']['checkoutSha']==CHECKOUT
  checkout=CHECKOUT
 else:checkout=None
 native=logs[0].get('native',[]) if logs else []
 tasks=[s for s in native if s.startswith('> Task ') and (s.endswith(':test') or s.endswith(':integrationTest'))]
 if matches:assert len(tasks)==1
 jobrows.append({'job_id':j['id'],'name':j['name'],'run_id':j['run_id'],'status':j['status'],'conclusion':j['conclusion'],
  'actual_checkout_sha':checkout,'receipt':'NARROW_GIT_LOG_AND_SAFE_OUTCOME' if matches else 'NARROW_GIT_LOG' if checkout else 'NOT_EXECUTED',
  'current_actual_test_tasks':tasks})
 for s in j['steps']:
  if s['conclusion']=='skipped':conditional.append({'run_id':j['run_id'],'job_id':j['id'],'job':j['name'],'step':s['name'],'conclusion':'skipped'})
assert len(jobrows)==32 and sum(r['actual_checkout_sha'] is not None for r in jobrows)==31
save('all-job-checkouts-final.json',{'producer':HEAD,'jobs':jobrows,'executed_jobs':31,'actualcheckout_proven_jobs':31,
                                    'explicit_skipped_jobs':1,'no_blanket_inference':True})
save('conditional-step-statuses.json',{'job_skips':[r for r in jobrows if r['conclusion']=='skipped'],'step_skips':conditional,
 'qualification':'Conditional upload/error/post-cache steps are explicit. Trivy built images NOT_EXECUTED; Diff coverage report actualSUCCESS.'})
d=json.loads((O/'safe-integration-outcomes-academic-service-1.json').read_text())
cases=[c for c in d['cases'] if (c.get('classname') or '').endswith('BotCredentialBrokerBridgeIT')]
assert len(cases)==1 and cases[0]['identity']=='SOURCE_METHOD' and cases[0]['status']=='PASSED'
b=cases[0];prior=P/'broker-current-eb-native.json';old=json.loads(prior.read_text());assert b['sourceSha256']==old['case']['sourceSha256']
artifact=next(a for a in artifacts if a['name']=='safe-integration-outcomes-academic-service-1')
job=next(j for j in m['jobs'] if j['name']=='Java IT — academic-service')
np=Path('/workspace/scratch/rct-validation/np01_native_caller_review/correction_recheck/actual-source-closure.safe.json')
npdata=json.loads(np.read_text());normal_pair=npdata['selected_mutants']
assert next(x for x in normal_pair if x['path'].endswith('BotCredentialBrokerBridgeIT.java'))['base_sha256']==b['sourceSha256']
save('broker-current-c16-native.json',{'artifact_id':artifact['artifact_id'],'artifact_digest':artifact['digest'],
 'metadata':d['metadata'],'case':b,'current_job_started_at':job['started_at'],'current_job_completed_at':job['completed_at'],
 'same_test_source_as_prior_qualified_seven':True,'prior_receipt':str(prior),'prior_receipt_sha256':hashlib.sha256(prior.read_bytes()).hexdigest(),
 'normal_source_pair_recent_independent_receipt':str(np),'normal_source_pair_recent_receipt_sha256':hashlib.sha256(np.read_bytes()).hexdigest(),
 'normal_source_pair':[{k:x[k] for k in ['path','base_sha256']}for x in normal_pair],
 'qualification':'Current named native method PASSED. Seven broker phase/default300 natural-expiry source oracles inherited by exact Java test source identity and recent normal Python helper source identity. SAFE collector omits native PTTL values/individual durations. Loopback emulator/direct JDBC synthetic fixture, not external Telegram or full product stand.',
 'NP01_sensitivity_chronology':'PRE_ONLY: current c16 case finished BEFORE pending temporary mutation native test; never green-after.',
 'no_semantic_or_runtime_replay':True})
result={'status':'COMPLETE_FINITE_RECEIPTS','producer':HEAD,'actual_checkout':CHECKOUT,'all4workflows':'SUCCESS',
 'java':totals,'python_passed':415,'vue_passed':1029,'vue_files':113,'chromium_passed':9,'chromium_seconds':20.8,
 'broker_current_method':'PASSED_SOURCE_QUALIFIED_SEVEN_PRE_ONLY','whole_product_acceptance':'NOT_ASSESSED','parent_promotions':0,
 'selected_model_effort':'Sol6.1/high','actual_model_effort':'UNKNOWN'}
save('RESULT.json',result)
print(json.dumps(result))
