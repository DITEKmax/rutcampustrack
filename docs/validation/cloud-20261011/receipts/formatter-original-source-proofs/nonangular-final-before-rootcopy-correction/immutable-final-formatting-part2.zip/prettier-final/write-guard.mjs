import fs from 'node:fs'
import fsp from 'node:fs/promises'
import { syncBuiltinESMExports } from 'node:module'
import { resolve } from 'node:path'
import { createHash } from 'node:crypto'
import { fileURLToPath } from 'node:url'

const root = '/workspace/rct-worktrees/ci-academic-heap'
const out = '/workspace/scratch/rct-validation/authored_format_current/prettier-final'
const original = { writeFile: fsp.writeFile.bind(fsp), writeFileSync: fs.writeFileSync.bind(fs), appendFileSync: fs.appendFileSync.bind(fs) }
const selected = new Set(JSON.parse(fs.readFileSync(`${out}/selected680.json`, 'utf8')).map((p) => resolve(root, p)))
const journal = `${out}/write-guard.ndjson`
function appendRecord(path, record) {
  const fd = fs.openSync(path, 'a', 0o600)
  try { fs.writeSync(fd, `${JSON.stringify(record)}\n`) } finally { fs.closeSync(fd) }
}
function guard(path) {
  const absolute = resolve(path instanceof URL ? fileURLToPath(path) : String(path))
  if (!selected.has(absolute)) {
    appendRecord(`${out}/guard-rejected-path.private.ndjson`, { path: String(path), absolute, cwd: process.cwd(), type: typeof path, constructor: path?.constructor?.name })
    process.exit(91)
  }
  const stat = fs.lstatSync(absolute)
  if (!stat.isFile() || stat.isSymbolicLink()) throw new Error('GUARD_UNEXPECTED_FILE_KIND')
  const record = { utc: new Date().toISOString(), phase: process.env.FORMAT_GUARD_PHASE ?? 'write4', pid: process.pid, path: absolute.slice(root.length + 1), nlink: stat.nlink, beforeInode: stat.ino, mode: stat.mode & 0o777, COW: false }
  if (stat.nlink > 1) {
    const data = fs.readFileSync(absolute)
    const hash = createHash('sha256').update(data).digest('hex')
    const tmp = `${absolute}.format-cow-${process.pid}`
    original.writeFileSync(tmp, data, { flag: 'wx', mode: stat.mode & 0o777 })
    if (createHash('sha256').update(fs.readFileSync(tmp)).digest('hex') !== hash) throw new Error('GUARD_COW_HASH')
    fs.renameSync(tmp, absolute)
    const independent = fs.lstatSync(absolute)
    if (independent.nlink !== 1 || independent.ino === stat.ino || (independent.mode & 0o777) !== (stat.mode & 0o777)) throw new Error('GUARD_COW_IDENTITY')
    record.COW = true
    record.afterInode = independent.ino
    record.sha256 = hash
  }
  appendRecord(journal, record)
}
fsp.writeFile = async (path, ...args) => { guard(path); return original.writeFile(path, ...args) }
fs.writeFileSync = (path, ...args) => { guard(path); return original.writeFileSync(path, ...args) }
syncBuiltinESMExports()
