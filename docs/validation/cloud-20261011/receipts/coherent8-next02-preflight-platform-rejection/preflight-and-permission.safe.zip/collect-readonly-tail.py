import datetime, errno, json, os, stat
from pathlib import Path
OWN=Path(__file__).parent
BASE=OWN.parents[1]
SOURCE=BASE/'current_academic_stage_completion_prepare'
actual=SOURCE/'actual-completion01'
state=json.loads((OWN/'preflight-critical-attempt01.safe.json').read_text())
def save(): (OWN/'preflight.safe.json').write_text(json.dumps(state,indent=2)+'\n')
def check(name, good):
 state['checks'][name]=bool(good)
 if not good:state['blockers'].append(name)
 save()
specs=json.loads((actual/'host-service-specs.safe.json').read_text());classrows=[]
for spec in specs:
 args=spec['argv'];cp=None
 if '-cp' in args:cp=args[args.index('-cp')+1]
 else:cp=next((arg.split('=',1)[1] for arg in args if arg.startswith('--class-path=')),None)
 good=Path(spec['cwd']).is_dir() and cp is not None
 if cp is not None:
  for entry in cp.split(':'):
   path=Path(entry);path=path if path.is_absolute() else Path(spec['cwd'])/path
   if path.name=='*':path=path.parent
   meta=path.lstat();good &= (stat.S_ISREG(meta.st_mode) or stat.S_ISDIR(meta.st_mode)) and os.access(path,os.R_OK)
 classrows.append({'service':spec['service'],'cwd':spec['cwd'],'classpath_style':'separate-cp' if '-cp' in args else 'inline-class-path','available_readable_nosymlink':bool(good)})
state['host7_classpath_metadata']=classrows;check('host7_app_cwds_and_declaredclasspath_readable',all(x['available_readable_nosymlink'] for x in classrows))
mounts=json.loads((BASE/'current_host_restart_ready_20261012/IPAM-mounts.safe.json').read_text())['exact_existing_readonly_bind_mounts'];mountrows=[]
for row in mounts:
 source=Path(row['source']);source=BASE/'current_host_config_v5_redirect_query_correction/edge-default.conf' if source.name=='edge-default.conf' else source;s=source.lstat();mountrows.append({'source':str(source),'device':s.st_dev,'inode':s.st_ino,'mode':stat.S_IMODE(s.st_mode),'uid':s.st_uid,'gid':s.st_gid,'nofollow_kind_ok':stat.S_ISDIR(s.st_mode) or stat.S_ISREG(s.st_mode)})
state['readonly_mount_metadata']=mountrows;check('exact_mounts_present_nosymlink_owned',all(x['nofollow_kind_ok'] and x['uid']==1000 for x in mountrows))
active=[];unreadable=[]
for path in Path('/proc').glob('[0-9]*/stat'):
 try:
  text=path.read_text();comm=text[text.index('(')+1:text.rindex(')')];fields=text.rsplit(')',1)[1].split()
  if comm in {'java','node','mongod','MiniBrowser','chrome','headless_shell'} and fields[0]!='Z':active.append({'pid':int(path.parent.name),'comm':comm,'start_ticks':int(fields[19]),'state':fields[0]})
 except OSError as e:
  if e.errno not in (errno.ENOENT,errno.ESRCH):unreadable.append({'pid':int(path.parent.name),'errno':e.errno})
state['visible_live_known_app_browser_names']=active;state['process_metadata_unreadable']=unreadable;check('no_visible_live_app_browser_and_root_heavy_released',not active and not unreadable)
check('new_cohort_absent',not(BASE/'current_host_restart_plan/runtime/restart-20261012-next02').exists());check('new_private_grant_absent',not(BASE/'current_host_config_v5/private/restart-launch-grant-next02.json').exists())
state['finished_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();state['disposition']='READY_READONLY_METADATA_ONLY' if not state['blockers'] else 'BLOCKED_EXACT_METADATA_GATE';save();print(json.dumps({'disposition':state['disposition'],'blockers':state['blockers'],'resources':state['resources'],'checks':state['checks'],'receipt':str(OWN/'preflight.safe.json')}))
