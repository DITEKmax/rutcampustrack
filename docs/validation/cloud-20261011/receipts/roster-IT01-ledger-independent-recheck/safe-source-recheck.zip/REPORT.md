APPROVE_SOURCE — closes only IT-ADMISSION-LEDGER-COMMIT-BEFORE-LIMITS.

Independent selected actual old/new observer class AST RAM confirms duplicate-role and third-session rejection now leaves sessions/known unchanged; settle removes all previously admitted resources, preserves denied/unknown resource and prior failure, and correctly reports overall settlement false while unknown remains. Old Source fails both invariant/cleanup controls.

Outside accept is byte-exact; plan changes only observer pin. Parent5b27/child130e/source13+protected2+supplement8 remain exact; all20 author manifest pins verified. Original b1d376/5323 CHANGES_REQUESTED receipt and old Source/18 controls remain immutable.

Native/Docker/private/probe data NOT_RUN/NOT_READ. Approval covers source only; fresh Root grant/resources/images, actual11 XML cases and owned cleanup remain external.
