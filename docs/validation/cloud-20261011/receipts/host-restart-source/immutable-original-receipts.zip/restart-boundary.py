"""Exact new restart grant and metadata gates; no secret or DB contents read."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import re
import stat
PLAN = Path('/workspace/scratch/rct-validation/current_host_restart_plan')
BASE = Path('/workspace/scratch/rct-validation/current_host_config_v5')
DB = Path('/tmp/rct-native-mongo-20261012/fresh-db')
KEY = Path('/tmp/rct-native-mongo-20261012/runtime/replica-key')

def regular(path):
    path = Path(path)
    if not path.is_absolute() or '..' in path.parts:
        raise RuntimeError('Absolute lexical path required')
    for parent in reversed(path.parents):
        if not stat.S_ISDIR(parent.lstat().st_mode):
            raise RuntimeError('Symlink ancestor denied')
    if not stat.S_ISREG(path.lstat().st_mode):
        raise RuntimeError('Regular exact input required')
    return path

def sha(path):
    return hashlib.sha256(regular(path).read_bytes()).hexdigest()

def validate_restart_fields(grant, now):
    if (grant.get('durable_restart_authorized') is not True
            or grant.get('launch_authorized') is not True
            or grant.get('native_mongo_authorized') is not True
            or grant.get('reuse_existing_mongo_db') != str(DB)
            or grant.get('reuse_existing_mongo_key') != str(KEY)
            or grant.get('repeat_bootstrap_authorized') is not False
            or grant.get('data_reset_authorized') is not False
            or not re.fullmatch(r'restart-[a-z0-9-]{1,48}', str(grant.get('cohort_name', '')))):
        raise RuntimeError('New exact durable restart grant required')
    seconds = grant.get('deadline_seconds')
    if type(seconds) is not int or not 1 <= seconds <= 1800:
        raise RuntimeError('Bounded deadline required')
    started = datetime.datetime.fromisoformat(grant['not_before_utc'])
    stop = datetime.datetime.fromisoformat(grant['stop_utc'])
    if (started.utcoffset() != datetime.timedelta(0) or stop.utcoffset() != datetime.timedelta(0)
            or not started <= now < stop or not 0 < (stop-started).total_seconds() <= 1800):
        raise RuntimeError('Fresh finite UTC grant required')
    return min(seconds, (stop-now).total_seconds())

def verify_restart(grant, source):
    remaining = validate_restart_fields(grant, datetime.datetime.now(datetime.timezone.utc))
    manifest_path = PLAN / 'manifest.json'
    if sha(manifest_path) != grant.get('restart_manifest_sha256'):
        raise RuntimeError('New exact restart seal required')
    manifest = json.loads(manifest_path.read_text())
    source = regular(Path(source).absolute())
    if not any(row['path'] == str(source) and sha(source) == row['sha256'] for row in manifest['files']):
        raise RuntimeError('Actual executing restart source must be sealed')
    for row in manifest['files']:
        if sha(row['path']) != row['sha256']:
            raise RuntimeError('Restart input changed')
    review = regular(grant['restart_review_manifest'])
    if sha(review) != grant['restart_review_manifest_sha256']:
        raise RuntimeError('Fresh independent restart review required')
    for row in json.loads((PLAN / 'prior-seals.safe.json').read_text())['seals']:
        if sha(row['path']) != row['sha256']:
            raise RuntimeError('Prior exact config/artifact/guard seal changed')
    return PLAN / 'runtime' / grant['cohort_name'], remaining

def metadata(path):
    path = Path(path)
    for parent in reversed(path.parents):
        if not stat.S_ISDIR(parent.lstat().st_mode):
            raise RuntimeError('Data symlink ancestor denied')
    s = path.lstat()
    kind = 'directory' if stat.S_ISDIR(s.st_mode) else 'regular' if stat.S_ISREG(s.st_mode) else 'denied'
    if kind == 'denied' or s.st_uid != os.getuid() or (kind == 'regular' and s.st_nlink != 1):
        raise RuntimeError('Own unaliased data identity required')
    return dict(path=str(path),device=s.st_dev,inode=s.st_ino,uid=s.st_uid,gid=s.st_gid,
                mode=stat.S_IMODE(s.st_mode),bytes=s.st_size,nlink=s.st_nlink,
                mtime_ns=s.st_mtime_ns,ctime_ns=s.st_ctime_ns,kind=kind)

def matching(expected, actual):
    return all(actual.get(key) == value for key, value in expected.items())

def verify_existing_data(fence, stopped):
    if not matching(fence['root_directory'], metadata('/tmp/rct-native-mongo-20261012')):
        raise RuntimeError('Native root identity changed')
    if not matching(fence['runtime_directory_identity'], metadata(KEY.parent)):
        raise RuntimeError('Native runtime identity changed')
    if not matching(fence['exact_key_metadata'], metadata(KEY)):
        raise RuntimeError('Existing key metadata changed')
    if stopped:
        current = [metadata(DB)]
        def fail(error):
            raise error
        for parent, dirs, files in os.walk(DB, followlinks=False, onerror=fail):
            current.extend(metadata(Path(parent)/name) for name in sorted(dirs+files))
        expected = {row['path']:row for row in fence['stopped_db_metadata_nodes']}
        if len(current) != len(expected) or {row['path']:row for row in current} != expected:
            raise RuntimeError('Stopped DB metadata fence changed')
    else:
        expected = fence['stopped_db_metadata_nodes'][0]
        identity = {key:expected[key] for key in ['path','device','inode','uid','gid','mode','kind']}
        if not matching(identity, metadata(DB)):
            raise RuntimeError('Live existing DB directory identity changed')
