"""One-shot exact recorded guard stop/reap. No daemon or group/global signal."""
import hashlib
import json
import os
from pathlib import Path
import signal
import time
import types

OWN = Path(__file__).parent
BASE = Path('/workspace/scratch/rct-validation/current_host_config_v5')
path = BASE.parent / 'guard_proc_race_correction/bounded-child.py'
body = path.read_bytes()
assert hashlib.sha256(body).hexdigest() == 'b78c61293568d9941692e0b92ee34fd0b84db6d532b4a2c9a5ad42ccbf2204a0'
guard = types.ModuleType('exact_stop_metadata')
exec(compile(body, str(path), 'exec'), guard.__dict__)
known = json.loads((OWN / 'live8-identities.safe.json').read_text())['identities']
attempts = []
for row in known:
    pid, birth = row['wrapper_pid'], row['wrapper_birth_ticks']
    table = guard.process_table()
    current = table.get(pid)
    if current is None or current['start_ticks'] != birth:
        attempts.append({'service': row['service'], 'wrapper_identity_absent': True})
        continue
    handle = os.pidfd_open(pid)
    try:
        current = guard.process_table().get(pid)
        if current is None or current['start_ticks'] != birth:
            raise RuntimeError('Birth changed while binding wrapper pidfd')
        signal.pidfd_send_signal(handle, signal.SIGTERM)
        attempts.append({'service': row['service'], 'pid': pid, 'birth_ticks': birth, 'exact_pidfd_SIGTERM': True})
    finally:
        os.close(handle)
(OWN / 'foreground-stop-attempts.safe.json').write_text(json.dumps(attempts, indent=2) + '\n')
deadline = time.monotonic() + 30
while time.monotonic() < deadline:
    table = guard.process_table()
    remaining = []
    for row in known:
        for key, ticks in [('wrapper_pid', 'wrapper_birth_ticks'), ('child_pid', 'child_birth_ticks')]:
            current = table.get(row[key])
            if current is not None and current['start_ticks'] == row[ticks]:
                remaining.append({'service': row['service'], 'kind': key, 'pid': row[key], 'state': current['state']})
    if not remaining:
        break
    time.sleep(0.05)
terminal = []
for row in known:
    receipt = json.loads((BASE / 'runtime' / (row['service'] + '-terminal.safe.json')).read_text())
    assert receipt['settled'] is True and receipt['all_owned_processes_reaped'] is True
    assert receipt['all_members_including_Z_after'] == []
    terminal.append({'service': row['service'], 'settled': True, 'reason': receipt['terminal_reason'],
                     'native_exit': receipt['native_exit'], 'all_owned_including_Z_reaped': True})
assert not remaining
(OWN / 'foreground-stop-terminal.safe.json').write_text(json.dumps({'all8_settled': True, 'known16_identities_absent': True,
    'terminal': terminal, 'no_foreign_or_numeric_group_signal': True}, indent=2) + '\n')
print(json.dumps({'all8_settled': True, 'known16_absent': True}))
