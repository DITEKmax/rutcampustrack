"""Pure metadata/FD counterexamples; never create aliases or native children."""
import ast
import copy
import errno
import json
import os
from pathlib import Path
import stat
import types
from unittest.mock import patch
C=Path(__file__).parent
P=C.parent/'current_host_restart_plan'
ns={'__file__':str(C/'restart-boundary.py')}
exec(compile((C/'restart-boundary.py').read_bytes(),'corrected-boundary','exec'),ns)
anchors=json.loads((C/'runtime-ancestor-anchors.safe.json').read_text())['anchors']
cohort=P/'runtime/restart-test'
checks=[]
def info(mode,uid,dev,ino,gid=1000,nlink=1):
 return types.SimpleNamespace(st_mode=mode,st_uid=uid,st_gid=gid,st_dev=dev,st_ino=ino,st_nlink=nlink)
base={r['path']:info(stat.S_IFDIR|r['mode'],r['uid'],r['device'],r['inode'],r['gid']) for r in anchors}
base[str(P/'runtime')]=info(stat.S_IFDIR|0o700,1000,27,9001)
base[str(cohort)]=info(stat.S_IFDIR|0o700,1000,27,9002)
class FakeOS:
 O_RDONLY=os.O_RDONLY;O_WRONLY=os.O_WRONLY;O_DIRECTORY=os.O_DIRECTORY
 O_NOFOLLOW=os.O_NOFOLLOW;O_CLOEXEC=os.O_CLOEXEC;O_CREAT=os.O_CREAT
 def __init__(self,table,swap=None):self.table=table;self.fds={};self.next=10;self.actions=[];self.swap=swap
 def getuid(self):return 1000
 def open(self,path,flags,mode=None,dir_fd=None):
  target=str(Path(self.fds[dir_fd][0])/path) if dir_fd is not None else str(path)
  if self.swap==target:
   self.table[target]=info(stat.S_IFDIR|0o700,1000,27,8888);self.swap=None
  value=self.table.get(target)
  if value is None:
   if flags & os.O_CREAT:
    value=info(stat.S_IFREG|mode,1000,27,9991);self.table[target]=value;self.actions.append(('create',target))
   else:raise FileNotFoundError(target)
  if stat.S_ISLNK(value.st_mode):raise OSError(errno.ELOOP,'mock nofollow')
  self.next+=1;self.fds[self.next]=(target,copy.copy(value));return self.next
 def fstat(self,fd):return self.fds[fd][1]
 def stat(self,name,dir_fd=None,follow_symlinks=True):
  assert follow_symlinks is False
  target=str(Path(self.fds[dir_fd][0])/name)
  if target not in self.table:raise FileNotFoundError(target)
  return self.table[target]
 def mkdir(self,name,mode,dir_fd=None):
  assert dir_fd is not None
  target=str(Path(self.fds[dir_fd][0])/name)
  if target in self.table:raise FileExistsError(target)
  self.table[target]=info(stat.S_IFDIR|mode,1000,27,9100+len(self.actions));self.actions.append(('mkdir',target))
 def close(self,fd):self.fds.pop(fd)
 def ftruncate(self,fd,length):self.actions.append(('truncate',self.fds[fd][0]))
 def fdopen(self,fd,mode):
  outer=self
  class Stream:
   def __enter__(self):return self
   def write(self,value):outer.actions.append(('write',outer.fds[fd][0]))
   def __exit__(self,*args):outer.close(fd)
  return Stream()
def run(name,table,create=False,should_accept=False,swap=None,mutate=None,receipt=False):
 fake=FakeOS(copy.deepcopy(table),swap)
 def lstat(path):
  value=fake.table.get(str(path))
  if value is None:raise FileNotFoundError(str(path))
  return value
 ns['os']=fake
 obj=None;accepted=False
 with patch.object(Path,'lstat',lstat):
  try:
   obj=ns['CohortDirectory'](cohort,create=create)
   if mutate:mutate(fake,obj)
   if receipt:obj.write_json('safe-process.json',{'status':'public'})
   else:obj.assert_current()
   accepted=True
  except (RuntimeError,OSError):pass
  finally:
   if obj:obj.close()
 assert accepted==should_accept,(name,accepted)
 if not should_accept:assert not any(a[0] in ('write','truncate') for a in fake.actions),name
 assert all(str(P) in action[1] for action in fake.actions),name
 checks.append({'name':name,'expected_accept':should_accept,'pass':True,'mock_actions':fake.actions})
run('valid existing exact owned cohort',base,should_accept=True,receipt=True)
new=copy.deepcopy(base);new.pop(str(cohort));run('new unique cohort uses pinned relative mkdir',new,create=True,should_accept=True,receipt=True)
new.pop(str(P/'runtime'));run('new runtime and cohort only under pinned PLAN',new,create=True,should_accept=True)
run('existing unique cohort denied for create',base,create=True)
for path in [str(P),str(P/'runtime'),str(cohort)]:
 for name,value in [('symlink',info(stat.S_IFLNK|0o777,1000,27,1)),('foreignowner',info(stat.S_IFDIR|0o700,999,27,1)),('regularfile',info(stat.S_IFREG|0o600,1000,27,1)),('otherwritable',info(stat.S_IFDIR|0o777,1000,27,1))]:
  bad=copy.deepcopy(base);bad[path]=value;run(name+' at '+path,bad)
for path in [str(P),str(P/'runtime')]:
 run('switched inode while opening '+path,base,swap=path)
run('pinned runtime ancestor replaced before receipt',base,should_accept=False,receipt=True,
 mutate=lambda fake,obj:fake.table.__setitem__(str(P/'runtime'),info(stat.S_IFLNK|0o777,1000,27,4)))
run('ambiguous descriptor count denied',base,receipt=True,mutate=lambda fake,obj:obj.identities.pop())
for name,value in [('receipt symlink',info(stat.S_IFLNK|0o777,1000,27,9003)),('receipt foreignowner',info(stat.S_IFREG|0o600,999,27,9003)),('receipt hardalias',info(stat.S_IFREG|0o600,1000,27,9003,nlink=2))]:
 bad=copy.deepcopy(base);bad[str(cohort/'safe-process.json')]=value;run(name,bad,receipt=True)
# Actual old selected return ignores runtime lstat. Mock symlink stays metadata-only.
tree=ast.parse((P/'restart-boundary.py').read_text())
function=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='verify_restart')
ret=next(n for n in function.body if isinstance(n,ast.Return))
old_return=eval(compile(ast.Expression(ret.value),'old actual return','eval'),{'PLAN':P,'grant':{'cohort_name':'restart-test'},'remaining':900})
assert old_return[0]==cohort
checks.append({'name':'old actual return accepts unchecked runtime path; new selected function denies symlink','pass':True,'old_counterexample':True})
# Source gates for all three actual runner entrypoints and one unchanged guard.
for name in ['docker-up-restart.py','run-mongo-restart.py','run-service-restart.py']:
 text=(C/name).read_text();compile(text,name,'exec')
 assert 'restart_ancestor_correction_manifest_sha256' in text
 assert text.index('restart_ancestor_correction_manifest_sha256')<text.index('exec(compile(')
 assert 'cohort = boundary.CohortDirectory' in text and 'cohort.assert_current()' in text and 'cohort.write_json' in text
 assert 'OUT.parent.mkdir' not in text and 'workspace_runtime.is_dir()' not in text and 'runtime.is_symlink() or not runtime.is_dir()' not in text
 checks.append({'name':name+' actual corrected source/import/use/receipt gates','pass':True})
(C/'ancestor-controls.safe.json').write_text(json.dumps({'status':'PASS_SELECTED_ANCESTOR_SOURCE_CONTROLS','count':len(checks),'checks':checks,'actual_aliases_children_or_runtime':False,'foreign_writes':False,'existing_data_or_key_read_or_mutation':False,'same_UID_isolation':'NOT_CLAIMED'},indent=2)+'\n')
print(json.dumps({'selected_controls':len(checks),'actual_aliases_or_runtime':False,'foreignwrites':False}))
