#!/usr/bin/env python3
"""Execute only the separately granted NP01_COMPILE1 lease."""
import datetime
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time

scope = Path(__file__).resolve().parent
worktree = Path("/workspace/rct-worktrees/np01-domain-bot")
grant = json.loads((scope / "compile1-grant.safe.json").read_text())
assert grant["lease"] == "NP01_COMPILE1"
assert subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=worktree).decode().strip() == grant["source_author"]
assert subprocess.check_output(["git", "status", "--porcelain=v1"], cwd=worktree) == b""
guard_path = scope / "guard-reviewed-f539.py"
assert hashlib.sha256(guard_path.read_bytes()).hexdigest() == "f539f126bb5591e89f1a9e1f6ac72fbb91ba0da39fccda02cd773ca515acf706"
spec = importlib.util.spec_from_file_location("reviewed_f539_guard", guard_path)
guard = importlib.util.module_from_spec(spec)
spec.loader.exec_module(guard)

def utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()

def write_json(name, value):
    target = scope / name
    temporary = target.with_suffix(target.suffix + ".new")
    temporary.write_text(json.dumps(value, indent=2) + "\n")
    temporary.replace(target)

memory_path = Path("/sys/fs/cgroup/memory.current")
initial_free = shutil.disk_usage("/workspace").free
initial_memory = int(memory_path.read_text())
assert initial_free >= grant["disk_floor"] + grant["disk_growth_cap"]
assert initial_memory < grant["shared_memory_stop"]
last_status = 0.0
peak = {"maximum_memory_current": initial_memory, "minimum_disk_free": initial_free}

def observe():
    free = shutil.disk_usage("/workspace").free
    memory = int(memory_path.read_text())
    peak["maximum_memory_current"] = max(peak["maximum_memory_current"], memory)
    peak["minimum_disk_free"] = min(peak["minimum_disk_free"], free)
    if free < grant["disk_floor"]:
        return "DISK_FLOOR"
    if initial_free - free > grant["disk_growth_cap"]:
        return "DISK_GROWTH_CAP"
    if memory >= grant["shared_memory_stop"]:
        return "SHARED_MEMORY_STOP"
    return None

def status(value):
    global last_status
    now = time.monotonic()
    if value["state"] == "RUNNING" and now - last_status < 1:
        return
    last_status = now
    value.update(utc=utc(), lease="NP01_COMPILE1", observer_pid=os.getpid(),
                 disk_free=shutil.disk_usage("/workspace").free,
                 shared_memory_current=int(memory_path.read_text()))
    write_json("compile1-live.safe.json", value)
    current = json.loads((scope / "CURRENT.json").read_text())
    current.update(utc=value["utc"], status="NP01_COMPILE1_" + value["state"],
                   lease="NP01_COMPILE1", observer_pid=os.getpid(),
                   owned_runtime_pids=value["members_including_Z"],
                   active_native_child_pid=value["child_pid"],
                   next="poll the existing compile session; no integrationTest/Docker/worker/provider grant")
    write_json("CURRENT.json", current)

environment = {
    "JAVA_HOME": "/workspace/rct-cloud-setup/jdk21",
    "GRADLE_USER_HOME": "/workspace/.gradle",
    "PATH": "/workspace/rct-cloud-setup/jdk21/bin:/opt/codex/runtimes/codex-primary-runtime/dependencies/python/bin:/usr/local/bin:/usr/bin:/bin",
    "LANG": "C.UTF-8", "LC_ALL": "C.UTF-8", "TZ": "UTC",
    "TMPDIR": str(scope / "private"), "PYTHONDONTWRITEBYTECODE": "1",
    "PYTHONNOUSERSITE": "1", "PYTHONSAFEPATH": "1",
}
for name in ("HTTP_PROXY", "HTTPS_PROXY", "NO_PROXY", "SSL_CERT_FILE"):
    if name in os.environ:
        environment[name] = os.environ[name]
started = time.monotonic()
result = guard.run_owned(
    [sys.executable, str(scope / "logged-gradle-child.py")], str(worktree), environment,
    deadline_seconds=grant["deadline_seconds"], observe=observe, status=status,
    term_seconds=15, kill_seconds=10,
)
result.update(utc=utc(), lease="NP01_COMPILE1", elapsed_seconds=round(time.monotonic() - started, 3),
              initial_disk_free=initial_free, initial_memory_current=initial_memory, peaks=peak,
              environment_keys=sorted(environment), environment_values_dumped=False)
write_json("compile1-process-result.safe.json", result)
print(json.dumps(result), flush=True)
raise SystemExit(0 if result["phase_success"] else 1)
