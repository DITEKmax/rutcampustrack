"""Closed reader for one pinned public class; failure bodies and streams are not inspected or emitted."""
import os
from pathlib import Path
import stat
import xml.etree.ElementTree as ET

CLASS = "ru.rutcampustrack.notification.security.PublicKeyProvisioningTest"
MAX_XML_BYTES = 1024 * 1024


def rejected(code):
    return {"schema": "RCT_P07_CLOSED_XML_V1", "schema_valid": False,
            "code": code, "pass": False, "cases": []}


def parse_closed(data, methods):
    if len(methods) != 2 or len(set(methods)) != 2:
        return rejected("EXPECTED_METHODS_INVALID")
    if len(data) > MAX_XML_BYTES:
        return rejected("XML_SIZE_CAP")
    try:
        document = data.decode("utf-8")
    except UnicodeDecodeError:
        return rejected("XML_ENCODING_INVALID")
    if "<!DOCTYPE" in document.upper() or "<!ENTITY" in document.upper():
        return rejected("XML_DTD_DENIED")
    try:
        suite = ET.fromstring(document)
    except (ET.ParseError, ValueError):
        return rejected("XML_INVALID")
    if suite.tag != "testsuite" or suite.get("name") != CLASS:
        return rejected("SUITE_INVALID")
    if any(child.tag not in ["testcase", "properties", "system-out", "system-err"]
           for child in suite):
        return rejected("SUITE_SHAPE_INVALID")
    try:
        declared = {key: int(suite.get(key, ""))
                    for key in ["tests", "failures", "errors", "skipped"]}
    except ValueError:
        return rejected("DECLARED_INVALID")
    if declared["tests"] != 2 or any(value < 0 or value > 2 for value in declared.values()):
        return rejected("DECLARED_INVALID")
    rows = {}
    aliases = {name: name for name in methods}
    aliases.update({name + "()": name for name in methods})
    for case in suite.findall("testcase"):
        method = aliases.get(case.get("name"))
        if case.get("classname") != CLASS or method is None or method in rows:
            return rejected("CASE_IDENTITY_INVALID")
        if any(child.tag not in ["failure", "error", "skipped", "system-out", "system-err"]
               for child in case):
            return rejected("CASE_SHAPE_INVALID")
        edges = [child.tag for child in case if child.tag in ["failure", "error", "skipped"]]
        if len(edges) > 1:
            return rejected("CASE_STATUS_INVALID")
        rows[method] = {"method": method,
                        "status": {"failure": "FAILED", "error": "ERROR",
                                   "skipped": "SKIPPED"}.get(edges[0], "PASSED")
                        if edges else "PASSED"}
    if set(rows) != set(methods):
        return rejected("EXACT2_REQUIRED")
    observed = {status: sum(row["status"] == status for row in rows.values())
                for status in ["PASSED", "FAILED", "ERROR", "SKIPPED"]}
    if (declared["failures"] != observed["FAILED"]
            or declared["errors"] != observed["ERROR"]
            or declared["skipped"] != observed["SKIPPED"]):
        return rejected("COUNTS_INCONSISTENT")
    return {"schema": "RCT_P07_CLOSED_XML_V1", "schema_valid": True, "code": "CLOSED",
            "pass": observed["PASSED"] == 2, "classname": CLASS,
            "declared": declared, "observed": observed,
            "cases": [rows[name] for name in methods]}


def collect(path, methods):
    path = Path(path)
    try:
        if path.resolve() != path.absolute():
            return rejected("XML_NOFOLLOW_REQUIRED")
        descriptor = os.open(path, os.O_RDONLY | os.O_NOFOLLOW)
        with os.fdopen(descriptor, "rb") as stream:
            info = os.fstat(stream.fileno())
            if (not stat.S_ISREG(info.st_mode) or info.st_mode & 0o777 != 0o600
                    or info.st_size > MAX_XML_BYTES):
                return rejected("XML_FILE_INVALID")
            data = stream.read(MAX_XML_BYTES + 1)
    except OSError:
        return rejected("XML_UNAVAILABLE")
    return parse_closed(data, methods)
