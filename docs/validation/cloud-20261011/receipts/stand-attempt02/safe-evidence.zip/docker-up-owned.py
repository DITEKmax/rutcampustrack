import datetime,hashlib,json,os,types
from pathlib import Path
OWN=Path('/workspace/scratch/rct-validation/current_host_config_v4');OUT=Path(__file__).parent
os.umask(0o077)
guard_path=OWN.parent/'guard_proc_race_correction/bounded-child.py';body=guard_path.read_bytes()
assert hashlib.sha256(body).hexdigest()=='b78c61293568d9941692e0b92ee34fd0b84db6d532b4a2c9a5ad42ccbf2204a0'
guard=types.ModuleType('reviewed_guard');guard.__file__=str(guard_path);exec(compile(body,str(guard_path),'exec'),guard.__dict__)
def save(name,value):
 (OUT/name).write_text(json.dumps(value,indent=2)+'\n')
def resources():
 v=os.statvfs('/workspace');return {'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'free_available_bytes':v.f_bavail*v.f_frsize,'memory_current':int(Path('/sys/fs/cgroup/memory.current').read_text()),'memory_max':int(Path('/sys/fs/cgroup/memory.max').read_text())}
def observe():
 r=resources();save('resources-live.safe.json',r)
 if r['free_available_bytes']<4294967296:return 'DISK_FLOOR'
 if r['memory_current']>=16106127360 or r['memory_max']-r['memory_current']<1073741824:return 'SHARED_MEMORY_STOP'
 return None
argv=json.loads((OWN/'launch-commands-v4.json').read_text())['Docker9_start_only_after_review_and_actual_resource_lease']
assert '--no-build' in argv and argv[argv.index('--pull')+1]=='never'
stat=guard.proc_stat(os.getpid()) if hasattr(guard,'proc_stat') else guard.process_table()[os.getpid()]
save('docker-up-launch.safe.json',{'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'wrapper_identity':stat,'argv':argv,'resource_before':resources(),'stdout_stderr':'DEVNULL; no ENV/key/log/Health.Log output'})
save('CURRENT.json',{'status':'DOCKER9_UP_IN_PROGRESS','wrapper_pid':os.getpid(),'started':datetime.datetime.now(datetime.timezone.utc).isoformat(),'next':'measure actual allocation/status then host foreground services'})
result=guard.run_owned(argv,str(OWN),{'PATH':'/usr/local/bin:/usr/bin:/bin','HOME':str(OWN/'runtime'),'LANG':'C.UTF-8','LC_ALL':'C.UTF-8'},deadline_seconds=600,observe=observe,status=lambda value:save('docker-up-process.safe.json',value))
save('docker-up-terminal.safe.json',{'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'guard':result,'resources_after':resources()})
print(json.dumps({'native_exit':result['native_exit'],'settled':result['settled'],'phase_success':result['phase_success'],'reason':result['terminal_reason'],'resources':resources()}))
raise SystemExit(0 if result['phase_success'] else 1)
