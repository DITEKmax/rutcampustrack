"""Pure plan/source controls; never imports or executes the broker harness."""

import ast
import hashlib
import json
from pathlib import Path


HERE = Path(__file__).resolve().parent
ROOT = Path('/workspace/rutcampustrack')
ORIGINAL = Path('/workspace/scratch/rct-validation/np01_broker_sensitivity_plan')
STAGE = 'np01_br_t01_new_foreign_removed_before_exact_card_assert'
PHASE03 = 'actual_unlinked_reset_original_uid_cleanup'
PYTHON_PATH = 'services/notification-bot/tests/np01_broker_bridge_runner.py'
JAVA_PATH = (
    'services/academic-service/academic-app/src/test/java/'
    'ru/rutcampustrack/academic/botcredentials/BotCredentialBrokerBridgeIT.java'
)


def digest(data):
    return hashlib.sha256(data).hexdigest()


def card_call(key, text):
    return ast.parse(f'require_exact_card(provider.cards, {key}, {text})').body[0]


def dump(node):
    return ast.dump(node, include_attributes=False)


def blocks(tree):
    for node in ast.walk(tree):
        for _, value in ast.iter_fields(node):
            if isinstance(value, list) and value and all(isinstance(x, ast.stmt) for x in value):
                yield value


def native_qualified(fields):
    return (
        fields.get('stage') == STAGE
        and fields.get('qualified') is False
        and type(fields.get('failures')) is int
        and fields['failures'] == 1
        and fields.get('workers_reaped') is True
        and type(fields.get('child_exit')) is int
        and fields['child_exit'] == 1
        and fields.get('junit_failed_at_zero_exit_assertion') is True
        and fields.get('all_owned_resources_terminal') is True
        and fields.get('noninfra_no_signal_deadline_or_cleanup_failure') is True
    )


def main():
    original_manifest = json.loads((ORIGINAL / 'manifest.safe.json').read_text())
    for entry in original_manifest['entries']:
        assert digest((ORIGINAL / entry['path']).read_bytes()) == entry['sha256']
    assert digest((ORIGINAL / 'safe-plan.zip').read_bytes()) == (
        '7f01456b46876f54b6357dcbee45526aa6281b8152e930f5faac9382f6e00412'
    )
    proposal = json.loads((HERE / 'PLAN.safe.json').read_text())
    source = (ROOT / PYTHON_PATH).read_text()
    java = (ROOT / JAVA_PATH).read_text()
    assert STAGE not in source and STAGE not in java
    anchor = proposal['fault']['original_anchor']
    insert = proposal['fault']['insert']
    assert source.count(anchor) == 1
    old_call = '            require_exact_card(provider.cards, old_foreign_key, old_foreign_text)\n'
    new_call = '            require_exact_card(provider.cards, new_foreign_key, new_foreign_text)\n'
    assert anchor.endswith(old_call + new_call)
    replacement = anchor[:-len(new_call)] + insert + new_call
    candidate = source.replace(anchor, replacement, 1)
    assert candidate.replace(replacement, anchor, 1) == source
    original_tree = ast.parse(source)
    candidate_tree = ast.parse(candidate)
    old_oracle = card_call('old_foreign_key', 'old_foreign_text')
    new_oracle = card_call('new_foreign_key', 'new_foreign_text')
    expected_delete = ast.parse('del provider.cards[new_foreign_key]').body[0]
    expected_stage = ast.parse(f'_phase = {STAGE!r}').body[0]
    matches = []
    for body in blocks(candidate_tree):
        for index in range(len(body) - 4):
            five = body[index:index + 5]
            if [dump(node) for node in five] == [
                dump(old_oracle), dump(new_oracle), dump(expected_delete),
                dump(expected_stage), dump(new_oracle),
            ]:
                matches.append((body, index))
    assert len(matches) == 1
    body, index = matches[0]
    inserted = body[index + 1:index + 4]
    assert not any(isinstance(n, ast.Await) for node in inserted for n in ast.walk(node))
    del body[index + 1:index + 4]
    assert dump(candidate_tree) == dump(original_tree)
    supervisor = next(n for n in original_tree.body if isinstance(n, ast.AsyncFunctionDef) and n.name == 'supervisor')
    assert any(isinstance(n, ast.Global) and '_phase' in n.names for n in supervisor.body)
    helper = next(n for n in original_tree.body if isinstance(n, ast.FunctionDef) and n.name == 'require_exact_card')
    expected_helper = ast.parse('check(key in cards and cards[key] == text)').body[0]
    assert dump(helper.body[-1]) == dump(expected_helper)
    original_java = 'assertThat(child.exitValue()).isZero();'
    assert java.count(original_java) == 1
    diagnostic = proposal['diagnostic']['proposed_statement']
    assert diagnostic.startswith('assertThat(child.exitValue())')
    assert diagnostic.rstrip().endswith('.isZero();')
    assert diagnostic.count(STAGE) == 2
    assert '"UNEXPECTED_STAGE"' in diagnostic
    assert diagnostic.count('result.path(') == 4
    assert 'System.out' not in diagnostic and 'toString()' not in diagnostic
    base = {
        'stage': STAGE, 'qualified': False, 'failures': 1,
        'workers_reaped': True, 'child_exit': 1,
        'junit_failed_at_zero_exit_assertion': True,
        'all_owned_resources_terminal': True,
        'noninfra_no_signal_deadline_or_cleanup_failure': True,
    }
    cases = [('intended_postfault_assertion', {}, True)]
    cases += [(name, {'stage': PHASE03}, False) for name in (
        'producer_guard_before_fault', 'native_ack_before_fault',
        'immediate_new_precondition_failure', 'deletion_keyerror_before_marker',
    )]
    cases += [
        ('unrecognized_public_stage', {'stage': 'UNEXPECTED_STAGE'}, False),
        ('worker_reap_unsettled', {'workers_reaped': False}, False),
        ('other_owned_resource_unsettled', {'all_owned_resources_terminal': False}, False),
        ('signal_deadline_cleanup_failure', {'noninfra_no_signal_deadline_or_cleanup_failure': False}, False),
        ('wrong_failure_count', {'failures': 2}, False),
        ('wrong_native_exit', {'child_exit': 2}, False),
        ('normal_success', {'qualified': True, 'failures': 0, 'child_exit': 0}, False),
        ('failure_at_other_java_assertion', {'junit_failed_at_zero_exit_assertion': False}, False),
    ]
    controls = []
    for name, delta, expected in cases:
        got = native_qualified(base | delta)
        assert got == expected
        controls.append({'id': name, 'expected_accepted': expected, 'actual_accepted': got})
    receipt = {
        'status': 'PASS_SOURCE_AST_AND_PLAN_PREDICATES_ONLY_NATIVE_NOT_RUN',
        'source_input_sha256': {PYTHON_PATH: digest(source.encode()), JAVA_PATH: digest(java.encode())},
        'candidate_python_parse': True,
        'exact_adjacent_old_new_precheck_delete_marker_unchanged_new': True,
        'no_await_in_inserted_sequence': True,
        'remove_three_inserted_ast_statements_equals_entire_original_ast': True,
        'text_restore_equals_entire_original_source': True,
        'original_exact_card_helper_and_java_zero_exit_assertion_preserved': True,
        'unique_stage_absent_from_original_two_sources': True,
        'java_diagnostic_closed_whitelist_static_literal_boolean_integer_only': True,
        'controls': controls,
        'original_plan_seal_unchanged': True,
        'tracked_source_writes': 0,
        'qualification': 'In-memory AST/text transformation and pure finite acceptance predicates; no harness import/run, Java compile, resources, native card/ACK/cleanup proof.'
    }
    output = HERE / 'source-controls.safe.json'
    assert not output.exists()
    output.write_text(json.dumps(receipt, indent=2) + '\n')
    output.chmod(0o600)
    print(json.dumps({'status': receipt['status'], 'controls': len(controls), 'tracked_source_writes': 0}))


if __name__ == '__main__':
    main()
