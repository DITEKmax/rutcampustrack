"""Capture safe selected TTL outcome and exact terminal identity. No token bodies."""
from pathlib import Path
import datetime
import hashlib
import json
import re
import subprocess
import sys
import xml.etree.ElementTree as ET

phase, session, native_exit = sys.argv[1], int(sys.argv[2]), int(sys.argv[3])
root = Path('/workspace/rct-worktrees/notification-provider')
scratch = Path('/workspace/scratch/rct-validation/notification_provider_developer')
xml_path = root / 'services/auth-service/auth-app/build/test-results/integrationTest/TEST-ru.rutcampustrack.auth.integration.WsTicketConcurrencyBoundaryIT.xml'
log_path = root / '.agent/evidence/notification-provider' / ('NTR01-control-red.log' if phase == 'red' else 'NTR01-restored-green.log')
xml = ET.parse(xml_path).getroot()
failure = xml.find('.//failure')
message = failure.get('message', '') if failure is not None else None
safe_timings = [line.strip() for line in xml.findtext('system-out', '').splitlines()
                if re.fullmatch(r'WS ticket TTL remaining_ms=-?\d+ issue_read_ms=\d+ minimum_ms=-?\d+', line.strip())]
for tag in ('system-out', 'system-err'):
    for node in xml.findall(tag):
        xml.remove(node)
if safe_timings:
    ET.SubElement(xml, 'system-out').text = '\n'.join(safe_timings) + '\n'
if failure is not None:
    # Expected lower-bound failure contains only fixed oracle label and integers.
    if 'Redis retains the accepted 30-second issuance window' not in message:
        failure.set('message', 'Non-oracle failure; raw diagnostic withheld pending classification')
        failure.text = 'Infrastructure/other assertion must be diagnosed before classifying sensitivity.'
        message = failure.get('message')
    else:
        failure.text = '\n'.join((failure.text or '').splitlines()[:8])
safe_xml = scratch / ('NTR01-' + phase + '-safe.xml')
ET.ElementTree(xml).write(safe_xml, encoding='utf-8', xml_declaration=True)
test = root / 'services/auth-service/auth-app/src/test/java/ru/rutcampustrack/auth/integration/WsTicketConcurrencyBoundaryIT.java'
command = json.loads((scratch / ('NTR01-' + phase + '-command.json')).read_text())
identical = hashlib.sha256(test.read_bytes()).hexdigest() == command['test_sha256']
assert identical
result = {'time': datetime.datetime.now(datetime.timezone.utc).isoformat(),
          'action': 'NTR01_' + phase + '_terminal', 'phase': phase, 'session': session,
          'native_exit': native_exit, 'tests': xml.attrib, 'failure_message': message,
          'safe_integer_timings': safe_timings, 'raw_xml_sha256': hashlib.sha256(xml_path.read_bytes()).hexdigest(),
          'raw_log_sha256': hashlib.sha256(log_path.read_bytes()).hexdigest(),
          'safe_xml': safe_xml.name, 'safe_xml_sha256': hashlib.sha256(safe_xml.read_bytes()).hexdigest(),
          'test_hash_matches_prelaunch': identical, 'test_sha256': command['test_sha256'],
          'lease': 'NOTIFY3', 'production_TTL_Clock_unchanged': True}
(scratch / ('NTR01-' + phase + '-result.json')).write_text(json.dumps(result, indent=2) + '\n')
with (scratch / 'attempts.ndjson').open('a') as file:
    file.write(json.dumps(result) + '\n')
if phase == 'red':
    restored = (scratch / 'NTR01-restored-target.java').read_bytes()
    test.write_bytes(restored)
    assert hashlib.sha256(restored).hexdigest() == command['restore_target_sha256']
    receipt = {'time': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'action': 'NTR01_exact_test_restore',
               'test_sha256': hashlib.sha256(restored).hexdigest(), 'control_removed': True,
               'other5files_unchanged': all(hashlib.sha256((root / row['path']).read_bytes()).hexdigest() == row['sha256']
                                             for row in command['other5unchanged'])}
    assert receipt['other5files_unchanged']
    (scratch / 'NTR01-restoration.json').write_text(json.dumps(receipt, indent=2) + '\n')
    with (scratch / 'attempts.ndjson').open('a') as file:
        file.write(json.dumps(receipt) + '\n')
print(json.dumps({'phase': phase, 'session': session, 'native_exit': native_exit, 'tests': xml.attrib,
                  'failure_message': message, 'timings': safe_timings}))
