import collections
import datetime
import hashlib
import json
import os
from pathlib import Path
import struct
import zipfile

OWN=Path('/workspace/scratch/rct-validation/current_artifact_review')
SRC=Path('/workspace/scratch/rct-validation/current_client_artifacts')
WT=Path('/workspace/rct-worktrees/client-current-artifacts')

def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  while b:=f.read(65536):h.update(b)
 return h.hexdigest()
def save(n,v):(OWN/n).write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')

observations=[]
for phase in ['boot8','pwa','tma']:
 r=json.loads((SRC/(phase+'-receipt.json')).read_text());group=r['child_pid'];members=[]
 for p in Path('/proc').iterdir():
  if not p.name.isdecimal():continue
  try:
   f=(p/'stat').read_text().rsplit(')',1)[1].split()
   if int(f[2])==group:members.append({'pid':int(p.name),'state':f[0],'ppid':int(f[1]),'pgrp':int(f[2])})
  except (OSError,ValueError,IndexError):pass
 assert r['native_exit']==0 and r['terminal_reason']=='NATIVE_TERMINAL'
 assert not Path('/proc',str(group)).exists()
 assert not [x for x in members if x['state']!='Z']
 observations.append({'phase':phase,'phase_pid':group,'phase_pid_absent':True,'native_exit':0,'current_live_group_members':[],'current_all_group_members':members,'raw_private_log_SHA':r['raw_log_sha256'],'raw_bodies':'NOT_READ','original_group_receipt_scope':'source helper excludes zombies; live-only assertion'})
save('native-source-cleanup-qualification.json',{'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'phases':observations,'no_live_process':True,'all_owned_processes_reaped':not any(x['current_all_group_members'] for x in observations),'qualification':'two npm-descendant PPID1 zombies observed; no kill/reap attempt; original sealed receipts unchanged'})

artifacts=json.loads((SRC/'eight-production-jars.json').read_text())['jars'];critical=[]
for r in artifacts:
 with zipfile.ZipFile(r['jar']) as z:
  checks={}
  if r['service']=='auth':
   name='BOOT-INF/classes/ru/rutcampustrack/auth/event/PasswordChangedEvent$Payload.class'
   b=z.read(name);checks['v2_password_event_identity_keys_present']=all(v in b for v in [b'user_id',b'credentials_version',b'telegram_binding_version'])
   checks['artifact_payload_class_SHA']=hashlib.sha256(b).hexdigest()
  if r['service']=='academic':
   checks['dedicated_bot_service_class_present']='BOOT-INF/classes/ru/rutcampustrack/academic/botcredentials/BotCredentialsService.class' in z.namelist()
   checks['Auth_TEST_artifact_absent_from_production_libs']=not any(n.startswith('BOOT-INF/lib/auth-app-') for n in z.namelist())
  if checks:assert all(v for k,v in checks.items() if isinstance(v,bool));critical.append({'service':r['service'],'checks':checks})
save('critical-current-production-classes.json',{'scope':'selected actual current classes; no JVM/linker/application run','entries':critical})

files=[SRC/'build-only.py',SRC/'inspect-artifacts.py',SRC/'build-plan.json',SRC/'manifest.json',SRC/'HANDOFF.md',Path('/workspace/rct-cloud-setup/run-gradle.py'),Path('/workspace/rct-cloud-setup/jdk21/release')]
files += [WT/n for n in ['build.gradle.kts','tests/e2e/backend-clock/verify-jar-isolation.py','services/shared/shared-web-api/src/main/java/ru/rutcampustrack/shared/web/time/EducationalTime.java','frontends/package.json','frontends/package-lock.json','frontends/pwa-vue/package.json','frontends/tma-vue/package.json','frontends/pwa-vue/vite.config.ts','frontends/tma-vue/vite.config.ts','frontends/pwa-vue/tsconfig.json','frontends/tma-vue/tsconfig.json','frontends/pwa-vue/src/App.vue','frontends/tma-vue/src/App.vue']]
save('critical-source-identities.json',[{'path':str(p),'sha256':sha(p),'bytes':p.stat().st_size,'read_scope':'opened runner/inspector/build/clock/production source or selected critical fragments'} for p in files])

findings=[{
 'id':'AR-C01','priority':'P2','kind':'cleanup evidence/source runner, not artifact content defect',
 'path':str(SRC/'build-only.py'),'line':62,
 'observation':'group_members excludes stateZ. Actual source build phasegroups PWA201350 and TMA201403 retain PIDs201385/201430 in Z withPPID1; boot group201154 empty; no live phase process/group member.',
 'impact':'native0/build identity valid, but empty-group cleanup supports live-only and cannot establish all-owned child reaping. HANDOFF/root allgroups-empty wording is too broad; repeating this runner can accumulate own zombies.',
 'minimum_correction':'Preserve original24. Add exact immutable qualification receipt/root state; any future reuse of build runner needs an owned-child reap strategy/source correction and adequate harmless control under a separate grant. Do not rebuild valid artifacts, kill PID1/foreign resources or invent successful reaping.',
 },{
 'id':'AR-P01','priority':'P3','kind':'provenance wording correction',
 'path':str(SRC/'HANDOFF.md'),'line':20,
 'observation':'HANDOFF calls build host Debian OpenJDK, but exact run-gradle wrapper setsJAVA_HOME=/workspace/rct-cloud-setup/jdk21 and release/recordedinspection identifyEclipseAdoptiumTemurin21.0.12.1+1/libcgnu. Node24.19 recorded.',
 'minimum_correction':'Retain immutable original; qualify actual buildTemurinLinuxGNU versus proposed runtimeDebianOpenJDK and productionTemurinAlpine, recording exact actual future runtimeJDK separately.'
 }]
save('findings.json',findings)
save('staging-proof-obligations.json',{
 'stage':'NOT_RUN_NO_GRANT','authority':'current-artifact-review packet explicitly requires NEW public stagedfiles644/dirs755; source ZIPclasses600 real',
 'source_payload':{'files':10834,'mode600_files':10029,'mode644_files':805,'logical_distinct_SHA_source_mode':166383274,'rounded_estimate':172953600},
 'NEW_public_modes':{'regular_compiled_payload_files':'0o644','directories':'0o755','private_keys_env':'outsidepublicpayload retain private rules; do not read/chmod original keys'},
 'identity':'Exactly source memberbytes/SHA/pathset mapped into full four layerCONTENTS union, not sourceZIPmode equality for NEW stage. No extras/symlinks/nonregular/path traversal/ambiguouscollisions. Original JAR/modes/manifests unchanged.',
 'dedup':'NEWpublicsameSHA+sameeffective644+size only, immutable/COW roots. Never hardlink staged public file to originalprivate600 inode thenchmod. Source-original mode estimate may overcount equal bytes mapped to same644; reserve remains conservative, not measured allocation.',
 'reserve':'192MiB stage estimate includes unknown directories/metadata; actual measured inode/blockallocation and diskfloor require separate grant',
 'native_renderer':'complete /app read-only currentunion masks all oldpayload; originalnativeimage USER/entrypoint/JRE/tools/OS/fonts retained. Actual image user readability/tmp/native conversion/process cleanup/realRPC/TLS negative and fiveformat/client chains all pending.',
 'runtime_capacity':'author conservative8277277457 required vs7326609408free deficit950668049. Snapshot not current capacity approval; remeasure sharedCPU4/RAM/free. Frozen494source303800320 duplicatecandidate overlaps smallerplans; no dedup/grant/recoverydelta inferred.',
 'limits':'hostsharedUID/privatekeyOSisolation, runtimeJDKdifference and missingperprocesshardcgroups remain; no productioncontainer/client/runtime PASS'})
save('scope-verdict.json',{'verdict':'CHANGES_REQUESTED_SCOPED_CLEANUP_QUALIFICATION','artifact_build_subscope':'APPROVE_SCOPED_BUILD_AND_SOURCE with exact producer/native/source/artifact qualifications','producer':'908fc8c27be82e4a0d7db7bf4d7b2c4a62225916','root_published_input':'731d45e5c890e62976a69192dce62e9b5f534c6c','source_build_product_defect_found':False,'findings':findings,'runtime':'NOT_RUN','client_acceptance':'NOT_RUN','stage':'NOT_RUN','children':0,'source_shared_writes':0,'actual_metadata':'UNKNOWN','requested_model':'gpt-6.1-sol','requested_effort':'high'})

print(json.dumps({'verdict':'CHANGES_REQUESTED_SCOPED_CLEANUP_QUALIFICATION','artifacts':'APPROVE_SCOPED_BUILD_AND_SOURCE','P2':'AR-C01','P3':'AR-P01','live_members':0,'owned_zombies':sum(len(x['current_all_group_members']) for x in observations),'runtime':'NOT_RUN'}))
