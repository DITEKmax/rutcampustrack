"""DEDUP1: exact sealed rows only; no subprocess, service, or broad cleanup."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import signal
import stat
import sys

BASE = Path('/workspace/scratch/rct-validation')
OUT = BASE / 'physical_dedup1'
PLAN = BASE / 'host_capacity_correction'
ALIASES = BASE / 'capacity_premutation_aliases'
FENCE = Path('/workspace/rutcampustrack/docs/validation/cloud-20261011/receipts/exact-path-freeze.json')
SEALS = {
    'host_runtime_prepare/manifest.json': 'fac7de9671ce6338b0e28ddd8745918bb04cd2816cd708861685e2d4f3f521cf',
    'host_runtime_prepare/renderer-addendum-manifest.json': '8159e470b37267bb2e2142e5e772eb0b925e83b50f82a68cfb0842ba28389287',
    'host_runtime_prepare/guard-corrections/manifest.json': '04e6355b92c0cd24a6c6b574bde5099de2a26a4b7d87caaf08c9c8c71f4044ba',
    'current_client_artifacts/manifest.json': '840492d38bfd204fe37c9bb46e89d3a3fdbc7957ad31ad1e9ca6ca058523ea7f',
    'host_capacity_plan/manifest.json': 'be3853df8f62a968c9e0e0171f70e4fa0b4435bcddce5b2b6e93b8c30f756a6b',
    'current_artifact_corrections/manifest.json': '486729fbf44eb6770a7504686831f614e15a2d949255a932c2b830b0da18a0a8',
    'host_capacity_correction/manifest.json': '4c2702f30182f291919b79d0d2b55bb8f917b94bd983f59f96bf7770b6485dcf',
    'current_artifact_corrections_v2/manifest.json': 'ff9f2c4121641cd7b530a9eb57919e83051492a666328ed9f649d91e2004c968',
    'host_capacity_correction_review/manifest.json': 'ed6bf081b4f98ed30bf3d48730a7b57a4ba690a30aba19121fefc495741667b7',
}
stop_requested = False
interrupts = []


def utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def save(name, value):
    with (OUT / name).open('w', encoding='utf-8') as f:
        json.dump(value, f, indent=2, ensure_ascii=False)
        f.write('\n')
        f.flush()
        os.fsync(f.fileno())


def guard_path(path):
    p = Path(path)
    if not p.is_absolute() or '..' in p.parts or str(p) != path:
        raise RuntimeError('Noncanonical path')
    for parent in reversed(p.parents):
        s = os.lstat(parent)
        if not stat.S_ISDIR(s.st_mode):
            raise RuntimeError('Non-directory/symlink ancestor: ' + str(parent))
    return p


def metadata(path):
    s = os.lstat(path)
    if not stat.S_ISREG(s.st_mode):
        raise RuntimeError('Nonregular/symlink path: ' + str(path))
    return {'path': str(path), 'device': s.st_dev, 'inode': s.st_ino,
            'nlink': s.st_nlink, 'bytes': s.st_size, 'allocated_bytes': s.st_blocks * 512,
            'mode': oct(stat.S_IMODE(s.st_mode)), 'uid': s.st_uid, 'gid': s.st_gid,
            'mtime_ns': s.st_mtime_ns, 'ctime_ns': s.st_ctime_ns}


def digest(path):
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW)
    try:
        before = os.fstat(fd)
        if not stat.S_ISREG(before.st_mode):
            raise RuntimeError('Hash nonregular file')
        h = hashlib.sha256()
        while chunk := os.read(fd, 262144):
            h.update(chunk)
        after = os.fstat(fd)
        fields = ('st_dev', 'st_ino', 'st_size', 'st_mode', 'st_uid', 'st_gid', 'st_mtime_ns', 'st_ctime_ns', 'st_nlink')
        if any(getattr(before, k) != getattr(after, k) for k in fields):
            raise RuntimeError('Identity changed while streaming hash: ' + str(path))
        current = os.lstat(path)
        if (current.st_dev, current.st_ino) != (after.st_dev, after.st_ino):
            raise RuntimeError('Hash path identity replaced: ' + str(path))
        return h.hexdigest()
    finally:
        os.close(fd)


def assert_meta(path, expected, fields=None, hash_check=True):
    guard_path(str(path))
    actual = metadata(path)
    fields = fields or ('device', 'inode', 'nlink', 'bytes', 'allocated_bytes', 'mode', 'uid', 'gid', 'mtime_ns', 'ctime_ns')
    for k in fields:
        if actual[k] != expected[k]:
            raise RuntimeError('Metadata changed ' + k + ': ' + str(path))
    if hash_check and digest(path) != expected['sha256']:
        raise RuntimeError('SHA changed: ' + str(path))
    return actual


def resources():
    s = os.statvfs('/workspace')
    current = int(Path('/sys/fs/cgroup/memory.current').read_text())
    maximum = int(Path('/sys/fs/cgroup/memory.max').read_text())
    value = {'utc': utc(), 'free_available_bytes': s.f_bavail * s.f_frsize,
             'memory_current': current, 'memory_max': maximum, 'pid': os.getpid()}
    if value['free_available_bytes'] < 4294967296 or maximum - current < 1073741824:
        raise RuntimeError('Required disk/memory floor unavailable')
    return value


def check_seals():
    checked = []
    for name, expected in SEALS.items():
        p = BASE / name
        if digest(p) != expected:
            raise RuntimeError('Input manifest changed: ' + name)
        m = json.loads(p.read_text())
        files = m.get('safe_files', m.get('files', []))
        symlinks = []
        declared = {r['path'] for r in files}
        for row in files:
            f = Path(row['path'])
            if f.is_symlink():
                # Historical G01's deliberate synthetic symlink is sealed as target
                # bytes. Read only a separately declared safe regular manifest path.
                target = os.readlink(f)
                if target not in declared or Path(target).is_symlink():
                    raise RuntimeError('Unsealed synthetic symlink target')
                symlinks.append({'path': str(f), 'target': target})
                f = Path(target)
            if f.stat().st_size != row['bytes'] or digest(f) != row['sha256']:
                raise RuntimeError('Old sealed receipt changed: ' + str(f))
        checked.append({'manifest': str(p), 'sha256': expected, 'verified_files': len(files), 'historical_synthetic_symlinks': symlinks})
    p = ALIASES / 'manifest.json'
    if digest(p) != 'a84242355d6223fbc2f87cd61b6b6928ce83d8bb476276df308afb8196496116':
        raise RuntimeError('Accepted alias manifest changed')
    m = json.loads(p.read_text())
    for row in m['files']:
        if Path(row['path']).stat().st_size != row['bytes'] or digest(row['path']) != row['sha256']:
            raise RuntimeError('Alias seal changed')
    checked.append({'manifest': str(p), 'sha256': digest(p), 'verified_files': len(m['files'])})
    return checked


def check_artifacts():
    current = json.loads((BASE / 'current_client_artifacts/eight-production-jars.json').read_text())['jars']
    old = json.loads(Path('/workspace/rutcampustrack/docs/validation/cloud-20261011/receipts/owned-old-java-image-retirement-plan.json').read_text())
    old_rows = old['rows']
    rows = [{'path': r['jar'], 'sha256': r['sha256'], 'bytes': r['bytes'], 'mode': r['mode']} for r in current]
    for r in old_rows:
        for path in r['retained_exact_jar_paths']:
            rows.append({'path': path, 'sha256': r['jar_sha256']})
    seen = {}
    for r in rows:
        if r['path'] in seen:
            continue
        if digest(r['path']) != r['sha256']:
            raise RuntimeError('Protected JAR changed')
        m = metadata(r['path'])
        if ('bytes' in r and r['bytes'] != m['bytes']) or ('mode' in r and r['mode'] != m['mode']):
            raise RuntimeError('Protected JAR metadata changed')
        seen[r['path']] = dict(m, sha256=r['sha256'])
    vue = json.loads((BASE / 'current_client_artifacts/production-vue-bundles.json').read_text())['bundles']
    count = 0
    for b in vue:
        for r in b['files']:
            p = Path(b['directory']) / r['path']
            m = metadata(p)
            if digest(p) != r['sha256'] or m['bytes'] != r['bytes'] or m['mode'] != r['mode']:
                raise RuntimeError('Protected Vue changed')
            count += 1
    return {'jars': list(seen.values()), 'verified_vue_files': count}


def signal_stop(signum, _frame):
    global stop_requested
    stop_requested = True
    interrupts.append(signum)


def main():
    signal.signal(signal.SIGINT, signal_stop)
    signal.signal(signal.SIGTERM, signal_stop)
    start = resources()
    save('CURRENT.json', {'status': 'PREFLIGHT', 'pid': os.getpid(), 'start': start, 'children': 0})
    seals = check_seals()
    fence = json.loads(FENCE.read_text())
    if digest(FENCE) != '6d4cef1bce6b7ee9d6ddae95a9b087e6b59af00c464572c2ecd65fc47ad61f50':
        raise RuntimeError('Root exact freeze receipt changed')
    registry_path = Path(fence['registry_original'])
    if fence['status'] != 'EXACT_PATH_FREEZE_ESTABLISHED_BY_ROOT' or digest(registry_path) != fence['registry_sha256']:
        raise RuntimeError('Root exact freeze not established or changed')
    registry = json.loads(registry_path.read_text())['paths']
    aliases = json.loads((ALIASES / 'reference-aliases.json').read_text())
    rows = []
    for entry in json.loads((PLAN / 'manifest.json').read_text())['files']:
        if Path(entry['path']).name.endswith('-strict-candidates.json'):
            rows.extend(json.loads(Path(entry['path']).read_text()))
    if len(rows) != 10831 or len(registry) != 12153 or len(aliases) != 714:
        raise RuntimeError('Exact granted counts differ')
    paths = {r['candidate']['path'] for r in rows}
    alias_paths = {a['path'] for group in aliases for a in group['aliases']}
    if len(paths) != 10831 or len(alias_paths) != 1322 or paths & alias_paths or paths | alias_paths != {r['path'] for r in registry}:
        raise RuntimeError('Exact freeze/selection/alias mismatch')
    if len({(r['candidate']['device'], r['candidate']['inode']) for r in rows}) != 10831:
        raise RuntimeError('Candidates not globally unique')
    heads = json.loads((OUT / 'heads-before.json').read_text())
    if not all(r['head_equal'] and r['tracked_clean'] for r in heads['rows']):
        raise RuntimeError('HEAD/status preflight failed')
    ledger = {}
    for group in aliases:
        if group['baseline_nlink'] != len(group['aliases']) or group['unaccounted_links'] != 0:
            raise RuntimeError('Unowned reference links')
        key = (group['device'], group['inode'])
        for a in group['aliases']:
            assert_meta(a['path'], dict(a, sha256=group['reference_sha256_prior_verified']))
        ref = dict(group['aliases'][0], sha256=group['reference_sha256_prior_verified'])
        ledger[key] = {'reference': ref, 'baseline_nlink': group['baseline_nlink'], 'success': 0, 'pending': 0,
                       'last_own_ctime_ns': ref['ctime_ns'], 'aliases': [a['path'] for a in group['aliases']]}
    for i, row in enumerate(rows):
        c, r = row['candidate'], row['reference']
        if c['nlink'] != 1 or (c['device'], c['inode']) in ledger:
            raise RuntimeError('Candidate shares inode or unknown links')
        assert_meta(c['path'], c)
        assert_meta(r['path'], r)
        if any(c[k] != r[k] for k in ('device', 'bytes', 'mode', 'uid', 'gid', 'sha256')):
            raise RuntimeError('Pair content/ownership mismatch')
        if i % 1000 == 0:
            print(json.dumps({'status': 'PREFLIGHT', 'checked': i, 'total': len(rows)}), flush=True)
    artifacts = check_artifacts()
    before = resources()
    save('preflight.json', {'utc': utc(), 'status': 'PASS', 'fence_sha256': digest(FENCE), 'registry_sha256': digest(registry_path),
                            'input_seals': seals, 'candidates': len(rows), 'aliases': len(alias_paths), 'references': len(ledger),
                            'candidate_unique_allocated_bytes': sum(r['candidate']['allocated_bytes'] for r in rows),
                            'heads': heads, 'resources': before, 'protected_artifacts': artifacts})
    journal = (OUT / 'journal.ndjson').open('x', encoding='utf-8')

    def log(value):
        journal.write(json.dumps(dict(utc=utc(), **value), ensure_ascii=False, separators=(',', ':')) + '\n')
        journal.flush()
        os.fsync(journal.fileno())

    completed = []
    error = None
    pending_path = None
    batches = [before]
    try:
        for i, row in enumerate(rows):
            if stop_requested:
                break
            c, r = row['candidate'], row['reference']
            key = (r['device'], r['inode'])
            state = ledger[key]
            expected = dict(r, nlink=state['baseline_nlink'] + state['success'], ctime_ns=state['last_own_ctime_ns'])
            assert_meta(c['path'], c)
            assert_meta(r['path'], expected)
            temp = str(Path(c['path']).parent / ('.rct-dedup1-' + str(i).zfill(5) + '-ced755.tmp'))
            if os.path.lexists(temp):
                raise RuntimeError('Unique owned temp already exists')
            log({'event': 'INTENT', 'row': i, 'candidate': c['path'], 'reference': r['path'], 'temp': temp,
                 'old_inode': c['inode'], 'old_mtime_ns': c['mtime_ns'], 'expected_nlink': expected['nlink'],
                 'last_own_ctime_ns': expected['ctime_ns']})
            cfd = os.open(Path(c['path']).parent, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
            rfd = os.open(Path(r['path']).parent, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
            try:
                os.link(Path(r['path']).name, Path(temp).name, src_dir_fd=rfd, dst_dir_fd=cfd, follow_symlinks=False)
                pending_path = temp
                state['pending'] = 1
                linked = metadata(r['path'])
                expected['nlink'] += 1
                expected['ctime_ns'] = linked['ctime_ns']
                assert_meta(r['path'], expected)
                assert_meta(temp, dict(expected, path=temp))
                state['last_own_ctime_ns'] = linked['ctime_ns']
                log({'event': 'LINKED', 'row': i, 'nlink': linked['nlink'], 'ctime_ns': linked['ctime_ns']})
                # Candidate remained its exact old inode while the temp was verified.
                assert_meta(c['path'], c)
                os.replace(Path(temp).name, Path(c['path']).name, src_dir_fd=cfd, dst_dir_fd=cfd)
                pending_path = None
                state['pending'] = 0
                state['success'] += 1
                completed.append(i)
                after_ref = metadata(r['path'])
                state['last_own_ctime_ns'] = after_ref['ctime_ns']
                log({'event': 'REPLACED', 'row': i, 'nlink': after_ref['nlink'], 'ctime_ns': after_ref['ctime_ns']})
                expected['ctime_ns'] = after_ref['ctime_ns']
                assert_meta(c['path'], dict(expected, path=c['path']))
                assert_meta(r['path'], expected)
                if os.path.lexists(temp):
                    raise RuntimeError('Consumed temp still present')
                os.fsync(cfd)
                log({'event': 'VERIFIED', 'row': i, 'candidate_inode': after_ref['inode'], 'mtime_ns': after_ref['mtime_ns']})
            finally:
                os.close(cfd)
                os.close(rfd)
            if (i + 1) % 250 == 0:
                batch = dict(resources(), completed=len(completed))
                batches.append(batch)
                log({'event': 'BATCH', **batch})
                save('CURRENT.json', {'status': 'MUTATING', 'pid': os.getpid(), 'completed': len(completed), 'total': len(rows), 'batch': batch})
                print(json.dumps({'status': 'MUTATING', 'completed': len(completed), 'free': batch['free_available_bytes']}), flush=True)
    except Exception as exc:
        error = {'type': type(exc).__name__, 'message': str(exc), 'row': i}
        log({'event': 'ERROR', **error})
        if pending_path is not None:
            # Remove only this invocation's exact pending hardlink, after identity proof.
            actual = metadata(pending_path)
            if (actual['device'], actual['inode']) == key and actual['nlink'] == state['baseline_nlink'] + state['success'] + 1 and digest(pending_path) == r['sha256']:
                os.unlink(pending_path)
                state['pending'] = 0
                state['last_own_ctime_ns'] = metadata(r['path'])['ctime_ns']
                log({'event': 'EXACT_PENDING_TEMP_SETTLED', 'temp': pending_path})
                pending_path = None
    finally:
        journal.close()
        save('link-ledger.json', list(ledger.values()))
        save('batches.json', batches)
    verification_error = None
    try:
        completed_set = set(completed)
        for i, row in enumerate(rows):
            c, r = row['candidate'], row['reference']
            state = ledger[(r['device'], r['inode'])]
            expected = dict(r, nlink=state['baseline_nlink'] + state['success'] + state['pending'], ctime_ns=state['last_own_ctime_ns'])
            assert_meta(c['path'], dict(expected, path=c['path']) if i in completed_set else c)
        for state in ledger.values():
            expected = dict(state['reference'], nlink=state['baseline_nlink'] + state['success'] + state['pending'], ctime_ns=state['last_own_ctime_ns'])
            for alias in state['aliases']:
                assert_meta(alias, dict(expected, path=alias))
        after_seals = check_seals()
        after_artifacts = check_artifacts()
        if after_artifacts != artifacts or after_seals != seals:
            raise RuntimeError('Protected receipt/artifact identity differs')
    except Exception as exc:
        verification_error = {'type': type(exc).__name__, 'message': str(exc)}
    after = resources()
    passed = len(completed) == len(rows) and not error and not verification_error and pending_path is None
    result = {'utc': utc(), 'status': 'PASS' if passed else 'HONEST_PARTIAL_OR_ERROR', 'pid': os.getpid(), 'children': 0,
              'candidate_count': len(rows), 'actual_replacements': len(completed), 'pending_temp': pending_path,
              'interrupts': interrupts, 'error': error, 'verification_error': verification_error,
              'before': before, 'after': after, 'observed_net_free_gain_bytes': after['free_available_bytes'] - before['free_available_bytes'],
              'original_unique_candidate_allocated_bytes': sum(rows[i]['candidate']['allocated_bytes'] for i in completed),
              'net_free_qualification': 'Observed VFS net difference includes own receipts and unrelated concurrent Root documentation writes; not a per-file allocator attribution.',
              'candidate_metadata_changes': 'inode/nlink/mtime/ctime intentionally become reference values; SHA/size/mode/UID/GID/path preserved',
              'reference_mtime_preserved': verification_error is None, 'all_known_alias_nlink_exact': verification_error is None,
              'future_rule': 'All exact12153 paths immutable; atomic COW + identity journal before ANY later edit/build/formatter/chmod.',
              'runtime_stage_keys_apps_containers': 'NOT_RUN'}
    save('RESULT.json', result)
    save('CURRENT.json', {'status': result['status'], 'pid': os.getpid(), 'completed': len(completed), 'terminal_pending_native_exit': True})
    print(json.dumps(result), flush=True)
    return 0 if passed else 1


if __name__ == '__main__':
    try:
        sys.exit(main())
    except Exception as exc:
        save('preflight-error.json', {'utc': utc(), 'type': type(exc).__name__, 'message': str(exc), 'no_more_mutations': True})
        print(json.dumps({'status': 'ERROR', 'type': type(exc).__name__, 'message': str(exc)}), flush=True)
        sys.exit(1)
