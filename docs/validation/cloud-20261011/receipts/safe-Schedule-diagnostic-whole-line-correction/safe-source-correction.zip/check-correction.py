from pathlib import Path
import ast, difflib, hashlib, importlib.util, json, sys
from xml.etree import ElementTree

sys.dont_write_bytecode=True
ORIG=Path('/workspace/scratch/rct-validation/schedule_safe_fail_diagnostics_source')
OLD=Path('/tmp/rct-schedule-safe-diagnostic-db177')
NEW=Path('/tmp/rct-schedule-safe-diagnostic-line-correction-db177')
OWN=Path('/workspace/scratch/rct-validation/schedule_safe_fail_diagnostics_line_correction')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(ORIG/'manifest.safe.json')=='9cafda102559d0f2b062fc0bfda816611d331121cee8e5c75a3412c761a0d3c9'
assert sha(ORIG/'safe-source-package.zip')=='1628de2fef1f4d3eaadcd9444dc3fe75155bb3a1f9301e497d55deb3d68a59b8'
manifest=json.loads((ORIG/'manifest.safe.json').read_text())
for row in manifest['files']:assert sha(Path(row['path']))==row['sha256']
collector='scripts/collect-ci-test-outcomes.py'; tests='tests/harness/test_ci_test_outcomes.py'
paths=[row['repo_path'] for row in manifest['files'] if row['kind']=='ASSIGNED_SOURCE']
assert {p for p in paths if (OLD/p).read_bytes()!=(NEW/p).read_bytes()}=={collector,tests}
def parse(p):return ast.parse(p.read_text())
a=parse(OLD/collector);b=parse(NEW/collector)
node_a=next(n for n in a.body if isinstance(n,ast.FunctionDef) and n.name=='cap_failure_diagnostic')
node_b=next(n for n in b.body if isinstance(n,ast.FunctionDef) and n.name=='cap_failure_diagnostic')
b.body[b.body.index(node_b)]=node_a
assert ast.dump(a)==ast.dump(b),'UNRELATED_COLLECTOR_AST_CHANGED'
a=parse(OLD/tests);b=parse(NEW/tests)
cls=next(n for n in b.body if isinstance(n,ast.ClassDef) and n.name=='SafeOutcomesControl')
new_names={'test_cap_marker_cutoff_never_attests_a_truncated_original_line','test_cap_marker_whole_bounded_lines_eof_newline_and_boundary_remain_valid'}
assert sum(isinstance(n,ast.FunctionDef) and n.name in new_names for n in cls.body)==2
cls.body=[n for n in cls.body if not(isinstance(n,ast.FunctionDef) and n.name in new_names)]
assert ast.dump(a)==ast.dump(b),'EXISTING_PRIVACY_CONTROLS_CHANGED'
def module(path,name):
 spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
old=module(OLD/collector,'old_collector');new=module(NEW/collector,'new_collector')
assert old.CAP_MARKER.pattern==new.CAP_MARKER.pattern and old.CAP_SQL_STATES==new.CAP_SQL_STATES
good='CAP_FUTURE_DIAGNOSTIC_V1 class=AssertionError sqlState=NONE barrier=TIMED_OUT'
case=ElementTree.Element('testcase');failure=ElementTree.SubElement(case,'failure');failure.text=' '*(2048-len(good))+good+'SYNTHETIC_PRIVATE_TAIL_DO_NOT_OUTPUT'
before=old.cap_failure_diagnostic(case);after=new.cap_failure_diagnostic(case)
assert before['state']=='CLOSED_MARKER' and before['stage']=='AWAIT_BARRIER'
assert after=={'state':'ABSENT_OR_UNRECOGNIZED','stage':'UNKNOWN'}
assert 'SYNTHETIC_PRIVATE_TAIL_DO_NOT_OUTPUT' not in json.dumps([before,after])
diff=''.join(''.join(difflib.unified_diff((OLD/p).read_text().splitlines(keepends=True),(NEW/p).read_text().splitlines(keepends=True),fromfile='a/'+p,tofile='b/'+p)) for p in [collector,tests])
(OWN/'correction-vs-original.patch').write_text(diff);(OWN/'correction-vs-original.patch').chmod(0o600)
size=sum(p.stat().st_size for p in NEW.rglob('*') if p.is_file());assert size<256*1024**2
report={'verdict':'AUTHOR_NARROW_SOURCE_CORRECTED_PENDING_INDEPENDENT_RECHECK','original13files_and2seals_exact':True,
 'changed_paths':[collector,tests],'original_Java_workflow_source_exact':True,
 'collector_outside_one_function_AST_exact':True,'all18original_controls_AST_exact':True,'whitelists_exact':True,
 'selected_actual_old_function_red':before,'selected_actual_new_function_green':after,
 'cutoff_denials':5,'wholeline_positive_controls':6,'Python_controls':20,'failed':0,
 'Ruff017_format_check_exit':0,'bounded_text_window_characters':2049,'maximum_original_lines':3,
 'source_tree_bytes':size,'source_cap_bytes':256*1024**2,'raw_tail_or_private_values_included':False,
 'Java_native_build_runtime':'NOT_RUN','historical_cause':'UNKNOWN','requested_model_effort':'gpt-6.1-sol/high','actual_model_effort':'UNKNOWN'}
(OWN/'correction-checks.safe.json').write_text(json.dumps(report,indent=2)+'\n');(OWN/'correction-checks.safe.json').chmod(0o600)
print(json.dumps({'old_red':'FALSE_CLOSED_MARKER','new':'UNKNOWN','old13immutable':True,'changed_functions':1,'new_tests':2,'runtime':False}))
