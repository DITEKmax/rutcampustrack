#!/usr/bin/env python3
"""Bounded own artifact build; no product runtime, raw output publication or daemon."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import time

OWN = Path('/workspace/scratch/rct-validation/current_client_artifacts')
WT = Path('/workspace/rct-worktrees/client-current-artifacts')
REVISION = '908fc8c27be82e4a0d7db7bf4d7b2c4a62225916'
stop_requested = False


def interrupted(signum, frame):
    global stop_requested
    stop_requested = True


def free():
    value = os.statvfs('/workspace')
    return value.f_bavail * value.f_frsize


def allocated(path):
    return int(subprocess.check_output(['du', '-s', '--block-size=1', str(path)]).split()[0])


def current_source():
    expected = json.loads((OWN / 'source-inputs-before.json').read_text())
    for row in expected['tracked']:
        path = WT / row['path']
        with path.open('rb') as stream:
            actual = hashlib.file_digest(stream, 'sha256').hexdigest()
        if actual != row['sha256']:
            raise ValueError('source identity')
    revision = subprocess.check_output(['git', '-C', str(WT), 'rev-parse', 'HEAD'], text=True).strip()
    if revision != REVISION:
        raise ValueError('revision')


def resources(initial_free, initial_allocated):
    remaining = free()
    cg = Path('/sys/fs/cgroup')
    used = int((cg / 'memory.current').read_text())
    maximum = int((cg / 'memory.max').read_text())
    return {'free_bytes': remaining, 'shared_memory_current': used,
            'shared_memory_max': maximum,
            'conservative_new_scope_bytes': initial_allocated + max(0, initial_free - remaining)}


def group_members(group):
    found = []
    for path in Path('/proc').iterdir():
        if not path.name.isdecimal():
            continue
        try:
            fields = (path / 'stat').read_text().rsplit(')', 1)[1].split()
            if int(fields[2]) == group and fields[0] != 'Z':
                found.append(int(path.name))
        except (OSError, ValueError, IndexError):
            pass
    return found


def run_phase(phase, plan, initial_free, initial_allocated):
    current_source()
    env = {'PATH': '/opt/codex/runtimes/codex-primary-runtime/dependencies/node/bin:/usr/local/bin:/usr/bin:/bin',
           'LANG': 'C.UTF-8', 'LC_ALL': 'C.UTF-8', 'CI': 'true', 'FORCE_COLOR': '0'}
    # Selected platform proxy/public CA only; no parent Java/Spring/credential copy.
    for name in ['HTTP_PROXY', 'HTTPS_PROXY', 'NO_PROXY', 'SSL_CERT_FILE', 'SSL_CERT_DIR']:
        if name in os.environ:
            env[name] = os.environ[name]
    env.update(phase['public_env'])
    before = resources(initial_free, initial_allocated)
    if (before['free_bytes'] < plan['floor_bytes']
            or before['shared_memory_max'] - before['shared_memory_current'] < plan['reserve_bytes']
            or before['conservative_new_scope_bytes'] > plan['allocation_limit']):
        raise ValueError('prelaunch budget')
    log_path = OWN / (phase['id'] + '.private.log')
    descriptor = os.open(log_path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    receipt = {'phase': phase['id'], 'revision': REVISION, 'cwd': phase['cwd'],
               'argv': phase['argv'], 'started_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
               'state': 'RUNNING', 'resource_before': before, 'raw_log_private_only': True}
    child = None
    reason = 'NATIVE_TERMINAL'
    started = time.monotonic()
    try:
        with os.fdopen(descriptor, 'wb') as log:
            child = subprocess.Popen(phase['argv'], cwd=phase['cwd'], env=env,
                                     stdin=subprocess.DEVNULL, stdout=log, stderr=subprocess.STDOUT,
                                     start_new_session=True)
            receipt['child_pid'] = child.pid
            (OWN / 'CURRENT.json').write_text(json.dumps(receipt, indent=2) + '\n')
            print(json.dumps({'phase': phase['id'], 'state': 'STARTED', 'pid': child.pid}), flush=True)
            while child.poll() is None:
                snapshot = resources(initial_free, initial_allocated)
                receipt['latest_resources'] = snapshot
                (OWN / 'CURRENT.json').write_text(json.dumps(receipt, indent=2) + '\n')
                if stop_requested:
                    reason = 'STOP_REQUEST'
                    break
                if snapshot['free_bytes'] < plan['floor_bytes']:
                    reason = 'DISK_FLOOR'
                    break
                if snapshot['conservative_new_scope_bytes'] > plan['allocation_limit']:
                    reason = 'ALLOCATION_BUDGET'
                    break
                if snapshot['shared_memory_max'] - snapshot['shared_memory_current'] < plan['reserve_bytes']:
                    reason = 'SHARED_MEMORY_RESERVE'
                    break
                if time.monotonic() - started > 1800:
                    reason = 'BOUNDED_DEADLINE'
                    break
                time.sleep(2)
    finally:
        if child is not None:
            if child.poll() is None:
                os.killpg(child.pid, signal.SIGTERM)
                try:
                    child.wait(timeout=20)
                except subprocess.TimeoutExpired:
                    os.killpg(child.pid, signal.SIGKILL)
                    child.wait(timeout=10)
            receipt.update({'state': 'TERMINAL', 'native_exit': child.returncode,
                            'terminal_reason': reason, 'group_members_after': group_members(child.pid),
                            'ended_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
                            'resource_after': resources(initial_free, initial_allocated),
                            'own_WT_allocated_bytes': allocated(WT), 'own_scratch_allocated_bytes': allocated(OWN)})
            with log_path.open('rb') as stream:
                receipt['raw_log_sha256'] = hashlib.file_digest(stream, 'sha256').hexdigest()
            current_source()
            receipt['all7350_tracked_source_hashes_unchanged'] = True
            (OWN / (phase['id'] + '-receipt.json')).write_text(json.dumps(receipt, indent=2) + '\n')
            (OWN / 'CURRENT.json').write_text(json.dumps(receipt, indent=2) + '\n')
            print(json.dumps({'phase': phase['id'], 'state': 'TERMINAL', 'native_exit': child.returncode,
                              'reason': reason, 'free_bytes': receipt['resource_after']['free_bytes'],
                              'actual_scope_allocated_bytes': receipt['own_WT_allocated_bytes'] + receipt['own_scratch_allocated_bytes']}), flush=True)
    return child is not None and child.returncode == 0 and reason == 'NATIVE_TERMINAL'


if __name__ == '__main__':
    signal.signal(signal.SIGINT, interrupted)
    signal.signal(signal.SIGTERM, interrupted)
    plan = json.loads((OWN / 'build-plan.json').read_text())
    initial_free = free()
    initial_allocated = allocated(WT) + allocated(OWN)
    (OWN / 'build-baseline.json').write_text(json.dumps({'initial_free': initial_free,
                                                       'initial_scope_allocated': initial_allocated}, indent=2) + '\n')
    for phase in plan['phases']:
        if not run_phase(phase, plan, initial_free, initial_allocated):
            raise SystemExit(2)
