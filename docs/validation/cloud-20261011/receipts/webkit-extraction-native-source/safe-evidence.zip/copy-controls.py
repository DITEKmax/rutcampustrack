"""Exact selected copier statements with harmless in-memory FD/stream mocks."""
import ast,hashlib,io,json,stat,types
from pathlib import Path
from unittest.mock import patch
P=Path(__file__).parent
source=ast.parse((P/'extract-selected.py').read_text())
main=next(n for n in source.body if isinstance(n,ast.FunctionDef) and n.name=='main')
loop=next(n for n in ast.walk(main) if isinstance(n,ast.For) and isinstance(n.target,ast.Name) and n.target.id=='member' and ast.unparse(n.iter)=='tar')
body=loop.body
start=next(i for i,n in enumerate(body) if isinstance(n,ast.If) and 'member.isreg()' in ast.unparse(n.test))
end=next(i for i,n in enumerate(body) if isinstance(n,ast.Expr) and 'copied.append' in ast.unparse(n))
selected=compile(ast.Module(body=body[start:end+1],type_ignores=[]),'actual selected bounded copier','exec')
checks=[]
class Target(io.BytesIO):
 def __enter__(self):return self
 def __exit__(self,*args):self.final=self.getvalue();return False
 def fileno(self):return 50
for label,payload,size,regular,mode,foreign,nlink,expect in [('exact',b'public',6,True,0o644,False,1,True),('symlink',b'public',6,False,0o644,False,1,False),('wrongmode',b'public',6,True,0o777,False,1,False),('declaredmismatch',b'public',5,True,0o644,False,1,False),('oversizedstream',b'public!',6,True,0o644,False,1,False),('shortstream',b'publ',6,True,0o644,False,1,False),('foreignFD',b'public',6,True,0o644,True,1,False),('aliasedFD',b'public',6,True,0o644,False,2,False)]:
 output=Target();actions=[]
 row={'declared_bytes':6};member=types.SimpleNamespace(isreg=lambda:regular,size=size,mode=mode)
 info=types.SimpleNamespace(st_mode=stat.S_IFREG|0o644,st_uid=999 if foreign else 1000,st_nlink=nlink)
 fake=types.SimpleNamespace(O_WRONLY=1,O_CREAT=2,O_EXCL=4,O_NOFOLLOW=8,O_CLOEXEC=16,open=lambda *a,**k:actions.append('open') or 50,fstat=lambda fd:info,fchmod=lambda fd,mode:actions.append('newFDmode'),close=lambda fd:actions.append('close'),fdopen=lambda fd,mode:output,fsync=lambda fd:actions.append('fsync'))
 ns={'row':row,'member':member,'name':'usr/lib/x86_64-linux-gnu/libsynthetic.so.1','check':lambda:None,'parent_fd':lambda name:40,'os':fake,'Path':Path,'PREFIX':Path('/tmp/synthetic'),'hashlib':hashlib,'tar':types.SimpleNamespace(extractfile=lambda member:io.BytesIO(payload)),'copied':[],'stat':stat,'sha':lambda path:hashlib.sha256(payload).hexdigest()}
 ok=False
 with patch.object(Path,'lstat',lambda self:types.SimpleNamespace(st_mode=stat.S_IFREG|0o644,st_uid=1000,st_nlink=1)):
  try:exec(selected,ns);ok=True
  except RuntimeError:pass
 assert ok==expect,(label,ok)
 if label in ('symlink','wrongmode','declaredmismatch'):assert actions==[]
 if label=='oversizedstream':assert output.getvalue()==b''
 checks.append({'case':label,'expected_accept':expect,'pass':True,'actual_files_private_or_payload_reads':False,'mock_actions':actions})
(P/'copy-controls.safe.json').write_text(json.dumps({'status':'PASS_ACTUAL_SELECTED_COPIER_STREAM_IDENTITY_CONTROLS','count':len(checks),'checks':checks,'only_synthetic_public_bytes_in_memory':True,'actual_extraction_or_native':False},indent=2)+'\n')
print(json.dumps({'selected_copy_controls':len(checks),'actual_extract':False}))
