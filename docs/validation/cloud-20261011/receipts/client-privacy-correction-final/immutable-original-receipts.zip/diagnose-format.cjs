'use strict';
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const ts = require('/workspace/rutcampustrack/frontends/node_modules/typescript/lib/typescript.js');
const own = __dirname;
const root = '/workspace/rutcampustrack';
const hash = (x) => crypto.createHash('sha256').update(x).digest('hex');
const canonical = (source, file) => {
  const ast = ts.createSourceFile(file, source, ts.ScriptTarget.ES2022, true);
  const visit = (node) => {
    const children = [];
    ts.forEachChild(node, (child) => { children.push(visit(child)); });
    return { kind: node.kind, text: ts.isSourceFile(node) ? undefined : node.text, children };
  };
  return { errors: ast.parseDiagnostics.map((x) => x.code), tree: visit(ast) };
};
const difference = (a, b, location = []) => {
  if (!a || !b) return { location, beforeKind: a?.kind ?? null, afterKind: b?.kind ?? null, sameText: a?.text === b?.text };
  if (a.kind !== b.kind || a.text !== b.text || a.children.length !== b.children.length)
    return { location, beforeKind: a.kind, afterKind: b.kind, beforeKindName: ts.SyntaxKind[a.kind], afterKindName: ts.SyntaxKind[b.kind], sameText: a.text === b.text, beforeChildren: a.children.length, afterChildren: b.children.length };
  for (let i = 0; i < a.children.length; i++) {
    const found = difference(a.children[i], b.children[i], [...location, i]);
    if (found) return found;
  }
  return null;
};
const comments = (text) => {
  const scanner = ts.createScanner(ts.ScriptTarget.ES2022, false, ts.LanguageVariant.Standard, text);
  const result = [];
  for (let kind = scanner.scan(); kind !== ts.SyntaxKind.EndOfFileToken; kind = scanner.scan())
    if (kind === ts.SyntaxKind.SingleLineCommentTrivia || kind === ts.SyntaxKind.MultiLineCommentTrivia)
      result.push(scanner.getTokenText());
  return JSON.stringify(result);
};
(async () => {
  const prettier = await import('/workspace/rct-worktrees/client-current-artifacts/frontends/node_modules/prettier/index.mjs');
  const rows = [];
  for (const { path: relative, sha256 } of JSON.parse(fs.readFileSync(path.join(own, 'root-node-correction-grant-02.json'))).source_hashes) {
    const before = fs.readFileSync(path.join(own, 'before-grant02', relative), 'utf8');
    if (hash(before) !== sha256) throw new Error('Original hash changed');
    const logical = path.join(root, relative);
    const config = await prettier.resolveConfig(logical);
    const after = await prettier.format(before, { ...config, filepath: logical });
    const a = canonical(before, relative); const b = canonical(after, relative);
    const options = { target: ts.ScriptTarget.ES2022, module: ts.ModuleKind.CommonJS, removeComments: true };
    const oldJS = ts.transpileModule(before, { compilerOptions: options, fileName: relative }).outputText;
    const newJS = ts.transpileModule(after, { compilerOptions: options, fileName: relative }).outputText;
    rows.push({ path: relative, originalHashMatched: true, beforeSha256: sha256, afterSha256: hash(after), parseErrorCodesBefore: a.errors, parseErrorCodesAfter: b.errors, firstCanonicalDifference: difference(a.tree, b.tree), commonJsEmissionEqual: oldJS === newJS, commonJsBeforeSha256: hash(oldJS), commonJsAfterSha256: hash(newJS), commentsEqual: comments(before) === comments(after) });
  }
  fs.writeFileSync(path.join(own, 'format-diagnostic.safe.json'), JSON.stringify({ state: 'READ_ONLY_FORMAT_DIAGNOSIS', sourceChanged: false, tsVersion: ts.version, prettierVersion: prettier.version, rows }, null, 2) + '\n');
})().catch(() => { fs.writeFileSync(path.join(own, 'format-diagnostic.safe.json'), JSON.stringify({ state: 'DIAGNOSTIC_FAILED', rawErrorSuppressed: true }) + '\n'); process.exit(1); });
