"""Read-only identity verification of previously sealed public build inputs."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import stat

BASE = Path('/workspace/scratch/rct-validation')
OUT = BASE / 'physical_dedup1'


def sha(path):
    h = hashlib.sha256()
    with open(path, 'rb') as f:
        while chunk := f.read(262144):
            h.update(chunk)
    return h.hexdigest()


def verify_regular(p, row):
    s = os.lstat(p)
    if not stat.S_ISREG(s.st_mode) or s.st_size != row['bytes'] or oct(stat.S_IMODE(s.st_mode)) != row['mode'] or sha(p) != row['sha256']:
        raise RuntimeError('Public input changed: ' + str(p))


source = json.loads((BASE / 'current_client_artifacts/source-inputs-before.json').read_text())
for row in source['tracked']:
    verify_regular(Path(source['worktree']) / row['path'], row)

deps = json.loads((BASE / 'current_client_artifacts/installed-deps-before.json').read_text())
root = Path(deps['source'])
for row in deps['entries']:
    p = root / row['path']
    if row.get('kind') == 'symlink':
        if not p.is_symlink() or os.readlink(p) != row['target']:
            raise RuntimeError('Installed dependency symlink changed')
    else:
        verify_regular(p, row)

actual = set()
for d, dirs, files in os.walk(root, followlinks=False):
    for name in files:
        actual.add(str((Path(d) / name).relative_to(root)))
    for name in list(dirs):
        p = Path(d) / name
        if p.is_symlink():
            actual.add(str(p.relative_to(root)))
            dirs.remove(name)
if actual != {r['path'] for r in deps['entries']}:
    raise RuntimeError('Installed dependency entry set changed')

result = {'utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'status': 'PASS',
          'public_tracked_inputs_SHA_size_mode': len(source['tracked']), 'revision': source['revision'],
          'installed_entries_SHA_size_mode_or_exact_symlink_target': len(deps['entries']),
          'installed_exact_path_set': True, 'private_keys_or_process_environment_read': False,
          'public_tracked_template_and_test_public_key_hash_only': True,
          'source_inode_mtime_nlink_changes': 'DEDUP1 intentional only; byte/mode identity preserved',
          'old_PID1_Z': 'untouched; no all-old-reaped claim', 'apps_build_containers': 'NOT_RUN'}
(OUT / 'public-inputs-preserved.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result))
