# P06 independent critical-test Source review

CHANGES_REQUESTED — one P2 cleanup finding; no other concrete blocker in the bounded one-method/two-helper review. Native compile/format/runtime/mutation NOT_RUN.

## P06-TEST-CLEANUP-001 — P2

InternalSessionAdmissionIT.java:289–292 gates unpause on successful Docker inspection in finally. Concrete failure: exact owned PG accepts pause, pause response is lost, and the finally inspect fails transiently. No unpause command is attempted; the owned PG can stay paused and recovery assertions are skipped. Ensure an exact-owned unpause attempt after attempted pause even if inspection is unavailable; retain honest cleanup/original failure reporting and target ownership. Reviewer has not edited the test.

The pure-RAM logical transcription of this selected condition produces one unpause attempt for paused/successful inspect, zero for unpaused/successful inspect, and zero with skipped recovery when inspect throws. This is Source control-flow evidence, not an actual Docker transport test.

## Specification to oracle

The test meaningfully establishes A/B healthy admission, committed A revoke and fresh JDBC/authority/admission/controller reconstruction against the same durable PG/key. Retained A bearer and A refresh receive exact revoked denial while retained B yields a signed own identity/version/STUDENT/ACTIVE/group JWT and rotates its real correct JTI.

The exact existing non-reusable PG fixture is paused and inspected; otherwise-valid B then exercises production controller/service/JDBC to typed503 AUTHORITY_UNAVAILABLE, no-store and no internalToken, plus JDBC refresh AUTHORITY_UNAVAILABLE. After cleanup B is valid, A remains revoked; RAM tuple equality covers session/JTI/versions/expiry/revocation/timestamps/labels, own exact security events, user roles version and outbox count. Correct retained B JTI rotates after integrity check.

The proposed AUTHORITY_UNAVAILABLE→INVALID_SESSION mapping fault is relevant: JDBC's paused dependency maps to401 instead of503, breaking the public status oracle after healthy controls. It has not been written/executed. A healthy native selected case, causal mutation failure, exact restoration and selected GREEN remain required.

## Pins and limits

Live/source-packet SHA36bb223e2f903b1133bee2ce940e3341f48fa16f481441232c5668643dbc9ba9; before ed055a5fc45c1d970033c01566acabca00fec57ce2e47611a1611379c097cfe5; READY59dae8140feec42fbd42439e8ebcf08595518d813f1f7f5927b8abe06115d0c2. All10 READY Source pins match independently. Exact inverse two insertions230lines restores baseline481 old bytes/imports/defaults/assertions.

Fresh authority reconstruction is not full OS process restart; standalone production MockMvc is not real Gateway/PWA/TMA; one active STUDENT does not close all roles or parentP06. Actual timeouts/Docker transport/cleanup remain UNKNOWN. New explicit checks keep tokens/JTIs/state in RAM using boolean comparisons; private artifacts need the existing closed collector.

Created only REPORT.safe.json, checks.safe.json, REVIEW.md, manifest.safe.json and review.safe.zip in assigned reviewer scratch directory. No source/shared-document edits, private XML/log/keys/env reads, runtime or children.
