import ast,datetime,hashlib,json,os,re,stat,types
from pathlib import Path
OWN=Path(__file__).parent
SOURCE=Path('/workspace/scratch/rct-validation/current1742_e2e_boot_diagnostic_source/closed-boot-parser.py')
raw=SOURCE.read_bytes();tree=ast.parse(raw)
env={'dt':datetime,'re':re,'stat':stat}
nodes=[n for n in tree.body if isinstance(n,(ast.FunctionDef,ast.ClassDef,ast.Assign))]
exec(compile(ast.Module(body=nodes,type_ignores=[]),str(SOURCE),'exec'),env)
b={'repo':'DITEKmax/rutcampustrack','head':env['HEAD'],'run_id':env['RUN'],'run_attempt':1,'job_id':env['JOB'],'job_name':'Playwright E2E auth flow','step_number':9,'step_name':env['STEP'],'step_conclusion':'failure','step_started_at':'2026-10-13T11:03:00Z','step_completed_at':'2026-10-13T11:04:00Z','metadata_verified':True}
data=b'2026-10-13T11:03:10Z Container rct-e2e-redis-1 Healthy\n'
rows=[]
for mode in ['NORMAL','UID_DRIFT_AFTER_READ','MODE_DRIFT_AFTER_READ','NLINK_DRIFT_AFTER_READ','REPLACEMENT_INODE']:
 initial=dict(st_dev=1,st_ino=2,st_mode=0o100600,st_uid=1000,st_gid=1000,st_nlink=1,st_size=len(data),st_mtime_ns=3,st_ctime_ns=4)
 later=initial.copy()
 if mode=='UID_DRIFT_AFTER_READ':later.update(st_uid=999,st_ctime_ns=5)
 if mode=='MODE_DRIFT_AFTER_READ':later.update(st_mode=0o100644,st_ctime_ns=5)
 if mode=='NLINK_DRIFT_AFTER_READ':later.update(st_nlink=2,st_ctime_ns=5)
 if mode=='REPLACEMENT_INODE':later.update(st_ino=9)
 calls={'fstat':0,'reads':0,'closed':0,'unlinks':0}
 def fstat(fd):
  calls['fstat']+=1
  return types.SimpleNamespace(**(initial if calls['fstat']==1 or mode=='REPLACEMENT_INODE' else later))
 def read(fd,n):calls['reads']+=1;return data
 def close(fd):calls['closed']+=1
 def unlink(name,dir_fd):calls['unlinks']+=1
 env['os']=types.SimpleNamespace(O_RDONLY=os.O_RDONLY,O_NOFOLLOW=os.O_NOFOLLOW,open=lambda *a,**k:20,fstat=fstat,read=read,close=close,stat=lambda *a,**k:types.SimpleNamespace(**later),unlink=unlink)
 denied=False
 try:env['consume_private'](10,b)
 except env['Blocked']:denied=True
 assert calls['reads']==1 and calls['closed']==1
 if mode=='NORMAL':assert not denied and calls['unlinks']==1
 elif mode=='REPLACEMENT_INODE':assert denied and calls['unlinks']==0
 else:assert denied and calls['unlinks']==1
 rows.append({'code':mode,'source_denied':denied,'unlink_count':calls['unlinks'],'foreign_or_alias_metadata_still_removed':mode not in ['NORMAL','REPLACEMENT_INODE'],'real_syscalls_or_private_reads':False})
r={'schema':'RCT_CLOSED_BOOT_PRIVATE_METADATA_DRIFT_SELECTED_AST_V1','source_sha256':hashlib.sha256(raw).hexdigest(),'controls':rows,'counterexamples':3,'no_real_fs_or_log_read':True}
(OWN/'metadata-drift-counterexample.safe.json').write_text(json.dumps(r,indent=2)+'\n')
print(json.dumps(r))
