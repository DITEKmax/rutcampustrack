import ast,datetime,hashlib,json,os,re,stat,sys,types
from pathlib import Path
SOURCE=Path('/workspace/scratch/rct-validation/current1742_e2e_boot_diagnostic_source_r1/closed-boot-parser.py')
env={'dt':datetime,'re':re,'stat':stat,'sys':sys}
nodes=[n for n in ast.parse(SOURCE.read_bytes()).body if isinstance(n,(ast.FunctionDef,ast.ClassDef,ast.Assign))]
exec(compile(ast.Module(body=nodes,type_ignores=[]),str(SOURCE),'exec'),env)
data=b'2026-10-13T11:04:45Z Container rct-e2e-redis-1 Healthy\n'
st=types.SimpleNamespace(st_dev=1,st_ino=2,st_mode=0o100600,st_uid=1000,st_nlink=1,st_size=len(data),st_mtime_ns=3,st_ctime_ns=4)
primary=OSError('PUBLIC_PRIMARY');cleanup=PermissionError('PUBLIC_CLEANUP')
def read(*a):raise primary
def unlink(*a,**k):raise cleanup
env['os']=types.SimpleNamespace(O_RDONLY=os.O_RDONLY,O_NOFOLLOW=os.O_NOFOLLOW,open=lambda *a,**k:20,fstat=lambda *a:st,read=read,close=lambda *a:None,stat=lambda *a,**k:st,unlink=unlink)
b={'repo':'DITEKmax/rutcampustrack','head':env['HEAD'],'run_id':env['RUN'],'run_attempt':1,'job_id':env['JOB'],'job_name':'Playwright E2E auth flow','step_number':9,'step_name':env['STEP'],'step_conclusion':'failure','step_started_at':'2026-10-13T11:04:31Z','step_completed_at':'2026-10-13T11:05:59Z','metadata_verified':True}
caught=None
try:env['consume_private'](10,b)
except BaseException as error:caught=error
assert caught is cleanup and caught is not primary
r={'schema':'RCT_BOOT_R1_UNLINK_PRIMARY_SELECTED_AST_V1','source_sha256':hashlib.sha256(SOURCE.read_bytes()).hexdigest(),'primary_read_OSError_preserved':False,'cleanup_PermissionError_observed':True,'current_ownership_metadata_valid':True,'real_log_FS_API_or_native_effects':False}
(Path(__file__).parent/'unlink-primary-counterexample.safe.json').write_text(json.dumps(r,indent=2)+'\n')
print(json.dumps(r))
