import ast,datetime,hashlib,json,types
from pathlib import Path
SOURCE=Path('/workspace/scratch/rct-validation/current1742_e2e_boot_outer_caller_source_r1/read-existing-boot.py')
tree=ast.parse(SOURCE.read_bytes())
helper=next(n for n in ast.walk(tree) if isinstance(n,ast.FunctionDef) and n.name=='fresh_cleanup_settlement')
need=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='need')
gate=next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name=='Gate')
code=compile(ast.Module(body=[gate,need,helper],type_ignores=[]),str(SOURCE),'exec')
start=datetime.datetime(2026,10,13,12,30,tzinfo=datetime.timezone.utc)
rows=[]
for mode in ['LIVE_RECORDED_BIRTH','ALL_RECORDED_ABSENT','REUSED_PID_DIFFERENT_BIRTH','UNKNOWN_SUPERVISION','EMPTY_TERMINAL_IDENTITIES','BOOLEAN_STORED_BIRTH','MEASUREMENT_DELAY_EXPIRES']:
 state={'clock':start,'tables':0}
 class Clock:
  fromisoformat=staticmethod(datetime.datetime.fromisoformat)
  @staticmethod
  def now(tz):return state['clock']
 def table():
  state['tables']+=1
  if mode=='MEASUREMENT_DELAY_EXPIRES':state['clock']=start+datetime.timedelta(seconds=121)
  return {88:{'start_ticks':800}} if mode=='LIVE_RECORDED_BIRTH' else {88:{'start_ticks':801}} if mode=='REUSED_PID_DIFFERENT_BIRTH' else {}
 result={'settled':True,'all_owned_processes_reaped':True,'supervision_error_type':None,'known_owned_identities':[{'pid':88,'start_ticks':800}]}
 if mode=='UNKNOWN_SUPERVISION':result['supervision_error_type']='UNKNOWN'
 if mode=='EMPTY_TERMINAL_IDENTITIES':result['known_owned_identities']=[]
 latest={88:True if mode=='BOOLEAN_STORED_BIRTH' else 800}
 env={'result':result,'latest_ids':latest,'guard':types.SimpleNamespace(process_table=table),'dt':types.SimpleNamespace(datetime=Clock,timezone=datetime.timezone),'grant':{'not_before':start.isoformat(),'hard_stop':(start+datetime.timedelta(seconds=120)).isoformat()}}
 exec(code,env);denied=False
 try:env['fresh_cleanup_settlement']()
 except env['Gate']:denied=True
 expected=mode not in ['ALL_RECORDED_ABSENT','REUSED_PID_DIFFERENT_BIRTH'];assert denied is expected
 rows.append({'code':mode,'passed':True,'denied':denied,'fresh_table_reads':state['tables'],'real_proc_or_native_effects':False})
r={'schema':'RCT_BOOT_OUTER_R1_FRESH_SETTLEMENT_SELECTED_AST_V1','source_sha256':hashlib.sha256(SOURCE.read_bytes()).hexdigest(),'controls':rows,'all7passed':True,'actual_private_API_native_read':False}
(Path(__file__).parent/'fresh-settlement-controls.safe.json').write_text(json.dumps(r,indent=2)+'\n')
print(json.dumps(r))
