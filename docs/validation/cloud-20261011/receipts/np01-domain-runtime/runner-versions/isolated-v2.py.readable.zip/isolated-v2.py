"""Own DOMAIN1 phase execution; raw output stays private, only safe native/XML facts printed."""
import argparse
import hashlib
import json
import os
import re
import shutil
import signal
import subprocess
import sys
import time
from pathlib import Path
import xml.etree.ElementTree as ET

BASE = Path('/workspace/scratch/rct-validation/np01_domain_bot')
ROOT = Path('/workspace/rct-worktrees/np01-domain-bot')
FLOOR = 4 * 1024 ** 3


def free_bytes():
    stat = os.statvfs('/workspace')
    return stat.f_bavail * stat.f_frsize


def write(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n')


parser = argparse.ArgumentParser()
parser.add_argument('--phase', required=True)
parser.add_argument('--workdir', default=str(ROOT))
parser.add_argument('--source-root', default=str(ROOT))
parser.add_argument('--xml-dir', action='append', default=[])
parser.add_argument('command', nargs=argparse.REMAINDER)
args = parser.parse_args()
command = args.command[1:] if args.command[:1] == ['--'] else args.command
if not command:
    raise SystemExit('explicit bounded phase command required')
directory = BASE / 'runtime' / args.phase
directory.mkdir(parents=True, exist_ok=False)
workdir = Path(args.workdir)
source_root = Path(args.source_root)
revision = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=source_root, text=True).strip()
paths = [os.fsdecode(path) for path in subprocess.check_output(
    ['git', 'ls-files', '-z'], cwd=source_root).split(b'\0') if path]
files = [{'path': path, 'sha256': hashlib.sha256((source_root/path).read_bytes()).hexdigest(),
          'bytes': (source_root/path).stat().st_size} for path in paths]
clock = time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())
prelaunch = {'lease': 'DOMAIN1', 'phase': args.phase, 'source_revision': revision,
             'source_files': files, 'source_count': len(files), 'free_bytes': free_bytes(),
             'utc': clock, 'command': command, 'workdir': str(workdir), 'source_root': str(source_root),
             'phase_runner_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
             'working_delta': [os.fsdecode(path) for path in subprocess.check_output(
                 ['git', 'diff', '--name-only', '-z'], cwd=source_root).split(b'\0') if path],
             'limits': 'maxworker1/Gradle768MiB/test768MiB/onefork; own ephemeral PG16/16-alpine/loopback only'}
write(directory/'prelaunch.safe.json', prelaunch)
if prelaunch['free_bytes'] < FLOOR:
    raise SystemExit('DOMAIN1 disk floor prevents launch')
environment = dict(os.environ)
environment['NP01_PYTHON_EXECUTABLE'] = '/workspace/scratch/rct-validation/np01_config/pinned-venv/bin/python'
environment['PYTHONDONTWRITEBYTECODE'] = '1'
environment['DOCKER_HOST'] = 'unix:///var/run/docker.sock'
for key in ['DOCKER_CONTEXT', 'DOCKER_TLS', 'DOCKER_TLS_VERIFY', 'DOCKER_CERT_PATH']:
    environment.pop(key, None)
started = time.time()
log = directory/'terminal.private.log'
with log.open('xb') as output:
    log.chmod(0o600)
    child = subprocess.Popen(command, cwd=workdir, env=environment, stdout=output,
                             stderr=subprocess.STDOUT, start_new_session=True)
    write(BASE/'active-runtime.safe.json', {'phase': args.phase, 'state': 'RUNNING',
          'pid': child.pid, 'started_utc': clock, 'prelaunch': str(directory/'prelaunch.safe.json')})
    print(json.dumps({'phase': args.phase, 'state': 'RUNNING', 'pid': child.pid,
                     'source_count': len(files), 'free_bytes': prelaunch['free_bytes']}), flush=True)
    aborted = False
    while child.poll() is None:
        if free_bytes() < FLOOR:
            os.killpg(child.pid, signal.SIGTERM)
            aborted = True
            try:
                child.wait(timeout=10)
            except subprocess.TimeoutExpired:
                os.killpg(child.pid, signal.SIGKILL)
            break
        time.sleep(2)
    native = child.wait()
cases = []
xmls = []
totals = {'tests': 0, 'failures': 0, 'errors': 0, 'skipped': 0}
private = directory/'private-xml'
private.mkdir()
for relative in args.xml_dir:
    search = Path(relative) if Path(relative).is_absolute() else workdir/relative
    for source in sorted(search.glob('TEST-*.xml')):
        if source.stat().st_mtime < started - 1:
            continue
        data = source.read_bytes()
        destination = private/(search.parent.name + '-' + source.name)
        destination.write_bytes(data)
        destination.chmod(0o600)
        suite = ET.fromstring(data)
        suites = [suite] if suite.tag == 'testsuite' else suite.findall('testsuite')
        for one in suites:
            for key in totals:
                totals[key] += int(one.get(key, '0'))
            for case in one.findall('testcase'):
                failure = case.find('failure')
                error = case.find('error')
                status = 'FAIL' if failure is not None else 'ERROR' if error is not None else 'SKIP' if case.find('skipped') is not None else 'PASS'
                cases.append({'class': case.get('classname'), 'case': case.get('name'), 'status': status,
                              'failure_type': failure.get('type') if failure is not None else error.get('type') if error is not None else None})
        xmls.append({'name': destination.name, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()})
changed = [entry['path'] for entry in files if hashlib.sha256((source_root/entry['path']).read_bytes()).hexdigest() != entry['sha256']]
pattern = re.compile(rb'(generic_ignored_marker|own&lt;&amp;|np01-private-(?:initial|hash)-[0-9a-f-]{24,}|np01l_[0-9a-f]{20})')
privacy_files = [log] + list(private.glob('*.xml'))
leak_files = sum(bool(pattern.search(path.read_bytes())) for path in privacy_files)
summary = {'lease': 'DOMAIN1', 'phase': args.phase, 'source_revision': revision, 'native_exit': native,
           'disk_aborted': aborted, 'seconds': round(time.time()-started, 3), 'counts': totals, 'cases': cases,
           'xml': xmls, 'all_source_inputs_unchanged': not changed, 'changed_paths': changed,
           'private_marker_match_files': leak_files, 'raw_artifacts_private': True,
           'terminal_sha256': hashlib.sha256(log.read_bytes()).hexdigest(), 'free_bytes': free_bytes(),
           'utc': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())}
write(directory/'summary.safe.json', summary)
write(BASE/'active-runtime.safe.json', {'phase': args.phase, 'state': 'TERMINAL',
      'pid': child.pid, 'native_exit': native, 'summary': str(directory/'summary.safe.json')})
with (BASE/'attempts.ndjson').open('a') as ledger:
    ledger.write(json.dumps({key: value for key, value in summary.items() if key not in ['cases', 'xml']})+'\n')
print(json.dumps({key: summary[key] for key in ['phase', 'native_exit', 'disk_aborted', 'counts',
      'all_source_inputs_unchanged', 'private_marker_match_files', 'free_bytes', 'seconds']}), flush=True)
raise SystemExit(native if native >= 0 else 128-native)
