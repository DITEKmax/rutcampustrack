#!/usr/bin/env python3
import hashlib
import importlib
import importlib.metadata
import json
from pathlib import Path
import subprocess
import sys
import types

OUT = Path(__file__).resolve().parent
SCRIPT = Path('/workspace/rct-worktrees/np01-config/scripts/generate-bot-proto.py')
PROTO = Path('/workspace/rct-worktrees/np01-contract/proto')
FROZEN = '9757742e9c6baf75760c6cb5174fbdd0fd491a0c'
FILES = ('academic_pb2.py', 'academic_pb2_grpc.py')

def hashes(path):
    return {n: hashlib.sha256((path / n).read_bytes()).hexdigest() for n in FILES}

def run(name, args, expected=0):
    result = subprocess.run(args, capture_output=True)
    (OUT / (name + '.private.log')).write_bytes(result.stdout + result.stderr)
    assert result.returncode == expected, name
    return {'name': name, 'exit_code': result.returncode, 'expected': expected, 'command': args}

original = subprocess.check_output(['git', 'show', FROZEN + ':proto/academic.proto'], cwd=PROTO.parent)
assert original == (PROTO / 'academic.proto').read_bytes()
first = OUT / 'academic-output-1'
second = OUT / 'academic-output-2'
records = [run('generation-1', [sys.executable, str(SCRIPT), '--proto-dir', str(PROTO), '--output-dir', str(first)])]
initial = hashes(first)
records.append(run('generation-2', [sys.executable, str(SCRIPT), '--proto-dir', str(PROTO), '--output-dir', str(second)]))
assert initial == hashes(second)
records.append(run('generation-idempotent', [sys.executable, str(SCRIPT), '--proto-dir', str(PROTO), '--output-dir', str(first)]))
assert initial == hashes(first)

raw = OUT / 'native-output'; raw.mkdir(exist_ok=True)
records.append(run('native-generation', [sys.executable, '-m', 'grpc_tools.protoc', '--proto_path=' + str(PROTO),
                   '--python_out=' + str(raw), '--grpc_python_out=' + str(raw), str(PROTO / 'academic.proto')]))
absolute = b'import academic_pb2 as academic__pb2\n'
relative = b'from . import academic_pb2 as academic__pb2\n'
adapted = (first / FILES[1]).read_bytes(); native = (raw / FILES[1]).read_bytes()
assert native.count(absolute) == 1 and adapted.count(relative) == 1
assert adapted.replace(relative, absolute, 1) == native
assert (first / FILES[0]).read_bytes() == (raw / FILES[0]).read_bytes()

package = types.ModuleType('np01_generated')
package.__path__ = [str(first)]
sys.modules[package.__name__] = package
pb = importlib.import_module('np01_generated.academic_pb2')
grpc = importlib.import_module('np01_generated.academic_pb2_grpc')
assert pb.DESCRIPTOR.name == 'academic.proto'
assert pb.DESCRIPTOR.package == 'rutcampustrack.academic'
service = pb.DESCRIPTOR.services_by_name['AcademicGrpcService']
expected_methods = {'GetOwnBotInitialCredentials', 'ManageOwnBotCredentialMessages'}
assert expected_methods.issubset({m.name for m in service.methods})
assert grpc.GRPC_GENERATED_VERSION == '1.73.0'

wrong_version = "import importlib.metadata,runpy,sys; original=importlib.metadata.version; importlib.metadata.version=lambda name:'0.0.0' if name=='grpcio-tools' else original(name); sys.argv=" + repr([str(SCRIPT), '--proto-dir', str(PROTO), '--output-dir', str(first)]) + "; runpy.run_path(" + repr(str(SCRIPT)) + ",run_name='__main__')"
records.append(run('reject-wrong-tool-version', [sys.executable, '-c', wrong_version], expected=1))
assert hashes(first) == initial
for name, contents in (
    ('wrong-package', 'syntax="proto3"; package unrelated; message Empty {} service AcademicGrpcService { rpc Read(Empty) returns(Empty); }\n'),
    ('wrong-import-shape', 'syntax="proto3"; package rutcampustrack.academic; service AcademicGrpcService {}\n'),
):
    invalid = OUT / name; invalid.mkdir(exist_ok=True)
    (invalid / 'academic.proto').write_text(contents)
    records.append(run('reject-' + name, [sys.executable, str(SCRIPT), '--proto-dir', str(invalid), '--output-dir', str(first)], expected=1))
    assert hashes(first) == initial
assert original == (PROTO / 'academic.proto').read_bytes()
receipt = {'status': 'PASS', 'frozen_common_proto': FROZEN, 'proto_sha256': hashlib.sha256(original).hexdigest(),
           'generator_sha256': hashlib.sha256(SCRIPT.read_bytes()).hexdigest(), 'outputs_sha256': initial,
           'descriptor_identity': {'name': pb.DESCRIPTOR.name, 'package': pb.DESCRIPTOR.package,
                                   'serialized_sha256': hashlib.sha256(pb.DESCRIPTOR.serialized_pb).hexdigest()},
           'new_protected_methods_present': sorted(expected_methods), 'native_message_output_identical': True,
           'exactly_one_relative_import_adaptation': True, 'deterministic_and_idempotent': True,
           'negative_cases_preserved_destination': True, 'source_proto_preserved': True,
           'tracked_generated_outputs_written': False, 'runs': records,
           'versions': {n: importlib.metadata.version(n) for n in ('grpcio-tools', 'grpcio', 'protobuf')}}
(OUT / 'generator-verification.safe.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps({k: v for k, v in receipt.items() if k != 'runs'}))
