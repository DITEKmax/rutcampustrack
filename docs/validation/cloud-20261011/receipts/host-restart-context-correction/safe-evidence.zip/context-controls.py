"""Selected pure context identity controls: no real mkdir, aliases or child."""
import copy,json,os,stat,types
from pathlib import Path
from unittest.mock import patch
P=Path(__file__).parent
restart=P.name.startswith('current_host_restart')
name='restart-boundary.py' if restart else 'download-headers.py'
old=P.parent/('current_host_restart_ancestor_correction_v2' if restart else 'browser_webkit_payload_prepare')
def load(path):
 m=types.ModuleType('selected_context');m.__file__=str(path)
 exec(compile(path.read_bytes(),str(path),'exec'),m.__dict__);return m
new=load(P/name);before=load(old/name)
a=json.loads((P/('runtime-ancestor-anchors.safe.json' if restart else 'namespace-anchors.safe.json')).read_text())['anchors']
def info(i):return types.SimpleNamespace(st_mode=stat.S_IFDIR|i['mode'],st_dev=i['device'],st_ino=i['inode'],st_uid=i['uid'],st_gid=i['gid'])
base={r['path']:info({k:v for k,v in r.items() if k!='path'} if restart else r['identity']) for r in a}
leaf=new.PLAN/'runtime/restart-context-test' if restart else Path('/tmp/rct-webkit-payloads-20261012-context-test')
if restart:base[str(new.PLAN/'runtime')]=info({'mode':0o700,'device':27,'inode':9101,'uid':1000,'gid':1000})
class FakeOS:
 O_RDONLY=os.O_RDONLY;O_DIRECTORY=os.O_DIRECTORY;O_NOFOLLOW=os.O_NOFOLLOW;O_CLOEXEC=os.O_CLOEXEC
 def __init__(self,table,uid=1000,gid=1000,fd_swap=False):self.table=table;self.uid=uid;self.gid=gid;self.fds={};self.serial=10;self.writes=[];self.fd_swap=fd_swap
 def getuid(self):return self.uid
 def getgid(self):return self.gid
 def open(self,path,flags,dir_fd=None):
  assert flags & os.O_DIRECTORY and flags & os.O_NOFOLLOW
  target=str(Path(self.fds[dir_fd][0])/path) if dir_fd else str(path)
  value=copy.copy(self.table[target])
  if not stat.S_ISDIR(value.st_mode):raise OSError('mock nofollow')
  if self.fd_swap and target=='/':value.st_ino+=1
  self.serial+=1;self.fds[self.serial]=(target,value);return self.serial
 def fstat(self,fd):return self.fds[fd][1]
 def stat(self,name,dir_fd=None,follow_symlinks=True):
  assert follow_symlinks is False
  p=str(Path(self.fds[dir_fd][0])/name)
  if p not in self.table:raise FileNotFoundError(p)
  return self.table[p]
 def mkdir(self,name,mode,dir_fd=None):
  assert dir_fd is not None
  p=str(Path(self.fds[dir_fd][0])/name)
  if p in self.table:raise FileExistsError(p)
  self.table[p]=info({'mode':mode,'device':27 if restart else 33,'inode':9200,'uid':1000,'gid':1000});self.writes.append(p)
 def close(self,fd):self.fds.pop(fd)
checks=[]
def run(label,module,table,expected,uid=1000,gid=1000,fd_swap=False):
 fake=FakeOS(copy.deepcopy(table),uid,gid,fd_swap);obj=None;accepted=False
 def ls(p):
  if str(p) not in fake.table:raise FileNotFoundError(str(p))
  return fake.table[str(p)]
 with patch.object(module,'os',fake),patch.object(Path,'lstat',ls):
  try:
   obj=module.CohortDirectory(leaf,create=True) if restart else module.Namespace(leaf)
   accepted=True
  except (RuntimeError,OSError):pass
  finally:
   if obj:obj.close()
 assert accepted==expected,(label,accepted)
 if not expected:assert fake.writes==[],label
 assert not fake.fds,label
 checks.append({'case':label,'expected_accept':expected,'pass':True,'mock_relative_mkdir_count':len(fake.writes),'actual_writes':0})
run('old selected source rejects actual approved root0 before mkdir',before,base,False)
run('new selected source accepts exact root0 actor1000 nofollow metadata',new,base,True)
for anchor in a:
 path=anchor['path']
 for field,value in [('st_uid',999),('st_gid',999),('st_dev',999),('st_ino',777),('st_mode',stat.S_IFLNK|0o777),('st_mode',stat.S_IFREG|0o600)]:
  bad=copy.deepcopy(base);setattr(bad[path],field,value);run('deny '+path+' '+field+' '+str(value),new,bad,False)
 bad=copy.deepcopy(base);bad[path].st_mode^=0o040;run('deny exact mode change '+path,new,bad,False)
for uid,gid in [(0,1000),(1000,0),(999,1000),(1000,999)]:run('deny wrong actor '+str((uid,gid)),new,base,False,uid,gid)
run('deny nofollow FD identity mismatch',new,base,False,fd_swap=True)
masked=copy.deepcopy(base);masked['/'].st_uid=65534;masked['/'].st_gid=65534
if not restart:masked['/tmp'].st_uid=65534;masked['/tmp'].st_gid=65534
run('deny masked65534 context rather than widening accepted UID',new,masked,False)
(P/'context-controls.safe.json').write_text(json.dumps({'status':'PASS_SELECTED_OLD_RED_NEW_GREEN_CONTEXT_CONTROLS','count':len(checks),'checks':checks,'native_children_network_runtime':False,'all_aliases_mkdirs_FDs_mocked':True,'real_private_reads':False},indent=2)+'\n')
print(json.dumps({'context_controls':len(checks),'old_red':1,'new_positive':1,'actual_runtime':False}))
