"""One fixed synthetic before/after mount proof; no existing key volume is accessed."""

import datetime
import json
import math
import os
from pathlib import Path
import re
import subprocess
import sys
import tempfile
import time

IMAGE = "sha256:775f483016a7d128be2a6c6978785619990f9ac24abb5ff1868222020118b279"
VOLUME = "p07-key-isolation-20261013-01"
NAMES = [VOLUME + suffix for suffix in ("-seed", "-old", "-new")]
LABEL = "io.rutcampustrack.p07-isolation=20261013-01"
OUTPUT = Path(__file__).parent / "physical01.safe.json"
DOCKER = ["docker", "--host=unix:///var/run/docker.sock"]
ENV = os.environ.copy()
for selector in ("DOCKER_HOST", "DOCKER_CONTEXT", "DOCKER_TLS", "DOCKER_TLS_VERIFY", "DOCKER_CERT_PATH"):
    ENV.pop(selector, None)


def free_bytes(path):
    stats = os.statvfs(path)
    return stats.f_bavail * stats.f_frsize


def resource_gate(initial_free, deadline, cleanup=False):
    # Cheap fresh probes are fail-closed; UTC is read last, immediately before the effect.
    for path in ("/workspace", "/tmp"):
        current = free_bytes(path)
        if current < 4 * 1024**3 or initial_free[path] - current > 32 * 1024**2:
            raise RuntimeError("disk budget")
    current = int(Path("/sys/fs/cgroup/memory.current").read_text().strip())
    maximum = int(Path("/sys/fs/cgroup/memory.max").read_text().strip())
    if current < 0 or maximum <= 0 or current > min(15 * 1024**3, maximum - 1024**3):
        raise RuntimeError("shared memory budget")
    remaining = deadline - time.time() - (0 if cleanup else 30)
    if remaining <= 0:
        raise RuntimeError("cleanup deadline")
    return min(30, remaining)


def admit_volume(candidate, creation_started, now):
    fields = candidate.split()
    if len(fields) != 3 or fields[0] != VOLUME or fields[2] != "20261013-01":
        raise RuntimeError("new volume ownership")
    created = datetime.datetime.fromisoformat(fields[1].replace("Z", "+00:00"))
    if created.tzinfo is None or created.utcoffset() != datetime.timedelta(0):
        raise RuntimeError("volume creation timezone")
    # Docker's volume CreatedAt has second precision. The admission window preserves that limit.
    if not math.floor(creation_started) <= created.timestamp() <= now:
        raise RuntimeError("volume creation window")
    return candidate


def main():
    # Root supplies a fresh deadline after its resource/ownership grant. No reusable grant.
    deadline = datetime.datetime.fromisoformat(sys.argv[1]).timestamp()
    if OUTPUT.exists() or not 0 < deadline - time.time() <= 180:
        raise RuntimeError("fresh bounded operation required")
    start = time.monotonic()
    initial_free = {path: free_bytes(path) for path in ("/workspace", "/tmp")}
    result = {"state": "IN_PROGRESS", "image": IMAGE, "resources": NAMES + [VOLUME]}
    created_volume = False
    created_containers = {}
    volume_identity = None
    synthetic = None
    synthetic_identity = None
    key_identities = {}

    def run(argv, expected=0, cleanup=False):
        timeout = resource_gate(initial_free, deadline, cleanup)
        proc = subprocess.run(argv, env=ENV, capture_output=True, timeout=timeout)
        if proc.returncode != expected:
            raise RuntimeError("unexpected native status")
        return proc.stdout.decode("ascii").strip()

    def container_id(name, cleanup=False):
        value = run(DOCKER + ["container", "ls", "--all", "--filter", "name=^/" + name + "$", "--no-trunc", "--format", "{{.ID}}"], cleanup=cleanup)
        if value and re.fullmatch(r"[0-9a-f]{64}", value) is None:
            raise RuntimeError("container ID shape")
        return value

    def inspect_container(name, expected_identity):
        identity = container_id(name, cleanup=True)
        if not identity:
            return None
        if identity != expected_identity:
            raise RuntimeError("container ID changed")
        value = run(DOCKER + ["inspect", "--format", '{{.Id}} {{.Config.Image}} {{index .Config.Labels "io.rutcampustrack.p07-isolation"}}', identity], cleanup=True)
        if value != identity + " " + IMAGE + " 20261013-01":
            raise RuntimeError("container cleanup ownership")
        return identity

    def container(name, args, command, user=None, expected=0):
        argv = DOCKER + ["create", "--name", name, "--label", LABEL, "--network", "none", "--pull", "never", "--memory", "32m", "--pids-limit", "32"]
        if user:
            argv += ["--user", user]
        identity = run(argv + args + [IMAGE, "sh", "-c", command])
        if re.fullmatch(r"[0-9a-f]{64}", identity) is None:
            raise RuntimeError("created container ID shape")
        created_containers[name] = identity
        return run(DOCKER + ["start", "--attach", identity], expected=expected)

    try:
        for name in NAMES:
            if container_id(name):
                raise RuntimeError("preexisting container")
        if run(DOCKER + ["volume", "ls", "--filter", "name=^" + VOLUME + "$", "--format", "{{.Name}}"]):
            raise RuntimeError("preexisting volume")
        if run(DOCKER + ["image", "inspect", "--format", "{{.Id}}", IMAGE]) != IMAGE:
            raise RuntimeError("image identity")
        resource_gate(initial_free, deadline)
        synthetic = tempfile.mkdtemp(prefix=VOLUME + "-", dir="/tmp")
        directory = os.stat(synthetic, follow_symlinks=False)
        synthetic_identity = (directory.st_dev, directory.st_ino, directory.st_uid)
        private = Path(synthetic) / "private.key"
        public = Path(synthetic) / "public.key"
        for key in (private, public):
            resource_gate(initial_free, deadline)
            descriptor = os.open(key, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600)
            try:
                metadata = os.fstat(descriptor)
                key_identities[key.name] = (metadata.st_dev, metadata.st_ino, metadata.st_uid)
            finally:
                os.close(descriptor)
        run(["openssl", "genpkey", "-algorithm", "RSA", "-pkeyopt", "rsa_keygen_bits:3072", "-out", str(private)])
        run(["openssl", "pkey", "-in", str(private), "-pubout", "-out", str(public)])
        for key in (private, public):
            metadata = key.stat(follow_symlinks=False)
            if metadata.st_nlink != 1 or (metadata.st_dev, metadata.st_ino, metadata.st_uid) != key_identities[key.name]:
                raise RuntimeError("synthetic key identity")
        resource_gate(initial_free, deadline)
        private.chmod(0o600)
        resource_gate(initial_free, deadline)
        public.chmod(0o644)
        created_volume = True
        creation_started = time.time()
        run(DOCKER + ["volume", "create", "--label", LABEL, VOLUME])
        candidate = run(DOCKER + ["volume", "inspect", "--format", '{{.Name}} {{.CreatedAt}} {{index .Labels "io.rutcampustrack.p07-isolation"}}', VOLUME])
        volume_identity = admit_volume(candidate, creation_started, time.time())
        user = container(NAMES[0], ["--mount", f"type=volume,source={VOLUME},target=/keys", "--mount", f"type=bind,source={synthetic},target=/input,readonly"], "addgroup -S app && adduser -S app -G app && cp /input/private.key /keys/private.key && cp /input/public.key /keys/public.key && chown app:app /keys /keys/private.key /keys/public.key && chmod 600 /keys/private.key && chmod 644 /keys/public.key && printf '%s:%s' \"$(id -u app)\" \"$(id -g app)\"")
        if not all(part.isdecimal() for part in user.split(":")) or len(user.split(":")) != 2:
            raise RuntimeError("synthetic app uid")
        old = ["--mount", f"type=volume,source={VOLUME},target=/keys,readonly"]
        # Independent checks never read key contents. Same absence oracle is RED then GREEN.
        before = container(NAMES[1], old, "test -r /keys/public.key && test -r /keys/private.key && test -e /keys/private.key || exit 2; printf 'PUBLIC_READABLE=1 PRIVATE_READABLE=1 PRIVATE_EXISTS=1'; test ! -e /keys/private.key", user=user, expected=1)
        if before != "PUBLIC_READABLE=1 PRIVATE_READABLE=1 PRIVATE_EXISTS=1":
            raise RuntimeError("old fixture not readable")
        if run(DOCKER + ["inspect", "--format", "{{.State.ExitCode}}", NAMES[1]]) != "1":
            raise RuntimeError("old oracle status")
        result["before"] = {"absence_oracle_exit": 1, "public_readable": True, "private_readable": True, "private_exists": True, "mount": "whole synthetic volume"}
        container(NAMES[2], [], "test ! -e /keys/private.key && test ! -e /keys/public.key", user=user)
        result["after"] = {"absence_oracle_exit": 0, "private_absent": True, "public_file_absent": True, "public_transport": "existing Auth HTTP endpoint tested separately"}
        result["synthetic_app_uid_gid"] = user
        result["state"] = "PASS"
    except BaseException as error:
        result["state"] = "FAIL"
        result["error_type"] = type(error).__name__
        raise
    finally:
        cleanup_errors = 0
        for name, expected_identity in reversed(created_containers.items()):
            try:
                identity = inspect_container(name, expected_identity)
                if identity is None:
                    continue
                run(DOCKER + ["rm", "--force", identity], cleanup=True)
            except BaseException:
                cleanup_errors += 1
        if created_volume:
            try:
                if volume_identity is None or run(DOCKER + ["volume", "inspect", "--format", '{{.Name}} {{.CreatedAt}} {{index .Labels "io.rutcampustrack.p07-isolation"}}', VOLUME], cleanup=True) != volume_identity:
                    raise RuntimeError("volume ownership")
                run(DOCKER + ["volume", "rm", VOLUME], cleanup=True)
            except BaseException:
                cleanup_errors += 1
        if synthetic is not None:
            try:
                directory = os.stat(synthetic, follow_symlinks=False)
                if (directory.st_dev, directory.st_ino, directory.st_uid) != synthetic_identity:
                    raise RuntimeError("synthetic directory identity")
                for name in ("private.key", "public.key"):
                    key = Path(synthetic) / name
                    if not key.exists():
                        continue
                    metadata = key.stat(follow_symlinks=False)
                    if metadata.st_nlink != 1 or (metadata.st_dev, metadata.st_ino, metadata.st_uid) != key_identities.get(name):
                        raise RuntimeError("synthetic key identity")
                    resource_gate(initial_free, deadline, cleanup=True)
                    key.unlink()
                resource_gate(initial_free, deadline, cleanup=True)
                Path(synthetic).rmdir()
            except BaseException:
                cleanup_errors += 1
        result["cleanup_errors"] = cleanup_errors
        result["elapsed_seconds"] = round(time.monotonic() - start, 3)
        resource_gate(initial_free, deadline, cleanup=True)
        OUTPUT.write_text(json.dumps(result, indent=2) + "\n")
        if cleanup_errors:
            raise RuntimeError("known own resources require cleanup")


if __name__ == "__main__":
    main()
