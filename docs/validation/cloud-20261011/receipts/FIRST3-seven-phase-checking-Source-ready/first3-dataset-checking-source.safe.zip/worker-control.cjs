const fs = require('node:fs'), path = require('node:path'), crypto = require('node:crypto'), cp = require('node:child_process');
const W = '/workspace/rct-worktrees/first3-dataset-correction-20261013/tests/e2e';
const D = '/workspace/rct-worktrees/client-ci-first3/tests/e2e/node_modules';
const marker = 'RCT_PUBLIC_DATASET_WORKER_' + crypto.randomUUID();
const output = process.env.RCT_SAFE_FAILURE_CONTROL_OUTPUT;
const child = cp.spawnSync(process.execPath,['--max-old-space-size=512',D+'/playwright/cli.js','test','--config',__dirname+'/worker-control.config.ts'],{cwd:W,encoding:'utf8',timeout:60000,env:{...process.env,RCT_SAFE_FAILURE_CONTROL_MARKER:marker}});
function files(dir) { return fs.readdirSync(dir,{withFileTypes:true}).flatMap(entry=>entry.isDirectory()?files(path.join(dir,entry.name)):[path.join(dir,entry.name)]); }
let report = null; try { report = JSON.parse(fs.readFileSync(path.join(output,'safe-results.json'),'utf8')); } catch {}
const artifacts = fs.existsSync(output)?files(output):[];
const markerAbsent = [child.stdout||'',child.stderr||'',...artifacts.map(file=>fs.readFileSync(file).toString())].every(value=>!value.includes(marker));
const bodiesNotStarted = !artifacts.some(file=>file.endsWith('body-started.safe.json'));
const rows = Array.isArray(report?.results)?report.results:[];
const only = rows[0];
const closedDataset400 = Array.isArray(only?.diagnostics) && only.diagnostics.some(value=>value?.stage==='DATASET_HTTP' && value?.cause==='DATASET_GROUP_CREATE_HTTP' && value?.httpStatus===400 && Object.keys(value).sort().join()==='cause,httpStatus,stage');
const failedTestRetained = rows.length===1 && only.status==='failed' && only.expectedStatus==='failed' && Number.isSafeInteger(only.errorCount) && only.errorCount>0 && only.errorCount<=32;
const result = {pass:child.status===0&&markerAbsent&&bodiesNotStarted&&closedDataset400&&failedTestRetained&&report?.runnerErrors===0&&report?.unsafeArtifact===false,childNativeExit:child.status,caseCount:rows.length,markerAbsent,bodiesNotStarted,closedDataset400,failedTestRetained,reportedContextOnly:true,noBrowserApi:true,actualCIcause:'UNKNOWN'};
fs.writeFileSync(process.env.RCT_SAFE_DIAGNOSTIC_RECEIPT,JSON.stringify(result,null,2)+'\n',{mode:0o600});process.exitCode=result.pass?0:1;
