from pathlib import Path
import ast
import hashlib
import json
import subprocess

ROOT = Path('/workspace/rutcampustrack')
WT = Path('/workspace/rct-worktrees/np01-domain-bot')
OWN = Path('/workspace/scratch/rct-validation/np01_domain_review')
DOMAIN = '2f4d3d412753bedb1b084442efef63713a4e4348'
BASE = '2bca095380f72e8908a2511f2b10f0e795607f05'
COMMON = '9757742e9c6baf75760c6cb5174fbdd0fd491a0c'
CONFIG = '5d564870e631a276d88ac5a4b97463929f9b6687'

def sha(data):
    return hashlib.sha256(data).hexdigest()

def blob(revision, path):
    return subprocess.check_output(['git', 'show', revision + ':' + path], cwd=WT)

def save(name, data):
    (OWN / name).write_text(json.dumps(data, indent=2, ensure_ascii=False) + '\n')

inventory = json.loads((OWN / 'frozen22-inventory.json').read_text())
paths = subprocess.check_output(['git', 'diff', '--name-only', BASE, DOMAIN], cwd=WT, text=True).splitlines()
assert paths == [r['path'] for r in inventory['files']]
python_rows = []
for row in inventory['files']:
    data = blob(DOMAIN, row['path'])
    assert sha(data) == row['sha256'] and len(data) == row['bytes']
    assert (OWN / 'private-frozen-source' / row['path']).read_bytes() == data
    assert (WT / row['path']).read_bytes() == data
    if row['path'].endswith('.py'):
        tree = ast.parse(data, filename=row['path'])
        python_rows.append({'path': row['path'], 'syntax': 'AST_PARSE_ONLY', 'functions': sum(isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef)) for n in ast.walk(tree))})
assert len(python_rows) == 11
save('python-static-syntax.json', {'runtime': 'NOT_RUN', 'files': python_rows})

grpc_path = 'services/academic-service/academic-app/src/main/java/ru/rutcampustrack/academic/grpc/AcademicGrpcServiceImpl.java'
def generic_method(data):
    text = data.decode()
    start = text.index('    public void getUserByTelegramId(')
    end = text.index('    @Override', start)
    return text[start:end].encode()
original_generic = generic_method(blob(BASE, grpc_path))
current_generic = generic_method(blob(DOMAIN, grpc_path))
assert original_generic == current_generic
assert b'.setInitialPassword("")' in current_generic
save('generic-profile-byte-proof.json', {'path': grpc_path, 'base': BASE, 'domain': DOMAIN, 'method': 'getUserByTelegramId', 'method_sha256': sha(current_generic), 'bytes': len(current_generic), 'exact_original_method': True, 'initial_password_still_blank': True})

config_paths = ['services/academic-service/academic-app/src/main/resources/application.yml', 'services/notification-bot/bot/config.py']
assert subprocess.check_output(['git', 'diff', '--name-only', BASE, CONFIG], cwd=WT, text=True).splitlines() == config_paths
config_rows = []
for path in config_paths:
    data = blob(CONFIG, path)
    assert (Path('/workspace/rct-worktrees/np01-config') / path).read_bytes() == data
    config_rows.append({'path': path, 'sha256': sha(data), 'bytes': len(data), 'revision': CONFIG})
save('config2-inputs.json', config_rows)

common_paths = ['proto/academic.proto', 'services/academic-service/academic-app/src/main/resources/db/migration/V57__bot_credential_message_lifecycle.sql', 'event-schemas/password.changed.json']
common_rows = []
for path in common_paths:
    data = blob(COMMON, path)
    assert (Path('/workspace/rct-worktrees/np01-contract') / path).read_bytes() == data
    assert data == blob('1dbee1831e58477b7ea455e0220751fda09284a0', path)
    common_rows.append({'path': path, 'sha256': sha(data), 'bytes': len(data), 'revision': COMMON, 'product_bytes_same_as_initial_contract': True})
save('consulted-common-inputs.json', {'scope': 'Consumer semantics/generation/invalidation consultation only; separate common reviewer owns full wire/DDL review', 'files': common_rows})

dependency_paths = ['services/shared/shared-security/src/main/java/ru/rutcampustrack/shared/security/grpc/ServiceIdentityServerInterceptor.java', 'services/shared/shared-security/src/main/java/ru/rutcampustrack/shared/security/grpc/DirectedServiceCredential.java', 'services/shared/shared-security/src/main/java/ru/rutcampustrack/shared/security/grpc/ServicePrincipal.java', 'services/shared/shared-security/src/main/java/ru/rutcampustrack/shared/security/admin/AdminAccessJdbcAuthority.java', 'services/academic-service/academic-app/src/main/java/ru/rutcampustrack/academic/grpc/GrpcAuthInterceptor.java', 'services/academic-service/academic-app/src/main/java/ru/rutcampustrack/academic/admin/AdminAccessConfiguration.java', 'services/auth-service/auth-app/src/main/java/ru/rutcampustrack/auth/session/jdbc/JdbcSessionAuthority.java', 'services/notification-bot/bot/consumers/event_consumer.py', 'services/notification-bot/bot/services/otp_message_tracker.py', 'services/academic-service/academic-app/src/main/java/ru/rutcampustrack/academic/user/UserService.java']
dependencies = []
for path in dependency_paths:
    data = blob(DOMAIN, path)
    assert blob(BASE, path) == data
    dependencies.append({'path': path, 'sha256': sha(data), 'bytes': len(data), 'unchanged_from_base': True})
save('dependency-inputs.json', dependencies)

governing_paths = ['AGENTS.md', 'services/AGENTS.md', 'tests/AGENTS.md', '.agent/orchestration-v2/RULES.md', '.agent/orchestration-v2/CURRENT.md', 'docs/agent-workflow.md', 'docs/validation/cloud-20261011/TASK-CONTRACT.md', 'docs/validation/cloud-20261011/CURRENT.md', 'docs/validation/cloud-20261011/decisions.md', 'docs/validation/cloud-20261011/questions.md', 'docs/validation/cloud-20261011/resources.md', 'docs/validation/cloud-20261011/packet-np01-domain-review.md', 'docs/validation/cloud-20261011/skills/project/rct-source-resolution/SKILL.md', 'docs/validation/cloud-20261011/skills/project/rct-verification/SKILL.md', 'docs/research/reference-rutcampustrack-design/knowledge/job-stories.md', 'docs/product/job-stories.yaml', 'docs/validation/cloud-20261011/receipts/np01-source-resolution/source-ledger.json', 'docs/validation/cloud-20261011/receipts/np01-source-resolution/implementation-packet.md']
governing = [{'path': p, 'sha256': sha((ROOT / p).read_bytes()), 'bytes': (ROOT / p).stat().st_size} for p in governing_paths]
assert next(row['sha256'] for row in governing if row['path'].endswith('/TASK-CONTRACT.md')) == '8cbd27d431815647886b2f39592905d3f1d4cb985643e5d9fa3f3f669b4df4a5'
save('governing-acceptance-inputs.json', governing)
save('source-review-summary.json', {'domain_revision': DOMAIN, 'domain_files': 22, 'config_revision': CONFIG, 'config_files': 2, 'common_revision': COMMON, 'common_semantics_consulted': 3, 'generic_profile_exact_and_blank': True, 'old_OTP_consumer_unchanged': True, 'runtime': 'NOT_RUN', 'source_writes': 0, 'children': 0, 'future_bridge_harness': 'NOT_PART_OF_THIS_FROZEN22_VERDICT'})
print(json.dumps({'frozen_domain': DOMAIN, 'files_exact': 22, 'config_files_exact': 2, 'consulted_common_files': 3, 'generic_profile_exact_and_blank': True, 'unchanged_dependencies': len(dependencies), 'python_AST_files': len(python_rows), 'runtime': 'NOT_RUN'}, indent=2))
