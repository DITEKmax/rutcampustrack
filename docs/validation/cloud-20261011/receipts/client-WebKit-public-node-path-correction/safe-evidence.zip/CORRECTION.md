# Explicit provided Node correction

Actual Root65259 launcher1 failed BEFORE Node/browser: guard FileNotFoundError, directPIDnull/knownbirthsempty/settledfalse/TMPretained. Bare node cannot be found through caller explicit PATH/usr/bin:/bin; provided public Node is /opt/codex/runtimes/codex-primary-runtime/dependencies/node/bin/node. Root/source review missed reachability. No WebKit/ABI/product failure follows.

New sibling changes only caller argv0 to the absolute provided Node, plus regular/no-symlink/X_OK and exact metadata/SHA preflight. Namespace changes only to own r2. Normal actor1000/root0 read-only source inspection confirms SHA bc17c508ffeed0ec622934f9b7fa72f8e78da65350e63c3eceb56fa688aa5e12,125989464B/755/UIDGID0:0/device27/inode9223372036854817350/nlink1/X_OK. Default sandbox has masked owner65534; pin uses authorized ordinary native context. Node was not executed by source inspection: executable reachability/identity, not dynamic loader/protocol PASS.

Public helper/classifier and prior use-time controls byte-identical. Structural AST comparison after removing ONLY exact Node delta plus sibling BASE path matches full original r1 AST, keeping all meaningful literals/operators. Resource/clock-LAST before namespace/dispatch/observer, wrapperstop==outer, browser-only6keyenvironment, b78, quotas, public heading, source6aed/reviewb3caa/proof5c167 unchanged. No ambient PATH/global env/vendor/cache/product/fixture/Angular changes, no native43 replay or Node/browser retry.

Original source8aae/f33a and actual terminal retained byte-identical. Supervisor370873/birth8557093 absent, no child assigned. Empty own700 TMP removed only with rmdir; no signals/recursive deletion. Original settledfalse/all_owned_reapedfalse remain false: zero-child guard failure is not relabelled successful. Ancestor failure/cleanup safe receipt preserved separately.

Runtime r2 NOT_RUN. Fresh Root source read/review and separate grants required; Root owns wrapper private/browser-grant.json. Prepared5ced/currentexecutionebc. Existing source/adapter and ordinary last-check-before-use scheduling qualifications remain.
