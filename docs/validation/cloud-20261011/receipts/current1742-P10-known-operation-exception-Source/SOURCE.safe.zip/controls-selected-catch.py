"""Selected catch AST and synthetic error controls only; no observer/import/network/private reads."""
from pathlib import Path
import ast, datetime, hashlib, json, os, ssl, urllib.error, zipfile
import xml.etree.ElementTree as ET

scope = Path(__file__).parent
old = scope.with_name('p10-current1742-failure-frame-source-lifecycle-r1')
trees = {key: ast.parse((path / 'logged-green-child.py').read_text())
         for key, path in [('old', old), ('new', scope)]}
def selected(tree):
    obs = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == 'observe_original_case')
    return next(n for n in obs.body if isinstance(n, ast.Try)).handlers[0].body
setup = [n for n in trees['old'].body
         if (isinstance(n, ast.ClassDef) and n.name == 'DiagnosticBlocked')
         or (isinstance(n, ast.Assign) and any(isinstance(t, ast.Name) and t.id == 'PRIMARY_REJECTION_CODES' for t in n.targets))]
base = {}
exec(compile(ast.Module(body=setup, type_ignores=[]), '<selected-Source-setup>', 'exec'), base)
D = base['DiagnosticBlocked']
canary = 'OWN_SYNTHETIC_PRIVATE_CANARY'
def run(key, error, stage='URL_OPEN'):
    env = {**base, 'failure': error, 'operation_stage': stage, 'exception_code': 'NONE',
           'http_status': 0, 'ssl': ssl, 'urllib': __import__('urllib'), 'zipfile': zipfile, 'ET': ET, 'json': json}
    exec(compile(ast.Module(body=selected(trees[key]), type_ignores=[]), '<selected-generic-catch-Source>', 'exec'), env)
    out = {k: env[k] for k in ['primary_rejection', 'operation_stage', 'exception_code', 'http_status']}
    assert canary not in json.dumps(out)
    return out
def http(status):
    return urllib.error.HTTPError('https://example.invalid/' + canary, status, canary, {}, None)
assert run('old', http(403)) == {'primary_rejection': 'BOUNDARY_UNKNOWN', 'operation_stage': 'URL_OPEN', 'exception_code': 'NONE', 'http_status': 0}
assert run('new', http(403)) == {'primary_rejection': 'BOUNDARY_UNKNOWN', 'operation_stage': 'URL_OPEN', 'exception_code': 'HTTP_ERROR', 'http_status': 403}
controls = {'old_HTTP403_loses_enum_status': True, 'new_direct_HTTP403_enum_status_stage_closed': True}
for name, error, stage, code in [
    ('url_read', urllib.error.URLError(canary), 'URL_READ', 'URL_ERROR'),
    ('readmit', OSError(canary), 'READMIT_BEFORE_URL_OPEN', 'OS_ERROR'),
    ('private_write', PermissionError(canary), 'PRIVATE_XML_WRITE', 'PERMISSION'),
    ('safe_write', OSError(canary), 'SAFE_PROJECTION_WRITE', 'OS_ERROR'),
    ('xml_parse', ET.ParseError(canary), 'SELECTED_XML_PROJECTION', 'XML_PARSE')]:
    out = run('new', error, stage)
    assert out['exception_code'] == code and out['http_status'] == 0 and out['primary_rejection'] == 'BOUNDARY_UNKNOWN' and out['operation_stage'] == stage
    controls[name + '_enum_stage_no_private_export'] = True
out = run('new', D('ZIP_SYNTAX'), 'SELECTED_ZIP_READ')
assert out['primary_rejection'] == 'ZIP_SYNTAX' and out['exception_code'] == 'DIAGNOSTIC_BLOCKED' and out['http_status'] == 0
controls['typed_primary_preserved'] = True
class UnknownHTTP(urllib.error.HTTPError):
    def __getattribute__(self, name):
        if object.__getattribute__(self, '__dict__').get('_trap', False):
            raise AssertionError('GETTER_TRAP')
        return object.__getattribute__(self, name)
unknown = UnknownHTTP('https://example.invalid/' + canary, 401, canary, {}, None)
object.__getattribute__(unknown, '__dict__')['_trap'] = True
out = run('new', unknown)
assert out['exception_code'] == 'OTHER' and out['http_status'] == 0 and out['primary_rejection'] == 'BOUNDARY_UNKNOWN'
controls['HTTP_subclass_getter_trap_never_accessed'] = True
for status in [True, '403', 99, 600]:
    out = run('new', http(status))
    assert out['exception_code'] == 'HTTP_ERROR' and out['http_status'] == 0
controls['direct_HTTP_status_noninteger_bool_outofrange_refused'] = True
for status in [100, 599]:
    assert run('new', http(status))['http_status'] == status
controls['direct_HTTP_status_valid_numeric_edges'] = True
obs = next(n for n in trees['new'].body if isinstance(n, ast.FunctionDef) and n.name == 'observe_original_case')
stages = [n.value.value for n in ast.walk(obs) if isinstance(n, ast.Assign)
          and any(isinstance(t, ast.Name) and t.id == 'operation_stage' for t in n.targets) and isinstance(n.value, ast.Constant)]
assert len(stages) == 15 and len(set(stages)) == 15
payload = {'schema': 'P10_OPERATION_R1_SELECTED_CATCH_AST_RAM_V1', 'utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
           'controls': controls, 'all_pass': all(controls.values()), 'actual_selected_catch_AST': True,
           'static_operation_stages': stages, 'unchanged_lifecycle13_and_parser17plus6': 'Prior approved evidence reused, not replayed',
           'actual02_operation_exception_HTTPstatus': 'UNKNOWN',
           'Source_only_effects': 'Synthetic errors inRAM/AST only; no environment/net/artifact/XML/log/nativeobserver/request access',
           'privacy': 'No messages/URI/context/arbitraryclass/body/hash exported; unknownclass getters never accessed',
           'fixture_checking_failure_preserved': 'operation-controls-attempt01.safe.json'}
os.umask(0o077)
target = scope / 'operation-controls.safe.json'
target.write_text(json.dumps(payload, indent=2) + '\n')
target.chmod(0o600)
print(json.dumps({'controls': len(controls), 'PASS': payload['all_pass'], 'sha256': hashlib.sha256(target.read_bytes()).hexdigest()}))
