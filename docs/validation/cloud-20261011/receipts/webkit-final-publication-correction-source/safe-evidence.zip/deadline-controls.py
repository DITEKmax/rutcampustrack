"""Expired-DURING-preflight actualselected usepoint counterexamples; all actions mocked."""
import ast,copy,datetime,json,os,types
from pathlib import Path
from unittest.mock import patch
P=Path(__file__).parent;OLD=P.parent/'browser_webkit_native_prepare'
gates=types.ModuleType('gates');exec(compile((P/'use-gates.py').read_bytes(),'use-gates','exec'),gates.__dict__)
stop=datetime.datetime(2026,10,12,17,0,tzinfo=datetime.timezone.utc)
clock={'now':stop-datetime.timedelta(seconds=1)}
class Clock:
 @classmethod
 def now(cls,tz):return clock['now']
gates.datetime=types.SimpleNamespace(datetime=Clock,timezone=datetime.timezone)
good={'/workspace_available':10000000000,'/tmp_available':10000000000,'shared_memory':3000000000,'shared_limit':17179869184,'rss':12000000}
gates.resources=lambda:dict(good)
checks=[]
def tree(path):return ast.parse(path.read_text())
def main(path):return next(n for n in tree(path).body if isinstance(n,ast.FunctionDef) and n.name=='main')
def compiled(nodes):return compile(ast.Module(body=nodes,type_ignores=[]),'actualselected action point','exec')
def run(label,nodes,globals,delay=True,want=False):
 clock['now']=stop-datetime.timedelta(seconds=1);actions=[];globals=dict(globals);globals['actions']=actions
 if delay:clock['now']+=datetime.timedelta(seconds=2)
 accepted=False
 try:exec(compiled(nodes),globals);accepted=True
 except RuntimeError:pass
 assert accepted==want,(label,accepted)
 if not want:assert actions==[],label
 checks.append({'case':label,'expired_during_preflight':delay,'expected_accept':want,'pass':True,'mock_actions':actions,'actual_allocations_exec_or_native':False})
# Real namespace subclass checks lease after potentially slow nofollow ancestor verification.
class Namespace:
 def __init__(self,path):
  self.identities=[1,2];self.check();events.append('mkdir')
 def check(self):clock['now']+=datetime.timedelta(seconds=2)
events=[]
oldmain=main(OLD/'extract-selected.py');oldnode=next(n for n in oldmain.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='ns' for t in n.targets))
newmain=main(P/'extract-selected.py');klass=next(n for n in newmain.body if isinstance(n,ast.ClassDef) and n.name=='LeasedNamespace');newnode=next(n for n in newmain.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='ns' for t in n.targets))
for label,nodes,want in [('old namespace metadata delay permits expiredmkdir',[oldnode],True),('new actualsubclass blocks expiredmkdir AFTER ancestorwork',[klass,newnode],False)]:
 clock['now']=stop-datetime.timedelta(seconds=1);events.clear();ok=False
 try:exec(compiled(nodes),{'driver':types.SimpleNamespace(Namespace=Namespace),'PREFIX':Path('/tmp/synthetic'),'CAP':33554432,'gates':gates,'stop':stop});ok=True
 except RuntimeError:pass
 assert ok==want
 if not want:assert events==[]
 checks.append({'case':label,'expiry_during_constructor_metadata':True,'expected_accept':want,'pass':True,'mock_mkdir_events':list(events),'actual_allocation':False})
# Actual first Output assignment +callback, delay inside constructor before firstmkdir.
class Output:
 def __init__(self,path,create=False,before_mutation=None):
  clock['now']+=datetime.timedelta(seconds=2)
  if before_mutation:before_mutation()
  events.append('mkdir')
for label,path,want in [('old native constructor lacksusegate',OLD/'validate-native.py',True),('new native constructor callbackdeniespostpreflight expiry',P/'validate-native.py',False)]:
 node=next(n for n in main(path).body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='out' for t in n.targets));clock['now']=stop-datetime.timedelta(seconds=1);events.clear();ok=False
 try:exec(compiled([node]),{'paths':types.SimpleNamespace(Output=Output),'OWN':P,'g':{'cohort_name':'native-test'},'gates':gates,'stop':stop});ok=True
 except RuntimeError:pass
 assert ok==want
 if not want:assert events==[]
 checks.append({'case':label,'expiry_during_constructor_metadata':True,'expected_accept':want,'pass':True,'mock_mkdir_events':list(events),'actual_allocation':False})
# Exact selected immediate executive gate; preflight was valid then became expired.
wm=main(P/'webkit-custom-exec.py');tryblock=next(n for n in wm.body if isinstance(n,ast.Try));execnode=next(n for n in tryblock.body if isinstance(n,ast.Expr) and isinstance(n.value,ast.Call) and ast.unparse(n.value.func)=='os.execve');gatenode=next(n for n in tryblock.body if isinstance(n,ast.Expr) and isinstance(n.value,ast.Call) and ast.unparse(n.value.func)=='gates.require_fresh')
for label,nodes,want in [('old wrapperexec afterslowproof accepts expiredgrant',[execnode],True),('new wrapperusegate beforeexec rejects expiryDURINGproof',[gatenode,execnode],False)]:
 events.clear();clock['now']=stop+datetime.timedelta(seconds=1);ok=False
 try:exec(compiled(nodes),{'os':types.SimpleNamespace(execve=lambda *a:events.append('execve')),'executable':'genuine-retained-MiniBrowser','argv':['--inspector-pipe'],'child_env':{},'gates':gates,'datetime':datetime,'grant':{'stop_utc':stop.isoformat()}});ok=True
 except RuntimeError:pass
 assert ok==want
 if not want:assert events==[]
 checks.append({'case':label,'expiry_during_proof_and_mapping':True,'expected_accept':want,'pass':True,'mock_exec':list(events),'actual_exec':False})
# Native finalsuccess gate after lastrehash. Existingactualresults are not faked as actualproof.
nm=main(P/'validate-native.py');tb=next(n for n in nm.body if isinstance(n,ast.Try));save=next(n for n in tb.body if isinstance(n,ast.Expr) and 'native-validation.safe.json' in ast.unparse(n));gate=tb.body[tb.body.index(save)-1];assert ast.unparse(gate).startswith('gates.require_fresh(stop)')
for label,nodes,want in [('old publication afterslowlastrehash passesexpiredwindow',[],True),('new finalpublication gate rejects expiryDURINGrehash',[gate],False)]:
 clock['now']=stop+datetime.timedelta(seconds=1);ok=False
 try:exec(compiled(nodes),{'gates':gates,'stop':stop});ok=True
 except RuntimeError:pass
 assert ok==want;checks.append({'case':label,'expiry_during_finalrehash':True,'expected_publish':want,'pass':True,'actual_proof_publication':False})
# Positive clock and each exact resource/actor denial atuse; delayedresourcefetch advances clock.
for label,mutation,want in [('validuse',None,True),('workspacefloor',('/workspace_available',4294967295),False),('tmpbudget',('/tmp_available',4294967296),False),('sharedstop',('shared_memory',16106127360),False),('reserve',('shared_limit',3000000000),False),('RSS',('rss',201326593),False)]:
 clock['now']=stop-datetime.timedelta(seconds=1);r=dict(good)
 if mutation:r[mutation[0]]=mutation[1]
 gates.resources=lambda r=r:dict(r);ok=False
 try:gates.require_fresh(stop,33554432);ok=True
 except RuntimeError:pass
 assert ok==want;checks.append({'case':'freshresource '+label,'expected_accept':want,'pass':True,'actual_mutation':False})
for uid,gid in [(0,1000),(1000,0)]:
 with patch.object(gates,'os',types.SimpleNamespace(getuid=lambda:uid,getgid=lambda:gid)):
  denied=False
  try:gates.require_fresh(stop)
  except RuntimeError:denied=True
  assert denied
 checks.append({'case':'wrongactor atuse '+str((uid,gid)),'pass':True})
def slowresources():clock['now']+=datetime.timedelta(seconds=2);return dict(good)
clock['now']=stop-datetime.timedelta(seconds=1);gates.resources=slowresources;denied=False
try:gates.require_fresh(stop)
except RuntimeError:denied=True
assert denied;checks.append({'case':'clockcheckedLAST afterdelayedresourcefetch prevents firstuse','pass':True,'actual_mutation':False})
# The realhelper constructor has callback immediately before each first mkdir, retaining originalguards.
helper=tree(P/'own-paths.py');cls=next(n for n in helper.body if isinstance(n,ast.ClassDef));ctor=next(n for n in cls.body if isinstance(n,ast.FunctionDef) and n.name=='__init__')
mkdirs=[]
for node in ast.walk(ctor):
 for field in ['body','orelse']:
  sequence=getattr(node,field,None)
  if not isinstance(sequence,list):continue
  for index,item in enumerate(sequence):
   if isinstance(item,ast.Expr) and isinstance(item.value,ast.Call) and ast.unparse(item.value.func)=='os.mkdir':
    assert index>0 and 'before_mutation()' in ast.unparse(sequence[index-1]);mkdirs.append(item)
assert len(mkdirs)==2;checks.append({'case':'bothactualhelpermkdirs immediatelyprecededbycallback, originalnofollow guardsretain','pass':True})
(P/'deadline-controls.safe.json').write_text(json.dumps({'status':'PASS_ACTUAL_SELECTED_EXPIRY_DURING_PREFLIGHT_USEPOINT_CONTROLS','count':len(checks),'checks':checks,'old_late_allow_counterexamples':4,'no_realclock_changes_resources_children_aliases_native_or_payload':True},indent=2)+'\n')
print(json.dumps({'deadline_controls':len(checks),'old_allow_vs_new_deny':4,'actual_native_or_extraction':False}))
