import ast
import datetime
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time

OWN=Path(__file__).parent
OLD=Path('/workspace/scratch/rct-validation/current_client_artifacts/build-only.py')
spec=importlib.util.spec_from_file_location('bounded_child',OWN/'bounded-child.py')
helper=importlib.util.module_from_spec(spec)
spec.loader.exec_module(helper)
ENV={'PATH':'/usr/bin:/bin','LANG':'C.UTF-8','LC_ALL':'C.UTF-8'}
attempts=OWN/'attempts.ndjson'


def record(action, **facts):
    value={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'action':action,**facts}
    with attempts.open('a') as stream:stream.write(json.dumps(value)+'\n')


def pointer(state, **facts):
    (OWN/'CURRENT.json').write_text(json.dumps({'state':state,**facts},indent=2)+'\n')


def resources():
    s=os.statvfs('/workspace')
    free=s.f_bavail*s.f_frsize
    current=int(Path('/sys/fs/cgroup/memory.current').read_text())
    maximum=int(Path('/sys/fs/cgroup/memory.max').read_text())
    if free<4294967296:return 'DISK_FLOOR'
    if maximum-current<1073741824:return 'SHARED_MEMORY_RESERVE'
    return None


def assert_absent(result):
    current=helper.process_table()
    for row in result['known_owned_identities']:
        assert row['pid'] not in current or current[row['pid']]['start_ticks']!=row['start_ticks']
    assert result['settled'] and result['all_owned_processes_reaped']
    assert result['all_members_including_Z_after']==[]
    assert result['supervision_error_type'] is None


def wait_status(path, predicate, seconds=4):
    deadline=time.monotonic()+seconds
    while time.monotonic()<deadline:
        try:
            value=json.loads(path.read_text())
            if predicate(value):return value
        except (FileNotFoundError,json.JSONDecodeError):pass
        time.sleep(.02)
    raise AssertionError('bounded status not observed')


previous=helper.subreaper()
assert resources() is None
assert not any(r['ppid']==os.getpid() for r in helper.process_table().values())
# Controller fallback adoption is process-local, only these harmless test trees.
helper.subreaper(1)
results={}
control_sources={name:hashlib.sha256((OWN/name).read_bytes()).hexdigest()
                 for name in ['bounded-child.py','harmless-tree.py','signal-runner.py','controls.py']}
results['control_sources_SHA']=control_sources
old_source=OLD.read_text()
old_tree=ast.parse(old_source)
function=next(node for node in old_tree.body if isinstance(node,ast.FunctionDef) and node.name=='group_members')
namespace={'Path':Path}
exec(compile(ast.Module(body=[function],type_ignores=[]),str(OLD),'exec'),namespace)
counter=None
supervisor=None
try:
    record('START_COUNTEREXAMPLE',old_source_sha256=hashlib.sha256(old_source.encode()).hexdigest())
    counter=subprocess.Popen([sys.executable,'-I','-S','-B',str(OWN/'harmless-tree.py'),
                              'normal',str(OWN/'counter-tree.json')],cwd=OWN,env=ENV,
                             stdin=subprocess.DEVNULL,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,
                             start_new_session=True)
    pointer('COUNTEREXAMPLE_RUNNING',pid=counter.pid,active_test_group=counter.pid)
    assert counter.wait(timeout=3)==0
    identities=json.loads((OWN/'counter-tree.json').read_text())
    grand=identities['grandchild_pid']
    actual=helper.process_table()[grand]
    assert actual['ppid']==os.getpid() and actual['state']=='Z' and actual['pgrp']==counter.pid
    legacy=namespace['group_members'](counter.pid)
    assert legacy==[]
    waited,status=os.waitpid(grand,0)
    assert waited==grand and os.waitstatus_to_exitcode(status)==0
    assert grand not in helper.process_table()
    assert not any(r['pgrp']==counter.pid for r in helper.process_table().values())
    results['old_counterexample']={'exact_AST_old_group_members':legacy,'actual_unreaped_owned_Z':actual,
                                   'false_all_owned_empty':True,'controller_waitpid_native_exit':0,
                                   'all_counter_PIDs_absent_after':True,'old_PPIDs1_untouched':True}
    record('COUNTEREXAMPLE_SETTLED',group=counter.pid,grandchild=grand,all_absent=True)
    pointer('NO_ACTIVE_TEST_GROUP',active_test_group=None)

    record('START_NORMAL_CONTROL')
    normal=helper.run_owned([sys.executable,'-I','-S','-B',str(OWN/'harmless-tree.py'),
                            'normal',str(OWN/'normal-tree.json')],str(OWN),ENV,
                           deadline_seconds=3,term_seconds=.2,kill_seconds=3,observe=resources,
                           status=lambda value:pointer('NORMAL_CONTROL',active_test_group=value['group'],observation=value))
    record('NORMAL_NATIVE_RESULT',**normal)
    assert_absent(normal)
    assert normal['native_exit']==0 and normal['phase_success']
    assert len(normal['adopted_waitpid_receipts'])==1 and normal['adopted_waitpid_receipts'][0]['native_exit']==0
    results['normal']=normal
    record('NORMAL_CONTROL_SETTLED',**normal)
    pointer('NO_ACTIVE_TEST_GROUP',active_test_group=None)

    record('START_DEADLINE_ESCAPED_DESCENDANT_CONTROL')
    timed=helper.run_owned([sys.executable,'-I','-S','-B',str(OWN/'harmless-tree.py'),
                           'signal',str(OWN/'deadline-tree.json')],str(OWN),ENV,
                          deadline_seconds=.3,term_seconds=.2,kill_seconds=3,observe=resources,
                          status=lambda value:pointer('DEADLINE_CONTROL',active_test_group=value['group'],observation=value))
    record('DEADLINE_NATIVE_RESULT',**timed)
    assert_absent(timed)
    assert timed['terminal_reason']=='BOUNDED_DEADLINE' and timed['native_exit']==-9 and not timed['phase_success']
    assert len(timed['adopted_waitpid_receipts'])==1 and timed['adopted_waitpid_receipts'][0]['native_exit']==-9
    results['deadline']=timed
    record('DEADLINE_CONTROL_SETTLED',**timed)
    pointer('NO_ACTIVE_TEST_GROUP',active_test_group=None)

    record('START_STATUS_FAILURE_DURING_SETTLEMENT_CONTROL')
    def fail_reporting(value):
        if value['state'].startswith('SETTLING_'):
            raise TypeError('synthetic reporting failure')
        pointer('STATUS_FAILURE_CONTROL',active_test_group=value['group'],observation=value)
    reported=helper.run_owned([sys.executable,'-I','-S','-B',str(OWN/'harmless-tree.py'),
                              'signal',str(OWN/'status-failure-tree.json')],str(OWN),ENV,
                             deadline_seconds=.3,term_seconds=.2,kill_seconds=3,
                             observe=resources,status=fail_reporting)
    record('STATUS_FAILURE_NATIVE_RESULT',**reported)
    assert reported['settled'] and reported['all_owned_processes_reaped']
    assert reported['all_members_including_Z_after']==[]
    assert reported['native_exit']==-9 and reported['supervision_error_type']=='TypeError'
    assert not reported['phase_success']
    current=helper.process_table()
    assert all(r['pid'] not in current or current[r['pid']]['start_ticks']!=r['start_ticks'] for r in reported['known_owned_identities'])
    results['status_failure_during_settlement']=reported
    record('STATUS_FAILURE_CONTROL_SETTLED',**reported)
    pointer('NO_ACTIVE_TEST_GROUP',active_test_group=None)

    record('START_TWO_SIGNAL_CONTROL')
    assert resources() is None
    supervisor=subprocess.Popen([sys.executable,'-I','-S','-B',str(OWN/'signal-runner.py')],cwd=OWN,env=ENV,
                                stdin=subprocess.DEVNULL,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
    pointer('SIGNAL_SUPERVISOR_RUNNING',supervisor_pid=supervisor.pid,active_test_group=None)
    running=wait_status(OWN/'signal-status.json',lambda value:value['state']=='RUNNING' and len(value['members_including_Z'])==2)
    group=running['group']
    assert any(r['session']!=group for r in running['members_including_Z'])
    supervisor.send_signal(signal.SIGINT)
    wait_status(OWN/'signal-status.json',lambda value:value['state']=='SETTLING_TERM' and value['signal_count']==1)
    supervisor.send_signal(signal.SIGTERM)
    assert supervisor.wait(timeout=6)==0
    signaled=json.loads((OWN/'signal-result.json').read_text())
    assert_absent(signaled)
    assert signaled['signal_count']==2 and signaled['terminal_reason']=='STOP_REQUEST'
    assert signaled['native_exit']==-9 and not signaled['phase_success']
    assert signaled['adopted_waitpid_receipts'][0]['native_exit']==-9
    assert supervisor.pid not in helper.process_table()
    results['two_signals_escaped_descendant']=signaled
    record('TWO_SIGNAL_CONTROL_SETTLED',supervisor_pid=supervisor.pid,**signaled)
    pointer('NO_ACTIVE_TEST_GROUP',active_test_group=None)

    blocked=subprocess.run([sys.executable,'-I','-S','-B',str(OWN/'bounded-child.py')],cwd=OWN,env=ENV,
                           stdin=subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=subprocess.DEVNULL,timeout=3)
    assert blocked.returncode==2
    assert not any(r['ppid']==os.getpid() for r in helper.process_table().values())
    results['dependent_false_grant']={'native_exit':2,'runtime_child_started':False}
    results['old_actual_qualification']={'old_PID201385_and201430':'Z/PPID1 remain material historical limitation; never touched/reparented/reaped','no_current_artifact_rebuild':True}
    results['control_native_exit']=0
    results['all_new_own_control_PIDs_absent']=True
    results['parent_environment_read']=False
    assert all(hashlib.sha256((OWN/name).read_bytes()).hexdigest()==sha for name,sha in control_sources.items())
    results['control_sources_unchanged']=True
    (OWN/'controls-result.json').write_text(json.dumps(results,indent=2)+'\n')
    record('CONTROLS_COMPLETE',native_exit=0,all_new_own_processes_absent=True)
    pointer('CONTROLS_COMPLETE',active_test_group=None,next='Seal immutable qualifications and request parent independent source recheck.')
finally:
    # Fallback covers only descendants of this fresh controller. Never PID1,
    # old build groups, arbitrary recorded PID lists or foreign processes.
    for direct in [counter,supervisor]:
        if direct is not None and direct.poll() is None:
            direct.kill()
            direct.wait(timeout=3)
    end=time.monotonic()+4
    while time.monotonic()<end:
        own={pid:r for pid,r in helper.process_table().items() if r['ppid']==os.getpid()}
        if not own:break
        helper.signal_records(own,signal.SIGKILL)
        for pid in own:
            try:os.waitpid(pid,os.WNOHANG)
            except ChildProcessError:pass
        time.sleep(.03)
    assert not any(r['ppid']==os.getpid() for r in helper.process_table().values())
    helper.subreaper(previous)

print(json.dumps({'native_exit':0,'old_filter_false_empty_proved':True,'new_normal_deadline_two_signal_reaped':True,
                  'all_new_test_PIDs_absent':True,'old_build_processes_untouched':True}),flush=True)
