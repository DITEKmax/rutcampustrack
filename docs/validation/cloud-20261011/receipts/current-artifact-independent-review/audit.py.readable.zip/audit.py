import collections
import datetime
import hashlib
import io
import json
import os
from pathlib import Path, PurePosixPath
import stat
import struct
import subprocess
import sys
import zipfile

SRC=Path('/workspace/scratch/rct-validation/current_client_artifacts')
WT=Path('/workspace/rct-worktrees/client-current-artifacts')
ROOT=Path('/workspace/rutcampustrack')
OWN=Path('/workspace/scratch/rct-validation/current_artifact_review')
REV='908fc8c27be82e4a0d7db7bf4d7b2c4a62225916'

def digest(stream):
 h=hashlib.sha256()
 while chunk:=stream.read(65536):h.update(chunk)
 return h.hexdigest()
def file_hash(p):
 with p.open('rb') as f:return digest(f)
def save(name,a):(OWN/name).write_text(json.dumps(a,ensure_ascii=False,indent=2)+'\n')
def git(*args,cwd=WT):return subprocess.run(['git','-C',str(cwd),*args],capture_output=True,check=True).stdout
def note(phase,**items):
 a={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'phase':phase,'runtime':'NOT_RUN',**items}
 (OWN/'attempts.ndjson').open('a').write(json.dumps(a)+'\n');print(json.dumps(a),flush=True)

if "--resume-artifacts" not in sys.argv:
 manifest=json.loads((SRC/'manifest.json').read_text())
 assert file_hash(SRC/'manifest.json')=='840492d38bfd204fe37c9bb46e89d3a3fdbc7957ad31ad1e9ca6ca058523ea7f'
 seal_checks=[]
 for r in manifest['safe_files']:
  p=Path(r['path']);assert p.is_relative_to(SRC) and p.is_file()
  v=file_hash(p);assert v==r['sha256'] and p.stat().st_size==r['bytes']
  seal_checks.append({'path':str(p),'sha256':v,'equal':True})
 archive=ROOT/'docs/validation/cloud-20261011/receipts/current-client-artifacts/immutable-original-receipts.zip'
 with zipfile.ZipFile(archive) as z:
  names=z.namelist();archive_checks=[]
  for r in manifest['safe_files']:
   name=Path(r['path']).name
   matches=[n for n in names if PurePosixPath(n).name==name]
   assert len(matches)==1,(name,matches)
   with z.open(matches[0]) as f:actual=digest(f)
   assert actual==r['sha256'];archive_checks.append({'member':matches[0],'sha256':actual,'equal':True})
 save('original-seal-identity.json',{'manifest_sha256':file_hash(SRC/'manifest.json'),'24payloads':seal_checks,'root_archive':str(archive),'root_archive_sha256':file_hash(archive),'root_original_payloads':archive_checks})
 note('original24_manifest_root_archive',payloads=len(seal_checks))

 assert git('rev-parse','HEAD').decode().strip()==REV
 assert not git('status','--porcelain=v1','--untracked-files=no')
 inputs=json.loads((SRC/'source-inputs-before.json').read_text())
 tracked=git('ls-files','-z').decode().split('\0');tracked=[x for x in tracked if x]
 assert len(tracked)==7350 and set(tracked)=={r['path'] for r in inputs['tracked']}
 mismatches=[]
 for r in inputs['tracked']:
  p=WT/r['path'];s=p.stat()
  if s.st_size!=r['bytes'] or oct(stat.S_IMODE(s.st_mode))!=r['mode'] or file_hash(p)!=r['sha256']:mismatches.append(r['path'])
 assert not mismatches
 root_diff=git('diff','--name-only',REV,'731d45e5c890e62976a69192dce62e9b5f534c6c',cwd=ROOT).decode().splitlines()
 unexpected=[p for p in root_diff if not p.startswith('docs/') and p!='.agent/checks.json']
 assert not unexpected,unexpected
 save('source7350-identity.json',{'worktree':str(WT),'producer':REV,'source_rows':len(tracked),'all_current_SHA_bytes_modes_equal':True,'git_tracked_clean':True,'root731_diff_from_producer':root_diff,'root_diff_kind':'docs/evidence and generated .agent/checks.json receipt; executable build/product inputs unchanged, no claim build executed at731','runtime':'NOT_RUN'})
 note('source7350_identity',paths=len(tracked))

 deps=json.loads((SRC/'installed-deps-before.json').read_text());base=Path(deps['source']);bad=[]
 for r in deps['entries']:
  p=base/r['path']
  if p.is_symlink():
   expected=r.get('symlink',r.get('target',r.get('symlink_target')))
   if expected!=os.readlink(p):bad.append(r['path'])
  else:
   if not p.is_file() or p.stat().st_size!=r['bytes'] or oct(stat.S_IMODE(p.stat().st_mode))!=r['mode'] or file_hash(p)!=r['sha256']:bad.append(r['path'])
 assert not bad,bad[:5]
 current_paths={str(p.relative_to(base)) for p in base.rglob('*') if p.is_file() or p.is_symlink()}
 assert current_paths=={r['path'] for r in deps['entries']}
 namespace=WT/'frontends/node_modules'
 aliases={name:str((namespace/'@rct'/name).resolve()) for name in ['mobile-core','pwa-vue','tma-vue']}
 assert all(v==str(WT/'frontends'/k) for k,v in aliases.items())
 save('installed-dependency-identity.json',{'source':str(base),'entries':len(deps['entries']),'all_SHA_bytes_modes_symlink_targets_and_pathset_equal':True,'current_workspace_aliases':aliases,'old_namespace_mutated':False})
 note('installed8272_identity',entries=len(deps['entries']))

def unfold(raw):
 lines=[]
 for x in raw.decode().replace('\r\n','\n').split('\n'):
  if x.startswith(' '):assert lines;lines[-1]+=x[1:]
  else:lines.append(x)
 return dict(x.split(': ',1) for x in lines if ': ' in x)

artifacts=json.loads((SRC/'eight-production-jars.json').read_text());rows=[]
distinct=set();total=unique=rounded=0;source_modes=collections.Counter();public_stage_modes={}
selected_nested=[]
for r in artifacts['jars']:
 p=Path(r['jar']);assert p.is_relative_to(WT)
 assert p.stat().st_size==r['bytes'] and file_hash(p)==r['sha256']
 assert oct(stat.S_IMODE(p.stat().st_mode))==r['mode']
 with zipfile.ZipFile(p) as z:
  names=z.namelist();assert len(names)==len(set(names))
  h=unfold(z.read('META-INF/MANIFEST.MF'))
  assert h['Main-Class']=='org.springframework.boot.loader.launch.JarLauncher'
  assert h['Start-Class']==r['unfolded_manifest']['Start-Class']
  loader='org/springframework/boot/loader/launch/JarLauncher.class'
  main='BOOT-INF/classes/'+h['Start-Class'].replace('.','/')+'.class'
  assert loader in names and main in names
  main_bytes=z.read(main);assert main_bytes[:4]==b'\xca\xfe\xba\xbe' and struct.unpack('>H',main_bytes[6:8])[0]==65
  indices={name:z.read(name).decode() for name in ['BOOT-INF/layers.idx','BOOT-INF/classpath.idx']}
  assert all('"'+x+'"' in indices['BOOT-INF/layers.idx'] for x in ['dependencies','spring-boot-loader','snapshot-dependencies','application'])
  lib_names=[n for n in names if n.startswith('BOOT-INF/lib/') and n.endswith('.jar')]
  assert len(lib_names)==r['direct_nested_jars']
  omitted_index=[n for n in lib_names if n not in indices['BOOT-INF/classpath.idx']]
  # Spring Boot 3.5.16 includes its tools-mode library outside normal launcher classpath.
  assert omitted_index==['BOOT-INF/lib/spring-boot-jarmode-tools-3.5.16.jar'],omitted_index
  assert 'ru/rutcampustrack/e2e/' not in '\n'.join(names) and not any('clock-fixture' in n for n in names)
  if r['service']=='academic':assert not any('/auth-app-' in n for n in lib_names)
  stamp='BOOT-INF/classes/git.properties'
  if r['service']=='renderer':assert stamp not in names
  else:
   props=z.read(stamp);pairs=dict(x.split('=',1) for x in props.decode().splitlines() if '=' in x and not x.startswith('#'));assert pairs['git.commit.id']==REV and hashlib.sha256(props).hexdigest()==r['git_properties_sha256']
  local_total=local_unique=local_rounded=0;entry_modes=collections.Counter();entries=[]
  for member in z.infolist():
   name=member.filename
   assert not name.startswith('/') and '\\' not in name and '..' not in PurePosixPath(name).parts
   filetype=(member.external_attr>>16)&0o170000
   assert filetype in (0,stat.S_IFREG,stat.S_IFDIR),name
   if member.is_dir():continue
   mode=((member.external_attr>>16)&0o777) or 0o644
   with z.open(member) as f:sha=digest(f) # complete streaming read also validates entry CRC
   key=(sha,mode,member.file_size);local_total+=member.file_size;entry_modes[oct(mode)]+=1;source_modes[oct(mode)]+=1
   if key not in distinct:
    distinct.add(key);local_unique+=member.file_size;local_rounded+=((member.file_size+4095)//4096)*4096
   entries.append({'path':name,'sha256':sha,'bytes':member.file_size,'source_zip_mode':oct(mode),'proposed_NEW_public_mode':'0o644'})
  for n in lib_names:
   # Reuse the existing all-nested absence receipt; independently inspect critical small shared dependencies.
   if '/shared-' in n:
    member=z.getinfo(n);assert member.file_size<8*1024*1024
    with zipfile.ZipFile(io.BytesIO(z.read(n))) as nested:
     nested_names=nested.namelist();assert not any('ru/rutcampustrack/e2e/' in n or 'clock-fixture' in n for n in nested_names)
     selected_nested.append({'service':r['service'],'member':n,'bytes':member.file_size,'fixture_names_absent':True,'EducationalTime_present':'ru/rutcampustrack/shared/web/time/EducationalTime.class' in nested_names})
  total+=local_total;unique+=local_unique;rounded+=local_rounded
  rows.append({'service':r['service'],'jar':str(p),'sha256':r['sha256'],'bytes':r['bytes'],'unfolded_manifest':{k:h[k] for k in ['Main-Class','Start-Class','Spring-Boot-Classes','Spring-Boot-Lib','Spring-Boot-Classpath-Index','Spring-Boot-Layers-Index']},'main_major_version':65,'CRC_streamed_regular_entries':len(entries),'source_member_modes':dict(entry_modes),'logical_payload_bytes':local_total,'new_distinct_SHA_mode_bytes':local_unique,'new_distinct_4KiB_rounded_bytes':local_rounded,'library_count':len(lib_names),'normal_index_omitted_tools_library':omitted_index,'git_properties':REV if r['service']!='renderer' else 'N/A canonical7-app generator'})
  save('payload-'+r['service']+'.json',{'producer':REV,'service':r['service'],'entries':entries,'staging':'NOT_RUN; dirs755/files644 in NEW public payload only; no source/JAR/keys mode change'})
 note('streaming_artifact',service=r['service'],entries=len(entries))
union=json.loads((SRC/'full-payload-union-proposal.json').read_text())
assert (total,unique,rounded)==(union['all_payload_logical_bytes'],union['distinct_SHA_mode_bytes'],union['distinct_4KiB_rounded_files_estimate'])
save('eight-artifact-streaming-audit.json',{'producer':REV,'jars':rows,'selected_small_nested_dependency_checks':selected_nested,'total_payload_logical_bytes':total,'source_mode_distinct_bytes':unique,'source_mode_distinct_4KiB_rounded_bytes':rounded,'source_zip_modes':dict(source_modes),'independent_scope':'all8 full file hashes/central metadata/unfolded headers/main/indices/streamed memberSHA+CRC; selected small shared nested metadata. Existing unchanged verifier all-nested absence receipt reused; no nested-600MB allocation/extraction/app launch.'})

bundles=json.loads((SRC/'production-vue-bundles.json').read_text());out=[]
for b in bundles['bundles']:
 root=Path(b['directory']);actual={str(p.relative_to(root)) for p in root.rglob('*') if p.is_file()}
 assert actual=={r['path'] for r in b['files']}
 for r in b['files']:
  p=root/r['path'];assert file_hash(p)==r['sha256'] and p.stat().st_size==r['bytes'] and oct(stat.S_IMODE(p.stat().st_mode))==r['mode']
 index=(root/'index.html').read_text();assert b['public_base'] in index
 if b['workspace']=='pwa-vue':
  version=json.loads((root/'version.json').read_text());assert version['latest']=='0.0.0' and version['minimumSupported']=='0.0.0' and version['force'] is True
  assert "'__RCT_PWA_RELEASE__'" not in (root/'sw.js').read_text()
  assert 'self.__RCT_PRECACHE_ASSETS__' in (root/'sw-assets.js').read_text()
 out.append({'workspace':b['workspace'],'directory':str(root),'file_count':len(actual),'all_hash_mode_byte_equal':True,'base':b['public_base'],'fixture_false':'build env exactfalse/source production branch; no browser admission claimed'})
save('production-vue-audit.json',{'producer':REV,'bundles':out,'typebuild':'normal scripts vue-tsc --noEmit then vite build; existing native0 receipts','browser':'NOT_RUN'})

cleanup=[]
for name in ['boot8','pwa','tma']:
 r=json.loads((SRC/(name+'-receipt.json')).read_text());pid=r['child_pid'];assert r['native_exit']==0 and r['state']=='TERMINAL' and r['terminal_reason']=='NATIVE_TERMINAL' and not r['group_members_after']
 members=[]
 for p in Path('/proc').iterdir():
  if not p.name.isdecimal():continue
  try:
   fields=(p/'stat').read_text().rsplit(')',1)[1].split()
   if int(fields[2])==pid:members.append({'pid':int(p.name),'state':fields[0]})
  except (OSError,ValueError,IndexError):pass
 assert not members and not Path('/proc',str(pid)).exists()
 cleanup.append({'phase':name,'recorded_native_exit':0,'phase_pid':pid,'current_pid_absent':True,'current_process_group_members_including_zombies':members,'original_raw_log_hash':r['raw_log_sha256'],'raw_log_read':'NOT_READ private raw bodies excluded'})
save('native-source-cleanup-qualification.json',{'phases':cleanup,'status':'native receipts/source runner/current /proc only; no execution by reviewer','source_modes':'all7350 independently current equal; runner phase current_source checks hashes, final mode proof separately preserved'})
note('audit_complete',jars=len(rows),bundles=len(out),source=7350,deps=8272)
