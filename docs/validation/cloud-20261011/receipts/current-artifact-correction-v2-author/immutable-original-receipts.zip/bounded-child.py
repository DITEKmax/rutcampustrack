#!/usr/bin/env python3
"""One foreground owned child tree. Import API only; no build/runtime CLI grant."""
import ctypes
import os
from pathlib import Path
import signal
import subprocess
import time


def subreaper(value=None):
    libc = ctypes.CDLL(None, use_errno=True)
    if value is None:
        current = ctypes.c_int()
        result = libc.prctl(37, ctypes.byref(current), 0, 0, 0)
        answer = current.value
    else:
        result = libc.prctl(36, int(value), 0, 0, 0)
        answer = int(value)
    if result != 0:
        raise OSError(ctypes.get_errno(), 'child subreaper unavailable')
    return answer


def process_table():
    records = {}
    for path in Path('/proc').iterdir():
        if not path.name.isdecimal():
            continue
        try:
            fields = (path / 'stat').read_text().rsplit(')', 1)[1].split()
            records[int(path.name)] = {'pid': int(path.name), 'state': fields[0],
                                      'ppid': int(fields[1]), 'pgrp': int(fields[2]),
                                      'session': int(fields[3]), 'start_ticks': int(fields[19])}
        except FileNotFoundError:
            continue
    return records


def owned_records(table, parent, group, known):
    # The caller had no children before this single launch. Children adopted by
    # this process-local subreaper therefore belong to this one invocation.
    # A numeric group/session is diagnostic only, never ownership authority.
    # A known PID with a different birth tick is denied even if its parent or
    # group looks familiar; that recorded identity is never overwritten.
    eligible = {pid: row for pid, row in table.items()
                if pid not in known or known[pid] == row['start_ticks']}
    chosen = {pid for pid, row in eligible.items() if row['ppid'] == parent
              or known.get(pid) == row['start_ticks']}
    while True:
        expanded = chosen | {pid for pid, row in eligible.items() if row['ppid'] in chosen}
        if expanded == chosen:
            break
        chosen = expanded
    return {pid: table[pid] for pid in chosen}


def remember_identities(records, known):
    for pid, row in records.items():
        if pid in known and known[pid] != row['start_ticks']:
            raise RuntimeError('owned birth identity mismatch')
        known.setdefault(pid, row['start_ticks'])


def signal_records(records, signum):
    # pidfds bind each signal to the observed process identity, including an
    # owned descendant that left its original process group/session.
    for pid, row in records.items():
        if row['state'] == 'Z':
            continue
        descriptor = None
        try:
            descriptor = os.pidfd_open(pid)
            current = process_table().get(pid)
            if current is not None and current['start_ticks'] == row['start_ticks']:
                signal.pidfd_send_signal(descriptor, signum)
        except ProcessLookupError:
            pass
        finally:
            if descriptor is not None:
                os.close(descriptor)


def run_owned(argv, cwd, env, *, deadline_seconds, observe=None, status=None,
              term_seconds=1.0, kill_seconds=5.0):
    if type(env) is not dict or not all(type(k) is str and type(v) is str for k, v in env.items()):
        raise ValueError('explicit string environment map required; never inherit parent')
    if not 0 < deadline_seconds <= 1800 or not 0 < term_seconds <= 20 or not 0 < kill_seconds <= 10:
        raise ValueError('bounded deadlines required')
    if not hasattr(os, 'pidfd_open') or not hasattr(signal, 'pidfd_send_signal'):
        raise RuntimeError('required Linux pidfd support unavailable')
    parent = os.getpid()
    if any(row['ppid'] == parent for row in process_table().values()):
        raise RuntimeError('single invocation requires no pre-existing child')
    if observe is not None:
        initial = observe()
        if initial:
            raise RuntimeError('prelaunch resource guard')
    previous_subreaper = subreaper()
    subreaper(1)
    if subreaper() != 1:
        raise RuntimeError('child adoption not enabled')
    stopped = []
    old_handlers = {}
    for signum in (signal.SIGINT, signal.SIGTERM):
        old_handlers[signum] = signal.getsignal(signum)
        signal.signal(signum, lambda number, frame: stopped.append(number))
    child = None
    known = {}
    reaped = []
    reason = 'NATIVE_TERMINAL'
    error = None
    settled = False
    members = {}

    def refresh():
        child.poll()  # Popen alone reaps the direct child and owns its status.
        table = process_table()
        records = owned_records(table, parent, child.pid, known)
        remember_identities(records, known)
        # A conflicting current direct/adopted child remains an observation
        # failure, not grounds to claim the invocation completely reaped.
        if any(pid in known and known[pid] != row['start_ticks']
               and row['ppid'] == parent for pid, row in table.items()):
            raise RuntimeError('ambiguous adopted child birth identity')
        for pid, row in records.items():
            if pid == child.pid or row['ppid'] != parent:
                continue
            try:
                waited, native = os.waitpid(pid, os.WNOHANG)
            except ChildProcessError:
                continue
            if waited:
                reaped.append({'pid': pid, 'start_ticks': row['start_ticks'],
                               'native_exit': os.waitstatus_to_exitcode(native)})
        return owned_records(process_table(), parent, child.pid, known)

    def emit(state, records):
        nonlocal error
        if status is not None:
            try:
                status({'state': state, 'child_pid': child.pid, 'group': child.pid,
                        'members_including_Z': list(records.values()),
                        'reason': reason, 'signal_count': len(stopped)})
            except BaseException as caught:
                # Reporting failure is fatal to phase success, never to reap.
                error = type(caught).__name__

    try:
        child = subprocess.Popen(argv, cwd=cwd, env=env, stdin=subprocess.DEVNULL,
                                 stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                                 start_new_session=True)
        row = process_table().get(child.pid)
        if row is not None:
            remember_identities({child.pid: row}, known)
        emit('STARTED', {})
        started = time.monotonic()
        while child.poll() is None:
            members = refresh()
            emit('RUNNING', members)
            if error is not None:
                reason = 'SUPERVISION_ERROR'
                break
            if stopped:
                reason = 'STOP_REQUEST'
                break
            if time.monotonic() - started >= deadline_seconds:
                reason = 'BOUNDED_DEADLINE'
                break
            if observe is not None:
                resource_reason = observe()
                if resource_reason:
                    reason = resource_reason
                    break
            time.sleep(0.03)
    except BaseException as caught:
        # Preserve type only. Settlement still runs; no second signal throws.
        reason = 'SUPERVISION_ERROR'
        error = type(caught).__name__
    finally:
        if child is not None:
            started_settlement = time.monotonic()
            try:
                while True:
                    members = refresh()
                    if child.returncode is not None and not members:
                        settled = True
                        break
                    elapsed = time.monotonic() - started_settlement
                    if elapsed >= term_seconds + kill_seconds:
                        break
                    signum = signal.SIGTERM if elapsed < term_seconds else signal.SIGKILL
                    signal_records(members, signum)
                    emit('SETTLING_TERM' if signum == signal.SIGTERM else 'SETTLING_KILL', members)
                    time.sleep(0.03)
            except BaseException as caught:
                error = type(caught).__name__
                settled = False
            # Final current identity check includes known descendants and Z.
            try:
                members = refresh()
                settled = settled and child.returncode is not None and not members
                emit('REAPED' if settled else 'UNSETTLED', members)
            except BaseException as caught:
                error = type(caught).__name__
                settled = False
        for number, handler in old_handlers.items():
            signal.signal(number, handler)
        if settled or child is None:
            subreaper(previous_subreaper)
    return {'direct_pid': child.pid if child else None,
            'native_exit': child.returncode if child else None,
            'terminal_reason': reason, 'signal_count': len(stopped),
            'settled': settled, 'all_owned_processes_reaped': settled,
            'all_members_including_Z_after': list(members.values()),
            'known_owned_identities': [{'pid': pid, 'start_ticks': ticks} for pid, ticks in known.items()],
            'adopted_waitpid_receipts': reaped, 'supervision_error_type': error,
            'phase_success': settled and error is None and child is not None
                             and child.returncode == 0 and reason == 'NATIVE_TERMINAL'}


if __name__ == '__main__':
    print('BLOCKED: dependent artifact/application execution grant required')
    raise SystemExit(2)
