"""Narrow read-only v3 recheck; no private values/digests in outputs.

NEW synthetic ENV comparisons and selected pure AST only. Keys/IDs stat-only.
No generator top-level, runner main, guard, processes, signals or network.
"""
import ast
import base64
import copy
import hashlib
import json
import os
from pathlib import Path
import re
import stat
import zipfile

BASE = Path('/workspace/scratch/rct-validation')
OLD = BASE / 'current_host_config'
NEW = BASE / 'current_host_config_directional_v3'
OWN = BASE / 'hostcfg_g01_v3_recheck'
PRODUCT = Path('/workspace/rutcampustrack')
NAMES = {'ACADEMIC_TO_SCHEDULE_SERVICE_TOKEN', 'SCHEDULE_TO_ACADEMIC_SERVICE_TOKEN',
         'BOT_TO_ACADEMIC_SERVICE_TOKEN', 'BOT_TO_NOTIFICATION_SERVICE_TOKEN'}


def sha(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()


def save(name, obj):
    (OWN / name).write_text(json.dumps(obj, indent=2) + '\n')


def selected(p, name, namespace):
    source = p.read_text()
    n = next(n for n in ast.parse(source).body if isinstance(n, ast.FunctionDef) and n.name == name)
    exec(compile(ast.Module(body=[copy.deepcopy(n)], type_ignores=[]), str(p), 'exec'), namespace)
    return namespace[name], {'path': str(p), 'source_sha256': sha(p),
                            'function_AST_sha256': hashlib.sha256(ast.dump(n, include_attributes=False).encode()).hexdigest()}


launch = NEW / 'launch-manifest.json'
assert sha(launch) == '1f20137db35518dcbad5bafedbfc64744bf48b78c8e2044b979dd27133a47c6f'
m = json.loads(launch.read_text())
assert m['file_count'] == len(m['files']) == 15
for r in m['files']:
    p = Path(r['path'])
    assert sha(p) == r['sha256'] and p.stat().st_size == r['bytes']
    assert not r['archive_path'].startswith('private/') and not r['archive_path'].endswith('.key')
archive = NEW / 'safe-evidence.zip'
assert sha(archive) == 'f56cc54539f1640f42a8b834f12152457e7a290ca1a7f897ff09d06c89bb9d22'
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    assert len(z.namelist()) == 16 and set(z.namelist()) == {r['archive_path'] for r in m['files']} | {'launch-manifest.json'}
    for r in m['files']:
        b = z.read(r['archive_path'])
        assert len(b) == r['bytes'] and hashlib.sha256(b).hexdigest() == r['sha256']
    assert z.read('launch-manifest.json') == launch.read_bytes()
assert sha(OLD / 'launch-manifest.json') == m['original39_manifest_sha256'] == 'abc478d49ee558d8c42fed6368bb003e35b42b3031a820617dec7fed0709ba12'
old_manifest = json.loads((OLD / 'launch-manifest.json').read_text())
for r in old_manifest['files']:
    assert sha(r['path']) == r['sha256'] and Path(r['path']).stat().st_size == r['bytes']
original_review = BASE / 'current_host_config_review/immutable-review-manifest.json'
assert sha(original_review) == 'afaa29d3a6bc8e84ed0e6f87ccf299bd86bf418f5a304ee8c8318c9979cb8758'
prior = json.loads(original_review.read_text())
for r in prior['safe_publishable_receipts']:
    p = original_review.parent / r['path']
    assert sha(p) == r['sha256'] and p.stat().st_size == r['bytes']
save('input-and-original-preservation.safe.json', {'v3_manifest_sha256': sha(launch),
    'v3_safe_files': 15, 'v3_archive_sha256': sha(archive), 'archive_bytes': archive.stat().st_size,
    'v3_SHA_bytes_CRC_members': 16, 'old39_and_manifest_exact': True,
    'old_independent_review16_exact': True, 'old_review_manifest_sha256': sha(original_review),
    'private_material_in_v3_archive': False})

grpc, grpc_proof = selected(PRODUCT / 'services/notification-bot/bot/grpc_client/bot_service_credentials.py', 'canonical_token', {'base64': base64, 're': re})
prefs, prefs_proof = selected(PRODUCT / 'services/notification-bot/bot/services/notification_prefs.py', 'canonical_token', {'base64': base64, 're': re})
java_path = PRODUCT / 'services/shared/shared-security/src/main/java/ru/rutcampustrack/shared/security/grpc/DirectedServiceCredential.java'
java = java_path.read_text()
assert 'TOKEN_BYTES = 32;' in java and 'TOKEN_CHARACTERS = 43;' in java
for text in ['encodedToken.length() != TOKEN_CHARACTERS', 'encodedToken.matches("[A-Za-z0-9_-]{43}")',
             'Base64.getUrlDecoder().decode(encodedToken)', 'decoded.length != TOKEN_BYTES',
             'Base64.getUrlEncoder().withoutPadding().encodeToString(decoded)', 'canonical.equals(encodedToken) ? decoded : null']:
    assert text in java


def java_source_rule(value):
    if not isinstance(value, str) or len(value) != 43 or not re.fullmatch(r'[A-Za-z0-9_-]{43}', value):
        return False
    decoded = base64.urlsafe_b64decode(value + '=')
    return len(decoded) == 32 and base64.urlsafe_b64encode(decoded).decode().rstrip('=') == value


original_sources = json.loads((BASE / 'current_host_config_review/critical-source-inventory.safe.json').read_text())
for r in original_sources:
    assert sha(r['path']) == r['sha256']
public_good = base64.urlsafe_b64encode(bytes(range(32))).decode().rstrip('=')
alias = 'A' * 42 + 'B'
assert base64.urlsafe_b64decode(alias + '=') == base64.urlsafe_b64decode('A' * 43 + '=')
cases = [('valid32', public_good, True), ('valid32zero', 'A' * 43, True),
         ('empty', '', False), ('hex64', '0' * 64, False), ('padding', public_good + '=', False),
         ('short42', public_good[:-1], False), ('long44', public_good + 'A', False),
         ('decoded31', base64.urlsafe_b64encode(bytes(31)).decode().rstrip('='), False),
         ('decoded33', base64.urlsafe_b64encode(bytes(33)).decode().rstrip('='), False),
         ('plus', '+' + public_good[1:], False), ('slash', '/' + public_good[1:], False),
         ('space', ' ' + public_good[1:], False), ('Unicode', 'я' + public_good[1:], False),
         ('same_decoded32_noncanonical_alias', alias, False)]
controls = []
for name, value, expected in cases:
    results = [grpc(value), prefs(value), java_source_rule(value)]
    assert results == [expected] * 3
    controls.append({'case': name, 'expected': expected, 'actual_python_selected_AST': results[:2], 'Java_source_rule_counterpart': results[2]})

old_env, new_env, env_changes, old_tokens, new_tokens = {}, {}, [], {}, {}
paths = sorted((NEW / 'private').iterdir())
assert len(paths) == 9 and {p.name for p in paths} == {p.name for p in (OLD / 'private').iterdir() if p.suffix in {'.json', '.env'}}
assert stat.S_IMODE((NEW / 'private').stat().st_mode) == 0o700
new_identities = set()
for p in paths:
    st = p.lstat()
    assert stat.S_ISREG(st.st_mode) and stat.S_IMODE(st.st_mode) == 0o600 and st.st_uid == os.getuid()
    assert p.suffix in {'.json', '.env'}
    original = OLD / 'private' / p.name
    old_stat = original.lstat()
    assert st.st_nlink == 1 and (st.st_dev, st.st_ino) != (old_stat.st_dev, old_stat.st_ino)
    new_identities.add((st.st_dev, st.st_ino))
    if p.suffix == '.json':
        previous = json.loads(original.read_text())
        current = json.loads(p.read_text())
        assert set(previous) == set(current)
        changed = sorted(k for k in previous if current[k] != previous[k])
        assert changed == sorted(set(previous) & NAMES)
        assert all(type(v) is str and v for v in current.values())
        for n in changed:
            assert all(not f(previous[n]) for f in [grpc, prefs, java_source_rule])
            assert all(f(current[n]) for f in [grpc, prefs, java_source_rule])
            old_tokens.setdefault(n, set()).add(previous[n])
            new_tokens.setdefault(n, set()).add(current[n])
        old_env[p.name], new_env[p.name] = previous, current
        if not changed:
            assert p.read_bytes() == original.read_bytes()
    else:
        changed = []
        assert p.read_bytes() == original.read_bytes()
    env_changes.append({'name': p.name, 'changed_value_names_only': changed,
                       'other_names_values_equal': True, 'unchanged_file_byte_equal': not changed,
                       'mode': '0600', 'owner': st.st_uid, 'new_regular_nlink': st.st_nlink})
assert len(new_identities) == 9
assert set(old_tokens) == set(new_tokens) == NAMES
assert all(len(v) == 1 for v in old_tokens.values()) and all(len(v) == 1 for v in new_tokens.values())
assert len({next(iter(v)) for v in new_tokens.values()}) == 4
redgreen = [{'name': n, 'old_actual_rejected_by_both_Python_and_Java_source_rule': True,
             'new_actual_accepted_by_both_Python_and_Java_source_rule': True,
             'all_sender_receiver_reserved_copies_match': True} for n in sorted(NAMES)]
save('canonical-controls-and-actual-env.safe.json', {'finding': 'HOSTCFG-G01',
    'status': 'CLOSED_SOURCE_AND_ACTUAL_SYNTHETIC_ENV', 'selected_current_Python': [grpc_proof, prefs_proof],
    'Java_source': {'path': str(java_path), 'sha256': sha(java_path), 'native_JVM': 'NOT_RUN; independently inspected source-rule counterpart'},
    'public_controls': controls, 'public_control_count': 14, 'predicate_count': 3,
    'noncanonical_alias_same_decoded_bytes': True, 'actual_redgreen': redgreen,
    'four_new_directions_distinct': True, 'nine_private_copies': env_changes,
    'private_values_or_hashes_written': False})

old_specs = json.loads((OLD / 'host-service-specs.json').read_text())
new_specs = json.loads((NEW / 'host-service-specs.json').read_text())
assert len(old_specs) == len(new_specs) == 7
for old, new in zip(old_specs, new_specs):
    restored = dict(new)
    restored['private_environment_file'] = old['private_environment_file']
    assert restored == old
    assert new['private_environment_file'] == str(NEW / 'private' / Path(old['private_environment_file']).name)
    assert set(new_env[Path(new['private_environment_file']).name]) == set(new['required_private_names'])
for n in ['data-renderer-edge.compose.yml', 'tool-provenance.json', 'launch-grant.template.json']:
    assert (NEW / n).read_bytes() == (OLD / n).read_bytes()
old_runner, new_runner = (OLD / 'run-service-v2.py').read_bytes(), (NEW / 'run-service-v3.py').read_bytes()
assert new_runner.replace(b"'run-service-v3.py'", b"'run-service-v2.py'") == old_runner
assert 'os.environ' not in new_runner.decode() and 'SourceFileLoader' not in new_runner.decode()
old_commands = json.loads((OLD / 'launch-commands-v2.json').read_text())
new_commands = json.loads((NEW / 'launch-commands-v3.json').read_text())
restored = copy.deepcopy(new_commands)
for item in restored['host7_each_in_separate_bounded_foreground_exec_session']:
    assert item['argv'][1] == str(NEW / 'run-service-v3.py') and item['argv'][-1] == str(NEW / 'private/launch-grant.json')
    item['argv'][1] = str(OLD / 'run-service-v2.py')
    item['argv'][-1] = str(OLD / 'private/launch-grant.json')
for key in ['Docker9_start_only_after_review_and_actual_resource_lease', 'Docker9_cleanup_only_exact_owned_project_after_label_ID_recheck']:
    argv = restored[key]
    assert argv[argv.index('--env-file') + 1] == str(NEW / 'private/docker.env')
    assert argv[argv.index('-f') + 1] == str(NEW / 'data-renderer-edge.compose.yml')
    argv[argv.index('--env-file') + 1] = str(OLD / 'private/docker.env')
    argv[argv.index('-f') + 1] = str(OLD / 'data-renderer-edge.compose.yml')
assert restored['launch_manifest'] == str(launch)
restored['launch_manifest'] = old_commands['launch_manifest']
restored['supersedes'] = old_commands['supersedes']
assert restored == old_commands

safe_owned, _ = selected(NEW / 'run-service-v3.py', 'safe_owned', {'Path': Path, 'stat': stat, 'os': os})
assert safe_owned(str(NEW / 'private/auth.json'), NEW / 'private') == NEW / 'private/auth.json'
for raw in [str(NEW / 'private/../runtime/x'), str(NEW) + '/private//auth.json', str(OLD / 'private/auth.json')]:
    try: safe_owned(raw, NEW / 'private')
    except ValueError: pass
    else: raise AssertionError('private-scope counterexample admitted')
tree = ast.parse(new_runner)
main = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == 'main')
gates = [n for n in main.body if isinstance(n, ast.If)][:2]
code = compile(ast.Module(body=copy.deepcopy(gates), type_ignores=[]), '<selected v3 initial grant gates>', 'exec')
guard_sha = 'b78c61293568d9941692e0b92ee34fd0b84db6d532b4a2c9a5ad42ccbf2204a0'
good = {'launch_authorized': True, 'reviewed_guard_sha256': guard_sha, 'heavy_leases_released': {'NP01_BROKER1': True, 'FORMAT_JAVA': True}}
exec(code, {'grant': good, 'GUARD_SHA': guard_sha})
bad = [json.loads((NEW / 'launch-grant.template.json').read_text()), {}, {**good, 'launch_authorized': 'true'},
       {**good, 'reviewed_guard_sha256': 'foreign'}, {**good, 'heavy_leases_released': {'NP01_BROKER1': True, 'FORMAT_JAVA': False}}]
for grant in bad:
    try: exec(code, {'grant': grant, 'GUARD_SHA': guard_sha})
    except RuntimeError: pass
    else: raise AssertionError('false grant counterexample admitted')
assert sha(BASE / 'guard_proc_race_correction/bounded-child.py') == guard_sha
save('effective-pointer-and-v3-source.safe.json', {'seven_specs_only_private_pointers_change': True,
    'authoritative_spec': str(NEW / 'host-service-specs.json'), 'authoritative_runner': str(NEW / 'run-service-v3.py'),
    'authoritative_commands': str(NEW / 'launch-commands-v3.json'), 'authoritative_manifest': str(launch),
    'runner_exact_reverse_to_v2_only_self_filename': True, 'commands_only_effective_inputs_and_supersedes': True,
    'Compose_tools_falsegrant_byte_equal': True, 'all_nonsecret_fields_classpaths_TLS_publicpaths_origins_burst60_RSS_unchanged': True,
    'private_path_positive_negatives': [1, 3], 'initial_grant_positive_negatives': [1, 5],
    'b78_immutable_inmemory_ENVdeny_foreground_and_reaping_policy': 'unchanged byte/source proof; new actual runtime not executed'})

attempt = (NEW / 'prepare-directional-v3.attempt01.py').read_bytes()
corrected = (NEW / 'prepare-directional-v3.py').read_bytes()
old_line = b"for path in (ORIGINAL / 'private').iterdir():\n    st = path.lstat()"
new_line = b"for path in sorted((ORIGINAL / 'private').iterdir()):\n    if path.suffix not in {'.json', '.env'}:\n        continue\n    st = path.lstat()"
old_keys = b"keys = [*ORIGINAL.glob('tls/**/*.key'), ORIGINAL / 'jwt-auth/private.key', ORIGINAL / 'jwt-auth/kid.txt']"
new_keys = b"keys = [*ORIGINAL.glob('tls/**/*.key'), ORIGINAL / 'jwt-auth/private.key', ORIGINAL / 'jwt-auth/kid.txt', ORIGINAL / 'private/vapid-p256.key']"
assert corrected == attempt.replace(old_line, new_line, 1).replace(old_keys, new_keys, 1)
assert not (NEW / 'private/vapid-p256.key').exists()
prior_metadata = json.loads((BASE / 'current_host_config_review/preservation-and-allocation.safe.json').read_text())['original_private_key_ENV_ID_stat_only_current']
for r in prior_metadata:
    s = Path(r['path']).lstat()
    assert (s.st_dev, s.st_ino, s.st_nlink, s.st_size, oct(stat.S_IMODE(s.st_mode)), s.st_uid, s.st_gid, s.st_mtime_ns, s.st_ctime_ns) == (
        r['device'], r['inode'], r['nlink'], r['bytes'], r['mode'], r['uid'], r['gid'], r['mtime_ns'], r['ctime_ns'])
gen_tree = ast.parse(corrected)
loop = next(n for n in gen_tree.body if isinstance(n, ast.For) and ast.unparse(n.iter) == "sorted((ORIGINAL / 'private').iterdir())")
condition = loop.body[0]
assert isinstance(condition, ast.If) and len(condition.body) == 1 and isinstance(condition.body[0], ast.Continue)
filter_code = compile(ast.Expression(body=copy.deepcopy(condition.test)), '<selected actual suffix deny predicate>', 'eval')
for name, excluded in [('auth.json', False), ('docker.env', False), ('vapid-p256.key', True), ('private.key', True), ('kid.txt', True), ('env.pem', True)]:
    assert eval(filter_code, {'path': Path(name)}) is excluded


class PublicBytesFixture:
    def token_bytes(self, count):
        assert count == 32
        return bytes(range(32))


generate, gen_proof = selected(NEW / 'prepare-directional-v3.py', 'generate_directional_token', {'base64': base64, 'secrets': PublicBytesFixture()})
assert generate() == public_good and grpc(generate()) and prefs(generate()) and java_source_rule(generate())
scope = json.loads((NEW / 'scope-correction.safe.json').read_text())
assert scope['actual_privatekey_READ_in_attempt01'] == 'OWN VAPID ONLY; other RSA/TLS/keyID not read'
save('scope-erratum-and-preservation.safe.json', {'attempt01_source_sha256': sha(NEW / 'prepare-directional-v3.attempt01.py'),
    'final_source_sha256': sha(NEW / 'prepare-directional-v3.py'), 'exact_scope_correction_changes_only': ['deterministic sorted iteration', 'ENV json/env suffix filter', 'VAPID added to stat-only key inventory'],
    'selected_actual_suffix_filter_controls': 6, 'generator_actual_function_with_public_deterministic_byte_fixture': gen_proof,
    'historical_author_OWN_VAPID_read_copy': 'acknowledged source/receipt erratum; exact redundant NEW copy removed; initial no-key-read flag superseded',
    'current_private_copy_count9_and_noPEM': True, 'original_private_keys_ID_ENV_all_captured_metadata_exact': len(prior_metadata),
    'reviewer_private_key_or_ID_bytes_read': False, 'private_hashes_or_values_disclosed': False,
    'full_corrected_generation_rerun': 'not claimed; actual current nine outputs independently validated',
    'old16review_old39_privatekeys_source_product_validators_unchanged': True})
print(json.dumps({'verdict': 'APPROVE_SOURCE', 'HOSTCFG-G01': 'CLOSED_SOURCE_AND_ACTUAL_SYNTHETIC_ENV',
    'public_canonical_controls': '14x3 PASS', 'old4_RED_new4_GREEN': True,
    'private_path3_falsegrant5': 'PASS', 'old39_old16_preserved': True, 'runtime': 'NOT_RUN'}))
