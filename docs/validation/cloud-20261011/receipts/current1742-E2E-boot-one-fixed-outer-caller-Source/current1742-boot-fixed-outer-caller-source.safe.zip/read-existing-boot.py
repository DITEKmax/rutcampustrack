"""One existing job read, b78 owned exec, private capture, closed projection."""
import datetime as dt
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import stat
import sys
from types import SimpleNamespace

OWN = Path(__file__).absolute().parent
OUT = OWN / 'actual-read01'
R2 = Path('/workspace/scratch/rct-validation/current1742_e2e_boot_diagnostic_source_r2')
PRIVATE = R2 / 'private'
GRANT = PRIVATE / 'read-grant.json'
GUARD = Path('/workspace/scratch/rct-validation/guard_proc_race_correction/bounded-child.py')
PINS = {
    GUARD: 'b78c61293568d9941692e0b92ee34fd0b84db6d532b4a2c9a5ad42ccbf2204a0',
    R2/'capture-job-private.py': '10ef7d979e33a4bdd209ed46d1fabf82717b3e51e7efc6386e91c5abbd9107b4',
    R2/'closed-boot-parser.py': 'e7a6f7a522a5ae781a98a72bb08336fb19a4cca5364b9bd28df3215f7c3f0a0c',
    R2/'binding.actual.safe.json': '3be4bfce8d095d2201e7e7de3619ca99f9f49dc0df4073ff83c4de7d23513ca1',
    R2/'manifest.json': 'c303f7f53358bd2d6e3e56237efe6546ce29cfce25c2f1f76a4b27513a7f9a04'}
ENV_KEYS = frozenset(('HOME', 'GH_CONFIG_DIR', 'GH_TOKEN', 'GITHUB_TOKEN',
    'HTTPS_PROXY', 'HTTP_PROXY', 'ALL_PROXY', 'NO_PROXY', 'https_proxy',
    'http_proxy', 'all_proxy', 'no_proxy', 'SSL_CERT_FILE', 'SSL_CERT_DIR',
    'CURL_CA_BUNDLE', 'REQUESTS_CA_BUNDLE'))

class Gate(Exception):
    pass

def need(ok, code):
    if not ok:
        raise Gate(code)  # Code is always a fixed source literal.

def identity(st):
    return [st.st_dev, st.st_ino, st.st_uid, st.st_gid, stat.S_IMODE(st.st_mode)]

def directory(path):
    fd = os.open('/', os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
    try:
        need(os.fstat(fd).st_uid == 0, 'NATIVE_ANCHOR')
        for component in path.parts[1:]:
            nxt = os.open(component, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW, dir_fd=fd)
            os.close(fd)
            fd = nxt
        return fd
    except BaseException:
        os.close(fd)
        raise

def read_fd(parent, name, cap, private=False):
    fd = os.open(name, os.O_RDONLY | os.O_NOFOLLOW, dir_fd=parent)
    try:
        st = os.fstat(fd)
        need(stat.S_ISREG(st.st_mode) and st.st_uid == 1000 and st.st_nlink == 1
            and 0 < st.st_size <= cap, 'INPUT_METADATA')
        if private:
            need(stat.S_IMODE(st.st_mode) == 0o600, 'INPUT_PRIVATE_MODE')
        data = os.read(fd, cap + 1)
        need(len(data) == st.st_size, 'INPUT_LENGTH')
        return data
    finally:
        os.close(fd)

def public_bytes(path):
    parent = directory(path.parent)
    try:
        return read_fd(parent, path.name, 1024*1024)
    finally:
        os.close(parent)

def module(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    result = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(result)
    return result

def explicit_environment(inherited):
    # Only existing standard GH auth/proxy/CA context is read for this exact GET.
    # Never serialize values/key presence, copy all ENV, or enable GH_DEBUG.
    env = {key: inherited[key] for key in ENV_KEYS if key in inherited}
    env.update(PATH='/usr/bin:/bin', LANG='C.UTF-8', LC_ALL='C.UTF-8',
        GH_PROMPT_DISABLED='1', GH_PAGER='cat', GH_HOST='github.com',
        PYTHONDONTWRITEBYTECODE='1')
    return env

def validate(g, capture, own_sha):
    capture.validate_grant(g, PINS[R2/'capture-job-private.py'])
    need(g['caller_sha256'] == own_sha and g['parser_sha256'] == PINS[R2/'closed-boot-parser.py']
        and g['binding_sha256'] == PINS[R2/'binding.actual.safe.json']
        and g['b78_sha256'] == PINS[GUARD]
        and g['r2_manifest_sha256'] == PINS[R2/'manifest.json']
        and g['review_approved'] is True, 'GRANT_SOURCE')
    need(g['output'] == str(OUT) and g['actor_uid'] == 1000
        and g['rss_bytes'] == 536870912 and g['disk_growth_bytes'] == 268435456
        and g['floor_bytes'] == 4294967296 and g['shared_stop_bytes'] == 16106127360
        and g['shared_reserve_bytes'] == 1073741824, 'GRANT_CAPS')

def main():
    sys.dont_write_bytecode = True
    need(len(sys.argv) == 3 and sys.argv[1] == '--grant'
        and Path(sys.argv[2]).absolute() == GRANT and os.getuid() == 1000, 'ENTRY')
    private_fd = directory(PRIVATE)
    own_fd = directory(OWN)
    out_fd = None
    grant = None
    guard = None
    result = None
    stage = 'PREFLIGHT'
    error = None
    cleanup_state = 'NOT_CREATED'
    latest_ids = {}
    status_ordinal = 0
    baseline = None
    capture_leaf_identity = None
    try:
        grant = json.loads(read_fd(private_fd, 'read-grant.json', 16384, private=True))
        for path, wanted in PINS.items():
            need(hashlib.sha256(public_bytes(path)).hexdigest() == wanted, 'SOURCE_PIN')
        capture = module(R2/'capture-job-private.py', 'own_capture')
        parser = module(R2/'closed-boot-parser.py', 'own_parser')
        guard = module(GUARD, 'own_b78')
        validate(grant, capture, hashlib.sha256(public_bytes(Path(__file__))).hexdigest())
        need(identity(os.fstat(private_fd)) == grant['private_directory_identity']
            and os.fstat(private_fd).st_uid == 1000
            and stat.S_IMODE(os.fstat(private_fd).st_mode) == 0o700, 'PRIVATE_DIR')
        need(identity(os.fstat(own_fd)) == grant['outer_directory_identity']
            and os.fstat(own_fd).st_uid == 1000
            and stat.S_IMODE(os.fstat(own_fd).st_mode) == 0o700, 'OUTPUT_PARENT')
        try:
            os.stat('job.log.private', dir_fd=private_fd, follow_symlinks=False)
        except FileNotFoundError:
            pass
        else:
            raise Gate('PRIVATE_LEAF_ALREADY_EXISTS')
        binding = json.loads(public_bytes(R2/'binding.actual.safe.json'))
        parser.validate_binding(binding)
        baseline = os.statvfs('/workspace')
        baseline = baseline.f_bavail * baseline.f_frsize

        def resources(active=True):
            ws, tmp = os.statvfs('/workspace'), os.statvfs('/tmp')
            workspace_free, tmp_free = ws.f_bavail*ws.f_frsize, tmp.f_bavail*tmp.f_frsize
            shared = int(Path('/sys/fs/cgroup/memory.current').read_text())
            table = guard.process_table()
            owned = guard.owned_records(table, os.getpid(), 0, latest_ids)
            rss = 0
            for pid in {os.getpid(), *owned}:
                try:
                    for line in (Path('/proc')/str(pid)/'status').read_text().splitlines():
                        if line.startswith('VmRSS:'):
                            rss += int(line.split()[1])*1024
                            break
                except (FileNotFoundError, ProcessLookupError):
                    continue
            need(workspace_free >= 4294967296 and tmp_free >= 4294967296
                and max(0, baseline-workspace_free) <= 268435456
                and shared+1073741824 < 16106127360 and rss <= 536870912, 'RESOURCE')
            snap = {'workspace_free':workspace_free,'tmp_free':tmp_free,
                'shared_bytes':shared,'sampled_owned_RSS':rss,
                'workspace_net_consumed':max(0,baseline-workspace_free)}
            # UTC LAST: no expensive measurements after this gate.
            now = dt.datetime.now(dt.timezone.utc)
            start = dt.datetime.fromisoformat(grant['not_before'])
            stop = dt.datetime.fromisoformat(grant['cleanup_gate'] if active else grant['hard_stop'])
            need(start <= now < stop, 'DEADLINE')
            snap['utc'] = now.isoformat()
            return snap

        def write_bytes(fd, data, active=False):
            offset = 0
            while offset < len(data):
                resources(active)
                n = os.write(fd, data[offset:offset+65536])
                need(n > 0, 'SAFE_WRITE')
                offset += n

        def save(name, value):
            data = (json.dumps(value, separators=(',', ':'))+'\n').encode()
            need(len(data) <= 65536, 'SAFE_SIZE')
            resources(False)
            fd = os.open(name, os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,
                0o600, dir_fd=out_fd)
            try:
                write_bytes(fd, data)
            finally:
                os.close(fd)  # Unbuffered FD; no implicit failure-close writes.

        start_snap = resources()
        remaining = (dt.datetime.fromisoformat(grant['cleanup_gate'])
            - dt.datetime.fromisoformat(start_snap['utc'])).total_seconds()
        need(remaining >= 55, 'INSUFFICIENT_PHASE_AND_SETTLEMENT_WINDOW')
        resources()
        os.mkdir('actual-read01', mode=0o700, dir_fd=own_fd)
        out_fd = os.open('actual-read01', os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW, dir_fd=own_fd)
        supervisor = guard.process_table()[os.getpid()]
        save('supervisor.safe.json', {'pid':supervisor['pid'],'start_ticks':supervisor['start_ticks'],
            'grant_phase_seconds':45,'resources':start_snap,'raw_output':False})

        def observe():
            try:
                resources()
            except Gate as caught:
                return 'RESOURCE_GUARD' if caught.args[0]=='RESOURCE' else 'BOUNDED_DEADLINE'
            return None

        def status(value):
            nonlocal status_ordinal
            changed = False
            rows = value['members_including_Z']
            child = guard.process_table().get(value['child_pid'])
            if child is not None:
                rows = rows+[child]
            for row in rows:
                pid, ticks = row['pid'], row['start_ticks']
                need(pid not in latest_ids or latest_ids[pid] == ticks, 'BIRTH_IDENTITY')
                if pid not in latest_ids:
                    latest_ids[pid] = ticks
                    changed = True
            if changed or value['state'] != 'RUNNING':
                status_ordinal += 1
                save(f'status-{status_ordinal}.safe.json', value)

        stage = 'CAPTURE'
        env = explicit_environment(os.environ)
        result = guard.run_owned(['/usr/bin/python3',str(R2/'capture-job-private.py'),
            '--grant',str(GRANT)], cwd=str(OWN), env=env, deadline_seconds=45,
            term_seconds=5, kill_seconds=5, observe=observe, status=status)
        env.clear()  # Never persist credentials/context.
        for row in result['known_owned_identities']:
            latest_ids[row['pid']] = row['start_ticks']
        table = guard.process_table()
        absent = all(pid not in table or table[pid]['start_ticks']!=ticks for pid,ticks in latest_ids.items())
        try:
            captured = os.stat('job.log.private', dir_fd=private_fd, follow_symlinks=False)
            capture_leaf_identity = identity(captured)
        except FileNotFoundError:
            pass
        save('capture-terminal.safe.json', {'result':result,'all_known_births_absent':absent})
        need(result['settled'] and result['all_owned_processes_reaped'] and absent, 'UNSETTLED')

        log_fd = None
        def safe_open(name, flags, *, dir_fd):
            nonlocal log_fd
            need(name=='job.log.private' and dir_fd==private_fd
                and flags==os.O_RDONLY|os.O_NOFOLLOW,'READ_SCOPE')
            resources()
            fd=os.open(name,flags,dir_fd=dir_fd)
            try:
                leaf=os.fstat(fd)
                need(capture_leaf_identity is not None and identity(leaf)==capture_leaf_identity
                    and stat.S_ISREG(leaf.st_mode) and leaf.st_uid==1000
                    and stat.S_IMODE(leaf.st_mode)==0o600 and leaf.st_nlink==1,'READ_IDENTITY')
            except BaseException:
                os.close(fd)
                raise
            log_fd=fd
            return fd
        def safe_read(fd, count):
            need(fd==log_fd and count==33554433,'READ_SCOPE')
            resources()
            return os.read(fd,count)
        def safe_unlink(name, *, dir_fd):
            need(name=='job.log.private' and dir_fd==private_fd, 'CLEANUP_SCOPE')
            leaf=os.stat(name,dir_fd=dir_fd,follow_symlinks=False)
            need(identity(leaf)==capture_leaf_identity and stat.S_ISREG(leaf.st_mode)
                and leaf.st_uid==1000 and stat.S_IMODE(leaf.st_mode)==0o600
                and leaf.st_nlink==1,'CLEANUP_IDENTITY')
            resources(False)
            os.unlink(name, dir_fd=dir_fd)
        # Exact cleanup-clock adapter only; approved parser source stays frozen.
        parser.os = SimpleNamespace(O_RDONLY=os.O_RDONLY,O_NOFOLLOW=os.O_NOFOLLOW,
            open=safe_open,fstat=os.fstat,read=safe_read,close=os.close,stat=os.stat,unlink=safe_unlink)
        need(result['phase_success'] and result['native_exit']==0, 'CAPTURE_FAILED')
        stage = 'PARSE'
        resources()
        projection = parser.consume_private(private_fd, binding)  # One private read.
        cleanup_state = 'REMOVED'
        stage = 'PUBLISH'
        final = {'state':'CLOSED_DIAGNOSTIC_COMPLETE','binding':binding,'projection':projection,
            'cleanup_state':cleanup_state,'resources':resources(False),
            'settled':True,'all_known_births_absent':absent,'cause':'UNKNOWN'}
        save('REPORT.safe.json', final)
        return 0
    except BaseException as caught:
        # Never retain message/traceback/note, ENV or raw private bytes/hash.
        error = type(caught).__name__ if type(caught).__name__ in {
            'Gate','Blocked','OSError','PermissionError','FileNotFoundError',
            'RuntimeError','ValueError','KeyError','KeyboardInterrupt'} else 'OTHER'
        if out_fd is not None and grant is not None:
            try:
                leaf = os.stat('job.log.private',dir_fd=private_fd,follow_symlinks=False)
            except FileNotFoundError:
                cleanup_state='ABSENT'
            except BaseException:
                cleanup_state='UNKNOWN_RECONCILIATION_REQUIRED'
            else:
                # PARSE has already performed its single approved cleanup
                # attempt. Never repeat an ambiguous/denied unlink automatically.
                if (stage=='CAPTURE' and result is not None and result['settled']
                    and result['all_owned_processes_reaped'] and capture_leaf_identity is not None):
                    try:
                        need(identity(leaf)==capture_leaf_identity and stat.S_ISREG(leaf.st_mode)
                            and leaf.st_uid==1000 and stat.S_IMODE(leaf.st_mode)==0o600
                            and leaf.st_nlink==1,'CLEANUP_METADATA')
                        resources(False)
                        fresh_leaf=os.stat('job.log.private',dir_fd=private_fd,follow_symlinks=False)
                        need(identity(fresh_leaf)==capture_leaf_identity and stat.S_ISREG(fresh_leaf.st_mode)
                            and fresh_leaf.st_nlink==1,'CLEANUP_DRIFT')
                        resources(False)
                        os.unlink('job.log.private',dir_fd=private_fd)
                        cleanup_state='REMOVED'
                    except BaseException:
                        cleanup_state='UNKNOWN_RECONCILIATION_REQUIRED'
                else:
                    cleanup_state='UNKNOWN_RECONCILIATION_REQUIRED'
            try:
                save('FAILURE.safe.json',{'state':'DIAGNOSTIC_FAILED','stage':stage,
                    'error_class':error,'cleanup_state':cleanup_state,
                    'cause':'UNKNOWN','raw_output':False})
            except BaseException:
                pass  # Preserve partial safe receipts, not false terminal proof.
        return 1
    finally:
        if out_fd is not None:
            os.close(out_fd)
        os.close(private_fd)
        os.close(own_fd)

if __name__ == '__main__':
    try:
        native = main()
    except BaseException:
        # Default closed failure even before safe output namespace was created.
        native = 1
    raise SystemExit(native)
