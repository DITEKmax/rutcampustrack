/* Source-only helper: no MCP call, output, filesystem access, or service-key guesses. */
function bootTextCarrier(result) {
  const limit = 33554432;
  const reject = () => { throw new Error('BOOT_BRIDGE_BLOCKED'); };
  const own = (value, key) => {
    if (value === null || typeof value !== 'object') reject();
    const d = Object.getOwnPropertyDescriptor(value, key);
    if (!d || !Object.prototype.hasOwnProperty.call(d, 'value')) reject();
    return d.value;
  };
  try {
    if (result === null || typeof result !== 'object') reject();
    const err = Object.getOwnPropertyDescriptor(result, 'isError');
    if (err && (!Object.prototype.hasOwnProperty.call(err, 'value') || err.value !== false)) reject();
    const content = own(result, 'content');
    if (!Array.isArray(content) || own(content, 'length') !== 1) reject();
    const block = own(content, '0');
    if (own(block, 'type') !== 'text') reject();
    const text = own(block, 'text');
    if (typeof text !== 'string' || text.length === 0 || text.length > limit) reject();
    // Count both UTF8 payload and ASCII JSON carrier BEFORE allocating encoded copies.
    const prefix = '{"schema":1,"repo":"DITEKmax/rutcampustrack","job_id":115262001797,"producer_head":"1742d1e806faa5c39c6d182a3554daa8f4239801","text":';
    let utf8 = 0, encoded = prefix.length + 3; // quotes plus closing object
    for (let i = 0; i < text.length; i++) {
      const c = text.charCodeAt(i);
      if (c === 0) reject();
      if (c >= 0xd800 && c <= 0xdbff) {
        const low = text.charCodeAt(++i);
        if (!(low >= 0xdc00 && low <= 0xdfff)) reject();
        utf8 += 4; encoded += 12;
      } else {
        if (c >= 0xdc00 && c <= 0xdfff) reject();
        utf8 += c < 0x80 ? 1 : c < 0x800 ? 2 : 3;
        encoded += c >= 0x7f ? 6 : c === 34 || c === 92 || [8,9,10,12,13].includes(c) ? 2 : c < 32 ? 6 : 1;
      }
      if (utf8 > limit || encoded > limit) reject();
    }
    const carrier = prefix + JSON.stringify(text).replace(/[\u007f-\uffff]/g,
      c => '\\u' + c.charCodeAt(0).toString(16).padStart(4, '0')) + '}';
    if (carrier.length !== encoded || carrier.length > limit || /[^\x20-\x7e]/.test(carrier)) reject();
    return carrier;
  } catch (_) {
    // Never propagate connector text, accessor exceptions, class names, or messages.
    throw new Error('BOOT_BRIDGE_BLOCKED');
  }
}
