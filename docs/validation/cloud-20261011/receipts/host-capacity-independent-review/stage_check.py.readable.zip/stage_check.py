from pathlib import Path, PurePosixPath
import datetime, hashlib, io, json, os, stat, zipfile

OUT=Path('/workspace/scratch/rct-validation/host_capacity_review')
PLAN=Path('/workspace/scratch/rct-validation/host_capacity_plan')
COPIED=Path('/workspace/rutcampustrack/docs/validation/cloud-20261011/receipts/host-capacity-plan')
def sha_stream(stream):
    h=hashlib.sha256()
    for data in iter(lambda:stream.read(1024*1024),b''): h.update(data)
    return h.hexdigest()
def file_sha(path):
    with path.open('rb') as stream:return sha_stream(stream)
parts=json.loads((COPIED/'immutable-container-parts.json').read_text());data=bytearray()
for part in parts['parts']:
    p=COPIED/part['path'];assert p.stat().st_size==part['bytes'] and file_sha(p)==part['sha256'];data.extend(p.read_bytes())
assert len(data)==parts['original_bytes'] and hashlib.sha256(data).hexdigest()==parts['original_sha256']
manifest=json.loads((PLAN/'manifest.json').read_text())
with zipfile.ZipFile(io.BytesIO(data)) as archive:
    archived_names=set(archive.namelist())
    for item in manifest['files']:
        name=Path(item['path']).name
        assert name in archived_names
        with archive.open(name) as stream: assert sha_stream(stream)==item['sha256']
    with archive.open('manifest.json') as stream: assert sha_stream(stream)==file_sha(PLAN/'manifest.json')
del data
preserved=[]
for item in json.loads((PLAN/'preservation-before.json').read_text()):
    p=Path(item['manifest']);assert file_sha(p)==item['sha256'];m=json.loads(p.read_text());files=m.get('safe_files',m.get('files'))
    for entry in files:
        p=Path(entry['path']);assert p.stat().st_size==entry['bytes'] and file_sha(p)==entry['sha256']
    preserved.append({'manifest':item['manifest'],'sha256':item['sha256'],'files':len(files)})
distinct=set();source_distinct=set();svc=[];dir_paths=0
for p in sorted(PLAN.glob('stage-*.json')):
    m=json.loads(p.read_text());jar=Path(m['jar']);assert file_sha(jar)==m['jar_sha256']
    old=jar.lstat();assert stat.S_IMODE(old.st_mode)==int(m['jar_source_mode'],8)
    rows=m['entries'];expected={r['path']:r for r in rows};assert len(expected)==len(rows)
    service_dirs=set();regular_count=0;source_modes={};target_modes={}
    with zipfile.ZipFile(jar) as z:
        names=[i.filename for i in z.infolist()];assert len(set(names))==len(names)
        final_files=set(expected)
        for name in final_files:
            path_parts=PurePosixPath(name).parts
            assert str(PurePosixPath(name))==name and not name.startswith('/') and '..' not in path_parts and '\\' not in name
            ancestors=[str(v) for v in PurePosixPath(name).parents if str(v)!='.'];assert not set(ancestors)&final_files
            service_dirs.update(ancestors)
        for item in z.infolist():
            filetype=(item.external_attr>>16)&0o170000;assert filetype in (0,0o100000,0o040000)
            if item.is_dir():continue
            regular_count+=1;row=expected[item.filename]
            mode=((item.external_attr>>16)&0o777) or 0o644;target=0o644|(mode&0o111)
            assert int(row['zip_mode'],8)==mode and int(row['proposed_NEW_public_payload_mode'],8)==target
            assert item.file_size==row['bytes']
            with z.open(item) as stream:assert sha_stream(stream)==row['sha256']
            source_distinct.add((row['sha256'],mode,row['bytes']));distinct.add((row['sha256'],target,row['bytes']))
            source_modes[oct(mode)]=source_modes.get(oct(mode),0)+1;target_modes[oct(target)]=target_modes.get(oct(target),0)+1
        idx=z.read('BOOT-INF/layers.idx').decode();patterns={};layer=None
        for line in idx.splitlines():
            if line.startswith('- '):layer=json.loads(line[2:].removesuffix(':'));patterns[layer]=[]
            elif line.startswith('  - '):patterns[layer].append(json.loads(line[4:]))
            elif line.strip():raise AssertionError('unexpected layer index syntax')
        assert list(patterns)==m['ordered_layers']==['dependencies','spring-boot-loader','snapshot-dependencies','application']
        for row in rows:
            matches=[k for k,values in patterns.items() if any(row['path']==v or v.endswith('/') and row['path'].startswith(v) for v in values)]
            assert matches==[row['layer']]
        text=z.read('META-INF/MANIFEST.MF').decode().replace('\r\n','\n');unfolded=[]
        for line in text.splitlines():
            if line.startswith(' '):unfolded[-1]+=line[1:]
            elif line:unfolded.append(line)
        attrs={k:v for k,v in (line.split(': ',1) for line in unfolded if ': ' in line)}
        for k in ['Main-Class','Start-Class']:assert attrs[k]==m['unfolded_manifest'][k]
        assert attrs['Main-Class']=='org.springframework.boot.loader.launch.JarLauncher'
        for needed in ['META-INF/MANIFEST.MF','BOOT-INF/layers.idx','BOOT-INF/classpath.idx','org/springframework/boot/loader/launch/JarLauncher.class','BOOT-INF/classes/'+attrs['Start-Class'].replace('.','/')+'.class']:assert needed in expected
    new=jar.lstat();assert (new.st_dev,new.st_ino,new.st_mtime_ns,new.st_size,new.st_mode)==(old.st_dev,old.st_ino,old.st_mtime_ns,old.st_size,old.st_mode)
    dir_paths+=len(service_dirs);svc.append({'service':m['service'],'entries':regular_count,'jar_sha256':m['jar_sha256'],'jar_mode_unchanged':True,'source_modes':source_modes,'target_modes':target_modes,'rounded_undeduplicated_file_bytes':sum((r['bytes']+4095)//4096*4096 for r in rows)})
summary={'time':datetime.datetime.now(datetime.timezone.utc).isoformat(),'immutable_original_archive_sha256':parts['original_sha256'],'original36plus_manifest_members_verified':True,'preserved_original_receipt_files':sum(x['files'] for x in preserved),'preserved_manifests':preserved,'services':svc,'all_regular_entries':sum(x['entries'] for x in svc),'unique_source_mode_SHA_size':len(source_distinct),'unique_target_mode_SHA_size':len(distinct),'logical_unique_bytes':sum(x[2] for x in distinct),'rounded4KiB_unique_file_bytes':sum((x[2]+4095)//4096*4096 for x in distinct),'directory_paths':dir_paths,'source_JARs_mode_metadata_unchanged':True,'traversal_duplicate_nonregular_file_dir_collision_checks':True,'full_4_layer_union_verified':True,'actual_staging':'NOT_RUN','actual_recovery_bytes':0,'resource_mutations':False}
(OUT/'independent-staging-check.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps({k:v for k,v in summary.items() if k not in ['preserved_manifests','services']}))
