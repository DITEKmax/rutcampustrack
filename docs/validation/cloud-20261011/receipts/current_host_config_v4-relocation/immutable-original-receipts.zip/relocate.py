"""Exact owned vendor cache relocation, verified before duplicate retirement."""
import collections
import datetime
import hashlib
import json
import os
from pathlib import Path
import shutil
import stat

OLD = Path('/workspace/scratch/rct-validation/real_client_runtime/browsers')
NEW = Path('/tmp/rct-validation-browsers-20261012')
RETIRED = OLD.with_name('browsers.retired-own-20261012')
LINK_TEMP = OLD.with_name('.browsers-link-rct-20261012')
OUT = Path(__file__).parent
os.umask(0o077)

def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()

def save(name, value):
    path = OUT / name
    with path.open('w') as stream:
        stream.write(json.dumps(value, indent=2) + '\n'); stream.flush(); os.fsync(stream.fileno())

def free(root):
    fs = os.statvfs(root)
    return fs.f_bavail * fs.f_frsize

def allocated(root):
    identities = set(); count = 0
    for path in [root, *root.rglob('*')]:
        value = path.lstat(); identity = value.st_dev, value.st_ino
        if identity not in identities:
            identities.add(identity); count += value.st_blocks * 512
    return count

def digest(path):
    result = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1048576), b''):
            result.update(block)
    return result.hexdigest()

def absent():
    matching = []
    for path in Path('/proc').iterdir():
        if not path.name.isdigit():
            continue
        try:
            exe = os.readlink(path / 'exe'); comm = (path / 'comm').read_text().strip()
        except OSError:
            continue
        if exe.startswith(str(OLD) + '/') or exe.startswith(str(NEW) + '/') or comm.lower() in {'chrome', 'chromium', 'headless_shell', 'minibrowser', 'webkitnetworkprocess', 'webkitwebprocess', 'playwright'}:
            matching.append({'pid': int(path.name), 'comm': comm, 'exe': exe})
    if matching:
        raise RuntimeError('Browser process present; no duplicate retirement')
    return True

assert OLD.is_dir() and not OLD.is_symlink() and OLD.stat().st_uid == os.getuid()
assert not NEW.exists() and not RETIRED.exists() and not LINK_TEMP.exists()
assert OLD.stat().st_dev != Path('/tmp').stat().st_dev
absent(); old_allocated = allocated(OLD)
assert free('/tmp') - old_allocated - 8388608 >= 4294967296
registry = []; hard = collections.defaultdict(list)
for path in [OLD, *sorted(OLD.rglob('*'))]:
    st = path.lstat(); relative = str(path.relative_to(OLD))
    assert st.st_uid == os.getuid() and st.st_dev == OLD.stat().st_dev
    row = {'relative': relative, 'mode': stat.S_IMODE(st.st_mode), 'uid': st.st_uid, 'gid': st.st_gid,
           'mtime_ns': st.st_mtime_ns, 'device': st.st_dev, 'inode': st.st_ino, 'nlink': st.st_nlink,
           'bytes': st.st_size, 'allocated': st.st_blocks * 512, 'ctime_ns': st.st_ctime_ns}
    if stat.S_ISREG(st.st_mode):
        row['kind'] = 'file'; row['sha256'] = digest(path); hard[(st.st_dev, st.st_ino)].append(row)
    elif stat.S_ISDIR(st.st_mode):
        row['kind'] = 'directory'
    elif stat.S_ISLNK(st.st_mode):
        row['kind'] = 'symlink'; row['target'] = os.readlink(path)
        assert not os.path.isabs(row['target']) and OLD in path.resolve(strict=True).parents
    else:
        raise RuntimeError('Unexpected cache node')
    registry.append(row)
assert all(rows[0]['nlink'] == len(rows) for rows in hard.values())
save('source-registry.safe.json', {'utc': now(), 'old_path': str(OLD), 'entries': registry, 'allocated_bytes': old_allocated,
                                  'external_hardrefs': 0, 'absolute_or_escaping_symlinks': 0, 'process_absence': True})
save('launch.safe.json', {'utc': now(), 'pid': os.getpid(), 'source_allocated': old_allocated,
                        'workspace_free_before_copy': free(OLD), 'tmp_free_before_copy': free('/tmp'), 'phase': 'COPY'})
count = 0

def copy(source, target):
    global count
    assert free('/tmp') >= 4294967296 + Path(source).stat().st_blocks * 512
    result = shutil.copy2(source, target)
    count += 1
    if count % 25 == 0:
        save('CURRENT.json', {'utc': now(), 'phase': 'COPY', 'pid': os.getpid(), 'regular_files_copied': count, 'tmp_free': free('/tmp')})
    return result

shutil.copytree(OLD, NEW, symlinks=True, copy_function=copy)
# Verify every byte/mode/link before the old duplicate can be retired.
for row in registry:
    original = OLD / row['relative']; target = NEW / row['relative']; st = original.lstat(); new = target.lstat()
    assert (st.st_dev, st.st_ino, st.st_size, st.st_mtime_ns, st.st_ctime_ns, st.st_nlink) == (row['device'], row['inode'], row['bytes'], row['mtime_ns'], row['ctime_ns'], row['nlink'])
    assert stat.S_IMODE(new.st_mode) == row['mode'] and new.st_uid == row['uid'] and new.st_gid == row['gid']
    assert new.st_mtime_ns == row['mtime_ns']
    if row['kind'] == 'file':
        assert digest(original) == row['sha256'] == digest(target)
    elif row['kind'] == 'symlink':
        assert os.readlink(original) == row['target'] == os.readlink(target)
    else:
        assert target.is_dir()
assert len([NEW, *NEW.rglob('*')]) == len(registry)
absent(); assert free('/tmp') >= 4294967296
save('copy-verified.safe.json', {'utc': now(), 'files': count, 'entries': len(registry), 'all_regular_sha_modes_mtime_UIDGID_link_targets_equal': True,
                               'tmp_allocated_bytes': allocated(NEW), 'tmp_free_after_copy': free('/tmp'), 'original_duplicate_still_present': True})
# Exact known cache aliases only. Publish complete preserved target before removing duplicate.
workspace_before = free(OLD)
os.symlink(str(NEW), LINK_TEMP)
save('retirement-journal.safe.json', {'utc': now(), 'phase': 'BEFORE_RENAME', 'old': str(OLD), 'retired': str(RETIRED), 'link_temp': str(LINK_TEMP),
                                    'new': str(NEW), 'copy_verified': True, 'workspace_free_before_retirement': workspace_before})
OLD.rename(RETIRED)
os.replace(LINK_TEMP, OLD)
save('retirement-journal.safe.json', {'utc': now(), 'phase': 'OLD_PATH_POINTS_TO_VERIFIED_NEW', 'old': str(OLD), 'retired': str(RETIRED), 'new': str(NEW)})
assert OLD.is_symlink() and os.readlink(OLD) == str(NEW)
for row in registry:
    old_reference = OLD / row['relative']; retired = RETIRED / row['relative']
    if row['kind'] == 'file':
        assert digest(old_reference) == row['sha256'] == digest(retired)
        assert retired.lstat().st_nlink == row['nlink']
    elif row['kind'] == 'symlink':
        assert os.readlink(old_reference) == row['target'] == os.readlink(retired)
absent()
shutil.rmtree(RETIRED)
assert not RETIRED.exists() and not LINK_TEMP.exists() and OLD.resolve() == NEW
workspace_after = free(OLD.parent)
result = {'utc': now(), 'status': 'OWN_CACHE_RELOCATED_PRESERVED_VERIFIED_OLD_REFERENCE_WORKS', 'old': str(OLD), 'new': str(NEW),
          'source_device': registry[0]['device'], 'target_device': NEW.stat().st_dev, 'source_allocated_bytes_retired': old_allocated,
          'target_allocated_bytes': allocated(NEW), 'regular_files': count, 'entries': len(registry),
          'all_bytes_modes_mtime_UIDGID_symlinktargets_verified': True, 'browser_processes_absent_before_copy_before_retirement': True,
          'old_reference_symlink_exact': True, 'retired_duplicate_absent': True,
          'workspace_free_before_retirement': workspace_before, 'workspace_free_after_retirement': workspace_after,
          'observed_free_gain_during_retirement': workspace_after - workspace_before,
          'concurrent_Root_dedup2': 'POSSIBLE; net free delta is not uniquely attributed; exact own retired allocation separately proven',
          'tmp_free_after': free('/tmp'), 'tmp_floor': 4294967296,
          'browser_versions_preserved': sorted(p.name for p in NEW.iterdir()), 'browser_launch': 'NOT_RUN'}
save('relocation-terminal.safe.json', result); save('CURRENT.json', result)
print(json.dumps({'status': result['status'], 'own_retired_allocated': old_allocated, 'observed_free_gain': result['observed_free_gain_during_retirement'],
                  'workspace_free': workspace_after, 'tmp_free': result['tmp_free_after'], 'regular_files': count}))
