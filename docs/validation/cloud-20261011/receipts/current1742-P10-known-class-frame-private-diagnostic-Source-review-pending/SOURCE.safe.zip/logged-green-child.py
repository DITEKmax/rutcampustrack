"""Existing NP01 private-Gradle-output pattern, narrowed to one coherent main/test compile and targeted unit invocation."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import stat
import subprocess
import sys
import io
import re
import urllib.request
import urllib.parse
import zipfile
import xml.etree.ElementTree as ET
from pathlib import PurePosixPath

CLASS = "ru.rutcampustrack.auth.integration.AuthOtpFlowIT"
METHOD = "unicodePasswordChangeAndResetPreserveExactCredentialsAtHttpBoundaries"
SOURCE_SHA = "104e98b35098b82e201497b5db7d037d7fa2caa2acd1a023d27f291e4e0aa9b8"
TYPES = {
    "java.lang.AssertionError": "ASSERTION_ERROR",
    "org.opentest4j.AssertionFailedError": "ASSERTION_FAILED",
    "org.opentest4j.MultipleFailuresError": "MULTIPLE_FAILURES",
    "java.lang.IllegalStateException": "ILLEGAL_STATE",
    "java.lang.NullPointerException": "NULL_POINTER",
    "org.springframework.jdbc.BadSqlGrammarException": "JDBC_BAD_SQL",
    "org.springframework.dao.DataIntegrityViolationException": "JDBC_CONSTRAINT",
    "org.springframework.dao.DataAccessResourceFailureException": "JDBC_RESOURCE",
    "org.springframework.jdbc.CannotGetJdbcConnectionException": "JDBC_CONNECTION",
    "org.springframework.web.client.ResourceAccessException": "HTTP_TRANSPORT",
    "java.util.concurrent.TimeoutException": "TIMEOUT",
}
HELPERS = {
    METHOD: "TEST_BODY",
    "seedUnicodePasswordActor": "SEED_ACTOR",
    "unicodePasswordPost": "HTTP_PASSWORD_POST",
    "assertUnicodePasswordRejection": "REJECTION_ORACLE",
    "unicodePasswordState": "PROTECTED_STATE",
    "assertUnicodePasswordCommitted": "COMMITTED_CREDENTIAL_ORACLE",
    "unicodePasswordLogin": "POSITIVE_LOGIN",
    "assertUnicodePasswordLoginDenied": "DENIED_LOGIN",
    "cleanUnicodePasswordActors": "ACTOR_CLEANUP",
    "bearerSessionStatus": "BEARER_ADMISSION",
    "refreshStatus": "REFRESH_ADMISSION",
    "receiveWithRetry": "OTP_EVENT_WAIT",
}

class DiagnosticBlocked(ValueError):
    def __init__(self, code):
        self.code = code
        super().__init__("CLOSED_DIAGNOSTIC_REJECTION")

def need(value, code):
    if not value:
        raise DiagnosticBlocked(code)

def selected_xml_projection(body, source_line_count):
    need(type(body) is bytes and len(body) <= 1024**2, "XML_SIZE")
    try:
        xml_text = body.decode("utf-8-sig")
    except UnicodeDecodeError:
        raise DiagnosticBlocked("XML_UTF8") from None
    need("\x00" not in xml_text and "<!DOCTYPE" not in xml_text and "<!ENTITY" not in xml_text,
         "XML_DTD_ENTITY_NUL")
    if re.match(r"<\?xml(?:[ \t\r\n]|\?>)", xml_text):
        declaration = re.match(
            r"""<\?xml[ \t\r\n]+version[ \t\r\n]*=[ \t\r\n]*(['"])1\.0\1"""
            r"""(?:[ \t\r\n]+encoding[ \t\r\n]*=[ \t\r\n]*(['"])(?i:UTF-8)\2)?"""
            r"""(?:[ \t\r\n]+standalone[ \t\r\n]*=[ \t\r\n]*(['"])(?:yes|no)\3)?"""
            r"[ \t\r\n]*\?>", xml_text)
        need(declaration is not None, "XML_DECLARATION")
    try:
        suite = ET.fromstring(xml_text)
    except ET.ParseError:
        raise DiagnosticBlocked("XML_SYNTAX") from None
    need(suite.tag == "testsuite" and suite.get("name") == CLASS, "XML_SUITE_IDENTITY")
    counts = {}
    for key in ["tests", "failures", "errors", "skipped"]:
        value = suite.get(key)
        need(type(value) is str and re.fullmatch(r"[0-9]{1,2}", value), "XML_COUNTS")
        counts[key] = int(value)
    cases = suite.findall("testcase")
    need(counts == {"tests": 9, "failures": 1, "errors": 0, "skipped": 0}
         and len(cases) == 9, "XML_CASE_COUNTS")
    selected = [c for c in cases if c.get("classname") == CLASS
                and c.get("name") in {METHOD, METHOD + "()"}]
    need(len(selected) == 1, "XML_SELECTED_IDENTITY")
    case = selected[0]
    failures = case.findall("failure")
    need(len(failures) == 1 and case.find("error") is None and case.find("skipped") is None
         and sum(len(c.findall("failure")) for c in cases) == 1
         and not any(c.find("error") is not None or c.find("skipped") is not None for c in cases),
         "XML_SELECTED_FAILURE")
    failure = failures[0]
    captured_type = failure.get("type")
    need(captured_type is None or len(captured_type) <= 256, "XML_TYPE_CAP")
    type_code = TYPES.get(captured_type, "UNKNOWN")
    # No message attribute is accessed. Stack contents never leave this bounded RAM projection.
    stack = failure.text or ""
    need(len(stack) <= 65536, "STACK_CAP")
    lines = stack.splitlines()
    need(len(lines) <= 256 and all(len(line) <= 2048 for line in lines), "STACK_LINE_CAP")
    first_line = 0
    helper = "UNKNOWN"
    frame = re.compile(r"[ \t]*at ru\.rutcampustrack\.auth\.integration\.AuthOtpFlowIT\."
                       r"([A-Za-z_$][A-Za-z0-9_$]{0,127})\(AuthOtpFlowIT\.java:([1-9][0-9]{0,5})\)[ \t]*")
    for line in lines:
        match = frame.fullmatch(line)
        if match is None:
            continue
        first_line = int(match.group(2))
        need(1 <= first_line <= source_line_count, "FRAME_SOURCE_LINE")
        helper = HELPERS.get(match.group(1), "UNKNOWN")
        if helper == "UNKNOWN":
            synthetic = re.fullmatch(r"lambda\$(seedUnicodePasswordActor|cleanUnicodePasswordActors)\$[0-9]{1,2}",
                                     match.group(1))
            if synthetic:
                helper = HELPERS[synthetic.group(1)]
        break
    return {"schema": "P10_CURRENT_FAILURE_FRAME_V1", "selected_xml_valid": True,
            "counts": counts, "selected_failed_cases": 1, "exception_code": type_code,
            "known_exception_class": captured_type if type_code != "UNKNOWN" else "UNKNOWN",
            "first_auth_frame_found": first_line != 0, "source_line": first_line,
            "helper": helper, "source_sha256": SOURCE_SHA,
            "message_body_stack_or_private_hash_export": False,
            "cause_acceptance": "NOT_ASSESSED_LOCATION_ONLY"}

def selected_xml_from_zip(data):
    need(type(data) is bytes and len(data) <= 1024**2, "ZIP_SIZE")
    try:
        with zipfile.ZipFile(io.BytesIO(data)) as archive:
            infos = archive.infolist()
            need(0 < len(infos) <= 512, "ZIP_MEMBER_COUNT")
            names = set()
            selected = []
            allowed = {
                "auth-service/auth-app/build/test-results/integrationTest/TEST-" + CLASS + ".xml",
                "services/auth-service/auth-app/build/test-results/integrationTest/TEST-" + CLASS + ".xml",
            }
            total = 0
            for info in infos:
                name = info.filename
                path = PurePosixPath(name)
                need(info.orig_filename == name and len(name) <= 512 and "\\" not in name and "\x00" not in name
                     and not path.is_absolute() and ".." not in path.parts and ":" not in name
                     and name.rstrip("/") == str(path) and name not in names, "ZIP_MEMBER_PATH")
                names.add(name)
                mode = (info.external_attr >> 16) & 0xffff
                need(not stat.S_ISLNK(mode) and not info.flag_bits & 1, "ZIP_MEMBER_KIND")
                need(info.file_size <= 32*1024**2 and info.compress_size <= 1024**2, "ZIP_MEMBER_SIZE")
                total += info.file_size
                need(total <= 32*1024**2, "ZIP_TOTAL_SIZE")
                if name in allowed:
                    selected.append(info)
            need(len(selected) == 1, "ZIP_SELECTED_COUNT")
            info = selected[0]
            need(not info.is_dir() and info.file_size <= 1024**2, "ZIP_SELECTED_SIZE")
            with archive.open(info) as stream:
                body = stream.read(1024**2 + 1)
            need(len(body) == info.file_size and len(body) <= 1024**2, "ZIP_SELECTED_READ")
            # Read only the single selected member; no testzip, extract, HTML or other XML reads.
            return body
    except DiagnosticBlocked:
        raise
    except (zipfile.BadZipFile, OSError, RuntimeError, EOFError, ValueError):
        raise DiagnosticBlocked("ZIP_SYNTAX") from None

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def private_json(path):
    if path.resolve() != path.absolute():
        raise ValueError("No-follow private input required")
    descriptor = os.open(path, os.O_RDONLY | os.O_NOFOLLOW)
    with os.fdopen(descriptor, "rb") as stream:
        info = os.fstat(stream.fileno())
        if not stat.S_ISREG(info.st_mode) or info.st_mode & 0o777 != 0o600 or info.st_size > 65536:
            raise ValueError("Bounded mode600 private input required")
        return json.loads(stream.read(65537))

def identity(pid):
    fields = (Path("/proc") / str(pid) / "stat").read_text().rsplit(")", 1)[1].split()
    if fields[0] == "Z":
        raise ValueError("Live process required")
    return {"pid": pid, "ppid": int(fields[1]), "start_ticks": int(fields[19])}

def admit_child(scope):
    plan_path = scope / "green-plan.safe.json"
    plan = json.loads(plan_path.read_text())
    run = Path(plan["run"])
    if not (os.getcwd() == plan["worktree"] and run.resolve() == run.absolute()
            and run.is_dir() and run.stat().st_mode & 0o777 == 0o700):
        raise ValueError("Exact owned private run and worktree required")
    witness = private_json(run / "parent-authority.private.json")
    parent = identity(os.getppid())
    child = identity(os.getpid())
    driver = scope / "run-green-owned.py"
    if not (witness["parent"]["pid"] == parent["pid"]
            and witness["parent"]["start_ticks"] == parent["start_ticks"]
            and child["ppid"] == parent["pid"] and witness["run"] == str(run)
            and witness["driver_sha256"] == digest(driver)
            and witness["child_sha256"] == digest(Path(__file__))
            and witness["plan_sha256"] == digest(plan_path)):
        raise ValueError("Exact live direct parent and source witness required")
    expected_args = [str(driver).encode(), witness["grant_path"].encode(), witness["grant_sha256"].encode()]
    actual_args = (Path("/proc") / str(parent["pid"]) / "cmdline").read_bytes().split(b"\0")
    if actual_args[1:4] != expected_args or any(actual_args[4:]):
        raise ValueError("Exact granted parent caller required")
    grant_path = Path(witness["grant_path"])
    grant = private_json(grant_path)
    if not (digest(grant_path) == witness["grant_sha256"] and grant["authorized"] is True
            and grant["lease"] == plan["lease"] and grant["source_review_approved"] is True
            and grant["driver_sha256"] == witness["driver_sha256"]
            and grant["child_sha256"] == witness["child_sha256"]
            and grant["plan_sha256"] == witness["plan_sha256"]
            and grant["guard_sha256"] == plan["guard_sha256"]
            and digest(Path(plan["guard_path"])) == plan["guard_sha256"]
            and grant["test_sha256"] == plan["test_sha256"]
            and digest(Path(plan["worktree"]) / plan["test_path"]) == plan["test_sha256"]):
        raise ValueError("Fresh Root grant and exact source required")
    manifest_path = scope / plan["source_manifest"]
    if not (digest(manifest_path) == plan["source_manifest_sha256"]
            and grant["source_manifest_sha256"] == plan["source_manifest_sha256"]):
        raise ValueError("Pinned formatted source manifest required")
    manifest = json.loads(manifest_path.read_text())
    for path, expected in {**manifest["files"], **manifest["protected_files"]}.items():
        if digest(Path(plan["worktree"]) / path) != expected:
            raise ValueError("Formatted source manifest mismatch")
    issued = datetime.datetime.fromisoformat(grant["issued_utc"])
    stop = datetime.datetime.fromisoformat(grant["stop_utc"])
    now = datetime.datetime.now(datetime.timezone.utc)
    if not (issued.tzinfo and stop.tzinfo and issued <= now
            < stop-datetime.timedelta(seconds=grant["limits"]["cleanup_margin_seconds"])):
        raise ValueError("Current grant with cleanup margin required")
    if identity(parent["pid"]) != parent or identity(child["pid"]) != child:
        raise ValueError("Live parent/child identity changed")
    return plan, run

def owned_request(path):
    need(path.resolve() == path.absolute(), "REQUEST_PATH")
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW)
    with os.fdopen(fd, "rb") as stream:
        info = os.fstat(stream.fileno())
        need(stat.S_ISREG(info.st_mode) and info.st_mode & 0o777 == 0o600
             and info.st_nlink == 1 and info.st_uid == os.geteuid() and info.st_size <= 16384,
             "REQUEST_METADATA")
        data = stream.read(16385)
    def pairs(items):
        value = {}
        for key, item in items:
            need(key not in value, "REQUEST_DUPLICATE_KEY")
            value[key] = item
        return value
    try:
        value = json.loads(data.decode("utf-8"), object_pairs_hook=pairs,
                           parse_constant=lambda _: (_ for _ in ()).throw(DiagnosticBlocked("REQUEST_JSON")))
    except (ValueError, UnicodeDecodeError):
        raise DiagnosticBlocked("REQUEST_JSON") from None
    return value, (info.st_dev, info.st_ino)

def observe_original_case(scope):
    plan, run = admit_child(scope)
    grant = private_json(Path(private_json(run / "parent-authority.private.json")["grant_path"]))
    need(grant.get("original_artifact_observation_authorized") is True
         and grant.get("artifact_id") == plan["artifact"]["artifact_id"]
         and grant.get("producer_head") == plan["artifact"]["head_sha"]
         and grant.get("actual_checkout") == plan["actual_checkout"]
         and grant.get("selected_xml_projection_only") is True, "OBSERVATION_GRANT")
    need(digest(scope / "metadata.safe.json") == plan["metadata_sha256"], "METADATA_SOURCE_PIN")
    artifact = json.loads((scope / "metadata.safe.json").read_text())
    need(artifact == plan["artifact"], "METADATA_IDENTITY")
    request_path = scope / ".download-request.private.json"
    request, request_identity = owned_request(request_path)
    try:
        need(type(request) is dict and set(request) == {
                 "artifact_id", "run_id", "name", "size_bytes", "head_sha", "actual_checkout", "private_url"},
             "REQUEST_SCHEMA")
        need(all(request[k] == artifact[k] for k in ["artifact_id", "run_id", "name", "size_bytes", "head_sha"])
             and request["actual_checkout"] == plan["actual_checkout"], "REQUEST_IDENTITY")
        url = request["private_url"]
        need(type(url) is str and 0 < len(url) <= 8192, "REQUEST_URL_CAP")
        parsed = urllib.parse.urlsplit(url)
        need(parsed.scheme == "https" and bool(parsed.hostname) and parsed.username is None
             and parsed.password is None and not parsed.fragment, "REQUEST_URL_SHAPE")
        # Exact URL supplied privately from the approved connector result for this artifact only.
        # Existing bounded download-safe.py urllib pattern, without private archive hashing.
        admit_child(scope)  # Fresh direct-parent/grant/clock admission immediately before download.
        with urllib.request.urlopen(url, timeout=30) as response:
            data = response.read(1024**2 + 1)
        need(len(data) == artifact["size_bytes"] <= 1024**2, "ARTIFACT_SIZE_IDENTITY")
        admit_child(scope)  # Download wait cannot license effects beyond the cleanup margin.
        body = selected_xml_from_zip(data)
        source = Path(plan["worktree"]) / plan["test_path"]
        need(digest(source) == SOURCE_SHA == plan["test_sha256"], "SOURCE_PIN_AFTER_CAPTURE")
        result = selected_xml_projection(body, len(source.read_text().splitlines()))
        descriptor = os.open(run / "selected-auth.raw.private.xml",
                             os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600)
        with os.fdopen(descriptor, "wb") as stream:
            stream.write(body)
        result.update(artifact_id=artifact["artifact_id"], run_id=artifact["run_id"],
                      producer_head=artifact["head_sha"], actual_checkout=plan["actual_checkout"],
                      selected_class=CLASS, selected_method=METHOD, case_status="FAILED",
                      private_selected_xml_retained_unhashed=True, other_members_read_or_extracted=0)
        (run / "case-observation.safe.json").write_text(json.dumps(result, indent=2) + "\n")
        print(json.dumps(result), flush=True)
    finally:
        try:
            info = request_path.stat(follow_symlinks=False)
        except FileNotFoundError:
            info = None
        if info is not None:
            need((info.st_dev, info.st_ino) == request_identity and stat.S_ISREG(info.st_mode)
                 and info.st_nlink == 1 and info.st_uid == os.geteuid(), "REQUEST_CLEANUP_IDENTITY")
            request_path.unlink()

if __name__ == "__main__":
    try:
        observe_original_case(Path(__file__).resolve().parent)
    except DiagnosticBlocked as error:
        print(json.dumps({"schema": "P10_DIAGNOSTIC_BLOCKED_V1", "diagnostic_valid": False,
                          "rejection_code": error.code, "no_private_export": True}), flush=True)
        raise SystemExit(1)
    except BaseException:
        print(json.dumps({"schema": "P10_DIAGNOSTIC_BLOCKED_V1", "diagnostic_valid": False,
                          "rejection_code": "BOUNDARY_UNKNOWN", "no_private_export": True}), flush=True)
        raise SystemExit(1)

