"""Root-authorized bounded single XML/target failure projection; no raw persistence."""
from pathlib import Path,PurePosixPath
import hashlib,io,json,os,re,traceback,urllib.request,zipfile
import xml.etree.ElementTree as ET
OUT=Path(__file__).parent
INPUT=OUT/'.xml-carrier-input.private.json'
MAX=32*1024*1024
METHOD='enumDatabaseAndHttpBoundaryRemainCanonicalUnderTurkishLocale'
CLASS='ru.rutcampustrack.academic.integration.AcademicGrpcIT'
NAME='TEST-'+CLASS+'.xml'
ALLOWED={'org.assertj.core.error.AssertJMultipleFailuresError','org.assertj.core.api.SoftAssertionError','org.opentest4j.MultipleFailuresError','java.lang.AssertionError'}
TAGS={'scalar_active':'/academic/users?status=active&page=0&size=100&sort=id,asc',
      'ADMIN_role':'/academic/users?status=active&role=ADMIN&page=0&size=100&sort=id,asc',
      'ACTIVE_grant':'/academic/users?role=admin&roleStatus=ACTIVE&page=0&size=100&sort=id,asc'}
try:
    inp=json.loads(INPUT.read_text());assert inp['id']==11769312255 and inp['name']=='integration-test-reports-academic-service'
    assert inp['size_in_bytes']==1240766 and inp['size_in_bytes']<MAX
    with urllib.request.urlopen(inp['url'],timeout=30) as response:archive=response.read(MAX+1)
    assert len(archive)==inp['size_in_bytes'] and 'sha256:'+hashlib.sha256(archive).hexdigest()==inp['digest']
    with zipfile.ZipFile(io.BytesIO(archive)) as z:
        candidates=[i for i in z.infolist() if PurePosixPath(i.filename).name==NAME]
        assert len(candidates)==1
        entry=candidates[0];p=PurePosixPath(entry.filename)
        assert not p.is_absolute() and '..' not in p.parts and entry.file_size<=MAX
        # Do not testzip/read any unrelated entry. Selected ZipExtFile verifies selected CRC.
        with z.open(entry) as stream:xml=stream.read(MAX+1)
    assert len(xml)==entry.file_size<=MAX and b'<!DOCTYPE' not in xml and b'<!ENTITY' not in xml
    safe=json.loads((OUT/'safe-integration-outcomes-academic-service-1.json').read_text())
    target=next(c for c in safe['cases'] if c.get('method')==METHOD and c['classname']==CLASS)
    assert target['status']=='FAILED' and target['identity']=='SOURCE_METHOD'
    assert target['sourceSha256']=='dd0c466926911d99879fcdb59dd94641ca810bb714992d8fda7bc470b409010d'
    assert safe['metadata']['prHeadSha']=='538af12e280bc0e34b62c99c8823a7bb552d6ea6' and safe['metadata']['runId']=='38297567499'
    assert safe['metadata']['checkoutSha']=='6e5385ddbab9cc967e4ef7be5e1fe29c8198082d'
    xmlhash=hashlib.sha256(xml).hexdigest()
    expected=safe['xml'][target['xmlOrdinal']-1]
    assert expected['ordinal']==target['xmlOrdinal'] and expected['sha256']==xmlhash
    assert target['suiteOrdinal']==1
    starts=list(re.finditer(rb'<testcase\b[^>]*>',xml))
    selected=[]
    for ordinal,start in enumerate(starts,1):
        header=start.group()
        h=ET.fromstring(header if header.endswith(b'/>') else header[:-1]+b'/>')
        if h.get('name') in {METHOD,METHOD+'()'} and h.get('classname')==CLASS:selected.append((ordinal,start))
    assert len(selected)==1 and selected[0][0]==target['ordinal']
    ordinal,start=selected[0];end=xml.index(b'</testcase>',start.end())+len(b'</testcase>')
    casebytes=xml[start.start():end]
    assert b'<system-out' not in casebytes and b'<system-err' not in casebytes
    case=ET.fromstring(casebytes);failures=case.findall('failure')
    assert len(failures)==1 and not case.findall('error') and not case.findall('skipped')
    fail=failures[0]
    typ=fail.get('type');known=typ in ALLOWED
    message=fail.get('message','');text=fail.text or ''
    combined=message+'\n'+text
    seen={k:('ENUM_ROW_EQUALITY tr-TR '+v) in combined for k,v in TAGS.items()}
    aggregate=re.findall(r'Multiple Failures \((\d+) failures?\)',combined)
    aggregatecounts=sorted({int(n) for n in aggregate})
    first=re.search(r'AcademicGrpcIT\.java:(\d+)\b',text)
    exact=re.findall(r'AcademicGrpcIT\.'+re.escape(METHOD)+r'\(AcademicGrpcIT\.java:(\d+)\)',text)
    lines=sorted({int(n) for n in exact})
    canonical=known and typ=='org.assertj.core.error.AssertJMultipleFailuresError' and lines==[479]
    causal=canonical and aggregatecounts==[2] and seen=={'scalar_active':False,'ADMIN_role':True,'ACTIVE_grant':True}
    result={'producer':safe['metadata']['prHeadSha'],'checkoutSha':safe['metadata']['checkoutSha'],'runId':38297567499,'jobId':114972244241,
        'carrier_artifact_id':inp['id'],'carrier_bytes':len(archive),'carrier_sha256':hashlib.sha256(archive).hexdigest(),
        'selected_XML_bytes':len(xml),'selected_XML_sha256':xmlhash,'selected_XML_SAFE_ordinal':target['xmlOrdinal'],
        'target_case_ordinal':ordinal,'sourceSha256':target['sourceSha256'],'targetFailureElementUnique':True,
        'knownExceptionType':known,'exceptionType':typ if known else 'UNKNOWN',
        'firstAcademicGrpcITFrameLineInFailureText':int(first.group(1)) if first else None,
        'exactTargetMethodFrameLines':lines,'fixedSoftAssertionTagsSeen':seen,'aggregateFailureCounts':aggregatecounts,
        'allHardCanonicalSQL_ID_status_count_total_page_positive_oracles_reached':canonical,
        'sixHTTP200_and_unknown400_reached_by_exact_source_control_flow':canonical,
        'scalarPairEqualQualified':True if causal else 'UNKNOWN',
        'roleAndGrantOnlyDivergenceQualified':causal,'verdict':'CONFIRMED_FINITE_CAUSAL_RED' if causal else 'CAUSAL_QUALIFICATION_INCOMPLETE',
        'inference_basis':'Current unique native FAILED target/source/dd0c plus exact aggregator479 AFTER all hard JDBC/HTTP/unknown400 assertions; exact two failed tags isolate roles/grants. No expectation weakening.',
        'finally_cleanup':'SOURCE_PRESENT; runtime state not independently observed',
        'other_archive_entries_decompressed':0,'unrelated_failure_bodies_or_system_out_parsed_or_emitted':False,
        'selected_XML_binary_in_RAM_explicitly_authorized':True,
        'raw_XML_logs_rows_IDs_credentials_failure_messages_persisted_or_emitted':False,
        'native_reexecution_or_product_fix_authorized':False}
    fd=os.open(OUT/'closed-target-cause.safe.json',os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
    with os.fdopen(fd,'w') as f:json.dump(result,f,indent=2);f.write('\n')
    print(json.dumps(result))
except Exception as error:
    print(json.dumps({'projection':'BLOCKED','safeErrorType':type(error).__name__,'httpStatus':getattr(error,'code',None),
        'ownLine':next((f.lineno for f in reversed(traceback.extract_tb(error.__traceback__)) if f.filename==__file__),None)}))
    raise SystemExit(1)
finally:INPUT.unlink(missing_ok=True)
