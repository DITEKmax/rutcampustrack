import copy,json,types
from pathlib import Path
P=Path(__file__).parent
m=types.ModuleType('selection');exec(compile((P/'selection.py').read_bytes(),'selection','exec'),m.__dict__)
w=types.ModuleType('mapping');exec(compile((P/'custom-executable-proposal.py').read_bytes(),'mapping','exec'),w.__dict__)
base=json.loads((P/'selected-dso-headers.safe.json').read_text())['selected'];checks=[]
def check(name,fn,expect):
 ok=False
 try:fn();ok=True
 except (ValueError,KeyError,TypeError):pass
 assert ok==expect,(name,ok);checks.append({'name':name,'expected_accept':expect,'pass':True})
check('actual22 signedheader regularDSO+onehoplink graph accepted',lambda:m.validate_selection(base),True)
def bad(field,value,link=False):
 rows=copy.deepcopy(base);r=next(r for r in rows if r['kind']==('symlink' if link else 'regular'));r[field]=value;return rows
for field,value in [('name','usr/lib/../../foreign'),('name','usr/share/foreign'),('name','/usr/lib/x86_64-linux-gnu/a'),('kind','hardlink'),('mode',0o777),('archive_uid',1000),('declared_bytes',0),('declared_bytes',-1),('declared_bytes',12231289)]:check('reject alteredregular '+field,lambda field=field,value=value:m.validate_selection(bad(field,value)),False)
check('duplicate selection rejected',lambda:m.validate_selection([base[0]]+base[:-1]),False)
for target in ['/foreign','../foreign','missing.so','..','nested/foreign']:
 rows=copy.deepcopy(base);r=next(r for r in rows if r['kind']=='symlink');r['link']['target']=target
 check('deny absolute/escape/missing/linkchain target',lambda rows=rows:m.validate_selection(rows),False)
rows=copy.deepcopy(base);next(r for r in rows if r['kind']=='symlink')['package']='foreign-package';check('crosspackage SONAMEtarget denied',lambda:m.validate_selection(rows),False)
required={'all_upstream_ELF_closure','version_symbols','GLES_actual_dlopen','x264_actual_capability','package_signature_hashes_modes','cache_byte_identity'};v={k:True for k in required}
for key in required:
 badv=dict(v);badv[key]=False;check('mapping failclosed nativeprerequisite '+key,lambda badv=badv:w.prepare_child(['--headless','--inspector-pipe'],{'PATH':'/usr/bin:/bin'},badv),False)
for extra in ['LD_LIBRARY_PATH','https_proxy','JAVA_TOOL_OPTIONS']:
 check('mapping rejects inherited unrelatedoverride '+extra,lambda extra=extra:w.prepare_child(['--headless','--inspector-pipe'],{'PATH':'/usr/bin:/bin',extra:'synthetic'},v),False)
for args,variant in [(['--headless','--inspector-pipe','--no-startup-window'],'minibrowser-wpe'),(['--inspector-pipe'],'minibrowser-gtk')]:
 exe,argv,env=w.prepare_child(args,{'PATH':'/usr/bin:/bin'},v);assert argv[1:]==args and exe==str(w.CACHE/variant/'bin/MiniBrowser');assert env['LD_LIBRARY_PATH'].startswith(str(w.CACHE/variant/'lib'));assert str(w.PREFIX/'usr/lib/x86_64-linux-gnu') in env['LD_LIBRARY_PATH'];checks.append({'name':'pure exactargs/canonicalenv mapping '+variant,'pass':True,'nativeproof_flags_are_synthetic_ONLY':True})
(P/'source-controls.safe.json').write_text(json.dumps({'status':'PASS_PURE_SELECTION_MAPPING_CONTROLS','count':len(checks),'checks':checks,'actual_extraction_or_nativeproof_or_browser':False,'syntheticmappingflags_not_runtimeauthority':True},indent=2)+'\n')
print(json.dumps({'pure_controls':len(checks),'extraction_native_browser':False}))
