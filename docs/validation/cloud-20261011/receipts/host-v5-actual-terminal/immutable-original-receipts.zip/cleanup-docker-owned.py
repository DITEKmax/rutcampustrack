"""Exact project six-container/network cleanup; preserve all volumes and tmp data."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import types

OWN = Path(__file__).parent
BASE = Path('/workspace/scratch/rct-validation/current_host_config_v5')
PROJECT = 'rct-client-host-config-20261012'
ENV = {'PATH': '/usr/local/bin:/usr/bin:/bin', 'HOME': str(BASE / 'runtime'), 'LANG': 'C.UTF-8'}
def read(args):
    result = subprocess.run(['docker', *args], env=ENV, stdin=subprocess.DEVNULL,
        stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, timeout=30, text=True)
    if result.returncode: raise RuntimeError('Selected Docker metadata failed')
    return result.stdout.strip()
expected = json.loads((OWN / 'data6-status.safe.json').read_text())['containers']
current_ids = read(['ps', '--all', '--no-trunc', '--filter', 'label=com.docker.compose.project=' + PROJECT, '--format', '{{.ID}}']).splitlines()
assert len(current_ids) == 6
verified = []
for row in expected:
    raw = read(['inspect', '--format', '{{.Id}} {{.Name}} {{.Image}} {{index .Config.Labels "com.docker.compose.project"}}', row['id']])
    ident, name, image, project = raw.split()
    assert ident.startswith(row['id']) and name == '/' + row['name'] and image == row['image'] and project == PROJECT
    assert ident in current_ids
    verified.append(ident)
assert set(verified) == set(current_ids)
volumes = set(read(['volume', 'ls', '--filter', 'label=com.docker.compose.project=' + PROJECT, '--format', '{{.Name}}']).splitlines())
assert len(volumes) == 5
(OWN / 'docker-cleanup-before.safe.json').write_text(json.dumps({'exact6_ids': verified, 'five_volumes_preserve': sorted(volumes),
    'native_tmp_data_key_preserved': True}, indent=2) + '\n')
path = BASE.parent / 'guard_proc_race_correction/bounded-child.py'
body = path.read_bytes()
assert hashlib.sha256(body).hexdigest() == 'b78c61293568d9941692e0b92ee34fd0b84db6d532b4a2c9a5ad42ccbf2204a0'
guard = types.ModuleType('exact_docker_cleanup_guard')
exec(compile(body, str(path), 'exec'), guard.__dict__)
commands = json.loads((BASE.parent / 'current_host_config_v5_mongo_identity_correction/effective-launch-inputs-v2.json').read_text())
argv = commands['docker_argv'][:commands['docker_argv'].index('up')] + ['down', '--timeout', '10']
assert '-v' not in argv and '--volumes' not in argv and '--remove-orphans' not in argv
result = guard.run_owned(argv, str(BASE), ENV, deadline_seconds=120,
    status=lambda value: (OWN / 'docker-cleanup-process.safe.json').write_text(json.dumps(value, indent=2) + '\n'))
remaining = read(['ps', '--all', '--filter', 'label=com.docker.compose.project=' + PROJECT, '--format', '{{.ID}}'])
network = read(['network', 'ls', '--filter', 'name=^' + PROJECT + '_private_net$', '--format', '{{.ID}}'])
after = set(read(['volume', 'ls', '--filter', 'label=com.docker.compose.project=' + PROJECT, '--format', '{{.Name}}']).splitlines())
assert result['phase_success'] and result['settled'] and not remaining and not network and after == volumes
fs = os.statvfs('/workspace')
report = {'guard': result, 'six_containers_network_absent': True, 'five_volumes_preserved': True,
          'native_tmp_data_key_preserved': True, 'workspace_available': fs.f_bavail * fs.f_frsize}
(OWN / 'docker-cleanup-terminal.safe.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({'cleanup_native_exit': result['native_exit'], 'settled': True, 'volumes_preserved': 5,
    'workspace_available': report['workspace_available']}))
