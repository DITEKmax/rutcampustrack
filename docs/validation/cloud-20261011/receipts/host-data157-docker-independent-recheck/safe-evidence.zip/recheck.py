"""Finite independent read-only seals, single-consumer delta and selected pure chain."""
import ast
import copy
import datetime
import hashlib
import json
import os
from pathlib import Path
import stat
import types
import zipfile

OUT=Path(__file__).parent
BASE=Path('/workspace/scratch/rct-validation')
OLD=BASE/'current_host_restart_data157_correction'
NEW=BASE/'current_host_restart_data157_docker_correction'
PREV=OUT.parent
DOCS=Path('/workspace/rutcampustrack/docs/validation/cloud-20261011')
os.umask(0o077)
checks=[]
def check(name,passed):
    assert passed,name
    checks.append({'check':name,'pass':True})
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def read(p):return json.loads(Path(p).read_text())
def save(n,o):(OUT/n).write_text(json.dumps(o,indent=2)+'\n')
ledger=[]
for n in ['TASK-CONTRACT.md','CURRENT.md','decisions.md','questions.md','resources.md']:
    p=DOCS/n;ledger.append({'path':str(p),'bytes':p.stat().st_size,'sha256':sha(p)})
for n,h in [('TASK-CONTRACT.md','e7cbc981e7d1f621f4a6390c0d88f2cbeb5ccfce347a9d324a30389685d2778e'),('decisions.md','c32b5e3d05d12717179e40a1ae228d3672d2982b7941d493bd576ab2d491baf6'),('questions.md','abed4dbf6e29fa7ce6b6383673bd4b8babd31f2eabbc7229a229735f7782df65')]:check('full retained state bridge '+n,sha(DOCS/n)==h)

def seal(p,h):
    check('manifest '+str(p),sha(p)==h)
    m=read(p)
    for r in m['files']:
        q=Path(r['path']);check('sealed member '+str(q),sha(q)==r['sha256'])
        if 'size' in r:check('size '+str(q),q.stat().st_size==r['size'])
        if 'mode' in r:check('mode '+str(q),stat.S_IMODE(q.lstat().st_mode)==(int(r['mode'],8) if isinstance(r['mode'],str) else r['mode']))
    ledger.append({'path':str(p),'sha256':h,'members':len(m['files'])})
    return m
prev=seal(PREV/'manifest.json','9389a850f8433aff80c6955ebdd375b67f3157f05031dc4ad206da43e7b99ebb')
old=seal(OLD/'manifest.json','b2549f6b5aa2717fa1d0dbdc00a793f2e891bfeb86e639dd72d0808194deb423')
new=seal(NEW/'manifest.json','1e7e26e631f7ece9a0d1b7d30ec60d586a7ce4c4c4d9f5fcbe53e913258070c8')
z=NEW/'Docker-fence-consumption.source.safe.zip'
check('exact ZIP',sha(z)=='3f5628cda15967aa0f681345e949484da0f119008b0ce53bf4f75a3976d04731')
with zipfile.ZipFile(z) as a:
    check('CRC',a.testzip() is None)
    check('ZIP exact unique inventory',len(a.namelist())==len(set(a.namelist())) and set(a.namelist())=={r['relative_path'] for r in new['files']}|{'manifest.json'})
    for n in a.namelist():check('ZIP member '+n,a.read(n)==(NEW/n).read_bytes())
prior=PREV/'safe-review.zip'
check('originalreview ZIP immutable',sha(prior)=='70de681972d129136b22a04887af24ed81eb6879dc5c0148f33e53a5dc2c86c4')

oldcall="boundary.verify_existing_data(json.loads((PLAN / 'stopped-native-data-fence.safe.json').read_text()), stopped=True)"
newcall="boundary.verify_existing_data(boundary.load_existing_data_fence(grant), stopped=True)"
ob=(OLD/'docker-up-restart.py').read_text();nb=(NEW/'docker-up-restart.py').read_text()
check('one and only old consumer',ob.count(oldcall)==1)
check('exact surgical Docker byte delta',ob.replace(oldcall,newcall)==nb)
for n in ['restart-boundary.py','run-mongo-restart.py','run-service-restart.py','runtime-ancestor-anchors.safe.json','stopped-native-data-fence157.safe.json','actor-controls.py','ancestor-controls.py','context-controls.py','helper-import-controls.py','data-fence-controls.py']:
    check('unchanged bytes '+n,(NEW/n).read_bytes()==(OLD/n).read_bytes())
check('fixed157 unchanged digest',sha(NEW/'stopped-native-data-fence157.safe.json')=='d368d1d211b71f0d364f86bb71ac5f79bfe0170a7f155e893fbd257d9e16e11f')
for n in ['docker-up-restart.py','run-mongo-restart.py','run-service-restart.py']:
    b=(NEW/n).read_text()
    check('self/helper seal before boundary exec '+n,b.index("grant.get('restart_ancestor_correction_manifest_sha256')")<b.index('boundary = types.ModuleType') and b.index('for source in [Path(__file__).absolute()')<b.index('boundary = types.ModuleType'))
    check('explicit helper __file__ '+n,'boundary.__file__ =' in b)
check('unchanged9.38GB source budget',"initial['/workspace_available'] >= 9380818650" in nb)
check('157 comparison precedes mock/create/resource/runtime',nb.index(newcall)<nb.index('cohort = boundary.CohortDirectory')<nb.index('initial = resources()')<nb.index('result = guard.run_owned'))
inputs=read(NEW/'effective-launch-inputs.json')
check('all effective runners NEW sibling',all(str(NEW)+'/' in inputs[k][1] for k in ['docker_guarded_command','mongo_server_command','mongo_readiness_command','host_command_schema']))
check('new canonical fixed fence pointer',inputs['required_new_grant_fields']['stopped_mongo_data_fence_path']==str(NEW/'stopped-native-data-fence157.safe.json'))

# Only selected function/class-free AST; target boundary module/top-level imports never executed.
names=['verify_execution_actor','regular','sha','validate_restart_fields','verify_restart','load_existing_data_fence','metadata','matching','verify_existing_data']
def setup(root):
    tree=ast.parse((root/'restart-boundary.py').read_text())
    funcs={n.name:n for n in tree.body if isinstance(n,ast.FunctionDef)}
    env={'datetime':datetime,'hashlib':hashlib,'json':json,'os':os,'Path':Path,'re':__import__('re'),'stat':stat,
        'PLAN':BASE/'current_host_restart_plan','CORRECTION':root,'BASE':BASE/'current_host_config_v5',
        'DB':Path('/tmp/rct-native-mongo-20261012/fresh-db'),'KEY':Path('/tmp/rct-native-mongo-20261012/runtime/replica-key'),
        'DATA_FENCE':root/'stopped-native-data-fence157.safe.json','DATA_FENCE_SHA':'d368d1d211b71f0d364f86bb71ac5f79bfe0170a7f155e893fbd257d9e16e11f',
        'PRIOR_CONTEXT_MANIFEST':BASE/'current_host_restart_context_correction/manifest.json','PRIOR_CONTEXT_SHA':'7c03e6cb7cb1c200c7e788e8b7c28b0d6cabb8b5b8bfc29d37f906739ad68236'}
    exec(compile(ast.Module(body=[copy.deepcopy(funcs[n]) for n in names],type_ignores=[]),'independent-selected-functions','exec'),env)
    return types.SimpleNamespace(**{n:env[n] for n in names})
def selection(path):
    tree=ast.parse(path.read_text());main=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='main')
    begin=next(i for i,n in enumerate(main.body) if isinstance(n,ast.Assign) and isinstance(n.value,ast.Call) and ast.unparse(n.value.func)=='boundary.verify_restart')
    chosen=main.body[begin:begin+3]
    check('exact selected chain includes only verify/consume/cohort '+str(path),len(chosen)==3 and ast.unparse(chosen[-1])=='cohort = boundary.CohortDirectory(OUT, create=True)')
    return compile(ast.Module(body=copy.deepcopy(chosen),type_ignores=[]),'independent-selected-Docker-chain','exec')
controls=[]
def exercise(name,root,wanted,alter=None):
    boundary=setup(root);events=[]
    def mock_cohort(p,create=False):
        assert create is True;events.append('MOCK_COHORT_BOUNDARY_ONLY');return None
    boundary.CohortDirectory=mock_cohort
    now=datetime.datetime.now(datetime.timezone.utc)
    review=BASE/'context_correction_review/manifest.json'
    grant={'durable_restart_authorized':True,'launch_authorized':True,'native_mongo_authorized':True,
        'reuse_existing_mongo_db':'/tmp/rct-native-mongo-20261012/fresh-db','reuse_existing_mongo_key':'/tmp/rct-native-mongo-20261012/runtime/replica-key',
        'repeat_bootstrap_authorized':False,'data_reset_authorized':False,'cohort_name':'restart-readonly-review','deadline_seconds':120,
        'not_before_utc':(now-datetime.timedelta(seconds=1)).isoformat(),'stop_utc':(now+datetime.timedelta(seconds=120)).isoformat(),
        'execution_actor_uid':1000,'execution_actor_gid':1000,'restart_manifest_sha256':'3b02e82b61409f7118bf434afcd888f5ae556504067913527d673d673d421537',
        'restart_ancestor_correction_manifest_sha256':sha(root/'manifest.json'),'restart_review_manifest':str(review),'restart_review_manifest_sha256':sha(review),
        'stopped_mongo_data_fence_path':str(root/'stopped-native-data-fence157.safe.json'),'stopped_mongo_data_fence_sha256':'d368d1d211b71f0d364f86bb71ac5f79bfe0170a7f155e893fbd257d9e16e11f'}
    if alter:grant[alter[0]]=alter[1]
    accepted=False
    try:exec(selection(root/'docker-up-restart.py'),{'boundary':boundary,'grant':grant,'__file__':str(root/'docker-up-restart.py'),'PLAN':BASE/'current_host_restart_plan','json':json});accepted=True
    except RuntimeError:pass
    check('control '+name,accepted==wanted and bool(events)==wanted)
    controls.append({'control':name,'accepted':accepted,'mock_boundary_events':events,'pass':True,'actual_mutation':False})
exercise('original old156 consumer rejects despite valid157 admission',OLD,False)
exercise('corrected valid157 chain reaches only mocked cohort boundary',NEW,True)
for name,field,value in [('historical156path','stopped_mongo_data_fence_path',str(BASE/'current_host_restart_plan/stopped-native-data-fence.safe.json')),('prior157siblingpath','stopped_mongo_data_fence_path',str(OLD/'stopped-native-data-fence157.safe.json')),('missingpath','stopped_mongo_data_fence_path',None),('missingsha','stopped_mongo_data_fence_sha256',None),('wrongsha','stopped_mongo_data_fence_sha256','0'*64),('wrongactor','execution_actor_uid',0),('old correction seal','restart_ancestor_correction_manifest_sha256','b2549f6b5aa2717fa1d0dbdc00a793f2e891bfeb86e639dd72d0808194deb423'),('reset requested','data_reset_authorized',True),('bootstrap requested','repeat_bootstrap_authorized',True)]:
    exercise(name+' denies before mock allocation',NEW,False,(field,value))
capacity={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'required_preDocker_bytes':9380818650,'snapshot_not_grant':True}
for base in ['/workspace','/tmp']:
    v=os.statvfs(base);capacity[base+'_available_bytes']=v.f_bavail*v.f_frsize
capacity['workspace_shortfall_bytes']=max(0,9380818650-capacity['/workspace_available_bytes'])
save('input-ledger.json',ledger)
save('recheck.safe.json',{'verdict':'APPROVE_SOURCE','closed_finding':'DATA157-DOCKER-OLD156','checks':checks,'count':len(checks),'selected_controls':controls,'target_module_imports':0,'private_bodies_read_or_hashed':False,'native':False,'only_mocked_operation':'CohortDirectory creation'})
save('resources.safe.json',capacity)
print(json.dumps({'verdict':'APPROVE_SOURCE','checks':len(checks),'selected_controls':len(controls),'capacity':capacity}))
