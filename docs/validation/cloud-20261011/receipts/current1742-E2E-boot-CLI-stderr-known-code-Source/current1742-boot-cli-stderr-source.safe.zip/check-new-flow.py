"""Only new successful/CLI-native1/live-birth branch selection in full caller RAM."""
import ast,datetime,hashlib,json,os,stat,types
from pathlib import Path

OWN=Path(__file__).parent
OLD=OWN.with_name('current1742_e2e_boot_outer_caller_source')
SOURCE=OWN/'read-existing-boot.py'
adapter=(OLD/'check-caller-ram.py').read_text()
adapter=adapter.replace("env['PINS'][R2/'capture-job-private.py']", "env['PINS'][env['CAPTURE']]")
adapter=adapter.replace("'r2_manifest_sha256':env['PINS'][R2/'manifest.json'],'review_approved':True,",
    "'r2_manifest_sha256':env['PINS'][R2/'manifest.json'],'review_approved':True,'cli_parser_sha256':env['PINS'][env['CLI']],")
adapter=adapter.replace("capture=load(R2/'capture-job-private.py','ram_capture_'+case)",
    "capture=load(env['CAPTURE'],'ram_capture_'+case)\n    cli=load(env['CLI'],'ram_cli_'+case)")
adapter=adapter.replace("str(R2/'capture-job-private.py')", "str(env['CAPTURE'])")
adapter=adapter.replace("def run_owned(argv,cwd,env,**k):", "def run_owned(argv,cwd,childenv,**k):")
adapter=adapter.replace("assert env['GH_TOKEN']=='PRIVATE_ENV_CANARY' and 'JAVA_TOOL_OPTIONS' not in env",
    "assert childenv['GH_TOKEN']=='PRIVATE_ENV_CANARY' and 'JAVA_TOOL_OPTIONS' not in childenv")
adapter=adapter.replace("proc_active[0]=False\n            failed=", "proc_active[0]=case=='LIVE_AFTER_FAILED_EXEC'\n            failed=")
adapter=adapter.replace("'FAILED_CAPTURE','FAILED_CAPTURE_FOREIGN'}", "'FAILED_CAPTURE','FAILED_CAPTURE_FOREIGN','CLI_HTTP403','LIVE_AFTER_FAILED_EXEC'}")
adapter=adapter.replace("if case=='MALFORMED_PRIVATE':data=b'\\xff'", "if case=='MALFORMED_PRIVATE':data=b'\\xff'\n    if case in {'CLI_HTTP403','LIVE_AFTER_FAILED_EXEC'}:data=b'gh: PRIVATE_CANARY_ABC https://private.invalid (HTTP 403)\\n'")
adapter=adapter.replace("env['module']=lambda p,n:Guard if p==env['GUARD'] else capture if p.name=='capture-job-private.py' else parser",
    "env['module']=lambda p,n:Guard if p==env['GUARD'] else capture if p==env['CAPTURE'] else cli if p==env['CLI'] else parser")
adapter=adapter.replace("def run_owned(argv,cwd,childenv,**k):", "def run_owned(argv,cwd,**k):\n            childenv=k.pop('env')")
adapter=adapter.replace("if case=='SUCCESS':assert", "if case=='CLI_HTTP403':\n        assert native==1 and counts['private_reads']==1 and counts['unlink']==1 and not leaf[0]\n        report=json.loads(outputs['REPORT.safe.json']);assert report['state']=='CLOSED_CLI_FAILURE_DIAGNOSTIC' and report['projection']['http_status_hints']==[403] and report['projection']['boot_cause']=='UNKNOWN'\n    elif case=='LIVE_AFTER_FAILED_EXEC':\n        assert native==1 and counts['private_reads']==0 and counts['unlink']==0 and leaf[0]\n    elif case=='SUCCESS':assert")
run_node=next(n for n in ast.parse(adapter).body if isinstance(n,ast.FunctionDef) and n.name=='run')
def load(path,name):
    g={'Path':Path,'dt':datetime,'re':__import__('re'),'os':os,'stat':stat,
        'sys':__import__('sys'),'hashlib':hashlib,'json':json,'__file__':str(path)}
    nodes=[n for n in ast.parse(path.read_bytes()).body if isinstance(n,(ast.FunctionDef,ast.ClassDef,ast.Assign))]
    mod=types.ModuleType(name);mod.__dict__.update(g)
    exec(compile(ast.Module(body=nodes,type_ignores=[]),str(path),'exec'),mod.__dict__)
    return mod
raw=SOURCE.read_bytes()
g={'ast':ast,'datetime':datetime,'hashlib':hashlib,'json':json,'os':os,'stat':stat,'types':types,
    'Path':Path,'OWN':OWN,'SOURCE':SOURCE,'raw':raw,
    'nodes':[n for n in ast.parse(raw).body if isinstance(n,(ast.FunctionDef,ast.ClassDef,ast.Assign))],
    'load':load,'checks':[]}
exec(compile(ast.Module(body=[run_node],type_ignores=[]),'PUBLIC_NEW_FLOW_RAM_ADAPTER','exec'),g)
for case in ['SUCCESS','CLI_HTTP403','LIVE_AFTER_FAILED_EXEC']:g['run'](case)
print(json.dumps({'state':'NEW_FLOW_TARGETED_RAM_PASS','checks':g['checks'],
    'actual_API_log_native':False,'old15_parser51_reused':True}))
