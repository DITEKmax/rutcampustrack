"""Bounded genuine public native availability only; no browser launch authority."""
import argparse
import datetime
import hashlib
import json
import os
from pathlib import Path
import re
import stat
import types
OWN=Path(__file__).parent
PREFIX=Path('/tmp/rct-webkit-native-deps-20261012')
PAYLOAD=OWN.parent/'browser_webkit_payload_context_correction'
GUARD=OWN.parent/'guard_proc_race_correction/bounded-child.py'
GUARD_SHA='b78c61293568d9941692e0b92ee34fd0b84db6d532b4a2c9a5ad42ccbf2204a0'
def sha(p):
    h=hashlib.sha256()
    with Path(p).open('rb') as f:
        for block in iter(lambda:f.read(1048576),b''):h.update(block)
    return h.hexdigest()
def regular(path):
    raw=str(path);path=Path(raw)
    if not path.is_absolute() or str(path)!=raw or '..' in path.parts:raise RuntimeError('Exact lexical source input required')
    for parent in reversed(path.parents):
        if not stat.S_ISDIR(parent.lstat().st_mode):raise RuntimeError('Source symlink ancestor denied')
    if not stat.S_ISREG(path.lstat().st_mode):raise RuntimeError('Regular source required')
    return path
def load(p,name):
    m=types.ModuleType(name);m.__file__=str(p);exec(compile(Path(p).read_bytes(),str(p),'exec'),m.__dict__);return m
def validate_fields(g,now):
    expected={'native_validation_authorized':True,'library_extraction_authorized':False,'browser_launch_authorized':False,'execution_actor_uid':1000,'execution_actor_gid':1000,'prefix_allocated_cap':33554432,'rss_stop_bytes':201326592}
    if any(type(g.get(k)) is not type(v) or g[k]!=v for k,v in expected.items()) or not re.fullmatch(r'native-[a-z0-9-]{1,32}',str(g.get('cohort_name',''))):raise RuntimeError('NEW exact native-only grant required')
    start=datetime.datetime.fromisoformat(g['not_before_utc']);stop=datetime.datetime.fromisoformat(g['stop_utc'])
    if start.utcoffset()!=datetime.timedelta(0) or stop.utcoffset()!=datetime.timedelta(0) or not start<=now<stop or not 0<(stop-start).total_seconds()<=600:raise RuntimeError('Fresh600s native window required')
    return stop
def main():
    if os.getuid()!=1000 or os.getgid()!=1000:raise RuntimeError('Exact actor1000 required')
    parser=argparse.ArgumentParser();parser.add_argument('--grant',required=True);args=parser.parse_args()
    grant_path=regular(args.grant);s=grant_path.lstat()
    if grant_path!=OWN/'private/native-grant.json' or s.st_uid!=1000 or stat.S_IMODE(s.st_mode)!=0o600 or s.st_nlink!=1 or s.st_size>65536:raise RuntimeError('Exact NEW native grant600 required')
    g=json.loads(grant_path.read_text());stop=validate_fields(g,datetime.datetime.now(datetime.timezone.utc))
    if sha(OWN/'manifest.json')!=g['source_manifest_sha256']:raise RuntimeError('Exact native source seal required')
    manifest=json.loads((OWN/'manifest.json').read_text())
    if not any(r['path']==str(Path(__file__).absolute()) and r['sha256']==sha(__file__) for r in manifest['files']):raise RuntimeError('Actual native source must be sealed')
    for row in manifest['files']:
        if sha(regular(row['path']))!=row['sha256']:raise RuntimeError('Sealed native input changed')
    if sha(regular(g['source_review_manifest']))!=g['source_review_manifest_sha256']:raise RuntimeError('Fresh source review required')
    for row in json.loads((OWN/'prior-authorities.safe.json').read_text())['seals']:
        if sha(regular(row['path']))!=row['sha256']:raise RuntimeError('Prior native authority changed')
    if sha(GUARD)!=GUARD_SHA:raise RuntimeError('Exact accepted guard required')
    guard=load(GUARD,'guard');driver=load(PAYLOAD/'download-headers.py','namespace_driver');probe=load(OWN/'native-probe.py','probe');paths=load(OWN/'own-paths.py','paths')
    receipt=regular(PREFIX/'terminal.safe.json')
    if sha(receipt)!=g['extraction_receipt_sha256']:raise RuntimeError('Exact actual copy receipt required')
    copied=json.loads(receipt.read_text())
    if copied['status']!='EXACT14_DSO_8_RELATIVE_LINKS_COPIED' or len(copied['copied'])!=14:raise RuntimeError('Actual complete copy required')
    selected=json.loads((OWN/'selected-dso-headers.safe.json').read_text())['selected']
    load(OWN/'selection.py','selection').validate_selection(selected)
    identities=[]
    for row in selected:
        file=PREFIX/row['name'];s=file.lstat()
        if s.st_uid!=1000:raise RuntimeError('Exact own selected native file required')
        if row['kind']=='regular':
            identity=next(r for r in copied['copied'] if r['name']==row['name'])
            if not stat.S_ISREG(s.st_mode) or s.st_nlink!=1 or stat.S_IMODE(s.st_mode)!=0o644 or s.st_size!=identity['bytes'] or sha(file)!=identity['sha256']:raise RuntimeError('Copied native bytes changed')
            identities.append({'path':str(file),'sha256':identity['sha256'],'bytes':s.st_size,'mode':0o644})
        elif not stat.S_ISLNK(s.st_mode) or os.readlink(file)!=row['link']['target']:raise RuntimeError('Exact native SONAMElink changed')
    vendor=json.loads((OWN/'native-validation-procedure.safe.json').read_text())['upstream25_ELF_4shell']
    for row in vendor:
        if sha(row['path'])!=row['sha256']:raise RuntimeError('Genuine vendor payload changed')
    tools=json.loads((OWN/'native-tools.safe.json').read_text())
    for row in tools['tools']:
        if sha(row['path'])!=row['sha256']:raise RuntimeError('Public native tool/version bytes changed')
    before=driver.resources()
    if driver.resource_stop(before):raise RuntimeError('Fresh native resource floor required')
    gates=load(OWN/'use-gates.py','use_gates')
    gates.require_fresh(stop)
    out=paths.Output(OWN/'runtime'/g['cohort_name'],create=True,before_mutation=lambda:gates.require_fresh(stop));known={};results=[]
    parent=guard.process_table()[os.getpid()]
    def observe():
        out.check();r=driver.resources()
        if datetime.datetime.now(datetime.timezone.utc)>=stop:return 'GRANT_DEADLINE'
        why=driver.resource_stop(r)
        if why:return why
        table=guard.process_table();rss=r['driver_rss']
        for member in known.get('members_including_Z',[]):
            if table.get(member['pid'],{}).get('start_ticks')!=member['start_ticks']:continue
            try:lines=Path('/proc/'+str(member['pid'])+'/status').read_text().splitlines()
            except OSError as e:
                if e.errno in (2,3):continue
                raise
            rss+=next((int(line.split()[1])*1024 for line in lines if line.startswith('VmRSS:')),0)
        if rss>201326592:return 'COMBINED_NATIVE_RSS'
        allocated=0
        for base in [PREFIX,out.path]:
            def fail(e):raise e
            for parent,dirs,files in os.walk(base,followlinks=False,onerror=fail):
                allocated+=sum((Path(parent)/n).lstat().st_blocks*512 for n in dirs+files)
        if allocated>33554432:return 'OWN_NATIVE_ALLOCATED_CAP'
        return None
    cases=[(r['path'],'minibrowser-wpe' if '/minibrowser-wpe/' in r['path'] else 'minibrowser-gtk','loader') for r in vendor if r['elf']]
    cases += [(str(PREFIX/r['name']),'package','loader') for r in selected if r['kind']=='regular']
    cases += [(target,variant,kind) for variant in ['minibrowser-wpe','minibrowser-gtk'] for target,kind in [(str(PREFIX/'usr/lib/x86_64-linux-gnu/libGLESv2.so.2'),'gles'),(str(probe.X264),'x264')]]
    try:
        out.save('launch.safe.json',{'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'parent_identity':parent,'resources_before':before,'native_cases':43,'source_manifest_sha256':g['source_manifest_sha256'],'browser':False})
        for index,(target,variant,kind) in enumerate(cases):
            if observe():raise RuntimeError('Native resource stop')
            name='probe-'+str(index).zfill(2)+'.safe.json'
            argv=['/usr/bin/python3',str(OWN/'native-probe.py'),'--kind',kind,'--target',target,'--variant',variant,'--result',str(out.path/name),'--parent-pid',str(parent['pid']),'--parent-ticks',str(parent['start_ticks']),'--source-manifest-sha256',g['source_manifest_sha256']]
            def status(v):known.clear();known.update(v);out.save('process-'+str(index)+'.safe.json',v)
            result=guard.run_owned(argv,str(OWN),probe.environment(variant),deadline_seconds=min(25,(stop-datetime.datetime.now(datetime.timezone.utc)).total_seconds()),observe=observe,status=status)
            out.save('terminal-'+str(index)+'.safe.json',result)
            if not result['phase_success'] or not result['settled'] or not result['all_owned_processes_reaped']:raise RuntimeError('Native check did not settle successfully')
            value=json.loads(regular(out.path/name).read_text())
            if value.get('pass') is not True:raise RuntimeError('Effective native loader/dlopen failure')
            results.append({'target':target,'kind':kind,'variant':variant,'safe_result':str(out.path/name),'sha256':sha(out.path/name),'pass':True})
            out.save('partial.safe.json',{'completed':results,'browser':False})
        if observe():raise RuntimeError('Terminal native resource stop')
        for row in vendor+identities:
            if sha(row['path'])!=row['sha256']:raise RuntimeError('Native input changed during proof')
        gates.require_fresh(stop)
        out.save('native-validation.safe.json',{'status':'PASS_EFFECTIVE_NATIVE_AVAILABILITY_ONLY','source_manifest_sha256':g['source_manifest_sha256'],'extraction_receipt_sha256':g['extraction_receipt_sha256'],'loader_count':39,'actual_GLES_dlopen':True,'actual_x264_dlopen_symbol':True,'version_errors':False,'results':results,'vendor':vendor,'copied_regular':identities,'selected_links':[r for r in selected if r['kind']=='symlink'],'resources':driver.resources(),'browser_E2E':'NOT_RUN'})
        print(json.dumps({'native_cases':43,'status':'NATIVE_AVAILABILITY_COMPLETE','browser':False}));return 0
    except BaseException as e:
        out.save('error.safe.json',{'status':'PARTIAL_STOPPED','completed':len(results),'error_type':type(e).__name__,'browser':False});print(json.dumps({'status':'PARTIAL_STOPPED','completed':len(results),'error_type':type(e).__name__}));return 1
    finally:out.close()
if __name__=='__main__':raise SystemExit(main())
