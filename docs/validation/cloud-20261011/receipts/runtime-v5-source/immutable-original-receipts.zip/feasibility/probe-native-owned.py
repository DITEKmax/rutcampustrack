import hashlib,json,os,types
from pathlib import Path
OUT=Path(__file__).parent;OWN=OUT.parent;os.umask(0o077)
body=(OWN.parent/'guard_proc_race_correction/bounded-child.py').read_bytes();assert hashlib.sha256(body).hexdigest()=='b78c61293568d9941692e0b92ee34fd0b84db6d532b4a2c9a5ad42ccbf2204a0'
guard=types.ModuleType('accepted_guard');exec(compile(body,'accepted_guard','exec'),guard.__dict__)
def status(value):(OUT/'probe-process.safe.json').write_text(json.dumps(value,indent=2)+'\n')
def observe():
 for path in ['/workspace','/tmp']:
  v=os.statvfs(path)
  if v.f_bavail*v.f_frsize<4294967296:return 'DISK_FLOOR'
 used=int(Path('/sys/fs/cgroup/memory.current').read_text());maximum=int(Path('/sys/fs/cgroup/memory.max').read_text())
 if used>=16106127360 or maximum-used<1073741824:return 'SHARED_MEMORY_STOP'
 return None
result=guard.run_owned(['/usr/bin/python3',str(OUT/'public-native-control.py')],str(OWN),{'PATH':'/usr/bin:/bin','HOME':str(OWN),'LANG':'C.UTF-8','LC_ALL':'C.UTF-8'},deadline_seconds=90,status=status,observe=observe)
(OUT/'probe-terminal.safe.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'probe_native_exit':result['native_exit'],'settled':result['settled'],'phase_success':result['phase_success'],'reason':result['terminal_reason']}));raise SystemExit(0 if result['phase_success'] else 1)
