"""P09 Source pins and explicitly qualified RAM control-flow analogy; no Java execution."""
from pathlib import Path
import hashlib
import json

HERE = Path(__file__).resolve().parent
WT = Path('/workspace/rct-worktrees/p09-auth-socket-join-20261013')
TEST = WT / 'services/auth-service/auth-app/src/test/java/ru/rutcampustrack/auth/integration/RealAuthOpenSocketLogoutIT.java'
BUILD = WT / 'services/auth-service/auth-app/build.gradle.kts'
text = TEST.read_text()
assert hashlib.sha256(TEST.read_bytes()).hexdigest() == '214c60272df3cbb471bb4cba4fe974c67d5e285d15517401517dc57a5831e607'
assert hashlib.sha256(BUILD.read_bytes()).hexdigest() == '282a4efc96471a80d07adcc68bd21568d350a48bf7dab29e58fc130b2b903eaf'
assert text.count('@Test\n') == 1 and 'addSuppressed' not in text
assert text.splitlines()[159].strip() == '} finally {'
assert 'if (revokedSocket != null && revokedSocket.isConnected()) revokedSocket.disconnect();' in text
assert 'if (controlSocket != null && controlSocket.isConnected()) controlSocket.disconnect();' in text

class PrimaryFailure(Exception):
    pass
class CleanupFailure(Exception):
    pass

# These closures model only Java's abrupt finally completion. They do not execute
# Java/Spring or claim actual socket/HTTP/PG behavior. Java source lines160-174
# have the same nested try/finally order and no primary catch/suppression.
def cleanup_semantics(primary, failure_at):
    attempted = []
    def action(name):
        attempted.append(name)
        if failure_at == name:
            raise CleanupFailure()
    terminal = 'NONE'
    try:
        try:
            if primary:
                raise PrimaryFailure()
        finally:
            try:
                action('disconnect_A')
                action('disconnect_B')
            finally:
                try:
                    action('client_stop')
                finally:
                    try:
                        action('logout_A')
                    finally:
                        action('logout_B')
    except PrimaryFailure:
        terminal = 'PRIMARY'
    except CleanupFailure:
        terminal = 'CLEANUP'
    return {'terminal': terminal, 'attempted_actions': attempted}

cases = {
    'normal_cleanup_preserves_primary': cleanup_semantics(True, None),
    'control_logout_failure_masks_primary': cleanup_semantics(True, 'logout_B'),
    'first_disconnect_failure_masks_primary_skips_second_direct_disconnect': cleanup_semantics(True, 'disconnect_A'),
    'cleanup_only_failure_fails': cleanup_semantics(False, 'logout_B'),
}
assert cases['normal_cleanup_preserves_primary']['terminal'] == 'PRIMARY'
assert cases['control_logout_failure_masks_primary']['terminal'] == 'CLEANUP'
assert cases['first_disconnect_failure_masks_primary_skips_second_direct_disconnect']['terminal'] == 'CLEANUP'
assert 'disconnect_B' not in cases['first_disconnect_failure_masks_primary_skips_second_direct_disconnect']['attempted_actions']
assert cases['cleanup_only_failure_fails']['terminal'] == 'CLEANUP'
out = {'schema': 'P09_INDEPENDENT_SOURCE_REVIEW_CHECKS_V1', 'verdict': 'FINDINGS',
    'test_source_sha256': hashlib.sha256(TEST.read_bytes()).hexdigest(),
    'build_source_sha256': hashlib.sha256(BUILD.read_bytes()).hexdigest(),
    'primary_cleanup_semantics_RAM4': cases,
    'qualification': 'Source counterexample by Java finally semantics; RAM analogue only, not actual Java AST/compile/runtime/sensitivity proof.',
    'compile_runtime_sensitivity': 'NOT_RUN', 'actual_auth_socket_effect': 'NOT_RUN',
    'privacy_effects': 'Public Source/RAM only; no raw test artifacts/private values/keys/env/native/API/network/product edit'}
(HERE / 'controls.safe.json').write_text(json.dumps(out, indent=2) + '\n')
print(json.dumps({'Source_pins': 'PASS', 'RAM_finally_semantics_cases': 4, 'verdict': 'FINDINGS', 'Java': 'NOT_RUN'}))
