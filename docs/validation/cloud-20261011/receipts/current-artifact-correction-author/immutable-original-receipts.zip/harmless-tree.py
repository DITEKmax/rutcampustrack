#!/usr/bin/env python3
"""Own bounded stdlib child/grandchild fixture. No network or external program."""
import json
import os
from pathlib import Path
import signal
import sys
import time

mode, report = sys.argv[1:]
if mode == 'signal':
    signal.signal(signal.SIGTERM, signal.SIG_IGN)
grandchild = os.fork()
if grandchild == 0:
    if mode == 'normal':
        os._exit(0)
    # Escape the group as well: adoption/ancestry must remain accounted for.
    os.setsid()
    time.sleep(15)
    os._exit(0)
Path(report).write_text(json.dumps({'parent_pid': os.getpid(), 'grandchild_pid': grandchild})+'\n')
if mode == 'normal':
    # Let the leaf become Z, then deliberately omit waitpid in this fixture.
    time.sleep(0.1)
    os._exit(0)
time.sleep(15)
os._exit(0)
