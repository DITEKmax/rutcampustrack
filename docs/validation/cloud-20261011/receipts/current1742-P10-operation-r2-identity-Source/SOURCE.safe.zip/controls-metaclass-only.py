"""Only two selected-catch AST/RAM metaclass counterexamples; no observer/environment/network."""
from pathlib import Path
import ast, json, os, ssl, urllib.error, zipfile
import xml.etree.ElementTree as ET

scope = Path(__file__).parent
old = scope.with_name('p10-current1742-failure-frame-source-operation-r1')
trees = {key: ast.parse((path/'logged-green-child.py').read_text()) for key, path in [('old', old), ('new', scope)]}
setup = [n for n in trees['old'].body if (isinstance(n, ast.ClassDef) and n.name == 'DiagnosticBlocked')
         or (isinstance(n, ast.Assign) and any(isinstance(t, ast.Name) and t.id == 'PRIMARY_REJECTION_CODES' for t in n.targets))]
base = {}
exec(compile(ast.Module(body=setup, type_ignores=[]), '<selected-setup>', 'exec'), base)
def run(key, error):
    obs = next(n for n in trees[key].body if isinstance(n, ast.FunctionDef) and n.name == 'observe_original_case')
    handler = next(n for n in obs.body if isinstance(n, ast.Try)).handlers[0]
    env = {**base, 'failure': error, 'primary_rejection': 'NONE', 'exception_code': 'NONE', 'http_status': 0,
           'operation_stage': 'URL_OPEN', 'ssl': ssl, 'urllib': __import__('urllib'), 'json': json, 'zipfile': zipfile, 'ET': ET}
    failed = False
    try:
        exec(compile(ast.Module(body=handler.body, type_ignores=[]), '<selected-catch>', 'exec'), env)
    except ValueError:
        failed = True
    return failed, {k: env[k] for k in ['primary_rejection', 'exception_code', 'http_status', 'operation_stage']}
hash_calls = []
class HashTrap(type):
    def __hash__(cls):
        hash_calls.append(True)
        raise ValueError('OWN_SYNTHETIC_HOOK_CANARY')
class HashTrapError(Exception, metaclass=HashTrap):
    pass
old_failed, old_hash = run('old', HashTrapError('OWN_SYNTHETIC_MESSAGE_CANARY'))
assert old_failed and len(hash_calls) == 1 and old_hash['primary_rejection'] == 'NONE'
hash_calls.clear()
new_failed, new_hash = run('new', HashTrapError('OWN_SYNTHETIC_MESSAGE_CANARY'))
assert not new_failed and not hash_calls and new_hash['primary_rejection'] == 'BOUNDARY_UNKNOWN' and new_hash['exception_code'] == 'OTHER' and new_hash['http_status'] == 0
equal_calls = []
class EqualTrap(type):
    def __hash__(cls):
        equal_calls.append('HASH')
        return hash(urllib.error.HTTPError)
    def __eq__(cls, other):
        equal_calls.append('EQUALITY')
        return other is urllib.error.HTTPError
class EqualTrapError(Exception, metaclass=EqualTrap):
    pass
old_failed, old_equal = run('old', EqualTrapError('OWN_SYNTHETIC_MESSAGE_CANARY'))
assert not old_failed and old_equal['exception_code'] == 'HTTP_ERROR' and 'EQUALITY' in equal_calls
equal_calls.clear()
new_failed, new_equal = run('new', EqualTrapError('OWN_SYNTHETIC_MESSAGE_CANARY'))
assert not new_failed and not equal_calls and new_equal['primary_rejection'] == 'BOUNDARY_UNKNOWN' and new_equal['exception_code'] == 'OTHER' and new_equal['http_status'] == 0
out = {'schema': 'P10_OPERATION_R2_METACLASS_SELECTED_AST_RAM_V1', 'old_hash_hook_aborts_before_primary': old_hash,
       'old_equality_hook_false_HTTP_enum': old_equal, 'new_hash_hook_not_called_primary_OTHER': new_hash,
       'new_equality_hook_not_called_primary_OTHER': new_equal, 'both_counterexamples_and_corrections_PASS': True,
       'actual_selected_catch_AST': True, 'hooks_executed_old_only': True,
       'unchanged_evidence': 'Reviewer97e9 ordinary19/status8/stages15/caps/source plus prior13/17+6 reused, not replayed',
       'no_unknown_type_message_context_or_URL_export': True,
       'effects': 'Synthetic selected-catch AST/RAM only; no observer/env/privateXML/log/network/native/request access',
       'actual02_and_P10_cause': 'UNKNOWN'}
assert 'OWN_SYNTHETIC' not in json.dumps(out)
os.umask(0o077)
p = scope/'metaclass-controls.safe.json'
p.write_text(json.dumps(out, indent=2)+'\n')
p.chmod(0o600)
print(json.dumps({'controls': 2, 'PASS': True}))
