"""One real Academic RPC -> bot /start -> loopback aiogram provider probe.

Input is synthetic material on stdin; output is safe booleans/counts only.
No real Telegram network, polling, credentials artifacts or provider body logs.
"""

import asyncio
import json
import sys
from datetime import datetime, timezone

import grpc
from aiogram import Bot, Dispatcher
from aiogram.client.session.aiohttp import AiohttpSession
from aiogram.client.telegram import TelegramAPIServer
from aiogram.types import Chat, Message, Update, User
from aiohttp import web

from bot.grpc_client.academic_client import AcademicGrpcClient
from bot.handlers.start import start_router


async def probe(data):
    observations = {"provider_attempts": 0, "delivered_initial": False, "exact_private_recipient": True}

    async def send(request):
        body = await request.post()
        observations["provider_attempts"] += 1
        chat_id = int(body["chat_id"])
        observations["exact_private_recipient"] &= chat_id == data["telegram_id"]
        observations["delivered_initial"] |= data["initial_marker"] in body.get("text", "")
        return web.json_response(
            {
                "ok": True,
                "result": {
                    "message_id": 1,
                    "date": 1,
                    "chat": {"id": chat_id, "type": "private"},
                    "text": "synthetic response",
                },
            }
        )

    app = web.Application()
    app.router.add_post("/bot{token}/sendMessage", send)
    runner = web.AppRunner(app, access_log=None)
    await runner.setup()
    site = web.TCPSite(runner, "127.0.0.1", 0)
    await site.start()
    session = AiohttpSession(api=TelegramAPIServer.from_base(f"http://127.0.0.1:{runner.addresses[0][1]}"))
    bot = Bot(token="123456789:" + "A" * 35, session=session)
    academic = AcademicGrpcClient("127.0.0.1", data["grpc_port"], grpc_secret=data["grpc_secret"])
    untrusted = AcademicGrpcClient("127.0.0.1", data["grpc_port"])
    try:
        try:
            await untrusted.get_user_by_telegram_id(data["telegram_id"])
            observations["untrusted_lookup_denied"] = False
        except grpc.aio.AioRpcError as error:
            observations["untrusted_lookup_denied"] = error.code() == grpc.StatusCode.UNAUTHENTICATED
        user = await academic.get_user_by_telegram_id(data["telegram_id"])
        observations["current_bound_user"] = user.found and user.user_id == data["user_id"]
        dispatcher = Dispatcher()
        dispatcher.include_router(start_router)
        update = Update(
            update_id=1,
            message=Message(
                message_id=1,
                date=datetime.now(timezone.utc),
                chat=Chat(id=data["telegram_id"], type="private"),
                from_user=User(id=data["telegram_id"], is_bot=False, first_name="Synthetic"),
                text="/start",
            ),
        )
        await dispatcher.feed_update(bot, update, academic_client=academic, prefs_client=None)
        return observations
    finally:
        await academic.close()
        await untrusted.close()
        await bot.session.close()
        await runner.cleanup()


if __name__ == "__main__":
    try:
        result = asyncio.run(probe(json.load(sys.stdin)))
    except Exception as error:
        # Provider/session exceptions can carry URLs or request material.
        print(json.dumps({"infrastructure_error_type": type(error).__name__}))
        sys.exit(2)
    print(json.dumps(result))
