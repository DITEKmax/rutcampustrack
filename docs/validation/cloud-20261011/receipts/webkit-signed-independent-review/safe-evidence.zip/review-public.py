"""Independent read-only public provenance checks; output only in own review dir."""
import datetime
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import re
import stat
import subprocess
import zipfile

OUT = Path(__file__).parent
PLAN = Path('/workspace/scratch/rct-validation/browser_webkit_signed_plan')
META = Path('/tmp/rct-webkit-signed-metadata-20261012')
ENV = {'PATH': '/usr/bin:/bin', 'LANG': 'C', 'LC_ALL': 'C'}
def sha(p):
    h = hashlib.sha256()
    with Path(p).open('rb') as f:
        for b in iter(lambda: f.read(1048576), b''):
            h.update(b)
    return h.hexdigest()
def save(name, obj):
    (OUT/name).write_text(json.dumps(obj, indent=2)+'\n')

manifest = json.loads((PLAN/'manifest.json').read_text())
checks = []
for row in manifest['files']:
    p = Path(row['path']); s = p.lstat()
    assert stat.S_ISREG(s.st_mode)
    assert sha(p) == row['sha256'] and s.st_size == row['bytes']
    assert stat.S_IMODE(s.st_mode) == row['mode']
    checks.append({'name': row['name'], 'sha256': sha(p), 'bytes': s.st_size})
assert sha(PLAN/'manifest.json') == '82a2775335737cbf8fe0bd40e612f2302f2cd5e73ea2663be3e489aa2a8cb3ac'
assert sha(PLAN/'safe-evidence.zip') == 'c7937e89ff03b86a0987ab645538e0c7c61004e364ec30353e80757f9047c17b'
with zipfile.ZipFile(PLAN/'safe-evidence.zip') as z:
    rows = z.infolist()
    assert len(rows) == 22 and len({r.filename for r in rows}) == 22
    for r in rows:
        path = PurePosixPath(r.filename)
        assert not path.is_absolute() and '..' not in path.parts
        assert not stat.S_ISLNK(r.external_attr >> 16)
        item = {'sha256': sha(PLAN/'manifest.json')} if r.filename == 'manifest.json' else next((x for x in checks if x['name'] == r.filename), None)
        assert item and hashlib.sha256(z.read(r)).hexdigest() == item['sha256']
    assert z.testzip() is None
sig = json.loads((PLAN/'signature.safe.json').read_text())
assert sha('/usr/share/keyrings/debian-archive-keyring.gpg') == sig['existing_keyring_sha256']
assert sha('/usr/bin/sqv') == sig['sqv_sha256']
verified = OUT/'Release.independently-verified'
r = subprocess.run(['/usr/bin/sqv', '--keyring', '/usr/share/keyrings/debian-archive-keyring.gpg', '--output', str(verified), '--cleartext', str(PLAN/'signed-public/InRelease')], env=ENV, capture_output=True, text=True, timeout=20)
assert r.returncode == 0
assert sha(verified) == sha(PLAN/'signed-public/Release.verified')
tampered = OUT/'InRelease.public-negative'
original = (PLAN/'signed-public/InRelease').read_bytes()
assert original.count(b'Codename: trixie') == 1
tampered.write_bytes(original.replace(b'Codename: trixie', b'Codename: trixiX'))
neg = subprocess.run(['/usr/bin/sqv', '--keyring', '/usr/share/keyrings/debian-archive-keyring.gpg', '--output', str(OUT/'Release.negative-UNTRUSTED'), '--cleartext', str(tampered)], env=ENV, capture_output=True, text=True, timeout=20)
assert neg.returncode != 0
release = verified.read_text()
section = release.split('\nSHA256:\n', 1)[1].split('\nSHA512:', 1)[0]
authenticated = {m[3]: (m[1], int(m[2])) for m in re.finditer(r'^\s*([0-9a-f]{64})\s+(\d+)\s+(\S+)', section, re.M)}
index = META/'lists/deb.debian.org_debian_dists_trixie_main_binary-amd64_Packages'
for relative, p in [('main/binary-amd64/Packages.xz', META/'Packages.xz'), ('main/binary-amd64/Packages', index)]:
    digest, size = authenticated[relative]
    assert sha(p) == digest and p.stat().st_size == size
closure = json.loads((PLAN/'package-closure-plan.safe.json').read_text())
records = {}
for paragraph in index.read_text().split('\n\n'):
    fields = {}
    for line in paragraph.splitlines():
        if line and not line[0].isspace() and ': ' in line:
            k, v = line.split(': ', 1); fields[k] = v
    if fields.get('Package') in {row['package'] for row in closure['closure']}:
        records[fields['Package']] = fields
assert len(records) == len(closure['closure']) == 11
for row in closure['closure']:
    rec = records[row['package']]
    for a, b in [('version','Version'), ('architecture','Architecture'), ('official_pool_filename','Filename'), ('package_sha256','SHA256')]:
        assert row[a] == rec[b]
    assert row['download_bytes'] == int(rec['Size'])
    assert row['declared_installed_bytes'] == int(rec['Installed-Size'])*1024
    assert row['depends'] == rec.get('Depends') and row['pre_depends'] == rec.get('Pre-Depends')
    path = PurePosixPath(row['official_pool_filename'])
    assert str(path).startswith('pool/main/') and not path.is_absolute() and '..' not in path.parts
assert sum(row['download_bytes'] for row in closure['closure']) == 6284816
assert sum(row['declared_installed_bytes'] for row in closure['closure']) == 29017088
api = json.loads((PLAN/'custom-executable-api.safe.json').read_text())
for row in api['source_files']:
    assert sha(row['path']) == row['sha256']
save('provenance.safe.json', {'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'manifest_sha256':sha(PLAN/'manifest.json'),'safe_zip_sha256':sha(PLAN/'safe-evidence.zip'),'manifest_members_verified':checks,'zip_crc_and_path_checks':True,'sqv_genuine_native_exit':r.returncode,'sqv_tampered_native_exit':neg.returncode,'verified_release_sha256':sha(verified),'signed_compressed_and_plain_index_exact':True,'all11_archive_metadata_exact_index_rows':True,'archive_bytes':6284816,'vendor_declared_installed_bytes':29017088,'all5_pinned_api_source_hashes_match':True,'downloads_extraction_native_loader_browser':False})
print(json.dumps({'manifest_members':len(checks),'zip_members':22,'signature_native_exit':r.returncode,'tampered_exit':neg.returncode,'exact_package_rows':11,'payload_browser':False}))
