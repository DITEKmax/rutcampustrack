import json,hashlib,re
from pathlib import Path
import pglast
from pglast import parser
w=Path('/workspace/rct-worktrees/ci-academic-heap');o=Path(__file__).parent
skip={'location','stmt_location','stmt_len','lineno'}
def normalize(value):
 if isinstance(value,list):return [normalize(v) for v in value]
 if not isinstance(value,dict):return value
 result={}
 for k,v in value.items():
  if k in skip:continue
  if k=='query' and isinstance(v,str):
   try:parsed=parser.parse_sql_json(v);kind='statement'
   except parser.ParseError:parsed=parser.parse_sql_json('SELECT '+v);kind='PL expression wrapped SELECT'
   result[k]={'kind':kind,'native_SQL_AST':normalize(json.loads(parsed))}
  else:result[k]=normalize(v)
 return result
def native(s):
 commands=re.findall(r'^\\[^\n]*',s,re.M);sql=re.sub(r'^\\[^\n]*','',s,flags=re.M);tree=json.loads(parser.parse_sql_json(sql));pl=[]
 for stmt in tree['stmts']:
  if 'DoStmt' in stmt['stmt']:
   raw=stmt['stmt']['DoStmt'];body=next(d['DefElem']['arg']['String']['sval'] for d in raw['args'] if d['DefElem']['defname']=='as');language=next((d['DefElem']['arg']['String']['sval'] for d in raw['args'] if d['DefElem']['defname']=='language'),'plpgsql');assert language=='plpgsql';grammar=normalize(pglast.parse_plpgsql('DO $proof$'+body+'$proof$;'));pl.append(grammar)
   for d in raw['args']:
    if d['DefElem']['defname']=='as':d['DefElem']['arg']={'NativePLpgSQL_AST':grammar}
 return {'commands':commands,'SQL':normalize(tree),'PLpgSQL':pl}
rows=[]
for rel in json.loads((o/'selected.json').read_text()):
 a=native((o/'before-files'/rel).read_text());b=native((w/rel).read_text());rows.append({'path':rel,'native_PG16_AST_equal':a==b,'before_sha256':hashlib.sha256(json.dumps(a,sort_keys=True).encode()).hexdigest(),'after_sha256':hashlib.sha256(json.dumps(b,sort_keys=True).encode()).hexdigest(),'statements':len(a['SQL']['stmts']),'psql_commands':len(a['commands']),'PLpgSQL_blocks':len(a['PLpgSQL'])})
result={'pglast':pglast.__version__,'native_postgresql_version':pglast.get_postgresql_version(),'rows':rows,'all_equal':all(r['native_PG16_AST_equal'] for r in rows),'qualification':'Genuine PG16 grammar/PLpgSQL+embedded SQL AST and exact psql commands; source positions only removed; no DB execution'};(o/'native-pg16-grammar.safe.json').write_text(json.dumps(result,indent=2));print({'files':len(rows),'all_equal':result['all_equal'],'pl_blocks':sum(r['PLpgSQL_blocks'] for r in rows)});raise SystemExit(not result['all_equal'])
