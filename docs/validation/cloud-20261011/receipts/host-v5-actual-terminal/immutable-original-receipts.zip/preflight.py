"""Read-only exact runtime input/namespace/resource preflight. No application start."""
import hashlib
import ipaddress
import json
import os
from pathlib import Path
import stat
import subprocess
import datetime

OWN = Path(__file__).parent
B = Path('/workspace/scratch/rct-validation')
BASE = B / 'current_host_config_v5'
REDIRECT = B / 'current_host_config_v5_redirect_query_correction'
IDENTITY = B / 'current_host_config_v5_mongo_identity_correction'
PROJECT = 'rct-client-host-config-20261012'
ENV = {'PATH': '/usr/local/bin:/usr/bin:/bin', 'LANG': 'C.UTF-8', 'HOME': str(OWN)}

def digest(p):
    h = hashlib.sha256()
    with Path(p).open('rb') as stream:
        for block in iter(lambda: stream.read(1048576), b''):
            h.update(block)
    return h.hexdigest()

def safe_write(name, data):
    (OWN / name).write_text(json.dumps(data, indent=2) + '\n')

def measure():
    result = {'utc': datetime.datetime.now(datetime.timezone.utc).isoformat()}
    for base in ['/workspace', '/tmp']:
        f = os.statvfs(base)
        result[base + '_available'] = f.f_bavail * f.f_frsize
    result['shared_memory'] = int(Path('/sys/fs/cgroup/memory.current').read_text())
    result['shared_limit'] = int(Path('/sys/fs/cgroup/memory.max').read_text())
    return result

def docker(args, absent_ok=False):
    # Only selected public metadata commands are permitted by this helper.
    argv = ['docker', '--host', 'unix:///var/run/docker.sock', *args]
    r = subprocess.run(argv, env=ENV, stdin=subprocess.DEVNULL, stdout=subprocess.PIPE,
                       stderr=subprocess.DEVNULL, timeout=30, text=True)
    if r.returncode and not absent_ok:
        raise RuntimeError('Docker metadata command failed')
    return r.returncode, r.stdout.strip()

def regular(p, mode=None):
    p = Path(p)
    for ancestor in reversed(p.parents):
        if not stat.S_ISDIR(ancestor.lstat().st_mode):
            raise RuntimeError('Unexpected symlink ancestor')
    m = p.lstat()
    if not stat.S_ISREG(m.st_mode) or (mode is not None and stat.S_IMODE(m.st_mode) != mode):
        raise RuntimeError('Unexpected file type/mode')
    return m

def main():
    native_stat = Path('/proc/self/stat').read_text()
    ticks = int(native_stat[native_stat.rindex(')') + 2:].split()[19])
    safe_write('CURRENT.json', {'status': 'READONLY_PREFLIGHT_METADATA', 'pid': os.getpid(), 'start_ticks': ticks,
                               'apps_started': 0, 'grant_required': True})
    safe_write('resources-before.safe.json', measure())
    seals = [(BASE / 'launch-manifest.json', 'e3b6e2c80d819e758bd54722a0d348764dcee5ce64a1ede0cd20df16adc96378'),
             (REDIRECT / 'manifest.json', '75e4107b7053de13feb12d5cdbecfdae67124b1cdd01fee1ab52140c0439ab73'),
             (IDENTITY / 'manifest.json', '077de277ed0dd9182e36da132c0e82611d65504382a9e45692d07ffe9d0a0e95'),
             (IDENTITY / 'launch-schema-addendum-manifest.json', 'b3c273ecf189f33c484945513dd5fd8ccc1bc20257b768da51e695a57c5846ec'),
             (B / 'hostcfg_v5_independent_recheck/correction_recheck/manifest.json', '8dd93948d3faf69df5aa5b671726c1083b9f8539aa547dccff780d47c14eb8f4')]
    proof = []
    for path, sha in seals:
        assert digest(path) == sha
        manifest = json.loads(path.read_text())
        rows = manifest.get('files', manifest.get('safe_files', []))
        if isinstance(rows, list):
            for row in rows:
                regular(row['path'])
                assert digest(row['path']) == row['sha256']
        proof.append({'path': str(path), 'sha256': sha, 'all_source_members_equal': True})
    assert digest(B / 'guard_proc_race_correction/bounded-child.py') == 'b78c61293568d9941692e0b92ee34fd0b84db6d532b4a2c9a5ad42ccbf2204a0'
    safe_write('seals.safe.json', proof)
    import yaml
    compose = yaml.safe_load((BASE / 'data-renderer-edge.compose.yml').read_text())
    overlay = yaml.safe_load((REDIRECT / 'edge-overlay.compose.yml').read_text())
    mounts = {m['target']: m for m in compose['services']['nginx']['volumes']}
    mounts.update({m['target']: m for m in overlay['services']['nginx']['volumes']})
    compose['services']['nginx']['volumes'] = list(mounts.values())
    assert set(compose['services']) == {'postgres-academic', 'postgres-schedule', 'redis', 'rabbitmq', 'document-renderer-service', 'nginx'}
    mount_proof = []
    for service, spec in compose['services'].items():
        for m in spec.get('volumes', []):
            if isinstance(m, str):
                continue
            assert m['read_only'] is True and m['bind']['create_host_path'] is False
            p = Path(m['source'])
            assert p.exists() and not p.is_symlink()
            mount_proof.append({'service': service, 'path': str(p), 'target': m['target'], 'read_only': True,
                                'exists': True, 'mode': oct(stat.S_IMODE(p.stat().st_mode))})
    private = []
    for name in ['docker.env', 'inactive-bot-pair.json', 'auth.json', 'gateway.json', 'attendance.json', 'schedule.json', 'academic.json', 'notification.json', 'bff.json']:
        p = BASE / 'private' / name
        m = regular(p, 0o600)
        assert m.st_uid == os.getuid()
        private.append({'name': name, 'mode': '0600', 'owner_uid': m.st_uid, 'bytes': m.st_size, 'values_or_hash_read': False})
    safe_write('mount-private-metadata.safe.json', {'mounts': mount_proof, 'private_input_metadata': private})
    cli, namespace = docker(['container', 'ls', '--all', '--filter', 'label=com.docker.compose.project=' + PROJECT, '--format', '{{.ID}}'])
    assert namespace == ''
    code, network = docker(['network', 'inspect', PROJECT + '_private_net', '--format', '{{.Name}}'], absent_ok=True)
    assert code != 0 and network == ''
    _, names = docker(['network', 'ls', '--format', '{{.ID}}'])
    ipam = []
    owned_subnet = ipaddress.ip_network('172.29.84.0/24')
    for network_id in names.splitlines():
        _, raw = docker(['network', 'inspect', network_id, '--format', '{{json .IPAM.Config}}'])
        configs = json.loads(raw)
        for config in configs or []:
            subnet = config.get('Subnet')
            if subnet and ipaddress.ip_network(subnet).version == 4:
                assert not owned_subnet.overlaps(ipaddress.ip_network(subnet))
        ipam.append({'network_id': network_id, 'IPAM': configs})
    images = []
    for image in sorted({s['image'] for s in compose['services'].values()}):
        _, raw = docker(['image', 'inspect', image, '--format', '{"id":{{json .Id}},"size":{{.Size}},"user":{{json .Config.User}},"entrypoint":{{json .Config.Entrypoint}},"cmd":{{json .Config.Cmd}}}'])
        selected = json.loads(raw)
        assert selected['id'] == image
        images.append(selected)
    volumes = []
    for entry in compose['volumes'].values():
        _, raw = docker(['volume', 'inspect', entry['name'], '--format', '{"name":{{json .Name}},"labels":{{json .Labels}},"driver":{{json .Driver}}}'])
        selected = json.loads(raw)
        assert selected['name'] == entry['name'] and selected['labels']['com.docker.compose.project'] == PROJECT
        volumes.append(selected)
    assert len(volumes) == 5
    ports = {28432, 28433, 28379, 28672, 19095, 28488, 8443, 28417, 9090, 9091, 9092, 9093, 9094, 9080, 8080, 19091, 19092, 19093}
    conflicts = []
    for file in ['/proc/net/tcp', '/proc/net/tcp6']:
        for line in Path(file).read_text().splitlines()[1:]:
            fields = line.split()
            port = int(fields[1].rsplit(':', 1)[1], 16)
            if fields[3] == '0A' and port in ports:
                conflicts.append({'table': file, 'port': port})
    assert not conflicts
    safe_write('namespace-images-volumes-ports.safe.json', {'project_containers_absent': True, 'project_network_absent': True,
        'foreign_network_overlap': False, 'foreign_IPAM_metadata': ipam, 'images': images, 'volumes': volumes,
        'exact_ports': sorted(ports), 'listen_conflicts': conflicts, 'no_ENV_Health_Log_or_data_read': True})
    safe_write('CURRENT.json', {'status': 'READONLY_CURRENT_ARTIFACT_SHA', 'pid': os.getpid(), 'start_ticks': ticks,
                               'apps_started': 0, 'grant_required': True})
    artifacts = json.loads((B / 'current_client_artifacts/eight-production-jars.json').read_text())['jars']
    for row in artifacts:
        regular(row['jar'], 0o600)
        assert digest(row['jar']) == row['sha256']
    by_inode = {}
    paths = 0
    for map_row in json.loads((B / 'current_host_stage/manifest.json').read_text())['payload_maps']:
        assert digest(map_row['path']) == map_row['sha256']
        mapping = json.loads(Path(map_row['path']).read_text())
        for row in mapping['files']:
            for key in ['layer_path', 'app_path']:
                p = Path(row[key]);m = regular(p, 0o644);paths += 1
                identity = (m.st_dev, m.st_ino)
                if identity not in by_inode:
                    assert digest(p) == row['sha256']
                    by_inode[identity] = row['sha256']
                else:
                    assert by_inode[identity] == row['sha256']
    assert paths == 21668 and len(by_inode) == 2937
    vue = json.loads((B / 'current_vue_stage/manifest.json').read_text())['public_payload_files']
    for row in vue:
        regular(row['path'], 0o644)
        assert digest(row['path']) == row['sha256']
    native = json.loads((BASE / 'feasibility/native-version-ELF.safe.json').read_text())['results']
    for result in native:
        assert digest('/tmp/rct-native-mongo-20261012/' + result['name']) == result['binary_sha256']
        for library in result['effective_host_dependencies']:
            assert digest(library['effective_public_library']) == library['public_sha256']
    assert not Path('/tmp/rct-native-mongo-20261012/fresh-db').exists() and not Path('/tmp/rct-native-mongo-20261012/runtime').exists()
    assert digest('/workspace/rct-cloud-setup/jdk21/bin/java') == '2a207f5e7d075afa01d97f8048389a64432a44c4a5af0f5e77d6e286ec5f401d'
    safe_write('artifact-stage-native-JDK.safe.json', {'current_JAR8_SHA_equal': True, 'stage_paths': paths,
        'stage_unique_inodes_SHA_equal': len(by_inode), 'Vue22_SHA_equal': len(vue), 'native_binary_DSO_SHA_equal': True,
        'native_tmp_db_runtime_absent': True, 'exact_measured_Temurin21_binary_equal': True, 'no_extract_or_application_run': True})
    current = measure()
    needed = 9380818650
    assert current['/workspace_available'] >= needed
    assert current['/tmp_available'] >= 4294967296 + 1073741824
    assert current['shared_memory'] < 16106127360 and current['shared_limit'] - current['shared_memory'] >= 1073741824
    current.update({'status': 'PASS_READONLY_PREFLIGHT_NO_LAUNCH', 'conservative_workspace_required': needed,
                    'workspace_headroom': current['/workspace_available'] - needed, 'new_grant_exists': (BASE / 'private/launch-grant.json').exists()})
    safe_write('RESULT.safe.json', current)
    print(json.dumps(current))

if __name__ == '__main__':
    main()
