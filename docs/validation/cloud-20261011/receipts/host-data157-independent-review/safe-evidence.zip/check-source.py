"""Independent bounded source/SAFE seal/metadata review; no runtime helper import."""
import ast
import copy
import datetime
import hashlib
import json
import os
from pathlib import Path
import stat
import zipfile

OUT = Path(__file__).parent
BASE = Path('/workspace/scratch/rct-validation')
NEW = BASE / 'current_host_restart_data157_correction'
OLD = BASE / 'current_host_restart_context_correction'
PLAN = BASE / 'current_host_restart_plan'
DOCS = Path('/workspace/rutcampustrack/docs/validation/cloud-20261011')
os.umask(0o077)
checks = []
def check(name, value):
    assert value, name
    checks.append({'check': name, 'pass': True})
def sha(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def read(p):
    return json.loads(Path(p).read_text())
def save(name, value):
    (OUT/name).write_text(json.dumps(value, indent=2) + '\n')

ledger=[]
for n in ['TASK-CONTRACT.md','CURRENT.md','decisions.md','questions.md','resources.md']:
    p=DOCS/n
    ledger.append({'path':str(p),'bytes':p.stat().st_size,'sha256':sha(p)})
check('retained full contract bridge unchanged', ledger[0]['sha256']=='e7cbc981e7d1f621f4a6390c0d88f2cbeb5ccfce347a9d324a30389685d2778e')
check('retained full questions bridge unchanged', ledger[3]['sha256']=='abed4dbf6e29fa7ce6b6383673bd4b8babd31f2eabbc7229a229735f7782df65')
def seal(p, expected):
    check('seal '+str(p),sha(p)==expected)
    m=read(p)
    for r in m['files']:
        q=Path(r['path'])
        check('sealed member digest '+str(q),sha(q)==r['sha256'])
        if 'size' in r: check('sealed member size '+str(q),q.stat().st_size==r['size'])
        if 'mode' in r:
            mode=int(r['mode'],8) if isinstance(r['mode'],str) else r['mode']
            check('sealed member mode '+str(q),stat.S_IMODE(q.lstat().st_mode)==mode)
    ledger.append({'path':str(p),'sha256':expected,'members':len(m['files'])})
    return m

m=seal(NEW/'manifest.json','b2549f6b5aa2717fa1d0dbdc00a793f2e891bfeb86e639dd72d0808194deb423')
oldm=seal(OLD/'manifest.json','7c03e6cb7cb1c200c7e788e8b7c28b0d6cabb8b5b8bfc29d37f906739ad68236')
seal(PLAN/'manifest.json','3b02e82b61409f7118bf434afcd888f5ae556504067913527d673d673d421537')
seal(BASE/'current_host_restart_ancestor_correction_v2/manifest.json','9ce528ac02bf076952f99fdcf2df2580518833c18abf57ab0672a1822cea1c4d')
seal(BASE/'context_correction_review/manifest.json','9498afbb0f18a27263e57c23805d514ff9a4001886482cd5d7634560b2fbee59')
seal(PLAN/'runtime/restart-20261012-next01/terminal-seal/manifest.json','71531ff5cf1ba436e328f8bc253203f29b87ce4181ade7d9acd021bc5999fb9c')
z=NEW/'data157-correction.source.safe.zip'
check('exact author SAFE ZIP',sha(z)=='6af4a6aba5daff0ef9b96d8ebd0b1cf2de5fa2da416fedda72352d9a3e1aa91d')
with zipfile.ZipFile(z) as a:
    check('ZIP CRC',a.testzip() is None)
    check('ZIP unique members',len(a.namelist())==len(set(a.namelist())))
    check('ZIP exact member inventory',set(a.namelist())=={r['relative_path'] for r in m['files']}|{'manifest.json'})
    for n in a.namelist(): check('ZIP frozen member '+n,a.read(n)==(NEW/n).read_bytes())

fence=read(NEW/'stopped-native-data-fence157.safe.json')
oldf=read(PLAN/'stopped-native-data-fence.safe.json')
check('fixed157 digest',sha(NEW/'stopped-native-data-fence157.safe.json')=='d368d1d211b71f0d364f86bb71ac5f79bfe0170a7f155e893fbd257d9e16e11f')
nodes=fence['stopped_db_metadata_nodes']
DB=Path('/tmp/rct-native-mongo-20261012/fresh-db')
KEY=Path('/tmp/rct-native-mongo-20261012/runtime/replica-key')
cols={'path','device','inode','uid','gid','mode','bytes','nlink','mtime_ns','ctime_ns','kind'}
check('157 unique canonical paths',len(nodes)==len({r['path'] for r in nodes})==157)
check('DB root first for live identity',nodes[0]['path']==str(DB))
for r in nodes:
    check('exact metadata schema '+r['path'],set(r)==cols)
    check('own contained lexical DB path '+r['path'],(Path(r['path'])==DB or DB in Path(r['path']).parents) and '..' not in Path(r['path']).parts and r['uid']==1000 and r['gid']==1000 and r['kind'] in {'directory','regular'})
    check('regular DB node nlink1 '+r['path'],r['kind']!='regular' or r['nlink']==1)
check('key fixed path/schema/600/nlink1',set(fence['exact_key_metadata'])==cols and fence['exact_key_metadata']['path']==str(KEY) and fence['exact_key_metadata']['mode']==0o600 and fence['exact_key_metadata']['nlink']==1)
check('old156 retained as historical fence',len(oldf['stopped_db_metadata_nodes'])==156)
check('old156 and new157 differ substantively',oldf['stopped_db_metadata_nodes']!=nodes)

def metadata(p):
    p=Path(p)
    for parent in reversed(p.parents):
        check('lstat directory ancestor '+str(parent),stat.S_ISDIR(parent.lstat().st_mode))
    s=p.lstat()
    kind='directory' if stat.S_ISDIR(s.st_mode) else 'regular' if stat.S_ISREG(s.st_mode) else 'denied'
    check('no symlink/special retained node '+str(p),kind!='denied')
    return dict(path=str(p),device=s.st_dev,inode=s.st_ino,uid=s.st_uid,gid=s.st_gid,mode=stat.S_IMODE(s.st_mode),bytes=s.st_size,nlink=s.st_nlink,mtime_ns=s.st_mtime_ns,ctime_ns=s.st_ctime_ns,kind=kind)
current=[metadata(DB)]
for p,dirs,files in os.walk(DB,followlinks=False,onerror=lambda e:(_ for _ in ()).throw(e)):
    current.extend(metadata(Path(p)/n) for n in sorted(dirs+files))
actual={r['path']:r for r in current}
metadata_result={'stopped_nodes':len(current),'actual_data_body_reads':0,'actual_key_body_reads':0,'new157_exact':actual=={r['path']:r for r in nodes},'old156_exact':actual=={r['path']:r for r in oldf['stopped_db_metadata_nodes']}}
metadata_result['root_equal']=metadata('/tmp/rct-native-mongo-20261012')==fence['root_directory']
runtime_actual=metadata(KEY.parent)
metadata_result['runtime_equal']=all(runtime_actual.get(k)==v for k,v in fence['runtime_directory_identity'].items())
metadata_result['key_equal']=metadata(KEY)==fence['exact_key_metadata']
check('actual metadata157 equality',metadata_result['new157_exact'])
check('actual old156 mismatch',not metadata_result['old156_exact'])
check('actual native root runtime key metadata equality',all(metadata_result[n] for n in ['root_equal','runtime_equal','key_equal']))

boundary=(NEW/'restart-boundary.py').read_text()
tree=ast.parse(boundary)
oldtree=ast.parse((OLD/'restart-boundary.py').read_text())
named=lambda t:{n.name:n for n in t.body if isinstance(n,(ast.FunctionDef,ast.ClassDef))}
nf,of=named(tree),named(oldtree)
for n in of:
    if n!='verify_restart':check('unchanged boundary AST '+n,ast.dump(nf[n],include_attributes=False)==ast.dump(of[n],include_attributes=False))
vr=copy.deepcopy(nf['verify_restart'])
vr.body=[s for s in vr.body if not (isinstance(s,ast.Expr) and isinstance(s.value,ast.Call) and isinstance(s.value.func,ast.Name) and s.value.func.id=='load_existing_data_fence')]
check('verify_restart solely adds fixed fence load',ast.dump(vr,include_attributes=False)==ast.dump(of['verify_restart'],include_attributes=False))
check('fixed fence load called prior plan/helper/cohort allocation',boundary.index('    load_existing_data_fence(grant)')<boundary.index("    manifest_path = PLAN / 'manifest.json'"))
check('complete old verify data AST preserved',ast.dump(nf['verify_existing_data'])==ast.dump(of['verify_existing_data']))
check('actor and path-digest gate explicit',"grant.get('stopped_mongo_data_fence_path') != str(DATA_FENCE)" in boundary and "grant.get('stopped_mongo_data_fence_sha256') != DATA_FENCE_SHA" in boundary)
check('loader nofollow uses unchanged regular/sha',"if sha(DATA_FENCE) != DATA_FENCE_SHA:" in boundary)
service=(NEW/'run-service-restart.py').read_text()
mongo=(NEW/'run-mongo-restart.py').read_text()
docker=(NEW/'docker-up-restart.py').read_text()
check('service entire bytes identical',service==(OLD/'run-service-restart.py').read_text())
check('Mongo sole fence consumer substitution',mongo==(OLD/'run-mongo-restart.py').read_text().replace("fence = json.loads((PLAN / 'stopped-native-data-fence.safe.json').read_text())","fence = boundary.load_existing_data_fence(grant)"))
check('Docker sole grant filename substitution',docker==(OLD/'docker-up-restart.py').read_text().replace("private/restart-launch-grant.json","private/restart-launch-grant-next02.json"))
check('Docker old156 consumer remains',"boundary.verify_existing_data(json.loads((PLAN / 'stopped-native-data-fence.safe.json').read_text()), stopped=True)" in docker)
for name,body in [('docker-up-restart.py',docker),('run-service-restart.py',service),('run-mongo-restart.py',mongo)]:
    check(name+' self and helper seal BEFORE exec',body.index("grant.get('restart_ancestor_correction_manifest_sha256')")<body.index("boundary = types.ModuleType") and body.index('for source in [Path(__file__).absolute()')<body.index("boundary = types.ModuleType"))
    check(name+' explicit helper __file__',"boundary.__file__ =" in body)
    check(name+' verify_restart all phases',"boundary.verify_restart(grant, __file__)" in body)
check('Mongo stopped exact server/live identity readiness',"boundary.verify_existing_data(fence, stopped=args.phase == 'server')" in mongo)
check('Docker old156 validation before cohort creation',docker.index("boundary.verify_existing_data")<docker.index("cohort = boundary.CohortDirectory")<docker.index("result = guard.run_owned"))
for name in ['runtime-ancestor-anchors.safe.json','actor-controls.py','ancestor-controls.py','context-controls.py','helper-import-controls.py']:
    check('unchanged prior source '+name,(NEW/name).read_bytes()==(OLD/name).read_bytes())
inputs=read(NEW/'effective-launch-inputs.json')
check('ALL effective runners NEW path',all(str(NEW)+'/' in inputs[k][1] for k in ['docker_guarded_command','mongo_server_command','mongo_readiness_command','host_command_schema']))
check('Mongo both commands fresh grant',all(inputs['new_grant_path'] in inputs[k] for k in ['mongo_server_command','mongo_readiness_command','host_command_schema']))
check('unchanged floor9380818650 enforced preDocker',"initial['/workspace_available'] >= 9380818650" in docker)

# Compile ONLY the exact selected pure metadata comparison functions. No helper module imports or entry points.
selected=ast.Module(body=[copy.deepcopy(nf[n]) for n in ['matching','verify_existing_data']],type_ignores=[])
snapshot=actual | {str(KEY):fence['exact_key_metadata'],str(KEY.parent):fence['runtime_directory_identity'],'/tmp/rct-native-mongo-20261012':fence['root_directory']}
class Walk:
    @staticmethod
    def walk(db,**kw):
        grouped={}
        for row in current[1:]:grouped.setdefault(str(Path(row['path']).parent),([],[]))[row['kind']=='regular'].append(Path(row['path']).name)
        return [(p,d,f) for p,(d,f) in grouped.items()]
env={'Path':Path,'KEY':KEY,'DB':DB,'metadata':lambda p:copy.deepcopy(snapshot[str(p)]),'os':Walk}
exec(compile(selected,'independent-selected-metadata-comparison','exec'),env)
pure=[]
def run_control(label,f,stopped,deny):
    rejected=False
    try:env['verify_existing_data'](f,stopped)
    except RuntimeError:rejected=True
    check('pure control '+label,rejected==deny)
    pure.append({'control':label,'denied':rejected,'pass':True})
run_control('157 stopped accepted',fence,True,False)
run_control('historical156 stopped rejected (actual Docker selected consumer)',oldf,True,True)
run_control('157 live directory accepted',fence,False,False)
for name,key,field in [('key inode','exact_key_metadata','inode'),('runtime inode','runtime_directory_identity','inode'),('root inode','root_directory','inode')]:
    f=copy.deepcopy(fence);f[key][field]+=1
    run_control(name+' rejected',f,True,True)
for name,field in [('node bytes','bytes'),('node mode','mode'),('node inode','inode')]:
    f=copy.deepcopy(fence);f['stopped_db_metadata_nodes'][-1][field]+=1
    run_control(name+' rejected',f,True,True)
f=copy.deepcopy(fence);f['stopped_db_metadata_nodes']=f['stopped_db_metadata_nodes'][:-1]
run_control('missing node rejected',f,True,True)
f=copy.deepcopy(fence);f['stopped_db_metadata_nodes'][0]['inode']+=1
run_control('live root identity changed rejected',f,False,True)

# Exact new loader function only; reads authenticated small SAFE metadata/source seals, never DB/key/private inputs.
loader=ast.Module(body=[copy.deepcopy(nf['load_existing_data_fence'])],type_ignores=[])
lg={'verify_execution_actor':lambda:None,'DATA_FENCE':NEW/'stopped-native-data-fence157.safe.json',
    'DATA_FENCE_SHA':'d368d1d211b71f0d364f86bb71ac5f79bfe0170a7f155e893fbd257d9e16e11f',
    'PRIOR_CONTEXT_MANIFEST':OLD/'manifest.json','PRIOR_CONTEXT_SHA':'7c03e6cb7cb1c200c7e788e8b7c28b0d6cabb8b5b8bfc29d37f906739ad68236','sha':sha,'json':json}
exec(compile(loader,'independent-selected-fixed-fence-loader','exec'),lg)
grant={'stopped_mongo_data_fence_path':str(lg['DATA_FENCE']),'stopped_mongo_data_fence_sha256':lg['DATA_FENCE_SHA']}
check('pure exact authenticated loader accepts157',lg['load_existing_data_fence'](grant)==fence)
pure.append({'control':'authenticated fixed loader accepts157','denied':False,'pass':True})
for name,field,value in [('wrong path','stopped_mongo_data_fence_path',str(PLAN/'stopped-native-data-fence.safe.json')),('wrong digest','stopped_mongo_data_fence_sha256','0'*64),('missing path','stopped_mongo_data_fence_path',None),('missing digest','stopped_mongo_data_fence_sha256',None)]:
    bad=copy.deepcopy(grant);bad[field]=value
    denied=False
    try:lg['load_existing_data_fence'](bad)
    except RuntimeError:denied=True
    check('pure fixed loader '+name+' denies',denied)
    pure.append({'control':name,'denied':denied,'pass':True})
for name,target in [('fence digest changed',lg['DATA_FENCE']),('original context manifest changed',lg['PRIOR_CONTEXT_MANIFEST'])]:
    lg['sha']=lambda p,t=target:'0'*64 if Path(p)==t else sha(p)
    denied=False
    try:lg['load_existing_data_fence'](grant)
    except RuntimeError:denied=True
    check('pure fixed loader '+name+' denies',denied)
    pure.append({'control':name,'denied':denied,'pass':True})
lg['sha']=sha
def bad_actor():raise RuntimeError('synthetic denied actor')
lg['verify_execution_actor']=bad_actor
denied=False
try:lg['load_existing_data_fence'](grant)
except RuntimeError:denied=True
check('pure fixed loader wrong actor early deny',denied)
pure.append({'control':'wrong actor','denied':denied,'pass':True})

capacity={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'unchanged_preDocker_required_bytes':9380818650,'sampling_only_no_launch_grant':True}
for base in ['/workspace','/tmp']:
    f=os.statvfs(base);capacity[base+'_available_bytes']=f.f_bavail*f.f_frsize
capacity['workspace_shortfall_bytes']=max(0,9380818650-capacity['/workspace_available_bytes'])
capacity['preDocker_capacity_pass']=capacity['workspace_shortfall_bytes']==0
save('input-ledger.json',ledger)
save('independent-source-checks.safe.json',{'verdict':'CHANGES_REQUESTED','checks':checks,'count':len(checks),'selected_pure_controls':pure,'runtime_helper_imports':0,'native_runtime':False})
save('metadata-only.safe.json',metadata_result)
save('resource-snapshot.safe.json',capacity)
save('findings.safe.json',{'verdict':'CHANGES_REQUESTED','findings':[{'id':'DATA157-DOCKER-OLD156','priority':2,'path':str(NEW/'docker-up-restart.py'),'line':next(i for i,l in enumerate(docker.splitlines(),1) if 'boundary.verify_existing_data' in l),'cause':'Docker still consumes historical156 stopped fence after new157 grant admission. Exact comparison fails before cohort creation/Docker launch.','independent_selected_source_counterexample':True,'minimum_correction':'New frozen author source must consume boundary.load_existing_data_fence(grant) for Docker as Mongo already does; preserve original seals and fresh independent review before any new grant.'}],'resource_block':capacity,'limits':['No DB/key/ENV/private grant/log/body reads or hashes.','No source changes/helper module imports/native probes/apps/Docker/API/launch.','157 schema checked against fixed authenticated SAFE metadata only.','Runtime capacity needs fresh proof after authorized release; no budget relaxation.','sameUID/soft guards/no hard isolation and earlier JVM KILL qualification preserved.']})
print(json.dumps({'verdict':'CHANGES_REQUESTED','checks':len(checks),'pure_controls':len(pure),'metadata':metadata_result,'capacity':capacity}))
