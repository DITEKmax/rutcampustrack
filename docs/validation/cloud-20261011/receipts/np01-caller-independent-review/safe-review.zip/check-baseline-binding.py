from pathlib import Path
import ast,datetime,hashlib,json,types
P=Path('/workspace/scratch/rct-validation/np01_broker_sensitivity_sourceprep');O=Path('/workspace/scratch/rct-validation/np01_native_caller_review');WT=Path('/workspace/rct-worktrees/np01-broker-sensitivity');script=P/'run-stage.py'
ns={'__file__':str(script),'__name__':'read_only_source_control'};exec(compile(script.read_bytes(),str(script),'exec'),ns)
source=json.loads((P/'sourceprep.safe.json').read_text());procedure=json.loads((P/'native-procedure.safe.json').read_text());baseline=json.loads((P/'complete-sparse-baseline.safe.json').read_text());d=ns['digest'];rowmap={str(WT/e['path']):e['sha256'] for e in baseline['entries']};rowmap.update({str(WT/e['path']):e['candidate_sha256'] for e in source['changes']})
now=datetime.datetime.now(datetime.timezone.utc);grant={'authorized':True,'phase':'compile','source_base':ns['BASE'],'driver_sha256':d(script),'procedure_sha256':d(P/'native-procedure.safe.json'),'sourceprep_sha256':d(P/'sourceprep.safe.json'),'guard_sha256':ns['GUARD_SHA'],'issued_utc':(now-datetime.timedelta(seconds=1)).isoformat(),'expires_utc':(now+datetime.timedelta(seconds=900)).isoformat(),'limits':{'disk_delta_cap_bytes':2*ns['GIB'],'workspace_floor_bytes':4*ns['GIB'],'shared_growth_cap_bytes':4*ns['GIB'],'shared_stop_bytes':15*ns['GIB'],'shared_reserve_bytes':ns['GIB'],'owned_tree_rss_cap_bytes':4*ns['GIB'],'cleanup_margin_seconds':60,'deadline_seconds':600}}
class Grant:
 def is_symlink(self):return False
 def resolve(self):return ns['ROOT_RECEIPTS']/'PUBLIC_SYNTHETIC_NOT_CREATED.json'
 def stat(self):return types.SimpleNamespace(st_mode=0o100600)
 def read_text(self):return json.dumps(grant)
class Artifact:
 def __init__(self,name):self.name=name
 def read_text(self):return json.dumps({'native-procedure.safe.json':procedure,'sourceprep.safe.json':source,'complete-sparse-baseline.safe.json':current_baseline}[self.name])
class Here:
 def __truediv__(self,name):return Artifact(name)
ns['HERE']=Here();g=Grant()
def fake_digest(p):
 if isinstance(p,Grant):return 'PUBLIC_FAKE_GRANT_SHA'
 if isinstance(p,Artifact):return grant[{'native-procedure.safe.json':'procedure_sha256','sourceprep.safe.json':'sourceprep_sha256'}[p.name]]
 if str(p)==str(WT/'gradlew'):return '0'*64
 if str(p) in rowmap:return rowmap[str(p)]
 return d(Path(p))
ns['digest']=fake_digest
results=[]
for name,ledger in [('exact_1945_ledger',baseline),('empty_substitution',{'base':ns['BASE'],'entries':[]}),('one_selected_only_substitution',{'base':ns['BASE'],'entries':[next(e for e in baseline['entries'] if e['path']==source['changes'][0]['path'])]})]:
 current_baseline=ledger
 try:ns['grant_input'](g,'PUBLIC_FAKE_GRANT_SHA','compile');accepted=True
 except ValueError:accepted=False
 results.append({'ledger':name,'ledger_entries':len(ledger['entries']),'unselected_gradlew_digest_model_mismatch':True,'actual_grant_input_accepts':accepted})
assert results[0]['actual_grant_input_accepts'] is False and all(r['actual_grant_input_accepts'] for r in results[1:])
(O/'baseline-binding-counterexample.safe.json').write_text(json.dumps({'finding':'NP01-CALLER-BASELINE-BINDING','cases':results,'actual_selected_grant_input':True,'actual_baseline_or_source_files_changed':False,'no_grant_file_created_or_private_contents_read':True,'no_runtime_or_guard_child':True,'qualification':'Only public sealed metadata/source plus synthetic in-memory grant/artifact/digest substitutions; unselected file body not mutated. Current driver/procedure/sourceprep/guard hashes remain exact.'},indent=2)+'\n')
print(json.dumps({'cases':len(results),'actual_unselected_verification_bypass_cases':sum(r['actual_grant_input_accepts'] for r in results),'runtime_or_source_mutation':False}))
