APPROVE_FINITE_NODE_EVIDENCE actual41949.
Expected oldcausal native1/exact2bool witness; corrected native0/all9; types0/fields2+7/list3original14,61,142.
All5 known child births natural terminal/reaped, no infra/signals; supervisorbirthNOT_CAPTURED qualified.
Root19/old11/new13 exact and original902762/r1approval169a immutable.
Source-adapter sensitivity only, no actual transport/browser/API or original client-cause closure.
Read REPORT.md, evidence.safe.json and receipt-ledger.safe.json. No new audit/rerun needed.
