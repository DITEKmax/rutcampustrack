import { defineConfig } from '/workspace/rutcampustrack/tests/e2e/node_modules/@playwright/test';
import focused from './focus3.config';

// Distinct --list command/config only. No fixture, API, login, browser or webServer is executed.
export default defineConfig<{}, { teachingInstant: Date | undefined }>({
  ...focused,
  webServer: undefined,
  reporter: [['/workspace/scratch/rct-validation/client_real_acceptance/focused3-preparation-5ced/discovery-reporter.cjs']],
});
