import datetime
import hashlib
import io
import json
import pathlib
import re
import subprocess
import xml.etree.ElementTree as ET
import zipfile

OUT = pathlib.Path('/workspace/scratch/rct-validation/export_audit_independent_review')
AUTHOR = pathlib.Path('/workspace/scratch/rct-validation/export_audit_http_followon')
ROOT = pathlib.Path('/workspace/rutcampustrack/docs/validation/cloud-20261011/receipts/export-audit-http-final')
WT = pathlib.Path('/workspace/rct-worktrees/exports')
HEAD = '1bb527d5acdc704fab1b1df9bdf1ee4db9c474b6'
PARENT = 'f09b70e383b1c29b31960b5da99647f8ae6530bf'
TEST = 'services/auth-service/auth-app/src/test/java/ru/rutcampustrack/auth/integration/ExportJobHttpIT.java'

def sha(data):
    return hashlib.sha256(data).hexdigest()

def read_json(path):
    return json.loads(path.read_bytes())

def git(*args):
    return subprocess.check_output(['git', '-C', str(WT), *args])

def tree(revision):
    return {line.split('\t')[1]: line.split('\t')[0]
            for line in git('ls-tree', '-r', revision).decode().splitlines()}

old_tree, new_tree = tree(PARENT), tree(HEAD)
changed = [p for p in old_tree if old_tree[p] != new_tree[p]]
assert changed == [TEST] and len(old_tree) == len(new_tree) == 6510
source = git('show', HEAD + ':' + TEST)
old_source = git('show', PARENT + ':' + TEST)
assert sha(source) == '7116bf1fde7346bbb8dde9ae8d3a6f5bb9e3aa74abedf07e427ba2bfee19dbff'
assert sha(old_source) == '639433e7fc5bb3508eacd439ebed24dfdd278441f16452e3f0f6cc4a50750a26'
assert source == (WT / TEST).read_bytes()
old_oracle = '''        assertThat(jdbc.queryForObject("SELECT count(*) FROM audit_log WHERE action='registry.export'", Long.class)).isEqualTo(1);'''
new_oracle = '''        assertThat(jdbc.queryForObject("SELECT count(*) FROM audit_log WHERE action='registry.export' AND extras->>'jobId'=?", Long.class, id.toString())).isEqualTo(1);'''
before = (AUTHOR / 'runtime/overlays/before-global/ExportJobHttpIT.java').read_bytes()
assert before == source.replace(new_oracle.encode(), old_oracle.encode(), 1)
injection = '''        assertThat(jdbc.update("INSERT INTO audit_log(user_id,action,target_type,extras,succeeded,created_at) "
                + "SELECT user_id,action,target_type,extras,succeeded,NOW() FROM audit_log "
                + "WHERE action='registry.export' AND extras->>'jobId'=?", id.toString())).isEqualTo(1);
'''
duplicate = (AUTHOR / 'runtime/overlays/duplicate-current/ExportJobHttpIT.java').read_bytes()
assert duplicate == source.replace(new_oracle.encode(), injection.encode() + new_oracle.encode(), 1)

manifest_bytes = (AUTHOR / 'final-manifest.safe.json').read_bytes()
assert sha(manifest_bytes) == '78f04b69a0289a69711f4d0bff511dba1094d4246e9a0b8748fc1b657b789190'
manifest = json.loads(manifest_bytes)
assert len(manifest['members']) == 71
archive_bytes = (AUTHOR / 'export-audit-final-safe-evidence.zip').read_bytes()
assert sha(archive_bytes) == '1bfbf9ea699d7c6f39f347d54c191878e94cbebaf0085e3f934484c8ac18299e'
root_index = read_json(ROOT / 'original-byte-index.json')
parts = []
for part in root_index['immutable_originals_parts']:
    data = (ROOT / part['path']).read_bytes()
    assert len(data) == part['bytes'] and sha(data) == part['sha256']
    parts.append(data)
root_archive = b''.join(parts)
assert len(root_archive) == root_index['immutable_originals_bytes']
assert sha(root_archive) == root_index['immutable_originals_sha256']
working_members = {e['path']: e for e in root_index['files']}
readable_count = 0
working_transformations = []
with zipfile.ZipFile(io.BytesIO(archive_bytes)) as author_zip, zipfile.ZipFile(io.BytesIO(root_archive)) as root_zip:
    assert len(author_zip.infolist()) == len(root_zip.infolist()) == 72
    assert set(author_zip.namelist()) == set(root_zip.namelist())
    for entry in manifest['members'] + [{'path': 'final-manifest.safe.json', 'sha256': sha(manifest_bytes), 'bytes': len(manifest_bytes)}]:
        name = entry['path']
        assert not name.startswith('/') and '..' not in pathlib.PurePosixPath(name).parts
        data = author_zip.read(name)
        assert len(data) == entry['bytes'] and sha(data) == entry['sha256']
        assert root_zip.read(name) == data
        indexed = working_members[name]
        assert indexed['original_sha256'] == sha(data) and indexed['original_bytes'] == len(data)
        if 'working_path' in indexed:
            with zipfile.ZipFile(ROOT / indexed['working_path']) as readable:
                assert len(readable.infolist()) == 1
                assert readable.read(indexed['archive_member']) == data
            assert indexed['working_sha256'] == sha(data) and indexed['working_bytes'] == len(data)
            readable_count += 1
        else:
            working = (ROOT / name).read_bytes()
            assert sha(working) == indexed['working_sha256'] and len(working) == indexed['working_bytes']
            if indexed['transformation'] == 'only final newline normalization':
                assert name.endswith('result.redacted.xml') and not data.endswith(b'\n')
                assert working == data + b'\n'
                working_transformations.append({'path': name, 'transformation': 'one declared final newline only'})
            else:
                assert working == data
assert readable_count == 9
assert len(working_transformations) == 4

summary = read_json(AUTHOR / 'runtime/final-summary.safe.json')
redaction = {e['phase']: e for e in read_json(AUTHOR / 'runtime/native-XML-redaction-manifest.safe.json')}
phases = []
inventory_bytes = None
for phase in summary['phases']:
    name = phase['phase']
    directory = AUTHOR / 'runtime' / name
    result = read_json(directory / 'results.safe.json')
    terminal = read_json(directory / 'terminal.safe.json')
    private = (directory / 'result.private.xml').read_bytes()
    assert len(private) == result['xml_bytes'] and sha(private) == result['xml_sha256']
    assert redaction[name]['native_XML_sha256'] == sha(private)
    native = ET.fromstring(private)
    redacted_bytes = (directory / 'result.redacted.xml').read_bytes()
    assert sha(redacted_bytes) == redaction[name]['redacted_XML_sha256']
    derived = ET.fromstring(redacted_bytes)
    assert native.attrib == derived.attrib
    ncase, dcase = native.find('testcase'), derived.find('testcase')
    assert ncase.attrib == dcase.attrib
    counts = {k: int(native.attrib[k]) for k in ['tests', 'failures', 'errors', 'skipped']}
    assert counts['tests'] == 1 and counts['errors'] == counts['skipped'] == 0
    assert terminal['native_exit'] == result['native_exit'] == phase['native']['exit']
    assert terminal['disk_floor_stop'] is False
    failure = ncase.find('failure')
    if name in ['before-global', 'duplicate-current']:
        assert counts['failures'] == 1 and terminal['native_exit'] == 1
        assert failure.attrib['type'] == 'org.opentest4j.AssertionFailedError'
        text = failure.attrib.get('message', '') + '\n' + (failure.text or '')
        assert re.search(r'expected:\s*1', text) and re.search(r'but was:\s*2', text)
        lines = sorted(set(re.findall(r'ExportJobHttpIT.java:\d+', text)))
        assert lines == ['ExportJobHttpIT.java:85' if name == 'before-global' else 'ExportJobHttpIT.java:88']
        assert dcase.find('failure').attrib['type'] == failure.attrib['type']
        assert not (dcase.find('failure').text or '').strip()
        scalar = {'expected': 1, 'actual': 2, 'source_frames': lines}
    else:
        assert failure is None and counts['failures'] == 0 and terminal['native_exit'] == 0
        scalar = {'current_exact1_and_history_exact1': 'Accepted source assertions PASS'}
    assert native.find('testcase/error') is None and native.find('testcase/skipped') is None
    for side in ['before', 'after']:
        data = (directory / ('all-inputs-' + side + '.safe.json')).read_bytes()
        if inventory_bytes is None:
            inventory_bytes = data
        assert data == inventory_bytes
    phases.append({'phase': name, 'native_session': phase['native']['session'], 'native_exit': terminal['native_exit'],
                   'counts': counts, 'native_xml_sha256': sha(private), 'native_xml_bytes': len(private),
                   'redacted_xml_sha256': sha(redacted_bytes), 'native_and_redacted_metadata_equal': True,
                   'safe_scalars_only': scalar})
inventory = json.loads(inventory_bytes)
assert len(inventory) == 6510
original_entries = read_json(AUTHOR / 'before-source-inventory.safe.json')['all_tracked_inputs']
original_inventory = {e['path']: {k: e[k] for k in ['sha256', 'bytes', 'mode']} for e in original_entries}
assert len(original_inventory) == 6510
assert [p for p in inventory if inventory[p] != original_inventory[p]] == [TEST]
for path, identity in inventory.items():
    data = (WT / path).read_bytes()
    assert len(data) == identity['bytes'] and sha(data) == identity['sha256']
    assert oct((WT / path).stat().st_mode & 0o777) == identity['mode']
class_path = WT / 'services/auth-service/auth-app/build/classes/java/test/ru/rutcampustrack/auth/integration/ExportJobHttpIT.class'
final_bridge = read_json(AUTHOR / 'runtime/final-source-bridge.safe.json')
assert sha(class_path.read_bytes()) == final_bridge['canonical_class_sha256']
assert len(class_path.read_bytes()) == final_bridge['canonical_class_bytes']
release = read_json(AUTHOR / 'runtime/lease-release.safe.json')
assert release['state'] == 'RELEASED' and release['own_active_Java_process_count'] == 0
assert release['own_all12_container_ids_standardcleaned']
result = {'timestamp': datetime.datetime.now(datetime.timezone.utc).isoformat(),
          'status': 'PASS_INDEPENDENT_SOURCE_AND_RECEIPT_VERIFICATION', 'reviewed_commit': HEAD, 'parent': PARENT,
          'source_path': TEST, 'source_sha256': sha(source), 'source_bytes': len(source),
          'sole_changed_source_and6509other_git_blobs_modes_preserved': True,
          'exact_source_overlay_deltas': {'before-global': 'Only scoped oracle replaced by original global exact1 oracle',
                                         'duplicate-current': 'Only one valid samejob durablefact INSERT SELECT with exact1 insertion guard before unchanged exact1 oracle'},
          'all8_phase_inventories_identical_and6510current_source_bytes_modes_matched': True,
          'canonical_source_class_final_hash_verified': final_bridge['canonical_class_sha256'],
          'phases': phases,
          'lossless_root_transfer': {'manifest_sha256': sha(manifest_bytes), 'author_archive_sha256': sha(archive_bytes),
                                    'root_container_sha256': sha(root_archive), 'parts': 5,
                                    '71members_plus_manifest_exact': True, 'readable_inventory_ZIPs': 9,
                                    'declared_working_derived_XML_transformations': working_transformations,
                                    'qualification': 'ZIP-container bytes differ after root repack; all72 decoded memberbytes are author-exact. No raw archive byte-equivalence claim.'},
          'old_remote_CI_numeric_actual': 'UNKNOWN; local intended counterexamples actual2 kept separate',
          'release_author_receipt': release,
          'reviewer_runtime_reruns': 0,
          'qualification': 'Original V56 exports producer; not current integrated wholeAuth/V57 or new remote all-three gates. Existing Rabbit publisher mocked; actual directAuthHTTP/PG/Redis and selected assertion outcomes only.'}
(OUT / 'verification.safe.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({'status': result['status'], 'source': HEAD, 'phases': 4,
                  'root_original_memberbytes': 72, 'readable_inventory_ZIPs': 9,
                  'current_inputs_verified': 6510, 'canonical_class_verified': True}))
