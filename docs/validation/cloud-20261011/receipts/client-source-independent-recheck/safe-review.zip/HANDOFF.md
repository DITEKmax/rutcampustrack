cf067a008d732ca77f385a3eb1f53e0a79234687 narrow independent recheck: APPROVE_SOURCE, blocking source findings0. CRA-EXPORT-T01/CLOSED_SOURCE_AND_PURE_ORACLE_CONTROLS; CRA-VIEWPORT-T02/CLOSED_SOURCE_AND_ACTUAL_SOURCE_DISCOVERY. Original8fe two P2 findings/10receipt seal remain immutable.

Exact source4 corrections/7total actual=frozenGit=archive45; unchanged3 and prior28 public critical source proofs reused by exactbytes. Native source receipts independently opened/validated: TS/format0, explicit28/effective390×844/hooks1/offflags, export2positive/18intendednegative +old18falsegreen, TMA5matching/5wrongHMAC/5unrelated401. No repeat Node/browser/product runtime by reviewer.

TMA fresh same-target valid200/owner/cookie before every date-negative and specific rejection cause now source-present; real stand-v4 signer/clock/TLS/currentsource/resource readiness and actual14 runtime are separate Root/ci731/runtimeowner prerequisites. No private ENV/key values read. All11 CLIENT groups remainUNKNOWN.

Root next: integrate exact reviewed NEW7 plus separately owned1b4 defaultignore context; actual finite client run only under separatecurrent grant. Preserve sanitized artifacts/source identities and narrow relevant mutation red→restoredgreen; do not promote pure oracle controls to actual API/client PASS. This correction package is immutable after seal; future checks use NEW scratch.
