import datetime,hashlib,json,os,subprocess,types
from pathlib import Path
import yaml
OWN=Path('/workspace/scratch/rct-validation/current_host_config_directional_v3');OUT=Path(__file__).parent;PROJECT='rct-client-host-config-20261012'
os.umask(0o077)
def save(name,data):(OUT/name).write_text(json.dumps(data,indent=2)+'\n')
def read(argv):
 p=subprocess.run(argv,stdout=subprocess.PIPE,stderr=subprocess.DEVNULL,stdin=subprocess.DEVNULL,timeout=30)
 if p.returncode:raise RuntimeError('Metadata failed')
 return p.stdout.decode().strip()
def resources():
 fs=os.statvfs('/workspace');return {'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'free_available_bytes':fs.f_bavail*fs.f_frsize,'memory_current':int(Path('/sys/fs/cgroup/memory.current').read_text()),'memory_max':int(Path('/sys/fs/cgroup/memory.max').read_text())}
compose=yaml.safe_load((OWN/'data-renderer-edge.compose.yml').read_text())
ids=read(['docker','container','ls','-aq','--no-trunc','--filter','label=com.docker.compose.project='+PROJECT]).splitlines();assert len(ids)==9
records=[];services=set()
for ident in ids:
 template='{"id":{{json .Id}},"name":{{json .Name}},"image":{{json .Image}},"project":{{json (index .Config.Labels "com.docker.compose.project")}},"service":{{json (index .Config.Labels "com.docker.compose.service")}},"status":{{json .State.Status}},"pid":{{json .State.Pid}},"exit":{{json .State.ExitCode}}}'
 row=json.loads(read(['docker','container','inspect',ident,'--format',template]))
 assert row['id']==ident and row['project']==PROJECT and row['service'] in compose['services']
 assert row['image']==compose['services'][row['service']]['image'] and row['status']=='created' and row['pid']==0
 assert row['name']==('/'+PROJECT+'-'+row['service']+'-1')
 services.add(row['service']);records.append(row)
assert services==set(compose['services'])
volumes=read(['docker','volume','ls','-q','--filter','label=com.docker.compose.project='+PROJECT]).splitlines();assert set(volumes)=={v['name'] for v in compose['volumes'].values()}
save('cleanup-before.safe.json',{'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exact_owned_containers':records,'volumes_preserve':volumes,'resources':resources(),'no_services_ever_started':True})
body=(OWN.parent/'guard_proc_race_correction/bounded-child.py').read_bytes();assert hashlib.sha256(body).hexdigest()=='b78c61293568d9941692e0b92ee34fd0b84db6d532b4a2c9a5ad42ccbf2204a0'
guard=types.ModuleType('reviewed_guard');exec(compile(body,'reviewed_guard','exec'),guard.__dict__)
argv=json.loads((OWN/'launch-commands-v3.json').read_text())['Docker9_cleanup_only_exact_owned_project_after_label_ID_recheck'];assert '-v' not in argv
result=guard.run_owned(argv,str(OWN),{'PATH':'/usr/local/bin:/usr/bin:/bin','HOME':str(OWN/'runtime'),'LANG':'C.UTF-8','LC_ALL':'C.UTF-8'},deadline_seconds=120,status=lambda value:save('cleanup-process.safe.json',value))
assert result['settled']
remaining=read(['docker','container','ls','-aq','--filter','label=com.docker.compose.project='+PROJECT])
volume_after=read(['docker','volume','ls','-q','--filter','label=com.docker.compose.project='+PROJECT]).splitlines()
network_after=read(['docker','network','ls','-q','--filter','name=^'+PROJECT+'_private_net$'])
assert not remaining and not network_after and set(volume_after)==set(volumes)
report={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'guard':result,'resources':resources(),'remaining_owned_containers':0,'owned_network_absent':True,'all_five_owned_volumes_preserved':True,'volumes':volume_after,'hosts_launched':0,'service_readiness_TLS_browser':'NOT_RUN'}
save('cleanup-terminal.safe.json',report);save('CURRENT.json',{'status':'DISK_FLOOR_INTERRUPTED_DOCKER9_CREATED_ONLY_CLEANUP_TERMINAL','hosts_launched':0,'owned_container_network_absent':True,'five_volumes_preserved':True,'resources':report['resources'],'next':'Root measured allocation correction before new lease; do not retry silently'})
print(json.dumps({'cleanup_native_exit':result['native_exit'],'settled':result['settled'],'containers_remaining':0,'volumes_preserved':len(volume_after),'resources':report['resources']}))
