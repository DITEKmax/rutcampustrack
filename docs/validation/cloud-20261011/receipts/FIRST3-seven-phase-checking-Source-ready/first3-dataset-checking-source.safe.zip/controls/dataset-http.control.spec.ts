import { writeFileSync } from 'node:fs';
import { test, sanitizeTestErrors } from '/workspace/rct-worktrees/first3-dataset-correction-20261013/tests/e2e/fixtures/artifact-privacy';
import { datasetHttpFailure } from '/workspace/rct-worktrees/first3-dataset-correction-20261013/tests/e2e/fixtures/safe-reporter';

const marker = process.env.RCT_SAFE_FAILURE_CONTROL_MARKER!;
test.afterEach(async ({}, info) => sanitizeTestErrors(info));
const early = test.extend<{}, { publicEarly: void }>({
  publicEarly: [async () => {
    const error = datasetHttpFailure('POST', '/api/academic/groups/registry', 400);
    error.stack += `\n    at publicControl (/public/${marker}:1:1)`;
    throw error;
  }, { scope: 'worker' }],
});
early.fail('closed dataset HTTP survives a preobserver worker fixture failure', async ({ publicEarly }, info) => {
  void publicEarly;
  writeFileSync(info.outputPath('body-started.safe.json'), JSON.stringify({ bodyStarted: true }));
  throw new Error('PUBLIC_BODY_MUST_NOT_START');
});
