"""Pure selected actual-source controls: no filesystem mutation, driver import or native/browser launch."""
import ast
import datetime as real_datetime
import json
from pathlib import Path
import stat
import types

OLD = Path('/workspace/scratch/rct-validation/client_real_acceptance/webkit-public-boot/run-probe.py')
NEW = Path(__file__).with_name('run-probe.py')


def actual_source(path):
    tree = ast.parse(path.read_text())
    functions = {item.name: item for item in tree.body if isinstance(item, ast.FunctionDef)}
    body = functions['main'].body
    namespace_start = next(i for i, node in enumerate(body) if isinstance(node, ast.Assign)
                           and any(isinstance(t, ast.Name) and t.id == 'runs' for t in node.targets))
    namespace_end = next(i for i, node in enumerate(body) if isinstance(node, ast.Assign)
                         and any(isinstance(t, ast.Name) and t.id == 'supervision' for t in node.targets))
    wrapper = [node for node in ast.walk(functions['main']) if isinstance(node, ast.Expr)
               and isinstance(node.value, ast.Call) and any(isinstance(a, ast.Constant)
               and a.value == 'WRAPPER_GRANT_EXPIRED' for a in node.value.args)]
    launch_index = next(i for i, node in enumerate(body) if isinstance(node, ast.Assign)
                        and isinstance(node.value, ast.Call) and isinstance(node.value.func, ast.Attribute)
                        and node.value.func.attr == 'run_owned')
    initial_index = next(i for i, node in enumerate(body) if isinstance(node, ast.Expr)
                         and isinstance(node.value, ast.Call) and any(isinstance(a, ast.Constant)
                         and a.value == 'GRANT_EXPIRED' for a in node.value.args))
    assert len(wrapper) == 1
    return functions, body[namespace_start:namespace_end], wrapper, body[launch_index - 1:launch_index + 1], body[initial_index - 2:initial_index + 1]


def evaluate(path, *, clock_second, resource_delay=False, low_disk=False, wrapper_second=None, dispatch=False):
    functions, namespace, wrapper, launch, initial = actual_source(path)
    utc = real_datetime.timezone.utc
    clock = {'value': real_datetime.datetime(2026, 1, 1, 0, 0, 9, tzinfo=utc)}
    events = {'mkdir': 0, 'dispatch': 0}

    class Date(real_datetime.datetime):
        @classmethod
        def now(cls, zone):
            return clock['value']

    class PublicPath:
        def __init__(self, value):
            self.value = str(value)
        def __truediv__(self, value):
            return PublicPath(self.value + '/' + str(value))
        def exists(self):
            return False
        def mkdir(self, **kwargs):
            events['mkdir'] += 1
        def is_symlink(self):
            return False
        def lstat(self):
            return types.SimpleNamespace(st_mode=stat.S_IFDIR | 0o700, st_uid=1000)
        def read_text(self):
            return {'/sys/fs/cgroup/memory.current': '1', '/sys/fs/cgroup/memory.max': '17179869184',
                    '/proc/self/status': 'VmRSS: 1 kB\n'}[self.value]

    def public_statvfs(filesystem):
        if resource_delay:
            clock['value'] = real_datetime.datetime(2026, 1, 1, 0, 0, 11, tzinfo=utc)
        return types.SimpleNamespace(f_bavail=1 if low_disk else 17179869184, f_frsize=1)

    def dispatch_public(*args, **kwargs):
        events['dispatch'] += 1
        return None

    grant = {'disk_floor_bytes': 4294967296, 'shared_stop_bytes': 16106127360,
             'shared_memory_reserve_bytes': 1073741824, 'owned_total_rss_stop_bytes': 1610612736,
             'issued_at': '2026-01-01T00:00:00Z', 'absolute_stop_at': '2026-01-01T00:00:10Z',
             'expires_at': '2026-01-01T00:00:20Z'}
    environment = {'Path': PublicPath, 'stat': stat, 'UTC': utc,
                   'os': types.SimpleNamespace(statvfs=public_statvfs, geteuid=lambda: 1000),
                   'datetime': types.SimpleNamespace(datetime=Date), 'BASE': PublicPath('/public/new'),
                   'grant': grant, 'stop': real_datetime.datetime(2026, 1, 1, 0, 0, 10, tzinfo=utc),
                   'attempt': 'attempt-01', 'guard': types.SimpleNamespace(run_owned=dispatch_public),
                   'argv': [], 'ROOT': PublicPath('/public/root'), 'env': {}, 'seconds': 1,
                   'observe': None, 'status': None}
    selected = [functions[n] for n in ['require', 'instant', 'private_directory']]
    if 'fresh_preflight' in functions:
        selected.append(functions['fresh_preflight'])
    exec(compile(ast.fix_missing_locations(ast.Module(body=selected, type_ignores=[])), 'selected-functions', 'exec'), environment)
    exec(compile(ast.fix_missing_locations(ast.Module(body=initial, type_ignores=[])), 'selected-initial-clock9', 'exec'), environment)
    clock['value'] = real_datetime.datetime(2026, 1, 1, 0, 0, clock_second, tzinfo=utc)
    if wrapper_second is not None:
        environment['browser_grant'] = {'not_before_utc': '2026-01-01T00:00:00Z',
                                       'stop_utc': f'2026-01-01T00:00:{wrapper_second:02d}Z'}
    chosen = wrapper if wrapper_second is not None else launch if dispatch else namespace
    denied = False
    deny_stage = None
    try:
        exec(compile(ast.fix_missing_locations(ast.Module(body=chosen, type_ignores=[])), 'selected-use-boundary', 'exec'), environment)
    except RuntimeError as error:
        denied = True
        value = error.args[0] if len(error.args) == 1 else None
        deny_stage = value if value in {'GRANT_EXPIRED_AT_USE', 'DISK_FLOOR_AT_USE', 'WRAPPER_GRANT_EXPIRED'} else 'OTHER'
    return {'denied': denied, 'denyStage': deny_stage, 'initialClock9Passed': True, **events}


def actual_wrapper_accepts_at11():
    wrapper = Path('/workspace/scratch/rct-validation/browser_webkit_native_anchor_correction/webkit-custom-exec.py')
    tree = ast.parse(wrapper.read_text())
    selected = [node for node in tree.body if isinstance(node, ast.FunctionDef) and node.name == 'validate_browser_grant'
                or isinstance(node, ast.Assign) and any(isinstance(target, ast.Name) and target.id == 'SAFE_ENV' for target in node.targets)]
    assert len(selected) == 2
    environment = {'datetime': real_datetime}
    exec(compile(ast.fix_missing_locations(ast.Module(body=selected, type_ignores=[])), 'selected-wrapper-schema-only', 'exec'), environment)
    public_grant = {'browser_launch_authorized': True, 'library_extraction_authorized': False,
                    'native_validation_authorized': False, 'execution_actor_uid': 1000, 'execution_actor_gid': 1000,
                    'not_before_utc': '2026-01-01T00:00:00Z', 'stop_utc': '2026-01-01T00:00:20Z',
                    'declared_browser_environment': {'PATH': '/usr/bin:/bin'}}
    return environment['validate_browser_grant'](public_grant, real_datetime.datetime(2026, 1, 1, 0, 0, 11, tzinfo=real_datetime.timezone.utc)) == public_grant['declared_browser_environment']


def main():
    # The old initial clock9 validation is already satisfied; source-selected
    # long preflight advances to11 before the unchanged namespace instructions.
    old_expired = evaluate(OLD, clock_second=11)
    new_expired = evaluate(NEW, clock_second=11)
    new_valid = evaluate(NEW, clock_second=9)
    new_delayed = evaluate(NEW, clock_second=9, resource_delay=True)
    new_low_disk = evaluate(NEW, clock_second=9, low_disk=True)
    old_later = evaluate(OLD, clock_second=9, wrapper_second=20)
    new_later = evaluate(NEW, clock_second=9, wrapper_second=20)
    new_equal = evaluate(NEW, clock_second=9, wrapper_second=10)
    new_dispatch_expired = evaluate(NEW, clock_second=11, dispatch=True)
    new_dispatch_delayed = evaluate(NEW, clock_second=9, resource_delay=True, dispatch=True)
    new_dispatch_valid = evaluate(NEW, clock_second=9, dispatch=True)
    checks = {
        'oldExpiredCreatesSixMockedDirectories': not old_expired['denied'] and old_expired['mkdir'] == 6,
        'newExpiredCreatesNone': new_expired['denyStage'] == 'GRANT_EXPIRED_AT_USE' and new_expired['mkdir'] == 0,
        'newValidCreatesSix': not new_valid['denied'] and new_valid['mkdir'] == 6,
        'newResourceDelayExpiresBeforeMutation': new_delayed['denyStage'] == 'GRANT_EXPIRED_AT_USE' and new_delayed['mkdir'] == 0,
        'newDiskFloorDeniesBeforeMutation': new_low_disk['denyStage'] == 'DISK_FLOOR_AT_USE' and new_low_disk['mkdir'] == 0,
        'oldLaterWrapperAccepted': not old_later['denied'],
        'actualWrapperLaterDeadlineAcceptsClock11': actual_wrapper_accepts_at11(),
        'newLaterWrapperDenied': new_later['denyStage'] == 'WRAPPER_GRANT_EXPIRED',
        'newEqualWrapperAccepted': not new_equal['denied'],
        'newExpiredDispatchDenied': new_dispatch_expired['denyStage'] == 'GRANT_EXPIRED_AT_USE' and new_dispatch_expired['dispatch'] == 0,
        'newDelayedDispatchDenied': new_dispatch_delayed['denyStage'] == 'GRANT_EXPIRED_AT_USE' and new_dispatch_delayed['dispatch'] == 0,
        'newValidDispatchOnce': not new_dispatch_valid['denied'] and new_dispatch_valid['dispatch'] == 1,
    }
    print(json.dumps({'schema': 'RCT_WEBKIT_USE_TIME_SOURCE_CONTROLS_V1', 'qualification': 'PURE_SELECTED_ACTUAL_SOURCE_WITH_MOCKED_RESOURCES_CLOCK_AND_MUTATIONS', 'initialClock9Passed': all(row['initialClock9Passed'] for row in [old_expired, new_expired, new_valid, new_delayed, new_low_disk, old_later, new_later, new_equal, new_dispatch_expired, new_dispatch_delayed, new_dispatch_valid]), 'checks': checks, 'passed': all(checks.values()), 'browser_native': 'NOT_RUN'}))
    return 0 if all(checks.values()) else 1


if __name__ == '__main__':
    try:
        raise SystemExit(main())
    except Exception:
        print('{"state":"SOURCE_CONTROL_FAILED","raw_error_emitted":false}')
        raise SystemExit(2)
