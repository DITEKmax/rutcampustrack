SOURCE_READY_COMPILE_ONLY_NOT_GRANTED.
Only source/file metadata preparation and PythonAST parse; no actualhelper/nativeGradle/JVM/Docker/API.
Next freshRoot source/resourcegrant for compile-only; testexecution stillheld.
