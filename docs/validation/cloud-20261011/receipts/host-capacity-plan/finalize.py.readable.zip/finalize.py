import datetime
import hashlib
import json
import os
from pathlib import Path
import stat
import subprocess

OUT=Path(__file__).parent
d=json.loads((OUT/'source-diagnosis.json').read_text())
rows=[]
for scope in d['scopes']:
    root=Path('/workspace/rct-worktrees')/scope['scope']
    assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root).decode().strip()==scope['head']
    assert not subprocess.check_output(['git','status','--porcelain','--untracked-files=no'],cwd=root).strip()
    rows+=json.loads((OUT/(scope['scope']+'-candidates.json')).read_text())
assert len({(r['candidate']['device'],r['candidate']['inode']) for r in rows})==len(rows)
for row in rows:
    a,b=row['candidate'],row['reference']
    assert all(a[k]==b[k] for k in ['sha256','bytes','mode','uid','gid','device'])
    assert a['nlink']==1 and a['inode']!=b['inode']
    for item in [a,b]:
        q=Path(item['path']);s=q.lstat()
        assert not any(p.is_symlink() for p in [q,*q.parents])
        assert (s.st_dev,s.st_ino,s.st_size,s.st_mtime_ns,s.st_nlink,s.st_blocks*512,stat.S_IMODE(s.st_mode),s.st_uid,s.st_gid)==(item['device'],item['inode'],item['bytes'],item['mtime_ns'],item['nlink'],item['allocated_bytes'],int(item['mode'],8),item['uid'],item['gid'])
old=json.loads(Path('/workspace/scratch/rct-validation/current_client_artifacts/frozen-source-large-duplicate-proposal.json').read_text())
oldpaths={r['new_own_path'] for r in old['candidates']}
new={r['candidate']['path'] for r in rows if r['scope']=='client-current-artifacts'}
reference=Path('/workspace/rct-worktrees/client-acceptance')
validation={'time':datetime.datetime.now(datetime.timezone.utc).isoformat(),'rows':len(rows),'unique_physical_inodes':len(rows),
            'uid_gid_mode_equal':True,'symlink_ancestry_absent':True,'metadata_unchanged':True,
            'reference_head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=reference).decode().strip(),
            'reference_tracked_status':subprocess.check_output(['git','status','--porcelain','--untracked-files=no'],cwd=reference).decode().splitlines(),
            'old494_overlap_count':len(oldpaths&new),'old494_overlap_bytes':sum(r['candidate']['allocated_bytes'] for r in rows if r['candidate']['path'] in oldpaths),
            'old494_extra_count':len(oldpaths-new),'smaller_old_plans_nonadditive':True,'actual_recovered_bytes':0,'resource_mutations':False}
(OUT/'candidate-validation.json').write_text(json.dumps(validation,indent=2)+'\n')
preservation=[]
for entry in json.loads((OUT/'preservation-before.json').read_text()):
    p=Path(entry['manifest']);assert hashlib.sha256(p.read_bytes()).hexdigest()==entry['sha256']
    manifest=json.loads(p.read_text())
    for item in manifest.get('safe_files',manifest.get('files')):
        q=Path(item['path']);assert q.stat().st_size==item['bytes']
        with q.open('rb') as stream:assert hashlib.file_digest(stream,'sha256').hexdigest()==item['sha256']
    preservation.append({**entry,'unchanged':True})
(OUT/'preservation-after.json').write_text(json.dumps(preservation,indent=2)+'\n')
s=os.statvfs('/workspace');free=s.f_bavail*s.f_frsize;gain=d['combined_unique_countable_allocated_bytes']
required=8277277457;transient=134217728
budget={'time':datetime.datetime.now(datetime.timezone.utc).isoformat(),'free_bytes':free,
        'memory_current':int(Path('/sys/fs/cgroup/memory.current').read_text()),'memory_max':int(Path('/sys/fs/cgroup/memory.max').read_text()),
        'cpu_max':Path('/sys/fs/cgroup/cpu.max').read_text().strip(),'required_original_pre_runtime_bytes':required,
        'required_with_standard_extraction_transient_bytes':required+transient,
        'components':{'floor_bytes':4294967296,'nine_Docker_VFS_image_logical_bytes':2707241745,'runtime_growth_reserve_bytes':1073741824,
                      'final8_payload_Vue_directory_reserve_bytes':201326592,'sequential_extractor_transient_bytes':transient},
        'current_original_deficit_bytes':max(0,required-free),'current_standard_extraction_deficit_bytes':max(0,required+transient-free),
        'candidate_unique_allocated_bytes':gain,'proposed_free_after_dedup_bytes':free+gain,
        'proposed_original_headroom_bytes':free+gain-required,'proposed_standard_extraction_headroom_bytes':free+gain-required-transient,
        'actual_reclaimed_bytes':0,'resource_mutations':False,'future_measurement_required':True}
(OUT/'budget.json').write_text(json.dumps(budget,indent=2)+'\n')
print(json.dumps({'validation':validation,'budget':budget,'preserved_original_files':sum(e['files'] for e in preservation)},indent=2))
