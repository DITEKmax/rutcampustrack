import fs from 'node:fs'
import crypto from 'node:crypto'
import vm from 'node:vm'
import { createRequire } from 'node:module'
const require = createRequire(import.meta.url)
const ts = require('/workspace/rutcampustrack/frontends/node_modules/typescript')
const scratch = '/workspace/scratch/rct-validation/client_real_acceptance'
const supportPath = '/workspace/rct-worktrees/client-real-acceptance/tests/e2e/fixtures/cloud-accepted-support.ts'
const support = fs.readFileSync(supportPath, 'utf8')
const source = ts.createSourceFile(supportPath, support, ts.ScriptTarget.Latest, true)
const oracle = source.statements.find((node) => ts.isFunctionDeclaration(node) && node.name?.text === 'registryHtmlBoundary')
if (!oracle) throw new Error('Current NEW oracle absent')
const emitted = ts.transpileModule(oracle.getText(source), { compilerOptions: { target: ts.ScriptTarget.ES2022, module: ts.ModuleKind.CommonJS } }).outputText
const sandbox = { exports: {} }
vm.runInNewContext(emitted, sandbox, { timeout: 1000 })
const inspect = sandbox.exports.registryHtmlBoundary
const beforePath = `${scratch}/export-8fe.original.ts`
const before = ts.createSourceFile(beforePath, fs.readFileSync(beforePath, 'utf8'), ts.ScriptTarget.Latest, true)
const bodyAsserts = []
function usesContent(node) {
  let found = false
  function scan(part) {
    if (ts.isIdentifier(part) && part.text === 'content') found = true
    ts.forEachChild(part, scan)
  }
  scan(node)
  return found
}
function visit(node) {
  if (ts.isCallExpression(node) && ts.isPropertyAccessExpression(node.expression) && node.expression.name.text === 'toBe') {
    const call = node.expression.expression
    if (ts.isCallExpression(call) && call.expression.getText(before) === 'expect' && call.arguments[0] && usesContent(call.arguments[0]))
      bodyAsserts.push({ actual: call.arguments[0].getText(before), expected: node.arguments[0].getText(before) })
  }
  ts.forEachChild(node, visit)
}
visit(before)
if (bodyAsserts.length !== 7) throw new Error('Unexpected historic body oracle inventory')
const ordinaryColumns = ['ФИО', 'Логин', 'Роли и статусы', 'Группа', 'Табельный номер', 'Привязка Telegram']
const target = { displayName: 'Controlled target', login: 'controlled-target', password: 'controlled-excluded-marker', telegramId: 8000000001 }
const nonmatching = { displayName: 'Controlled other', login: 'controlled-other' }
const ordinaryRow = [target.displayName, target.login, 'STUDENT: ACTIVE; TEACHER: ACTIVE', 'Controlled group', 'Controlled staff', 'Привязан']
const otherRow = [nonmatching.displayName, nonmatching.login, 'STUDENT: ACTIVE', 'Other group', '', 'Привязан']
const escape = (value) => value.replace(/[&<>"']/g, (character) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&apos;' })[character])
function table(columns, rows) {
  return '<!doctype html><html><table><thead><tr>' + columns.map((value) => `<th>${escape(value)}</th>`).join('') + '</tr></thead><tbody>' + rows.map((row) => '<tr>' + row.map((value) => `<td>${escape(value)}</td>`).join('') + '</tr>').join('') + '</tbody></table></html>'
}
function oldPass(content, mode) {
  const values = { content, target, mode }
  return bodyAsserts.every((check) => vm.runInNewContext(check.actual, values, { timeout: 1000 }) === vm.runInNewContext(check.expected, values, { timeout: 1000 }))
}
const controls = []
for (const mode of ['FULL', 'LIMITED']) {
  const full = mode === 'FULL'
  const columns = [...ordinaryColumns, ...(full ? ['Telegram ID'] : [])]
  const row = [...ordinaryRow, ...(full ? [String(target.telegramId)] : [])]
  const other = [...otherRow, ...(full ? ['8000000002'] : [])]
  const positive = table(columns, [row])
  const cases = [
    { id: 'ordinary-positive', content: positive, failure: null },
    { id: 'ignored-filter', content: table(columns, [row, other]), failure: 'oneRow' },
    ...[2, 3, 4, 5].map((index) => ({ id: `ordinary-column-omission-${index}`, content: table(columns.filter((_, n) => n !== index), [row.filter((_, n) => n !== index)]), failure: 'columnsExact' })),
    ...[2, 3, 4, 5].map((index) => ({ id: `ordinary-value-corruption-${index}`, content: table(columns, [row.map((value, n) => n === index ? 'Controlled wrong value' : value)]), failure: 'valuesExact' })),
  ]
  for (const sample of cases) {
    const result = inspect(sample.content, full, row, nonmatching)
    const beforePass = oldPass(sample.content, mode)
    const afterPass = Object.values(result).every((value) => value === true)
    const relevantFailure = sample.failure === null ? null : result[sample.failure] === false
    if (!beforePass || afterPass !== (sample.failure === null) || (sample.failure && !relevantFailure)) throw new Error(`Boundary control failed: ${mode}/${sample.id}`)
    if (sample.id === 'ignored-filter' && result.knownNonmatchAbsent !== false) throw new Error('Known nonmatching row escaped its oracle')
    controls.push({ mode, id: sample.id, before_pass: beforePass, after_pass: afterPass, relevant_oracle: sample.failure, relevant_oracle_rejected: relevantFailure, safe_boundary_results: result })
  }
}
const receipt = {
  finding: 'CRA-EXPORT-T01', kind: 'NATIVE_SOURCE_ORACLE_CONTROLLED_COUNTEREXAMPLES',
  timestamp: new Date().toISOString(), before_source_commit: '8fe9fe946ded3174796778b33f84385c6f98473b',
  current_source_path: supportPath, current_source_sha256: crypto.createHash('sha256').update(support).digest('hex'),
  actual_oracle_extracted_from_current_typescript: true, compiler_version: ts.version,
  historic_body_assertions: bodyAsserts.length, controls,
  body_html_or_personal_values_persisted: false,
  product_backend_browser_runtime: 'NOT_RUN', product_bug_claimed: false,
  limits: { node_heap_mib: 1024, network: false, child_processes: false },
}
fs.writeFileSync(`${scratch}/CRA-EXPORT-T01.controls.safe.json`, JSON.stringify(receipt, null, 2) + '\n')
process.stdout.write(JSON.stringify({ controls: controls.length, positives: controls.filter((row) => row.after_pass).length, relevant_negatives: controls.filter((row) => row.relevant_oracle_rejected).length, actual_oracle: true, runtime: 'NOT_RUN' }) + '\n')
