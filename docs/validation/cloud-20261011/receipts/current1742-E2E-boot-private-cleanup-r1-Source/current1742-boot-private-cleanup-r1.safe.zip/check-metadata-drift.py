"""Original/new actual AST counterexamples in RAM, without private/native effects."""
import ast
import datetime
import hashlib
import json
import os
from pathlib import Path
import re
import stat
import sys
import types

OWN = Path(__file__).parent
OLD = Path('/workspace/scratch/rct-validation/current1742_e2e_boot_diagnostic_source/closed-boot-parser.py')
NEW = OWN/'closed-boot-parser.py'
def selected(path):
    raw=path.read_bytes()
    nodes=[n for n in ast.parse(raw).body if isinstance(n,(ast.FunctionDef,ast.ClassDef,ast.Assign))]
    env={'dt':datetime,'re':re,'stat':stat,'sys':sys}
    exec(compile(ast.Module(body=nodes,type_ignores=[]),str(path),'exec'),env)
    return env

data=b'2026-10-13T11:03:10Z Container rct-e2e-redis-1 Healthy\n'
rows=[]
for name in ['NORMAL','UID_DRIFT_AFTER_READ','MODE_DRIFT_AFTER_READ',
    'NLINK_DRIFT_AFTER_READ','REPLACEMENT_INODE','NONREGULAR_DRIFT',
    'UID_DRIFT_ONLY_AT_CLEANUP','READ_PRIMARY_ERROR_WITH_UID_DRIFT']:
    results={}
    for label,path in [('old',OLD),('new',NEW)]:
        e=selected(path)
        b={'repo':'DITEKmax/rutcampustrack','head':e['HEAD'],'run_id':e['RUN'],
            'run_attempt':1,'job_id':e['JOB'],'job_name':'Playwright E2E auth flow',
            'step_number':9,'step_name':e['STEP'],'step_conclusion':'failure',
            'step_started_at':'2026-10-13T11:03:00Z','step_completed_at':'2026-10-13T11:04:00Z',
            'metadata_verified':True}
        initial=dict(st_dev=1,st_ino=2,st_mode=0o100600,st_uid=1000,st_gid=1000,
            st_nlink=1,st_size=len(data),st_mtime_ns=3,st_ctime_ns=4)
        later=initial.copy()
        if 'UID_DRIFT' in name:later.update(st_uid=999,st_ctime_ns=5)
        if name=='MODE_DRIFT_AFTER_READ':later.update(st_mode=0o100644,st_ctime_ns=5)
        if name=='NLINK_DRIFT_AFTER_READ':later.update(st_nlink=2,st_ctime_ns=5)
        if name=='REPLACEMENT_INODE':later.update(st_ino=9)
        if name=='NONREGULAR_DRIFT':later.update(st_mode=0o040600,st_ctime_ns=5)
        calls={'fstat':0,'reads':0,'closed':0,'unlinks':0}
        def fstat(fd):
            calls['fstat']+=1
            unchanged=calls['fstat']==1 or name in {'REPLACEMENT_INODE','UID_DRIFT_ONLY_AT_CLEANUP'}
            return types.SimpleNamespace(**(initial if unchanged else later))
        primary=OSError('PUBLIC_SYNTHETIC_PRIMARY')
        def read(fd,n):
            calls['reads']+=1
            if name=='READ_PRIMARY_ERROR_WITH_UID_DRIFT':raise primary
            return data
        def close(fd):calls['closed']+=1
        def unlink(name_,dir_fd):calls['unlinks']+=1
        e['os']=types.SimpleNamespace(O_RDONLY=os.O_RDONLY,O_NOFOLLOW=os.O_NOFOLLOW,
            open=lambda *a,**k:20,fstat=fstat,read=read,close=close,
            stat=lambda *a,**k:types.SimpleNamespace(**later),unlink=unlink)
        caught=None
        try:e['consume_private'](10,b)
        except BaseException as error:caught=error
        assert calls['reads']==1 and calls['closed']==1
        if label=='new':
            assert calls['unlinks']==(1 if name=='NORMAL' else 0)
            assert (caught is None)==(name=='NORMAL')
            if name=='READ_PRIMARY_ERROR_WITH_UID_DRIFT':
                assert caught is primary and caught.__notes__==['PRIVATE_CAPTURE_RETAINED_RECONCILIATION_REQUIRED']
        elif name not in {'NORMAL','REPLACEMENT_INODE'}:
            assert calls['unlinks']==1  # Exact old semantic counterexample.
        results[label]={'denied':caught is not None,'unlink_count':calls['unlinks'],
            'primary_error_preserved':caught is primary if name.startswith('READ_PRIMARY') else None}
    rows.append({'case':name,'results':results,'real_effects':False})
print(json.dumps({'state':'TARGETED_SOURCE_RAM_PASS','checks':rows,
    'source_sha256':{'old':hashlib.sha256(OLD.read_bytes()).hexdigest(),
        'new':hashlib.sha256(NEW.read_bytes()).hexdigest()},'actual_log_native_read':False}))
