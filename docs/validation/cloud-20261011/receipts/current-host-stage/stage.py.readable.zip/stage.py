"""Exact current production payload staging; stdlib only, no child processes."""
import datetime
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import re
import resource
import signal
import stat
import sys
import zipfile

BASE = Path('/workspace/scratch/rct-validation')
OUT = BASE / 'current_host_stage'
PAYLOAD = OUT / 'payload'
ORDER = ['auth', 'academic', 'schedule', 'attendance', 'bff', 'gateway', 'notification', 'renderer']
LAYERS = ['dependencies', 'spring-boot-loader', 'snapshot-dependencies', 'application']
FINAL_CAP = 201326592
SEALS = {
    'current_client_artifacts/manifest.json': '840492d38bfd204fe37c9bb46e89d3a3fdbc7957ad31ad1e9ca6ca058523ea7f',
    'current_artifact_review/manifest.json': '9b62cd7bab7a27c77de3a2048b527cab8d808d5e866fb705c93bf5271feddbcd',
    'host_capacity_plan/manifest.json': 'be3853df8f62a968c9e0e0171f70e4fa0b4435bcddce5b2b6e93b8c30f756a6b',
    'host_runtime_prepare/renderer-addendum-manifest.json': '8159e470b37267bb2e2142e5e772eb0b925e83b50f82a68cfb0842ba28389287',
    'current_artifact_corrections_v2/manifest.json': 'ff9f2c4121641cd7b530a9eb57919e83051492a666328ed9f649d91e2004c968',
    'current_artifact_correction_v2_review/manifest.json': '64715bd8880fb714f45f3cd3a719a442fc43384018e3067ce1c3a7dc321459ee',
    'host_capacity_correction/manifest.json': '4c2702f30182f291919b79d0d2b55bb8f917b94bd983f59f96bf7770b6485dcf',
    'capacity_premutation_aliases/manifest.json': 'a84242355d6223fbc2f87cd61b6b6928ce83d8bb476276df308afb8196496116',
    'physical_dedup1/manifest.json': '70bd8a7d4aadd226913551dd852e701d6cf2d0df54671fc89c84f3e1e78db687',
}
stop = False
signals = []


def utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def sha(path):
    h = hashlib.sha256()
    with open(path, 'rb') as f:
        while chunk := f.read(262144):
            h.update(chunk)
    return h.hexdigest()


def save(name, obj):
    with (OUT / name).open('w', encoding='utf-8') as f:
        json.dump(obj, f, indent=2, ensure_ascii=False)
        f.write('\n')
        f.flush()
        os.fsync(f.fileno())


def meta(path):
    s = os.lstat(path)
    return {'path': str(path), 'device': s.st_dev, 'inode': s.st_ino, 'nlink': s.st_nlink,
            'bytes': s.st_size, 'allocated_bytes': s.st_blocks * 512,
            'mode': oct(stat.S_IMODE(s.st_mode)), 'uid': s.st_uid, 'gid': s.st_gid,
            'mtime_ns': s.st_mtime_ns, 'ctime_ns': s.st_ctime_ns}


def allocated():
    seen = set()
    total = 0
    for d, dirs, files in os.walk(OUT, followlinks=False):
        for p in [Path(d)] + [Path(d) / n for n in files]:
            s = os.lstat(p)
            if stat.S_ISLNK(s.st_mode):
                raise RuntimeError('Unexpected stage symlink')
            key = (s.st_dev, s.st_ino)
            if key not in seen:
                seen.add(key)
                total += s.st_blocks * 512
        for n in dirs:
            if (Path(d) / n).is_symlink():
                raise RuntimeError('Unexpected directory symlink')
    return total


def resources():
    s = os.statvfs('/workspace')
    current = int(Path('/sys/fs/cgroup/memory.current').read_text())
    maximum = int(Path('/sys/fs/cgroup/memory.max').read_text())
    rss = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss * 1024
    result = {'utc': utc(), 'free_available_bytes': s.f_bavail * s.f_frsize,
              'memory_current': current, 'memory_max': maximum, 'own_peak_rss_bytes': rss,
              'own_unique_allocated_bytes': allocated()}
    if result['free_available_bytes'] < 4294967296 or maximum - current < 1073741824:
        raise RuntimeError('Disk/shared-memory floor unavailable')
    if rss > 134217728 or result['own_unique_allocated_bytes'] > FINAL_CAP:
        raise RuntimeError('Own stage allocation/RSS exceeds granted cap')
    return result


def safe_member(name, directory=False):
    stripped = name[:-1] if directory and name.endswith('/') else name
    p = PurePosixPath(stripped)
    if not stripped or p.is_absolute() or str(p) != stripped or any(x in ('..', '.') for x in p.parts) or '\\' in name or '\x00' in name or ':' in name:
        raise RuntimeError('Unsafe/noncanonical member path')
    return stripped


def mkdir_new(path):
    path.relative_to(OUT)
    if path == OUT:
        return
    mkdir_new(path.parent)
    if not path.exists():
        path.mkdir(mode=0o755)
        path.chmod(0o755)  # Newly created unshared directory only.
    s = os.lstat(path)
    if not stat.S_ISDIR(s.st_mode) or stat.S_IMODE(s.st_mode) != 0o755:
        raise RuntimeError('Unsafe stage directory or mode')


def parse_layers(data):
    result = {}
    current = None
    for line in data.decode('utf-8').splitlines():
        group = re.fullmatch(r'- "([a-z-]+)":', line)
        member = re.fullmatch(r'  - "([^"]+)"', line)
        if group:
            current = group.group(1)
            if current in result:
                raise RuntimeError('Duplicate layer')
            result[current] = []
        elif member and current:
            value = member.group(1)
            safe_member(value, value.endswith('/'))
            result[current].append(value)
        else:
            raise RuntimeError('Unexpected layers.idx syntax')
    if list(result) != LAYERS:
        raise RuntimeError('Standard layer order differs')
    return result


def member_layer(name, rules):
    matches = [layer for layer, paths in rules.items()
               if any(name.startswith(p) if p.endswith('/') else name == p for p in paths)]
    if len(matches) != 1:
        raise RuntimeError('Unmapped/ambiguous layer member')
    return matches[0]


def unfolded(data):
    lines = []
    for line in data.decode('utf-8').replace('\r\n', '\n').split('\n'):
        if line.startswith(' '):
            if not lines:
                raise RuntimeError('Manifest orphan continuation')
            lines[-1] += line[1:]
        else:
            lines.append(line)
    headers = {}
    for line in lines:
        if ': ' in line:
            k, v = line.split(': ', 1)
            if k in headers:
                raise RuntimeError('Duplicate manifest header')
            headers[k] = v
    return headers


def seals():
    result = []
    for relative, expected in SEALS.items():
        p = BASE / relative
        if sha(p) != expected:
            raise RuntimeError('Accepted input seal changed')
        m = json.loads(p.read_text())
        files = m.get('files', m.get('safe_files', []))
        for row in files:
            f = Path(row['path'])
            if not f.is_absolute():
                f = p.parent / f
            if f.stat().st_size != row['bytes'] or sha(f) != row['sha256']:
                raise RuntimeError('Old sealed input changed: ' + str(f))
        result.append({'path': str(p), 'sha256': expected, 'safe_files': len(files)})
    return result


def on_signal(number, _frame):
    global stop
    stop = True
    signals.append(number)


def main():
    signal.signal(signal.SIGINT, on_signal)
    signal.signal(signal.SIGTERM, on_signal)
    save('CURRENT.json', {'utc': utc(), 'pid': os.getpid(), 'status': 'PREFLIGHT', 'children': 0})
    before = resources()
    old_seals = seals()
    fence = Path('/workspace/rutcampustrack/docs/validation/cloud-20261011/receipts/exact-path-freeze.json')
    if sha(fence) != '6d4cef1bce6b7ee9d6ddae95a9b087e6b59af00c464572c2ecd65fc47ad61f50':
        raise RuntimeError('Root fence changed')
    if sha(BASE / 'physical_dedup1/package.json') != '22cf2ded803fcb09157d670a8832bc678dfaa764165d8d15f1714c22156c9606':
        raise RuntimeError('Actual DEDUP1 capacity package changed')
    artifact = json.loads((BASE / 'current_client_artifacts/eight-production-jars.json').read_text())
    jars = {r['service']: r for r in artifact['jars']}
    plans = {s: json.loads((BASE / 'host_capacity_plan' / ('stage-' + s + '.json')).read_text()) for s in ORDER}
    jar_before = {}
    for service in ORDER:
        jar = jars[service]
        if not jar['nested_fixture_absent'] or sha(jar['jar']) != jar['sha256'] or plans[service]['jar_sha256'] != jar['sha256']:
            raise RuntimeError('Current production JAR/fixture proof differs')
        jar_before[service] = meta(jar['jar'])
        if jar_before[service]['mode'] != '0o600' or jar_before[service]['bytes'] != jar['bytes']:
            raise RuntimeError('Source JAR metadata differs')
    count = sum(len(p['entries']) for p in plans.values())
    tuples = {(r['sha256'], r['bytes'], '0o644') for p in plans.values() for r in p['entries']}
    if count != 10834 or len(tuples) != 2937:
        raise RuntimeError('Granted complete member/unique union counts differ')
    if PAYLOAD.exists():
        raise RuntimeError('New stage payload target already exists')
    save('preflight.json', {'utc': utc(), 'status': 'PASS', 'members': count, 'unique_new644_tuples': len(tuples),
                            'source_producer': artifact['revision'], 'old_seals': old_seals, 'JAR_metadata': jar_before,
                            'before': before, 'method': 'stdlib streaming ZIP with source CRC + SHA, NEW644 before links, standard4layer+flatapp'})
    journal = (OUT / 'attempts.ndjson').open('x', encoding='utf-8')

    def log(obj):
        journal.write(json.dumps(dict(obj, utc=utc()), ensure_ascii=False, separators=(',', ':')) + '\n')
        journal.flush()

    mkdir_new(PAYLOAD)
    canonical = {}
    all_rows = []
    temp = None
    samples = [before]
    try:
        for service in ORDER:
            plan, jar = plans[service], jars[service]
            service_rows = []
            expected = {r['path']: r for r in plan['entries']}
            if len(expected) != len(plan['entries']):
                raise RuntimeError('Sealed plan duplicate path')
            with zipfile.ZipFile(jar['jar']) as archive:
                names = set()
                regular = {}
                for info in archive.infolist():
                    if info.filename in names:
                        raise RuntimeError('JAR duplicate member')
                    names.add(info.filename)
                    safe_member(info.filename, info.is_dir())
                    kind = (info.external_attr >> 16) & 0o170000
                    if kind not in (0, stat.S_IFREG, stat.S_IFDIR) or info.flag_bits & 1:
                        raise RuntimeError('JAR nonregular/encrypted member')
                    if not info.is_dir():
                        regular[info.filename] = info
                if set(regular) != set(expected):
                    raise RuntimeError('Complete ZIP member set differs')
                rules = parse_layers(archive.read('BOOT-INF/layers.idx'))
                headers = unfolded(archive.read('META-INF/MANIFEST.MF'))
                if any(headers.get(k) != v for k, v in plan['unfolded_manifest'].items()) or headers['Main-Class'] != 'org.springframework.boot.loader.launch.JarLauncher':
                    raise RuntimeError('Current unfolded standard manifest differs')
                for layer in LAYERS:
                    mkdir_new(PAYLOAD / service / 'layers' / layer)
                mkdir_new(PAYLOAD / service / 'app')
                for name, info in regular.items():
                    if stop:
                        raise RuntimeError('Requested interruption; honest partial stage')
                    row = expected[name]
                    layer = member_layer(name, rules)
                    if layer != row['layer'] or info.file_size != row['bytes']:
                        raise RuntimeError('Layer or member length differs')
                    layer_path = PAYLOAD / service / 'layers' / layer / name
                    app_path = PAYLOAD / service / 'app' / name
                    mkdir_new(layer_path.parent)
                    mkdir_new(app_path.parent)
                    key = (row['sha256'], row['bytes'], '0o644')
                    first = key not in canonical
                    h = hashlib.sha256()
                    length = 0
                    target = None
                    if first:
                        temp = layer_path.parent / ('.stage-owned-' + str(len(all_rows)).zfill(5) + '.tmp')
                        log({'event': 'TEMP_INTENT', 'member': name, 'service': service, 'temp': str(temp), 'destination': str(layer_path)})
                        journal.flush()
                        os.fsync(journal.fileno())
                        fd = os.open(temp, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o644)
                        os.fchmod(fd, 0o644)  # This freshly created file still has nlink1.
                        target = os.fdopen(fd, 'wb')
                    try:
                        with archive.open(info) as stream:
                            while chunk := stream.read(262144):
                                length += len(chunk)
                                h.update(chunk)
                                if target:
                                    target.write(chunk)
                        if target:
                            target.flush()
                            os.fsync(target.fileno())
                    finally:
                        if target:
                            target.close()
                    if length != row['bytes'] or h.hexdigest() != row['sha256']:
                        raise RuntimeError('Streamed ZIP SHA/length differs')
                    # Reading ZipExtFile to EOF has also verified this source CRC.
                    if first:
                        os.replace(temp, layer_path)
                        temp = None
                        canonical[key] = layer_path
                    else:
                        os.link(canonical[key], layer_path, follow_symlinks=False)
                    os.link(layer_path, app_path, follow_symlinks=False)
                    record = {'service': service, 'member': name, 'layer': layer, 'bytes': row['bytes'],
                              'sha256': row['sha256'], 'original_zip_mode': row['zip_mode'], 'new_mode': '0o644',
                              'layer_path': str(layer_path), 'app_path': str(app_path), 'source_CRC32': info.CRC,
                              'source_CRC_stream_verified': True}
                    service_rows.append(record)
                    all_rows.append(record)
                    log({'event': 'MEMBER_STAGED', 'service': service, 'member': name, 'first_distinct_content': first})
                    if len(all_rows) % 500 == 0:
                        sample = dict(resources(), completed=len(all_rows))
                        samples.append(sample)
                        save('CURRENT.json', {'utc': utc(), 'status': 'STAGING', 'pid': os.getpid(), 'members': len(all_rows), 'resource': sample, 'children': 0})
                        print(json.dumps({'status': 'STAGING', 'members': len(all_rows), 'allocated': sample['own_unique_allocated_bytes']}), flush=True)
                save('payload-' + service + '.json', {'service': service, 'source_producer': artifact['revision'], 'jar': jar,
                                                     'ordered_layers': LAYERS, 'unfolded_manifest': headers, 'files': service_rows})
                print(json.dumps({'status': 'SERVICE_COMPLETE', 'service': service, 'members': len(service_rows)}), flush=True)
        unique = {}
        dirs = []
        physical_paths = set()
        for d, children, files in os.walk(PAYLOAD, followlinks=False):
            s = os.lstat(d)
            if not stat.S_ISDIR(s.st_mode) or stat.S_IMODE(s.st_mode) != 0o755:
                raise RuntimeError('Payload directory mode/nonregular differs')
            dirs.append(meta(d))
            for name in files:
                p = Path(d) / name
                s = os.lstat(p)
                if not stat.S_ISREG(s.st_mode) or stat.S_IMODE(s.st_mode) != 0o644:
                    raise RuntimeError('Payload file mode/nonregular differs')
                physical_paths.add(str(p))
                key = (s.st_dev, s.st_ino)
                entry = unique.setdefault(key, {'metadata': meta(p), 'paths': []})
                entry['paths'].append(str(p))
        expected_paths = {r[k] for r in all_rows for k in ('layer_path', 'app_path')}
        if physical_paths != expected_paths or len(unique) != 2937:
            raise RuntimeError('Complete physical pathset/unique inode count differs')
        for entry in unique.values():
            if entry['metadata']['nlink'] != len(entry['paths']):
                raise RuntimeError('Stage links include unowned path')
        for row in all_rows:
            for key in ('layer_path', 'app_path'):
                p = row[key]
                if meta(p)['bytes'] != row['bytes'] or sha(p) != row['sha256']:
                    raise RuntimeError('Final staged content differs')
        save('new-stage-inode-aliases.json', list(unique.values()))
        save('new-stage-directory-modes.json', dirs)
        save('resource-samples.json', samples)
        for service in ORDER:
            if sha(jars[service]['jar']) != jars[service]['sha256'] or meta(jars[service]['jar']) != jar_before[service]:
                raise RuntimeError('Original JAR changed during stage')
        if seals() != old_seals:
            raise RuntimeError('Original sealed receipts changed during stage')
        vue = json.loads((BASE / 'current_client_artifacts/production-vue-bundles.json').read_text())['bundles']
        vue_files = 0
        for bundle in vue:
            for row in bundle['files']:
                p = Path(bundle['directory']) / row['path']
                if sha(p) != row['sha256'] or meta(p)['bytes'] != row['bytes'] or meta(p)['mode'] != row['mode']:
                    raise RuntimeError('Readonly original Vue changed')
                vue_files += 1
        after = resources()
        result = {'utc': utc(), 'status': 'CURRENT8_STAGED_BYTE_PROVEN_RUNTIME_NOT_RUN', 'pid': os.getpid(), 'children': 0,
                  'members': len(all_rows), 'stage_file_paths_layer_plus_app': len(physical_paths), 'unique_payload_inodes': len(unique),
                  'payload_unique_allocated_bytes': sum(e['metadata']['allocated_bytes'] for e in unique.values()),
                  'payload_directory_allocated_bytes': sum(r['allocated_bytes'] for r in dirs),
                  'stage_directories': len(dirs), 'original_JAR8_exact': True, 'original_Vue22_exact': vue_files == 22,
                  'original_seals_exact': True, 'new_public_files': '0644', 'new_public_directories': '0755',
                  'all_source_member_SHA_CRC_exact': True, 'all_app_and_layer_pathsets_exact': True, 'no_symlink_collision_extras': True,
                  'recursive_fixture_absence': 'retained exact reviewed current8JAR proof; every staged member SHA exact',
                  'source_producer': artifact['revision'], 'before': before, 'after': after, 'transient_files_remaining': 0,
                  'transient_buffer_bytes': 262144, 'max_transient_file_bytes': max(r['bytes'] for r in all_rows),
                  'staged_inodes_policy': 'FROZEN; atomic COW before any future content/edit/build/formatter/chmod on any staged alias',
                  'native_renderer': 'full exact current /app payload ready for readonly bind; default retained USER/WORKDIR/JarLauncher/tools unchanged',
                  'native_numeric_UID_tmp_mount_tools_liveness_conversions': 'NOT_RUN', 'keys_apps_browser_Docker_JVM': 'NOT_RUN'}
        save('RESULT.json', result)
        save('CURRENT.json', {'utc': utc(), 'status': result['status'], 'pid': os.getpid(), 'native_exit_pending': True, 'members': len(all_rows), 'children': 0})
        print(json.dumps(result), flush=True)
        return 0
    except Exception as exc:
        if temp is not None and temp.exists():
            # Exact new own temp, created O_EXCL by this process, no foreign glob.
            temp.unlink()
        save('RESULT.json', {'utc': utc(), 'status': 'HONEST_PARTIAL_STAGE_ERROR', 'pid': os.getpid(), 'members': len(all_rows),
                             'error_type': type(exc).__name__, 'error': str(exc), 'signals': signals, 'temp_settled': str(temp) if temp else None,
                             'children': 0, 'keys_apps_Docker_JVM': 'NOT_RUN'})
        raise
    finally:
        journal.close()


if __name__ == '__main__':
    try:
        sys.exit(main())
    except Exception as exc:
        save('native-error.json', {'utc': utc(), 'error_type': type(exc).__name__, 'error': str(exc), 'no_next_phase_launch': True})
        print(json.dumps({'status': 'ERROR', 'type': type(exc).__name__, 'error': str(exc)}), flush=True)
        sys.exit(1)
