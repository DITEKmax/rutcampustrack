"""Finite reported CLI-failure codes; no messages/addresses/body/hash export."""
import re

LIMIT = 33554432
HTTP = frozenset((301,302,307,308,400,401,403,404,410,422,429,500,502,503,504))
MARKERS = (
    ('To get started with GitHub CLI, please run:  gh auth login', 'GH_AUTH_REQUIRED'),
    ('To get started with GitHub CLI, please run: gh auth login', 'GH_AUTH_REQUIRED'),
    ('TLS handshake timeout', 'TLS_HANDSHAKE_TIMEOUT'),
    ('x509: certificate signed by unknown authority', 'TLS_UNKNOWN_AUTHORITY'),
    ('x509: certificate has expired or is not yet valid', 'TLS_CERT_TIME'),
    ('context deadline exceeded', 'TIMEOUT'),
    ('i/o timeout', 'TIMEOUT'),
    ('proxyconnect tcp:', 'PROXY_CONNECT'),
    ('no such host', 'DNS_FAILURE'),
    ('connection refused', 'CONNECTION_REFUSED'),
    ('unexpected EOF', 'UNEXPECTED_EOF'),
    ('stopped after 10 redirects', 'REDIRECT_LIMIT'),
)

class Blocked(Exception):
    pass

def require(ok):
    if not ok:
        raise Blocked()

def eligible(result):
    # Helper pre-exec failures are2, so2 is deliberately NOT a GH diagnostic.
    return (type(result) is dict and result.get('settled') is True
        and result.get('all_owned_processes_reaped') is True
        and result.get('supervision_error_type','UNKNOWN') is None
        and result.get('terminal_reason') == 'NATIVE_TERMINAL'
        and type(result.get('signal_count')) is int and result['signal_count']==0
        and type(result.get('native_exit')) is int and result['native_exit'] in {1,4})

def parse(data, native_exit):
    require(type(native_exit) is int and native_exit in {1,4}
        and type(data) is bytes and 0<len(data)<=LIMIT)
    try:
        text=data.decode('utf-8','strict')
    except UnicodeError:
        raise Blocked() from None
    require('\x00' not in text and '\x1b' not in text)
    http=set()
    codes=set()
    for line in text.splitlines():
        require(len(line)<=65536 and not any(ord(c)<32 and c!='\t' for c in line))
        for m in re.finditer(r'\bHTTP[ :]+(\d{3})(?!\d)',line):
            status=int(m[1])
            require(status in HTTP)
            http.add(status)
        for marker,code in MARKERS:
            if marker in line:
                codes.add(code)
    if native_exit==4:
        codes.add('GH_AUTH_EXIT4')
    return {'schema':1,'state':'CLOSED_CLI_REPORTED_HINTS' if http or codes else 'UNKNOWN',
        'native_exit':native_exit,'http_status_hints':sorted(http),
        'transport_auth_code_hints':sorted(codes),'log_GET_success':False,
        'boot_cause':'UNKNOWN','actual_checkout':'UNKNOWN','original_FIRST3':'NOT_RUN',
        'raw_content_emitted':False,
        'qualification':'Finite untrusted CLI-reported context only; does not prove boot/application/authentication cause. No message/address/body/private digest retained.'}
