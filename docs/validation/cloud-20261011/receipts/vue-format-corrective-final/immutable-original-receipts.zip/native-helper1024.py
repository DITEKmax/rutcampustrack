import os, pathlib, json, subprocess, hashlib, stat, time, signal, shutil
R = pathlib.Path('/workspace/rct-worktrees/ci-academic-heap')
S = pathlib.Path(__file__).parent
OLD = S.parent
NODE = '/opt/codex/runtimes/codex-primary-runtime/dependencies/node/bin/node'
TOOLS = OLD / 'tools/bin'
os.umask(0o077)
for p in ['tmp', 'cache']: (S / p).mkdir(exist_ok=True)
ENV = {'PATH': f'{TOOLS}:{pathlib.Path(NODE).parent}:/usr/bin:/bin',
       'NODE_OPTIONS': '--max-old-space-size=1024', 'TMPDIR': str(S/'tmp'),
       'XDG_CACHE_HOME': str(S/'cache'), 'RUFF_CACHE_DIR': str(S/'cache/ruff'),
       'LANG': 'C.UTF-8', 'LC_ALL': 'C.UTF-8', 'CI': 'true', 'NO_COLOR': '1'}
def save(name, obj):
    (S / name).write_text(json.dumps(obj, indent=2)+'\n')
def git(*args): return subprocess.check_output(['git',*args],cwd=R).decode().strip()
def row(path):
    p=R/path
    return {'path':path,'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),
            'mode':oct(stat.S_IMODE(p.stat().st_mode))}
def resources():
    mem=dict(line.split(':',1) for line in pathlib.Path('/proc/meminfo').read_text().splitlines())
    c=pathlib.Path('/sys/fs/cgroup/memory.current')
    return {'disk_available':shutil.disk_usage(R).free,
            'mem_available':int(mem['MemAvailable'].split()[0])*1024,
            'shared_memory_current':int(c.read_text()) if c.exists() else None}
def cache_bytes(): return sum(p.stat().st_size for p in (S/'cache').rglob('*') if p.is_file())
def rss_group(pgid):
    total=0; ids=[]
    for d in pathlib.Path('/proc').iterdir():
        if not d.name.isdigit(): continue
        try:
            fields=(d/'stat').read_text().rsplit(')',1)[1].split()
            if int(fields[2]) != pgid: continue
            total+=int(fields[21])*os.sysconf('SC_PAGE_SIZE'); ids.append(int(d.name))
        except (FileNotFoundError, ProcessLookupError, PermissionError): pass
    return total,ids
def check(name, argv, cwd=R, timeout=300):
    before=resources(); assert before['disk_available']>=4*1024**3
    assert before['mem_available']>=1024**3
    log=S/(name+'.private.log'); start=time.monotonic(); peak=0; stop=None
    with log.open('wb') as out:
        p=subprocess.Popen(argv,cwd=cwd,env=ENV,stdout=out,stderr=subprocess.STDOUT,start_new_session=True)
        save('CURRENT.json', {'step':name,'pid':p.pid,'argv':argv,'cwd':str(cwd),'revision':git('rev-parse','HEAD')})
        while p.poll() is None:
            rss,ids=rss_group(p.pid); peak=max(peak,rss); now=resources()
            if time.monotonic()-start>timeout: stop='deadline'
            elif now['disk_available']<4*1024**3: stop='disk floor'
            elif now['shared_memory_current'] is not None and now['shared_memory_current']>16*1024**3: stop='shared memory stop'
            elif cache_bytes()>128*1024**2: stop='cache cap'
            if stop:
                os.killpg(p.pid,signal.SIGTERM)
                try: p.wait(5)
                except subprocess.TimeoutExpired: os.killpg(p.pid,signal.SIGKILL)
                break
            time.sleep(.2)
        code=p.wait()
    result={'name':name,'argv':argv,'cwd':str(cwd),'native_exit':code,'elapsed_seconds':round(time.monotonic()-start,3),
            'max_old_space_mib':1024,'cache_limit_mib':128,'peak_owned_rss_bytes':peak,
            'before':before,'after':resources(),'cache_bytes':cache_bytes(),'stop':stop,
            'remaining_owned_pids':rss_group(p.pid)[1],'log':str(log),'revision':git('rev-parse','HEAD')}
    save(name+'.safe.json',result)
    print(json.dumps({'step':name,'native_exit':code,'seconds':result['elapsed_seconds'],'stop':stop}),flush=True)
    return result
