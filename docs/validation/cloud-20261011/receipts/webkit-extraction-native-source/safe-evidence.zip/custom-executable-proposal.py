"""Pure source proposal for supported custom WebKit executablePath; never launches."""
from pathlib import Path
CACHE = Path('/tmp/rct-validation-browsers-20261012/webkit-2272')
PREFIX = Path('/tmp/rct-webkit-native-deps-20261012')
SAFE_NAMES = {'PATH','LANG','LC_ALL','HOME','TMPDIR','XDG_CONFIG_HOME','XDG_CACHE_HOME'}

def prepare_child(arguments, declared_environment, native_validation):
    required = {'all_upstream_ELF_closure', 'version_symbols', 'GLES_actual_dlopen',
                'x264_actual_capability', 'package_signature_hashes_modes', 'cache_byte_identity'}
    if set(native_validation) != required or any(value is not True for value in native_validation.values()):
        raise ValueError('Own-context meaningful native validation required before custom executable launch')
    if not all(type(value) is str for value in arguments) or '--inspector-pipe' not in arguments:
        raise ValueError('Original WebKit pipe protocol arguments required')
    if set(declared_environment) - SAFE_NAMES or not all(type(value) is str for value in declared_environment.values()):
        raise ValueError('Explicit safe child environment only; no inherited credential or loader overrides')
    # Matches existing pw_run.sh "$*" substring variant selection under ordinary space IFS.
    headless = '--headless' in ' '.join(arguments)
    root = CACHE / ('minibrowser-wpe' if headless else 'minibrowser-gtk')
    env = dict(declared_environment)
    env.update({'WEBKIT_FORCE_COMPLEX_TEXT':'1','WEBKIT_EXEC_PATH':str(root/'bin'),
                'WEBKIT_INJECTED_BUNDLE_PATH':str(root/'lib'),
                'LD_LIBRARY_PATH':':'.join(map(str,[root/'lib',root/'sys/lib',PREFIX/'usr/lib/x86_64-linux-gnu',PREFIX/'lib/x86_64-linux-gnu']))})
    if headless:
        env['WEBKIT_INSPECTOR_RESOURCES_PATH'] = str(root/'share')
    executable = str(root/'bin/MiniBrowser')
    return executable, [executable, *arguments], env

if __name__ == '__main__':
    raise SystemExit('SOURCE_ONLY_PROPOSAL_NO_LAUNCH_AUTHORITY')
