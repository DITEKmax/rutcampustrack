"""Pure exact header selection/link graph validation; no payload writes."""
import posixpath,re
PREFIX='usr/lib/x86_64-linux-gnu/'
def validate_selection(rows):
 if len(rows)!=22:raise ValueError('Exact22 selected public entries required')
 index={}
 for row in rows:
  name=row['name'];kind=row['kind']
  if not isinstance(name,str) or not name.startswith(PREFIX) or any(p in ('','.','..') for p in name.split('/')) or not re.fullmatch(r'[A-Za-z0-9_.+/-]+',name):raise ValueError('Exact canonical own DSO suffix required')
  if name in index or kind not in ('regular','symlink') or row['archive_uid']!=0 or row['archive_gid']!=0:raise ValueError('Exact signed public type/identity required')
  if kind=='regular':
   if row['mode']!=0o644 or type(row['declared_bytes']) is not int or not 0<row['declared_bytes']<=12231288:raise ValueError('Bounded exact regularDSO644 required')
  else:
   link=row['link'];target=link['target']
   if row['mode']!=0o777 or row['declared_bytes']!=0 or not re.fullmatch(r'[A-Za-z0-9_+.-]+',target) or target in ('.','..') or link['hardlink'] is not False:raise ValueError('Contained plain relativeSONAMElink required')
   normalized=posixpath.normpath(posixpath.join(posixpath.dirname(name),target))
   if link['normalized_target']!=normalized or link['class']!='RELATIVE_CONTAINED_LINK_REQUIRES_TARGET_CHAIN_REVIEW':raise ValueError('Exact containedlink disposition required')
  index[name]=row
 regular=[r for r in rows if r['kind']=='regular']
 if len(regular)!=14 or sum(r['declared_bytes'] for r in regular)!=12231288:raise ValueError('Exact14DSO declaredbyte envelope required')
 for row in rows:
  if row['kind']!='symlink':continue
  target=index.get(row['link']['normalized_target'])
  if target is None or target['kind']!='regular' or target['package']!=row['package']:raise ValueError('Onehop exact samepackage regulartarget required')
 for name in index:
  parents=name.split('/')[:-1]
  if any('/'.join(parents[:n]) in index for n in range(1,len(parents)+1)):raise ValueError('Selectedmember cannot be ancestor')
 return {'regular_count':14,'symlink_count':8,'logical_regular_bytes':12231288}
if __name__=='__main__':raise SystemExit('SOURCE_ONLY_SELECTION_HELPER_NO_EXTRACTION_AUTHORITY')
