import fs from 'node:fs'
import { extname } from 'node:path'
import { createRequire } from 'node:module'
import { createHash } from 'node:crypto'
const cache = '/workspace/rct-worktrees/client-current-artifacts/frontends/node_modules'
const require = createRequire(`${cache}/@vue/compiler-sfc/package.json`)
const babel = require(`${cache}/@babel/parser`)
const sfc = require(`${cache}/@vue/compiler-sfc`)
const ts = require(`${cache}/typescript`)
const prettier = await import(`${cache}/prettier/index.mjs`)
const out = '/workspace/scratch/rct-validation/authored_format_current/prettier-final'
const root = '/workspace/rct-worktrees/ci-academic-heap'
const selected = JSON.parse(fs.readFileSync(`${out}/selected680.json`, 'utf8'))
const skip = new Set(['start','end','loc','extra','comments','leadingComments','trailingComments','innerComments','tokens','errors','sourceIndex','sourceEndIndex','position','raws','spaces','parent','rawText','sourceSpan','startSourceSpan','endSourceSpan','nameSpan','keySpan','valueSpan','startOffset','endOffset'])
function clean(value, key = '', context = '', inUrl = false) {
  if (Array.isArray(value)) return value.map((item) => clean(item,'',context,inUrl)).filter((item)=>item!==undefined)
  if (!value || typeof value !== 'object') return value
  if (value.type === 'EmptyStatement') return undefined
  if (value.type === 'TSParenthesizedType') return clean(value.typeAnnotation,key,context)
  if (value.type === 'LogicalExpression') {
    const operands=[]
    function visit(n) { if (n.type==='LogicalExpression' && n.operator===value.operator) {visit(n.left);visit(n.right)} else operands.push(clean(n,'',context,inUrl)) }
    visit(value)
    return {type:'orderedAssociativeLogicalExpression',operator:value.operator,operands}
  }
  if (['MemberExpression','OptionalMemberExpression'].includes(value.type) && ((!value.computed && value.property?.type==='Identifier') || (value.computed && value.property?.type==='StringLiteral'))) {
    return {type:value.type,object:clean(value.object,'',context),property:{type:'stableLiteralMember',value:value.computed?value.property.value:value.property.name},optional:value.optional??false}
  }
  if (value.type === 'CommentLine' || value.type === 'CommentBlock' || value.type === 'css-comment') return undefined
  const result = {}
  for (const [name, item] of Object.entries(value)) {
    if (skip.has(name) || /Span$/.test(name)) continue
    if(name==='raw' && context!=='tagged-template')continue
    if(name==='source' && ['css','angular'].includes(context))continue
    if (context==='css' && (name==='text' || name==='inputs' || name==='quote' || name==='quoteMark')) continue
    if (context==='css' && ['before','after'].includes(name)) continue
    if (context==='css' && name==='value' && Array.isArray(value.nodes) && value.nodes.length) continue
    if (name === 'key' && !value.computed && item && ['Identifier','StringLiteral'].includes(item.type)) {
      result[name] = { type: 'stablePropertyKey', value: item.type==='Identifier'?item.name:item.value }; continue
    }
    let cleaned = clean(item,name,value.type==='TaggedTemplateExpression'&&name==='quasi'?'tagged-template':context,inUrl||(context==='css'&&value.type==='value-func'&&String(value.value).toLowerCase()==='url'))
    if (context==='css' && name==='value' && value.type==='value-number') cleaned=Number(item)
    if (context==='css' && name==='value' && value.type==='value-string' && /^(['"]).*\1$/s.test(item)) cleaned=item.slice(1,-1).replace(/\\([0-9a-fA-F]{1,6})(?:\r\n|[ \t\n\r\f])?|\\([\s\S])/g,(_,hex,char)=>hex?String.fromCodePoint(parseInt(hex,16)):char)
    if (context==='css' && name==='value' && value.type==='value-word' && value.isHex && !inUrl) cleaned=String(item).toLowerCase()
    if (context==='css' && name==='value' && ['selector-combinator','combinator'].includes(value.type) && /^\s+$/.test(item)) cleaned=' '
    if (context==='css' && name==='value' && ['selector-attribute','attribute'].includes(value.type) && /^(['"]).*\1$/s.test(item)) cleaned=item.slice(1,-1).replace(/\\([0-9a-fA-F]{1,6})(?:\r\n|[ \t\n\r\f])?|\\([\s\S])/g,(_,hex,char)=>hex?String.fromCodePoint(parseInt(hex,16)):char)
    if (cleaned !== undefined) result[name] = cleaned
  }
  return result
}
async function script(text, filename='source.ts') {
  const ast=babel.parse(text, { sourceType:'unambiguous', plugins:['typescript','decorators-legacy','importAttributes'], allowAwaitOutsideFunction:true, allowReturnOutsideFunction:true })
  if(filename==='render.js') {
    const slots=new Map()
    function cacheSlots(n){
      if(!n||typeof n!=='object')return
      if(n.type==='MemberExpression'&&n.computed&&n.object?.type==='Identifier'&&n.object.name==='_cache'&&n.property?.type==='NumericLiteral') {
        if(!slots.has(n.property.value))slots.set(n.property.value,slots.size)
        n.property={type:'VueGeneratedCacheSlot',index:slots.get(n.property.value)}
      }
      for(const item of Object.values(n))if(Array.isArray(item)){for(const child of item)cacheSlots(child)}else if(item&&typeof item==='object')cacheSlots(item)
    }
    cacheSlots(ast)
  }
  return clean(ast)
}
function expression(text) {
  try { return clean(babel.parseExpression(text,{plugins:['typescript']})) }
  catch {
    const scanner=ts.createScanner(ts.ScriptTarget.Latest,true,ts.LanguageVariant.Standard,text)
    const tokens=[]; let token
    while ((token=scanner.scan())!==ts.SyntaxKind.EndOfFileToken) tokens.push([token,[ts.SyntaxKind.Identifier,ts.SyntaxKind.StringLiteral,ts.SyntaxKind.NumericLiteral,ts.SyntaxKind.NoSubstitutionTemplateLiteral].includes(token)?scanner.getTokenValue():scanner.getTokenText()])
    return {fallback:'TypeScript lexical token values',tokens}
  }
}
async function css(text) { return clean((await prettier.__debug.parse(text,{parser:'css'})).ast,'','css') }
async function vue(text, filename) {
  const parsed=sfc.parse(text,{filename})
  if (parsed.errors.length) throw new Error('SFC_PARSE_ERRORS')
  const d=parsed.descriptor
  const result={}
  for (const name of ['script','scriptSetup']) {
    const block=d[name]
    if (block) result[name]={attrs:block.attrs,ast:await script(block.content, block.lang==='ts'?'block.ts':'block.js')}
  }
  result.styles=[]
  for (const block of d.styles) result.styles.push({attrs:block.attrs,ast:await css(block.content)})
  result.customBlocks=d.customBlocks.map((block)=>({type:block.type,attrs:block.attrs,content:block.content}))
  if (d.template) {
    const compiled=sfc.compileTemplate({source:d.template.content,filename,id:'authored-format-preservation',compilerOptions:{mode:'module',prefixIdentifiers:true,hoistStatic:true,comments:false,expressionPlugins:['typescript']}})
    if (compiled.errors.length) throw new Error('VUE_TEMPLATE_COMPILE_ERRORS')
    result.template={attrs:d.template.attrs,render:await script(compiled.code,'render.js')}
  }
  return result
}
async function html(text,parser='html') {
  if(parser==='angular')throw new Error('D010_EXCLUDED_INPUT')
  const ast=(await prettier.__debug.parse(text,{parser})).ast
  function interpolated(value){return value.split(/(\{\{[\s\S]*?\}\})/g).filter(Boolean).map(part=>part.startsWith('{{')?{interpolation:expression(part.slice(2,-2))}:part)}
  async function node(n,preserve=false,sensitiveGap=false) {
    if (n.type==='comment') return null
    const keep=preserve || ['pre','textarea'].includes(n.name)
    const r={type:n.type}
    if (n.name) r.name=n.name
    if(n.parameters)r.parameters=(Array.isArray(n.parameters)?n.parameters:n.parameters.children).map(p=>expression(p.expression))
    if ('value' in n) {
      if (n.type==='text') {
        if (!keep && !sensitiveGap && !n.value.trim()) return null
        r.value=keep?n.value:n.value.split(/(\{\{[\s\S]*?\}\})/g).filter(Boolean).map(part=>part.startsWith('{{')?{interpolation:expression(part.slice(2,-2))}:part.replace(/[\t\r\n ]+/g,' '))
      }
      else r.value=n.value
    }
    if (n.attrs) {
      r.attrs=[]
      for(const a of n.attrs)r.attrs.push({name:a.name,value:a.name==='style'?await css(`x{${a.value}}`):/^[\[(*]|^\(.*\)$/.test(a.name)?a.value===null?null:expression(a.name.startsWith('*')?a.value.replace(/;\s*$/,''):a.value):typeof a.value==='string'&&a.value.includes('{{')?interpolated(a.value):a.value})
    }
    if (n.children) {
      if (n.name==='script' && n.children.every(c=>c.type==='text')) {
        const content=n.children.map(c=>c.value).join('')
        const type=n.attrs?.find(a=>a.name==='type')?.value
        r.script=['application/ld+json','application/json'].includes(type)?{json:JSON.parse(content)}:await script(content,'embedded.js')
      }
      else if (n.name==='style' && n.children.every(c=>c.type==='text')) r.style=await css(n.children.map(c=>c.value).join(''))
      else {
 const phrasing=new Set(['a','span','strong','small','b','em','i','img','input','button','label','time','svg','code','br'])
 const children=n.children
 r.children=(await Promise.all(children.map((c,i)=>node(c,keep,c.type==='text'&&!c.value.trim()&&phrasing.has(children[i-1]?.name)&&phrasing.has(children[i+1]?.name))))).filter(Boolean)
}
    }
    return r
  }
  return node(ast)
}
async function angularStyles(value){
 if(!value||typeof value!=='object')return
 if(value.constructor.name==='TextAttribute'&&value.name==='style')value.value={parsedStyle:await css(`x{${value.value}}`)}
 for(const [k,v] of Object.entries(value)){if(/Span$/.test(k)||['source','location','i18n','span','original'].includes(k))continue;if(Array.isArray(v))for(const c of v)await angularStyles(c);else if(v&&typeof v==='object')await angularStyles(v)}
}
function angularClean(value,key=''){
 if(Array.isArray(value))return value.map(v=>angularClean(v))
 if(value===null||typeof value!=='object')return value
 if(/Span$/.test(key)||['source','location','sourceSpan','keySpan','valueSpan','nameSpan','handlerSpan','startSourceSpan','endSourceSpan','i18n','span','absoluteSourceSpan'].includes(key))return undefined
 const r={nodeClass:value.constructor.name}
 for(const [k,v] of Object.entries(value)){if(/Span$/.test(key)||['source','location','sourceSpan','keySpan','valueSpan','nameSpan','handlerSpan','startSourceSpan','endSourceSpan','i18n','span','absoluteSourceSpan','original'].includes(k))continue;const c=angularClean(v,k);if(c!==undefined)r[k]=c}
 return r
}
function firstDelta(a,b,path='') {
  if (JSON.stringify(a)===JSON.stringify(b)) return null
  if (a && b && typeof a==='object' && typeof b==='object') {
    for (const key of new Set([...Object.keys(a),...Object.keys(b)])) { const diff=firstDelta(a[key],b[key],`${path}/${key}`); if(diff)return diff }
  }
  return path || '/'
}
if (process.argv[2] !== 'library') {
const rows=[]
for (const path of selected) {
  const before=fs.readFileSync(`${out}/before-files/${path}`,'utf8')
  const after=fs.readFileSync(`${root}/${path}`,'utf8')
  const row={path,changed:before!==after,status:'BYTE_IDENTICAL'}
  if (before!==after) {
    const extension=extname(path)
    try {
      let a,b,method
      if (['.ts','.js','.mjs','.cjs'].includes(extension)) {a=await script(before,path);b=await script(after,path);method='independent Babel AST identifiers/literals/imports/operators; genuine Angular Component template/styles only are additionally parsed as DSL grammar'}
      else if (extension==='.vue') {a=await vue(before,path);b=await vue(after,path);method='real Vue compiler-sfc scripts/styles and compiled template render Babel AST'}
      else if (extension==='.html') {a=await html(before,path.startsWith('frontends/web-panel/')?'angular':'html');b=await html(after,path.startsWith('frontends/web-panel/')?'angular':'html');method='actual HTML/Angular block grammar, attribute expressions, significant pre/textarea/text and embedded JS/CSS parsed; block-layout whitespace omitted'}
      else if (['.css','.pcss'].includes(extension)) {a=await css(before);b=await css(after);method='parsed CSS selectors/declarations/value groups/units/mixins; raw layout metadata ignored'}
      else if (extension==='.json') {
        const left=ts.parseConfigFileTextToJson(path,before),right=ts.parseConfigFileTextToJson(path,after)
        if(left.error||right.error)throw new Error('JSON_JSONC_PARSE_ERROR')
        a=left.config;b=right.config;method='independent TypeScript JSON/JSONC parser values (comments are syntax-neutral)'
      }
      else if (['.yml','.yaml'].includes(extension)) {row.status='PYTHON_YAML_VALUE_PROOF_REQUIRED';rows.push(row);continue}
      else throw new Error('UNASSIGNED_LANGUAGE')
      const diff=firstDelta(a,b)
      row.status=diff?'SEMANTIC_DIFF':'PARSE_AST_EQUAL'
      row.method=method
      row.before_semantic_sha256=createHash('sha256').update(JSON.stringify(a)).digest('hex')
      row.after_semantic_sha256=createHash('sha256').update(JSON.stringify(b)).digest('hex')
      if(diff) row.first_delta=diff
    } catch(error) {row.status='PARSE_PROOF_ERROR';row.error_kind=error.name;row.error_code=String(error.message).split('\n')[0].slice(0,80)}
  }
  rows.push(row)
}
fs.writeFileSync(`${out}/meaning-proof.safe.json`,`${JSON.stringify({rows,qualification:'Independent structural/compiled-template preservation proof; does not replace real product/browser/lint/type/build acceptance'},null,2)}\n`)
const counts={};for(const row of rows)counts[row.status]=(counts[row.status]||0)+1
console.log(JSON.stringify({counts,failures:rows.filter(row=>['SEMANTIC_DIFF','PARSE_PROOF_ERROR'].includes(row.status)).map(({path,status,first_delta,error_kind,error_code})=>({path,status,first_delta,error_kind,error_code}))}))
if(rows.some(row=>['SEMANTIC_DIFF','PARSE_PROOF_ERROR'].includes(row.status)))process.exitCode=1
}
export {clean, script, vue, css, html, firstDelta}
