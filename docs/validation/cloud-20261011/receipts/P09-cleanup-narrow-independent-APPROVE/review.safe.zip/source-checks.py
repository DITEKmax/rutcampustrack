"""Narrow P09 Source inverse and new aggregation semantics; no Java or actual cleanup."""
import hashlib
import json
from pathlib import Path
import subprocess

HERE = Path(__file__).resolve().parent
WT = Path('/workspace/rct-worktrees/p09-auth-socket-join-20261013')
REL = 'services/auth-service/auth-app/src/test/java/ru/rutcampustrack/auth/integration/RealAuthOpenSocketLogoutIT.java'
new_bytes = (WT / REL).read_bytes()
old_bytes = subprocess.check_output(['git', '-C', str(WT), 'show', 'a7648c62e34eb75776603ffcc171e8aaf2f54f42:' + REL])
new, old = new_bytes.decode(), old_bytes.decode()
assert hashlib.sha256(new_bytes).hexdigest() == 'f8f7f9b37afcc313d80833b1ff9998584685f218ac7b2bc5e4eefb0df6cae52c'
assert hashlib.sha256(old_bytes).hexdigest() == '214c60272df3cbb471bb4cba4fe974c67d5e285d15517401517dc57a5831e607'
build_rel = 'services/auth-service/auth-app/build.gradle.kts'
old_build = subprocess.check_output(['git', '-C', str(WT), 'show', 'a7648c62e34eb75776603ffcc171e8aaf2f54f42:' + build_rel])
checks = {
    'prefix_imports_fields_exact': new.split('    @AfterAll\n')[0] == old.split('    @AfterAll\n')[0],
    'test_locals_only_primary_slot': new.split('    @Test\n')[1].split('        try (var notification')[0].replace('        Throwable primaryFailure = null;\n', '') == old.split('    @Test\n')[1].split('        try (var notification')[0],
    'genuine_join_body_and_assertions_exact': new.split('        try (var notification')[1].split('        } catch (Exception | AssertionError failure)')[0] == old.split('        try (var notification')[1].split('        } finally {')[0],
    'all_noncleanup_helpers_and_secondary_config_exact': new.split('    private ServletWebServerApplicationContext notificationSocketContext')[1] == old.split('    private ServletWebServerApplicationContext notificationSocketContext')[1],
    'build_exact_old_and_pinned': (WT / build_rel).read_bytes() == old_build and hashlib.sha256(old_build).hexdigest() == '282a4efc96471a80d07adcc68bd21568d350a48bf7dab29e58fc130b2b903eaf',
}
assert all(checks.values()), checks
section = new.split('        } finally {\n            Throwable cleanupFailure = primaryFailure;')[1].split('    private ServletWebServerApplicationContext')[0]
assert section.count('catch (RuntimeException | AssertionError failure)') == 5
assert section.count('else cleanupFailure.addSuppressed(failure);') == 5
assert 'if (primaryFailure == null)' in section
assert 'if (cleanupFailure instanceof RuntimeException failure) throw failure;' in section
assert 'if (cleanupFailure instanceof AssertionError failure) throw failure;' in section

# Explicit RAM analogy for only the newly added accumulator. No Java AST/bytecode
# is executed and no real socket, actor, Spring context or key is touched.
class Failure:
    def __init__(self, code):
        self.code, self.suppressed = code, []
    def add(self, failure):
        self.suppressed.append(failure)

def accumulator(primary, actions):
    first = primary
    attempted = []
    for name, error in actions:
        attempted.append(name)
        if error is not None:
            if first is None:
                first = error
            else:
                first.add(error)
    return first, attempted

names = ['disconnect_A', 'disconnect_B', 'client_stop', 'logout_A', 'logout_B']
primary = Failure('PRIMARY_ASSERTION')
primary.add(Failure('CONTEXT_CLOSE_TWR'))
first, attempted = accumulator(primary, [(name, Failure('CLEANUP_' + str(i))) for i, name in enumerate(names)])
assert first is primary and attempted == names and [f.code for f in first.suppressed] == ['CONTEXT_CLOSE_TWR'] + ['CLEANUP_' + str(i) for i in range(5)]
primary_control = {'main': first.code, 'suppressed': [f.code for f in first.suppressed], 'all5_attempted': True}
first, attempted = accumulator(None, [(name, Failure('CLEANUP_' + str(i))) for i, name in enumerate(names)])
assert first.code == 'CLEANUP_0' and attempted == names and len(first.suppressed) == 4
cleanup_only = {'main': first.code, 'suppressed_count': len(first.suppressed), 'all5_attempted': True, 'would_fail': True}
first, attempted = accumulator(None, [('own_leaf_1', Failure('DELETE_IO')), ('own_leaf_2', Failure('DELETE_RUNTIME')), ('own_dir', None)])
assert attempted == ['own_leaf_1', 'own_leaf_2', 'own_dir'] and first.code == 'DELETE_IO' and first.suppressed[0].code == 'DELETE_RUNTIME'
key_aggregation = {'main': first.code, 'suppressed': [f.code for f in first.suppressed], 'all_owned_entries_attempted': True, 'would_fail': True}
out = {'schema': 'P09_CLEANUP_NARROW_SOURCE_RECHECK_V1', 'verdict': 'APPROVE_SOURCE',
    'closed_finding': 'P09-TEST-CLEANUP-MASKS-PRIMARY', 'inverse5': checks,
    'new_RAM3_aggregation_semantics': {'primary_with_existing_TWR_plus_five_cleanup_failures': primary_control,
        'cleanup_only_first_error_and_four_suppressed': cleanup_only, 'AfterAll_multiple_delete_failures_continue': key_aggregation},
    'qualification': 'Source/JLS reasoning and RAM accumulator analogue only; not Java AST/compile/native/sensitivity or actual resource cleanup.',
    'original_join_review': 'REUSED_NO_FULL_REVIEW_OR_OLD4_REPLAY', 'compile_runtime_sensitivity_cleanup': 'NOT_RUN', 'P09_parent': 'UNKNOWN',
    'effects': 'Public Source/Git blob reads + own receipt RAM only; no Source edits/real keys/native/network/API/privateenv/artifacts/children/B013'}
(HERE / 'controls.safe.json').write_text(json.dumps(out, indent=2) + '\n')
print(json.dumps({'verdict': 'APPROVE_SOURCE', 'inverse5': 'PASS', 'new_RAM_aggregation_cases': 3, 'Java': 'NOT_RUN'}))
