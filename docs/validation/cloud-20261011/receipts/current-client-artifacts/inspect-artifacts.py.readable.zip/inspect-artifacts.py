"""Inspect built ZIP/bundle/source inputs only; no extraction/application startup."""
import datetime
import hashlib
import importlib.util
import json
from pathlib import Path
import stat
import subprocess
from zipfile import ZipFile

OWN = Path('/workspace/scratch/rct-validation/current_client_artifacts')
WT = Path('/workspace/rct-worktrees/client-current-artifacts')
REV = '908fc8c27be82e4a0d7db7bf4d7b2c4a62225916'
MODULES = {'auth': 'auth-service/auth-app', 'academic': 'academic-service/academic-app',
           'schedule': 'schedule-service/schedule-app', 'attendance': 'attendance-service/attendance-app',
           'bff': 'mobile-bff/mobile-bff-app', 'gateway': 'api-gateway',
           'notification': 'notification-service/notification-app',
           'renderer': 'document-renderer-service/document-renderer-app'}


def file_hash(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def headers(raw):
    unfolded = []
    for line in raw.decode('utf8').replace('\r\n', '\n').splitlines():
        if line.startswith(' '):
            if not unfolded:
                raise ValueError('manifest continuation')
            unfolded[-1] += line[1:]
        else:
            unfolded.append(line)
    return dict(line.split(': ', 1) for line in unfolded if ': ' in line)


source = WT / 'tests/e2e/backend-clock/verify-jar-isolation.py'
spec = importlib.util.spec_from_file_location('existing_isolation', source)
isolation = importlib.util.module_from_spec(spec)
spec.loader.exec_module(isolation)
artifacts, payload, distinct_keys = [], [], set()
for name, module in MODULES.items():
    jars = [f for f in (WT / 'services' / module / 'build/libs').glob('*.jar')
            if not f.name.endswith('-plain.jar')]
    assert len(jars) == 1
    path = jars[0]
    with ZipFile(path) as archive:
        assert archive.testzip() is None
        isolation.require_fixture_absent(archive)
        manifest = headers(archive.read('META-INF/MANIFEST.MF'))
        assert manifest['Main-Class'] == 'org.springframework.boot.loader.launch.JarLauncher'
        assert 'BOOT-INF/classes/' + manifest['Start-Class'].replace('.', '/') + '.class' in archive.namelist()
        for key, expected in [('Spring-Boot-Classes', 'BOOT-INF/classes/'),
                              ('Spring-Boot-Lib', 'BOOT-INF/lib/'),
                              ('Spring-Boot-Classpath-Index', 'BOOT-INF/classpath.idx'),
                              ('Spring-Boot-Layers-Index', 'BOOT-INF/layers.idx')]:
            assert manifest[key] == expected
        total = distinct = rounded = count = 0
        for member in archive.infolist():
            if member.is_dir():
                continue
            assert not member.filename.startswith('/') and '..' not in Path(member.filename).parts
            with archive.open(member) as stream:
                value = hashlib.file_digest(stream, 'sha256').hexdigest()
            mode = ((member.external_attr >> 16) & 0o777) or 0o644
            key = (value, mode, member.file_size)
            total += member.file_size
            count += 1
            if key not in distinct_keys:
                distinct_keys.add(key)
                distinct += member.file_size
                rounded += ((member.file_size + 4095) // 4096) * 4096
        payload.append({'service': name, 'logical_all_file_bytes': total,
                        'new_distinct_SHA_mode_bytes': distinct,
                        'distinct_4KiB_rounded_files_estimate': rounded, 'regular_entries': count})
        git_member = 'BOOT-INF/classes/git.properties'
        embedded = git_member in archive.namelist()
        if name == 'renderer':
            assert not embedded  # Canonical springBootApps metadata generator has seven apps.
            git_proof = 'N/A_CANONICAL_RENDERER_NOT_ENROLLED; fresh boot8/source7350 producer proof'
            git_hash = None
        else:
            props = archive.read(git_member)
            pairs = dict(line.split('=', 1) for line in props.decode().splitlines()
                         if '=' in line and not line.startswith('#'))
            assert pairs['git.commit.id'] == REV
            git_proof = 'EXACT_EMBEDDED_CURRENT908_SHA'
            git_hash = hashlib.sha256(props).hexdigest()
        selected = {k: v for k, v in manifest.items() if k.startswith('Spring-Boot')
                    or k in ['Main-Class', 'Start-Class']}
        artifacts.append({'service': name, 'module': module, 'jar': str(path),
                          'bytes': path.stat().st_size, 'allocated_bytes': path.stat().st_blocks * 512,
                          'mode': oct(stat.S_IMODE(path.stat().st_mode)), 'sha256': file_hash(path),
                          'unfolded_manifest': selected, 'git_properties_proof': git_proof,
                          'git_properties_sha256': git_hash, 'nested_fixture_absent': True,
                          'ZIP_CRC_all_entries': 'PASS', 'direct_nested_jars':
                          sum(n.startswith('BOOT-INF/lib/') and n.endswith('.jar') for n in archive.namelist())})
(OWN / 'eight-production-jars.json').write_text(json.dumps({
    'revision': REV, 'boot8_native_exit': 0, 'source7350_exact': True, 'JAR_runtime': 'NOT_RUN',
    'fixture_inspector_source_sha256': file_hash(source), 'jars': artifacts}, indent=2) + '\n')
(OWN / 'full-payload-union-proposal.json').write_text(json.dumps({
    'status': 'READ_ONLY_ZIP_HASH_PROPOSAL_NO_EXTRACTION_OR_STAGING', 'producer': REV,
    'ordered_layers': ['dependencies', 'spring-boot-loader', 'snapshot-dependencies', 'application'],
    'service_order': list(MODULES), 'services': payload,
    'all_payload_logical_bytes': sum(r['logical_all_file_bytes'] for r in payload),
    'distinct_SHA_mode_bytes': sum(r['new_distinct_SHA_mode_bytes'] for r in payload),
    'distinct_4KiB_rounded_files_estimate': sum(r['distinct_4KiB_rounded_files_estimate'] for r in payload),
    'qualification': 'Logical/rounded estimate only, including complete CURRENT Renderer payload. Actual '
                     'directories/unique inode allocation/staging delta require separate root grant; '
                     'sameSHA+mode hardlinks only, roots frozen/COW before later writes. No extraction/JAR/app execution.'},
    indent=2) + '\n')

bundles = []
for name, base in [('pwa-vue', '/app/'), ('tma-vue', '/mini-app/')]:
    directory = WT / 'frontends' / name / 'dist'
    rows = [{'path': str(f.relative_to(directory)), 'sha256': file_hash(f),
             'bytes': f.stat().st_size, 'allocated_bytes': f.stat().st_blocks * 512,
             'mode': oct(stat.S_IMODE(f.stat().st_mode))}
            for f in sorted(directory.rglob('*')) if f.is_file()]
    assert rows and (directory / 'index.html').is_file()
    assert base in (directory / 'index.html').read_text()
    if name == 'pwa-vue':
        assert (directory / 'sw.js').is_file() and (directory / 'sw-assets.js').is_file()
        assert (directory / 'version.json').is_file() and (directory / 'manifest.webmanifest').is_file()
    bundles.append({'workspace': name, 'directory': str(directory), 'public_base': base,
                    'fixture_mode_build_environment': 'false', 'production': True,
                    'native_build_exit': 0, 'files': rows})
(OWN / 'production-vue-bundles.json').write_text(json.dumps({
    'revision': REV, 'build_commands': 'Normal vue-tsc --noEmit && vite build, current source/current aliases',
    'client_browser': 'NOT_RUN', 'bundles': bundles}, indent=2) + '\n')

input_manifest = json.loads((OWN / 'source-inputs-before.json').read_text())
for row in input_manifest['tracked']:
    assert file_hash(WT / row['path']) == row['sha256']
env = {'PATH': '/usr/bin:/bin', 'LANG': 'C.UTF-8'}
versions = []
for executable, argument in [('/workspace/rct-cloud-setup/jdk21/bin/java', '-version'),
                             ('/opt/codex/runtimes/codex-primary-runtime/dependencies/node/bin/node', '--version')]:
    result = subprocess.run([executable, argument], env=env, capture_output=True, text=True, timeout=10)
    assert result.returncode == 0
    versions.append({'executable': executable, 'sha256': file_hash(Path(executable)),
                     'native_exit': result.returncode, 'public_version': (result.stdout + result.stderr).strip()})
(OWN / 'artifact-inspection-result.json').write_text(json.dumps({
    'at': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'inspection_native_exit': 0,
    'eight_jars': 8, 'unfolded_headers_mainclass_and_CRC': 'PASS', 'recursive_fixture_absence': 'PASS',
    'embedded_git_current_revision': '7EXACT + RendererN/A canonical; all8 freshbuild/source7350 proof',
    'source7350_after_all_builds_and_inspection': 'EXACT', 'Vue_production_dist': '2_BUILT_CURRENT_SOURCE',
    'versions': versions, 'stage_app_browser_container_keys_TLS': 'NOT_RUN'}, indent=2) + '\n')
print(json.dumps({'status': 'PASS_CURRENT_ARTIFACT_INSPECTION_ONLY', 'production_jars': 8,
                  'production_dist': 2, 'source7350': 'EXACT',
                  'distinct_payload_logical_bytes': sum(r['new_distinct_SHA_mode_bytes'] for r in payload),
                  'staging_app_browser': 'NOT_RUN'}))
