import hashlib
import json
from pathlib import Path
import xml.etree.ElementTree as ET

R = Path('/workspace/rutcampustrack')
T = R / 'docs/validation/cloud-20261011/receipts'
O = Path('/workspace/scratch/rct-validation/matrix_runtime_plan')
data = json.loads((O/'remaining-groups.json').read_text())
lookup = {e['id']:e for e in data['entries']}
for gid,family_ids,kind in [
 ('SECURITY2-ACCEPTANCE',['RESEARCH-L03','RESEARCH-L04','RESEARCH-P10','RESEARCH-P17'],'evidence/source acceptance audit; no standalone product runtime'),
 ('SCHEMA-OWNER-L08',['RESEARCH-L08','RESEARCH-P18','JS-SYSTEM-04','JS-SYSTEM-14','JS-ADMIN-02'],'schema ownership audit; actual atomic/upgrade oracles owned by AUTH-SESSION/MIGRATIONS/NP01'),
 ('FINAL-FORMAT-PARSER-GATES',[],'task formatter/review/remote gate; BOUNDARY-52 and TASK-CONTRACT §4/7/8/D009')]:
 lookup[gid]['source_family_ids']=family_ids
 lookup[gid]['group_kind']=kind
 lookup[gid]['source_paths']=['/workspace/rutcampustrack/docs/validation/cloud-20261011/TASK-CONTRACT.md','/workspace/rutcampustrack/docs/validation/cloud-20261011/decisions.md']
 lookup[gid]['acceptance_audit_rule']='This audit adds no repeated runtime or independent feature. Reconcile sufficient exact finite evidence from the source-owning execution group.'
files = list(R.glob('services/**/src/test/**/*.java')) + list(R.glob('services/notification-bot/tests/**/*.py'))

extra = {
 'ACADEMIC-MAP':['CampusMapFileBoundaryIT'],
 'ACADEMIC-ASSIGNMENT':['AcademicGrpcIT','LessonsByIdsGrpcIT'],
 'MIGRATIONS':['BotCredentialLifecycleMigrationIT'],
 'SCHEMA-OWNER-L08':['BotCredentialLifecycleMigrationIT','JdbcSessionAuthorityIT'],
 'DASHBOARD-ACTIVITY':['DashboardActivityServiceTest','DashboardInvalidationIT','AdminActivityGrpcIT'],
 'EXPORT-ASYNC-CORE':['ExportJobsIT','ExportJobHttpIT','ExportCrossLayerBoundaryIT','ExportJobWorkerTest','ExportReadyEventConsumerTest'],
 'EXPORT-HEADMAN-MODELS':['HeadmanWeeklyReportServiceTest','HeadmanWeeklyReportControllerIT','HeadmanStatsServiceTest','HeadmanStatsRendererTest'],
 'EXPORT-STATS-TEACHER-MODELS':['HeadmanStatsTrendRendererTest','TeacherAttendanceExportServiceTest','TeacherStatsExportServiceTest','TeacherReadFacadeTest'],
 'EXPORT-ROSTER-ADMIN-MODELS':['HeadmanGroupCompositionServiceTest','AdminRegistryExportsIT','ReportDownloadTicketServiceTest'],
 'PUBLIC-RETIRED-NEGATIVE':['StudentRequestDomainIT'],
 'RECOVERY':['test-application-recovery-checks'],
}
for gid,names in extra.items():
 for name in names:
  found=[p for p in files if p.stem==name]
  if gid=='RECOVERY':found=[R/'scripts/test-application-recovery-checks.py',R/'scripts/recovery.py']
  for p in found:
   lookup[gid].setdefault('supplementary_current_proof_paths',[]).append({'path':str(p),'exists':p.is_file(),'execution':'NOT_RUN_BY_REVIEWER','limit':'Select only exact uncovered assertion. Class presence/source is not acceptance.'})

for e in data['entries']:
 if e['id'].startswith('CLIENT-'):
  e['supplementary_current_proof_paths']=[{'path':str(R/p),'exists':(R/p).is_file(),'execution':'NOT_RUN_BY_REVIEWER'} for p in ['tests/e2e/specs/mobile-real-server.spec.ts','tests/e2e/fixtures/mobile-dataset.ts','tests/e2e/playwright.real-mobile.config.ts','tests/e2e/REAL-MOBILE.md']]
  e['uncovered_harness_rule']='Eight existing cases supply only named exact invariants; remaining finite_execution_slices require source-derived bounded real-server/browser cases. No default fixture-mode / Angular scalar-role substitute.'
lookup['BOT-DELIVERY']['supplementary_current_proof_paths']=[
 {'path':str(Path('/workspace/rct-worktrees/np01-domain-bot')/p),'exists':True,'execution':'author reported actual; independent selected evidence/runtime recheck still pending','limit':'aa713 author/current reviewed product0b9 + root752 import; never root2a wholeflow PASS'} for p in [
 'services/academic-service/academic-app/src/test/java/ru/rutcampustrack/academic/botcredentials/BotCredentialLifecycleIT.java',
 'services/academic-service/academic-app/src/test/java/ru/rutcampustrack/academic/botcredentials/BotCredentialPythonBridgeIT.java',
 'services/notification-bot/tests/test_bot_credential_cards.py',
 'services/notification-bot/tests/test_start_handler.py',
 'services/auth-service/auth-app/src/main/java/ru/rutcampustrack/auth/event/PasswordChangedOutbox.java']]
lookup['BOT-DELIVERY']['NP01_exact_role_state_risk']={
 'sources':['JS-SYSTEM-01','JS-SYSTEM-04','JS-ADMIN-01','T002','D006','D007'],
 'actors':'Private positive sender=chat; fresh exact own UID/binding; unarchived; >=1 current own ACTIVE durable grant; unchanged password and nonempty accepted initial. Separate role-default choice. Nonprivate/foreign UID/stale binding/no ACTIVE/changed state denied.',
 'states':['event before REGISTER','one REGISTER render permit','render in flight','confirmed edit','definite no edit','uncertain edit response','invalidated credential generation','unlink/rebind/later account','unsettled cleanup','confirmed exact delete/absence','sanitization only settled render','stale CAS and unknown outcome'],
 'remaining_proof':'Actual Auth producer v2 envelope→real Rabbit routing→bot claim→exact provider card cleanup→durable effect→ACK. Failed/uncertain cleanup retains record/retry/DLQ and no completed cleanup ACK. Old event cannot affect later card/binding/account. Real TLS/directed identity remains enabled; no secret in safe receipt.',
 'existing_bridge_limit':'Actual Academic TLS/PG/Python aiogram/provider is a distinct accepted seam; it does not exercise Auth producer→Rabbit→consumer ACK.',
}

map_receipt=json.loads((T/'map-validation-recheck/final-receipt.json').read_text())
map_sources=json.loads((T/'map-validation-recheck/source-equivalence.json').read_text())['files']
map_equal=[{'path':x['path'],'sha256':hashlib.sha256((R/x['path']).read_bytes()).hexdigest(),'equal':hashlib.sha256((R/x['path']).read_bytes()).hexdigest()==x['sha256']} for x in map_sources]
xml=T/'map-validation-recheck/original-evidence/green-mvr-06-integrationTest-xml/TEST-ru.rutcampustrack.academic.map.CampusMapFileBoundaryIT.xml'
suite=ET.parse(xml).getroot()
lookup['ACADEMIC-MAP']['D008_existing_qualified_proof']={
 'producer_revision':map_receipt['final_author_commit'], 'execution_relation':map_receipt['runtime_revision_relationship'],
 'review':'APPROVE MVR01–03; original review '+str(T/'map-validation-recheck/final-receipt.json'),
 'xml_path':str(xml),'xml_sha256':hashlib.sha256(xml.read_bytes()).hexdigest(),'counts':{k:suite.get(k) for k in ['tests','failures','errors','skipped']},
 'current5_direct_sources_equal':all(x['equal'] for x in map_equal),'source_checks':map_equal,
 'finite_proof':'Six exact at/over bytes/rows/Adam7/overflow budget cases PASS, no inventory/file publication on refusal; regular wide fixture retained.',
 'remaining_only':'Actual gateway/live actor/browser/version/download flow. No repeat inflation/billion-row run required; direct source equality alone is not a whole current runtime claim.',
}
lookup['ACADEMIC-MAP']['newproof_minimum'][1]='D008 budget already has accepted actual six-case evidence and current5 exact source equality: retain qualified proof; remaining public gateway/browser/live authority layer only.'

ntr=json.loads((T/'ntr-seal-review/source-equivalence.json').read_text())
ntr_checks=[{'path':str(R/x['path']),'sha256':hashlib.sha256((R/x['path']).read_bytes()).hexdigest(),'equal':hashlib.sha256((R/x['path']).read_bytes()).hexdigest()==x['sha256']} for x in ntr['other5']]
test=R/'services/auth-service/auth-app/src/test/java/ru/rutcampustrack/auth/integration/WsTicketConcurrencyBoundaryIT.java'
ntr_checks.append({'path':str(test),'sha256':hashlib.sha256(test.read_bytes()).hexdigest(),'equal':hashlib.sha256(test.read_bytes()).hexdigest()==ntr['final_test_sha256']})
lookup['AUTH-WS-TICKET']['existing_NTR_qualified_proof']={
 'producer_revision':ntr['head'],'source_checks':ntr_checks,'review':str(T/'ntr-seal-review/completion.json'),
 'accepted_oracle':'Actual independent 30-second advertised lifetime + Redis lower bound + real expiry/key absence/HTTP404; meaningful shortened1s red and restored green.',
 'remaining':'Transport/role-specific concurrent ticket cases if not covered by accepted prior exact receipts; actual combined live Auth→opened private WS revoke/client chain. No unchanged TTL repetition.',
 'dependency_limit':'six direct sources qualified only; do not assert entire old292 prelaunch dependencies unchanged now.'}
lookup['BOT-DELIVERY']['existing_NP02_qualified_proof']={
 'producer_revision':'fa02ce439dfb989fc28eaddcbf1a8840d16bf9ff',
 'receipt':str(T/'ntr-seal-review/findings.md'),
 'actual_result':'provider500 keeps completed=false/claim released/mainACK0/DLQ1; manual same-event recovery+duplicate attempts2/success1/completed=true/mainACK2/DLQ0',
 'scope_limit':'Controlled audience/binding + synthetic HTTP provider; manual recovery, no automatic provider retry promise/real Telegram. Existing bytes retained. NP01 actual producer/broker/cleanup remains separate.'}

(O/'remaining-groups.json').write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n')
(O/'supplementary-qualified-evidence.json').write_text(json.dumps({'D008':lookup['ACADEMIC-MAP']['D008_existing_qualified_proof'],'NTR':lookup['AUTH-WS-TICKET']['existing_NTR_qualified_proof'],'NP02':lookup['BOT-DELIVERY']['existing_NP02_qualified_proof']},ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'D008_current5_equal':all(x['equal'] for x in map_equal),'NTR_direct6_equal':all(x['equal'] for x in ntr_checks),'groups':len(data['entries'])}))
