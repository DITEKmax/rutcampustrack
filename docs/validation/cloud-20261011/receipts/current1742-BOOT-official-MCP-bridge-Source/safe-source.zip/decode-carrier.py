"""Pure Source seam only. No CLI, imports of native helpers, files or output."""
import json

MAX_BYTES = 33554432

class BridgeBlocked(Exception):
    """Fixed no-input-derived diagnostic."""

def decode_carrier(data):
    """Existing guarded consumer supplies one stable private600 carrier read.

    Result is decoded connector text, not authenticated original transport bytes.
    Root must write it via its existing pinned FD-relative unbuffered private
    writer then call exact accepted r2 consume_private ONCE after writer settle.
    """
    def unique(pairs):
        obj = {}
        for key, value in pairs:
            if key in obj:
                raise BridgeBlocked()
            obj[key] = value
        return obj
    try:
        if type(data) is not bytes or not 0 < len(data) <= MAX_BYTES:
            raise BridgeBlocked()
        if any(c > 127 for c in data):
            raise BridgeBlocked()
        obj = json.loads(data.decode('ascii'), object_pairs_hook=unique)
        if type(obj) is not dict or set(obj) != {'schema', 'repo', 'job_id', 'producer_head', 'text'}:
            raise BridgeBlocked()
        if (type(obj['schema']) is not int or obj['schema'] != 1
            or obj['repo'] != 'DITEKmax/rutcampustrack'
            or type(obj['job_id']) is not int or obj['job_id'] != 115262001797
            or obj['producer_head'] != '1742d1e806faa5c39c6d182a3554daa8f4239801'
            or type(obj['text']) is not str or not obj['text'] or '\x00' in obj['text']):
            raise BridgeBlocked()
        payload = obj['text'].encode('utf-8', errors='strict')
        if not 0 < len(payload) <= MAX_BYTES:
            raise BridgeBlocked()
        return payload
    except Exception:
        raise BridgeBlocked() from None
