"""Read exact source ordering, then project only closed ownership booleans. No JS/helper/API."""
from pathlib import Path
import hashlib,json,os
ROOT=Path('/workspace/rutcampustrack')
AUTHOR=Path('/workspace/scratch/rct-validation/client_real_acceptance/roster-witness-correction-r1')
OUT=Path(__file__).parent
b=(AUTHOR/'witness-detail-lookup.cjs').read_bytes()
assert hashlib.sha256(b).hexdigest()=='bf115103115a8cbb5379398f53903b62cc3523078557e9c2fff291c62fc84b9c'
s=b.decode();call=s[s.index('async function call('):s.index('async function admit(')];cleanup=s[s.index('async function cleanup('):s.index('async function run(')]
assert call.index('await handle.context.fetch')<call.index('handle.loginIssued = true')
assert 'let logoutConfirmed = !handle.loginIssued;' in cleanup and 'if (handle.loginIssued) {' in cleanup
assert cleanup.index('if (handle.loginIssued) {')<cleanup.index('await handle.context.storageState()')
pw=ROOT/'tests/e2e/node_modules/playwright-core/lib/server/fetch.js';pwb=pw.read_bytes();p=pwb.decode()
assert p.index('await this._addCookies(cookies)')<p.index('response.on("aborted", () => reject')
assert 'this._cookieStore.addCookies(cookies)' in p and 'cookies: this._cookieStore.allCookies()' in p
def disposition(login_issued,cookie_captured):
    logout_confirmed=not login_issued
    logout_status='NOT_NEEDED'
    inspected=False;called=False
    if login_issued:
        inspected=True;called=True;logout_status='204';logout_confirmed=cookie_captured
        cookie_captured=False
    return {'logoutConfirmed':logout_confirmed,'logoutStatus':logout_status,'cookieStateInspected':inspected,'logoutAttempted':called,'ownedCookieBeforeDispose':cookie_captured,'contextDisposed':True}
actual=disposition(False,True)
assert actual['logoutConfirmed'] and actual['ownedCookieBeforeDispose'] and not actual['logoutAttempted']
control=disposition(True,True);assert control['logoutConfirmed'] and control['logoutAttempted'] and not control['ownedCookieBeforeDispose']
v={'verdict':'CHANGES_REQUESTED','residual_finding':'ROSTER-WITNESS-ADMISSION-CLEANUP-002','helper_sha256':hashlib.sha256(b).hexdigest(),'pinned_Playwright_fetch_sha256':hashlib.sha256(pwb).hexdigest(),'counterexample':{'case':'OWN_COOKIE_CAPTURED_THEN_LOGIN_FETCH_REJECTED','source_cleanup_disposition':actual,'expected':'Attempt owned cookie cleanup or explicitly UNCONFIRMED; never NOT_NEEDED+confirmed without inspecting owned state.'},'returned_login_positive':control,'qualification':'Exact helper branch/source ordering plus installed pinned Playwright cookie-before-body-abort source. Python closed-state projection; no JS/PW import, network, HTTP, native, cookie/token/credential values.'}
fd=os.open(OUT/'selected-cleanup-boundary.safe.json',os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
with os.fdopen(fd,'w') as f:json.dump(v,f,indent=2);f.write('\n')
print(json.dumps({'helper_sha256':v['helper_sha256'],'source_counterexample_verified':True,'actual_native':False,'verdict':v['verdict']}))
