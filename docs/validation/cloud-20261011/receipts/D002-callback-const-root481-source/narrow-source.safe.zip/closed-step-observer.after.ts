import { lstatSync, renameSync, writeFileSync } from 'node:fs';
import { join } from 'node:path';

type Category = 'API' | 'EXPECT' | 'FIXTURE' | 'HOOK' | 'TEST_STEP' | 'ATTACH' | 'OTHER';
type Source = 'ORIGINAL' | 'PWA_AUTH' | 'WRAPPER' | 'UNKNOWN';
type Metadata = { category: Category; source: Source; line: number };
type Event = Metadata & { order: number; step: number; edge: 'BEGIN' | 'END' };
export type Snapshot = {
  schema: 'RCT_D002_CLOSED_STEPS_V1';
  caseLine: 367;
  events: Event[];
  ignored: number;
};

const original = '/workspace/rutcampustrack/tests/e2e/specs/mobile-real-server.spec.ts';
const auth = '/workspace/rutcampustrack/tests/e2e/fixtures/pwa-auth.ts';
const wrapper =
  '/workspace/rct-worktrees/client-session-offline/tests/e2e/d002-step-specs/mobile-d002-steps.spec.ts';

function own(value: unknown, key: string): unknown {
  if (!value || typeof value !== 'object') return undefined;
  try {
    const descriptor = Object.getOwnPropertyDescriptor(value, key);
    return descriptor && 'value' in descriptor ? descriptor.value : undefined;
  } catch {
    return undefined;
  }
}

function selected(test: unknown): boolean {
  const location = own(test, 'location');
  return own(location, 'file') === original && own(location, 'line') === 367;
}

function metadata(step: unknown): Metadata {
  const rawCategory = own(step, 'category');
  const category: Category =
    rawCategory === 'pw:api'
      ? 'API'
      : rawCategory === 'expect'
        ? 'EXPECT'
        : rawCategory === 'fixture'
          ? 'FIXTURE'
          : rawCategory === 'hook'
            ? 'HOOK'
            : rawCategory === 'test.step'
              ? 'TEST_STEP'
              : rawCategory === 'test.attach'
                ? 'ATTACH'
                : 'OTHER';
  const location = own(step, 'location');
  const file = own(location, 'file');
  const line = own(location, 'line');
  if (typeof line !== 'number' || !Number.isInteger(line)) {
    return { category, source: 'UNKNOWN', line: 0 };
  }
  if (file === original && line >= 367 && line <= 410) {
    return { category, source: 'ORIGINAL', line };
  }
  if (file === auth && line >= 1 && line <= 64) {
    return { category, source: 'PWA_AUTH', line };
  }
  if (file === wrapper && line >= 1 && line <= 32) {
    return { category, source: 'WRAPPER', line };
  }
  return { category, source: 'UNKNOWN', line: 0 };
}

/** Only source locations and closed categories enter this state; titles/args/errors are never read. */
export function createClosedStepHooks(
  publish: (snapshot: Snapshot) => void,
  signalFailure: () => void,
) {
  const events: Event[] = [];
  const tracked = new WeakMap<object, Metadata & { step: number }>();
  let nextStep = 0;
  let ignored = 0;
  let unknownHooks = 0;
  let failed = false;

  function fail() {
    if (failed) return;
    failed = true;
    signalFailure();
  }

  function append(edge: 'BEGIN' | 'END', value: Metadata & { step: number }) {
    if (events.length >= 256) {
      fail();
      return;
    }
    events.push({ ...value, order: events.length + 1, edge });
    try {
      publish({
        schema: 'RCT_D002_CLOSED_STEPS_V1',
        caseLine: 367,
        events: events.map((event) => ({ ...event })),
        ignored,
      });
    } catch {
      // Public reporter exceptions are swallowed by the pinned multiplexer.
      // Signal through the unchanged canonical onError bookkeeping instead.
      fail();
    }
  }

  return {
    begin(test: unknown, step: unknown) {
      if (failed || !selected(test)) return;
      if (!step || typeof step !== 'object') return;
      const value = metadata(step);
      if (value.source === 'UNKNOWN') {
        if (!['FIXTURE', 'HOOK'].includes(value.category) || unknownHooks >= 32) {
          ignored++;
          if (ignored > 4096) fail();
          return;
        }
        unknownHooks++;
      }
      if (tracked.has(step)) {
        fail();
        return;
      }
      const trackedValue = { ...value, step: ++nextStep };
      tracked.set(step, trackedValue);
      append('BEGIN', trackedValue);
    },
    end(test: unknown, step: unknown) {
      if (failed || !selected(test)) return;
      if (!step || typeof step !== 'object') return;
      const value = tracked.get(step);
      if (!value) return;
      tracked.delete(step);
      append('END', value);
    },
  };
}

/** Explicit checking-process addition. No existing canonical method is replaced. */
export function installD002StepObserver(reporter: { prototype: object }, run: string) {
  const prototype = reporter.prototype;
  if ('onStepBegin' in prototype || 'onStepEnd' in prototype) {
    throw new Error('D002 observer requires absent public step callbacks');
  }
  const errorHandler = Object.getOwnPropertyDescriptor(prototype, 'onError');
  if (!errorHandler || typeof errorHandler.value !== 'function') {
    throw new Error('D002 observer requires canonical failure bookkeeping');
  }
  const failureCallback = errorHandler.value;
  for (const path of [run, join(run, 'supervision')]) {
    const info = lstatSync(path);
    if (!info.isDirectory() || info.isSymbolicLink() || (info.mode & 0o777) !== 0o700) {
      throw new Error('D002 observer requires its precreated private namespace');
    }
  }
  const output = join(run, 'supervision', 'd002-steps.safe.json');
  const states = new WeakMap<object, ReturnType<typeof createClosedStepHooks>>();
  function state(receiver: object) {
    let hooks = states.get(receiver);
    if (!hooks) {
      hooks = createClosedStepHooks(
        (snapshot) => {
          const data = JSON.stringify(snapshot, null, 2) + '\n';
          if (Buffer.byteLength(data) > 65536) throw new Error('D002 observer size cap');
          writeFileSync(output + '.next', data, { mode: 0o600, flag: 'wx' });
          renameSync(output + '.next', output);
        },
        () => {
          // No original error object or string enters canonical reporting.
          failureCallback.call(receiver, { message: 'D002 step observer failed' });
        },
      );
      states.set(receiver, hooks);
    }
    return hooks;
  }
  Object.defineProperty(prototype, 'onStepBegin', {
    value(this: object, test: unknown, _result: unknown, step: unknown) {
      state(this).begin(test, step);
    },
  });
  Object.defineProperty(prototype, 'onStepEnd', {
    value(this: object, test: unknown, _result: unknown, step: unknown) {
      state(this).end(test, step);
    },
  });
}
