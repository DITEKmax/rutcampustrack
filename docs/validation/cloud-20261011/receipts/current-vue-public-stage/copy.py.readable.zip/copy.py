"""Exact Vue22 public copies only; stdlib streaming, no subprocess/network."""
import datetime
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import signal
import stat
import sys

BASE = Path('/workspace/scratch/rct-validation')
OUT = BASE / 'current_vue_stage'
CAP = 12582912
stop = False


def utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def save(name, value):
    with (OUT / name).open('w', encoding='utf-8') as f:
        json.dump(value, f, indent=2, ensure_ascii=False)
        f.write('\n')
        f.flush()
        os.fsync(f.fileno())


def sha(path):
    h = hashlib.sha256()
    with open(path, 'rb') as f:
        while chunk := f.read(131072):
            h.update(chunk)
    return h.hexdigest()


def metadata(path):
    s = os.lstat(path)
    return {'path': str(path), 'device': s.st_dev, 'inode': s.st_ino, 'nlink': s.st_nlink,
            'bytes': s.st_size, 'allocated_bytes': s.st_blocks * 512, 'mode': oct(stat.S_IMODE(s.st_mode)),
            'uid': s.st_uid, 'gid': s.st_gid, 'mtime_ns': s.st_mtime_ns, 'ctime_ns': s.st_ctime_ns}


def path_guard(path):
    p = Path(path)
    if not p.is_absolute() or '..' in p.parts or str(p) != str(path):
        raise RuntimeError('Unsafe absolute path')
    for parent in reversed(p.parents):
        if not stat.S_ISDIR(os.lstat(parent).st_mode):
            raise RuntimeError('Symlink/nondirectory ancestor')
    if not stat.S_ISREG(os.lstat(p).st_mode):
        raise RuntimeError('Nonregular source')


def relative_guard(name):
    p = PurePosixPath(name)
    if not name or name == '.' or p.is_absolute() or str(p) != name or '..' in p.parts or '\\' in name or ':' in name or '\x00' in name:
        raise RuntimeError('Unsafe relative path')


def own_directory(path):
    path.relative_to(OUT)
    if path == OUT:
        return
    own_directory(path.parent)
    if not path.exists():
        path.mkdir(mode=0o755)
        path.chmod(0o755)
    s = os.lstat(path)
    if not stat.S_ISDIR(s.st_mode) or stat.S_IMODE(s.st_mode) != 0o755:
        raise RuntimeError('Unsafe owned directory')


def resources():
    seen = set()
    allocated = 0
    for d, dirs, files in os.walk(OUT, followlinks=False):
        for path in [Path(d)] + [Path(d) / f for f in files]:
            s = os.lstat(path)
            if stat.S_ISLNK(s.st_mode):
                raise RuntimeError('New stage symlink')
            key = (s.st_dev, s.st_ino)
            if key not in seen:
                seen.add(key)
                allocated += s.st_blocks * 512
        if any((Path(d) / n).is_symlink() for n in dirs):
            raise RuntimeError('New directory symlink')
    s = os.statvfs('/workspace')
    current = int(Path('/sys/fs/cgroup/memory.current').read_text())
    maximum = int(Path('/sys/fs/cgroup/memory.max').read_text())
    if allocated > CAP or s.f_bavail * s.f_frsize < 4294967296 or maximum - current < 1073741824:
        raise RuntimeError('Own allocation/shared-memory/disk floor unavailable')
    return {'utc': utc(), 'own_unique_allocated_bytes': allocated, 'free_available_bytes': s.f_bavail * s.f_frsize,
            'memory_current': current, 'memory_max': maximum, 'extra_cap': CAP}


def sealed_inputs():
    result = []
    for directory, expected in [('current_client_artifacts', '840492d38bfd204fe37c9bb46e89d3a3fdbc7957ad31ad1e9ca6ca058523ea7f'),
                                ('current_host_stage', '6fa4a78f3a3b3a5593456487306da86964a1f8ec078f75ef37ab6e68b80b7cd2')]:
        p = BASE / directory / 'manifest.json'
        if sha(p) != expected:
            raise RuntimeError('Old artifact/stage seal changed')
        m = json.loads(p.read_text())
        files = m.get('safe_files', m.get('files', []))
        for row in files:
            if Path(row['path']).stat().st_size != row['bytes'] or sha(row['path']) != row['sha256']:
                raise RuntimeError('Old sealed receipt changed')
        result.append({'manifest': str(p), 'sha256': expected, 'safe_files': len(files)})
    return result


def on_signal(_signum, _frame):
    global stop
    stop = True


def main():
    signal.signal(signal.SIGINT, on_signal)
    signal.signal(signal.SIGTERM, on_signal)
    save('CURRENT.json', {'utc': utc(), 'pid': os.getpid(), 'status': 'PREFLIGHT', 'children': 0})
    before = resources()
    old_seals = sealed_inputs()
    bundle_receipt = BASE / 'current_client_artifacts/production-vue-bundles.json'
    bundles = json.loads(bundle_receipt.read_text())
    source_rows = []
    parents = {}
    counts = {b['workspace']: len(b['files']) for b in bundles['bundles']}
    if counts != {'pwa-vue': 13, 'tma-vue': 9}:
        raise RuntimeError('Exact13+9 source selection differs')
    jars = json.loads((BASE / 'current_client_artifacts/eight-production-jars.json').read_text())['jars']
    jar_meta = {}
    for jar in jars:
        if sha(jar['jar']) != jar['sha256']:
            raise RuntimeError('Original JAR differs')
        jar_meta[jar['jar']] = metadata(jar['jar'])
    for bundle in bundles['bundles']:
        source_root = Path(bundle['directory'])
        actual = set()
        for d, dirs, files in os.walk(source_root, followlinks=False):
            for name in dirs:
                if (Path(d) / name).is_symlink():
                    raise RuntimeError('Source directory symlink')
            actual.update(str((Path(d) / n).relative_to(source_root)) for n in files)
        if actual != {r['path'] for r in bundle['files']}:
            raise RuntimeError('Original exact source pathset differs')
        for row in bundle['files']:
            relative_guard(row['path'])
            src = source_root / row['path']
            path_guard(src)
            m = metadata(src)
            if m['bytes'] != row['bytes'] or m['mode'] != '0o600' or sha(src) != row['sha256']:
                raise RuntimeError('Original Vue SHA/mode/size differs')
            for parent in src.parents:
                parents[str(parent)] = metadata(parent)
                if parent == source_root:
                    break
            dst = OUT / 'frontend' / bundle['workspace'] / 'dist' / row['path']
            source_rows.append({'workspace': bundle['workspace'], 'relative_path': row['path'], 'source': m,
                                'destination': str(dst), 'sha256': row['sha256'], 'bytes': row['bytes']})
    save('preflight.json', {'utc': utc(), 'status': 'PASS', 'source_producer': bundles['revision'], 'source_rows': source_rows,
                            'original_parent_metadata': parents, 'old_seals': old_seals, 'JAR8_metadata': jar_meta, 'resources': before})
    completed = []
    journal = (OUT / 'attempts.ndjson').open('x', encoding='utf-8')
    temp = None
    try:
        for i, row in enumerate(source_rows):
            if stop:
                raise RuntimeError('Requested interruption; honest partial only')
            src = Path(row['source']['path'])
            dst = Path(row['destination'])
            own_directory(dst.parent)
            temp = dst.parent / ('.copy-owned-' + str(i).zfill(2) + '.tmp')
            journal.write(json.dumps({'utc': utc(), 'event': 'INTENT', 'source': str(src), 'destination': str(dst), 'exact_temp': str(temp)}) + '\n')
            journal.flush()
            os.fsync(journal.fileno())
            fd = os.open(temp, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o644)
            os.fchmod(fd, 0o644)
            h = hashlib.sha256()
            size = 0
            with os.fdopen(fd, 'wb') as target, src.open('rb') as source:
                while chunk := source.read(131072):
                    target.write(chunk)
                    h.update(chunk)
                    size += len(chunk)
                target.flush()
                os.fsync(target.fileno())
            if size != row['bytes'] or h.hexdigest() != row['sha256'] or metadata(src) != row['source']:
                raise RuntimeError('Streaming copy/source identity differs')
            if dst.exists():
                raise RuntimeError('New target collision')
            os.replace(temp, dst)
            temp = None
            m = metadata(dst)
            if m['mode'] != '0o644' or m['nlink'] != 1 or (m['device'], m['inode']) == (row['source']['device'], row['source']['inode']) or sha(dst) != row['sha256']:
                raise RuntimeError('NEW copy identity/mode differs')
            completed.append(dict(row, staged=m))
            journal.write(json.dumps({'utc': utc(), 'event': 'VERIFIED', 'number': i, 'stage_path': str(dst), 'sha256': row['sha256']}) + '\n')
            journal.flush()
            sample = resources()
            save('CURRENT.json', {'utc': utc(), 'status': 'COPYING', 'pid': os.getpid(), 'completed': len(completed), 'resource': sample, 'children': 0})
        template = BASE / 'host_runtime_prepare/data-renderer-edge.compose.template.yml'
        old_bytes = template.read_bytes()
        if hashlib.sha256(old_bytes).hexdigest() != 'c2ae96c53bbfd4fcbaf8886d12d0fc3c7d66a19de25174bd30ec601c1554cea6':
            raise RuntimeError('Old accepted template changed')
        changed = old_bytes
        replacements = []
        for workspace in ['pwa-vue', 'tma-vue']:
            old = ('/workspace/scratch/rct-validation/host_runtime_prepare/runtime/frontend/' + workspace + '/dist').encode()
            new = str(OUT / 'frontend' / workspace / 'dist').encode()
            if changed.count(old) != 1:
                raise RuntimeError('Ambiguous frontend template source')
            changed = changed.replace(old, new)
            replacements.append({'old_source': old.decode(), 'new_source': new.decode()})
        (OUT / 'data-renderer-edge.public-vue.compose.template.yml').write_bytes(changed)
        restored = changed
        for r in replacements:
            restored = restored.replace(r['new_source'].encode(), r['old_source'].encode())
        if restored != old_bytes:
            raise RuntimeError('Template changed beyond exactly2 sources')
        expected_files = {r['destination'] for r in source_rows}
        actual_files = set()
        directories = []
        for d, dirs, files in os.walk(OUT / 'frontend', followlinks=False):
            s = os.lstat(d)
            if not stat.S_ISDIR(s.st_mode) or stat.S_IMODE(s.st_mode) != 0o755:
                raise RuntimeError('New directory not755')
            directories.append(metadata(d))
            actual_files.update(str(Path(d) / n) for n in files)
        if actual_files != expected_files:
            raise RuntimeError('New exact22 pathset differs/temp remaining')
        for row in completed:
            if metadata(row['source']['path']) != row['source'] or sha(row['source']['path']) != row['sha256']:
                raise RuntimeError('Original22 changed')
        if any(metadata(p) != m for p, m in parents.items()):
            raise RuntimeError('Original source parent metadata changed')
        for jar in jars:
            if sha(jar['jar']) != jar['sha256'] or metadata(jar['jar']) != jar_meta[jar['jar']]:
                raise RuntimeError('Original JAR8 changed')
        if sealed_inputs() != old_seals or template.read_bytes() != old_bytes:
            raise RuntimeError('Old seals/template changed')
        save('copy-map.json', completed)
        save('directory-modes.json', directories)
        save('template-change-proof.json', {'old_template': str(template), 'old_sha256': hashlib.sha256(old_bytes).hexdigest(),
                                           'new_template': str(OUT / 'data-renderer-edge.public-vue.compose.template.yml'),
                                           'new_sha256': hashlib.sha256(changed).hexdigest(), 'exact2_source_replacements': replacements,
                                           'roundtrip_to_original_byte_exact': True, 'routing_USER_nginx_create_host_path_false_unchanged': True,
                                           'renderer_current_overlay': '/workspace/scratch/rct-validation/current_host_stage/renderer-overlay.template.yml',
                                           'complete9service_readiness': 'NOT_RUN; future Root merges Renderer overlay and separately grants data/TLS/app runtime'})
        after = resources()
        result = {'utc': utc(), 'status': 'VUE22_CURRENT_PUBLIC_COPY_BYTE_PROVEN_NATIVE_UID_HTTP_NOT_RUN', 'pid': os.getpid(),
                  'source_producer': bundles['revision'], 'files': len(completed), 'per_workspace': counts, 'old22_mode600_metadata_SHA_exact': True,
                  'oldJAR8_oldstage26_originaltemplate_exact': True, 'new_files_mode': '0644', 'new_directories_mode': '0755',
                  'copies_new_independent_inode_nlink1': True, 'pathset_exact_noextras_missing_symlinks': True,
                  'temp_files': 0, 'children': 0, 'before': before, 'after': after, 'buffer_bytes': 131072,
                  'freeze_policy': 'All NEW stage files/directories immutable; COW before any future edit/build/formatter/chmod/write.',
                  'native_UID_HTTP_browser_keys_Docker_JVM_network': 'NOT_RUN'}
        save('RESULT.json', result)
        print(json.dumps(result), flush=True)
        return 0
    except Exception as exc:
        if temp is not None and temp.exists():
            temp.unlink()
        save('RESULT.json', {'utc': utc(), 'status': 'HONEST_PARTIAL_ERROR', 'completed': len(completed), 'error_type': type(exc).__name__,
                             'error': str(exc), 'exact_pending_temp_settled': str(temp) if temp else None, 'children': 0})
        raise
    finally:
        journal.close()


if __name__ == '__main__':
    try:
        sys.exit(main())
    except Exception as exc:
        save('native-error.json', {'utc': utc(), 'error_type': type(exc).__name__, 'error': str(exc), 'no_runtime_grant': True})
        print(json.dumps({'status': 'ERROR', 'type': type(exc).__name__, 'error': str(exc)}), flush=True)
        sys.exit(1)
