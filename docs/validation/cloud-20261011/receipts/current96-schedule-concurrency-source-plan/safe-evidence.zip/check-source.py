from pathlib import Path
import hashlib, json, os, stat, subprocess, zipfile

OWN=Path('/workspace/scratch/rct-validation/schedule_cov_concurrency_source_plan')
ROOT=Path('/workspace/rutcampustrack')
HEAD='96c7aee0a114e978ce3ed2976127a2a59c1a69e3'
APP='services/schedule-service/schedule-app/'
TEST=APP+'src/test/java/ru/rutcampustrack/schedule/integration/'
JAVA=APP+'src/main/java/ru/rutcampustrack/schedule/'
SQL=APP+'src/main/resources/db/migration/'
paths=[TEST+'RecurringScheduleItemIT.java', TEST+'AbstractScheduleIntegrationTest.java',
 JAVA+'replacement/AssignmentReplacementService.java', JAVA+'grpc/ScheduleSemesterArchiveWriteFence.java',
 JAVA+'recurring/RecurringScheduleItemWriter.java', JAVA+'config/SchedulingConfig.java',
 SQL+'V18__recurring_assignment_fence.sql', SQL+'V23__final_semester_deletion.sql',
 SQL+'V25__one_off_create_replay.sql', SQL+'V28__assignment_unassignment.sql',
 'build.gradle.kts','gradle/wrapper/gradle-wrapper.properties', '.github/workflows/ci.yml', '.github/workflows/coverage.yml',
 'docs/product/decisions/2026-09-23-teacher-replacement-and-group-attendance.md',
 'docs/product/decisions/2026-09-29-semester-archive-write-lock.md']
def sha(b): return hashlib.sha256(b).hexdigest()
def emit(name,x):
 p=OWN/name; p.write_text(json.dumps(x,indent=2,ensure_ascii=False)+'\n'); p.chmod(0o600)
texts={}; ledger=[]
for rel in paths:
 b=(ROOT/rel).read_bytes()
 frozen=subprocess.run(['/usr/bin/git','-C',str(ROOT),'show',HEAD+':'+rel],env={'PATH':'/usr/bin:/bin','LANG':'C','GIT_OPTIONAL_LOCKS':'0'},check=True,capture_output=True,timeout=15).stdout
 assert b==frozen,rel
 texts[rel]=b.decode(); s=(ROOT/rel).lstat()
 ledger.append({'path':rel,'bytes':len(b),'sha256':sha(b),'mode':oct(stat.S_IMODE(s.st_mode)),'current_equals_frozen96':True})
t=texts[paths[0]]; cap=t[t.index('void capNarrowingCommitIsFreshBeforeBlockedPhysicalInsert()'):t.index('void physicalInsertCommitIsFreshBeforeCapNarrowingChecksRetainedRow()')]
checks={
 'target_155e':sha((ROOT/paths[0]).read_bytes())=='155e101972daeec228def4dd5b89e1f405a21f24fbf6e1909e612e6418e74723',
 'cap_prelocks_assignment_before_install':cap.index('lockFence(ASSIGNMENT_ID)')<cap.index('replacementService.install'),
 'insert_signal_before_SQL':cap.index('insertStarted.countDown()')<cap.index('insertOccurrence('),
 'captured_cap_assert_line894':t.splitlines()[893].strip()=='assertThat(cap.get(10, TimeUnit.SECONDS)).isNull();',
 'capture_catches_Throwable': 'catch (Throwable failure)' in t,
 'barrier_5s_unchanged':'latch.await(5, TimeUnit.SECONDS)' in t,
 'insert_DataAccessException_assert':'isInstanceOf(DataAccessException.class)' in cap,
 'finally_shutdownNow':'executor.shutdownNow()' in cap,
 'service_read_committed':'ISOLATION_READ_COMMITTED' in texts[paths[2]],
 'service_default_required_no_requires_new':'PROPAGATION_REQUIRES_NEW' not in texts[paths[2]],
 'applyLocal_semester_before_domain':texts[paths[2]].split('private AssignmentCloseReceipt applyLocal(')[1].index('archiveWriteFence.lockForBusinessWrite')<texts[paths[2]].split('private AssignmentCloseReceipt applyLocal(')[1].index('FOR UPDATE'),
 'same_advisory_namespace':'5_452_097' in texts[paths[3]] and 'pg_advisory_xact_lock(5452097,' in texts[paths[7]],
 'semester_trigger_precedes_no_barrier_continue':texts[paths[7]].index('PERFORM pg_advisory_xact_lock')<texts[paths[7]].index('IF barrier_state IS NULL OR NOT deleting THEN CONTINUE'),
 'occurrence_before_trigger_a':'CREATE TRIGGER a_schedule_semester_deletion_fence\n    BEFORE INSERT OR UPDATE OR DELETE ON lesson_occurrences' in texts[paths[7]],
 'recurring_validator_locks_assignment':'WHERE assignment_id = NEW.assignment_id FOR UPDATE;' in texts[paths[8]],
 'creation_fence_exclusive': 'NEW.occurrence_date >= fence_record.creation_cap_until_exclusive' in texts[paths[8]],
 'test_scheduling_disabled':'@Profile("!test")' in texts[paths[5]],
 'pg16_nonreuse':'PostgreSQLContainer<>("postgres:16")' in texts[paths[1]] and '.withReuse(false)' in texts[paths[1]],
 'jacoco_global': 'apply(plugin = "jacoco")' in texts['build.gradle.kts'],
 'report_depends_both': 'dependsOn(tasks.named("test"))' in texts['build.gradle.kts'] and 'findByName("integrationTest")?.let { dependsOn(it) }' in texts['build.gradle.kts'],
 'gradle812':'gradle-8.12-bin.zip' in texts['gradle/wrapper/gradle-wrapper.properties'],
 'no_matching_not_failure':'isFailOnNoMatchingTests = false' in texts['build.gradle.kts'],
}
assert all(checks.values()), [k for k,v in checks.items() if not v]
# Pure lock graph: abstract held->requested edges, not native execution evidence.
def cycle(edges):
 def visit(n,active):
  if n in active:return True
  return any(visit(b,active|{n}) for a,b in edges if a==n)
 return any(visit(n,set()) for n in {a for a,b in edges})
graph={'CAP':['assignment_row','semester_advisory'],'INSERT':['semester_advisory','assignment_row']}
controls={'opposite_orders_cycle':cycle(list(map(tuple,graph.values()))), 'same_order_negative_control':not cycle([('semester_advisory','assignment_row'),('semester_advisory','assignment_row')]), 'single_edge_negative_control':not cycle([('assignment_row','semester_advisory')])}
assert all(controls.values())
old=Path('/workspace/scratch/rct-validation/ci_96c7_locale_green_receipts/schedule_coverage_closed_diagnostic')
m=old/'manifest.json'; assert sha(m.read_bytes())=='3e3aa4b6c423b7967867c0cf92b34c5956a1217785c96f07086362106b1e5d1e'
prior=json.loads(m.read_text())
for row in prior['files']:
 p=Path(row['path']); assert sha(p.read_bytes())==row['sha256'] and p.stat().st_size==row['bytes']
zips=[p for p in old.iterdir() if p.suffix=='.zip']
assert len(zips)==1 and sha(zips[0].read_bytes())=='08d466227c9897b93dc9d408ef4f1994b2b2571b9b02080c85e31fb92357878b'
with zipfile.ZipFile(zips[0]) as z: assert z.testzip() is None
state=[]
for n in ['TASK-CONTRACT.md','CURRENT.md','decisions.md','questions.md','resources.md']:
 b=(ROOT/'docs/validation/cloud-20261011'/n).read_bytes(); state.append({'name':n,'bytes':len(b),'sha256':sha(b)})
emit('source-ledger.safe.json',{'producer':HEAD,'public_source_files':ledger,'governing_snapshot':state,'no_protected_fixture_bodies_read':True})
emit('source-checks.safe.json',{'verdict':'SOURCE_DIAGNOSTIC_PLAN_ONLY','checks':checks,'pure_lock_graph':graph,'graph_controls':controls,'historical_seal_and_all6_members_unchanged':True,'historical_zip_hash_and_CRC_valid':True,'source_native_imports':False,'native_execution':False,'second_log_XML_network_read':False,'actual_underlying_cause':'UNKNOWN','model_requested':'gpt-6.1-sol/high','actual_model_effort':'UNKNOWN'})
print(json.dumps({'public_sources':len(ledger),'static_checks':len(checks),'pure_controls':len(controls),'all_pass':True,'runtime':False}))
