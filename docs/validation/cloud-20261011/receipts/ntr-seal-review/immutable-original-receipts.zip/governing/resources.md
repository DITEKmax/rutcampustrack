# Active writers and resources

Updated 2026-10-12T00:20:40.300542+00:00. Contract SHA256 8cbd27d431815647886b2f39592905d3f1d4cb985643e5d9fa3f3f669b4df4a5. Root sole shared-doc writer/integrator. Actual collaboration tree: root RUNNING, frontend_inventory PENDING_INIT, real_client_runtime RUNNING. Historical agents absent; their worktrees/WIP/evidence preserved. Model requested gpt-6.1-sol with explicit effort/fork none; actual UNKNOWN. Max6 children, heavy max2 independent maxworker1 after measurement; currently NO heavy/app/browser grant because disk2.6GiB below4GiB floor.

| Owner | Resources and frozen scope | Status |
| --- | --- | --- |
| root | /workspace/rutcampustrack, eec3, designated branch; shared docs/integration | Light disk metadata/packets/source work |
| frontend_inventory high | common configs/formatter/generator/locks; new security-fingerprint WT frozen eec3 assigned00:01:35 | PENDING_INIT, exact historical .gitleaksignore fingerprint proof only; no broad exclusions |
| real_client_runtime high | client-acceptance WT eec3, own scratch, project rct-client-eec3, HTTPS8443/HTTP28488/IPAM172.29.84/24 | Phase2A resource paused,8 Java images built; no apps/browser launches |
| export successor (not yet spawned) | exports WT0af9, untracked new crosslayer test; sole exports/public API/proto/V56/generated Auth Academic | Source-only continuation pending assignment; no test runtime until floor restored |

NTR d674 / clienta7c / Clock10a / mapc73 and completed prior worktrees immutable read-only review sources. New reader scopes use separate scratch and no tracked/source writes. Detailed historical lease evidence retained receipts/resources-before-0018.md; no restarts merely to recover history. Private bot/18514/prod/backups/real credentials outside scope.

2026-10-12T00:24:13.207087+00:00: New export_resume xhigh SOURCE_ONLY soleexports successor; ci_artifact_reconcile high READ_ONLY ownscratch; ntr_seal_review xhigh READ_ONLY ownscratch. Root+5children actual (frontend pending) within6childcapacity; allrequestedSol6.1/forknone. No heavy grants until disk restored.
