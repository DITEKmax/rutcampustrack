"""One fixed synthetic before/after mount proof; no existing key volume is accessed."""

import datetime
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import time

IMAGE = "sha256:775f483016a7d128be2a6c6978785619990f9ac24abb5ff1868222020118b279"
VOLUME = "p07-key-isolation-20261013-01"
NAMES = [VOLUME + suffix for suffix in ("-seed", "-old", "-new")]
LABEL = "io.rutcampustrack.p07-isolation=20261013-01"
OUTPUT = Path(__file__).parent / "physical01.safe.json"
DOCKER = ["docker", "--host=unix:///var/run/docker.sock"]
ENV = os.environ.copy()
for selector in ("DOCKER_HOST", "DOCKER_CONTEXT", "DOCKER_TLS", "DOCKER_TLS_VERIFY", "DOCKER_CERT_PATH"):
    ENV.pop(selector, None)


def main():
    # Root supplies a fresh deadline after its resource/ownership grant. No reusable grant.
    deadline = datetime.datetime.fromisoformat(sys.argv[1]).timestamp()
    if OUTPUT.exists() or not 0 < deadline - time.time() <= 180:
        raise RuntimeError("fresh bounded operation required")
    start = time.monotonic()
    initial_free = os.statvfs("/workspace").f_bavail * os.statvfs("/workspace").f_frsize
    result = {"state": "IN_PROGRESS", "image": IMAGE, "resources": NAMES + [VOLUME]}
    created_volume = False
    created_containers = []

    def run(argv, expected=0, cleanup=False):
        free = os.statvfs("/workspace").f_bavail * os.statvfs("/workspace").f_frsize
        if not cleanup and (free < 4 * 1024**3 or initial_free - free > 32 * 1024**2):
            raise RuntimeError("disk budget")
        remaining = deadline - time.time() - (0 if cleanup else 30)
        if remaining <= 0:
            raise RuntimeError("cleanup deadline")
        proc = subprocess.run(argv, env=ENV, capture_output=True, timeout=min(30, remaining))
        if proc.returncode != expected:
            raise RuntimeError("unexpected native status")
        return proc.stdout.decode("ascii").strip()

    def inspect_container(name):
        remaining = deadline - time.time()
        if remaining <= 0:
            raise RuntimeError("cleanup deadline")
        proc = subprocess.run(DOCKER + ["inspect", "--format", '{{.Config.Image}} {{index .Config.Labels "io.rutcampustrack.p07-isolation"}}', name], env=ENV, capture_output=True, timeout=min(5, remaining))
        if proc.returncode == 1:
            return None
        if proc.returncode != 0:
            raise RuntimeError("container cleanup inspection")
        return proc.stdout.decode("ascii").strip()

    def container(name, args, command, user=None, expected=0):
        created_containers.append(name)
        argv = DOCKER + ["run", "--name", name, "--label", LABEL, "--network", "none", "--pull", "never", "--memory", "32m", "--pids-limit", "32"]
        if user:
            argv += ["--user", user]
        return run(argv + args + [IMAGE, "sh", "-c", command], expected=expected)

    try:
        for name in NAMES:
            run(DOCKER + ["container", "inspect", name], expected=1)
        run(DOCKER + ["volume", "inspect", VOLUME], expected=1)
        if run(DOCKER + ["image", "inspect", "--format", "{{.Id}}", IMAGE]) != IMAGE:
            raise RuntimeError("image identity")
        with tempfile.TemporaryDirectory(prefix=VOLUME + "-", dir="/tmp") as synthetic:
            private = Path(synthetic) / "private.key"
            public = Path(synthetic) / "public.key"
            run(["openssl", "genpkey", "-algorithm", "RSA", "-pkeyopt", "rsa_keygen_bits:3072", "-out", str(private)])
            run(["openssl", "pkey", "-in", str(private), "-pubout", "-out", str(public)])
            private.chmod(0o600)
            public.chmod(0o644)
            created_volume = True
            run(DOCKER + ["volume", "create", "--label", LABEL, VOLUME])
            if run(DOCKER + ["volume", "inspect", "--format", '{{index .Labels "io.rutcampustrack.p07-isolation"}}', VOLUME]) != "20261013-01":
                raise RuntimeError("new volume ownership")
            user = container(NAMES[0], ["--mount", f"type=volume,source={VOLUME},target=/keys", "--mount", f"type=bind,source={synthetic},target=/input,readonly"], "addgroup -S app && adduser -S app -G app && cp /input/private.key /keys/private.key && cp /input/public.key /keys/public.key && chown app:app /keys /keys/private.key /keys/public.key && chmod 600 /keys/private.key && chmod 644 /keys/public.key && printf '%s:%s' \"$(id -u app)\" \"$(id -g app)\"")
            if not all(part.isdecimal() for part in user.split(":")) or len(user.split(":")) != 2:
                raise RuntimeError("synthetic app uid")
            old = ["--mount", f"type=volume,source={VOLUME},target=/keys,readonly"]
            # Independent checks never read key contents. Same absence oracle is RED then GREEN.
            before = container(NAMES[1], old, "test -r /keys/public.key && test -r /keys/private.key && test -e /keys/private.key || exit 2; printf 'PUBLIC_READABLE=1 PRIVATE_READABLE=1 PRIVATE_EXISTS=1'; test ! -e /keys/private.key", user=user, expected=1)
            if before != "PUBLIC_READABLE=1 PRIVATE_READABLE=1 PRIVATE_EXISTS=1":
                raise RuntimeError("old fixture not readable")
            if run(DOCKER + ["inspect", "--format", "{{.State.ExitCode}}", NAMES[1]]) != "1":
                raise RuntimeError("old oracle status")
            result["before"] = {"absence_oracle_exit": 1, "public_readable": True, "private_readable": True, "private_exists": True, "mount": "whole synthetic volume"}
            container(NAMES[2], [], "test ! -e /keys/private.key && test ! -e /keys/public.key", user=user)
            result["after"] = {"absence_oracle_exit": 0, "private_absent": True, "public_file_absent": True, "public_transport": "existing Auth HTTP endpoint tested separately"}
            result["synthetic_app_uid_gid"] = user
            result["state"] = "PASS"
    except BaseException as error:
        result["state"] = "FAIL"
        result["error_type"] = type(error).__name__
        raise
    finally:
        cleanup_errors = 0
        for name in reversed(created_containers):
            try:
                identity = inspect_container(name)
                if identity is None:
                    continue
                if identity != IMAGE + " 20261013-01":
                    raise RuntimeError("container ownership")
                run(DOCKER + ["rm", "--force", name], cleanup=True)
            except BaseException:
                cleanup_errors += 1
        if created_volume:
            try:
                if run(DOCKER + ["volume", "inspect", "--format", '{{index .Labels "io.rutcampustrack.p07-isolation"}}', VOLUME], cleanup=True) != "20261013-01":
                    raise RuntimeError("volume ownership")
                run(DOCKER + ["volume", "rm", VOLUME], cleanup=True)
            except BaseException:
                cleanup_errors += 1
        result["cleanup_errors"] = cleanup_errors
        result["elapsed_seconds"] = round(time.monotonic() - start, 3)
        OUTPUT.write_text(json.dumps(result, indent=2) + "\n")
        if cleanup_errors:
            raise RuntimeError("known own resources require cleanup")


if __name__ == "__main__":
    main()
