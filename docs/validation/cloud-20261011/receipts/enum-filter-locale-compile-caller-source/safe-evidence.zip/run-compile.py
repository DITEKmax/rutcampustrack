"""One compile-only foreground b78 caller; requires a fresh exact private Root grant."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import re
import stat
import subprocess
import sys
import time
import types

HERE = Path(__file__).resolve().parent
WT = Path('/workspace/rct-worktrees/enum-filter-locale')
ROOT = Path('/workspace/rutcampustrack')
GUARD = Path('/workspace/scratch/rct-validation/guard_proc_race_correction/bounded-child.py')
GUARD_SHA = 'b78c61293568d9941692e0b92ee34fd0b84db6d532b4a2c9a5ad42ccbf2204a0'
HEAD = '4c3745f2febdd4b9bcdd39a4e5f1fc9b3199fab1'
TEST = 'services/academic-service/academic-app/src/test/java/ru/rutcampustrack/academic/integration/AcademicGrpcIT.java'
PROD = 'services/academic-service/academic-app/src/main/java/ru/rutcampustrack/academic/user/UserSpecifications.java'
TEST_SHA = '5a4a7ad3daceb99d16005bc555bbb460bb6088fbd92cb19e9f49e08970d56e0a'
PROD_SHA = '4f62d5ac9724c9524697145734577954fbdf54c68162bd1af5e0166f376e98f9'
ROOT_TEST_SHA = '88bb5c967d08f851ea9e827112ca7404ff444ebaa2ef760bd6c4ff3e31bc5df5'
METHOD = 'enumDatabaseAndHttpBoundaryRemainCanonicalUnderTurkishLocale'
ARGV = ['./gradlew', '--offline', '--no-daemon', '--max-workers=1', '--console=plain', ':services:academic-service:academic-app:compileTestJava', '--rerun']
GIB = 1024 ** 3

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def require(value, stage):
    if not value:
        raise RuntimeError(stage)

def atomic(path, value):
    temporary = path.with_name(path.name + '.next')
    with temporary.open('x') as output:
        json.dump(value, output, indent=2)
        output.write('\n')
    temporary.chmod(0o600)
    temporary.replace(path)

def source_check(expected):
    require(digest(HERE / 'source-inputs.safe.json') == expected, 'SOURCE_LEDGER_CHANGED')
    ledger = json.loads((HERE / 'source-inputs.safe.json').read_text())
    require(subprocess.check_output(['git', '-C', str(WT), 'rev-parse', 'HEAD']).decode().strip() == HEAD, 'HEAD_CHANGED')
    require(subprocess.check_output(['git', '-C', str(WT), 'diff', '--name-only']).decode().splitlines() == [TEST], 'SOURCE_DIFF_SCOPE')
    require(not subprocess.check_output(['git', '-C', str(WT), 'ls-files', '--others', '--exclude-standard', '-z']), 'UNTRACKED_INPUT')
    for row in ledger['entries']:
        p = WT / row['path']
        s = p.lstat()
        require(stat.S_ISREG(s.st_mode) and not p.is_symlink() and s.st_nlink == row['nlink'] == 1 and s.st_size == row['bytes'] and oct(s.st_mode & 0o777) == row['mode'], 'SOURCE_METADATA_CHANGED')
        if not row['metadata_only']:
            require(digest(p) == row['sha256'], 'SOURCE_BODY_CHANGED')
    require(digest(WT / TEST) == TEST_SHA and digest(WT / PROD) == PROD_SHA, 'TWO_SOURCE_CHANGED')
    require(digest(ROOT / TEST) == ROOT_TEST_SHA and digest(ROOT / PROD) == PROD_SHA, 'ROOT_TWO_CHANGED')
    require((WT / TEST).read_text().count('void ' + METHOD + '()') == 1, 'EXACT_METHOD_MISSING')

def main():
    os.umask(0o077)
    require(len(sys.argv) == 3, 'EXACT_ROOT_GRANT_REQUIRED')
    grant_path = Path(sys.argv[1])
    receipts = ROOT / 'docs/validation/cloud-20261011/receipts'
    require(grant_path.is_absolute() and grant_path.is_relative_to(receipts) and grant_path.resolve() == grant_path and '..' not in grant_path.parts and not any(parent.is_symlink() for parent in grant_path.parents), 'PRIVATE_ROOT_GRANT_PATH')
    grant_stat = grant_path.lstat()
    require(stat.S_ISREG(grant_stat.st_mode) and grant_stat.st_uid == os.getuid() and grant_stat.st_nlink == 1 and grant_stat.st_mode & 0o777 == 0o600, 'PRIVATE_ROOT_GRANT_METADATA')
    require(digest(grant_path) == sys.argv[2], 'ROOT_GRANT_SHA')
    grant = json.loads(grant_path.read_text())
    now = datetime.datetime.now(datetime.timezone.utc)
    issued = datetime.datetime.fromisoformat(grant['issued_utc'])
    expires = datetime.datetime.fromisoformat(grant['expires_utc'])
    stop = datetime.datetime.fromisoformat(grant['absolute_stop_at'])
    require(all(x.tzinfo is not None for x in [issued, expires, stop]) and issued <= now < stop <= expires, 'GRANT_TIME')
    require(grant['authorized'] is True and grant['phase'] == 'compile-only' and grant['argv'] == ARGV and grant['source_base'] == HEAD and grant['driver_sha256'] == digest(Path(__file__)) and grant['guard_sha256'] == digest(GUARD) == GUARD_SHA and grant['test_source_sha256'] == TEST_SHA and grant['production_source_sha256'] == PROD_SHA and grant['test_source_review_approved'] is True and grant['test_API_Docker_authorized'] is False, 'EXACT_COMPILE_SCOPE')
    require(re.fullmatch('[0-9a-f]{64}', grant['test_source_review_sha256']) is not None, 'REVIEW_IDENTITY')
    limits = grant['limits']
    require(0 < limits['deadline_seconds'] <= 600 and limits['cleanup_margin_seconds'] >= 60 and limits['workspace_floor_bytes'] >= 4 * GIB and limits['tmp_floor_bytes'] >= 4 * GIB and 0 < limits['disk_delta_cap_bytes'] <= 2 * GIB and 0 < limits['shared_growth_cap_bytes'] <= 4 * GIB and limits['shared_stop_bytes'] <= 15 * GIB and limits['shared_reserve_bytes'] >= GIB and 0 < limits['owned_tree_rss_cap_bytes'] <= 4 * GIB and (expires - stop).total_seconds() >= limits['cleanup_margin_seconds'], 'RESOURCE_LIMITS')
    require(digest(HERE / 'jdk-pin.safe.json') == grant['jdk_pin_sha256'], 'JDK_PIN_CHANGED')
    jdk = json.loads((HERE / 'jdk-pin.safe.json').read_text())
    require(jdk['JAVA_VERSION'].startswith('21.') and str(Path(jdk['JAVA_HOME']).resolve()) == jdk['resolved_home'], 'JDK21_REQUIRED')
    for pin in jdk['files']:
        require(str(Path(pin['path']).resolve()) == pin['resolved'] and digest(Path(pin['path'])) == pin['sha256'], 'JDK_BYTES_CHANGED')
    source_check(grant['source_inputs_sha256'])
    require(re.fullmatch('compile-attempt-[0-9]{2}', grant['run_id']) is not None, 'OWN_RUN_ID')
    run = HERE / grant['run_id']
    run.mkdir(mode=0o700, exist_ok=False)
    private_tmp = run / 'private-tmp'
    private_tmp.mkdir(mode=0o700)
    class_root = WT / 'services/academic-service/academic-app/build/classes/java/test/ru/rutcampustrack/academic/integration'
    classes = [class_root / (name + '.class') for name in ['AcademicGrpcIT', 'AcademicGrpcIT$FilteredUserRow', 'AcademicGrpcIT$FilteredUsers']]
    require(all(not p.exists() for p in classes), 'FRESH_CLASS_OUTPUT_REQUIRED')
    guard = types.ModuleType('pinned_b78_guard')
    exec(compile(GUARD.read_bytes(), str(GUARD), 'exec'), guard.__dict__)
    known = {}
    latest = {}
    baseline_free = os.statvfs('/workspace').f_bavail * os.statvfs('/workspace').f_frsize
    baseline_memory = int(Path('/sys/fs/cgroup/memory.current').read_text())
    peaks = {'owned_rss_bytes': 0, 'cohort_disk_delta_bytes': 0, 'shared_growth_bytes': 0}
    def status(value):
        latest.clear()
        latest.update(value)
        for row in value['members_including_Z']:
            known[row['pid']] = row['start_ticks']
        atomic(run / 'process.safe.json', value)
    def observe():
        if datetime.datetime.now(datetime.timezone.utc) >= stop:
            return 'ABSOLUTE_STOP'
        free = os.statvfs('/workspace').f_bavail * os.statvfs('/workspace').f_frsize
        tmpfree = os.statvfs('/tmp').f_bavail * os.statvfs('/tmp').f_frsize
        memory = int(Path('/sys/fs/cgroup/memory.current').read_text())
        maximum = int(Path('/sys/fs/cgroup/memory.max').read_text())
        rss = 0
        table = guard.process_table()
        for pid, birth in known.items():
            if table.get(pid, {}).get('start_ticks') != birth:
                continue
            try:
                lines = (Path('/proc') / str(pid) / 'status').read_text().splitlines()
                rss += sum(int(line.split()[1]) * 1024 for line in lines if line.startswith('VmRSS:'))
            except FileNotFoundError:
                continue
        delta = max(0, baseline_free - free)
        growth = max(0, memory - baseline_memory)
        peaks['owned_rss_bytes'] = max(peaks['owned_rss_bytes'], rss)
        peaks['cohort_disk_delta_bytes'] = max(peaks['cohort_disk_delta_bytes'], delta)
        peaks['shared_growth_bytes'] = max(peaks['shared_growth_bytes'], growth)
        if free < limits['workspace_floor_bytes'] or tmpfree < limits['tmp_floor_bytes']:
            return 'DISK_FLOOR'
        if delta > limits['disk_delta_cap_bytes'] or growth > limits['shared_growth_cap_bytes'] or memory >= limits['shared_stop_bytes'] or maximum - memory < limits['shared_reserve_bytes'] or rss > limits['owned_tree_rss_cap_bytes']:
            return 'RESOURCE_CAP'
        return None
    env = {'PATH': '/workspace/rct-cloud-setup/jdk21/bin:/usr/local/bin:/usr/bin:/bin', 'JAVA_HOME': '/workspace/rct-cloud-setup/jdk21', 'GRADLE_USER_HOME': '/workspace/.gradle', 'LANG': 'C.UTF-8', 'LC_ALL': 'C.UTF-8', 'TZ': 'UTC', 'TMPDIR': str(private_tmp)}
    started_ns = time.time_ns()
    atomic(run / 'launch.safe.json', {'phase': 'compile-only', 'argv': ARGV, 'test_source_sha256': TEST_SHA, 'production_source_sha256': PROD_SHA, 'started_ns': started_ns, 'raw_stdout_stderr': 'DEVNULL', 'test_API_Docker': 'NOT_AUTHORIZED'})
    result = guard.run_owned(ARGV, str(WT), env, deadline_seconds=min(limits['deadline_seconds'], (stop - now).total_seconds()), observe=observe, status=status)
    source_unchanged = True
    try:
        source_check(grant['source_inputs_sha256'])
    except Exception:
        source_unchanged = False
    produced = []
    for p in classes:
        if p.exists():
            s = p.lstat()
            produced.append({'path': str(p.relative_to(WT)), 'bytes': s.st_size, 'sha256': digest(p), 'mtime_ns': s.st_mtime_ns, 'fresh': s.st_mtime_ns >= started_ns, 'mode': oct(s.st_mode & 0o777), 'nlink': s.st_nlink})
    fresh = len(produced) == 3 and all(x['fresh'] and x['nlink'] == 1 and x['mode'] == '0o600' for x in produced)
    settled = result['settled'] and result['all_owned_processes_reaped']
    output = {'state': 'PASS_COMPILE_ONLY' if result['phase_success'] and fresh and source_unchanged else 'FAIL_COMPILE_ONLY', 'native': result, 'classes': produced, 'fresh_three_classes': fresh, 'source_unchanged': source_unchanged, 'peaks': peaks, 'supervisor': {'pid': os.getpid(), 'birth': guard.process_table().get(os.getpid(), {}).get('start_ticks')}, 'test_API_Docker': 'NOT_RUN', 'stdout_stderr': 'DEVNULL', 'cleanup_tmp_removed': False}
    if settled:
        import shutil
        shutil.rmtree(private_tmp)
        output['cleanup_tmp_removed'] = True
    atomic(run / 'terminal.safe.json', output)
    print(json.dumps({'state': output['state'], 'settled': settled, 'fresh_three_classes': fresh}))
    return 0 if result['phase_success'] and fresh and source_unchanged and settled else 1

if __name__ == '__main__':
    try:
        raise SystemExit(main())
    except Exception:
        print('{"state":"BLOCKED_COMPILE_SCOPE_OR_SUPERVISION"}')
        raise SystemExit(2)
