"""Pure decoder controls; public synthetic input only, no native helper import."""
import json
from pathlib import Path

root = Path(__file__).absolute().parent
namespace = {}
exec(compile((root / 'decode-carrier.py').read_text(), 'decode-carrier.py', 'exec'), namespace)
decode = namespace['decode_carrier']
base = {'schema': 1, 'repo': 'DITEKmax/rutcampustrack', 'job_id': 115262001797,
        'producer_head': '1742d1e806faa5c39c6d182a3554daa8f4239801', 'text': 'synthetic'}

def carrier(obj):
    return json.dumps(obj, ensure_ascii=True, separators=(',', ':')).encode('ascii')

def deny(data):
    try:
        decode(data)
    except namespace['BridgeBlocked'] as error:
        return not error.args and error.__cause__ is None
    return False

rows = []
def record(name, passed):
    rows.append({'name': name, 'passed': passed is True})

text = 'synthetic\r\n*** End Patch\n*** Add File: never\nΕλληνικά 😀\t'
record('EXACT_CRLF_LF_TRAILING_NEWLINE_UNICODE_AND_PATCH_TEXT',
       decode(carrier(dict(base, text=text))) == text.encode('utf-8'))
record('EXTRA_MISSING_AND_WRONG_HEAD_SCHEMA_DENIED', all(deny(carrier(obj)) for obj in
       [dict(base, extra='discarded'), {k:v for k,v in base.items() if k != 'text'},
        dict(base, producer_head='unknown'), dict(base, job_id=True), dict(base, schema=True)]))
record('DUPLICATE_KEY_AND_NON_ASCII_CARRIER_DENIED',
       deny(carrier(base)[:-1] + b',"text":"second"}') and deny(b'\xff'))
record('MALFORMED_EMPTY_NUL_LONE_SURROGATE_DENIED', all(deny(data) for data in
       [b'', b'{', carrier(dict(base, text='')), carrier(dict(base, text='\0')),
        carrier(dict(base, text='\ud800'))]))
record('CARRIER_OVER_32M_DENIED', deny(b'a' * 33554433))
record('ERROR_IS_CLOSED_NO_INPUT_MESSAGE', deny(b'not-public-synthetic-marker'))
assert all(row['passed'] for row in rows), 'SOURCE_CONTROL_FAILURE'
(root / 'decoder-controls.safe.json').write_text(json.dumps({
    'source_only': True, 'actual_connector_called': False,
    'native_helper_imported': False, 'groups': len(rows), 'rows': rows}, indent=2) + '\n')
print(json.dumps({'source_only': True, 'groups': len(rows), 'passed': True}))
