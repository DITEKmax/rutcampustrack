"""Readonly product-boundary/source preservation check; no Java/DB/CI replay."""
import hashlib
import json
from pathlib import Path
import stat
import subprocess
import zipfile

OWN=Path(__file__).parent
PACKET=OWN.parent/'enum_filtered_locale_developer/locale_root_fix01'
WT=Path('/workspace/rct-worktrees/enum-filter-source-only')
ROOT=Path('/workspace/rutcampustrack')
SOURCE='services/academic-service/academic-app/src/main/java/ru/rutcampustrack/academic/user/UserSpecifications.java'
TEST='services/academic-service/academic-app/src/test/java/ru/rutcampustrack/academic/integration/AcademicGrpcIT.java'
BASE='538af12e280bc0e34b62c99c8823a7bb552d6ea6'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
manifest=PACKET/'manifest.safe.json'
assert sha(manifest)=='78b069cc5cc0938ba60ebd5f37cd2711f0654e83cc42f2e23adf1416a2996005'
z=PACKET/'locale-root-fix.safe.zip'
assert sha(z)=='3ad61d84914018a783cba663210690b6721b4a30f68d52e96c4e10d4e4e70e8c'
m=json.loads(manifest.read_text());expected={}
for row in m['members']:
    p=PACKET/row['path'];s=p.lstat()
    assert p.parent==PACKET and stat.S_ISREG(s.st_mode) and s.st_nlink==1
    assert s.st_size==row['bytes'] and stat.S_IMODE(s.st_mode)==int(row['mode'],0) and sha(p)==row['sha256']
    expected[row['path']]=row['sha256']
expected['manifest.safe.json']=sha(manifest)
with zipfile.ZipFile(z) as a:
    assert len(a.infolist())==7 and a.testzip() is None and set(a.namelist())==set(expected)
    for name in a.namelist():assert hashlib.sha256(a.read(name)).hexdigest()==expected[name]
before=(PACKET/'before-UserSpecifications.java').read_bytes()
after=(PACKET/'after-UserSpecifications.java').read_bytes()
assert hashlib.sha256(before).hexdigest()=='4f62d5ac9724c9524697145734577954fbdf54c68162bd1af5e0166f376e98f9'
assert hashlib.sha256(after).hexdigest()=='49dbdf2833a6be5ac35c3b873570139d62b4b965ed52370b7543590c9a998e3b'
reverse=after
changes=[(b'import java.util.Locale;\n',b''),
 (b'            Predicate roleMatch =\n                    cb.equal(cb.lower(grant.get("role")), role.toLowerCase(Locale.ROOT));',b'            Predicate roleMatch = cb.equal(cb.lower(grant.get("role")), role.toLowerCase());'),
 (b'            Predicate statusMatch =\n                    cb.equal(cb.lower(grant.get("status")), status.toLowerCase(Locale.ROOT));',b'            Predicate statusMatch = cb.equal(cb.lower(grant.get("status")), status.toLowerCase());')]
for new,old in changes:
    assert reverse.count(new)==1
    reverse=reverse.replace(new,old)
assert reverse==before
assert (WT/SOURCE).read_bytes()==after and (ROOT/SOURCE).read_bytes()==before
assert sha(WT/TEST)==sha(ROOT/TEST)=='dd0c466926911d99879fcdb59dd94641ca810bb714992d8fda7bc470b409010d'
assert subprocess.check_output(['git','-C',str(WT),'rev-parse','HEAD'],text=True).strip()==BASE
assert subprocess.check_output(['git','-C',str(WT),'diff','--name-only'],text=True).splitlines()==[SOURCE]
subprocess.run(['git','-C',str(WT),'diff','--check'],check=True)
assert subprocess.check_output(['git','-C',str(WT),'show',BASE+':'+SOURCE])==before
preserve=json.loads((PACKET/'source-preservation.safe.json').read_text())
for row in preserve['after_sparse_inventory']:
    p=WT/row['path'];s=p.lstat()
    assert stat.S_ISREG(s.st_mode) and s.st_nlink==row['nlink'] and s.st_size==row['bytes'] and stat.S_IMODE(s.st_mode)==int(row['mode'],0) and sha(p)==row['sha256']
RED=ROOT/'docs/validation/cloud-20261011/receipts/enum-locale-current-ci-causal-red-seal'
assert sha(RED/'manifest.json')=='3703071d1d67c6c3814b3a0f28528817d59e4fb87307bbb9c8794fdda89d4bea'
assert sha(RED/'safe-evidence.zip')=='d65911ed1eaca50bab078a727c8b358a748e9212dfc7bd988f81e09be4003bfe'
red_manifest=json.loads((RED/'manifest.json').read_text())
red_expected={r['relative_path']:r['sha256'] for r in red_manifest['files']}
red_expected['manifest.json']=sha(RED/'manifest.json')
with zipfile.ZipFile(RED/'safe-evidence.zip') as a:
    assert a.testzip() is None and set(a.namelist())==set(red_expected)
    for name in a.namelist():assert hashlib.sha256(a.read(name)).hexdigest()==red_expected[name]
    red=json.loads(a.read('closed-target-cause.safe.json'))
assert red['producer']==BASE and red['checkoutSha']=='6e5385ddbab9cc967e4ef7be5e1fe29c8198082d'
assert red['sourceSha256']==sha(ROOT/TEST) and red['exceptionType']=='org.assertj.core.error.AssertJMultipleFailuresError'
assert red['exactTargetMethodFrameLines']==[479] and red['aggregateFailureCounts']==[2]
assert red['fixedSoftAssertionTagsSeen']==dict(scalar_active=False,ADMIN_role=True,ACTIVE_grant=True)
assert red['scalarPairEqualQualified'] is True and red['allHardCanonicalSQL_ID_status_count_total_page_positive_oracles_reached'] is True
assert red['sixHTTP200_and_unknown400_reached_by_exact_source_control_flow'] is True
# ASCII illustration only: not execution of Java locale/JPA/SQL methods.
mapping=[]
for value in ['ADMIN','AdMiN','admin','ACTIVE','AcTiVe','active']:
    root=value.lower();tr=value.replace('I','\u0131').lower()
    mapping.append(dict(input=value,old_default_English=root,old_default_TR=tr,new_ROOT=root))
assert mapping[0]['old_default_TR']!='admin' and mapping[3]['old_default_TR']!='active'
result=dict(outcome='APPROVE_SOURCE',blocking_findings=0,defect='DF-ENUM-FILTER-LOCALE-001',source_manifest=sha(manifest),source_zip=sha(z),base=BASE,before_sha=sha(PACKET/'before-UserSpecifications.java'),after_sha=sha(WT/SOURCE),test_sha=sha(WT/TEST),exact_reverse_restores_full_bytes=True,only_authorized_tracked_product_file=True,other_four_sparse_files_preserved=True,closed_RED_manifest=sha(RED/'manifest.json'),closed_RED_zip=sha(RED/'safe-evidence.zip'),RED_producer=BASE,RED_checkout=red['checkoutSha'],RED_scope='2 causal grant normalization pair divergences; scalar and hard positive oracles reached',ASCII_mapping_illustration_only=mapping,runtime_green='PENDING_EXISTING_STANDARD_CI_AFTER_ROOT_INTEGRATION',native_Java_tests_API_Docker_XML_logs_custom_RED_reads_or_source_writes=0)
(OWN/'checks.safe.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(dict(outcome=result['outcome'],reverse_full_bytes=True,test_unchanged=True,blocking_findings=0,native_tests=0)))
