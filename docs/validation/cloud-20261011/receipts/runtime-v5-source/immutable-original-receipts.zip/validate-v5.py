"""Finite pure/source controls. No application, Docker, JVM or network launch."""
import ast
import contextlib
import hashlib
import io
import json
import os
from pathlib import Path
import re
import stat
import sys
import types
import yaml

OWN = Path(__file__).parent
OLD = OWN.parent / 'current_host_config_v4'
REPO = Path('/workspace/rutcampustrack')
checks = []

def check(name, value):
    checks.append({'name': name, 'pass': bool(value)})
    if not value:
        raise AssertionError(name)

def locations(text):
    result = {}
    for match in re.finditer(r'\blocation\s+([^{}]+)\{', text):
        end = text.index('}', match.end())
        result[match.group(1).strip()] = text[match.end():end].strip()
    return result

def headers(body):
    return re.findall(r'add_header\s+([^;]+);', body)

def load_source(name):
    module = types.ModuleType('source_' + name.replace('-', '_'))
    module.__file__ = str(OWN / name)
    exec(compile((OWN / name).read_bytes(), str(OWN / name), 'exec'), module.__dict__)
    return module

def main():
    for source in ['prepare-v5.py', 'run-service-v5.py', 'run-mongo.py', 'validate-v5.py']:
        ast.parse((OWN / source).read_text())
        check('python_parse_' + source, True)
    old = yaml.safe_load((OLD / 'data-renderer-edge.compose.yml').read_text())
    new = yaml.safe_load((OWN / 'data-renderer-edge.compose.yml').read_text())
    keep = {'postgres-academic', 'postgres-schedule', 'redis', 'rabbitmq', 'document-renderer-service', 'nginx'}
    check('exact_six_services', set(new['services']) == keep)
    for service in keep - {'nginx'}:
        check('unchanged_native_data_service_' + service, new['services'][service] == old['services'][service])
    check('five_volume_definitions_preserved', new['volumes'] == old['volumes'])
    check('old_mongo_volume_not_mounted', 'owned-mongo-attendance' not in str(new['services']))
    check('network_ipam_unchanged', new['networks'] == old['networks'])
    edge_old, edge_new = old['services']['nginx'], new['services']['nginx']
    for name in ['image', 'ports', 'networks', 'pull_policy', 'mem_limit', 'cpus', 'extra_hosts']:
        check('edge_unchanged_' + name, edge_old[name] == edge_new[name])
    for mount in edge_new['volumes']:
        check('readonly_existing_bind_' + mount['target'], mount['read_only'] is True
              and mount['bind']['create_host_path'] is False and Path(mount['source']).exists())
    check('unchanged_main_mime_CSP_config', edge_new['volumes'][0] == edge_old['volumes'][0])
    check('unchanged_TLS_bind', edge_new['volumes'][2] == edge_old['volumes'][2])
    old_edge = (REPO / 'tests/e2e/infra/nginx/default.conf').read_text()
    new_edge = (OWN / 'edge-default.conf').read_text()
    ol, nl = locations(old_edge), locations(new_edge)
    for route in ['/api/ws/', '= /api/v1/student/requests/excuse', '/api/', '= /', '/']:
        check('exact_API_redirect_default_' + route, ol[route] == nl[route])
    check('exact_TLS_API_prefix', old_edge[:old_edge.index('    location /app/ {')]
          == new_edge[:new_edge.index('    root /var/www/clients;')])
    immutable = nl['~* ^/(?:app|mini-app)/.*\\.(js|css|png|jpg|jpeg|svg|ico|woff|woff2)$']
    for prefix, frontend in [('app', 'pwa-vue'), ('mini-app', 'tma-vue')]:
        backend = locations((REPO / 'frontends' / frontend / 'nginx.conf').read_text())
        old_immutable = next(b for name, b in backend.items() if name.startswith('~*'))
        check('immutable_headers_' + prefix, headers(immutable) == headers(old_immutable))
        check('immutable_missing_404_' + prefix, 'try_files $uri =404;' in immutable)
        check('SPA_headers_' + prefix, headers(nl['/' + prefix + '/']) == headers(backend['/']))
        check('SPA_fallback_' + prefix, 'try_files $uri $uri/ /' + prefix + '/index.html;' in nl['/' + prefix + '/'])
        check('prefix_redirect_' + prefix, nl['= /' + prefix] == 'return 301 /' + prefix + '/;')
        exacts = ['/index.html'] + (['/sw.js', '/sw-assets.js', '/version.json'] if prefix == 'app' else [])
        for path in exacts:
            check('specific_no_cache_' + prefix + path, headers(nl['= /' + prefix + path]) == headers(backend['= ' + path]))
        root = Path('/workspace/scratch/rct-validation/current_vue_stage/frontend') / frontend / 'dist'
        for file in root.rglob('*'):
            if file.is_file():
                check('public_byte_mapping_' + prefix + '/' + str(file.relative_to(root)),
                      not file.is_symlink() and stat.S_IMODE(file.stat().st_mode) == 0o644)
    # Counterexample sensitivity: policy files must beat regex; unrelated paths must not enter static roots.
    check('policy_exact_beats_immutable', '= /app/sw.js' in nl and headers(nl['= /app/sw.js']) != headers(immutable))
    pattern = re.compile(r'^/(?:app|mini-app)/.*\.(js|css|png|jpg|jpeg|svg|ico|woff|woff2)$', re.I)
    for url in ['/api/test.js', '/outside.js', '/appish/test.js', '/mini-appish/a.css']:
        check('foreign_static_rejected_' + url, pattern.match(url) is None)
    for url in ['/app/assets/app.js', '/mini-app/assets/APP.CSS']:
        check('genuine_static_accepted_' + url, pattern.match(url) is not None)
    previous_specs = json.loads((OLD / 'host-service-specs.json').read_text())
    specs = json.loads((OWN / 'host-service-specs.json').read_text())
    for before, after in zip(previous_specs, specs):
        changed = [key for key in before if before[key] != after[key]]
        check('seven_spec_only_private_pointer_' + before['service'], changed == ['private_environment_file'])
        check('private_ENV_equal_' + before['service'], Path(before['private_environment_file']).read_bytes()
              == Path(after['private_environment_file']).read_bytes())
    creds = dict(line.split('=', 1) for line in (OWN / 'private/docker.env').read_text().splitlines() if line and not line.startswith('#'))
    key = creds['MONGODB_REPLICA_SET_KEY']
    check('existing_synthetic_keyFile_canonical_format_only', 6 <= len(key) <= 1024
          and all(c in 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=' for c in key))
    del key, creds
    check('accepted_app_roles_script_byte_equal', (OWN / 'mongo-init-app-users.js').read_bytes()
          == (REPO / 'infra/mongo/init-mongo.js').read_bytes())
    native = load_source('run-mongo.py')
    service = load_source('run-service-v5.py')
    false = OWN / 'private/false-grant.json'
    false.write_text('{"launch_authorized": false}\n')
    false.chmod(0o600)
    for module, args in [(native, ['--phase', 'server']), (service, ['--service', 'academic'])]:
        original_argv = sys.argv
        sys.argv = [module.__file__, *args, '--grant', str(false)]
        rejected = False
        try:
            with contextlib.redirect_stdout(io.StringIO()), contextlib.redirect_stderr(io.StringIO()):
                module.main()
        except RuntimeError:
            rejected = True
        finally:
            sys.argv = original_argv
        check('actual_selected_main_falsegrant_' + module.__name__, rejected)
    check('falsegrant_no_db_or_key_allocation', not Path('/tmp/rct-native-mongo-20261012/fresh-db').exists()
          and not Path('/tmp/rct-native-mongo-20261012/runtime').exists())
    safe = {'status': 'PASS_SOURCE_ONLY', 'checks': checks, 'actual_children': 0,
            'not_run': ['mongod server', 'bootstrap', 'Docker6', 'Nginx native syntax/HTTP', 'Host7', 'browser', 'auth/wire acceptance'],
            'scope': 'Pure source controls; does not claim actual route response/DB behavior.'}
    (OWN / 'validation-v5.safe.json').write_text(json.dumps(safe, indent=2) + '\n')
    print(json.dumps({'source_controls': len(checks), 'pass': True, 'applications_started': 0}))

if __name__ == '__main__':
    main()
