Исходный frozen8fe client14: CHANGES_REQUESTED; два P2 — CRA-EXPORT-T01 (фильтр/обычные поля HTML не защищены body oracle) и CRA-VIEWPORT-T02 (Desktop project viewport перекрывает390×844). Report.md/partial-findings.safe.json содержат exact paths, причины и минимальные corrections. Root получил обе находки до зависимой correction/review; reviewer не автор и не исправляет source.

Семь original frozen Git blobs совпадают с independently verified archive61 SHA/bytes; только7A/new tests, Angular/product/API/locks untouched. TS0/list28/hooks1/default57 receipts приняты как SOURCE only. Reviewer actually harmless checks: original seven export body predicates false-green на18 meaningful bad controls +2positives; viewport vendor/public merge native0 оба1280×720. Browser/app/API/DB/runtime/mutations NOT_RUN.

Prepared-v3 TMA signer mismatch — отдельная Root runtime prerequisite, live ENV не inspected; Root NEWv4 readiness отдельно. Same-target valid proof/control перед negative auth_date и specific problem distinction рекомендованы. Никакой whole11CLIENT family/provider/isolation PASS.

Оригинальный package после seal immutable. Автор corrections WIP ожидает Root freeze; свежий correction recheck должен писать NEW scratch, сохранять original findings/receipts. Existing8 browser acceptance может идти по отдельному grant; этот барьер касается NEW14.
