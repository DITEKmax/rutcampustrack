"""One finite accepted-guard native mongosh readiness check. No server manager."""
import hashlib
import json
import os
from pathlib import Path
import stat
import types

OWN = Path(__file__).parent
BASE = Path('/workspace/scratch/rct-validation/current_host_config_v5')
GUARD = BASE.parent / 'guard_proc_race_correction/bounded-child.py'
grant = json.loads((BASE / 'private/launch-grant.json').read_text())
assert grant['launch_authorized'] is True and grant['native_mongo_authorized'] is True
assert grant['config_manifest_sha256'] == hashlib.sha256((BASE / 'launch-manifest.json').read_bytes()).hexdigest()
assert grant['mongo_identity_correction_manifest_sha256'] == hashlib.sha256((BASE.parent / 'current_host_config_v5_mongo_identity_correction/manifest.json').read_bytes()).hexdigest()
body = GUARD.read_bytes()
assert hashlib.sha256(body).hexdigest() == grant['reviewed_guard_sha256'] == 'b78c61293568d9941692e0b92ee34fd0b84db6d532b4a2c9a5ad42ccbf2204a0'
guard = types.ModuleType('readiness_owned_guard')
exec(compile(body, str(GUARD), 'exec'), guard.__dict__)
record = json.loads((BASE / 'runtime/mongo-server-process.safe.json').read_text())
rows = [r for r in record['members_including_Z'] if r['pid'] == record['child_pid']]
assert len(rows) == 1
current = guard.process_table().get(rows[0]['pid'])
assert current and current['start_ticks'] == rows[0]['start_ticks'] and current['state'] not in ('Z', 'X', 'x')
private = BASE / 'private/docker.env'
m = private.lstat()
assert stat.S_ISREG(m.st_mode) and stat.S_IMODE(m.st_mode) == 0o600 and m.st_uid == os.getuid()
values = dict(line.split('=', 1) for line in private.read_text().splitlines() if line and not line.startswith('#'))
names = ['MONGO_ROOT_USER', 'MONGO_ROOT_PASSWORD', 'MONGO_USER', 'MONGO_PASSWORD', 'MONGO_NOTIFICATION_USER', 'MONGO_NOTIFICATION_PASSWORD']
env = {'PATH': '/usr/bin:/bin', 'HOME': '/tmp/rct-native-mongo-20261012/runtime', 'LANG': 'C.UTF-8',
       'MONGOSH_FORCE_DISABLE_TELEMETRY': 'true'}
env.update({name: values[name] for name in names})
del values
def observe():
    for path in ['/workspace', '/tmp']:
        f = os.statvfs(path)
        if f.f_bavail * f.f_frsize < 4294967296: return 'DISK_FLOOR'
    used = int(Path('/sys/fs/cgroup/memory.current').read_text())
    maximum = int(Path('/sys/fs/cgroup/memory.max').read_text())
    if used >= 16106127360 or maximum - used < 1073741824: return 'SHARED_MEMORY_STOP'
    return None
result = guard.run_owned(['/tmp/rct-native-mongo-20261012/mongosh', '--norc', '--quiet',
    'mongodb://127.0.0.1:28417/admin?directConnection=true', str(OWN / 'mongo-readiness.js')], str(OWN), env,
    deadline_seconds=60, observe=observe,
    status=lambda value: (OWN / 'mongo-readiness-process.safe.json').write_text(json.dumps(value, indent=2) + '\n'))
(OWN / 'mongo-readiness-terminal.safe.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({'native_exit': result['native_exit'], 'settled': result['settled'], 'phase_success': result['phase_success']}))
raise SystemExit(0 if result['phase_success'] else 1)
