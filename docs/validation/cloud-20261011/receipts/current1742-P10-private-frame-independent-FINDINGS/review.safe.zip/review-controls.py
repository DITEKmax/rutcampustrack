"""Independent selected-AST/RAM checks; no observer launch or private input read."""
import ast
import hashlib
import io
import json
from pathlib import Path, PurePosixPath
import re
import stat
from types import SimpleNamespace
import xml.etree.ElementTree as ET
from xml.sax.saxutils import escape, quoteattr
import zipfile

HERE = Path(__file__).resolve().parent
SCOPE = Path('/workspace/scratch/rct-validation/client_session_offline_acceptance/p10-current1742-failure-frame-source')
text = (SCOPE / 'logged-green-child.py').read_text()
tree = ast.parse(text)
names = {'CLASS', 'METHOD', 'SOURCE_SHA', 'TYPES', 'HELPERS', 'DiagnosticBlocked', 'need',
         'selected_xml_projection', 'selected_xml_from_zip', 'observe_original_case'}
nodes = [n for n in tree.body if (isinstance(n, (ast.FunctionDef, ast.ClassDef)) and n.name in names)
         or (isinstance(n, ast.Assign) and any(isinstance(t, ast.Name) and t.id in names for t in n.targets))]
ns = {'re': re, 'ET': ET, 'io': io, 'zipfile': zipfile, 'stat': stat, 'PurePosixPath': PurePosixPath}
exec(compile(ast.Module(body=nodes, type_ignores=[]), '<pinned-selected-AST>', 'exec'), ns)
CLASS, METHOD = ns['CLASS'], ns['METHOD']
project, selected_zip, Blocked = ns['selected_xml_projection'], ns['selected_xml_from_zip'], ns['DiagnosticBlocked']
checks = {}

def xml(stack='', kind='java.lang.AssertionError', method=METHOD):
    failure = '<failure type=' + quoteattr(kind) + ' message="RAM_PRIVATE_MESSAGE">' + escape(stack) + '</failure>'
    cases = '<testcase classname=' + quoteattr(CLASS) + ' name=' + quoteattr(method) + '>' + failure + '</testcase>'
    cases += ''.join('<testcase classname=' + quoteattr(CLASS) + ' name="other' + str(i) + '"/>' for i in range(8))
    return ('<testsuite name=' + quoteattr(CLASS) + ' tests="9" failures="1" errors="0" skipped="0">' + cases + '</testsuite>').encode()

def rejects(body, code):
    try:
        project(body, 1403)
    except Blocked as error:
        return error.code == code
    return False

frame = ' at ' + CLASS + '.seedUnicodePasswordActor(AuthOtpFlowIT.java:1140)'
out = project(xml('RAM_PRIVATE_STACK\n' + frame + '\n at ' + CLASS + '.' + METHOD + '(AuthOtpFlowIT.java:226)'), 1403)
checks['known_type_first_frame_only_no_private_canary'] = (out['source_line'] == 1140 and out['helper'] == 'SEED_ACTOR'
    and out['exception_code'] == 'ASSERTION_ERROR' and 'RAM_PRIVATE' not in json.dumps(out))
out = project(xml(frame, kind='RAM_PRIVATE_UNKNOWN_CLASS'), 1403)
checks['unknown_class_never_exported'] = out['known_exception_class'] == 'UNKNOWN' and 'RAM_PRIVATE' not in json.dumps(out)
out = project(xml(' at ' + CLASS + '.RAM_PRIVATE_METHOD(AuthOtpFlowIT.java:20)'), 1403)
checks['unknown_helper_never_exported'] = out['helper'] == 'UNKNOWN' and 'RAM_PRIVATE' not in json.dumps(out)
checks['UTF16_DTD_rejected'] = rejects(('<?xml version="1.0" encoding="UTF-16"?><!DOCTYPE testsuite>' + xml().decode()).encode('utf-16'), 'XML_UTF8')
checks['UTF8_DTD_ENTITY_rejected'] = rejects(b'<!DOCTYPE testsuite [<!ENTITY x "v">]>' + xml(), 'XML_DTD_ENTITY_NUL')
checks['UTF8_BOM_declaration_positive'] = project(b'\xef\xbb\xbf<?xml version="1.0" encoding="UTF-8"?>' + xml(frame), 1403)['source_line'] == 1140
checks['NUL_rejected'] = rejects(xml() + b'\0', 'XML_DTD_ENTITY_NUL')
checks['foreign_case_rejected'] = rejects(xml(method='foreign'), 'XML_SELECTED_IDENTITY')
checks['out_of_source_line_rejected'] = rejects(xml(' at ' + CLASS + '.' + METHOD + '(AuthOtpFlowIT.java:1404)'), 'FRAME_SOURCE_LINE')
checks['malformed_XML_rejected'] = rejects(xml()[:-2], 'XML_SYNTAX')
checks['stack_line_cap_rejected'] = rejects(xml('\n'.join('line' for _ in range(257))), 'STACK_LINE_CAP')
checks['declaration_encoding_rejected'] = rejects(b'<?xml version="1.0" encoding="ISO-8859-1"?>' + xml(), 'XML_DECLARATION')
checks['xml_size_cap_rejected'] = rejects(b'a' * (1024**2 + 1), 'XML_SIZE')

member = 'auth-service/auth-app/build/test-results/integrationTest/TEST-' + CLASS + '.xml'
def archive(entries):
    sink = io.BytesIO()
    with zipfile.ZipFile(sink, 'w', compression=zipfile.ZIP_DEFLATED) as z:
        for name, body in entries:
            z.writestr(name, body)
    return sink.getvalue()

def zip_rejects(entries, code):
    try:
        selected_zip(archive(entries))
    except Blocked as error:
        return error.code == code
    return False

original_open = zipfile.ZipFile.open
opened = []
def tracking_open(self, name, *args, **kwargs):
    if args and args[0] == 'w':
        return original_open(self, name, *args, **kwargs)
    opened.append(name.filename if isinstance(name, zipfile.ZipInfo) else name)
    return original_open(self, name, *args, **kwargs)
data = archive([(member, xml(frame)), ('auth-service/auth-app/build/reports/tests/private.html', b'RAM_PRIVATE_OTHER_BODY')])
zipfile.ZipFile.open = tracking_open
try:
    checks['single_selected_member_only'] = selected_zip(data) == xml(frame) and opened == [member]
finally:
    zipfile.ZipFile.open = original_open
checks['ZIP_traversal_rejected'] = zip_rejects([(member, xml()), ('../other', b'')], 'ZIP_MEMBER_PATH')
checks['duplicate_allowed_selected_members_rejected'] = zip_rejects([(member, xml()), ('services/' + member, xml())], 'ZIP_SELECTED_COUNT')
checks['unapproved_prefix_rejected'] = zip_rejects([('unknown/' + member, xml())], 'ZIP_SELECTED_COUNT')
assert len(checks) == 17 and all(checks.values()), checks

# Lifecycle proof executes the exact observe_original_case AST with paths/stat/read/admission
# replaced by RAM objects. It stops at REQUEST_SCHEMA, before URL handling or any write.
class FakePath:
    def __init__(self, name='', metadata=None):
        self.name, self.metadata, self.unlinked = name, metadata, False
    def __truediv__(self, name):
        return request_path if name == '.download-request.private.json' else FakePath(name)
    def read_text(self):
        return json.dumps(artifact)
    def stat(self, **kwargs):
        if self.metadata is None:
            raise FileNotFoundError
        return self.metadata
    def unlink(self):
        self.unlinked = True

artifact = json.loads((SCOPE / 'metadata.safe.json').read_text())
plan = json.loads((SCOPE / 'green-plan.safe.json').read_text())
grant = {'original_artifact_observation_authorized': True, 'artifact_id': artifact['artifact_id'],
         'producer_head': artifact['head_sha'], 'actual_checkout': plan['actual_checkout'], 'selected_xml_projection_only': True}
ns.update(json=json, Path=lambda _: FakePath(), os=SimpleNamespace(geteuid=lambda: 1000),
    digest=lambda _: plan['metadata_sha256'], admit_child=lambda _: (plan, FakePath('run')),
    private_json=lambda p: {'grant_path': 'RAM_GRANT'} if p.name == 'parent-authority.private.json' else grant,
    owned_request=lambda _: ({'deliberately_invalid_schema': True}, (7, 11)))

lifecycle = {}
for label, mode, uid, links, inode in [
    ('own_private', 0o600, 1000, 1, 11), ('mode_drift', 0o644, 1000, 1, 11),
    ('uid_drift', 0o600, 999, 1, 11), ('nlink_drift', 0o600, 1000, 2, 11),
    ('inode_replaced', 0o600, 1000, 1, 12)]:
    request_path = FakePath('request', SimpleNamespace(st_dev=7, st_ino=inode, st_mode=stat.S_IFREG | mode, st_uid=uid, st_nlink=links))
    try:
        ns['observe_original_case'](FakePath('scope'))
    except Blocked as error:
        lifecycle[label] = {'request_unlinked': request_path.unlinked, 'terminal_code': error.code,
            'primary_preserved_in_context': isinstance(error.__context__, Blocked) and error.__context__.code == 'REQUEST_SCHEMA'}
assert lifecycle['own_private']['request_unlinked'] is True
assert lifecycle['mode_drift']['request_unlinked'] is True
assert all(lifecycle[k]['request_unlinked'] is False for k in ['uid_drift', 'nlink_drift', 'inode_replaced'])
assert all(lifecycle[k]['terminal_code'] == 'REQUEST_CLEANUP_IDENTITY' for k in ['uid_drift', 'nlink_drift', 'inode_replaced'])

pins = {}
seal = json.loads((SCOPE / 'manifest.safe.json').read_text())
for name, expected in seal['files'].items():
    content = (SCOPE / name).read_bytes()
    pins[name] = hashlib.sha256(content).hexdigest() == expected['sha256'] and len(content) == expected['bytes']
old = Path('/workspace/scratch/rct-validation/client_session_offline_acceptance/p06-format-compile-source/compile01')
pins['parent_exact_old_P06'] = (SCOPE / 'run-green-owned.py').read_bytes() == (old / 'run-green-owned.py').read_bytes()
old_ast = ast.parse((old / 'logged-green-child.py').read_text())
for name in ['digest', 'private_json', 'identity', 'admit_child']:
    a = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == name)
    b = next(n for n in old_ast.body if isinstance(n, ast.FunctionDef) and n.name == name)
    pins['admission_' + name] = ast.get_source_segment(text, a) == ast.get_source_segment((old / 'logged-green-child.py').read_text(), b)
manifest = json.loads((SCOPE / 'source-manifest.safe.json').read_text())
wt = Path(plan['worktree'])
pins['all18_source_manifest_files'] = all(hashlib.sha256((wt / name).read_bytes()).hexdigest() == expected for name, expected in {**manifest['files'], **manifest['protected_files']}.items())
pins['guard_b78'] = hashlib.sha256(Path(plan['guard_path']).read_bytes()).hexdigest() == plan['guard_sha256']
source = (wt / plan['test_path']).read_text()
pins['source_1403_lines_12_helpers'] = len(source.splitlines()) == 1403 and all(name in source for name in ns['HELPERS'])
assert all(pins.values()), pins
new_template = json.loads((SCOPE / 'grant-template.private.json').read_text())
old_template = json.loads((old / 'grant-template.private.json').read_text())
pins['caps_exact_old_except_lower_phase60'] = (new_template['limits']['phase_seconds'] == 60 < old_template['limits']['phase_seconds']
    and {k: v for k, v in new_template['limits'].items() if k != 'phase_seconds'}
    == {k: v for k, v in old_template['limits'].items() if k != 'phase_seconds'})
pins['template_no_native_authority'] = all(new_template[k] is False for k in ['authorized', 'source_review_approved', 'original_artifact_observation_authorized'])
pins['READY_exact'] = hashlib.sha256((SCOPE / 'READY.safe.json').read_bytes()).hexdigest() == '93b399431fc7b2aaf227e0e686072a016769c060f7953891593d39ca7a6f7539'
pins['manifest_exact'] = hashlib.sha256((SCOPE / 'manifest.safe.json').read_bytes()).hexdigest() == '14eb04fcbd6f671f1a23a54099be85e62f30caf894ad0f41817d2f257550e505'
pins['ZIP_exact'] = hashlib.sha256((SCOPE / 'SOURCE.safe.zip').read_bytes()).hexdigest() == '8c3324d42acb89b8314ab585dbea1fd6b5c1355345f3fc2ba8cfe0daa05e8c20'
assert all(pins.values()), pins
additional = {}
additional['all11_exception_enums'] = all(project(xml(frame, kind=kind), 1403)['exception_code'] == code for kind, code in ns['TYPES'].items()) and len(ns['TYPES']) == 11
additional['all12_helper_enums'] = all(project(xml(' at ' + CLASS + '.' + name + '(AuthOtpFlowIT.java:20)'), 1403)['helper'] == code for name, code in ns['HELPERS'].items()) and len(ns['HELPERS']) == 12
additional['two_lambda_helpers'] = all(project(xml(' at ' + CLASS + '.lambda$' + name + '$0(AuthOtpFlowIT.java:20)'), 1403)['helper'] == ns['HELPERS'][name] for name in ['seedUnicodePasswordActor', 'cleanUnicodePasswordActors'])
additional['arbitrary_frame_paths_do_not_map'] = all(project(xml(' at ' + CLASS + '.' + METHOD + '(' + filename + ':20)'), 1403)['first_auth_frame_found'] is False for filename in ['private/path/AuthOtpFlowIT.java', 'Other.java', 'AuthOtpFlowIT.java.private'])
additional['first_unknown_helper_stays_unknown'] = project(xml(' at ' + CLASS + '.unknown(AuthOtpFlowIT.java:20)\n' + frame), 1403)['helper'] == 'UNKNOWN'
additional['other_auth_suite_errors_refused'] = rejects(xml().replace(b'name="other0"/>', b'name="other0"><error/></testcase>'), 'XML_SELECTED_FAILURE')
assert all(additional.values()), additional
result = {'schema': 'P10_INDEPENDENT_PRIVACY_SOURCE_RAM_REVIEW_V1', 'targeted17': checks, 'source_pins': pins,
          'additional6_projection_controls': additional, 'lifecycle_counterexamples': lifecycle, 'native_original_artifact': 'NOT_RUN', 'cause': 'UNKNOWN',
          'effects': {'network': 0, 'private_XML_log_reads': 0, 'product_edits': 0, 'real_metadata_mutations': 0},
          'verdict': 'FINDINGS', 'qualification': 'Only public Source reads and selected AST with RAM synthetic/mocked boundaries; no runtime acceptance.'}
(HERE / 'controls.safe.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({'targeted17_pass': all(checks.values()), 'pins_pass': all(pins.values()), 'lifecycle': lifecycle, 'verdict': 'FINDINGS'}))
