# Source-only privacy and first-three-case diagnosis

No Node, control, API or browser execution has been made for this task. Original source/attempt receipts and the old57 worktree are unchanged.

Pinned Playwright1.59.1 recognizes `PLAYWRIGHT_NO_COPY_PROMPT`, which returns before `page.ariaSnapshot`; `PW_TEST_DISABLE_ERROR_CONTEXT` is absent. Automatic `error-context.md` is still produced from meaningful errors after fixture teardown. Current SafeReporter attachment replacement starts only at `onTestEnd`, so a producer write can survive an interruption. This is an established interruption boundary risk, not confirmed credential disclosure.

The safe failure location at original line76 is HEADMAN `locator.click`; the write-status assertion is line77. The three failures remain undiagnosed.

Proposed narrow patch: require the actual producer flag before credentials and set it before workers load; preserve canonical reporter, error sanitizer and all artifact-off flags. First prove actual source producer capture suppression with a public synthetic marker and no reporter callback. Also test a browser-free late-fixture failure before claiming the remaining text-error boundary safe. No vendor file/dependency mutation.

Future observer emits only closed checkpoint/category/result enums and closed endpoint method/status enums. It ignores dynamic titles, errors, params, bodies, headers and identities. Supervision receipts live outside Playwright outputDir, which is cleared at startup. A scratch wrapper may register page-response observation on the unchanged imported original spec; Root must review its exact config hash and exact first-three selection before the next cohort. Original assertions stay intact.

Next: Root finite source/control grant, then freeze a narrow correction and qualified proof. A real three-case run needs a separately ready shared stand and fresh browser grant.
