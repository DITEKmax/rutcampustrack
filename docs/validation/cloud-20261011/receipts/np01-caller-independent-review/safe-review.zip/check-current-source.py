from pathlib import Path
import json,hashlib,stat,zipfile,ast
P=Path('/workspace/scratch/rct-validation/np01_broker_sensitivity_sourceprep');O=Path('/workspace/scratch/rct-validation/np01_native_caller_review');W=Path('/workspace/rct-worktrees/np01-broker-sensitivity');checks=[]
def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb') as f:
  for b in iter(lambda:f.read(65536),b''):h.update(b)
 return h.hexdigest()
def check(n,v):
 checks.append({'name':n,'pass':bool(v)})
 if not v:raise AssertionError(n)
check('caller_exact0747',sha(P/'run-stage.py')=='07475597f612ef2733dfc26ea7f830be174d40e6f647d7004d524cde78871958');check('SAFEZIP_exact8384',sha(P/'safe-sourceprep.zip')=='8384a33ae7cdaf43a7036d4fc0409cd96c412824ffab48c77834033c5771d313')
rows=json.loads((P/'manifest.safe.json').read_text())['entries'];check('safe8_seal_entries',len(rows)==8 and all(sha(P/r['path'])==r['sha256'] and (P/r['path']).stat().st_size==r['bytes'] and stat.S_IMODE((P/r['path']).stat().st_mode)==int(r['mode'],8) for r in rows))
with zipfile.ZipFile(P/'safe-sourceprep.zip') as z:check('SAFEZIP_CRC',z.testzip() is None);check('SAFEZIP_archive_bytes',all(hashlib.sha256(z.read(r['path'])).hexdigest()==r['sha256'] for r in rows))
source=json.loads((P/'sourceprep.safe.json').read_text());base=json.loads((P/'complete-sparse-baseline.safe.json').read_text());changed={r['path']:r for r in source['changes']};paths=[e['path'] for e in base['entries']];check('baseline1945_unique_lexical',len(paths)==1945 and len(set(paths))==1945 and all(not Path(p).is_absolute() and '..' not in Path(p).parts for p in paths));check('only2_selected',len(changed)==2)
protected={'env_samples':0,'public_key_fixture':0};hashed=0;metadata=0
for row in base['entries']:
 p=W/row['path'];s=p.lstat();check('metadata/'+row['path'],stat.S_ISREG(s.st_mode) and stat.S_IMODE(s.st_mode)==int(row['mode'],8) and s.st_nlink==1)
 if p.name.startswith('.env'):
  protected['env_samples']+=1;metadata+=1;continue
 if p.suffix in {'.pem','.key','.p12','.pfx','.jks'}:
  protected['public_key_fixture']+=1;metadata+=1;continue
 expected=changed[row['path']]['candidate_sha256'] if row['path'] in changed else row['sha256'];check('body_SHA/'+row['path'],sha(p)==expected);hashed+=1
check('nlink1_modes_all1945',hashed+metadata==1945);check('hash1942_metadata3_only',hashed==1942 and metadata==3)
check('Root_two_source_base_identity',all(sha(Path('/workspace/rutcampustrack')/r['path'])==r['base_sha256'] for r in source['changes']))
check('guard_b78',sha('/workspace/scratch/rct-validation/guard_proc_race_correction/bounded-child.py')=='b78c61293568d9941692e0b92ee34fd0b84db6d532b4a2c9a5ad42ccbf2204a0');check('guard_review_c61',sha('/workspace/scratch/rct-validation/guard_vue_current_review/immutable-review-manifest.json')=='c61b4647f8467726d2fdc308c2fb046fa1e3552c99e2b2294f1c8524c1c6fb36')
text=(P/'run-stage.py').read_text();tree=ast.parse(text);main=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='main');check('driver_parse_main_not_executed',True)
check('separate_phase_grant_gate',"grant['phase'] == phase" in text);check('offline_compile_no_test_tasks',all(x not in json.loads((P/'native-procedure.safe.json').read_text())['commands']['compile'] for x in ['test','integrationTest','--tests']))
procedure=json.loads((P/'native-procedure.safe.json').read_text());fault=procedure['commands']['fault'];check('one_exact_native_method',fault.count('--tests')==1 and fault[fault.index('--tests')+1]=='ru.rutcampustrack.academic.botcredentials.BotCredentialBrokerBridgeIT.actualProducerBrokerClaimAckRetryRestartAndDlqPreserveExactCards');check('two_stages_offline_nondaemon_bounds',all(all(x in a for x in ['--offline','--no-daemon','--no-parallel','--max-workers=1','--no-build-cache']) for a in procedure['commands'].values()))
check('child_log_EXCL600',"os.O_EXCL, 0o600" in text and 'native.raw.private.log' in text);check('outer_root_umask077',main.body[5].__class__.__name__=='Expr' if False else 'os.umask(0o077)' in text)
check('outer_guard_TERM15_KILL5', 'term_seconds=15, kill_seconds=5' in text);check('deadline_cleanup60_and_caps',all(x in text for x in ['<= 2 * GIB','<= 4 * GIB','<= 15 * GIB','>= GIB',"limits['cleanup_margin_seconds'] >= 60",'600 if phase == \'compile\' else 900']))
check('cohort_initial_budgets_used_without_phase_reset',"grant['cohort_initial_workspace_available_bytes'] - free" in text and "memory - grant['cohort_initial_shared_memory_bytes']" in text)
check('IT_outputs_absent_current',not (W/'services/academic-service/academic-app/build/test-results/integrationTest').exists());check('no_build_outputs_current',not list(W.glob('services/**/build')))
# Source profiles and actual ignored7 use public path names only; no contents read.
check('ignored_gitproperties7_count',len(procedure['generated_ignored_outputs'])==7 and len(set(procedure['generated_ignored_outputs']))==7);check('ignored7_currently_absent',all(not (W/p).exists() for p in procedure['generated_ignored_outputs']))
(O/'current-source-checks.safe.json').write_text(json.dumps({'status':'CURRENT_SOURCE_PREPARATION_PASS_WITH_SEPARATE_CALLER_FINDING','checks':checks,'count':len(checks),'tracked_metadata1945':True,'source_bodies_hashed1942':hashed,'three_exempt_source_bodies_not_read':protected,'unselected_source_expected1943':'1940 body hashes+3 metadata-only ENV/public-key exemptions; trusted original sealed ledger retained','raw_logs_private_patch_ENV_key_data_contents_read':False,'actual_runtime':False},indent=2)+'\n')
print(json.dumps({'checks':len(checks),'tracked1945_metadata_valid':True,'source1942_hash_valid':True,'ENV_key_body_exemptions':protected,'actual_runtime':False}))
