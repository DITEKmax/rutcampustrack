import ast, datetime, hashlib, json, stat, types
from pathlib import Path

OWN=Path(__file__).parent
OLD=Path('/workspace/scratch/rct-validation/first3_dataset_call_source/checking-plan/native-plan/run-approved-node.py')
NEW=OWN/'native-plan/run-approved-node.py'
old_tree=ast.parse(OLD.read_bytes());new_tree=ast.parse(NEW.read_bytes())
old_code=compile(ast.Module(body=[node for node in old_tree.body if node.lineno>=75],type_ignores=[]),str(OLD),'exec')
new_code=compile(ast.Module(body=[node for node in new_tree.body if isinstance(node,ast.FunctionDef) and node.name=='run_checked_phases'],type_ignores=[]),str(NEW),'exec')

class P:
    def __init__(self,name,state): self.name=name;self.state=state
    def __str__(self): return self.name
    def __truediv__(self,name): return P(self.name+'/'+name,self.state)
    def __eq__(self,other): return isinstance(other,P) and self.name==other.name
    @property
    def parent(self): return P(self.name.rsplit('/',1)[0],self.state)
    def resolve(self): return self
    def is_dir(self): return self.name!='/own/node_modules'
    def is_symlink(self): return self.name=='/own/node_modules' and self.state['exists'] and not self.state['plain_replacement']
    def stat(self): return types.SimpleNamespace(st_uid=1000,st_ino=self.state['parent_inode'] if self.name=='/own' else 10,st_mode=0o40700)
    def lstat(self):
        if self.state['identity_error']: raise self.state['primary']
        return types.SimpleNamespace(st_uid=self.state['link_uid'],st_ino=self.state['link_inode'])
    def unlink(self,**kw):
        if self.name=='/own/node_modules': self.state['exists']=False;self.state['unlinks']+=1

class Receipt(P):
    def __truediv__(self,name): return Receipt(self.name+'/'+name,self.state)
    def exists(self): return self.state['receipt_error'] and self.name.endswith('format-check.safe.json')
    def read_text(self): raise self.state['primary']

class Clock:
    @staticmethod
    def now(zone): return datetime.datetime(2026,10,13,9,40,tzinfo=zone)

def exercise(version,mode):
    primary=RuntimeError('PUBLIC_PRIMARY_EXCEPTION')
    state={'exists':False,'unlinks':0,'observes':0,'settled_children':0,'calls':0,'parent_inode':10,'link_inode':20,'link_uid':1000,'plain_replacement':False,'identity_error':False,'receipt_error':False,'primary':primary,'output':None,'cleanup_dirs':0}
    def observe():
        state['observes']+=1
        if mode=='DEADLINE_BEFORE_FIRST_CHILD' and state['observes']>=2: return 'ABSOLUTE_DEADLINE'
        if mode=='DEADLINE_AFTER_SETTLED_CHILD' and state['observes']>=3: return 'ABSOLUTE_DEADLINE'
        return None
    def symlink(target,link,**kw):
        if mode=='FAILED_CREATION': raise primary
        state['exists']=True
        if mode=='UNCERTAIN_CREATION': raise primary
        if mode=='IDENTITY_CAPTURE_FAILURE': state['identity_error']=True
    def owned(*args,**kwargs):
        state['calls']+=1
        if mode=='OWNED_CALL_RAISES_UNKNOWN': raise primary
        if mode=='INTERRUPTION_AFTER_SETTLED_CHILD':
            state['settled_children']+=1
            raise KeyboardInterrupt()
        state['settled_children']+=1
        if mode=='RECEIPT_PARSE_FAILURE': state['receipt_error']=True
        if mode=='FOREIGN_PARENT_REPLACEMENT': state['parent_inode']=11
        if mode=='FOREIGN_LINK_REPLACEMENT': state['link_inode']=21
        if mode=='FOREIGN_LINK_UID': state['link_uid']=1001
        if mode=='FOREIGN_LINK_TYPE': state['plain_replacement']=True
        return {'phase_success':True,'native_exit':0,'settled':mode!='UNSETTLED_CHILD','all_owned_processes_reaped':mode!='UNREAPED_CHILD'}
    def atomic(path,value):
        if str(path).endswith('/OUTCOME.safe.json'):
            if mode=='OUTCOME_WRITE_FAILURE': raise primary
            state['output']=value
    phases=[] if mode in ['NORMAL_NO_CHILD_FALLTHROUGH','FAILED_CREATION','UNCERTAIN_CREATION','IDENTITY_CAPTURE_FAILURE'] else [{'name':'format-check','argv':['PUBLIC_NODE'],'expectedNativeExit':0}]
    if mode=='DEADLINE_AFTER_SETTLED_CHILD': phases=phases*2
    env={'Path':lambda name:P(str(name),state),'plan':{'ownedDependencyLink':{'path':'/own/node_modules','target':'/cached/node_modules'},'explicitEnv':{},'commands':phases},
      'g':{'owned_dependency_link':{'path':'/own/node_modules','target':'/cached/node_modules'},'per_phase_seconds':180},
      'os':types.SimpleNamespace(geteuid=lambda:1000,getpid=lambda:100,symlink=symlink,readlink=lambda p:'/foreign/node_modules' if mode=='FOREIGN_LINK_TARGET' and state['calls'] else '/cached/node_modules',path=types.SimpleNamespace(lexists=lambda p:state['exists'])),
      'observe':observe,'datetime':types.SimpleNamespace(datetime=Clock),'UTC':datetime.timezone.utc,'stop':datetime.datetime(2026,10,13,9,50,tzinfo=datetime.timezone.utc),
      'guard':types.SimpleNamespace(process_table=lambda:{100:{'pid':100,'start_ticks':1}},run_owned=owned),
      'atomic':atomic,'status':lambda value:None,'supervision':Receipt('/run/supervision',state),'run':Receipt('/run',state),'peaks':{},'json':json,'shlex':types.SimpleNamespace(join=lambda a:'PUBLIC_COMMAND',quote=lambda a:a),
      'shutil':types.SimpleNamespace(rmtree=lambda p:state.__setitem__('cleanup_dirs',state['cleanup_dirs']+1)),'stat':stat,'print':lambda *a,**k:None}
    failure=None;primary_same=False;return_code=None
    try:
        exec(old_code if version=='OLD' else new_code,env)
        if version=='NEW': return_code=env['run_checked_phases']()
    except BaseException as error:
        failure=type(error).__name__;primary_same=error is primary
    return {'code':mode,'version':version,'exception_type':failure,'primary_identity_preserved':primary_same,'return_code':return_code,'link_remaining':state['exists'],'unlink_count':state['unlinks'],'settled_owned_child_count':state['settled_children'],'guard_call_count':state['calls'],'active_call_unknown':bool(state['output'] and state['output'].get('activeOwnedCallUnknown')),'output_pass':bool(state['output'] and state['output'].get('pass')),'actual_fs_link_or_child_effects':False}

old_rows=[exercise('OLD',mode) for mode in ['NORMAL_NO_CHILD_FALLTHROUGH','DEADLINE_BEFORE_FIRST_CHILD','DEADLINE_AFTER_SETTLED_CHILD']]
assert old_rows[0]['link_remaining'] is False and all(row['link_remaining'] is True for row in old_rows[1:])
modes=['NORMAL_NO_CHILD_FALLTHROUGH','NORMAL_SETTLED_CHILD','DEADLINE_BEFORE_FIRST_CHILD','DEADLINE_AFTER_SETTLED_CHILD','RECEIPT_PARSE_FAILURE','OUTCOME_WRITE_FAILURE','FAILED_CREATION','UNCERTAIN_CREATION','IDENTITY_CAPTURE_FAILURE','OWNED_CALL_RAISES_UNKNOWN','INTERRUPTION_AFTER_SETTLED_CHILD','UNSETTLED_CHILD','UNREAPED_CHILD','FOREIGN_PARENT_REPLACEMENT','FOREIGN_LINK_REPLACEMENT','FOREIGN_LINK_UID','FOREIGN_LINK_TYPE','FOREIGN_LINK_TARGET']
new_rows=[exercise('NEW',mode) for mode in modes]
clean={'NORMAL_NO_CHILD_FALLTHROUGH','NORMAL_SETTLED_CHILD','DEADLINE_BEFORE_FIRST_CHILD','DEADLINE_AFTER_SETTLED_CHILD','RECEIPT_PARSE_FAILURE','OUTCOME_WRITE_FAILURE'}
for row in new_rows:
    assert row['unlink_count']==(1 if row['code'] in clean else 0),row['code']
    if row['code'] in {'RECEIPT_PARSE_FAILURE','OUTCOME_WRITE_FAILURE','FAILED_CREATION','UNCERTAIN_CREATION','IDENTITY_CAPTURE_FAILURE','OWNED_CALL_RAISES_UNKNOWN'}: assert row['primary_identity_preserved'] is True,row['code']
    if row['code'] not in {'NORMAL_NO_CHILD_FALLTHROUGH','NORMAL_SETTLED_CHILD'}: assert row['output_pass'] is False,row['code']
    if row['code'] in {'OWNED_CALL_RAISES_UNKNOWN','INTERRUPTION_AFTER_SETTLED_CHILD'}: assert row['active_call_unknown'] is True,row['code']
receipt={'schema':'RCT_FIRST3_LINK_LIFECYCLE_SELECTED_AST_RAM_V1','old_source_sha256':hashlib.sha256(OLD.read_bytes()).hexdigest(),'new_source_sha256':hashlib.sha256(NEW.read_bytes()).hexdigest(),'old_counterexamples':2,'new_controls':len(new_rows),'all_controls_passed':True,'controls':old_rows+new_rows,'actual_fs_link_or_child_effects':False,'native_Node_Java_Docker_API_browser':False,'producer_8ca6_unchanged':True}
(OWN/'lifecycle-controls.safe.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({'old_counterexamples':2,'new_controls':len(new_rows),'all_controls_passed':True,'actual_fs_link_or_child_effects':False}))
