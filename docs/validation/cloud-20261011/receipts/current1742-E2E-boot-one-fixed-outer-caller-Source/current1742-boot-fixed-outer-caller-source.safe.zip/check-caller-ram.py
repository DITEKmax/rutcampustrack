"""Actual fixed caller entry/lifecycle with RAM-only OS/gh controls."""
import ast,datetime,hashlib,importlib.util,json,os,stat,types
from pathlib import Path

OWN=Path(__file__).parent
SOURCE=OWN/'read-existing-boot.py'
raw=SOURCE.read_bytes()
tree=ast.parse(raw)
nodes=[n for n in tree.body if isinstance(n,(ast.FunctionDef,ast.ClassDef,ast.Assign))]
def load(path,name):
    spec=importlib.util.spec_from_file_location(name,path)
    m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
    return m

checks=[]
def run(case):
    base=datetime.datetime.now(datetime.timezone.utc)
    clock=[0]
    class Clock:
        fromisoformat=staticmethod(datetime.datetime.fromisoformat)
        @staticmethod
        def now(tz):return base+datetime.timedelta(seconds=clock[0])
    env={'Path':Path,'dt':types.SimpleNamespace(datetime=Clock,timezone=datetime.timezone),
        'hashlib':hashlib,'json':json,'stat':stat,'SimpleNamespace':types.SimpleNamespace,
        '__file__':str(SOURCE)}
    exec(compile(ast.Module(body=nodes,type_ignores=[]),str(SOURCE),'exec'),env)
    R2=env['R2'];GRANT=env['GRANT']
    caller_sha=hashlib.sha256(raw).hexdigest()
    identity=[1,2,1000,1000,0o700];outer=[1,3,1000,1000,0o700]
    grant={'authorized':True,'scope':'EXACT1742_JOB_LOG_READ_ONLY',
        'head':'1742d1e806faa5c39c6d182a3554daa8f4239801','run_id':38387263916,
        'job_id':115262001797,'run_attempt':1,'capture_sha256':env['PINS'][R2/'capture-job-private.py'],
        'max_bytes':33554432,'phase_seconds':45,'not_before':base.isoformat(),
        'cleanup_gate':(base+datetime.timedelta(seconds=90)).isoformat(),
        'hard_stop':(base+datetime.timedelta(seconds=120)).isoformat(),
        'caller_sha256':caller_sha,'parser_sha256':env['PINS'][R2/'closed-boot-parser.py'],
        'binding_sha256':env['PINS'][R2/'binding.actual.safe.json'],'b78_sha256':env['PINS'][env['GUARD']],
        'r2_manifest_sha256':env['PINS'][R2/'manifest.json'],'review_approved':True,
        'output':str(env['OUT']),'actor_uid':1000,'rss_bytes':536870912,
        'disk_growth_bytes':268435456,'floor_bytes':4294967296,
        'shared_stop_bytes':16106127360,'shared_reserve_bytes':1073741824,
        'private_directory_identity':identity,'outer_directory_identity':outer}
    if case=='FALSE_JOB':grant['job_id']=1
    if case=='FALSE_REVIEW':grant['review_approved']=False
    if case=='FALSE_SELF':grant['caller_sha256']='0'*64
    if case=='CAP_RAISE':grant['rss_bytes']+=1
    if case=='EXPIRED_ENTRY':clock[0]=121
    if case=='INSUFFICIENT_WINDOW':clock[0]=40
    data=b'2026-10-13T11:04:50Z Container rct-e2e-redis-1 Healthy\n2026-10-13T11:04:51Z PRIVATE_CANARY_ABC\n'
    if case=='MALFORMED_PRIVATE':data=b'\xff'
    leaf=[False];changed=[False];captured=[False];proc_active=[False]
    counts={'capture':0,'private_reads':0,'unlink':0,'mkdir':0,'write':0}
    outputs={};fdname={};nextfd=[100]
    def row(mode=0o100600,ino=9,uid=1000,nlink=1,size=0):
        return types.SimpleNamespace(st_dev=1,st_ino=ino,st_uid=uid,st_gid=1000,
            st_mode=mode,st_nlink=nlink,st_size=size,st_mtime_ns=1,st_ctime_ns=1)
    def logrow():
        return row(ino=10 if changed[0] else 9,uid=999 if case=='FAILED_CAPTURE_FOREIGN' else 1000,size=len(data))
    def open_(name,flags,*a,dir_fd=None,**k):
        nextfd[0]+=1;fd=nextfd[0];fdname[fd]=str(name)
        if flags & os.O_WRONLY:outputs[str(name)]=b''
        return fd
    def fstat(fd):
        if fd==10:return row(mode=0o40700,ino=2)
        if fd==11:return row(mode=0o40700,ino=3)
        name=fdname.get(fd,'')
        if name=='read-grant.json':return row(mode=0o100644 if case=='GRANT_MODE' else 0o100600,size=len(json.dumps(grant).encode()))
        if name=='job.log.private':return logrow()
        return row(mode=0o40700,ino=4)
    def stat_(name,*a,**k):
        if str(name)=='job.log.private':
            if not leaf[0]:raise FileNotFoundError()
            return logrow()
        raise AssertionError('unexpected RAM stat')
    def read(fd,n):
        name=fdname[fd]
        if name=='read-grant.json':return json.dumps(grant).encode()
        assert name=='job.log.private'
        counts['private_reads']+=1
        if case=='PRIMARY_AND_CLEANUP_FAIL':raise OSError('PUBLIC_PRIMARY')
        return data
    def unlink(name,*,dir_fd):
        counts['unlink']+=1
        if case=='PRIMARY_AND_CLEANUP_FAIL':raise PermissionError('PUBLIC_CLEANUP')
        leaf[0]=False
    def write(fd,value):
        counts['write']+=1;outputs[fdname[fd]]+=value
        return len(value)
    def mkdir(*a,**k):counts['mkdir']+=1
    class WS:
        f_bavail=10*1024**3
        f_frsize=1
    fake_os=types.SimpleNamespace(O_RDONLY=os.O_RDONLY,O_NOFOLLOW=os.O_NOFOLLOW,
        O_DIRECTORY=os.O_DIRECTORY,O_WRONLY=os.O_WRONLY,O_CREAT=os.O_CREAT,O_EXCL=os.O_EXCL,
        open=open_,fstat=fstat,stat=stat_,read=read,write=write,close=lambda _:None,
        unlink=unlink,mkdir=mkdir,getuid=lambda:1000,getpid=lambda:77,statvfs=lambda _:WS(),
        environ={'HOME':'/PUBLIC','GH_TOKEN':'PRIVATE_ENV_CANARY','JAVA_TOOL_OPTIONS':'UNRELATED_CANARY'})
    env['os']=fake_os
    class RAMPath:
        def __init__(self,value):self.value=str(value)
        def absolute(self):return Path(self.value).absolute()
        def __truediv__(self,v):return RAMPath(self.value+'/'+str(v))
        def read_text(self):
            if self.value=='/sys/fs/cgroup/memory.current':
                if case=='MEMORY_STOP':return str(16*1024**3)
                if case=='EXPIRE_DURING_MEASUREMENT':clock[0]=121
                return str(4*1024**3)
            assert self.value.startswith('/proc/')
            return 'VmRSS:\t1024 kB\n'
        def __str__(self):return self.value
    env['Path']=RAMPath
    public={str(p):p.read_bytes() for p in env['PINS']}
    public[str(SOURCE)]=raw
    env['public_bytes']=lambda p:public[str(p)]
    env['directory']=lambda p:10 if p==env['PRIVATE'] else 11
    env['sys']=types.SimpleNamespace(argv=[str(SOURCE),'--grant',str(GRANT)],dont_write_bytecode=False)
    parser=load(R2/'closed-boot-parser.py','ram_parser_'+case)
    capture=load(R2/'capture-job-private.py','ram_capture_'+case)
    class Guard:
        @staticmethod
        def process_table():
            own={77:{'pid':77,'start_ticks':700,'state':'R','ppid':1,'pgrp':77,'session':77}}
            if proc_active[0]:own[88]={'pid':88,'start_ticks':800,'state':'R','ppid':77,'pgrp':88,'session':88}
            return own
        @staticmethod
        def owned_records(table,parent,group,known):return {pid:r for pid,r in table.items() if pid==88}
        @staticmethod
        def run_owned(argv,cwd,env,**k):
            counts['capture']+=1
            assert argv==['/usr/bin/python3',str(R2/'capture-job-private.py'),'--grant',str(GRANT)]
            assert env['GH_TOKEN']=='PRIVATE_ENV_CANARY' and 'JAVA_TOOL_OPTIONS' not in env
            assert k['deadline_seconds']==45 and k['term_seconds']==5 and k['kill_seconds']==5
            assert k['observe']() is None
            proc_active[0]=True;leaf[0]=True;captured[0]=True
            k['status']({'state':'STARTED','child_pid':88,'members_including_Z':[],
                'reason':'NATIVE_TERMINAL','signal_count':0,'group':88})
            proc_active[0]=False
            failed=case in {'FAILED_CAPTURE','FAILED_CAPTURE_FOREIGN'}
            return {'settled':True,'all_owned_processes_reaped':True,'phase_success':not failed,
                'native_exit':1 if failed else 0,'known_owned_identities':[{'pid':88,'start_ticks':800}],
                'all_members_including_Z_after':[],'terminal_reason':'NATIVE_TERMINAL',
                'signal_count':0,'supervision_error_type':None}
    env['module']=lambda p,n:Guard if p==env['GUARD'] else capture if p.name=='capture-job-private.py' else parser
    # Expire just before private read, after terminal snapshot was recorded.
    real_open=open_
    if case=='EXPIRE_BEFORE_PRIVATE_READ':
        def read_deadline_open(name,*a,**k):
            fd=real_open(name,*a,**k)
            if str(name)=='job.log.private':clock[0]=121
            return fd
        fake_os.open=read_deadline_open
    native=env['main']()
    safe=b''.join(outputs.values())
    assert b'PRIVATE_CANARY_ABC' not in safe and b'PRIVATE_ENV_CANARY' not in safe and b'UNRELATED_CANARY' not in safe
    if case=='SUCCESS':assert native==0 and counts['capture']==1 and counts['private_reads']==1 and counts['unlink']==1 and not leaf[0]
    elif case=='FAILED_CAPTURE':assert native==1 and counts['private_reads']==0 and counts['unlink']==1 and not leaf[0]
    elif case=='FAILED_CAPTURE_FOREIGN':assert native==1 and counts['private_reads']==0 and counts['unlink']==0 and leaf[0]
    elif case=='MALFORMED_PRIVATE':assert native==1 and counts['private_reads']==1 and counts['unlink']==1 and not leaf[0]
    elif case=='PRIMARY_AND_CLEANUP_FAIL':
        assert native==1 and counts['private_reads']==1 and counts['unlink']==1 and leaf[0]
        f=json.loads(outputs['FAILURE.safe.json']);assert f['error_class']=='OSError' and f['cleanup_state']=='UNKNOWN_RECONCILIATION_REQUIRED'
    elif case=='EXPIRE_BEFORE_PRIVATE_READ':assert native==1 and counts['private_reads']==0 and leaf[0]
    else:assert native==1 and counts['capture']==0 and counts['mkdir']==0
    checks.append({'case':case,'native':native,'counts':counts,'privacy_canaries_absent':True,'RAM_only':True})

for case in ['SUCCESS','FALSE_JOB','FALSE_REVIEW','FALSE_SELF','CAP_RAISE','GRANT_MODE',
    'EXPIRED_ENTRY','INSUFFICIENT_WINDOW','MEMORY_STOP','EXPIRE_DURING_MEASUREMENT',
    'FAILED_CAPTURE','FAILED_CAPTURE_FOREIGN','MALFORMED_PRIVATE',
    'PRIMARY_AND_CLEANUP_FAIL','EXPIRE_BEFORE_PRIVATE_READ']:
    run(case)
print(json.dumps({'state':'CALLER_SOURCE_RAM_PASS','checks':checks,'actual_API_log_child':False}))
