import { writeFileSync } from 'node:fs';
import { test, sanitizeTestErrors } from '/workspace/rct-worktrees/client-ci-first3/tests/e2e/fixtures/artifact-privacy';

const marker = process.env.RCT_SAFE_FAILURE_CONTROL_MARKER!;
test.afterEach(async ({}, info) => sanitizeTestErrors(info));
const early = test.extend<{}, { earlyFailure: void }>({
  earlyFailure: [async () => { throw new Error('Synthetic actor login: HTTP 401'); }, { scope: 'worker' }],
});
early.fail('source known worker setup failure precedes the test body', async ({ earlyFailure }, info) => {
  void earlyFailure;
  writeFileSync(info.outputPath('body-started.safe.json'), JSON.stringify({ bodyStarted: true }));
  throw new Error('PUBLIC_BODY_MUST_NOT_START');
});
const late = test.extend<{ lateFailure: void }>({
  lateFailure: async ({}, use) => { await use(); throw new Error('Synthetic actor session: HTTP 503'); },
});
late.fail('source known explicit teardown failure keeps its closed cause', async ({ lateFailure }) => {
  void lateFailure;
});
const unknown = test.extend<{ unknownFailure: void }>({
  unknownFailure: [async () => { throw new Error(`Unknown private payload: ${marker}\nSynthetic actor login: HTTP 401`); }, { auto: true }],
});
unknown.fail('unknown multiline private setup error remains unknown and redacted', async ({}, info) => {
  writeFileSync(info.outputPath('body-started.safe.json'), JSON.stringify({ bodyStarted: true }));
  throw new Error('PUBLIC_BODY_MUST_NOT_START');
});
