"""Independent changed-catch AST controls only; no observer/native/private inputs."""
import ast
import hashlib
import json
from pathlib import Path
import ssl
import urllib.error
import zipfile
import xml.etree.ElementTree as ET

HERE = Path(__file__).resolve().parent
NEW = Path('/workspace/scratch/rct-validation/client_session_offline_acceptance/p10-current1742-failure-frame-source-operation-r1')
OLD = NEW.with_name('p10-current1742-failure-frame-source-lifecycle-r1')
text = (NEW / 'logged-green-child.py').read_text()
tree = ast.parse(text)
observer = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == 'observe_original_case')
block = next(n for n in observer.body if isinstance(n, ast.Try))
setup = [n for n in tree.body if isinstance(n, ast.ClassDef) and n.name == 'DiagnosticBlocked'
    or isinstance(n, ast.Assign) and any(isinstance(t, ast.Name) and t.id == 'PRIMARY_REJECTION_CODES' for t in n.targets)]
base = {'urllib': __import__('urllib'), 'ssl': ssl, 'zipfile': zipfile, 'ET': ET, 'json': json}
exec(compile(ast.Module(body=setup, type_ignores=[]), '<selected-public-setup>', 'exec'), base)
D = base['DiagnosticBlocked']
catch = compile(ast.Module(body=block.handlers[0].body, type_ignores=[]), '<exact-new-catch>', 'exec')
canary = 'RAM_PRIVATE_CANARY'
def evaluate(error, stage='URL_OPEN'):
    ns = {**base, 'failure': error, 'operation_stage': stage, 'primary_rejection': 'NONE', 'exception_code': 'NONE', 'http_status': 0}
    classifier_failed = False
    try:
        exec(catch, ns)
    except BaseException:
        classifier_failed = True
    result = {key: ns[key] for key in ['operation_stage', 'primary_rejection', 'exception_code', 'http_status']}
    assert canary not in json.dumps(result)
    return result, classifier_failed

def http(code):
    return urllib.error.HTTPError('https://ram.invalid/' + canary, code, canary, {}, None)

ordinary = {}
for code, error in [
    ('DIAGNOSTIC_BLOCKED', D('ZIP_SYNTAX')),
    ('HTTP_ERROR', http(403)), ('URL_ERROR', urllib.error.URLError(canary)),
    ('TLS_CERT_VERIFICATION', ssl.SSLCertVerificationError(1, canary)), ('TLS_ERROR', ssl.SSLError(1, canary)),
    ('TIMEOUT', TimeoutError(canary)), ('CONNECTION_RESET', ConnectionResetError(canary)),
    ('CONNECTION_REFUSED', ConnectionRefusedError(canary)), ('PERMISSION', PermissionError(canary)),
    ('FILE_NOT_FOUND', FileNotFoundError(canary)), ('FILE_EXISTS', FileExistsError(canary)),
    ('OS_ERROR', OSError(canary)), ('VALUE', ValueError(canary)), ('TYPE', TypeError(canary)),
    ('KEY', KeyError(canary)), ('UNICODE_DECODE', UnicodeDecodeError('utf-8', b'\xff', 0, 1, canary)),
    ('JSON_DECODE', json.JSONDecodeError(canary, canary, 0)), ('ZIP_ERROR', zipfile.BadZipFile(canary)), ('XML_PARSE', ET.ParseError(canary))]:
    result, failed = evaluate(error)
    assert not failed and result['exception_code'] == code
    assert result['primary_rejection'] == ('ZIP_SYNTAX' if code == 'DIAGNOSTIC_BLOCKED' else 'BOUNDARY_UNKNOWN')
    ordinary[code] = True
assert len(ordinary) == 19

getter_calls = []
class UnknownHTTP(urllib.error.HTTPError):
    def __getattribute__(self, name):
        if object.__getattribute__(self, '__dict__').get('_armed', False):
            getter_calls.append('INSTANCE_GETTER')
            raise RuntimeError('getter canary')
        return object.__getattribute__(self, name)
    def __str__(self):
        getter_calls.append('STRING_COERCION')
        raise RuntimeError('str canary')
error = UnknownHTTP('https://ram.invalid/' + canary, 403, canary, {}, None)
object.__getattribute__(error, '__dict__')['_armed'] = True
r, failed = evaluate(error)
assert not failed and r['exception_code'] == 'OTHER' and r['http_status'] == 0 and not getter_calls
class IntTrap(int):
    def __int__(self):
        raise AssertionError('INT_COERCION')
    def __str__(self):
        raise AssertionError('STRING_COERCION')
status_checks = {}
for label, value, expected in [('bool', True, 0), ('text', '403', 0), ('int_subclass', IntTrap(403), 0),
    ('object', object(), 0), ('low', 99, 0), ('high', 600, 0), ('lower_edge', 100, 100), ('upper_edge', 599, 599)]:
    r, failed = evaluate(http(value))
    assert not failed and r['http_status'] == expected and r['exception_code'] == 'HTTP_ERROR'
    status_checks[label] = True

meta_calls = []
class HashTrap(type):
    def __hash__(cls):
        meta_calls.append('UNKNOWN_META_HASH_EXECUTED')
        raise RuntimeError(canary)
class HashTrapError(Exception, metaclass=HashTrap):
    pass
r, failed = evaluate(HashTrapError(canary))
assert failed and meta_calls == ['UNKNOWN_META_HASH_EXECUTED'] and r['primary_rejection'] == 'NONE' and r['exception_code'] == 'NONE'
counterexample = {'classifier_failed': failed, 'hook_calls': list(meta_calls), 'closed_state_after_failure': r}

equality_calls = []
class EqualTrap(type):
    def __hash__(cls):
        equality_calls.append('UNKNOWN_META_HASH_EXECUTED')
        return hash(urllib.error.HTTPError)
    def __eq__(cls, other):
        equality_calls.append('UNKNOWN_META_EQ_EXECUTED')
        return other is urllib.error.HTTPError
class EqualTrapError(Exception, metaclass=EqualTrap):
    pass
r, failed = evaluate(EqualTrapError(canary))
assert not failed and r['exception_code'] == 'HTTP_ERROR' and 'UNKNOWN_META_EQ_EXECUTED' in equality_calls
forged = {'classifier_failed': failed, 'hook_calls': equality_calls, 'closed_state': r,
    'exact_standard_type': False, 'unknown_should_be_OTHER': False}

stages = [n.value.value for n in ast.walk(observer) if isinstance(n, ast.Assign)
    and any(isinstance(t, ast.Name) and t.id == 'operation_stage' for t in n.targets)]
assert len(stages) == len(set(stages)) == 15 and all(type(s) is str for s in stages)
pins = {}
for name, sha in json.loads((NEW / 'manifest.safe.json').read_text())['files'].items():
    pins[name] = hashlib.sha256((NEW / name).read_bytes()).hexdigest() == sha
old_text = (OLD / 'logged-green-child.py').read_text()
old_tree = ast.parse(old_text)
def inverse(text, tree, new):
    lines = text.splitlines(keepends=True)
    changes = [n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == 'observe_original_case'
        or new and isinstance(n, ast.Import) and n.names[0].name in {'urllib.error', 'ssl'}]
    for node in sorted(changes, key=lambda n: n.lineno, reverse=True):
        del lines[node.lineno - 1:node.end_lineno]
    return ''.join(lines)
pins['whole_inverse'] = inverse(text, tree, True) == inverse(old_text, old_tree, False)
pins['parent_exact'] = (NEW / 'run-green-owned.py').read_bytes() == (OLD / 'run-green-owned.py').read_bytes()
pins['caps_exact'] = json.loads((NEW / 'grant-template.private.json').read_text())['limits'] == json.loads((OLD / 'grant-template.private.json').read_text())['limits']
pins['primary_codes_exact'] = ast.get_source_segment(text, next(n for n in tree.body if isinstance(n, ast.Assign) and any(isinstance(t, ast.Name) and t.id == 'PRIMARY_REJECTION_CODES' for t in n.targets))) == ast.get_source_segment(old_text, next(n for n in old_tree.body if isinstance(n, ast.Assign) and any(isinstance(t, ast.Name) and t.id == 'PRIMARY_REJECTION_CODES' for t in n.targets)))
manifest = json.loads((NEW / 'source-manifest.safe.json').read_text())
plan = json.loads((NEW / 'green-plan.safe.json').read_text())
wt = Path(plan['worktree'])
pins['18_public_inputs'] = all(hashlib.sha256((wt / n).read_bytes()).hexdigest() == sha for n, sha in {**manifest['files'], **manifest['protected_files']}.items())
pins['b78'] = hashlib.sha256(Path(plan['guard_path']).read_bytes()).hexdigest() == plan['guard_sha256']
for name, expected in [('READY.safe.json', 'cfbd8290d826180e57e4607180641655bbc344ef26701a725c89f5425c347121'),
    ('manifest.safe.json', '270111f261d0fade23cb22e8281c735e3fdee1f1dbfa95fda927f6dbbfe242d8'),
    ('SOURCE.safe.zip', '57a9a5317fe236c87c25f0f29109ba462136d2738b6f5d5dcedc8233b7aa4208')]:
    pins['sealed_' + name] = hashlib.sha256((NEW / name).read_bytes()).hexdigest() == expected
assert all(pins.values()), {k: v for k, v in pins.items() if not v}
out = {'schema': 'P10_OPERATION_R1_INDEPENDENT_CHANGED_CATCH_REVIEW_V1', 'verdict': 'FINDINGS',
    'ordinary19': ordinary, 'status8': status_checks, 'ordinary_subclass_no_instance_getter_or_str': True,
    'static15_stages': stages, 'source_pins': pins,
    'unknown_metaclass_hash_counterexample': counterexample, 'unknown_metaclass_equal_false_mapping': forged,
    'old_lifecycle13_and_parser17plus6': 'REUSED_NOT_RERUN', 'native': 'NOT_RUN', 'actual02_cause': 'UNKNOWN',
    'effects': 'Source reads + RAM synthetic exception/catch AST only; no actual network/URL/body/XML/log/environment/native/Source edits'}
(HERE / 'controls.safe.json').write_text(json.dumps(out, indent=2) + '\n')
print(json.dumps({'verdict': 'FINDINGS', 'ordinary19': 'PASS', 'status8': 'PASS', 'Source_pins': 'PASS', 'metaclass_counterexamples': 2}))
