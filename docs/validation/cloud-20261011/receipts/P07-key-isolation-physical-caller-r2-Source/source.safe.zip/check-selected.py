"""Selected actual-branch RAM checks for the two caller findings; native NOT_RUN."""
import ast
import datetime
import hashlib
import json
import math
from pathlib import Path
from types import SimpleNamespace

source = Path(__file__).with_name("prove-key-volume.py")
tree = ast.parse(source.read_text())
main = next(node for node in tree.body if isinstance(node, ast.FunctionDef) and node.name == "main")
flow = next(node for node in main.body if isinstance(node, ast.Try))
volume = "p07-key-isolation-20261013-01"
admission = next(node for node in tree.body if isinstance(node, ast.FunctionDef) and node.name == "admit_volume")
namespace = {"datetime": datetime, "math": math, "VOLUME": volume}
exec(compile(ast.Module(body=[admission], type_ignores=[]), str(source), "exec"), namespace)
start = datetime.datetime(2026, 10, 13, 13, 45, 0, 100000, tzinfo=datetime.timezone.utc).timestamp()
cases = []
for name, timestamp, accepted in (
    ("old_matching_label_denied", "2020-01-01T00:00:00Z", False),
    ("invalid_createdAt_denied", "INVALID", False),
    ("future_createdAt_denied", "2026-10-13T13:45:02Z", False),
    ("missing_timezone_denied", "2026-10-13T13:45:00", False),
    ("nonUTC_timezone_denied", "2026-10-13T14:45:00+01:00", False),
    ("fresh_second_precision_admitted", "2026-10-13T13:45:00Z", True),
    ("fresh_fractional_precision_admitted", "2026-10-13T13:45:00.200000Z", True),
):
    candidate = volume + " " + timestamp + " 20261013-01"
    try:
        outcome = namespace["admit_volume"](candidate, start, start + .5)
    except (ValueError, RuntimeError):
        assert not accepted
    else:
        assert accepted and outcome == candidate
    cases.append({"case": name, "status": "PASS"})

# Run the exact precreation/generation statements and the unchanged original except/finally.
begin = next(index for index, node in enumerate(flow.body)
             if isinstance(node, ast.Assign) and any(isinstance(target, ast.Name) and target.id == "private" for target in node.targets))
end = next(index for index in range(begin, len(flow.body))
           if isinstance(flow.body[index], ast.Expr) and isinstance(flow.body[index].value, ast.Call)
           and isinstance(flow.body[index].value.func, ast.Name) and flow.body[index].value.func.id == "run"
           and isinstance(flow.body[index].value.args[0], ast.List)
           and len(flow.body[index].value.args[0].elts) > 1
           and isinstance(flow.body[index].value.args[0].elts[1], ast.Constant)
           and flow.body[index].value.args[0].elts[1].value == "pkey")
selected = ast.Try(body=flow.body[begin:end+1], handlers=flow.handlers, orelse=[], finalbody=flow.finalbody)
ast.fix_missing_locations(selected)

for failure_operation in ("genpkey", "pkey"):
    created = {"private.key": False, "public.key": False}
    descriptors = {}
    output = []
    removed = []
    primary = OSError()

    class RamPath:
        def __init__(self, name): self.name = str(name).rsplit("/", 1)[-1]
        def __truediv__(self, name): return RamPath(name)
        def exists(self): return created[self.name]
        def stat(self, **kwargs): return metadata(self.name)
        def unlink(self): created[self.name] = False
        def rmdir(self): assert not any(created.values()); removed.append(True)

    def metadata(name):
        return SimpleNamespace(st_dev=1, st_ino=2 if name == "private.key" else 3, st_uid=1000, st_nlink=1)

    def exclusive_open(key, flags, mode):
        assert flags == 1 | 64 | 128 | 131072 and mode == 0o600
        assert not created[key.name]
        created[key.name] = True
        descriptor = len(descriptors) + 1
        descriptors[descriptor] = key.name
        return descriptor

    def native(argv, **kwargs):
        # The selected native writer fails after a partial write; content never exists in this model.
        assert len(ns["key_identities"]) == 2 and all(created.values())
        if argv[1] == failure_operation:
            raise primary
        return ""

    ns = {"Path": RamPath, "synthetic": "RAM_ONLY_DIRECTORY", "synthetic_identity": (1, 1, 1000),
          "key_identities": {}, "created_containers": {}, "created_volume": False,
          "run": native, "resource_gate": lambda *a, **kw: 30, "initial_free": {}, "deadline": 280,
          "result": {"state": "IN_PROGRESS"}, "start": 0,
          "time": SimpleNamespace(monotonic=lambda: 0), "json": json,
          "OUTPUT": SimpleNamespace(write_text=lambda value: output.append(json.loads(value))),
          "os": SimpleNamespace(open=exclusive_open, fstat=lambda descriptor: metadata(descriptors[descriptor]),
                                close=lambda descriptor: None, O_WRONLY=1, O_CREAT=64, O_EXCL=128, O_NOFOLLOW=131072,
                                stat=lambda *a, **kw: SimpleNamespace(st_dev=1, st_ino=1, st_uid=1000))}
    try:
        exec(compile(ast.Module(body=[selected], type_ignores=[]), str(source), "exec"), ns)
    except OSError as final:
        assert final is primary and not any(created.values()) and removed == [True]
        assert output[-1]["state"] == "FAIL" and output[-1]["cleanup_errors"] == 0
        assert output[-1]["error_type"] == "OSError"
    else:
        raise AssertionError("native failure not preserved")
    cases.append({"case": "partial_" + failure_operation + "_failure_cleans_exact_owned_leaves", "status": "PASS"})

receipt = {"state": "SELECTED_ACTUAL_AST_RAM_PASS_NATIVE_NOT_RUN", "source_sha256": hashlib.sha256(source.read_bytes()).hexdigest(), "cases": cases,
           "qualification": "Second-precision CreatedAt admission is not atomic ownership proof; original namespace/sameUID qualifications retained. Original20 unchanged branches not rerun."}
Path(__file__).with_name("selected-controls.safe.json").write_text(json.dumps(receipt, indent=2) + "\n")
print(json.dumps({"state": receipt["state"], "controls": len(cases)}))
