"""Author-only pure strict schema controls; no remote artifacts, Node or product runtime."""
from pathlib import Path
import copy,hashlib,importlib.util,json,os,re
P=Path(__file__).parent
spec=importlib.util.spec_from_file_location('candidate_closed_schema',P/'strict-browser-schema.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
spec=importlib.util.spec_from_file_location('old_sealed_schema',P/'before-strict-browser-schema.py');old=importlib.util.module_from_spec(spec);spec.loader.exec_module(old)
assert m.STAGES==old.STAGES and m.HTTP==old.HTTP and m.HTTP_CAUSES==old.HTTP_CAUSES and m.CODES==old.CODES
declared=Path('/workspace/scratch/rct-validation/client_real_acceptance/ci-reported-hints-48124/after/safe-reporter.ts').read_text()
classes=re.search(r'const reportedClassHints = \{(.*?)\} as const;',declared,re.S)[1]
frames=re.search(r'const reportedFrameHints = \{(.*?)\} as const;',declared,re.S)[1]
source_codes=set(re.findall(r"'((?:REPORTED_CLASS|REPORTED_FRAME)_[A-Z_]+)'",classes+frames))
assert source_codes==m.REPORTED_HINTS and len(source_codes)==9
checks=[]
def check(code,fn,expected):
 try:fn();accepted=True
 except m.SchemaBlocked:accepted=False
 checks.append({'code':code,'passed':accepted==expected});assert accepted==expected,code
def d(cause,stage='UNKNOWN',status=0):return {'cause':cause,'stage':stage,'httpStatus':status}
for cause,stage in m.STAGES.items():
 status=401 if cause in m.HTTP_CAUSES else 0
 check('CORE_VALID_'+cause,lambda c=cause,s=stage,h=status:m.validate_diagnostics([d(c,s,h)],1),True)
for status in m.HTTP-{0}:check('CORE_HTTP_VALID_'+str(status),lambda h=status:m.validate_diagnostics([d('ACTOR_LOGIN_HTTP','ACTOR_LOGIN',h)],1),True)
for cause in sorted(m.REPORTED_HINTS):
 check('REPORTED_VALID_'+cause,lambda c=cause:m.validate_diagnostics([d(c)],1),True)
 check('REPORTED_WRONG_STAGE_'+cause,lambda c=cause:m.validate_diagnostics([d(c,'ACTOR_LOGIN')],1),False)
 for status in m.HTTP-{0}:check('REPORTED_NONZERO_'+cause+'_'+str(status),lambda c=cause,h=status:m.validate_diagnostics([d(c,status=h)],1),False)
for cause in ['REPORTED_CLASS_ASSERTION_ERROR','REPORTED_FRAME_PRIVATE_PATH','REPORTED_CLASS_ERROR_EXTRA','TYPE_ERROR','REPORTED_FRAME_DATASET_CALL\nPUBLIC']:
 check('UNKNOWN_EXACT_REJECTION_'+str(len(checks)),lambda c=cause:m.validate_diagnostics([d(c)],1),False)
good=d('REPORTED_CLASS_TYPE_ERROR')
for code,value in [('RAW_EXTRA',{**good,'message':'PUBLIC_CANARY'}),('BAD_STAGE_TYPE',{**good,'stage':None}),('BOOL_HTTP',{**good,'httpStatus':False}),('FLOAT_HTTP',{**good,'httpStatus':0.0}),('STRING_HTTP',{**good,'httpStatus':'0'}),('MISSING_KEY',{'cause':good['cause'],'stage':'UNKNOWN'})]:
 check(code,lambda v=value:m.validate_diagnostics([v],1),False)
check('SAME_DIAGNOSTIC_DUPLICATE',lambda:m.validate_diagnostics([good,good],1),False)
check('MULTIPLE_REPORTED_CLASSES',lambda:m.validate_diagnostics([d('REPORTED_CLASS_ERROR'),good],1),False)
check('MULTIPLE_REPORTED_FRAMES',lambda:m.validate_diagnostics([d('REPORTED_FRAME_DATASET_CALL'),d('REPORTED_FRAME_DATASET_DATE')],1),False)
eight=[d('UNKNOWN'),d('REPORTED_CLASS_TYPE_ERROR'),d('REPORTED_FRAME_DATASET_CALL')]+[d('ACTOR_LOGIN_HTTP','ACTOR_LOGIN',x) for x in [401,403,404,409,410]]
check('TOTAL_EIGHT_MIXED_VALID',lambda:m.validate_diagnostics(eight,1),True)
check('TOTAL_NINE_MIXED_REJECT',lambda:m.validate_diagnostics(eight+[d('ACTOR_LOGIN_HTTP','ACTOR_LOGIN',422)],1),False)
check('NO_ERROR_EMPTY_ALLOWED',lambda:m.validate_diagnostics([],0),True)
check('ERROR_EMPTY_REJECT',lambda:m.validate_diagnostics([],1),False)
check('DUPLICATE_JSON_KEYS',lambda:m.decode(b'{"cause":"UNKNOWN","cause":"REPORTED_CLASS_ERROR"}'),False)
check('NONFINITE_JSON',lambda:m.decode(b'{"durationMs":NaN}'),False)
base={'file':'mobile-real-server.spec.ts','line':14,'project':'chromium','status':'failed','expectedStatus':'passed','durationMs':1,'errorCount':1,'errorLocations':[]}
def report(row):return {'status':'failed','runnerErrors':0,'unsafeArtifact':False,'suppressedStdoutBytes':0,'suppressedStderrBytes':0,'results':[row]}
check('LEGACY_OPTIONAL_ABSENT',lambda:m.validate_results(report(base),{'mobile-real-server.spec.ts'}),True)
check('OPTIONAL_REPORTED_EXACT_ROW',lambda:m.validate_results(report({**base,'diagnostics':[good]}),{'mobile-real-server.spec.ts'}),True)
check('NO_NEW_RESULT_FIELDS',lambda:m.validate_results(report({**base,'diagnostics':[good],'reportedRawHint':'PUBLIC_CANARY'}),{'mobile-real-server.spec.ts'}),False)
binding={'state':'ROOT_ACTUAL_PUSH_AND_CURRENT_METADATA_VERIFIED','producer':'a'*40,'event':'pull_request','run_attempt':1,'runs':{'ci':1,'coverage':2,'security':3,'openapi':4},'schema_source_sha':'b'*40,'reporter_sha256':'c'*64,'privacy_sha256':'d'*64}
real_path=m.Path
class RamFile:
 def __truediv__(self,other):return self
 def exists(self):return True
 def read_bytes(self):return json.dumps(binding).encode()
m.Path=lambda value:RamFile()
check('UNBOUND_SCHEMA_FAILS_CLOSED',lambda:m.load_binding('PUBLIC_RAM_ONLY'),False)
original_constants=(m.SOURCE_HEAD,m.REPORTER_SHA,m.PRIVACY_SHA)
m.SOURCE_HEAD='b'*40;m.REPORTER_SHA='c'*64;m.PRIVACY_SHA='d'*64
check('SYNTHETIC_PINNED_BINDING_INTERFACE_VALID',lambda:m.load_binding('PUBLIC_RAM_ONLY'),True)
binding['event']='push';check('WRONG_EVENT_REJECT',lambda:m.load_binding('PUBLIC_RAM_ONLY'),False);binding['event']='pull_request'
binding['reporter_sha256']='e'*64;check('WRONG_REPORTER_PIN_REJECT',lambda:m.load_binding('PUBLIC_RAM_ONLY'),False);binding['reporter_sha256']='c'*64
binding['raw']='PUBLIC_CANARY';check('BINDING_EXTRA_FIELD_REJECT',lambda:m.load_binding('PUBLIC_RAM_ONLY'),False);del binding['raw']
m.SOURCE_HEAD,m.REPORTER_SHA,m.PRIVACY_SHA=original_constants;m.Path=real_path
assert all(c['passed'] for c in checks)
v={'state':'SOURCE_SCHEMA_CONTROLS_PASS_INDEPENDENT_REVIEW_REQUIRED','count':len(checks),'failed':0,'controls':checks,'core15_HTTP14_byte_values_unchanged':True,'reported9_exact_current_proposal_source':True,'reported_scope':'UNTRUSTED_METADATA_ONLY_UNKNOWN_HTTP0; never authenticated class/frame/cause/operation','source_binding':'UNBOUND_UNTIL_ROOT_REVIEW_FREEZE_ACTUAL_PUSH_AND_METADATA','Node_API_remote_artifact_product_runtime':'NOT_RUN','new_result_fields':False}
os.umask(0o077)
with (P/'schema-controls.safe.json').open('x') as f:json.dump(v,f,indent=2);f.write('\n')
print(json.dumps({'source_schema_controls':len(checks),'failed':0,'independent_review':'PENDING','remote_native':'NOT_RUN'}))
