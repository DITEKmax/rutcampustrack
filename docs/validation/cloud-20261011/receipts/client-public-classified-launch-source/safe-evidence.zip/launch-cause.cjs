'use strict';

// Public-only launch exception message stays in RAM. Nothing returns its contents.
function classify(message) {
  if (typeof message !== 'string') return 'OTHER';
  if (message.includes('Host system is missing dependencies to run browsers.') ||
      message.includes('Host system is missing dependencies!')) return 'MISSING_DEPS';
  if (message.includes("Executable doesn't exist at ") ||
      message.includes("Failed to launch chromium because executable doesn't exist at ")) return 'MISSING_EXECUTABLE';
  if (/Failed to launch: Error: spawn [^\r\n]+ EACCES\b/.test(message)) return 'EXEC_PERMISSION';
  if (message.includes('Chromium sandboxing failed!') ||
      /Failed to launch: Error: spawn [^\r\n]+ EPERM\b/.test(message)) return 'IPC_OR_SANDBOX_DENIED';
  if (message.includes('Failed to launch the browser process.\nBrowser logs:') ||
      /<process did exit: exitCode=(?:null|-?\d+), signal=(?:null|SIG[A-Z0-9]+)>/.test(message)) return 'NATIVE_PROCESS_EXIT';
  return 'OTHER';
}

function controls() {
  const cases = [
    ['Host system is missing dependencies to run browsers.', 'MISSING_DEPS'],
    ['Host system is missing dependencies!\nPublic synthetic details', 'MISSING_DEPS'],
    ["Executable doesn't exist at /public/synthetic/browser", 'MISSING_EXECUTABLE'],
    ["Failed to launch chromium because executable doesn't exist at /public/synthetic/browser", 'MISSING_EXECUTABLE'],
    ['Failed to launch: Error: spawn /public/synthetic/browser EACCES', 'EXEC_PERMISSION'],
    ['Chromium sandboxing failed!', 'IPC_OR_SANDBOX_DENIED'],
    ['Failed to launch: Error: spawn /public/synthetic/browser EPERM', 'IPC_OR_SANDBOX_DENIED'],
    ['Failed to launch the browser process.\nBrowser logs:\nPublic synthetic details', 'NATIVE_PROCESS_EXIT'],
    ['[pid=1] <process did exit: exitCode=1, signal=null>', 'NATIVE_PROCESS_EXIT'],
    ['[pid=1] <process did exit: exitCode=null, signal=SIGABRT>', 'NATIVE_PROCESS_EXIT'],
    ['Permission denied while writing public synthetic output', 'OTHER'],
    ['Target page, context or browser has been closed', 'OTHER'],
    ['Failed to launch: Error: spawn /public/synthetic/browser ENOENT', 'OTHER'],
    ['Public synthetic unrelated error', 'OTHER'],
    [undefined, 'OTHER'],
  ];
  const passedCount = cases.filter(([message, expected]) => classify(message) === expected).length;
  return { caseCount: cases.length, passedCount, failedCount: cases.length - passedCount, passed: passedCount === cases.length };
}

module.exports = { classify, controls };
