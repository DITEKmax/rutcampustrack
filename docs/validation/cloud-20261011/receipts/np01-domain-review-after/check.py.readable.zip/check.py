from pathlib import Path
import ast, hashlib, json
p=Path(__file__).resolve().parent
for entry in json.loads((p/'source-inventory.json').read_text()):
    frozen=(p/'private-frozen-source'/entry['path']).read_bytes()
    assert len(frozen)==entry['bytes'] and hashlib.sha256(frozen).hexdigest()==entry['sha256']
    if entry['path'].endswith('.py'):
        ast.parse(frozen.decode(), filename=entry['path'])
old=p.parent/'np01_domain_review'
m=old/'immutable-review-manifest.json'
assert hashlib.sha256(m.read_bytes()).hexdigest()=='42a2d450f6746ea21112518ed676250973ad1de2d98a05383f58e96d59cdc519'
for entry in json.loads(m.read_text())['safe_publishable_receipts']:
    data=(old/entry['path']).read_bytes()
    assert len(data)==entry['bytes'] and hashlib.sha256(data).hexdigest()==entry['sha256']
print('PASS: six exact frozen sources, Python syntax only, original14 safe receipts unchanged; runtime NOT_RUN')
