import datetime
import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time

ROOT = Path('/workspace/rct-worktrees/ci-academic-heap')
OUT = Path('/workspace/scratch/rct-validation/authored_format_current/java1')
PHASE = sys.argv[1]
ATTEMPT = sys.argv[2] if len(sys.argv) > 2 else PHASE
CGROUP = Path('/sys/fs/cgroup')
LIMIT = 536870912
FLOOR = 4294967296
RESERVE = 1073741824
os.umask(0o077)
OUT.mkdir(exist_ok=True)


def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def write(name, value):
    (OUT / name).write_text(json.dumps(value, indent=2) + '\n')


def allocation():
    total = 0
    roots = [ROOT / '.gradle', OUT, Path('/workspace/.gradle')]
    roots.extend(p for p in (ROOT / 'services').rglob('build') if p.is_dir())
    for root in roots:
        if not root.exists():
            continue
        for directory, _, names in os.walk(root):
            for name in names:
                try:
                    total += (Path(directory) / name).lstat().st_blocks * 512
                except FileNotFoundError:
                    pass
    return total


def metrics():
    vfs = os.statvfs(ROOT)
    return {'utc': now(), 'free_bytes': vfs.f_bavail * vfs.f_frsize,
            'memory_current': int((CGROUP / 'memory.current').read_text()),
            'memory_max': int((CGROUP / 'memory.max').read_text()),
            'cpu_max': (CGROUP / 'cpu.max').read_text().strip(),
            'allocation_bytes': allocation()}


def snapshot():
    paths = subprocess.check_output(['git', 'ls-files', '-z'], cwd=ROOT).decode().split('\0')
    rows = []
    for relative in filter(None, paths):
        p = ROOT / relative
        rows.append({'file': relative, 'sha256': hashlib.sha256(p.read_bytes()).hexdigest(),
                     'mode': p.stat().st_mode & 0o777})
    return rows


def process_records():
    records = {}
    for directory in Path('/proc').iterdir():
        if not directory.name.isdigit():
            continue
        try:
            fields = (directory / 'stat').read_text().split(') ', 1)[1].split()
            records[int(directory.name)] = {'ppid': int(fields[1]), 'pgid': int(fields[2]),
                                            'start': int(fields[19]), 'state': fields[0]}
        except (FileNotFoundError, ProcessLookupError, PermissionError):
            continue
    return records


def own_alive(owned):
    current_processes = process_records()
    return {pid: info for pid, info in current_processes.items()
            if pid in owned and info['start'] == owned[pid]['start'] and info['state'] != 'Z'}


if not (OUT / 'prelease.json').exists():
    pre = metrics()
    write('prelease.json', pre)
    write('launch-inputs.before.json', snapshot())
else:
    pre = json.loads((OUT / 'prelease.json').read_text())
current = metrics()
if current['free_bytes'] < FLOOR or current['memory_max'] - current['memory_current'] < RESERVE:
    raise SystemExit('Resource preflight floor/reserve blocked')
if current['allocation_bytes'] - pre['allocation_bytes'] > LIMIT:
    raise SystemExit('Resource preflight allocation cap blocked')

argv=['/workspace/rct-cloud-setup/jdk21/bin/java','-Xmx256m',str(OUT/'JavaMeaning.java'),str(OUT/'before-files'),str(ROOT),str(OUT/'java-targets.lines')]

environment = {'PATH': '/workspace/rct-cloud-setup/jdk21/bin:/usr/local/bin:/usr/bin:/bin',
               'JAVA_HOME': '/workspace/rct-cloud-setup/jdk21',
               'GRADLE_USER_HOME': '/workspace/.gradle',
               'HTTP_PROXY': 'http://proxy:8080', 'HTTPS_PROXY': 'http://proxy:8080',
               'SSL_CERT_FILE': '/etc/ssl/certs/ca-certificates.crt',
               'LANG': 'C.UTF-8', 'TMPDIR': str(OUT / 'tmp')}
(OUT / 'tmp').mkdir(exist_ok=True)
write(ATTEMPT + '-command.json', {'argv': argv, 'cwd': str(ROOT), 'env_keys': sorted(environment),
                               'source_sha': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip()})
raw_path = OUT / (ATTEMPT + '.raw.private.log')
with raw_path.open('xb') as raw:
    child = subprocess.Popen(argv, cwd=ROOT, env=environment, stdout=raw, stderr=subprocess.STDOUT,
                             start_new_session=True)
    write('CURRENT.json', {'phase': PHASE, 'utc': now(), 'status': 'RUNNING', 'pid': child.pid,
                           'pgid': child.pid, 'birth_ticks': process_records().get(child.pid,{}).get('start'), 'runner_pid':os.getpid(), 'raw_private_log': str(raw_path)})
    print(json.dumps({'phase': PHASE, 'status': 'RUNNING', 'pid': child.pid}), flush=True)
    peak = current
    started_at=time.monotonic()
    stopped = None
    owned = {}
    with (OUT / (ATTEMPT + '-metrics.ndjson')).open('x') as samples:
        while child.poll() is None:
            processes = process_records()
            parents = {child.pid} | set(owned)
            while True:
                found = {pid for pid, info in processes.items() if info['ppid'] in parents}
                if found <= parents:
                    break
                parents |= found
            owned.update({pid: processes[pid] for pid in parents if pid in processes})
            for pid, info in owned.items():
                try:
                    args = (Path('/proc') / str(pid) / 'cmdline').read_bytes().split(b'\0')
                    info['bounded_jvm_flags'] = [arg.decode() for arg in args
                        if arg.startswith(b'-Xmx') or arg.startswith(b'-XX:MaxMetaspaceSize=')]
                except (FileNotFoundError, ProcessLookupError, PermissionError):
                    pass
            write(ATTEMPT + '-own-processes.json', owned)
            m = metrics()
            samples.write(json.dumps(m) + '\n')
            samples.flush()
            for key in ['memory_current', 'allocation_bytes']:
                if m[key] > peak[key]:
                    peak[key] = m[key]
            if (time.monotonic()-started_at>600 or m['memory_current']>=16106127360 or m['free_bytes'] < FLOOR or m['memory_max'] - m['memory_current'] < RESERVE
                    or m['allocation_bytes'] - pre['allocation_bytes'] > LIMIT):
                stopped = 'RESOURCE_BOUND'
                os.killpg(child.pid, signal.SIGTERM)
                break
            time.sleep(3)
        if stopped:
            try:
                child.wait(timeout=15)
            except subprocess.TimeoutExpired:
                os.killpg(child.pid, signal.SIGKILL)
        result = child.wait()
    deadline = time.monotonic() + 20
    while own_alive(owned) and time.monotonic() < deadline:
        time.sleep(1)
    remaining = own_alive(owned)
    if remaining:
        for pid in remaining:
            try:
                os.kill(pid, signal.SIGTERM)
            except ProcessLookupError:
                pass
        deadline = time.monotonic() + 10
        while own_alive(owned) and time.monotonic() < deadline:
            time.sleep(1)
        for pid in own_alive(owned):
            try:
                os.kill(pid, signal.SIGKILL)
            except ProcessLookupError:
                pass
    remaining = own_alive(owned)
    after = metrics()
    outcome = {'phase': PHASE, 'utc': now(), 'native_exit': result, 'stopped': stopped,
               'peak': peak, 'after': after, 'raw_private_log': str(raw_path),
               'own_processes_remaining': remaining,
               'cleanup_qualification': 'Only descendants recorded with exact process start-time identities'}
    write(ATTEMPT + '-outcome.json', outcome)
    write('CURRENT.json', dict(outcome, status='TERMINAL', pid=child.pid))
    print(json.dumps({'phase': PHASE, 'native_exit': result, 'stopped': stopped,
                      'allocation_delta_bytes': after['allocation_bytes'] - pre['allocation_bytes'],
                      'free_bytes': after['free_bytes']}), flush=True)
    sys.exit(result if result else (1 if stopped else 0))
