import ast, datetime, hashlib, json, os, stat, types
from pathlib import Path

OWN=Path(__file__).parent
SOURCE=Path('/workspace/scratch/rct-validation/first3_dataset_call_source/checking-plan/native-plan/run-approved-node.py')
raw=SOURCE.read_bytes(); tree=ast.parse(raw)
selected=[node for node in tree.body if node.lineno >= 75]
code=compile(ast.Module(body=selected,type_ignores=[]),str(SOURCE),'exec')
class P:
    def __init__(self,name,state): self.name=name;self.state=state
    def __str__(self): return self.name
    def __truediv__(self,name): return P(self.name+'/'+name,self.state)
    def __eq__(self,other): return isinstance(other,P) and self.name==other.name
    @property
    def parent(self): return P(self.name.rsplit('/',1)[0],self.state)
    def resolve(self): return self
    def is_dir(self): return self.name != '/own/node_modules'
    def is_symlink(self): return self.name=='/own/node_modules' and self.state['exists']
    def stat(self): return types.SimpleNamespace(st_uid=1000,st_ino=10,st_mode=0o40700)
    def lstat(self): return types.SimpleNamespace(st_uid=1000,st_ino=20)
    def unlink(self,**kw):
        if self.name=='/own/node_modules': self.state['exists']=False;self.state['unlinks']+=1
class Clock:
    @staticmethod
    def now(zone): return datetime.datetime(2026,10,13,9,40,tzinfo=zone)

out=[]
for mode in ['NORMAL_NO_CHILD_FALLTHROUGH','DEADLINE_BEFORE_FIRST_CHILD','DEADLINE_AFTER_SETTLED_CHILD']:
    state={'exists':False,'unlinks':0,'observes':0,'settled_children':0}
    def observe():
        state['observes']+=1
        return 'ABSOLUTE_DEADLINE' if mode.startswith('DEADLINE') and state['observes']>= (2 if mode.endswith('FIRST_CHILD') else 3) else None
    def symlink(target,link,**kw): state['exists']=True
    def owned(*args,**kwargs):
        state['settled_children']+=1
        return {'phase_success':True,'native_exit':0,'settled':True,'all_owned_processes_reaped':True}
    class Receipt(P):
        def exists(self): return False
    def fake_atomic(path,value): pass
    phases=[] if mode.startswith('NORMAL') else [{'name':'format-check','argv':['PUBLIC_NODE'],'expectedNativeExit':0}]
    if mode.endswith('SETTLED_CHILD'): phases=phases*2
    env={'Path':lambda name:P(str(name),state),'plan':{'ownedDependencyLink':{'path':'/own/node_modules','target':'/cached/node_modules'},'explicitEnv':{},'commands':phases},
      'g':{'owned_dependency_link':{'path':'/own/node_modules','target':'/cached/node_modules'},'per_phase_seconds':180},
      'os':types.SimpleNamespace(geteuid=lambda:1000,getpid=lambda:100,symlink=symlink,readlink=lambda p:'/cached/node_modules',path=types.SimpleNamespace(lexists=lambda p:state['exists'])),
      'observe':observe,'datetime':types.SimpleNamespace(datetime=Clock),'UTC':datetime.timezone.utc,'stop':datetime.datetime(2026,10,13,9,50,tzinfo=datetime.timezone.utc),
      'guard':types.SimpleNamespace(process_table=lambda:{100:{'pid':100,'start_ticks':1}},run_owned=owned),
      'atomic':fake_atomic,'status':lambda value:None,'supervision':Receipt('/run/supervision',state),'run':Receipt('/run',state),'peaks':{},'json':json,'shlex':types.SimpleNamespace(join=lambda a:'PUBLIC_COMMAND',quote=lambda a:a),
      'shutil':types.SimpleNamespace(rmtree=lambda p:None),'stat':stat,'print':lambda *a,**k:None}
    # Preserve receipt path subtype through division; no actual path operations.
    Receipt.__truediv__=lambda self,name:Receipt(self.name+'/'+name,self.state)
    failure=None
    try: exec(code,env)
    except (AssertionError,SystemExit) as exc: failure=type(exc).__name__
    expected_left=mode.startswith('DEADLINE')
    assert state['exists'] is expected_left
    assert state['settled_children']==(1 if mode.endswith('SETTLED_CHILD') else 0)
    out.append({'code':mode,'exception_type':failure,'link_remaining':state['exists'],'unlink_count':state['unlinks'],'settled_owned_child_count':state['settled_children'],'actual_fs_or_child_effects':False})
receipt={'schema':'RCT_SELECTED_SOURCE_AST_COUNTEREXAMPLE_V1','source_sha256':hashlib.sha256(raw).hexdigest(),'selected_original_lines':[75,131],'controls':out,'counterexamples':2,'no_real_fs_link_or_native_execution':True}
(OWN/'counterexample.safe.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt))
