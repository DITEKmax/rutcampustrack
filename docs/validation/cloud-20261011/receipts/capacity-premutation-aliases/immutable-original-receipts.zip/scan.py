from pathlib import Path, PurePosixPath
import ast, collections, datetime, json, os, re, stat, subprocess

OUT=Path('/workspace/scratch/rct-validation/capacity_premutation_aliases')
PLAN=Path('/workspace/scratch/rct-validation/host_capacity_correction')
ROOT=Path('/workspace/rutcampustrack')
def git(path,*args):return subprocess.check_output(['git','--no-optional-locks','-C',str(path),*args]).decode()
source=(PLAN/'strict-source-plan.py').read_text();tree=ast.parse(source)
names={'EXCLUDED','PRIVATE','EXECUTABLE_OUTPUT_SUFFIXES'}
nodes=[n for n in tree.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id in names for t in n.targets)]
nodes += [n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='exclusion']
ns={'PurePosixPath':PurePosixPath,'re':re};exec(compile(ast.Module(body=nodes,type_ignores=[]),'strictmetadatafilter','exec'),ns);excluded=ns['exclusion']
worktrees=[]
for block in git(ROOT,'worktree','list','--porcelain').strip().split('\n\n'):
    fields=dict(line.split(' ',1) for line in block.splitlines() if ' ' in line)
    p=Path(fields['worktree'])
    assert p==ROOT or p.parent==Path('/workspace/rct-worktrees') or p==Path('/workspace/scratch/rct-validation/np01_domain_bot/fault-worktree')
    worktrees.append({'root':str(p),'scope':'root' if p==ROOT else p.name,'head_before':fields.get('HEAD'),'branch':fields.get('branch','DETACHED'),'authority':'registered same-repository task worktree; finer ownership from Root/history required'})
ledger=json.loads((PLAN/'reference-link-ledger-template.json').read_text())
groups={(g['device'],g['inode']):g for g in ledger['reference_inodes']};assert len(groups)==714
diagnosis=json.loads((PLAN/'strict-source-diagnosis.json').read_text());rows=[]
for scope in diagnosis['scopes']:rows+=json.loads((PLAN/(scope['scope']+'-strict-candidates.json')).read_text())
candidates={(r['candidate']['device'],r['candidate']['inode']):r for r in rows};assert len(candidates)==len(rows)==10831
refmatches=collections.defaultdict(list);cmatches=collections.defaultdict(list);lookups=0;excluded_count=0
def classify(scope,relative):
    active={'root':'Root shared-doc integrator/current source integration','np01-domain-bot':'active NP source writer','ci-academic-heap':'active formatter driver source writer'}
    if scope in active:return {'writer_status':'ACTIVE_SCOPE_EXACT_PATH_FENCE_REQUIRED','writer':active[scope],'whole_branch_freeze':False}
    if scope in {'client-format','client-runtime'}:return {'writer_status':'HISTORICAL_TASK_OWN_SCOPE_ROOT_PATH_CONFIRMATION_REQUIRED','writer':'prior source/runtime-prep author; no current writer assigned in restored registry','whole_branch_freeze':False}
    if scope=='fault-worktree':return {'writer_status':'PROTECTED_NP_FAULT_WORKTREE_ROOT_PATH_CONFIRMATION_REQUIRED','writer':'NP task-owned controlled fault resource','whole_branch_freeze':False}
    return {'writer_status':'COMPLETED_OWN_SCOPE_BOTH_PATH_FREEZE_PENDING','writer':'Root task-owned completed author/resource','whole_branch_freeze':False}
for wt in worktrees:
    root=Path(wt['root']);listed=git(root,'ls-files','-z').split('\0');matched=0
    for rel in listed:
        if not rel:continue
        if excluded(rel) is not None:excluded_count+=1;continue
        parts=PurePosixPath(rel).parts
        assert not rel.startswith('/') and '..' not in parts and '\\' not in rel
        path=root/rel
        try:s=path.lstat()
        except FileNotFoundError:continue
        lookups+=1
        if not stat.S_ISREG(s.st_mode):continue
        key=(s.st_dev,s.st_ino)
        if key not in groups and key not in candidates:continue
        assert not any(p.is_symlink() for p in (path,*path.parents))
        record={'path':str(path),'relative_path':rel,'root':str(root),'scope':wt['scope'],'branch':wt['branch'],'head_at_listing':wt['head_before'],'device':s.st_dev,'inode':s.st_ino,'nlink':s.st_nlink,'bytes':s.st_size,'allocated_bytes':s.st_blocks*512,'mode':oct(stat.S_IMODE(s.st_mode)),'uid':s.st_uid,'gid':s.st_gid,'mtime_ns':s.st_mtime_ns,'ctime_ns':s.st_ctime_ns,**classify(wt['scope'],rel),'freeze_status':'PENDING_EXPLICIT_ROOT_PATH_FREEZE','future_policy':'no inplace edits/build/formatter/chmod; atomic COW before any future change'}
        if key in groups:refmatches[key].append(record)
        if key in candidates:cmatches[key].append(record)
        matched+=1
    wt['eligible_metadata_lookups']=lookups;wt['target_aliases_found']=matched;wt['head_after']=git(root,'rev-parse','HEAD').strip()
    wt['tracked_status_count']=len(git(root,'status','--porcelain','--untracked-files=no').splitlines())
    (OUT/'CURRENT.json').write_text(json.dumps({'state':'METADATA_ALIAS_SCAN','completed_root':str(root),'completed_roots':worktrees.index(wt)+1,'total_roots':len(worktrees),'metadata_lookups':lookups,'no_contents_read':True,'next':'remaining known roots then countlink/freeze scope'},indent=2)+'\n')
    (OUT/'attempts.ndjson').open('a').write(json.dumps({'time':datetime.datetime.now(datetime.timezone.utc).isoformat(),'root_completed':str(root),'target_aliases':matched,'heads_may_advance_in_active_Root':wt['head_before']!=wt['head_after'],'resource_mutations':False})+'\n')
unknown=[];reference_results=[]
for key,g in groups.items():
    found=refmatches[key];expected=g['baseline_nlink']
    for item in found:
        p=Path(item['path']);s=p.lstat()
        assert (s.st_dev,s.st_ino,s.st_nlink,s.st_size,s.st_mtime_ns,s.st_ctime_ns)==(item['device'],item['inode'],item['nlink'],item['bytes'],item['mtime_ns'],item['ctime_ns'])
        assert s.st_nlink==expected and s.st_mtime_ns==g['baseline_mtime_ns'] and s.st_ctime_ns==g['baseline_ctime_ns'] and item['mode']==g['mode']
    aliases={item['path'] for item in found};status='ALL_DECLARED_LINKS_ACCOUNTED' if len(aliases)==expected else 'PAUSE_UNACCOUNTED_OR_FOREIGN_ALIASES'
    result={'device':key[0],'inode':key[1],'baseline_nlink':expected,'known_alias_count':len(aliases),'unaccounted_links':expected-len(aliases),'status':status,'reference_sha256_prior_verified':g['sha256'],'candidate_count':g['candidate_count'],'reference_paths':g['reference_paths'],'aliases':found,'freeze_status':'PENDING_ROOT_EXACT_ALLALIAS_FREEZE'}
    reference_results.append(result)
    if status!='ALL_DECLARED_LINKS_ACCOUNTED':unknown.append(key)
for key,r in candidates.items():
    found=cmatches[key];assert len(found)==1 and found[0]['path']==r['candidate']['path'] and found[0]['nlink']==1
    s=Path(found[0]['path']).lstat();item=r['candidate'];assert (s.st_dev,s.st_ino,s.st_nlink,s.st_size,s.st_blocks*512,stat.S_IMODE(s.st_mode),s.st_uid,s.st_gid,s.st_mtime_ns,s.st_ctime_ns)==(item['device'],item['inode'],item['nlink'],item['bytes'],item['allocated_bytes'],int(item['mode'],8),item['uid'],item['gid'],item['mtime_ns'],item['ctime_ns'])
safe=[r for r in rows if (r['reference']['device'],r['reference']['inode']) not in unknown]
single=[r for r in rows if groups[(r['reference']['device'],r['reference']['inode'])]['baseline_nlink']==1]
shared=[r for r in rows if groups[(r['reference']['device'],r['reference']['inode'])]['baseline_nlink']>1]
freeze_records=[item for aliases in refmatches.values() for item in aliases]+[item for aliases in cmatches.values() for item in aliases]
(OUT/'reference-aliases.json').write_text(json.dumps(reference_results,indent=2)+'\n')
(OUT/'proposed-path-freeze-COW-registry.json').write_text(json.dumps({'status':'PROPOSED_NOT_ACTUAL_FREEZE','metadata_only':True,'no_mutation_permission':True,'paths':freeze_records,'serialized_reference_link_ledger':'baseline+verifiedsuccesslinks+pendingexactownlinks, no unknown changes','protected_active_writer_paths_are_exact_fences':'Root/docs source work continues outside these exactpaths; never wholebranch freeze'},indent=2)+'\n')
summary={'time':datetime.datetime.now(datetime.timezone.utc).isoformat(),'known_worktrees_scanned':len(worktrees),'metadata_lstat_lookups':lookups,'protected_paths_filtered_before_metadata':excluded_count,'reference_groups':len(groups),'reference_aliases_accounted':sum(len(x) for x in refmatches.values()),'nlink20_groups':sum(g['baseline_nlink']==20 for g in groups.values()),'nlink1_groups':sum(g['baseline_nlink']==1 for g in groups.values()),'unknown_reference_groups':len(unknown),'candidate_nlink1_aliases_accounted':len(cmatches),'safe_accounted_candidate_rows':len(safe),'safe_accounted_candidate_potential_bytes':sum(r['candidate']['allocated_bytes'] for r in safe),'nlink1_reference_only_candidate_rows':len(single),'nlink1_reference_only_potential_bytes':sum(r['candidate']['allocated_bytes'] for r in single),'shared_reference_candidate_rows':len(shared),'shared_reference_potential_bytes':sum(r['candidate']['allocated_bytes'] for r in shared),'proposed_frozen_paths':len(freeze_records),'actual_freeze':'NOT_SET_BY_REVIEWER','actual_recovery_bytes':0,'resource_mutations':False,'file_contents_read':'ONLY safe plan/registry JSON and Git metadata; no candidate/alias bodies','processes_after_exit':[]}
(OUT/'SUMMARY.json').write_text(json.dumps(summary,indent=2)+'\n');(OUT/'worktrees.json').write_text(json.dumps(worktrees,indent=2)+'\n');print(json.dumps(summary))
