import { lstatSync } from 'node:fs';
import { join } from 'node:path';
import { defineConfig } from '/workspace/rutcampustrack/tests/e2e/node_modules/@playwright/test';
import existing from '/workspace/rutcampustrack/tests/e2e/playwright.real-mobile.config';
import { readTeachingInstant } from '/workspace/rutcampustrack/tests/e2e/fixtures/teaching-clock';

// Explicit opt-in lane for the two unchanged real-server session/offline cases.
process.env.PLAYWRIGHT_NO_COPY_PROMPT = '1';

const runRoot = '/workspace/scratch/rct-validation/client_session_offline_acceptance';
const run = process.env.RCT_SESSION_OFFLINE_RUN;
if (!run || !new RegExp(`^${runRoot}/runs/attempt-[0-9]{2}$`).test(run)) {
  throw new Error('Session/offline acceptance requires its private run namespace');
}
for (const path of [run, join(run, 'artifacts'), join(run, 'supervision')]) {
  const info = lstatSync(path);
  if (!info.isDirectory() || info.isSymbolicLink() || (info.mode & 0o777) !== 0o700) {
    throw new Error('Session/offline artifact directories must be precreated and private');
  }
}
const teachingInstant = readTeachingInstant(
  '/workspace/scratch/rct-validation/current_host_config_v4/teaching-clock',
);

export default defineConfig<{}, { teachingInstant: Date | undefined }>({
  ...existing,
  testDir: '/workspace/rct-worktrees/client-session-offline/tests/e2e/session-offline-specs',
  testMatch: 'mobile-session-offline.spec.ts',
  testIgnore: [],
  grep: /(?:another live session revokes the browser session and recovery exposes login only|warm offline reload remains read-only; revoked session reconnect clears the cached user)$/,
  outputDir: join(run, 'artifacts'),
  reporter: [['/workspace/rutcampustrack/tests/e2e/fixtures/safe-reporter.ts']],
  fullyParallel: false,
  workers: 1,
  retries: 0,
  forbidOnly: true,
  use: {
    ...existing.use,
    trace: 'off',
    video: 'off',
    screenshot: 'off',
    viewport: { width: 390, height: 844 },
    timezoneId: 'Europe/Moscow',
    teachingInstant,
  },
  projects: existing.projects
    ?.filter((project) => project.name === 'chromium')
    .map((project) => ({
      ...project,
      use: {
        ...project.use,
        trace: 'off',
        video: 'off',
        screenshot: 'off',
        viewport: { width: 390, height: 844 },
        timezoneId: 'Europe/Moscow',
        teachingInstant,
      },
    })),
});
