from pathlib import Path
import datetime,hashlib,json,os,shlex,shutil,stat,sys,types
BASE=Path('/workspace/scratch/rct-validation/first3_dataset_call_source/checking-plan-link-lifecycle-r1')
NATIVE=BASE/'native-plan';GRANT=Path(sys.argv[1])
g=json.loads(GRANT.read_text());plan=json.loads((NATIVE/'PLAN.safe.json').read_text())
assert g['authorized_by_root'] is True and g['scope']==plan['scope'] and g['allow_format_write'] is True
assert GRANT.parent==BASE/'private' and stat.S_IMODE(GRANT.stat().st_mode)==0o600
assert hashlib.sha256((NATIVE/'PLAN.safe.json').read_bytes()).hexdigest()==g['native_plan_sha256']
run=Path(g['scope_new_own_run']);supervision=run/'supervision';UTC=datetime.timezone.utc;stop=datetime.datetime.fromisoformat(g['stop_utc'])
assert run==Path(plan['scope_new_own_run'])
assert (g['per_phase_seconds'],g['workspace_floor'],g['shared_stop'],g['shared_reserve'],g['owned_RSS_cap'],g['own_tmp_cache_cap'])==(plan['budget']['perPhaseSeconds'],4*1024**3,15*1024**3,1024**3,1024**3,32*1024**2)
assert 0<(stop-datetime.datetime.fromisoformat(g['not_before_utc'])).total_seconds()<=plan['budget']['totalActiveSeconds']
grant={'disk_floor_bytes':g['workspace_floor'],'shared_stop_bytes':g['shared_stop'],'shared_memory_reserve_bytes':g['shared_reserve'],'owned_total_rss_stop_bytes':g['owned_RSS_cap'],'cache_stop_bytes':g['own_tmp_cache_cap']}
GUARD=Path('/workspace/scratch/rct-validation/guard_proc_race_correction/bounded-child.py')
assert hashlib.sha256(GUARD.read_bytes()).hexdigest()==g['guard_sha256']
guard=types.ModuleType('reviewed_owned_guard');guard.__file__=str(GUARD);exec(compile(GUARD.read_bytes(),str(GUARD),'exec'),guard.__dict__)
def atomic(path,value):
 temporary=path.with_suffix(path.suffix+'.next');temporary.write_text(json.dumps(value,indent=2)+'\n');temporary.chmod(0o600);temporary.replace(path)
latest={};active_phase='dataset-red';peaks={'owned_rss_bytes':0,'run_allocated_bytes':0,'shared_memory_bytes':0}
def status(value):
    child = guard.process_table().get(value['child_pid'])
    if child is not None:
        value = {**value, 'direct_birth': child['start_ticks']}
    latest.clear()
    latest.update(value)
    atomic(supervision / (active_phase + '-process.safe.json'), value)

def observe():
    if datetime.datetime.now(UTC) >= stop:
        return 'ABSOLUTE_DEADLINE'
    for filesystem in ['/workspace', '/tmp']:
        value = os.statvfs(filesystem)
        if value.f_bavail * value.f_frsize < grant['disk_floor_bytes']:
            return 'DISK_FLOOR'
    used = int(Path('/sys/fs/cgroup/memory.current').read_text())
    limit = int(Path('/sys/fs/cgroup/memory.max').read_text())
    peaks['shared_memory_bytes'] = max(peaks['shared_memory_bytes'], used)
    if used >= grant['shared_stop_bytes'] or limit - used < grant['shared_memory_reserve_bytes']:
        return 'SHARED_MEMORY_STOP'
    table = guard.process_table()
    rss = next((int(line.split()[1]) * 1024 for line in Path('/proc/self/status').read_text().splitlines()
                if line.startswith('VmRSS:')), 0)
    for row in latest.get('members_including_Z', []):
        current = table.get(row['pid'])
        if current is None or current['start_ticks'] != row['start_ticks']:
            continue
        try:
            lines = Path('/proc', str(row['pid']), 'status').read_text().splitlines()
        except FileNotFoundError:
            continue
        rss += next((int(line.split()[1]) * 1024 for line in lines if line.startswith('VmRSS:')), 0)
    peaks['owned_rss_bytes'] = max(peaks['owned_rss_bytes'], rss)
    if rss > grant['owned_total_rss_stop_bytes']:
        return 'OWN_TOTAL_RSS_STOP'
    allocated = sum(path.lstat().st_blocks * 512 for path in run.rglob('*')
                    if path.is_file() and not path.is_symlink())
    peaks['run_allocated_bytes'] = max(peaks['run_allocated_bytes'], allocated)
    return 'OWN_CACHE_STOP' if allocated > grant['cache_stop_bytes'] else None



for filename,digest in plan['immutablePins'].items():
 assert hashlib.sha256(Path(filename).read_bytes()).hexdigest()==digest
for filename,digest in plan['mutableOnlyAfterExplicitFormatGrant'].items():
 path=Path(filename);assert not path.is_symlink() and path.stat().st_nlink==1 and hashlib.sha256(path.read_bytes()).hexdigest()==digest
assert set(g['format_write_scope'])==set(plan['mutableOnlyAfterExplicitFormatGrant'])
assert os.access(plan['commands'][0]['argv'][0],os.X_OK)
# Existing resources first, clock LAST before the first own directory allocation.
for filesystem in ['/workspace','/tmp']:
 value=os.statvfs(filesystem);assert value.f_bavail*value.f_frsize>=g['workspace_floor']
used=int(Path('/sys/fs/cgroup/memory.current').read_text());limit=int(Path('/sys/fs/cgroup/memory.max').read_text());assert used<g['shared_stop'] and limit-used>=g['shared_reserve']
now=datetime.datetime.now(UTC);assert datetime.datetime.fromisoformat(g['not_before_utc'])<=now<stop
os.umask(0o077);run.mkdir(mode=0o700)
for name in ['supervision','private-tmp','transform-cache','worker-artifacts']:(run/name).mkdir(mode=0o700)
def run_checked_phases():
 global active_phase
 results=[];active_owned_call=False;link_inode=None;link_parent_inode=None
 dependency_link_removed=False;primary_error=None;cleanup_error=None;temporary_artifacts_removed=False
 link=Path(plan['ownedDependencyLink']['path']);target=Path(plan['ownedDependencyLink']['target'])
 try:
  assert g['owned_dependency_link']==plan['ownedDependencyLink']
  assert link.parent.is_dir() and not link.parent.is_symlink() and link.parent.stat().st_uid==os.geteuid()
  assert target.is_dir() and not target.is_symlink() and target.stat().st_uid==os.geteuid()
  assert link.parent.resolve()==link.parent and target.resolve()==target
  link_parent_inode=link.parent.stat().st_ino
  assert not os.path.lexists(link)
  assert observe() is None
  assert datetime.datetime.now(UTC)<stop
  os.symlink(target,link,target_is_directory=True)
  link_inode=link.lstat().st_ino
  assert link.is_symlink() and link.lstat().st_uid==os.geteuid() and os.readlink(link)==str(target)
  s=guard.process_table()[os.getpid()];atomic(supervision/'supervisor.safe.json',s);print(json.dumps({'stage':'FIRST3_DATASET_CHECKING_STARTED','pid':s['pid'],'birth':s['start_ticks']}),flush=True)
  env=plan['explicitEnv'].copy();env.update(TMPDIR=str(run/'private-tmp'),TMP=str(run/'private-tmp'),TEMP=str(run/'private-tmp'),PWTEST_CACHE_DIR=str(run/'transform-cache'),RCT_FOCUS3_TYPES_OUTPUT=str(supervision/'types.safe.json'),RCT_FOCUS3_RUN=str(run),RCT_FOCUS3_OBSERVATIONS=str(supervision/'observations.safe.json'),RCT_SAFE_FAILURE_CONTROL_OUTPUT=str(run/'worker-artifacts'))
  for phase in plan['commands']:
   active_phase=phase['name'];assert observe() is None
   phaseEnv=env.copy();receipt=supervision/(active_phase+'.safe.json');phaseEnv['RCT_SAFE_DIAGNOSTIC_RECEIPT']=str(receipt)
   if active_phase=='privacy':phaseEnv['RCT_E2E_CONTROL_RECEIPT_PATH']=str(receipt)
   argv=phase['argv'];actual=argv;diagnostic=run/'private-tmp/formatter-public-source.private.log'
   if active_phase in ['format-write','format-check']:actual=['/usr/bin/bash','-c','exec '+shlex.join(argv)+' >'+shlex.quote(str(diagnostic))+' 2>&1']
   seconds=min(g['per_phase_seconds'],int((stop-datetime.datetime.now(UTC)).total_seconds()));assert seconds>0
   atomic(supervision/(active_phase+'-launch.safe.json'),{'phase':active_phase,'argv':argv,'deadlineSeconds':seconds,'expectedNativeExit':phase['expectedNativeExit']})
   active_owned_call=True
   result=guard.run_owned(actual,'/workspace/rct-worktrees/first3-dataset-correction-20261013/tests/e2e',phaseEnv,deadline_seconds=seconds,observe=observe,status=status)
   results.append(result)
   active_owned_call=False
   row=json.loads(receipt.read_text()) if receipt.exists() else {};accepted=result['phase_success']
   if active_phase=='dataset-red':
    accepted=result['native_exit']==1 and result['settled'] and result['all_owned_processes_reaped'] and result.get('supervision_error_type') is None and result.get('signal_count')==0 and result.get('terminal_reason')=='NATIVE_TERMINAL'
    expected={'BYTE_0_CANONICAL_VALID','BYTE_100_CANONICAL_VALID','BYTE_200_CANONICAL_VALID','GROUP400_CLOSED_DIAGNOSTIC'}
    controls=row.get('controls',[])
    accepted=accepted and row.get('pass') is False and row.get('expectedCausalRed') is True and row.get('count')==6 and row.get('failed')==4 and row.get('parserDiagnosticCount')==0 and len(controls)==6 and {item.get('code') for item in controls if item.get('passed') is False}==expected and all(item.get('passed') is True for item in controls if item.get('code') in {'ACTUAL_FAILURE_RETAINED','PRIVATE_MARKER_ABSENT'})
   elif active_phase=='dataset-green':
    accepted=accepted and row.get('pass') is True and row.get('count')==40 and row.get('failed')==0 and row.get('parserDiagnosticCount')==0 and row.get('reportedContextOnly') is True and row.get('noBrowserApi') is True and len(row.get('controls',[]))==40 and all(item.get('passed') is True for item in row.get('controls',[]))
    required={'ALL256_CURRENT_CODES_CANONICAL_VALID','ALL90_ACCEPTED_CODES_PRESERVED','NO_GETTER_PROTOTYPE_OR_CONVERSION_READ','NEW_CORE_EVICTS_ONLY_REPORTED_SLOT','EIGHT_ORIGINAL_CORE_FACTS_PRESERVED','FIRST32_ANNOTATIONS_ONLY','EXPECTED_HTTP_NOT_WEAKENED','FORGED_MARKER_REPORTS_NO_ADMISSION_OR_SUCCESS','THREE_DIAGNOSTIC_FIELDS_ONLY'}
    accepted=accepted and required.issubset({item.get('code') for item in row.get('controls',[])})
   elif active_phase=='worker':
    accepted=accepted and row.get('pass') is True and row.get('childNativeExit')==0 and row.get('caseCount')==1 and all(row.get(k) is True for k in ['markerAbsent','bodiesNotStarted','closedDataset400','failedTestRetained','reportedContextOnly','noBrowserApi'])
   elif active_phase=='privacy':accepted=accepted and row.get('state')=='PRIVACY_BOUNDARIES_PASSED' and all(row.get(k) is True for k in ['markerAbsent','expectedFailureRetained','interruptionPassed','missingGuardRejectedBeforeOperation'])
   elif active_phase=='types':accepted=accepted and row.get('pass') is True and row.get('error_count')==0
   elif active_phase in ['format-write','format-check']:
    text=diagnostic.read_text() if diagnostic.exists() else '';row={'publicDiagnosticBytes':len(text.encode()),'styleDifference':'Code style issues found' in text,'parserError':'[error]' in text};diagnostic.unlink(missing_ok=True)
    if active_phase=='format-write':row['afterSourceHashes']={name:hashlib.sha256(Path(name).read_bytes()).hexdigest() for name in plan['mutableOnlyAfterExplicitFormatGrant']}
   facts={'phase':active_phase,'nativeExit':result['native_exit'],'accepted':accepted,'expectedNativeExit':phase['expectedNativeExit']};atomic(supervision/(active_phase+'-outcome.safe.json'),facts)
   result.update(phase=active_phase,accepted=accepted,peaks=peaks.copy());atomic(supervision/(active_phase+'-terminal.safe.json'),result);print(json.dumps(facts),flush=True)
   if active_phase=='format-write':atomic(supervision/'formatted-source.safe.json',row)
   if not accepted:break
 except BaseException as error:
  primary_error=error
 finally:
  settled=not active_owned_call and all(isinstance(value,dict) and value.get('settled') is True and value.get('all_owned_processes_reaped') is True for value in results)
  try:
   if settled and link_inode is not None and link_parent_inode is not None:
    assert link.parent.resolve()==link.parent and link.parent.stat().st_ino==link_parent_inode
    assert link.is_symlink() and link.lstat().st_uid==os.geteuid() and link.lstat().st_ino==link_inode and os.readlink(link)==str(target)
    link.unlink();dependency_link_removed=True
   if settled:
    for name in ['private-tmp','transform-cache','worker-artifacts']:
     path=run/name;assert not path.is_symlink() and path.stat().st_uid==os.geteuid() and stat.S_IMODE(path.stat().st_mode)==0o700;shutil.rmtree(path)
    temporary_artifacts_removed=True
  except BaseException as error:
   cleanup_error=error
  passed=primary_error is None and cleanup_error is None and settled and dependency_link_removed and len(results)==len(plan['commands']) and all(isinstance(value,dict) and value.get('accepted') is True for value in results)
  try:
   atomic(supervision/'OUTCOME.safe.json',{'pass':passed,'settled':settled,'completedPhases':len(results),'peaks':peaks,'ownedTempArtifactsRemoved':temporary_artifacts_removed,'nativeClientAcceptance':False,'actualCIcause':'UNKNOWN','sampledSoftMonitoring':True,'ownedDependencyLinkRemoved':dependency_link_removed,'ownedLinkIdentityRecorded':link_inode is not None,'activeOwnedCallUnknown':active_owned_call,'primaryExceptionRetained':primary_error is not None,'cleanupExceptionRetained':cleanup_error is not None})
   print(json.dumps({'stage':'FIRST3_DATASET_CHECKING_TERMINAL','pass':passed,'settled':settled}),flush=True)
  except BaseException as error:
   if primary_error is None:
    primary_error=error
   else:
    primary_error.add_note('FIRST3_CLOSED_OUTCOME_WRITE_FAILED')
 if primary_error is not None:
  if cleanup_error is not None:
   primary_error.add_note('FIRST3_OWN_LINK_CLEANUP_BLOCKED')
  raise primary_error
 if cleanup_error is not None:
  raise cleanup_error
 return 0 if passed and settled and dependency_link_removed else 1

try:
 exit_code=run_checked_phases()
except BaseException:
 print(json.dumps({'stage':'FIRST3_DATASET_CHECKING_BLOCKED','pass':False,'actualCIcause':'UNKNOWN','rawErrorSuppressed':True}),flush=True)
 exit_code=1
raise SystemExit(exit_code)
