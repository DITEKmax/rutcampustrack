import datetime
import hashlib
import json
import os
from pathlib import Path
import re
import stat
import subprocess

OUT = Path(__file__).parent
BASE = Path('/workspace/rct-worktrees')
REFERENCE = BASE / 'client-acceptance'
SCOPES = ['client-current-artifacts', 'np01-config', 'np01-contract', 'security-fingerprint',
          'delivery', 'file-boundaries', 'gateway-claims', 'recovery', 'renderer-files', 'auth-generator', 'ci-evidence']
DENY = re.compile(r'(^|/)(\.env[^/]*|\.npmrc|\.aws|\.codex|secrets?|certs?|certificates?|keys?)(/|$)|\.(pem|key|p12|pfx|jks|keystore)$', re.I)
hashes = {}

def digest(path, s):
    identity = (s.st_dev, s.st_ino, s.st_size, s.st_mtime_ns)
    if identity not in hashes:
        h = hashlib.sha256()
        with path.open('rb') as stream:
            for data in iter(lambda: stream.read(1024 * 1024), b''):
                h.update(data)
        assert path.stat().st_mtime_ns == s.st_mtime_ns
        hashes[identity] = h.hexdigest()
    return hashes[identity]

def meta(path, s):
    return {'path': str(path), 'device': s.st_dev, 'inode': s.st_ino, 'nlink': s.st_nlink,
            'bytes': s.st_size, 'allocated_bytes': s.st_blocks * 512, 'mode': oct(stat.S_IMODE(s.st_mode)),
            'uid': s.st_uid, 'gid': s.st_gid, 'mtime_ns': s.st_mtime_ns, 'sha256': digest(path, s)}

summary = []
all_rows = []
for name in SCOPES:
    scope = BASE / name
    paths = subprocess.check_output(['git', 'ls-files', '-z'], cwd=scope).decode().split('\0')
    rows = []
    excluded_shared = 0
    for rel in paths:
        if not rel or DENY.search(rel) or rel.startswith('docs/validation/'):
            continue
        candidate = scope / rel
        reference = REFERENCE / rel
        try:
            a, b = candidate.lstat(), reference.lstat()
        except FileNotFoundError:
            continue
        if not stat.S_ISREG(a.st_mode) or not stat.S_ISREG(b.st_mode) or a.st_size < 65536:
            continue
        if a.st_dev != b.st_dev or a.st_size != b.st_size or stat.S_IMODE(a.st_mode) != stat.S_IMODE(b.st_mode):
            continue
        if a.st_ino == b.st_ino:
            excluded_shared += 1
            continue
        if digest(candidate, a) != digest(reference, b):
            continue
        rows.append({'candidate': meta(candidate, a), 'reference': meta(reference, b), 'relative_path': rel,
                     'kind': 'frozen tracked source', 'scope': name})
    # nlink=1 makes each replacement's physical reclamation precise; shared candidates separately reported.
    counted = { (r['candidate']['device'], r['candidate']['inode']): r['candidate']['allocated_bytes']
                for r in rows if r['candidate']['nlink'] == 1 }
    summary.append({'scope': name, 'head': subprocess.check_output(['git','rev-parse','HEAD'],cwd=scope).decode().strip(),
                    'matches': len(rows), 'nlink1_candidates': len(counted), 'countable_allocated_bytes': sum(counted.values()),
                    'already_same_inode_count': excluded_shared,
                    'status': subprocess.check_output(['git','status','--porcelain','--untracked-files=no'],cwd=scope).decode().splitlines()})
    all_rows.extend(rows)
    (OUT / (name + '-candidates.json')).write_text(json.dumps(rows,indent=2)+'\n')
all_counted = {(r['candidate']['device'],r['candidate']['inode']): r['candidate']['allocated_bytes'] for r in all_rows if r['candidate']['nlink']==1}
result = {'time': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'source_only': True,
          'scopes':summary,'combined_unique_countable_allocated_bytes':sum(all_counted.values()),
          'combined_unique_countable_inodes':len(all_counted),'protected_active_scope':'np01-domain-bot',
          'excluded_pending_heavy_scope':'ci-academic-heap (root announced forthcoming GRAPH_COMPILE_ONLY lease)',
          'excluded_secret_paths_regex':DENY.pattern,'minimum_file_bytes':65536,
          'shared_candidates_counted':False,'resource_mutations':False}
(OUT/'source-diagnosis.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
