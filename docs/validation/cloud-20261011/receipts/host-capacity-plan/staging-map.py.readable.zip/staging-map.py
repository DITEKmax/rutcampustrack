import hashlib
import json
from pathlib import Path, PurePosixPath
import re
import zipfile

OUT = Path(__file__).parent
INPUT = Path('/workspace/scratch/rct-validation/current_client_artifacts')
producer = json.loads((INPUT/'eight-production-jars.json').read_text())
layers_order = ['dependencies', 'spring-boot-loader', 'snapshot-dependencies', 'application']
distinct = set()
staged_distinct = set()
services = []
for jar in producer['jars']:
    path = Path(jar['jar'])
    assert hashlib.file_digest(path.open('rb'),'sha256').hexdigest() == jar['sha256']
    rows = []
    with zipfile.ZipFile(path) as archive:
        index = archive.read('BOOT-INF/layers.idx').decode()
        patterns = {}
        layer = None
        for line in index.splitlines():
            if line.startswith('- '):
                layer = json.loads(line[2:].removesuffix(':'))
                patterns[layer] = []
            elif line.startswith('  - '):
                patterns[layer].append(json.loads(line[4:]))
            elif line.strip():
                raise AssertionError('Unknown layers index syntax')
        assert list(patterns) == layers_order
        names = set()
        for member in archive.infolist():
            name = member.filename
            assert name not in names
            names.add(name)
            parts = PurePosixPath(name).parts
            assert not name.startswith('/') and '..' not in parts and '\\' not in name
            filetype = (member.external_attr >> 16) & 0o170000
            assert filetype in (0,0o100000,0o040000)
            if member.is_dir():
                continue
            matched = [l for l, ps in patterns.items() if any(name == p or (p.endswith('/') and name.startswith(p)) for p in ps)]
            assert len(matched) == 1, (jar['service'],name,matched)
            mode = ((member.external_attr >> 16) & 0o777) or 0o644
            staged_mode = 0o644 | (mode & 0o111)
            with archive.open(member) as stream:
                sha = hashlib.file_digest(stream,'sha256').hexdigest()
            identity = (sha,mode,member.file_size)
            distinct.add(identity)
            staged_distinct.add((sha,staged_mode,member.file_size))
            rows.append({'path':name,'layer':matched[0],'bytes':member.file_size,'sha256':sha,
                         'zip_mode':oct(mode),'proposed_NEW_public_payload_mode':oct(staged_mode)})
        required = ['META-INF/MANIFEST.MF','org/springframework/boot/loader/launch/JarLauncher.class',
                    'BOOT-INF/layers.idx','BOOT-INF/classpath.idx',
                    'BOOT-INF/classes/' + jar['unfolded_manifest']['Start-Class'].replace('.','/') + '.class']
        assert all(n in names for n in required)
    assert hashlib.file_digest(path.open('rb'),'sha256').hexdigest() == jar['sha256']
    record = {'service':jar['service'],'producer':producer['revision'],'jar':str(path),'jar_sha256':jar['sha256'],
              'jar_source_mode':jar['mode'],'unfolded_manifest':jar['unfolded_manifest'],'ordered_layers':layers_order,
              'fixture_proof':'retained eight-production-jars.json recursive nested fixture absence',
              'directories_proposed_mode':'0o755',
              'files_public_readable_mode':'NEW public compiled payload only:0644 plus original execute bits; existing artifacts untouched',
              'entries':rows,'actual_staging':'NOT_RUN','actual_allocated_bytes':'UNKNOWN'}
    (OUT / ('stage-' + jar['service'] + '.json')).write_text(json.dumps(record,indent=2)+'\n')
    services.append({'service':jar['service'],'regular_entries':len(rows),'source_jar_sha256':jar['sha256']})
summary = {'status':'READ_ONLY_ZIP_ENTRY_MAPPING_NO_EXTRACTION','producer':producer['revision'],
           'services':services,'distinct_SHA_mode_size_count':len(distinct),
           'logical_distinct_bytes':sum(k[2] for k in distinct),
           'rounded4KiB_distinct_bytes':sum(((k[2]+4095)//4096)*4096 for k in distinct),
           'proposed_staged_mode_distinct_bytes':sum(k[2] for k in staged_distinct),
           'proposed_staged_mode_rounded4KiB_bytes':sum(((k[2]+4095)//4096)*4096 for k in staged_distinct),
           'stage_reserve_bytes':201326592,'actual_allocated_bytes':'UNKNOWN',
           'dirs_paths_created':False,'resource_mutations':False}
(OUT/'staging-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary,indent=2))
