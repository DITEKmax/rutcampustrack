from pathlib import Path
import ast,datetime,hashlib,json,stat,zipfile,copy
P=Path('/workspace/scratch/rct-validation/current_host_restart_plan');O=Path('/workspace/scratch/rct-validation/current_host_restart_review');checks=[]
def check(n,v):
 checks.append({'name':n,'pass':bool(v)})
 if not v:raise AssertionError(n)
def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb') as f:
  for b in iter(lambda:f.read(65536),b''):h.update(b)
 return h.hexdigest()
check('restart_manifest',sha(P/'manifest.json')=='3b02e82b61409f7118bf434afcd888f5ae556504067913527d673d673d421537')
check('restart_ZIP',sha(P/'safe-evidence.zip')=='f05c922802abcbd8fb07608b05890cfe040f9b5c8ccd86ee0c3f16cb461a2383')
rows=json.loads((P/'manifest.json').read_text())['files'];check('safe15_source_members',len(rows)==15 and all(Path(r['path']).is_relative_to(P) and stat.S_ISREG(Path(r['path']).lstat().st_mode) and Path(r['path']).stat().st_size==r['bytes'] and sha(r['path'])==r['sha256'] for r in rows))
with zipfile.ZipFile(P/'safe-evidence.zip') as z:
 check('ZIP_CRC',z.testzip() is None);check('ZIP_exact_members',set(z.namelist())=={r['name'] for r in rows}|{'manifest.json'});check('ZIP_source_bytes',all(hashlib.sha256(z.read(r['name'])).hexdigest()==r['sha256'] for r in rows))
prior=json.loads((P/'prior-seals.safe.json').read_text())['seals'];check('prior11_seals_preserved',len(prior)==11 and all(sha(r['path'])==r['sha256'] for r in prior))
# Definitions-only execution of public helper: no main, runtime, private input or data content read.
ns={};exec(compile((P/'restart-boundary.py').read_bytes(),str(P/'restart-boundary.py'),'exec'),ns)
now=datetime.datetime(2026,10,12,15,0,tzinfo=datetime.timezone.utc);grant={'durable_restart_authorized':True,'launch_authorized':True,'native_mongo_authorized':True,'reuse_existing_mongo_db':str(ns['DB']),'reuse_existing_mongo_key':str(ns['KEY']),'repeat_bootstrap_authorized':False,'data_reset_authorized':False,'cohort_name':'restart-reviewed-02','deadline_seconds':900,'not_before_utc':now.isoformat(),'stop_utc':(now+datetime.timedelta(seconds=900)).isoformat()}
fn=ns['validate_restart_fields'];check('new_grant_positive',fn(grant,now)==900);check('UTC_elapsed_remaining',fn(grant,now+datetime.timedelta(seconds=120))==780)
def denied(g,t=now):
 try:fn(g,t)
 except (RuntimeError,ValueError,KeyError,TypeError):return True
 return False
for k,value in [('durable_restart_authorized',False),('launch_authorized',False),('native_mongo_authorized',False),('reuse_existing_mongo_db','/tmp/other'),('reuse_existing_mongo_key','/tmp/other'),('repeat_bootstrap_authorized',True),('repeat_bootstrap_authorized',0),('data_reset_authorized',True),('data_reset_authorized',0),('cohort_name','../old'),('cohort_name','restart-../x'),('cohort_name','RESTART-02'),('deadline_seconds',True),('deadline_seconds',0),('deadline_seconds',1801),('deadline_seconds','900'),('not_before_utc',(now+datetime.timedelta(seconds=1)).isoformat()),('stop_utc',now.isoformat()),('stop_utc',(now+datetime.timedelta(seconds=1801)).isoformat()),('not_before_utc',now.replace(tzinfo=None).isoformat())]:check('deny_field_'+k+'_'+str(len(checks)),denied(grant|{k:value}))
check('old_fresh_only_grant_denied',denied({'launch_authorized':True,'native_mongo_authorized':True,'deadline_seconds':1800}));check('expired_grant_denied',denied(grant,now+datetime.timedelta(seconds=901)))
fence=json.loads((P/'stopped-native-data-fence.safe.json').read_text());ns['verify_existing_data'](fence,True);check('actual156_stopped_metadata_intact',len(fence['stopped_db_metadata_nodes'])==156)
for k in ['inode','mode','uid','gid','bytes','nlink','mtime_ns','ctime_ns']:
 bad=copy.deepcopy(fence);bad['exact_key_metadata'][k]+=1
 try:ns['verify_existing_data'](bad,True);good=False
 except RuntimeError:good=True
 check('metadata_key_delta_denied_'+k,good)
for change in ['missing','extra','inode']:
 bad=copy.deepcopy(fence)
 if change=='missing':bad['stopped_db_metadata_nodes'].pop()
 elif change=='extra':bad['stopped_db_metadata_nodes'].append(bad['stopped_db_metadata_nodes'][0]|{'path':str(ns['DB']/'unexpected')})
 else:bad['stopped_db_metadata_nodes'][1]['inode']+=1
 try:ns['verify_existing_data'](bad,True);good=False
 except RuntimeError:good=True
 check('metadata_DB_delta_denied_'+change,good)
sources={n:(P/n).read_text() for n in ['run-mongo-restart.py','run-service-restart.py','docker-up-restart.py','restart-boundary.py']}
for n,s in sources.items():ast.parse(s);check('Python_parse_'+n,True)
tree=ast.parse(sources['run-mongo-restart.py']);helper=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='exact_live_child');scope={};exec(compile(ast.Module(body=[helper],type_ignores=[]),'<exact-identity>','exec'),scope)
base=Path('/workspace/scratch/rct-validation/current_host_config_v5_mongo_identity_correction/run-mongo.py').read_text();oldhelper=next(n for n in ast.parse(base).body if isinstance(n,ast.FunctionDef) and n.name=='exact_live_child');check('identity_helper_exact_prior_AST',ast.dump(helper,include_attributes=False)==ast.dump(oldhelper,include_attributes=False))
child={'pid':101,'start_ticks':1001,'state':'S'};desc={'pid':102,'start_ticks':1002,'state':'S'};rec={'child_pid':101,'members_including_Z':[child,desc]}
for name,table,wanted in [('exact',{101:child,102:desc},True),('absent',{102:desc},False),('reuse',{101:child|{'start_ticks':9000},102:desc},False),('Z',{101:child|{'state':'Z'},102:desc},False),('X',{101:child|{'state':'X'},102:desc},False)]:check('child_identity_'+name,scope['exact_live_child'](rec,table) is wanted)
server=next(n for n in ast.walk(tree) if isinstance(n,ast.If) and ast.unparse(n.test)=="phase == 'server'");text=ast.unparse(ast.Module(body=server.body,type_ignores=[]));check('server_no_ENV_keywrite_mkdir_bootstrap',all(x not in text for x in ['read_bytes','read_text','os.open','mkdir','write','credentials','createUser','bootstrap']));check('server_auth_key_rs0_db_fixed',all(x in text for x in ['--auth','--keyFile','--replSet','rs0','--dbpath','127.0.0.1','28417']))
for n in ['run-mongo-restart.py','run-service-restart.py','docker-up-restart.py']:
 s=sources[n];check('preimport_self_helper_seal_'+n,s.index('manifest_path =')<s.index("exec(compile((PLAN / 'restart-boundary.py')") and 'Path(__file__).absolute()' in s and "PLAN / 'restart-boundary.py'" in s);check('fresh_UTC_before_child_'+n,'boundary.validate_restart_fields' in s[s.index('guard.run_owned'):])
launch=json.loads((P/'effective-launch-inputs.json').read_text());oldlaunch=json.loads(Path('/workspace/scratch/rct-validation/current_host_config_v5_mongo_identity_correction/effective-launch-inputs-v2.json').read_text());check('Docker_exact_reviewed_v5_argv',launch['docker_exact_argv']==oldlaunch['docker_argv']);check('new_grant_exact_commands',all('restart-launch-grant.json' in launch[k][-1] for k in ['mongo_server_command','mongo_readiness_command','host_command_schema']));check('readiness_not_bootstrap',launch['mongo_readiness_command'][3]=='readiness')
js=(P/'mongo-restart-readiness.js').read_text();check('readiness_no_reset_roles_or_replica_creation',all(x not in js for x in ['createUser','updateUser','dropDatabase','replSetInitiate','rs.initiate','rs.reconfig']));check('readiness_roles_and_denied_foreign_codes',all(x in js for x in ['user.roles','dbAdmin','readWrite','error.code === 13','isWritablePrimary','admin.logout()']));check('readiness_no_print_or_credentials_argv','console.' not in js and 'print(' not in js and 'process.env.RCT_RESTART_READINESS_OUTPUT' in js)
vol=json.loads((P/'existing-volume-identities.safe.json').read_text());check('five_volume_record_count',len(vol)==5 if isinstance(vol,list) else len(vol.get('exact5volume_identities',[]))==5)
(O/'source-checks.safe.json').write_text(json.dumps({'status':'PASS_FINITE_CONTROLS_WITH_SEPARATE_PATH_FINDING','checks':checks,'count':len(checks),'private_content_or_data_hashes_read':False,'native_Data':'METADATA_ONLY156','runtime_or_children':False},indent=2)+'\n')
print(json.dumps({'checks':len(checks),'failed':0,'native_data_nodes_metadata_only':156,'runtime_or_children':False}))
