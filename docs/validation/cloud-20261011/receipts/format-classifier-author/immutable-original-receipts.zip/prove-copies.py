#!/usr/bin/env python3
import hashlib
import json
from pathlib import Path
import zipfile

ROOT = Path('/workspace/rutcampustrack')
OUT = Path(__file__).resolve().parent
paths = json.loads((OUT / 'root-tracked-paths.json').read_text())

def dictionaries(value):
    if isinstance(value, dict):
        yield value
        for child in value.values():
            yield from dictionaries(child)
    elif isinstance(value, list):
        for child in value:
            yield from dictionaries(child)

def prove(path):
    file = ROOT / path
    digest = hashlib.sha256(file.read_bytes()).hexdigest()
    receipt = ROOT / '/'.join(path.split('/')[:5])
    relative = str(file.relative_to(receipt))
    manifests = []
    archives = []
    for metadata in receipt.glob('*.json'):
        try:
            data = json.loads(metadata.read_text())
        except (ValueError, UnicodeError):
            continue
        for item in dictionaries(data):
            names = [v for k, v in item.items() if k in ('path', 'file', 'name') and isinstance(v, str)]
            hashes = {k: v for k, v in item.items() if 'sha256' in k and isinstance(v, str)}
            if digest in hashes.values() and any(n == relative or n.endswith('/' + relative) for n in names):
                manifests.append({'path': str(metadata.relative_to(ROOT)), 'matching_hash_fields': [k for k, v in hashes.items() if v == digest]})
                break
    for archive in receipt.glob('*.zip'):
        with zipfile.ZipFile(archive) as z:
            for member in z.infolist():
                if member.file_size < 2_000_000 and (member.filename == relative or member.filename.endswith('/' + relative)):
                    if hashlib.sha256(z.read(member)).hexdigest() == digest:
                        archives.append({'path': str(archive.relative_to(ROOT)), 'member': member.filename})
    return {'path': path, 'sha256': digest, 'bytes': file.stat().st_size,
            'matching_manifests': manifests, 'matching_archives': archives,
            'exact_identity_verified': bool(manifests or archives)}

copies = [prove(p) for p in paths if p.startswith('docs/validation/cloud-20261011/receipts/') and p.endswith(('.py', '.java', '.sql'))]
(OUT / 'exact-source-copy-proofs.json').write_text(json.dumps(copies, indent=2) + '\n')
print(json.dumps({'candidate_count': len(copies), 'verified_count': sum(x['exact_identity_verified'] for x in copies),
                  'unresolved': [x['path'] for x in copies if not x['exact_identity_verified']],
                  'verified': [x['path'] for x in copies if x['exact_identity_verified']]}))
