#!/usr/bin/env python3
"""In-memory selected guard mutations; no recovery source writes or native calls."""
from contextlib import redirect_stdout
from datetime import datetime, timezone
import hashlib
import importlib.util
import io
import json
from pathlib import Path
import unittest

WT = Path('/workspace/rct-worktrees/recovery')
OUT = Path('/workspace/scratch/rct-validation/recovery_developer/light-sensitivity-1')
OUT.mkdir(mode=0o700)
product = WT / 'scripts/recovery.py'
before = hashlib.sha256(product.read_bytes()).hexdigest()
partial = 'test_partial_dump_is_retained_without_success_manifest_and_retry_needs_new_output'
preflight = 'test_schedule_or_mongo_preflight_failure_prevents_every_restore_write'
cases = [
    ('R01-premature-success-manifest', partial, None),
    ('R02-Schedule-nonempty-guard', preflight, 'PostgreSQL target is not fresh; restore refused'),
    ('R02-Mongo-nonempty-guard', preflight, 'Mongo target is not fresh; restore refused'),
    ('R02-disposable-label-guard', preflight, 'Restore accepts only the explicit labeled disposable project'),
]
receipts = []
for identifier, method, message in cases:
    spec = importlib.util.spec_from_file_location(identifier, WT / 'scripts/test-recovery-failure-boundaries.py')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    if message is None:
        source = product.read_text()
        anchor = '    # No success manifest on failure; partial artifacts are retained for diagnosis.'
        assert source.count(anchor) == 1
        source = source.replace(anchor, '    write_json(args.output / "manifest.json", {"format": 1})\n' + anchor)
        exec(compile(source, str(product) + ':in-memory-premature-manifest', 'exec'), module.r.__dict__)
    else:
        original_require = module.r.require

        def broken_require(condition, diagnostic, original=original_require, skipped=message):
            if diagnostic != skipped:
                original(condition, diagnostic)

        module.r.require = broken_require
    log = io.StringIO()
    stdout = io.StringIO()
    with redirect_stdout(stdout):
        result = unittest.TextTestRunner(stream=log, verbosity=2).run(
            unittest.TestSuite([module.RecoveryFailureBoundaries(method)])
        )
    (OUT / (identifier + '.log')).write_text(stdout.getvalue() + log.getvalue())
    assert not result.wasSuccessful(), identifier + ': mutation escaped'
    assert not result.errors, identifier + ': infrastructure error instead of assertion failure'
    assert result.failures, identifier + ': expected assertion failure missing'
    receipt = {
        'id': identifier,
        'timestamp': datetime.now(timezone.utc).isoformat(),
        'test_method': method,
        'outcome': 'EXPECTED_ASSERTION_FAILURE',
        'failures': [{'test': str(test), 'assertion': trace.strip().splitlines()[-1]} for test, trace in result.failures],
        'errors': len(result.errors),
        'retained_artifacts': str(module.RecoveryFailureBoundaries.retained),
        'log': str(OUT / (identifier + '.log')),
    }
    receipts.append(receipt)
    print(json.dumps(receipt))
assert hashlib.sha256(product.read_bytes()).hexdigest() == before
summary = {'argv': ['python3', '/workspace/scratch/rct-validation/recovery_developer/run-sensitivity.py'],
           'level': 'In-memory controlled-seam guard sensitivity; no product file mutation',
           'product_sha256_before_after': before, 'test_sha256': hashlib.sha256((WT / 'scripts/test-recovery-failure-boundaries.py').read_bytes()).hexdigest(),
           'cases': receipts, 'exit': 0, 'native': 'NOT_RUN'}
(OUT / 'run.json').write_text(json.dumps(summary, indent=2) + '\n')
with (OUT.parent / 'attempts.ndjson').open('a') as stream:
    stream.write(json.dumps({'timestamp': datetime.now(timezone.utc).isoformat(), 'action': 'LIGHT_SELECTED_SENSITIVITY', 'receipt': str(OUT / 'run.json'), 'exit': 0}) + '\n')
