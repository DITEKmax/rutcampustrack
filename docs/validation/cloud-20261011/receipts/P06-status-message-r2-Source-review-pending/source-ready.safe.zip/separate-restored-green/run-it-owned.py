"""One fresh Root-granted formatted journal source compile and targeted checks, using unchanged reviewed b78 ownership."""
import datetime
import errno
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time

os.umask(0o077)
scope = Path(__file__).resolve().parent
plan_path = scope / "it-plan.safe.json"
plan = json.loads(plan_path.read_text())
worktree = Path(plan["worktree"])
run = Path(plan["run"])
grant_path = Path(sys.argv[1])

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def utc():
    return datetime.datetime.now(datetime.timezone.utc)

def write(name, value):
    target = run / name
    temporary = target.with_name(target.name + ".next")
    temporary.write_text(json.dumps(value, indent=2) + "\n")
    temporary.replace(target)

if grant_path.resolve() != grant_path.absolute() or grant_path.stat().st_mode & 0o777 != 0o600:
    raise ValueError("Exact private Root grant required")
if digest(grant_path) != sys.argv[2]:
    raise ValueError("Root grant hash mismatch")
grant = json.loads(grant_path.read_text())
if not (grant["authorized"] is True and grant["lease"] == plan["lease"]
        and grant["driver_sha256"] == digest(Path(__file__))
        and grant["child_sha256"] == digest(scope / "logged-it-child.py")
        and grant["plan_sha256"] == digest(plan_path)
        and grant["test_sha256"] == plan["test_sha256"]
        and grant["guard_sha256"] == plan["guard_sha256"]
        and grant["source_review_approved"] is True):
    raise ValueError("Grant/source identity mismatch")
issued = datetime.datetime.fromisoformat(grant["issued_utc"])
stop = datetime.datetime.fromisoformat(grant["stop_utc"])
if not issued.tzinfo or not stop.tzinfo or not issued <= utc() < stop:
    raise ValueError("Fresh grant required")
if subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=worktree).decode().strip() != plan["base"]:
    raise ValueError("Formatted source commit changed")
manifest_path = scope / plan["source_manifest"]
if not (digest(manifest_path) == plan["source_manifest_sha256"]
        and grant["source_manifest_sha256"] == plan["source_manifest_sha256"]):
    raise ValueError("Exact formatted source manifest required")
manifest = json.loads(manifest_path.read_text())
for path, expected in {**manifest["files"], **manifest["protected_files"]}.items():
    if digest(worktree / path) != expected:
        raise ValueError("Formatted source manifest mismatch")
if digest(worktree / plan["test_path"]) != plan["test_sha256"]:
    raise ValueError("Test source changed")
guard_path = Path(plan["guard_path"])
if digest(guard_path) != plan["guard_sha256"]:
    raise ValueError("Reviewed ownership guard changed")
spec = importlib.util.spec_from_file_location("reviewed_b78", guard_path)
guard = importlib.util.module_from_spec(spec)
spec.loader.exec_module(guard)
limits = grant["limits"]
gib = 1024**3
if not (0 < limits["phase_seconds"] <= 540 and limits["cleanup_margin_seconds"] >= 60
        and limits["workspace_floor_bytes"] >= 4*gib and 0 < limits["disk_growth_cap_bytes"] <= 2*gib
        and limits["shared_stop_bytes"] <= 15*gib and limits["shared_reserve_bytes"] >= gib
        and 0 < limits["shared_growth_cap_bytes"] <= 4*gib
        and 0 < limits["owned_rss_cap_bytes"] <= 4*gib and 0 < limits["private_log_cap_bytes"] <= 8*1024**2):
    raise ValueError("Bounded resource specification required")
initial_free = shutil.disk_usage("/workspace").free
memory_path = Path("/sys/fs/cgroup/memory.current")
initial_memory = int(memory_path.read_text())
known = {}
peaks = {"memory": initial_memory, "min_workspace_free": initial_free, "owned_rss": 0, "log_bytes": 0}
last_status = 0.0
containers = None

def observe():
    free = shutil.disk_usage("/workspace").free
    memory = int(memory_path.read_text())
    maximum = int(Path("/sys/fs/cgroup/memory.max").read_text())
    log = run / "native.raw.private.log"
    log_size = log.stat().st_size if log.exists() else 0
    rss = 0
    for pid, ticks in list(known.items()):
        try:
            proc = Path("/proc") / str(pid)
            fields = (proc / "stat").read_text().rsplit(")", 1)[1].split()
            if int(fields[19]) == ticks and fields[0] != "Z":
                rss += int((proc / "statm").read_text().split()[1]) * os.sysconf("SC_PAGE_SIZE")
        except OSError as error:
            if error.errno not in (errno.ENOENT, errno.ESRCH):
                raise
    peaks.update(memory=max(peaks["memory"], memory), min_workspace_free=min(peaks["min_workspace_free"], free),
                 owned_rss=max(peaks["owned_rss"], rss), log_bytes=max(peaks["log_bytes"], log_size))
    if utc() >= stop - datetime.timedelta(seconds=limits["cleanup_margin_seconds"]):
        return "ABSOLUTE_STOP_MARGIN"
    if free < limits["workspace_floor_bytes"] or initial_free-free > limits["disk_growth_cap_bytes"]:
        return "WORKSPACE_LIMIT"
    if memory >= min(limits["shared_stop_bytes"], maximum-limits["shared_reserve_bytes"]):
        return "SHARED_RESERVE_STOP"
    if memory-initial_memory > limits["shared_growth_cap_bytes"] or rss > limits["owned_rss_cap_bytes"]:
        return "MEMORY_GROWTH_STOP"
    if log_size > limits["private_log_cap_bytes"]:
        return "PRIVATE_LOG_CAP"
    if containers is not None:
        return containers.sample()
    return None

def status(value):
    global last_status
    for row in value["members_including_Z"]:
        if row["pid"] in known and known[row["pid"]] != row["start_ticks"]:
            raise ValueError("Owned process birth changed")
        known[row["pid"]] = row["start_ticks"]
    now = time.monotonic()
    if value["state"] != "RUNNING" or now-last_status >= 1:
        write("process.safe.json", {"utc": utc().isoformat(), **value})
        last_status = now

if run.exists() or run.is_symlink() or observe():
    raise ValueError("Fresh own namespace and resource floor required")
run.mkdir(mode=0o700)
(run / "private-tmp").mkdir(mode=0o700)
write("supervisor.safe.json", guard.process_table()[os.getpid()])
write("parent-authority.private.json", {
    "parent": guard.process_table()[os.getpid()],
    "grant_path": str(grant_path.absolute()), "grant_sha256": sys.argv[2],
    "driver_sha256": digest(Path(__file__)), "child_sha256": digest(scope / "logged-it-child.py"),
    "plan_sha256": digest(plan_path), "run": str(run),
})
print(json.dumps({"stage": "STARTED", "supervisor": guard.process_table()[os.getpid()], "run": str(run)}), flush=True)
environment = {
    "JAVA_HOME": "/workspace/rct-cloud-setup/jdk21", "GRADLE_USER_HOME": "/workspace/.gradle",
    "PATH": "/workspace/rct-cloud-setup/jdk21/bin:/usr/local/bin:/usr/bin:/bin",
    "LANG": "C.UTF-8", "LC_ALL": "C.UTF-8", "TZ": "UTC", "TMPDIR": str(run / "private-tmp"),
    "DOCKER_HOST": "unix:///var/run/docker.sock", "TESTCONTAINERS_HOST_OVERRIDE": "127.0.0.1",
    "TESTCONTAINERS_REUSE_ENABLE": "false", "TESTCONTAINERS_RYUK_DISABLED": "false",
    "JAVA_TOOL_OPTIONS": "-Djava.io.tmpdir=" + str(run / "private-tmp"),
    "PYTHONDONTWRITEBYTECODE": "1", "PYTHONNOUSERSITE": "1", "PYTHONSAFEPATH": "1",
}
observer_path = scope / plan["container_observer"]
if not (digest(observer_path) == plan["container_observer_sha256"]
        and grant["container_observer_sha256"] == plan["container_observer_sha256"]
        and grant["exclusive_docker_creation"] is True and grant["owned_container_cleanup"] is True
        and digest(scope / plan["source_supplement"]) == plan["source_supplement_sha256"]
        and grant["source_supplement_sha256"] == plan["source_supplement_sha256"]):
    raise ValueError("Exact IT source/resource authorization required")
for path, expected in json.loads((scope / plan["source_supplement"]).read_text())["files"].items():
    if digest(worktree / path) != expected:
        raise ValueError("IT existing fixture/build source changed")
images = grant["container_images"]
if set(images) != {"postgres", "mongo", "rabbitmq", "redis", "ryuk", "probe"}:
    raise ValueError("Exact six-role image allowlist required")
for role, tag in plan["container_image_tags"].items():
    if len(images[role]) != 1 or images[role][0]["tag"] != tag:
        raise ValueError("Fixture image tag mismatch")
if not (1 <= len(images["ryuk"]) <= 2 and all(row["tag"] in {"testcontainers/ryuk:0.11.0", "testcontainers/ryuk:0.12.0"} for row in images["ryuk"])):
    raise ValueError("Standard cached Testcontainers Ryuk image required")
# Fresh SHA check immediately before loading checking callback source.
if digest(observer_path) != plan["container_observer_sha256"]:
    raise ValueError("IT observer changed before load")
observer_spec = importlib.util.spec_from_file_location("owned_it_observer", observer_path)
observer_module = importlib.util.module_from_spec(observer_spec)
if digest(observer_path) != plan["container_observer_sha256"]:
    raise ValueError("IT observer changed immediately before exec")
observer_spec.loader.exec_module(observer_module)
containers = observer_module.ContainerObserver(run, images, environment, True, stop, plan["probe_class_hashes"])
remaining = (stop-utc()).total_seconds()-limits["cleanup_margin_seconds"]
result = guard.run_owned(
    [sys.executable, str(scope / "logged-it-child.py")], str(worktree), environment,
    deadline_seconds=min(limits["phase_seconds"], remaining), observe=observe, status=status,
    term_seconds=15, kill_seconds=10,
)
try:
    container_settled = containers.settle() if result["settled"] else False
except BaseException as failure:
    containers.failure = "IT_CLEANUP_" + type(failure).__name__
    containers.save(settled=False)
    container_settled = False
result.update(container_settled=container_settled,
              utc=utc().isoformat(), peaks=peaks, expected_native_exit=0,
              native_phase_pass=result["phase_success"], qualification="Compile and selected class XML validation required before PASS")
write("terminal.safe.json", result)
if result["settled"]:
    if container_settled:
        shutil.rmtree(run / "private-tmp")
    (run / "parent-authority.private.json").unlink()
print(json.dumps(result), flush=True)
raise SystemExit(0 if result["phase_success"] and container_settled else 1)
