"""Independent complete Java lexical preservation and SAFE one-file source identity."""
import hashlib
import json
import os
from pathlib import Path
import re
import stat
import subprocess
import zipfile

OUT=Path(__file__).parent
BASE=Path('/workspace/scratch/rct-validation')
PACK=BASE/'enum_filtered_locale_developer/formatter_apply01'
OLD=OUT.parent
DOCS=Path('/workspace/rutcampustrack/docs/validation/cloud-20261011')
WT=Path('/workspace/rct-worktrees/enum-filter-locale')
ROOT=Path('/workspace/rutcampustrack')
TEST='services/academic-service/academic-app/src/test/java/ru/rutcampustrack/academic/integration/AcademicGrpcIT.java'
PROD='services/academic-service/academic-app/src/main/java/ru/rutcampustrack/academic/user/UserSpecifications.java'
os.umask(0o077)
checks=[]
def check(n,b):
    assert b,n
    checks.append({'check':n,'pass':True})
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def save(n,v):(OUT/n).write_text(json.dumps(v,indent=2)+'\n')
ledger=[]
for n in ['TASK-CONTRACT.md','CURRENT.md','decisions.md','questions.md','resources.md']:
    p=DOCS/n;ledger.append({'path':str(p),'bytes':p.stat().st_size,'sha256':sha(p)})
for n,h in [('TASK-CONTRACT.md','e7cbc981e7d1f621f4a6390c0d88f2cbeb5ccfce347a9d324a30389685d2778e'),('decisions.md','c32b5e3d05d12717179e40a1ae228d3672d2982b7941d493bd576ab2d491baf6'),('questions.md','abed4dbf6e29fa7ce6b6383673bd4b8babd31f2eabbc7229a229735f7782df65')]:check('retained FULL state bridge '+n,sha(DOCS/n)==h)
check('original independent test review seal',sha(OLD/'manifest.json')=='a91a24f0d182f57ff4b4819a7430e8fdc6579926013e491c3b7774285ee926b5')
check('current author source seal',sha(PACK/'manifest.safe.json')=='727b1299101dd4e0fba0efcc7886439e2edd9fac828f2815e136b9038cfe13bd')
m=json.loads((PACK/'manifest.safe.json').read_text())
for r in m['members']:
    p=PACK/r['path'];check('SAFE member '+r['path'],sha(p)==r['sha256'] and p.stat().st_size==r['bytes'] and stat.S_IMODE(p.lstat().st_mode)==int(r['mode'],8))
z=PACK/'formatted-test-source.safe.zip'
check('exact SAFE ZIP',sha(z)=='0a505245e8ada8e304f7c6f107c9f01002a3e7593e28fd0d08b09b2780530cd2')
with zipfile.ZipFile(z) as a:
    check('SAFE ZIP CRC/unique inventory',a.testzip() is None and len(a.namelist())==len(set(a.namelist())) and set(a.namelist())=={r['path'] for r in m['members']}|{'manifest.safe.json'})
    for n in a.namelist():check('ZIP member '+n,a.read(n)==(PACK/n).read_bytes())
before=(PACK/'before-test5a4a.java').read_text()
after=(PACK/'formatted-test-dd0c.java').read_text()
check('before reviewed5a4a',sha(PACK/'before-test5a4a.java')=='5a4a7ad3daceb99d16005bc555bbb460bb6088fbd92cb19e9f49e08970d56e0a')
check('after dd0c',sha(PACK/'formatted-test-dd0c.java')=='dd0c466926911d99879fcdb59dd94641ca810bb714992d8fda7bc470b409010d')

# ASCII identifiers cover this file; complete consuming scanner denies unsupported characters,
# Unicode escape preprocessing and text blocks rather than silently normalizing them.
identifier=re.compile(r'[A-Za-z_$][A-Za-z0-9_$]*')
number=re.compile(r'(?:0[xX][0-9a-fA-F_]+(?:\.[0-9a-fA-F_]*)?(?:[pP][+-]?[0-9_]+)?[fFdDlL]?|0[bB][01_]+[lL]?|(?:[0-9][0-9_]*(?:\.[0-9_]*)?|\.[0-9][0-9_]*)(?:[eE][+-]?[0-9_]+)?[fFdDlL]?)')
ops=sorted(['>>>=','<<=','>>=','>>>','<<','>>','==','!=','<=','>=','&&','||','++','--','+=','-=','*=','/=','&=','|=','^=','%=','->','::','...'],key=len,reverse=True)
punct=set('(){}[];,.@=><!~?:+-*/&|^%')
def lex(s):
    assert not re.search(r'\\u+?[0-9a-fA-F]{4}',s),'unsupported Unicode escape preprocessing'
    assert '"""' not in s,'unsupported text block'
    code=[];literals=[];comments=[];delimiters=[];stack=[];i=0
    while i<len(s):
        if s[i].isspace():i+=1;continue
        start=i
        if s.startswith('//',i):
            end=s.find('\n',i);i=len(s) if end<0 else end;comments.append(s[start:i]);continue
        if s.startswith('/*',i):
            end=s.find('*/',i+2);assert end>=0,'unterminated comment';i=end+2;comments.append(s[start:i]);continue
        if s[i] in ['"',"'"]:
            quote=s[i];i+=1
            while i<len(s) and s[i]!=quote:
                assert s[i] not in '\r\n','unterminated literal'
                if s[i]=='\\':i+=2
                else:i+=1
            assert i<len(s) and s[i]==quote,'unterminated literal';i+=1
            v=s[start:i];code.append(v);literals.append(v);continue
        match=identifier.match(s,i)
        if match:i=match.end();code.append(match.group());continue
        match=number.match(s,i)
        if match:i=match.end();code.append(match.group());continue
        op=next((o for o in ops if s.startswith(o,i)),None)
        if op:i+=len(op);code.append(op);continue
        assert s[i] in punct,'unsupported source character'
        ch=s[i];code.append(ch);i+=1
        if ch in '({[':stack.append(ch);delimiters.append(ch)
        if ch in ')}]':
            assert stack and stack.pop()=={')':'(','}':'{',']':'['}[ch],'unbalanced delimiter'
            delimiters.append(ch)
    assert not stack,'unclosed delimiter'
    return {'code':code,'literals':literals,'comments':comments,'delimiters':delimiters}
b=lex(before);a=lex(after)
for k in b:check('full ordered '+k+' equality',b[k]==a[k])
counts={k:len(v) for k,v in a.items()}
check('exact declared lexical counts',counts=={'code':4519,'literals':143,'comments':65,'delimiters':1278})
check('imports byte-identical',before[:before.index('@SpringBootTest')]==after[:after.index('@SpringBootTest')])
controls=[]
def changed(label,s):
    rejected=False
    try:rejected=lex(s)!=a
    except AssertionError:rejected=True
    check('negative control '+label,rejected);controls.append({'case':label,'detected':True})
changed('seed oracle zero weakening',after.replace('isEqualTo(expected.size())','isEqualTo(0)',1))
changed('HTTP unknown status oracle weakening',after.replace('HttpStatus.BAD_REQUEST','HttpStatus.OK',1))
changed('accepted role spelling changed',after.replace('role=ADMIN','role=ADMINISTRATOR',1))
changed('literal whitespace changed',after.replace('ROOT rows match SQL','ROOT  rows match SQL',1))
changed('finally cleanup removed',after.replace('Locale.setDefault(previous);',';',1))
changed('comment removal',after.replace(a['comments'][0],'',1))
check('control whitespace only preserves tokens',lex(after.replace('private FilteredUsers filteredUsers','private\n  FilteredUsers\tfilteredUsers'))==a)
check('maximal munch prevents merging unary tokens',lex('class T { int x = a + +b; }')!=lex('class T { int x = a++b; }'))
for fragment in ['"/academic/users?status=active&page=0&size=100&sort=id,asc"','"/academic/users?status=active&role=ADMIN&page=0&size=100&sort=id,asc"','"/academic/users?role=admin&roleStatus=ACTIVE&page=0&size=100&sort=id,asc"','"%s nonempty SQL fixture"','localeEquality.assertAll();','Locale.setDefault(previous);']:
    check('existing specific oracle remains '+fragment,fragment in before and fragment in after)

metadata=json.loads((PACK/'tracked-metadata-before-after.safe.json').read_text())
bm={r['path']:r for r in metadata['before']};am={r['path']:r for r in metadata['after']}
check('9108 unique equal metadata pathsets',len(bm)==len(metadata['before'])==len(am)==len(metadata['after'])==9108 and set(bm)==set(am))
check('only test tracked metadata delta',[p for p in bm if bm[p]!=am[p]]==[TEST])
fresh_mismatches=[]
for p,r in am.items():
    s=(WT/p).lstat();actual={'path':p,'bytes':s.st_size,'mode':oct(stat.S_IMODE(s.st_mode)),'nlink':s.st_nlink,'inode':s.st_ino,'device':s.st_dev,'mtime_ns':s.st_mtime_ns,'ctime_ns':s.st_ctime_ns,'type':stat.S_IFMT(s.st_mode)}
    if actual!=r:fresh_mismatches.append(p)
check('fresh9108 metadata matches sealed after',not fresh_mismatches)
check('own current test bytes',sha(WT/TEST)==m['formatted_test_sha256'])
check('own test600/nlink1',stat.S_IMODE((WT/TEST).lstat().st_mode)==0o600 and (WT/TEST).lstat().st_nlink==1)
check('original Root test unchanged',sha(ROOT/TEST)=='88bb5c967d08f851ea9e827112ca7404ff444ebaa2ef760bd6c4ff3e31bc5df5')
check('own and Root production original unchanged',sha(WT/PROD)==sha(ROOT/PROD)==m['production_original_sha256'])
env={'PATH':'/usr/bin:/bin','LANG':'C.UTF-8','GIT_OPTIONAL_LOCKS':'0'}
def git(args):
    result=subprocess.run(['git','-C',str(WT),*args],env=env,capture_output=True,check=True);return result.stdout.decode().strip()
check('WT frozen4c',git(['rev-parse','HEAD'])=='4c3745f2febdd4b9bcdd39a4e5f1fc9b3199fab1')
check('WT detached',git(['rev-parse','--abbrev-ref','HEAD'])=='HEAD')
check('only two public paths scoped Git delta is test',git(['diff','--name-only','--',TEST,PROD])==TEST)
tracked=git(['ls-files','-z']).split('\0')
tracked=[p for p in tracked if p]
check('index path inventory9108 metadata exact',len(tracked)==9108 and set(tracked)==set(am))
save('input-ledger.json',ledger)
save('lexical-source-proof.safe.json',{'verdict':'APPROVE_SOURCE_FORMAT_EQUIVALENCE','checks':checks,'count':len(checks),'lexical_counts':counts,'negative_controls':controls,'full_source_characters_consumed':True,'imports_identical':True,'fresh_tracked_metadata_count':9108,'fresh_metadata_mismatches':fresh_mismatches,'full_other_tracked_body_hash_claim':False,'new_AST_parser_compiler_formatter_native':False,'custom_RED_WIP':'NOT_OPENED_OR_RESUMED'})
print(json.dumps({'verdict':'APPROVE_SOURCE_FORMAT_EQUIVALENCE','checks':len(checks),'lexical_counts':counts,'negative_controls':len(controls),'fresh_metadata9108':True,'native':False}))
