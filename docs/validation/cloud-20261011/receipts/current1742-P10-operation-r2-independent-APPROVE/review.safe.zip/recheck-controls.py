"""Two narrow actual catch AST/RAM cases; Source byte boundaries; no observer launch."""
import ast
import hashlib
import json
from pathlib import Path
import ssl
import urllib.error
import zipfile
import xml.etree.ElementTree as ET

HERE = Path(__file__).resolve().parent
NEW = Path('/workspace/scratch/rct-validation/client_session_offline_acceptance/p10-current1742-failure-frame-source-operation-r2')
OLD = NEW.with_name('p10-current1742-failure-frame-source-operation-r1')
old_text, new_text = (OLD / 'logged-green-child.py').read_text(), (NEW / 'logged-green-child.py').read_text()
old_tree, new_tree = ast.parse(old_text), ast.parse(new_text)
def handler(tree):
    observe = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == 'observe_original_case')
    return next(n for n in observe.body if isinstance(n, ast.Try)).handlers[0]
base = {'ssl': ssl, 'urllib': __import__('urllib'), 'zipfile': zipfile, 'ET': ET, 'json': json}
setup = [n for n in new_tree.body if isinstance(n, ast.ClassDef) and n.name == 'DiagnosticBlocked'
    or isinstance(n, ast.Assign) and any(isinstance(t, ast.Name) and t.id == 'PRIMARY_REJECTION_CODES' for t in n.targets)]
exec(compile(ast.Module(body=setup, type_ignores=[]), '<public-Source-setup>', 'exec'), base)
catch = compile(ast.Module(body=handler(new_tree).body, type_ignores=[]), '<new-sealed-catch>', 'exec')
calls = []
class HashTrap(type):
    def __hash__(cls):
        calls.append('HASH')
        raise RuntimeError('RAM_PRIVATE_HASH_MESSAGE')
class HashTrapError(Exception, metaclass=HashTrap):
    pass
class EqualityTrap(type):
    def __hash__(cls):
        calls.append('HASH')
        return hash(urllib.error.HTTPError)
    def __eq__(cls, other):
        calls.append('EQUALITY')
        return other is urllib.error.HTTPError
class EqualityTrapError(Exception, metaclass=EqualityTrap):
    pass
controls = {}
for label, error in [('hash_trap', HashTrapError('RAM_PRIVATE_CONTEXT')), ('equality_trap', EqualityTrapError('RAM_PRIVATE_CONTEXT'))]:
    calls.clear()
    ns = {**base, 'failure': error, 'primary_rejection': 'NONE', 'exception_code': 'NONE', 'http_status': 0, 'operation_stage': 'URL_OPEN'}
    exec(catch, ns)
    value = {k: ns[k] for k in ['primary_rejection', 'exception_code', 'http_status', 'operation_stage']}
    assert not calls and value == {'primary_rejection': 'BOUNDARY_UNKNOWN', 'exception_code': 'OTHER', 'http_status': 0, 'operation_stage': 'URL_OPEN'}
    assert 'RAM_PRIVATE' not in json.dumps(value)
    controls[label] = {'hooks_called': 0, 'closed_fields': value, 'PASS': True}

old_assignment = handler(old_tree).body[0]
new_nodes = handler(new_tree).body[:3]
assert isinstance(old_assignment.value, ast.Call) and isinstance(old_assignment.value.func.value, ast.Dict)
dictionary = old_assignment.value.func.value
loop = new_nodes[2]
assert isinstance(loop, ast.For) and isinstance(loop.iter, ast.Tuple)
old_pairs = [(ast.dump(key, include_attributes=False), ast.dump(value, include_attributes=False)) for key, value in zip(dictionary.keys, dictionary.values)]
new_pairs = [(ast.dump(item.elts[0], include_attributes=False), ast.dump(item.elts[1], include_attributes=False)) for item in loop.iter.elts]
checks = {'same19_type_code_pairs': len(new_pairs) == 19 and new_pairs == old_pairs,
    'selection_only_identity': isinstance(loop.body[0].test, ast.Compare) and len(loop.body[0].test.ops) == 1 and isinstance(loop.body[0].test.ops[0], ast.Is)}
old_block = ast.get_source_segment(old_text, old_assignment)
new_block = '\n'.join(new_text.splitlines()[new_nodes[0].lineno - 1:loop.end_lineno])
# Remove the indentation common to both mapping regions consistently.
old_lines = old_text.splitlines(keepends=True)
new_lines = new_text.splitlines(keepends=True)
del old_lines[old_assignment.lineno - 1:old_assignment.end_lineno]
del new_lines[new_nodes[0].lineno - 1:loop.end_lineno]
checks['whole_inverse_exact_except_mapping'] = ''.join(old_lines) == ''.join(new_lines)
for name, sha in json.loads((NEW / 'manifest.safe.json').read_text())['files'].items():
    checks['seal_' + name] = hashlib.sha256((NEW / name).read_bytes()).hexdigest() == sha
checks['parent_c5af_exact'] = (NEW / 'run-green-owned.py').read_bytes() == (OLD / 'run-green-owned.py').read_bytes()
checks['caps_exact'] = json.loads((NEW / 'grant-template.private.json').read_text())['limits'] == json.loads((OLD / 'grant-template.private.json').read_text())['limits']
manifest = json.loads((NEW / 'source-manifest.safe.json').read_text())
plan = json.loads((NEW / 'green-plan.safe.json').read_text())
wt = Path(plan['worktree'])
checks['18_public_inputs'] = all(hashlib.sha256((wt / n).read_bytes()).hexdigest() == sha for n, sha in {**manifest['files'], **manifest['protected_files']}.items())
checks['b78'] = hashlib.sha256(Path(plan['guard_path']).read_bytes()).hexdigest() == plan['guard_sha256']
for name, sha in [('READY.safe.json', '8ef8b8fe4292f84c556383fa15a19d4926fd91ef62665ea30ba48c827233532f'),
    ('manifest.safe.json', 'ac4e581c3b770940b047d93aba4be03ca510d05bd24da767ee853624454333aa'),
    ('SOURCE.safe.zip', '93edce30fde9355ad2524cd4954d5dac2899a96d7ac90efeeace42665e70b341')]:
    checks['exact_' + name] = hashlib.sha256((NEW / name).read_bytes()).hexdigest() == sha
checks['old_seals_preserved'] = hashlib.sha256((OLD / 'manifest.safe.json').read_bytes()).hexdigest() == '270111f261d0fade23cb22e8281c735e3fdee1f1dbfa95fda927f6dbbfe242d8' and hashlib.sha256((OLD / 'SOURCE.safe.zip').read_bytes()).hexdigest() == '57a9a5317fe236c87c25f0f29109ba462136d2738b6f5d5dcedc8233b7aa4208'
assert all(checks.values()), {k: v for k, v in checks.items() if not v}
out = {'schema': 'P10_OPERATION_R2_NARROW_INDEPENDENT_RECHECK_V1', 'verdict': 'APPROVE_SOURCE',
    'closed_finding': 'P10-EXCEPTION-TYPE-LOOKUP-METACLASS-HOOKS', 'two_actual_catch_AST_RAM': controls,
    'source_boundary_checks': checks, 'old19_plus8_plus15_and13_and17plus6': 'REUSED_NOT_RERUN',
    'native': 'NOT_RUN', 'actual02_and_CI_P10_cause': 'UNKNOWN', 'network_context_proposal': 'OUTSIDE_APPROVAL_NOT_IMPLEMENTED',
    'effects': 'Public Source and RAM synthetic catch only; no private URL/log/XML/environment/native/API/network/test/Source edit/children/B013'}
(HERE / 'controls.safe.json').write_text(json.dumps(out, indent=2) + '\n')
print(json.dumps({'verdict': 'APPROVE_SOURCE', 'targeted_cases': 2, 'source_checks': 'PASS', 'native': 'NOT_RUN'}))
