"""Narrow public seals + selected pure AST/mocks; never imports runtime target modules."""
import ast
import datetime
import difflib
import hashlib
import json
from pathlib import Path
import stat
import types
import zipfile

OUT=Path(__file__).parent
SOURCE=OUT.parent/'browser_webkit_native_deadline_correction'
OLD=OUT.parent/'browser_webkit_native_prepare'
REVIEW=OUT.parent/'native_prepare_review'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def sealed(directory,expected):
    assert sha(directory/'manifest.json')==expected
    m=json.loads((directory/'manifest.json').read_text());members={}
    for row in m['files']:
        path=Path(row['path']);info=path.lstat()
        assert 'private' not in path.parts and stat.S_ISREG(info.st_mode)
        assert sha(path)==row['sha256']
        if 'bytes' in row:assert info.st_size==row['bytes']
        if 'size' in row:assert info.st_size==row['size']
        if 'mode' in row:assert stat.S_IMODE(info.st_mode)==(int(row['mode'],0) if isinstance(row['mode'],str) else row['mode'])
        members[row.get('name',row.get('relative_path'))]=row['sha256']
        if path.suffix=='.py':ast.parse(path.read_text())
    members['manifest.json']=expected
    return members
members=sealed(SOURCE,'7dfe76bcf892651a4b8265f64f2ef14bb75df500052157c8bffde4f99eadeeb4')
oldmembers=sealed(OLD,'5de31368e2d41d803d54250487d83e5749728d385f38375e0db489fe7fbc01d8')
reviewmembers=sealed(REVIEW,'24fec2136401c5401fd698acc0b742fee2573ccd9755b67e6aeef5f1fbc47a57')
archive=SOURCE/'deadline-correction.source.safe.zip'
assert sha(archive)=='4c7f7821f46b87a3a10f34c219866fe47622186d4a6de696c8eadc485cf06d4f'
with zipfile.ZipFile(archive) as z:
    assert len(z.infolist())==len(members) and len(z.namelist())==len(set(z.namelist()))
    for item in z.infolist():
        assert item.filename in members and '/' not in item.filename
        assert hashlib.sha256(z.read(item)).hexdigest()==members[item.filename]
    assert z.testzip() is None
delta=[]
for name in ['extract-selected.py','validate-native.py','webkit-custom-exec.py','own-paths.py']:
    delta.append(''.join(difflib.unified_diff((OLD/name).read_text().splitlines(keepends=True),(SOURCE/name).read_text().splitlines(keepends=True),fromfile=str(OLD/name),tofile=str(SOURCE/name))))
unchanged=['selection.py','native-probe.py','custom-executable-proposal.py','source-controls.py','caller-controls.py','copy-controls.py','selected-dso-headers.safe.json','signed-archive-inputs.safe.json','native-tools.safe.json','extraction-procedure.safe.json','native-validation-procedure.safe.json','custom-wrapper-boundary.safe.json']
for name in unchanged:assert sha(SOURCE/name)==sha(OLD/name)
for name in ['source-controls.safe.json','caller-controls.safe.json','copy-controls.safe.json']:
    n=json.loads((SOURCE/name).read_text());o=json.loads((OLD/name).read_text())
    assert n['count']==o['count'] and sorted(json.dumps(r,sort_keys=True) for r in n['checks'])==sorted(json.dumps(r,sort_keys=True) for r in o['checks'])
controls=json.loads((SOURCE/'deadline-controls.safe.json').read_text())
assert controls['count']==len(controls['checks'])==18 and controls['old_late_allow_counterexamples']==4
assert all(r['pass'] is True for r in controls['checks'])

def main(name):
    return next(n for n in ast.parse((SOURCE/name).read_text()).body if isinstance(n,ast.FunctionDef) and n.name=='main')
fresh=next(n for n in ast.parse((SOURCE/'use-gates.py').read_text()).body if isinstance(n,ast.FunctionDef) and n.name=='require_fresh')
good={'/workspace_available':10000000000,'/tmp_available':10000000000,'shared_memory':3000000000,'shared_limit':17179869184,'rss':12000000}
stop=datetime.datetime(2026,10,12,18,0,tzinfo=datetime.timezone.utc)
clock={'now':stop-datetime.timedelta(seconds=1)}
class Clock:
    @classmethod
    def now(cls,tz):return clock['now']
gate_globals={'os':types.SimpleNamespace(getuid=lambda:1000,getgid=lambda:1000),'resources':lambda:dict(good),'datetime':types.SimpleNamespace(datetime=Clock,timezone=datetime.timezone)}
exec(compile(ast.Module(body=[fresh],type_ignores=[]),'selected pure gate','exec'),gate_globals)
gate=gate_globals['require_fresh'];checks=[]

# Actual new callback placements deny delayed initial mutation under synthetic identities.
extract=main('extract-selected.py')
klass=next(n for n in extract.body if isinstance(n,ast.ClassDef) and n.name=='LeasedNamespace')
assignment=next(n for n in extract.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='ns' for t in n.targets))
actions=[]
class Namespace:
    def __init__(self,path):
        self.identities=[1,2];self.check();actions.append('mkdir')
    def check(self):clock['now']+=datetime.timedelta(seconds=2)
try:
    exec(compile(ast.Module(body=[klass,assignment],type_ignores=[]),'selected namespace','exec'),{'driver':types.SimpleNamespace(Namespace=Namespace),'PREFIX':Path('/tmp/public-synthetic'),'CAP':33554432,'stop':stop,'gates':types.SimpleNamespace(require_fresh=gate)})
except RuntimeError:pass
else:raise AssertionError('Expired namespace accepted')
assert not actions
checks.append({'point':'first prefix mkdir','delayed_metadata_denied':True,'actual_effects':False})
clock['now']=stop-datetime.timedelta(seconds=1)
class Output:
    def __init__(self,path,create=False,before_mutation=None):
        clock['now']+=datetime.timedelta(seconds=2)
        before_mutation();actions.append('mkdir')
native=main('validate-native.py')
output=next(n for n in native.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='out' for t in n.targets))
try:
    exec(compile(ast.Module(body=[output],type_ignores=[]),'selected output','exec'),{'paths':types.SimpleNamespace(Output=Output),'OWN':SOURCE,'g':{'cohort_name':'native-synthetic'},'stop':stop,'gates':types.SimpleNamespace(require_fresh=gate)})
except RuntimeError:pass
else:raise AssertionError('Expired output accepted')
assert not actions
checks.append({'point':'first native output mkdir','delayed_constructor_denied':True,'actual_effects':False})
wrapper=main('webkit-custom-exec.py');wrapped=next(n for n in wrapper.body if isinstance(n,ast.Try))
execute=next(n for n in wrapped.body if isinstance(n,ast.Expr) and isinstance(n.value,ast.Call) and ast.unparse(n.value.func)=='os.execve')
beforeexec=wrapped.body[wrapped.body.index(execute)-1]
assert ast.unparse(beforeexec).startswith('gates.require_fresh(')
clock['now']=stop+datetime.timedelta(seconds=1)
try:
    exec(compile(ast.Module(body=[beforeexec,execute],type_ignores=[]),'selected final exec','exec'),{'os':types.SimpleNamespace(execve=lambda *a:actions.append('execve')),'executable':'public-synthetic','argv':[],'child_env':{},'gates':types.SimpleNamespace(require_fresh=gate),'datetime':datetime,'grant':{'stop_utc':stop.isoformat()}})
except RuntimeError:pass
else:raise AssertionError('Expired exec accepted')
assert not actions
checks.append({'point':'final execve','expired_proof_denied':True,'actual_effects':False})

# Exact new final gate + full following publication expression. All resources/output mocked.
native_try=next(n for n in native.body if isinstance(n,ast.Try))
publish=next(n for n in native_try.body if isinstance(n,ast.Expr) and 'native-validation.safe.json' in ast.unparse(n))
beforepublish=native_try.body[native_try.body.index(publish)-1]
assert ast.unparse(beforepublish)=='gates.require_fresh(stop)'
clock['now']=stop-datetime.timedelta(seconds=1)
published=[]
def delayed_resources():
    clock['now']+=datetime.timedelta(seconds=2)
    return dict(good)
def fake_save(name,value):
    published.append({'name':name,'status':value['status'],'publication_utc':clock['now'].isoformat(),'after_stop':clock['now']>=stop})
synthetic_results=[{'target':'public-synthetic-case-'+str(i),'pass':True} for i in range(43)]
namespace={'gates':types.SimpleNamespace(require_fresh=gate),'stop':stop,'out':types.SimpleNamespace(save=fake_save),'g':{'source_manifest_sha256':'synthetic-metadata-only','extraction_receipt_sha256':'synthetic-metadata-only'},'results':synthetic_results,'vendor':[],'identities':[],'selected':[],'driver':types.SimpleNamespace(resources=delayed_resources)}
exec(compile(ast.Module(body=[beforepublish,publish],type_ignores=[]),'exact selected final gate and publication','exec'),namespace)
assert len(published)==1 and published[0]['status']=='PASS_EFFECTIVE_NATIVE_AVAILABILITY_ONLY' and published[0]['after_stop'] is True
checks.append({'point':'native PASS publication','exact_new_gate_plus_FULL_save_expression':'STILL_ALLOWS_LATE_PASS','mock_trace':published,'actual_effects':False,'synthetic_success_case_count':43,'synthetic_metadata':'NOT_NATIVE_PROOF; only evaluation ordering exercised'})
result={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'verdict':'CHANGES_REQUESTED','finding':'T005-GRANT-USE-TIME remains open ONLY final publication','input_manifest_sha256':sha(SOURCE/'manifest.json'),'input_zip_sha256':sha(archive),'new_members':len(members)-1,'zip_members':len(members),'original25_and_review6_preserved':True,'unchanged_helper_and_procedure_files':unchanged,'author18_controls_inspected_not_rerun':True,'reviewer_selected_mock_cases':checks,'remaining_location':{'path':str(SOURCE/'validate-native.py'),'gate_line':beforepublish.lineno,'publication_line':publish.lineno},'required_fix':'Build publication resource snapshot/arguments before final fresh clock gate or enforce gate after argument preparation at publication boundary; test full selected save expression/resource delay, not gate alone','target_runtime_imports_spawn_extract_native_browser_API_Docker':False}
(OUT/'recheck.safe.json').write_text(json.dumps(result,indent=2)+'\n')
(OUT/'source-delta.patch').write_text(''.join(delta))
print(json.dumps({'seals':'PASS','source_scope':'NARROW','closed_points':3,'remaining':'late native PASS via postgate driver.resources','verdict':'CHANGES_REQUESTED','actual_native':'NOT_RUN'}))
