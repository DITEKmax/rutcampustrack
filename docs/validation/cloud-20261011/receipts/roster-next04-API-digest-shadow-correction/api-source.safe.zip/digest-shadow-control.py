from pathlib import Path
import ast,hashlib,io,json,types
B=Path(__file__).parent
DATA=b'PUBLIC_SOURCE_DIGEST_CONTROL'
EXPECTED=hashlib.sha256(DATA).hexdigest()
class PublicPath:
 def __init__(self,*args):pass
 def open(self,*args):return io.BytesIO(DATA)
 def read_bytes(self):return DATA
 def is_symlink(self):return False
 def stat(self):return types.SimpleNamespace(st_nlink=1)
 def __truediv__(self,other):return self

def selected(source):
 tree=ast.parse(source);nodes=[]
 for node in tree.body:
  if isinstance(node,ast.FunctionDef) and node.name=='digest':nodes.append(node)
  if isinstance(node,ast.For) and isinstance(node.iter,ast.Call) and isinstance(node.iter.func,ast.Attribute) and isinstance(node.iter.func.value,ast.Subscript) and isinstance(node.iter.func.value.value,ast.Name) and node.iter.func.value.value.id=='plan' and isinstance(node.iter.func.value.slice,ast.Constant) and node.iter.func.value.slice.value in {'immutablePins','mutableOnlyAfterExplicitFormatGrant'}:nodes.append(node)
 assert len(nodes)==3
 box={'hashlib':hashlib,'Path':PublicPath,'plan':{'immutablePins':{'PUBLIC':EXPECTED},'mutableOnlyAfterExplicitFormatGrant':{}},'BASE':PublicPath()}
 exec(compile(ast.Module(body=nodes,type_ignores=[]),'<selected-public-source>','exec'),box)
 expression=ast.Expression(body=ast.Call(func=ast.Name(id='digest',ctx=ast.Load()),args=[ast.BinOp(left=ast.Name(id='BASE',ctx=ast.Load()),op=ast.Div(),right=ast.Constant(value='READY.safe.json'))],keywords=[]));ast.fix_missing_locations(expression)
 try: return {'functionSurvives':callable(box['digest']),'hashCallPass':eval(compile(expression,'<selected-ready-hash-call>','eval'),box)==EXPECTED,'closedTypeError':False}
 except TypeError:return {'functionSurvives':False,'hashCallPass':False,'closedTypeError':True}
old=selected((B/'before-d0b9-run-api-witness.py').read_text());new=selected((B/'run-api-witness.py').read_text())
result={'pass':old['closedTypeError'] and not old['functionSurvives'] and new['functionSurvives'] and new['hashCallPass'] and not new['closedTypeError'],'old':old,'new':new,'qualification':'Actual selected old/new Python AST function and exact two module-level loops, publicfakePath/hash in RAM. Source control only; no module execution/privategrant/Node/HTTP/API/browser/service effects.'}
(B/'digest-shadow-control.safe.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'sourceControlPass':result['pass'],'oldTypeError':old['closedTypeError'],'newHashCallPass':new['hashCallPass']}))
