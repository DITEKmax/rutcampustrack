"""Finite recorded evidence review. Standard library only; no runtime replay."""
import hashlib
import json
from pathlib import Path
import re
import stat
import zipfile

OWN = Path(__file__).parent
SOURCE = OWN.parent / 'browser_webkit_native_anchor_correction'
ACTUAL = SOURCE / 'actual-native02'
SEALED = ACTUAL / 'terminal-seal'
RUNTIME = SOURCE / 'runtime/native-20261012-proof02'
PREFIX = Path('/tmp/rct-webkit-native-deps-20261012')
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p): return json.loads(p.read_text())
manifest = SEALED / 'manifest.json'
assert sha(manifest) == '202c8a33f010bd03b601331d1e3acec95543496eedd44d4ad7284e39e9dc3fe6'
rows = read(manifest)['files']
assert len(rows) == 136
def verify_rows(items, parent):
    for row in items:
        p = Path(row['path'])
        assert p.parent == parent and 'private' not in p.parts and '.env' != p.name
        s = p.lstat()
        assert stat.S_ISREG(s.st_mode) and s.st_nlink == 1
        assert s.st_size == row['size'] and stat.S_IMODE(s.st_mode) == int(row['mode'],0)
        assert sha(p) == row['sha256']
verify_rows(rows, SEALED)
z = ACTUAL / 'native43-outcome.safe.zip'
assert sha(z) == '112bba90bf52f52ffca774afa3dfc9a85d8cb78bde6041d8bf54d37013d307d7'
expected_files = {r['relative_path']:r['sha256'] for r in rows}
expected_files['manifest.json'] = sha(manifest)
with zipfile.ZipFile(z) as archive:
    members = archive.infolist()
    assert len(members) == 137 and archive.testzip() is None
    assert len({m.filename for m in members}) == len(members)
    for m in members:
        assert m.filename in expected_files and not stat.S_ISLNK(m.external_attr >> 16)
        assert hashlib.sha256(archive.read(m)).hexdigest() == expected_files[m.filename]
root_copy = Path('/workspace/rutcampustrack/docs/validation/cloud-20261011/receipts/webkit-native43-actual-availability')
assert sha(root_copy/'manifest.json') == sha(manifest)
assert sha(root_copy/'safe-evidence.zip') == sha(z)
source_manifest = SOURCE/'manifest.json'
assert sha(source_manifest) == '6aed2f66ce5c1dcf0d78fcd534903523575b6ca82b6231606d9aa7ff5062eb3c'
verify_rows(read(source_manifest)['files'], SOURCE)
review_manifest = OWN.parent/'native_anchor_recheck/manifest.json'
assert sha(review_manifest) == 'b3caa360f9687c119244a60f7b38f117e1f8cd7a6a667cd821534f2c91a0d3c1'
proof = read(SEALED/'native-validation.safe.json')
assert sha(SEALED/'native-validation.safe.json') == sha(RUNTIME/'native-validation.safe.json') == '5c16718574eac396903beff33d0f30ac036f67c7a89e58b0885b93c6fd95b7e8'
copy_receipt = PREFIX/'terminal.safe.json'
assert sha(copy_receipt) == proof['extraction_receipt_sha256'] == '55f4fe3e0e05bed1a2e66c337fbb532154513d1c0ee71e0b0000cf2c1c9ea2f4'
copy = read(copy_receipt)
assert copy['status'] == 'EXACT14_DSO_8_RELATIVE_LINKS_COPIED' and len(copy['copied']) == 14
procedure = read(SOURCE/'native-validation-procedure.safe.json')
selected = read(SOURCE/'selected-dso-headers.safe.json')['selected']
assert proof['vendor'] == procedure['upstream25_ELF_4shell']
vendor = proof['vendor']
regular = [r for r in selected if r['kind']=='regular']
assert len(vendor)==29 and sum(r['elf'] for r in vendor)==25 and len(regular)==14
assert proof['selected_links'] == [r for r in selected if r['kind']=='symlink'] and len(proof['selected_links'])==8
copy_by_name = {r['name']:r for r in copy['copied']}
assert proof['copied_regular'] == [dict(path=str(PREFIX/r['name']),sha256=copy_by_name[r['name']]['sha256'],bytes=copy_by_name[r['name']]['bytes'],mode=0o644) for r in regular]
expected = [(r['path'],'minibrowser-wpe' if '/minibrowser-wpe/' in r['path'] else 'minibrowser-gtk','loader') for r in vendor if r['elf']]
expected += [(str(PREFIX/r['name']),'package','loader') for r in regular]
expected += [(target,variant,kind) for variant in ['minibrowser-wpe','minibrowser-gtk'] for target,kind in [(str(PREFIX/'usr/lib/x86_64-linux-gnu/libGLESv2.so.2'),'gles'),('/usr/lib/x86_64-linux-gnu/libx264.so.164','x264')]]
assert len(expected)==len(set(expected))==43
assert [(r['target'],r['variant'],r['kind']) for r in proof['results']]==expected
assert proof['status']=='PASS_EFFECTIVE_NATIVE_AVAILABILITY_ONLY' and proof['source_manifest_sha256']==sha(source_manifest)
assert proof['loader_count']==39 and proof['actual_GLES_dlopen'] is True and proof['actual_x264_dlopen_symbol'] is True and proof['version_errors'] is False and proof['browser_E2E']=='NOT_RUN'
assert read(SEALED/'partial.safe.json')['completed']==proof['results']
launch = read(SEALED/'launch.safe.json')
terminal = read(SEALED/'own-terminal-verification.safe.json')
current = read(SEALED/'own-CURRENT.json')
assert launch['native_cases']==43 and launch['source_manifest_sha256']==sha(source_manifest) and launch['browser'] is False
parent = launch['parent_identity']
assert parent['pid']==367844 and parent['start_ticks']==8343841 and terminal['supervisor_identity']==parent==current['supervisor_identity']
assert terminal['session']==current['session']==22128 and current['supervisor_live_exact'] is False and current['active_sessions']==[]
all_known = set()
coverage = []
provider_hashes = {}
for index,row in enumerate(proof['results']):
    name='probe-'+str(index).zfill(2)+'.safe.json'
    assert row['safe_result']==str(RUNTIME/name) and row['pass'] is True
    assert row['sha256']==sha(SEALED/name)==sha(RUNTIME/name)
    value=read(SEALED/name)
    assert value['pass'] is True
    if index<39:
        assert value['native_exit']==value['ELF_version_metadata_native_exit']==0
        assert value['missing_sonames']==[] and value['version_error_or_warning'] is False and value['raw_output_not_saved_or_published'] is True
        assert value['resolved_public_dsos'] and isinstance(value['public_version_names'],list)
        for provider in value['resolved_public_dsos']:
            path=provider['path']; digest=provider['sha256']
            assert path.startswith(('/usr/lib/','/lib/','/tmp/rct-validation-browsers-20261012/webkit-2272/','/tmp/rct-webkit-native-deps-20261012/')) and re.fullmatch('[a-f0-9]{64}',digest)
            assert provider_hashes.setdefault(path,digest)==digest
    else:
        assert value['actual_dlopen'] is True and value['GL_context_encoding_or_browser']=='NOT_RUN'
        assert value['public_symbol_present']==('glGetString' if row['kind']=='gles' else 'x264_encoder_open_164')
    t=read(SEALED/('terminal-'+str(index)+'.safe.json'))
    proc=read(SEALED/('process-'+str(index)+'.safe.json'))
    assert t['native_exit']==0 and t['phase_success'] is True and t['settled'] is True and t['all_owned_processes_reaped'] is True
    assert t['signal_count']==0 and t['all_members_including_Z_after']==[] and t['supervision_error_type'] is None
    assert proc['state']=='REAPED' and proc['child_pid']==t['direct_pid'] and proc['members_including_Z']==[] and proc['signal_count']==0
    assert len(t['known_owned_identities'])==1 and t['known_owned_identities'][0]['pid']==t['direct_pid']
    all_known.add((t['direct_pid'],t['known_owned_identities'][0]['start_ticks']))
    coverage.append(dict(index=index,target=row['target'],variant=row['variant'],kind=row['kind'],probe_sha256=row['sha256'],direct_pid=t['direct_pid'],native_exit=0,settled_reaped=True,signals=0))
all_known.add((parent['pid'],parent['start_ticks']))
assert len(all_known)==44 and all_known=={(r['pid'],r['start_ticks']) for r in terminal['known']}
assert terminal['known_identity_count']==44 and terminal['all_known_identities_absent'] is True and terminal['no_signals'] is True
assert terminal['postproof_vendor_and14DSO_SHA_equal'] is True and terminal['proof_sha256']==sha(RUNTIME/'native-validation.safe.json')
assert terminal['prefix_plus_native_cohort_allocated_bytes']==13361152 < 33554432
for path,digest in provider_hashes.items():
    copies={r['path']:r['sha256'] for r in proof['copied_regular']}
    vendors={r['path']:r['sha256'] for r in vendor}
    if path in copies: assert copies[path]==digest
    if path in vendors: assert vendors[path]==digest
ready=read(SEALED/'future-browser-ready.safe.json')
assert ready['actual_native_proof_sha256']==sha(RUNTIME/'native-validation.safe.json') and ready['browser_not_granted_or_run'] is True
assert ready['wrapper_sha256']==sha(SOURCE/'webkit-custom-exec.py') and ready['source_manifest_sha256']==sha(source_manifest)
result=dict(outcome='APPROVE_FINITE_EVIDENCE',blocking_findings=0,source_manifest=sha(source_manifest),source_review=sha(review_manifest),actual_manifest=sha(manifest),actual_zip=sha(z),actual_proof=sha(RUNTIME/'native-validation.safe.json'),safe_members=136,zip_members=137,exact_cases=43,loader_version_pairs=39,dlopen_cases=4,coverage=coverage,unique_recorded_provider_paths=len(provider_hashes),known_identities=44,all_known_absent_recorded=True,supervisor_native0='Recorded by author own-CURRENT/HANDOFF and Root tool22128; no replay',allocated_bytes_recorded=13361152,limitations=['Nested fast loader/readelf births NOT_CAPTURED; successful subprocess.run synchronously waited','Recorded cleanup/rehash reviewed; no independent native/ABI/process replay or binary rehash','Resource sampling and sameUID/byname controls are soft, not hard cgroup isolation','WebKit browser protocol/GTK GUI resources/rendering/encoding/client/API NOT_RUN; fresh separate browser grant required'],reviewer_target_imports_native_browser_network_calls=0)
(OWN/'checks.safe.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:result[k] for k in ['outcome','safe_members','zip_members','exact_cases','unique_recorded_provider_paths','known_identities']}))
