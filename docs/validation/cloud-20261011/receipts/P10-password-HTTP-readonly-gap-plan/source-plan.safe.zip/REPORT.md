P10 exact existing evidence and minimum gap

Current597/actualcheckoutbb4c already has real networkHTTP ASCII change/reset, realPG atomicity, pureUnicodepolicy and MockMvc/realPG initial-password grant tests. Fifteen exact SOURCE_METHOD PASS identities matched public ownSource bytes; sourceledger andproducer/run/task qualifications are in REPORT.safe.json. These tests didnotrun at Rootnewlocalae027/d949.

The concrete missing seam is Unicode12scalar/72byte input across HTTP parsing, production BCrypt, durable credentialcommit and exactinputlogin, plus invalidboundary no partial state/ticketconsumption. Policy unit72/73 PASS cannot prove that seam. ResetHTTP fixture startsinitialpasswordNULL; actual resetclear fromnonNULLneedsanexplicitnetworkoracle. WrongcurrentHTTP400 existingunit mocksAuthService. No productDEFECT inferred.

Minimum proposal: ONE new method in existingAuthOtpFlowIT realHTTP/PG/Redis/Rabbit fixture, notwritten/granted. Verifynegativewrongcurrent/11scalar/73byte/malformedunpaired requests with noecho/noJWT/stateunchanged, positiveUnicode12scalar change and72UTF8byte reset with RAMBCrypt matches/exactnewlogin/oldcredential+bearer-refresh denials/initialclear/flags; same resetticket usable afterinvalidinput. Preserve existingpolicy/categories/clocks/grants/fixture defaults and sensitiveassertion/artifact rules. No normalization/lifetime/newgrant. ExistingPASS slices are reused, no broadrerun.

Next: Root narrowauthorassignment onlyifaccepted, Source criticalreview thenfreshactualgrant/currentCI. Fixture requiresPG+Redis7-alpine+Rabbit3.13-management-alpine/defaultRyuk; currentCloudavailability uninvestigated. ParentP10UNKNOWN. No native/product/Rootwrites/privateXML/log/credential orB013action.
