"""Readonly source seal checks and selected pure grant counterexamples; no target imports."""
import ast
import datetime
import hashlib
import json
from pathlib import Path
import stat
import types
import zipfile

OWN=Path(__file__).parent
SOURCE=OWN.parent/'client_real_acceptance/webkit-public-boot'
WRAPPER=OWN.parent/'browser_webkit_native_anchor_correction'
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
assert sha(SOURCE/'manifest.safe.json')=='ffb76a7b81f46d31c9ff33654a06830af05c7bff4d6b0cd2e768c06ece098498'
assert sha(SOURCE/'READY.safe.json')=='ab1b30c9728276f7ae8882255780f42fa36119fac26a4ca0cfbe813b6814afc8'
assert sha(SOURCE/'source.safe.zip')=='bead1b2be6fc92242ec78aae79965f77418f35b71e59d5e9e38b7f846c4ebe0d'
m=json.loads((SOURCE/'manifest.safe.json').read_text())
expected={}
for row in m['files']:
    path=SOURCE/row['path'];s=path.lstat()
    assert path.parent==SOURCE and stat.S_ISREG(s.st_mode) and s.st_nlink==row['nlink']==1
    assert s.st_size==row['bytes'] and stat.S_IMODE(s.st_mode)==int(row['mode'],0) and sha(path)==row['sha256']
    expected[row['path']]=row['sha256']
expected['manifest.safe.json']=sha(SOURCE/'manifest.safe.json')
with zipfile.ZipFile(SOURCE/'source.safe.zip') as z:
    assert len(z.infolist())==6 and z.testzip() is None and set(z.namelist())==set(expected)
    for name in z.namelist():assert hashlib.sha256(z.read(name)).hexdigest()==expected[name]
ready=json.loads((SOURCE/'READY.safe.json').read_text())
for path,digest in ready['pinned_source_hashes'].items():
    assert 'private' not in Path(path).parts and sha(Path(path))==digest
s=(WRAPPER/'webkit-custom-exec.py').lstat()
assert stat.S_IMODE(s.st_mode)==0o555 and s.st_nlink==1 and sha(WRAPPER/'webkit-custom-exec.py')==ready['wrapper_sha256']
tree=ast.parse((SOURCE/'run-probe.py').read_text())
main=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='main')
fns=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in ['require','instant']]
initial=[n for n in main.body if 85<=n.lineno<=88]
allocation=[n for n in main.body if 120<=n.lineno<=131]
assert len(initial)==3 and len(allocation)==9
clock=[9]
epoch=datetime.datetime(2026,10,12,tzinfo=datetime.timezone.utc)
class FakeClock(datetime.datetime):
    @classmethod
    def now(cls,tz=None):return epoch+datetime.timedelta(seconds=clock[0])
writes=[]
class MockPath:
    def __init__(self,value):self.value=value
    def __truediv__(self,name):return MockPath(self.value+'/'+name)
    def exists(self):return False
    def mkdir(self,**kwargs):writes.append(dict(path=self.value,clock=clock[0],options=kwargs))
scope=dict(datetime=types.SimpleNamespace(datetime=FakeClock),UTC=datetime.timezone.utc,
           grant=dict(issued_at=epoch.isoformat(),absolute_stop_at=(epoch+datetime.timedelta(seconds=10)).isoformat(),expires_at=(epoch+datetime.timedelta(seconds=20)).isoformat(),attempt='attempt-01'),
           BASE=MockPath('/mock/own'),private_directory=lambda p:None)
exec(compile(ast.Module(body=fns+initial,type_ignores=[]),'selected_initial_grant_clock','exec'),scope)
clock[0]=11 # Intervening unchanged source/runtime hash preflight consumes the remaining lease.
exec(compile(ast.Module(body=allocation,type_ignores=[]),'selected_first_namespace_effects','exec'),scope)
assert len(writes)==6 and all(r['clock']>10 for r in writes)
wrapper_grant=dict(browser_launch_authorized=True,library_extraction_authorized=False,native_validation_authorized=False,
                   execution_actor_uid=1000,execution_actor_gid=1000,not_before_utc=epoch.isoformat(),stop_utc=(epoch+datetime.timedelta(seconds=20)).isoformat(),
                   declared_browser_environment=ready['required_wrapper_environment'])
outer=scope['stop'];scope['browser_grant']=wrapper_grant
binding=next(n for n in main.body if n.lineno==204)
clock[0]=9
exec(compile(ast.Module(body=[binding],type_ignores=[]),'selected_outer_wrapper_time_binding','exec'),scope)
wrapper_tree=ast.parse((WRAPPER/'webkit-custom-exec.py').read_text())
validator=next(n for n in wrapper_tree.body if isinstance(n,ast.FunctionDef) and n.name=='validate_browser_grant')
wrapper_scope=dict(datetime=datetime,SAFE_ENV={'PATH','LANG','LC_ALL','HOME','TMPDIR','XDG_CONFIG_HOME','XDG_CACHE_HOME'})
exec(compile(ast.Module(body=[validator],type_ignores=[]),'selected_wrapper_grant_validator','exec'),wrapper_scope)
late=epoch+datetime.timedelta(seconds=11)
assert wrapper_scope['validate_browser_grant'](wrapper_grant,late)==ready['required_wrapper_environment'] and late>outer
record=dict(outcome='CHANGES_REQUESTED',finding='WEBKIT-PUBLIC-GRANT-USE-TIME',severity='P2',
 source_manifest=sha(SOURCE/'manifest.safe.json'),source_ready=sha(SOURCE/'READY.safe.json'),source_zip=sha(SOURCE/'source.safe.zip'),
 seal_members=5,zip_members=6,pinned_public_sources=len(ready['pinned_source_hashes']),
 counterexamples=[dict(case='expire_during_preflight_before_namespace',initial_clock=9,outer_stop=10,post_preflight_clock=11,mocked_mkdir_effects=writes,confirmed=True),
                  dict(case='outer_grant_accepts_later_wrapper_stop',outer_stop=10,wrapper_stop=20,binding_check_accepted_at=9,wrapper_validator_accepts_at=11,confirmed=True)],
 native_browser_Node_target_import_network_or_actual_runtime_mkdir=0,
 scope='Small public WebKit boot source only; existing native43 proof not replayed',
 selected_model_effort='gpt-6.1-sol/high',actual_metadata='UNKNOWN')
(OWN/'checks.safe.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(dict(outcome=record['outcome'],finding=record['finding'],counterexamples=2,native_calls=0)))
