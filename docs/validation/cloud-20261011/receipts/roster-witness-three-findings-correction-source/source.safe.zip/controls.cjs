const fs = require('node:fs');
const vm = require('node:vm');
const crypto = require('node:crypto');
const own = require('./witness-detail-lookup.cjs');
const old = fs.readFileSync(__dirname + '/before-witness.cjs', 'utf8');
const marker = 'RCT_PUBLIC_WITNESS_' + crypto.randomUUID();
const rows = [];
function check(code, value) { rows.push({ code, passed: value === true }); }
function denied(f) { try { f(); return false; } catch { return true; } }
const body = detail => ({ status: 503, type: 'https://api.rutcampustrack.ru/problems/service-unavailable', detail });
const classify = (status, value) => own.classifyWitness(status, Buffer.from(JSON.stringify(value)));
const oldBlock = old.slice(old.indexOf('    facts.boundary ='), old.indexOf("    stage = 'CLASSIFIED';"));
const oldClassify = new Function('witness', 'facts', oldBlock + ';return facts;');
const malformed = body('Academic Service unavailable: Status{code=UNAUTHENTICATED, garbage}');
const positive = body('Academic Service unavailable: Status{code=UNAUTHENTICATED, description=' + marker + ', cause=null}');
const oldBad = oldClassify({ status: 200, body: malformed }, {});
check('OLD_WRONG_STATUS_AND_MALFORMED_CLASSIFIED', oldBad.boundary === 'ATTENDANCE_DEPENDENCY' && oldBad.rpc === 'UNAUTHENTICATED');
const good = classify(503, positive);
check('CURRENT_CANONICAL_PRIVATE_DESCRIPTION', good.boundary === 'ATTENDANCE_DEPENDENCY' && good.dependency === 'ACADEMIC' && good.rpc === 'UNAUTHENTICATED' && good.operationHint === 'UNKNOWN' && !JSON.stringify(good).includes(marker));
check('CURRENT_MALFORMED_RPC_UNKNOWN', classify(503, malformed).rpc === 'UNKNOWN');
check('CURRENT_WRONG_HTTP_UNKNOWN', classify(200, positive).boundary === 'OTHER');
check('CURRENT_UNKNOWN_ISSUER_UNKNOWN', classify(503, { status: 503, detail: positive.detail }).rpc === 'UNKNOWN');
check('CURRENT_GATEWAY_WRONG_DETAIL_UNKNOWN', classify(503, { status: 503, code: 'DEPENDENCY_UNAVAILABLE', detail: marker }).boundary === 'OTHER');
function page(key, ids, changes = {}) { return { _embedded: { [key]: ids.map(id => ({ id })) }, page: { number: 0, size: 100, totalElements: ids.length, totalPages: 1, ...changes } }; }
const oldPageGate = new Function('read', 'need', old.match(/need\(!read\.body\.page \|\| read\.body\.page\.totalPages <= 1\);/)[0]);
check('OLD_MISSING_USER_METADATA_ACCEPTED', !denied(() => oldPageGate({ body: { _embedded: { userResponseList: [{ id: 1 }] } } }, value => { if (!value) throw 0; })));
const oldItems = vm.runInNewContext('(' + old.match(/function items\(v, key\) \{[^\n]+\}/)[0] + ')');
check('OLD_PARTIAL_LESSON_ACCEPTED', oldItems(page('lessonResponseList', [1], { totalPages: 2 }), 'lessonResponseList').length === 1);
check('CURRENT_COMPLETE_USER_PAGE', own.completePage(page('userResponseList', [1, 2]), 'userResponseList').length === 2);
check('CURRENT_MISSING_METADATA_DENIED', denied(() => own.completePage({ _embedded: { userResponseList: [{ id: 1 }] } }, 'userResponseList')));
check('CURRENT_MULTIPAGE_USER_DENIED', denied(() => own.completePage(page('userResponseList', [1], { totalPages: 2 }), 'userResponseList')));
check('CURRENT_MULTIPAGE_LESSON_DENIED', denied(() => own.completePage(page('lessonResponseList', [1], { totalPages: 2 }), 'lessonResponseList')));
check('CURRENT_TRUNCATED_PAGE_DENIED', denied(() => own.completePage(page('lessonResponseList', [1], { totalElements: 2 }), 'lessonResponseList')));
check('CURRENT_DUPLICATE_ID_DENIED', denied(() => own.completePage(page('userResponseList', [1, 1]), 'userResponseList')));
function response(status, value) { return { status: () => status, headers: () => ({}), body: async () => Buffer.from(JSON.stringify(value)), dispose: async () => {} }; }
function handle(owner, options = {}) {
  let cookie = false; let logoutMatched = false;
  const token = marker + owner;
  const context = {
    fetch: async (route, request) => {
      if (request.maxRedirects !== 0 || request.maxRetries !== 0) throw 0;
      if (route === '/api/auth/login') { cookie = true; return response(200, { accessToken: token }); }
      if (route === '/api/auth/session') return response(403, {});
      throw 0;
    },
    storageState: async () => ({ cookies: cookie ? [{ name: 'rct_refresh' }] : [] }),
    post: async (route, request) => {
      logoutMatched = cookie && request.headers.Authorization === 'Bearer ' + token;
      if (options.unowned) cookie = false;
      const status = options.logoutFailure ? 401 : 204;
      if (status === 204) cookie = false;
      return response(status, {});
    },
    dispose: async () => { if (options.disposeFailure) throw 0; },
  };
  const value = { owner, context, token: undefined, tokens: new Set(), loginIssued: false };
  return { value, matches: () => logoutMatched };
}
async function main() {
  const oldAdmitSource = old.slice(old.indexOf('async function admit('), old.indexOf('(async () =>'));
  const oldAdmit = new Function('call', 'need', oldAdmitSource + ';return admit;')(
    async (_method, route) => route === '/api/auth/login' ? { status: 200, body: { accessToken: marker } } : { status: 403, body: {} },
    value => { if (!value) throw 0; },
  );
  let oldToken;
  try { oldToken = (await oldAdmit({ login: marker, password: marker }, 'HEADMAN')).token; } catch {}
  check('OLD_POST_LOGIN_GATE_LOSES_OWNED_TOKEN', oldToken === undefined);
  const admin = handle('ADMIN'); const actor = handle('HEADMAN');
  for (const item of [admin, actor]) {
    try { await own.admit(item.value, { login: marker, password: marker }, item.value.owner); } catch {}
    check('CURRENT_PROVISIONAL_' + item.value.owner + '_OWNED', item.value.loginIssued && item.value.tokens.size === 1 && !!item.value.token);
  }
  const actorClean = await own.cleanup(actor.value); const adminClean = await own.cleanup(admin.value);
  check('CURRENT_TWO_CONTEXTS_MATCH_OWN_COOKIE_AND_BEARER', actor.matches() && admin.matches() && actorClean.logoutConfirmed && adminClean.logoutConfirmed);
  check('CURRENT_TOKENS_CLEARED_AND_DISPOSED', actor.value.tokens.size === 0 && actor.value.token === undefined && admin.value.tokens.size === 0 && actorClean.contextDisposed && adminClean.contextDisposed);
  for (const [code, options] of [['LOGOUT_FAILURE', { logoutFailure: true }], ['DISPOSE_FAILURE', { disposeFailure: true }]]) {
    const item = handle('HEADMAN', options);
    try { await own.admit(item.value, { login: marker, password: marker }, 'HEADMAN'); } catch {}
    const result = await own.cleanup(item.value);
    check('CURRENT_' + code + '_NOT_CLEANUP_PASS', !(result.logoutConfirmed && result.contextDisposed));
  }
  const unowned = handle('HEADMAN'); unowned.value.loginIssued = true;
  const noAuth = await own.cleanup(unowned.value);
  check('CURRENT_UNOWNED_NOOP_204_NOT_CONFIRMED', noAuth.logoutStatus === '204' && !noAuth.logoutConfirmed);
  const result = { pass: rows.every(row => row.passed), count: rows.length, failed: rows.filter(row => !row.passed).length, controls: rows, qualification: 'Actual corrected source functions and extracted old source seams/public API adapters only; no transport/API/browser/credentials/client acceptance.' };
  check('RECEIPT_HAS_NO_PUBLIC_PRIVATE_MARKER', !JSON.stringify(result).includes(marker));
  result.pass = rows.every(row => row.passed); result.count = rows.length; result.failed = rows.filter(row => !row.passed).length;
  fs.writeFileSync(process.env.RCT_WITNESS_CONTROL_RECEIPT, JSON.stringify(result, null, 2) + '\n', { flag: 'wx', mode: 0o600 });
  process.exitCode = result.pass ? 0 : 1;
}
main().catch(() => { process.exitCode = 1; });
