from pathlib import Path, PurePosixPath
import json, urllib.request, zipfile, io, hashlib, collections, os, re
O=Path('/workspace/scratch/rct-validation/ci_c16_receipts')
INPUT=O/'.safe-download-inputs.private.json'
HEAD='c16a2995a3a830e5c0c4a0acf9cba4073aa212a2'
STATUSES={'PASSED','FAILED','ERROR','SKIPPED','NOT_EXECUTED'}
old=Path('/workspace/scratch/rct-validation/ci_eb0_receipts')
baseline=json.loads((old/'safe-unit-outcomes-academic-service-1.json').read_text())
allowed={k:set(baseline[k]) for k in ['metadata','collection','summary']}
top=set(baseline)
xmlkeys=set(baseline['xml'][0]);suitekeys=set(baseline['xml'][0]['suites'][0])
casekeys=set().union(*(set(c) for p in old.glob('safe-*-outcomes-*.json') for c in json.loads(p.read_text())['cases']))
summaries=[];schema=[];skips=[]
def safe_write(name,b):
 p=O/name
 if p.exists():
  assert p.read_bytes()==b
  return
 f=os.open(p,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
 with os.fdopen(f,'wb') as out:out.write(b)
try:
 inputs=json.loads(INPUT.read_text());assert len(inputs)==12
 for a in inputs:
  assert re.fullmatch(r'safe-(unit|integration)-outcomes-(academic-service|auth-service|attendance-service|notification-service|schedule-service|api-gateway)-1',a['name'])
  assert 0<a['bytes']<=1048576
  prior=O/(a['name']+'.zip')
  if prior.exists():b=prior.read_bytes()
  else:
   with urllib.request.urlopen(a['url'],timeout=30) as response:b=response.read(1048577)
  assert len(b)<=1048576 and len(b)==a['bytes']
  digest=hashlib.sha256(b).hexdigest();assert 'sha256:'+digest==a['digest']
  with zipfile.ZipFile(io.BytesIO(b)) as z:
   assert z.testzip() is None and len(z.infolist())==1
   item=z.infolist()[0];assert item.file_size<=1048576 and item.filename.endswith('.json')
   d=json.loads(z.read(item))
  assert set(d)==top and d['schemaVersion']==1
  for k in allowed:assert set(d[k])==allowed[k]
  assert d['metadata']['prHeadSha']==HEAD and d['metadata']['runId']=='38272615834'
  assert re.fullmatch('[0-9a-f]{40}',d['metadata']['checkoutSha'])
  counts=collections.Counter(c['status'] for c in d['cases']);xmlcounts=collections.Counter()
  for x in d['xml']:
   assert set(x)<=xmlkeys and x['state']=='PARSED'
   for s in x['suites']:
    assert set(s)==suitekeys and set(s['observed'])==STATUSES and s['countsConsistent'] is True
    xmlcounts.update(s['observed'])
  for c in d['cases']:
   assert set(c)<=casekeys and c['status'] in STATUSES
   assert c['identity'] in {'SOURCE_METHOD','ORDINAL_ONLY'}
   if c.get('source'):
    q=PurePosixPath(c['source']);assert not q.is_absolute() and '..' not in q.parts
    assert re.fullmatch('[0-9a-f]{64}',c['sourceSha256'])
   if c['identity']=='SOURCE_METHOD':assert re.fullmatch('[A-Za-z_$][A-Za-z0-9_$]*',c['method'])
   if c['status']!='PASSED':skips.append({'artifact':a['name'],**c})
  assert all(counts[k]==d['summary'][k]==xmlcounts[k] for k in STATUSES)
  safe_write(a['name']+'.zip',b)
  safe_write(a['name']+'.json',(json.dumps(d,indent=2)+'\n').encode())
  summaries.append({'artifact_id':a['id'],'name':a['name'],'bytes':len(b),'digest':digest,'metadata':d['metadata'],
                    'xml_count':len(d['xml']),'totals':d['summary'],'counts_consistent':True,'collection':d['collection']})
  schema.append({'artifact':a['name'],'schema_keys_valid':True,'case_summary_XML_consistent':True,
                 'source_method_cases':sum(c['identity']=='SOURCE_METHOD' for c in d['cases']),
                 'ordinal_only_cases':sum(c['identity']=='ORDINAL_ONLY' for c in d['cases']),
                 'request_body_raw_XML_display_names_persisted':False})
 safe_write('safe-native-partial.json',(json.dumps({'producer':HEAD,'artifacts':summaries,'acceptance':'NOT_ASSESSED'},indent=2)+'\n').encode())
 safe_write('safe-schema-checks.json',(json.dumps({'checks':schema,'count':len(schema)},indent=2)+'\n').encode())
 safe_write('native-explicit-skips.json',(json.dumps(skips,indent=2)+'\n').encode())
 print(json.dumps({'status':'SAFE_ARTIFACTS_VERIFIED','artifacts':len(summaries),'checkouts':sorted({s['metadata']['checkoutSha'] for s in summaries}),
  'totals':{k:sum(s['totals'][k] for s in summaries) for k in sorted(STATUSES)}}))
except Exception as failure:
 print(json.dumps({'status':'SAFE_COLLECTION_BLOCKED','safe_error_type':type(failure).__name__,
  'http_status':getattr(failure,'code',None),'completed_SAFE_scopes':len(summaries)}))
 raise SystemExit(1)
finally:INPUT.unlink(missing_ok=True)
