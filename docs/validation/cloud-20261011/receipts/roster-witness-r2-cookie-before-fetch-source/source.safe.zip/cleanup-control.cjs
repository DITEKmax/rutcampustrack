const fs = require('node:fs');
const old = require('./before-r1-witness.cjs');
const current = require('./witness-detail-lookup.cjs');
function ownedPublicHandle() {
  let cookie = false; let logoutCalls = 0;
  const context = {
    fetch: async () => { cookie = true; throw new Error('PUBLIC_FETCH_BODY_REJECT'); },
    storageState: async () => ({ cookies: cookie ? [{ name: 'rct_refresh' }] : [] }),
    post: async (_route, options) => {
      if (!cookie || options.headers.Authorization !== undefined || options.maxRedirects !== 0 || options.maxRetries !== 0) throw 0;
      logoutCalls++; cookie = false;
      return { status: () => 204, dispose: async () => {} };
    },
    dispose: async () => {},
  };
  return { handle: { owner: 'HEADMAN', context, token: undefined, tokens: new Set(), loginIssued: false, loginAttempted: false }, cookie: () => cookie, logoutCalls: () => logoutCalls };
}
async function probe(source) {
  const item = ownedPublicHandle();
  try { await source.call(item.handle, 'POST', '/api/auth/login', { login: 'PUBLIC', password: 'PUBLIC' }); } catch {}
  const beforeCleanupOwnedCookie = item.cookie();
  const result = await source.cleanup(item.handle);
  return { beforeCleanupOwnedCookie, logoutConfirmed: result.logoutConfirmed, contextDisposed: result.contextDisposed, logoutStatus: result.logoutStatus, cookieStillPresent: item.cookie(), logoutCalls: item.logoutCalls(), attempted: item.handle.loginAttempted };
}
(async () => {
  const before = await probe(old), after = await probe(current);
  const rows = [
    { code: 'OLD_COOKIE_BEFORE_REJECTION_FALSE_NOOP_CONFIRMATION', passed: before.beforeCleanupOwnedCookie && before.logoutConfirmed && before.logoutStatus === 'NOT_NEEDED' && before.cookieStillPresent && before.logoutCalls === 0 },
    { code: 'CURRENT_ATTEMPT_OWNED_BEFORE_FETCH', passed: after.attempted && after.beforeCleanupOwnedCookie },
    { code: 'CURRENT_OWN_COOKIE_LOGOUT_CONFIRMED_AND_DISPOSED', passed: after.logoutCalls === 1 && after.logoutStatus === '204' && after.logoutConfirmed && after.contextDisposed && !after.cookieStillPresent },
  ];
  const result = { pass: rows.every(row => row.passed), count: rows.length, failed: rows.filter(row => !row.passed).length, controls: rows, before, after, qualification: 'Actual oldr1/newr2 functions with public cookie-before-fetch-reject adapter; no real HTTP/auth/credentials/client acceptance.' };
  fs.writeFileSync(process.env.RCT_WITNESS_CONTROL_RECEIPT, JSON.stringify(result, null, 2) + '\n', { flag: 'wx', mode: 0o600 });
  process.exitCode = result.pass ? 0 : 1;
})().catch(() => { process.exitCode = 1; });
