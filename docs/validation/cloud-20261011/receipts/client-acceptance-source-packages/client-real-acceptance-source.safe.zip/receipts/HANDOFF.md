# Current real-client acceptance harness — source handoff

SOURCE_PREPARED_NOT_ACCEPTED. Branch `codex/client-real-acceptance-20261012`, commit `a8474924894c51ff65d510dc8ef5b2af301efa3e`, exact frozen base `cd3f237acffd4f0b9dd2a74babb2ee822376f0cb`. Requested Sol6.1/xhigh; actual model metadata UNKNOWN. Sole sparse worktree `/workspace/rct-worktrees/client-real-acceptance`; receipt directory `/workspace/scratch/rct-validation/client_real_acceptance`.

The change adds 14 finite current-Vue/real-server browser scenarios. No application code, API, lock, existing fixture, existing config or Root task document changed. Runtime, discovery, full typecheck, fault sensitivity and independent review are NOT_RUN/PENDING. All eleven CLIENT groups remain UNKNOWN; this package does not close a family or claim DONE.

## Observable finite operations

- A synthetic account really has STUDENT/HEADMAN/TEACHER/FULL-ADMIN grants. Login defaults to STUDENT. An assistant command is denied before selecting HEADMAN and leaves no assistant grant; the same command succeeds after the actual role switch. A stale expected session version returns exactly409/SESSION_VERSION_CONFLICT. HEADMAN/ADMIN survive PWA reload.
- Four separate synthetic STUDENT helpers receive only VIEW_STATS, MANAGE_HOMEWORK, CANCEL_LESSONS or MANAGE_EXCUSES. They render their current Vue surface, perform their permitted read/edit/cancel/decision, and retain no marking capability. Revoked requests return403 with retained homework revision/title, CANCELLED lesson, or PENDING request/decision revision. Existing MARK_ATTENDANCE case is reused, not copied.
- A LIMITED admin edits an ordinary user through Vue with USERS_VIEW+USERS_MANAGE, has no credential controls/password text, and cannot issue a reset link. Removing management denies the old bearer and retains profile fields; reload recovers as a viewer.
- FULL and LIMITED USERS_VIEW admins select HTML in the actual export component. Real durable job202, ready ticket200, MIME/content/filename and actual browser download are observed. One filtered synthetic row, FULL-only TelegramID and zero passwords/reset links are checked in memory. Foreign job/file requests and LIMITED later status/ticket/file/capability fetch after grant removal return403. Only HTML bytes are covered; the five-format catalogue is checked without pretending other four formats were executed.
- Five correctly signed negative TMA proofs isolate absent/non-numeric/overflow/future/expired auth_date. Actual TMA401, rendered failure, absent role/navigation/cookie and empty browser-context refresh401 are required. A fresh linked teacher first opens the real Vue owner, then real Academic PUT clears binding; reusing the signed proof returns401 with no new owner/cookie. Existing signed reuse/tampered cases are reused. Exact86400 age boundary, duplicate parameter policy and native provider remain separate.

`scenario-oracle-map.json` contains exact IDs, source references/hashes, data preparation and oracle for every named finite case. It uses scenarios.csv, boundary-scenarios.csv and dated decisions; historical flattened source_paths were not used as paths.

## Source coverage and remaining work

`assessment.json` records the eight existing real-mobile cases against eleven groups. Existing source intent covers own completion/reload/foreign denial; journal/PNG and teacher read/write denial; MARK_ATTENDANCE/revoke; LIMITED viewer/create denial; empty/retry; two-session revoke; D003 reuse/suspended neutral bootstrap; D002 warm service-worker homework/read-only/reconnect/A→B/logout.

Significant remaining slices include password/change/reset/OTP/history/terminal roles and token expiry; successful geo/manual/automatic student request UI and teaching-clock boundaries; homework publication/next lesson/transfer/archive/order/links; schedule construction/subject lifecycle/roster and full helper exports; teacher full journal/stats/export scopes; other FULL/LIMITED grant families, maps/semesters/credentials; map version/SVG safety, four other registry formats/distinct report models; inbox/preferences/actions and open WS revocation; offline schedule/date rollover/no new attachment/no role switch/TMA offline/late callbacks; install/update/push and available native provider. The new request setup is HTTP preparation, not student browser acceptance. No native device gate is invented.

## Integration dependency and future command

Root must coordinate one existing config hunk before integration: in `tests/e2e/playwright.config.ts`, extend
`testIgnore: /mobile-real-server\.spec\.ts/` to
`testIgnore: /mobile-real-server\.spec\.ts|cloud-accepted-.*\.spec\.ts/`.
The new package is explicitly opt-in. That existing file was read-only in this assignment, so the hunk is NOT applied here. Without it, ordinary default discovery can pick up these source-only cases; the canonical privacy guard refuses the unsafe default reporter before generating credentials.

After independent review, correct current-namespace E2E dependencies, current relevant producer hashes, shared healthy genuine production Vue/server/DB/queue/native renderer/edge configuration, exact synthetic seed/clock/TLS review and Root runtime grant:

```sh
cd /workspace/rutcampustrack/tests/e2e
RCT_E2E_SYNTHETIC_SEED=true E2E_BASE_URL=https://localhost:8443 node node_modules/playwright/cli.js test --config fixtures/cloud-accepted-playwright.ts --project=chromium
```

The new config has one worker, no retries/parallel dataset writers, 390×844 viewport, canonical safe reporter, traces/video/screenshots off. It inherits the exact HTTPS loopback:8443 + opt-in guard and RNG synthetic credentials from current MobileDataset. WebKit is a separate actual capability admission. Existing browser metadata lists Chromium1217/WebKit2272 cache entries, browser_launch=false and prior WebKit library warnings; it is not a launch/dependency PASS. No downloads, installs, app/browser/JVM/Docker/key/network actions were performed here.

## Verification and quality

Current-source TypeScript5.9.3 createSourceFile/transpileModule:7 files,0 diagnostics. Source policy inspection:0 page.route API mocks, skip/fail/fixme/only declarations, attachments, logging or waitForTimeout; all relative current-source imports resolve. This is syntax preparation, not full typecheck. The Root current E2E module namespace is absent; historical @rct source/type/artifact aliases were not used.

Pinned Prettier3.6.2 cache was used as a read-only tool only, with formatter-owner current config; check native0. Staged diff whitespace check native0. See `source-verification.json`, `verification-receipt.json`, `format-check-final.log`. Rechecks followed concrete source corrections; there was no browser run/retry. Common Git hooks contain samples only; no mandatory gate was changed or disabled.

`counterexamples.json` records author corrections: negative TMA refresh moved off seeded API cookie; stale-version request ordered before reload; roster restriction limited to accepted export rule; cancellation isolates lesson8 so later mark oracles remain meaningful. Failures report only sanitized metadata through the inherited policy. Credentials, bearer values, signed proof, Telegram identity and download capability/body stay in memory; no body/secret assertion value is exported. The public CI signing placeholder is the existing synthetic adapter contract.

## Controlled sensitivity plan — no mutations executed

Under a future separate Root resource/fault grant, use an isolated exact-source fault worktree and NEW synthetic data, one narrow fault at a time, with recorded red→restored green and relevant producer hashes:

1. `ActiveRolePolicy.evaluate`: temporarily select ADMIN in the default branch instead of STUDENT. CRA-ROLE-01 must fail its default and wrong-selected-role oracle; restore and rerun only that case with the positive HEADMAN command.
2. `TmaService.authenticateWithInitData`: bypass only the future/max-age condition. CRA-TMA-FUTURE/EXPIRED must fail at200/exposed owner; restore, rerun them plus existing valid D003 control. Malformed parser controls must still deny.
3. `HomeworkService` assistant admission: temporarily ignore revoked MANAGE_HOMEWORK for the synthetic group. CRA-HELPER-HW must fail403/no-effect and expose changed durable revision/title; restore and rerun that case.
4. `LessonService` CANCEL_LESSONS admission: temporarily ignore revoked permission for the synthetic lesson. CRA-HELPER-CANCEL must fail denied restore/retained cancellation; restore and recheck it.
5. `StudentRequestService` MANAGE_EXCUSES admission: temporarily ignore revocation for the synthetic pending request. CRA-HELPER-EXCUSE must fail403/unchanged decision revision; restore and recheck it.
6. `AdminAccessProfile`/live permission lookup: narrowly allow USERS_MANAGE or credentials after removed/absent grant. CRA-ADMIN-GRANT must fail exact403/retained profile or credential state; restore and recheck it.
7. `AdminRegistryExportService.users`: temporarily include the Telegram column for LIMITED. CRA-EXPORT-LIMITED must fail the in-memory field oracle. Separately bypass only `RegistryExportAdmission.requireCurrent` USERS_VIEW check to exercise retained capability denial. Restore and rerun LIMITED plus FULL field positive control.

These are plans, not product defects or executed sensitivity PASS. Privacy controls themselves remain the existing dedicated browser-free suite; do not run credential-bearing browser tests with an ordinary reporter.

## Inventory and resources

Created, tests/harness only:

- `/workspace/rct-worktrees/client-real-acceptance/tests/e2e/fixtures/cloud-accepted-playwright.ts`
- `/workspace/rct-worktrees/client-real-acceptance/tests/e2e/fixtures/cloud-accepted-support.ts`
- `/workspace/rct-worktrees/client-real-acceptance/tests/e2e/specs/cloud-accepted-admin-grants.spec.ts`
- `/workspace/rct-worktrees/client-real-acceptance/tests/e2e/specs/cloud-accepted-helper-capabilities.spec.ts`
- `/workspace/rct-worktrees/client-real-acceptance/tests/e2e/specs/cloud-accepted-registry-export.spec.ts`
- `/workspace/rct-worktrees/client-real-acceptance/tests/e2e/specs/cloud-accepted-role-authority.spec.ts`
- `/workspace/rct-worktrees/client-real-acceptance/tests/e2e/specs/cloud-accepted-tma-proof.spec.ts`

Modified existing: none. Deleted: none. Product: none. Root CSV/docs/config/locks/API untouched. Receipt/inventory/source hashes are in this own scratch directory and the safe transfer archive; Root owns persistence into task docs/PR. Sparse WT7.8MiB, receipt package bounded below64MiB. No processes, containers or child agents retained. No push/main integration/deploy.
