const fs = require('node:fs')
const path = require('node:path')
class SafeDiscoveryReporter {
  printsToStdio() { return true }
  onBegin(config, suite) {
    this.config = config
    this.tests = suite.allTests().map(test => ({
      id: test.id,
      file: path.relative('/workspace/rct-worktrees/client-real-acceptance', test.location.file),
      line: test.location.line,
      project: test.parent.project().name,
    }))
  }
  onError(error) {
    this.errors = (this.errors || 0) + 1
    if (error.location) (this.locations ||= []).push({file:path.basename(error.location.file),line:error.location.line})
  }
  onTestBegin() { throw new Error('Discovery must not execute tests') }
  onEnd(result) {
    const row = {
      status: result.status,
      mode: 'list-only, no browser/API/fixture execution',
      tests: this.tests || [],
      count: (this.tests || []).length,
      errorCount: this.errors || 0,
      errorLocations: this.locations || [],
      projects: (this.config?.projects || []).map(project => ({name:project.name,testDir:project.testDir,trace:project.use.trace,video:project.use.video,screenshot:project.use.screenshot})),
    }
    const target = process.env.RCT_DISCOVERY_RECEIPT
    if (!target || !path.isAbsolute(target) || !target.startsWith('/workspace/scratch/rct-validation/client_real_acceptance/')) throw new Error('Own safe discovery receipt required')
    fs.writeFileSync(target, JSON.stringify(row,null,2)+'\n')
    process.stdout.write(JSON.stringify({status:row.status,count:row.count,errorCount:row.errorCount,mode:row.mode})+'\n')
  }
}
module.exports = SafeDiscoveryReporter
