"""Narrow independent lifecycle recheck: selected original functions, all effects RAM mocked."""
import ast
import hashlib
import json
import os
from pathlib import Path
import stat
from types import SimpleNamespace

HERE = Path(__file__).resolve().parent
OLD = Path('/workspace/scratch/rct-validation/client_session_offline_acceptance/p10-current1742-failure-frame-source')
NEW = OLD.with_name(OLD.name + '-lifecycle-r1')
old_text, new_text = (OLD / 'logged-green-child.py').read_text(), (NEW / 'logged-green-child.py').read_text()
old_tree, new_tree = ast.parse(old_text), ast.parse(new_text)
nodes = [n for n in new_tree.body if (isinstance(n, (ast.FunctionDef, ast.ClassDef)) and n.name in {'need', 'DiagnosticBlocked', 'observe_original_case'})
    or (isinstance(n, ast.Assign) and any(isinstance(t, ast.Name) and t.id in {'CLASS', 'METHOD', 'SOURCE_SHA', 'PRIMARY_REJECTION_CODES'} for t in n.targets))]
ns = {'stat': stat, 'json': json}
exec(compile(ast.Module(body=nodes, type_ignores=[]), '<sealed-observe-AST>', 'exec'), ns)
Blocked = ns['DiagnosticBlocked']
artifact = json.loads((NEW / 'metadata.safe.json').read_text())
plan = json.loads((NEW / 'green-plan.safe.json').read_text())
grant = {'original_artifact_observation_authorized': True, 'artifact_id': artifact['artifact_id'],
    'producer_head': artifact['head_sha'], 'actual_checkout': plan['actual_checkout'], 'selected_xml_projection_only': True}
base_request = {k: artifact[k] for k in ['artifact_id', 'run_id', 'name', 'size_bytes', 'head_sha']}
base_request.update(actual_checkout=plan['actual_checkout'], private_url='https://ram.invalid/RAM_PRIVATE_URL')

class DangerousError(RuntimeError):
    @property
    def code(self):
        raise AssertionError('GETTER_MUST_NOT_EXECUTE')
    def __str__(self):
        raise AssertionError('COERCION_MUST_NOT_EXECUTE')

class FakePath:
    def __init__(self, name):
        self.name = name
    def __truediv__(self, name):
        return FakePath(name)
    def read_text(self):
        return json.dumps(artifact) if self.name == 'metadata.safe.json' else 'source\n' * 1403
    def write_text(self, text):
        state['texts'][self.name] = text
    def stat(self, **kwargs):
        assert kwargs == {'follow_symlinks': False}
        state['stat_calls'] += 1
        if state['stat_error']:
            raise state['stat_error']
        return state['metadata']
    def unlink(self):
        state['unlink_calls'] += 1
        if state['unlink_error']:
            raise state['unlink_error']
        state['unlinked'] = True

class FakeStream:
    def __init__(self, target):
        self.target = target
    def __enter__(self):
        return self
    def __exit__(self, *args):
        return False
    def write(self, data):
        state['writes'][self.target] = data
        return len(data)

def fake_open(path, flags, mode):
    state['opens'].append({'target': path.name, 'flags': flags, 'mode': mode})
    if path.name == 'case-observation-lifecycle.safe.json' and state['receipt_error']:
        raise state['receipt_error']
    return path.name

class Response:
    def __enter__(self):
        return self
    def __exit__(self, *args):
        return False
    def read(self, amount):
        assert amount == 1024**2 + 1
        return b'x' * artifact['size_bytes']

def fake_urlopen(url, timeout):
    assert url == base_request['private_url'] and timeout == 30
    state['urlopen_calls'] += 1
    return Response()

def owned_request(_):
    if state['admission_error']:
        raise state['admission_error']
    return state['request'], (7, 11)

ns.update(Path=lambda name: FakePath(name),
    os=SimpleNamespace(geteuid=lambda: 1000, open=fake_open, fdopen=lambda fd, mode: FakeStream(fd),
        O_WRONLY=os.O_WRONLY, O_CREAT=os.O_CREAT, O_EXCL=os.O_EXCL, O_NOFOLLOW=os.O_NOFOLLOW),
    admit_child=lambda _: (plan, FakePath('run')), owned_request=owned_request,
    digest=lambda path: plan['metadata_sha256'] if path.name == 'metadata.safe.json' else ns['SOURCE_SHA'],
    private_json=lambda path: {'grant_path': 'RAM_GRANT'} if path.name == 'parent-authority.private.json' else grant,
    urllib=SimpleNamespace(parse=SimpleNamespace(urlsplit=lambda _: SimpleNamespace(scheme='https', hostname='ram.invalid', username=None, password=None, fragment='')),
                           request=SimpleNamespace(urlopen=fake_urlopen)),
    selected_xml_from_zip=lambda _: b'RAM_PRIVATE_XML_NEVER_EXPORTED',
    selected_xml_projection=lambda *_: {'schema': 'RAM_SAFE_SELECTED_LOCATION_ONLY'}, print=lambda *args, **kwargs: None)

keys = {'schema', 'diagnostic_valid', 'primary_rejection', 'cleanup_rejection', 'cleanup_outcome',
    'request_reconciliation_required', 'no_private_message_context_or_values_export'}
results = {}
def run(label, *, primary='REQUEST_SCHEMA', mode=stat.S_IFREG | 0o600, uid=1000, links=1, inode=11,
        stat_error=None, unlink_error=None, admission_error=None, receipt_error=None):
    global state
    state = {'request': dict(base_request) if primary == 'NONE' else {'invalid_schema': True},
        'metadata': SimpleNamespace(st_dev=7, st_ino=inode, st_mode=mode, st_uid=uid, st_nlink=links),
        'stat_error': stat_error, 'unlink_error': unlink_error, 'admission_error': admission_error,
        'receipt_error': receipt_error, 'texts': {}, 'writes': {}, 'opens': [], 'stat_calls': 0,
        'unlink_calls': 0, 'unlinked': False, 'urlopen_calls': 0}
    terminal = 'NONE'
    try:
        ns['observe_original_case'](FakePath('scope'))
    except Blocked as error:
        terminal = error.code
    except BaseException:
        terminal = 'BOUNDARY_UNKNOWN'
    payload = state['writes'].get('case-observation-lifecycle.safe.json')
    if payload is not None:
        value = json.loads(payload)
        assert set(value) == keys and len(payload) <= 1024
        assert value['schema'] == 'P10_REQUEST_LIFECYCLE_V1'
        assert value['primary_rejection'] in ns['PRIMARY_REJECTION_CODES'] | {'NONE'}
        assert value['cleanup_rejection'] in {'NONE', 'REQUEST_CLEANUP_NOT_ADMITTED', 'REQUEST_CLEANUP_IDENTITY', 'REQUEST_CLEANUP_UNKNOWN'}
        assert value['cleanup_outcome'] in {'RETAINED_NOT_ADMITTED', 'ALREADY_ABSENT', 'REMOVED', 'RETAINED_METADATA_MISMATCH', 'RECONCILIATION_REQUIRED'}
        assert value['no_private_message_context_or_values_export'] is True
        assert b'RAM_PRIVATE' not in payload and b'GETTER' not in payload and b'COERCION' not in payload
        entry = next(e for e in state['opens'] if e['target'] == 'case-observation-lifecycle.safe.json')
        assert entry['flags'] == os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW and entry['mode'] == 0o600
    else:
        value = None
    results[label] = {'receipt': value, 'terminal_code': terminal, 'unlinked': state['unlinked'],
        'stat_calls': state['stat_calls'], 'unlink_calls': state['unlink_calls'], 'RAM_capture_calls': state['urlopen_calls'],
        'lifecycle_receipt_saved': payload is not None}
    return results[label]

r = run('own600_primary')
assert r['unlinked'] and r['terminal_code'] == 'REQUEST_SCHEMA' and r['receipt']['primary_rejection'] == 'REQUEST_SCHEMA' and r['receipt']['cleanup_rejection'] == 'NONE'
for label, kwargs in [('mode0644', {'mode': stat.S_IFREG | 0o644}), ('UID999', {'uid': 999}),
                     ('nlink2', {'links': 2}), ('inode_replaced', {'inode': 12}), ('symlink', {'mode': stat.S_IFLNK | 0o600})]:
    r = run(label, **kwargs)
    assert not r['unlinked'] and r['unlink_calls'] == 0 and r['terminal_code'] == 'REQUEST_SCHEMA'
    assert r['receipt']['primary_rejection'] == 'REQUEST_SCHEMA' and r['receipt']['cleanup_rejection'] == 'REQUEST_CLEANUP_IDENTITY'
    assert r['receipt']['request_reconciliation_required'] and not r['receipt']['diagnostic_valid']
r = run('capture_success', primary='NONE')
assert r['terminal_code'] == 'NONE' and r['unlinked'] and r['receipt']['diagnostic_valid']
r = run('cleanup_only_mode_denial', primary='NONE', mode=stat.S_IFREG | 0o644)
assert r['terminal_code'] == 'REQUEST_CLEANUP_IDENTITY' and not r['unlinked'] and not r['receipt']['diagnostic_valid']
for label, kwargs in [('stat_error_dual', {'stat_error': OSError('RAM_PRIVATE_STAT')}),
                     ('unlink_error_dual', {'unlink_error': PermissionError('RAM_PRIVATE_UNLINK')})]:
    r = run(label, **kwargs)
    assert r['terminal_code'] == 'REQUEST_SCHEMA' and not r['unlinked']
    assert r['receipt']['primary_rejection'] == 'REQUEST_SCHEMA' and r['receipt']['cleanup_rejection'] == 'REQUEST_CLEANUP_UNKNOWN'
r = run('unadmitted_known', admission_error=Blocked('REQUEST_METADATA'))
assert r['terminal_code'] == 'REQUEST_METADATA' and not r['unlinked'] and r['stat_calls'] == 0
assert r['receipt']['cleanup_outcome'] == 'RETAINED_NOT_ADMITTED'
r = run('unknown_code_closed', admission_error=Blocked('RAM_PRIVATE_UNKNOWN_CODE'))
assert r['terminal_code'] == 'BOUNDARY_UNKNOWN' and r['receipt']['primary_rejection'] == 'BOUNDARY_UNKNOWN'
r = run('getter_coercion_context_refused', admission_error=DangerousError('RAM_PRIVATE_CONTEXT'))
assert r['terminal_code'] == 'BOUNDARY_UNKNOWN' and r['receipt']['primary_rejection'] == 'BOUNDARY_UNKNOWN'
r = run('already_absent_primary', stat_error=FileNotFoundError('RAM_PRIVATE_ABSENT'))
assert r['terminal_code'] == 'REQUEST_SCHEMA' and r['receipt']['cleanup_outcome'] == 'ALREADY_ABSENT' and r['receipt']['cleanup_rejection'] == 'NONE'
r = run('unlink_only_failure', primary='NONE', unlink_error=PermissionError('RAM_PRIVATE_UNLINK'))
assert r['terminal_code'] == 'REQUEST_CLEANUP_UNKNOWN' and not r['unlinked'] and not r['receipt']['diagnostic_valid']
r = run('exclusive_receipt_unavailable_rejects', receipt_error=FileExistsError('RAM_PRIVATE_FOREIGN_RECEIPT'))
assert r['terminal_code'] == 'BOUNDARY_UNKNOWN' and r['lifecycle_receipt_saved'] is False

# Byte boundaries allow the unchanged accepted 17+6 parser controls to be reused.
checks = {}
for name, expected in json.loads((NEW / 'manifest.safe.json').read_text())['files'].items():
    checks['seal_' + name] = hashlib.sha256((NEW / name).read_bytes()).hexdigest() == expected
def without_changed_nodes(text, tree, new):
    lines = text.splitlines(keepends=True)
    intervals = [(n.lineno - 1, n.end_lineno) for n in tree.body if (isinstance(n, ast.FunctionDef) and n.name == 'observe_original_case')
        or (new and isinstance(n, ast.Assign) and any(isinstance(t, ast.Name) and t.id == 'PRIMARY_REJECTION_CODES' for t in n.targets))]
    for start, end in sorted(intervals, reverse=True):
        del lines[start:end]
    return ''.join(lines)
# The new constant has one extra separating blank line; remove only that delta.
old_inverse = without_changed_nodes(old_text, old_tree, False)
new_inverse = without_changed_nodes(new_text, new_tree, True)
checks['whole_inverse_only_allowed_blank_separator'] = new_inverse.replace('\n\n\n\n', '\n\n\n', 1) == old_inverse
for name in ['need', 'selected_xml_projection', 'selected_xml_from_zip', 'digest', 'private_json', 'identity', 'admit_child', 'owned_request']:
    a = next(n for n in old_tree.body if isinstance(n, ast.FunctionDef) and n.name == name)
    b = next(n for n in new_tree.body if isinstance(n, ast.FunctionDef) and n.name == name)
    checks['unchanged_' + name] = ast.get_source_segment(old_text, a) == ast.get_source_segment(new_text, b)
checks['unchanged_parent'] = (OLD / 'run-green-owned.py').read_bytes() == (NEW / 'run-green-owned.py').read_bytes()
checks['original_seal_immutable'] = hashlib.sha256((OLD / 'manifest.safe.json').read_bytes()).hexdigest() == '14eb04fcbd6f671f1a23a54099be85e62f30caf894ad0f41817d2f257550e505' and hashlib.sha256((OLD / 'SOURCE.safe.zip').read_bytes()).hexdigest() == '8c3324d42acb89b8314ab585dbea1fd6b5c1355345f3fc2ba8cfe0daa05e8c20'
checks['unchanged_caps'] = json.loads((OLD / 'grant-template.private.json').read_text())['limits'] == json.loads((NEW / 'grant-template.private.json').read_text())['limits']
checks['unchanged_metadata_manifest'] = all((OLD / n).read_bytes() == (NEW / n).read_bytes() for n in ['metadata.safe.json', 'source-manifest.safe.json'])
manifest = json.loads((NEW / 'source-manifest.safe.json').read_text())
wt = Path(plan['worktree'])
checks['18_source_pins'] = all(hashlib.sha256((wt / name).read_bytes()).hexdigest() == expected for name, expected in {**manifest['files'], **manifest['protected_files']}.items())
checks['b78_exact'] = hashlib.sha256(Path(plan['guard_path']).read_bytes()).hexdigest() == plan['guard_sha256']
checks['new_READY_exact'] = hashlib.sha256((NEW / 'READY.safe.json').read_bytes()).hexdigest() == '0dcb740d0fe0bd731eed44ed4ee14ce5ea9a9abc46040c404b2293a3c838e3b8'
checks['new_manifest_exact'] = hashlib.sha256((NEW / 'manifest.safe.json').read_bytes()).hexdigest() == 'fdc76b32c62b874f458fa303a7f66091aba77518efbdeb040ffed9be9f226a56'
checks['new_ZIP_exact'] = hashlib.sha256((NEW / 'SOURCE.safe.zip').read_bytes()).hexdigest() == '7967ed89797314fcade41613c2f91bd950a128dffd63b7f75249450752156d31'
assert all(checks.values()), {k: v for k, v in checks.items() if not v}
report = {'schema': 'P10_LIFECYCLE_NARROW_INDEPENDENT_AST_RAM_RECHECK_V1', 'verdict': 'APPROVE_SOURCE',
    'closed_findings': ['P10-REQUEST-CLEANUP-MODE', 'P10-PRIMARY-ERROR-MASKING'],
    'lifecycle16': results, 'boundary_checks': checks, 'unchanged17_plus6': 'REUSED_NOT_RERUN',
    'native': 'NOT_RUN', 'cause': 'UNKNOWN', 'actual_private_reads_network_or_metadata_mutations': 0,
    'limitation': 'Lifecycle receipt storage failure rejects observation; it cannot preserve a durable primary record when saving is unavailable. File-backed receipt is not a power-loss guarantee.'}
(HERE / 'controls.safe.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({'verdict': 'APPROVE_SOURCE', 'lifecycle_cases': len(results), 'boundaries_pass': all(checks.values()), 'native': 'NOT_RUN'}))
