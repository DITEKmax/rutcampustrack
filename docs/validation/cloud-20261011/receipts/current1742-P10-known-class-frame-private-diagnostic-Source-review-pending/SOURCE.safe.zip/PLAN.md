P10 current original CI failure frame — Source only

Reuse P06 parent c5af/b78 and exact old private direct-parent admission. New bounded child reads exactly one original AuthOtpFlowIT XML member in RAM, reuses reviewed strict UTF8/DTD/declaration gate, and emits only finite known exception class + first exact numeric AuthOtp frame/helper. No message parsing or private hashes.

Original artifact11806374316/run38387263916/head1742/currentcheckout38d7; selected Source104e/own5dac frozen. Full ZIP prefix is UNKNOWN until exact public workflow layout selection. Other members never opened/extracted.

17 targeted synthetic RAM controls PASS; original synthetic fixture construction checking FAIL retained. No original archive/XML/network or native process launched. Fresh independent privacy review and separate Root original-artifact grant required; existing SAFE collector authority does not apply.

Exact nine fields, limits, file pins, falsegrant template and dispatch/private-input schemas: READY.safe.json. Native observed failure location is not acceptance PASS or cause proof. Test/product unchanged; sensitivity still required after actual HTTP GREEN; B013 untouched.
