'use strict';

const fs = require('node:fs');
const path = require('node:path');
const { classify, controls } = require('./launch-cause.cjs');
const wrapper = '/workspace/scratch/rct-validation/browser_webkit_native_anchor_correction/webkit-custom-exec.py';
const allowedStages = new Set(['BROWSER_LAUNCH', 'ABOUT_BLANK', 'PUBLIC_HEADING', 'CONTEXT_CLOSE', 'BROWSER_CLOSE']);
const allowedClasses = new Set(['Error', 'TypeError', 'RangeError', 'ReferenceError', 'SyntaxError', 'TimeoutError']);
const errorClass = (error) => allowedClasses.has(error?.name) ? error.name : 'OTHER';

async function main() {
  const output = path.join(process.env.RCT_PUBLIC_WEBKIT_RUN, 'supervision/probe.safe.json');
  const result = { schema: 'RCT_WEBKIT_PUBLIC_BOOT_V1', scope: 'PUBLIC_BROWSER_ONLY', passed: false, stages: [], classifierControls: controls(), clientAcceptance: false, workerEffectiveTeachingInstantType: 'NOT_MEASURED_NO_CONFIG_OR_FIXTURES' };
  function save() {
    fs.writeFileSync(output + '.next', JSON.stringify(result, null, 2) + '\n', { mode: 0o600 });
    fs.renameSync(output + '.next', output);
  }
  function record(stage, passed, facts = null, error = null) {
    if (!allowedStages.has(stage)) throw new Error('Invalid closed stage');
    result.stages.push({ stage, passed, facts, errorClass: error ? errorClass(error) : null, launchCause: stage === 'BROWSER_LAUNCH' && error ? classify(error.message) : null });
    save();
  }
  save();
  let browser;
  let context;
  let stage = 'BROWSER_LAUNCH';
  try {
    const { webkit } = require('/workspace/rutcampustrack/tests/e2e/node_modules/playwright');
    browser = await webkit.launch({ executablePath: wrapper, headless: true, timeout: 20000, env: JSON.parse(process.env.RCT_PUBLIC_WEBKIT_CHILD_ENV) });
    record(stage, true);
    context = await browser.newContext({ viewport: { width: 1280, height: 720 }, serviceWorkers: 'block' });
    const page = await context.newPage();
    stage = 'ABOUT_BLANK';
    await page.goto('about:blank', { timeout: 5000 });
    record(stage, page.url() === 'about:blank');
    stage = 'PUBLIC_HEADING';
    await page.setContent('<!doctype html><html><body><h1>Public diagnostic heading</h1></body></html>', { timeout: 5000 });
    const heading = page.getByRole('heading', { name: 'Public diagnostic heading', exact: true });
    const facts = { headingCount: await heading.count(), headingVisible: await heading.isVisible() };
    record(stage, facts.headingCount === 1 && facts.headingVisible, facts);
  } catch (error) {
    record(stage, false, null, error);
  } finally {
    if (context) {
      try { await context.close(); record('CONTEXT_CLOSE', true); }
      catch (error) { record('CONTEXT_CLOSE', false, null, error); }
    }
    if (browser) {
      try { await browser.close(); record('BROWSER_CLOSE', true); }
      catch (error) { record('BROWSER_CLOSE', false, null, error); }
    }
  }
  result.passed = result.classifierControls.passed && result.stages.length === 5 && result.stages.every((item) => item.passed);
  save();
  process.exitCode = result.passed ? 0 : 1;
}

main().catch(() => { process.exitCode = 2; });
