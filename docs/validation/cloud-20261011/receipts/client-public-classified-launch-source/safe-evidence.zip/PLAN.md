# Публичная классификация отказа запуска Chromium

Исходный пакет762e и фактический результат42166 immutable. Попытка91017 использовала exec_command use_default с ограниченными network/IPC permissions: это гипотеза причины, не доказательство. Config/privacy guard фактически PASS, browser launch Error; прежние три клиентские причины остаются UNKNOWN.

Variant меняет только in-memory classifier публичного browser-launch exception и подключает15 синтетических controls. Строка exception.message читается только в RAM у новой публичной ошибки, никогда не возвращается/пишется/печатается/архивируется. Original failed test errors не читаются. Return — только MISSING_DEPS/MISSING_EXECUTABLE/EXEC_PERMISSION/IPC_OR_SANDBOX_DENIED/NATIVE_PROCESS_EXIT/OTHER. Коды сообщают распознанный класс, а не доказывают конкретную syscall/политику или product cause. Permission и native exit selectors требуют узких известных форм; unrelated permission/target closed/ENOENT остаются OTHER.

Exact pinned patterns: registry/dependencies.js missing dependencies header; registry/index.js executable header; browserType.js explicit executable/failed native launch; chromium/chromium.js sandbox rewrite; utils/processLauncher.js failed spawn prefix и process did exit. Node EACCES/EPERM — стандартные публичные spawn codes, конкретные OS строки не сохраняются. Priority — specific class прежде generic native exit. Нет добавленной broad substring Permission denied.

Две фазы как762e: actual configLoader/readback/requirePrivateArtifacts без specs/dataset/users/seed/API/login; штатный chromium.launch headless +about:blank/public heading/close. Config-effective clock TYPE измеряется, worker-effective остаётся NOT_MEASURED_CONFIG_ONLY. Assertions/fixtures/reporters/vendor/cache/Root19/r1source13 unchanged. Самостоятельный browser не означает client acceptance.

После нового Root grant один запуск через exec_command sandbox_permissions=with_additional_permissions, additional_permissions.network.enabled=true. Driver требует это намерение в grant, но не может сам доказать tool sandbox context; доказательство — фактический tool call, отдельно в safe receipt. Не изменять args/chromiumSandbox/env ради PASS. Old run не повторять; fresh absent r1/runs/attempt-03, b78, Node512MiB/RSS1.5GiB/cache32MiB/deadline60s, explicit original r1 env, public-only outputs и exact pidfd/birth cleanup. Allowned reap прежде удаления private TMP. Никакого старта stand/реального сайта/provider/API/данных.

Команда после свежего GO:
`python3 /workspace/scratch/rct-validation/client_real_acceptance/precredential-classified-r1/run-probe.py /workspace/scratch/rct-validation/client_real_acceptance/precredential-classified-r1/private/root-grant-01.json`

Source preparation only; controls/Node/browser NOT_RUN. Root readback +новый sealed grant нужны до исполнения. Public standalone diagnostic remains reversible, no product/config source correction.
