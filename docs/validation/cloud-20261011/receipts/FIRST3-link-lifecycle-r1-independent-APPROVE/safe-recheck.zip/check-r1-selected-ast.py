import ast,datetime,hashlib,json,stat,types
from pathlib import Path
OWN=Path(__file__).parent
BASE=Path('/workspace/scratch/rct-validation/first3_dataset_call_source/checking-plan-link-lifecycle-r1')
SOURCE=BASE/'native-plan/run-approved-node.py'
OLD_PROOF=OWN.parent/'check-selected-ast.py'
# Reuse only the original independent RAM adapter class definitions.
env0={'types':types,'datetime':datetime}
defs=[n for n in ast.parse(OLD_PROOF.read_text()).body if isinstance(n,ast.ClassDef)]
exec(compile(ast.Module(body=defs,type_ignores=[]),str(OLD_PROOF),'exec'),env0)
P,Clock=env0['P'],env0['Clock']
fn=next(n for n in ast.parse(SOURCE.read_text()).body if isinstance(n,ast.FunctionDef) and n.name=='run_checked_phases')
code=compile(ast.Module(body=[fn],type_ignores=[]),str(SOURCE),'exec')
rows=[]
for mode in ['DEADLINE_BEFORE_FIRST_CHILD','DEADLINE_AFTER_SETTLED_CHILD','RECEIPT_ERROR_AFTER_SETTLED','UNKNOWN_GUARD_CALL','UNSETTLED_RETURN','NONBOOLEAN_SETTLE','REPLACED_LINK','PRIMARY_AND_REPLACED_LINK']:
 state={'exists':False,'unlinks':0,'observes':0,'calls':0,'settled':0,'replacement':False,'output':None,'tmp_removes':0};primary=ValueError('PUBLIC_CLOSED_CONTROL')
 class PathMock(P):
  def __truediv__(self,name):return PathMock(self.name+'/'+name,self.state)
  @property
  def parent(self):return PathMock(self.name.rsplit('/',1)[0],self.state)
  def exists(self):return self.name.endswith('format-check.safe.json') and mode in ['RECEIPT_ERROR_AFTER_SETTLED','PRIMARY_AND_REPLACED_LINK']
  def read_text(self):raise primary
  def lstat(self):return types.SimpleNamespace(st_uid=1000,st_ino=21 if state['replacement'] else 20)
 def observe():
  state['observes']+=1
  return 'ABSOLUTE_DEADLINE' if (mode=='DEADLINE_BEFORE_FIRST_CHILD' and state['observes']>=2) or (mode=='DEADLINE_AFTER_SETTLED_CHILD' and state['observes']>=3) else None
 def symlink(*a,**k):state['exists']=True
 def owned(*a,**k):
  state['calls']+=1
  if mode=='UNKNOWN_GUARD_CALL':raise primary
  state['settled']+=1
  if mode in ['REPLACED_LINK','PRIMARY_AND_REPLACED_LINK']:state['replacement']=True
  return {'phase_success':True,'native_exit':0,'settled':False if mode=='UNSETTLED_RETURN' else 1 if mode=='NONBOOLEAN_SETTLE' else True,'all_owned_processes_reaped':True}
 def atomic(path,value):
  if str(path).endswith('OUTCOME.safe.json'):state['output']=value
 phases=[{'name':'format-check','argv':['PUBLIC_NODE'],'expectedNativeExit':0}]
 if mode=='DEADLINE_AFTER_SETTLED_CHILD':phases*=2
 env={'Path':lambda n:PathMock(str(n),state),'plan':{'ownedDependencyLink':{'path':'/own/node_modules','target':'/cached/node_modules'},'explicitEnv':{},'commands':phases},'g':{'owned_dependency_link':{'path':'/own/node_modules','target':'/cached/node_modules'},'per_phase_seconds':180},'os':types.SimpleNamespace(geteuid=lambda:1000,getpid=lambda:100,symlink=symlink,readlink=lambda p:'/cached/node_modules',path=types.SimpleNamespace(lexists=lambda p:state['exists'])),'observe':observe,'datetime':types.SimpleNamespace(datetime=Clock),'UTC':datetime.timezone.utc,'stop':datetime.datetime(2026,10,13,9,50,tzinfo=datetime.timezone.utc),'guard':types.SimpleNamespace(process_table=lambda:{100:{'pid':100,'start_ticks':1}},run_owned=owned),'atomic':atomic,'status':lambda v:None,'supervision':PathMock('/run/supervision',state),'run':PathMock('/run',state),'peaks':{},'json':json,'shlex':types.SimpleNamespace(join=lambda a:'PUBLIC_COMMAND',quote=lambda a:a),'shutil':types.SimpleNamespace(rmtree=lambda p:state.__setitem__('tmp_removes',state['tmp_removes']+1)),'stat':stat,'print':lambda *a,**k:None}
 exec(code,env);caught=None;identity=False;result=None
 try:result=env['run_checked_phases']()
 except BaseException as error:caught=type(error).__name__;identity=error is primary
 should_remove=mode in ['DEADLINE_BEFORE_FIRST_CHILD','DEADLINE_AFTER_SETTLED_CHILD','RECEIPT_ERROR_AFTER_SETTLED']
 assert state['unlinks']==int(should_remove),mode
 assert state['exists'] is (not should_remove),mode
 assert state['output']['pass'] is False,mode
 if mode in ['RECEIPT_ERROR_AFTER_SETTLED','UNKNOWN_GUARD_CALL','PRIMARY_AND_REPLACED_LINK']:assert identity,mode
 if mode=='UNKNOWN_GUARD_CALL':assert state['output']['activeOwnedCallUnknown'] is True
 rows.append({'code':mode,'passed':True,'link_removed':should_remove,'link_remaining':state['exists'],'guard_call_count':state['calls'],'exception_type':caught,'primary_identity_preserved':identity,'outcome_pass':False,'literal_settle_required':mode=='NONBOOLEAN_SETTLE','real_fs_or_native_effects':False})
receipt={'schema':'RCT_INDEPENDENT_LIFECYCLE_R1_SELECTED_AST_RAM_V1','source_sha256':hashlib.sha256(SOURCE.read_bytes()).hexdigest(),'original_proof_reused_sha256':hashlib.sha256(OLD_PROOF.read_bytes()).hexdigest(),'controls':rows,'all8_passed':True,'native_checking':'NOT_RUN'}
(OWN/'counterexamples-r1.safe.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({'all8_passed':True,'source_sha256':receipt['source_sha256'],'native_checking':'NOT_RUN'}))
