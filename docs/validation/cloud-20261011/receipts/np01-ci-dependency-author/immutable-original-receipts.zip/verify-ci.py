#!/usr/bin/env python3
import hashlib
import json
import os
from pathlib import Path
import subprocess
import tempfile

import yaml

OUT = Path(__file__).resolve().parent
WT = Path('/workspace/rct-worktrees/np01-config')
NEW_NAMES = {'Setup Python for Academic credential bridge', 'Install isolated Academic credential bridge dependencies'}
expected_condition = "matrix.service.name == 'academic-service'"
records = []
setup_body = None
for filename, job_name in [('ci.yml', 'java-integration-test'), ('coverage.yml', 'java-coverage')]:
    before_bytes = (OUT / ('before-' + filename)).read_bytes()
    after_bytes = (WT / '.github/workflows' / filename).read_bytes()
    before = yaml.safe_load(before_bytes)
    after = yaml.safe_load(after_bytes)
    job = after['jobs'][job_name]
    added = [step for step in job['steps'] if step.get('name') in NEW_NAMES]
    assert len(added) == 2
    for step in added:
        assert step['if'] == expected_condition
        assert not {'continue-on-error', 'timeout-minutes'}.intersection(step)
    setup = next(step for step in added if 'uses' in step)
    assert setup['uses'] == 'actions/setup-python@a26af69be951a213d495a4c3e4e4022e16d87065'
    assert setup['with']['python-version'] == '3.12'
    assert setup['with']['cache-dependency-path'].splitlines() == [
        'services/notification-bot/requirements.txt', 'services/notification-bot/requirements-test.txt']
    install = next(step for step in added if 'run' in step)
    if setup_body is not None:
        assert install['run'] == setup_body
    setup_body = install['run']
    assert 'python -m venv "$RUNNER_TEMP/np01-python"' in setup_body
    assert '"$RUNNER_TEMP/np01-python/bin/python" -m pip install -r services/notification-bot/requirements.txt -r services/notification-bot/requirements-test.txt' in setup_body
    assert 'NP01_PYTHON_EXECUTABLE=$RUNNER_TEMP/np01-python/bin/python' in setup_body
    assert 'PYTHONDONTWRITEBYTECODE=1' in setup_body
    assert subprocess.run(['bash', '-n'], input=setup_body.encode(), capture_output=True).returncode == 0
    services = job['strategy']['matrix']['service']
    matching = [service['name'] for service in services if service['name'] == 'academic-service']
    assert matching == ['academic-service']
    first_test = next(i for i, step in enumerate(job['steps']) if ':integrationTest' in step.get('run', ''))
    assert all(job['steps'].index(step) < first_test for step in added)
    job['steps'] = [step for step in job['steps'] if step.get('name') not in NEW_NAMES]
    assert after == before
    records.append({'workflow': filename, 'job': job_name, 'before_sha256': hashlib.sha256(before_bytes).hexdigest(),
                    'after_sha256': hashlib.sha256(after_bytes).hexdigest(), 'added_steps': 2,
                    'only_enabled_matrix_service': matching, 'unchanged_other_services': len(services) - 1,
                    'original_workflow_semantics_exact_after_removing_only_added_steps': True})

# Execute the actual shell with a fixture Python/venv creator, never reinstalling
# the frozen shared venv. A failing install must not publish an interpreter env.
wrapper = '''#!/usr/bin/env python3
import json,os,sys
from pathlib import Path
with open(os.environ['NP01_SETUP_CONTROL_CALLS'],'a') as stream: stream.write(json.dumps(sys.argv[1:])+'\\n')
if sys.argv[1:3]==['-m','venv']:
    target=Path(sys.argv[3])/'bin/python';target.parent.mkdir(parents=True);target.write_text(Path(__file__).read_text());target.chmod(0o755)
elif sys.argv[1:4]==['-m','pip','install']:
    raise SystemExit(int(os.environ['NP01_SETUP_CONTROL_FAIL']))
else: raise SystemExit(9)
'''
shell_controls = []
for failed in (False, True):
    with tempfile.TemporaryDirectory(prefix='ci-setup-control-', dir=OUT) as temp:
        temp = Path(temp)
        bin_dir = temp / 'bin'; bin_dir.mkdir()
        python = bin_dir / 'python'; python.write_text(wrapper); python.chmod(0o755)
        output = temp / 'job-env'; calls = temp / 'calls.jsonl'
        env = os.environ.copy()
        env.update({'PATH': str(bin_dir) + ':' + env['PATH'], 'RUNNER_TEMP': str(temp), 'GITHUB_ENV': str(output),
                    'NP01_SETUP_CONTROL_CALLS': str(calls), 'NP01_SETUP_CONTROL_FAIL': '1' if failed else '0'})
        result = subprocess.run(['bash', '-e'], input=setup_body.encode(), env=env, capture_output=True)
        assert result.returncode == (1 if failed else 0)
        if failed:
            assert not output.exists()
        else:
            assert output.read_text().splitlines() == ['NP01_PYTHON_EXECUTABLE=' + str(temp / 'np01-python/bin/python'), 'PYTHONDONTWRITEBYTECODE=1']
        invoked = [json.loads(line) for line in calls.read_text().splitlines()]
        assert invoked[0] == ['-m', 'venv', str(temp / 'np01-python')]
        assert invoked[1] == ['-m', 'pip', 'install', '-r', 'services/notification-bot/requirements.txt', '-r', 'services/notification-bot/requirements-test.txt']
        shell_controls.append({'dependency_install_fails': failed, 'exit': result.returncode,
                               'interpreter_published': output.exists(), 'actual_dependency_reinstall': False})
receipt = {'status': 'PASS_SOURCE_ONLY_CI_DEPENDENCY_SETUP', 'workflows': records, 'shell_controls': shell_controls,
           'triggers_matrices_original_commands_collectors_other_jobs': 'UNCHANGED',
           'requirements_locks_java_dependencies': 'UNCHANGED', 'shared_venv': 'READ_ONLY_UNTOUCHED',
           'hosted_CI_Coverage_new_bridge_execution': 'NOT_RUN; requires coherent integration/push/current hosted checks',
           'cloud_app_java_docker_execution': 'NOT_RUN'}
(OUT / 'verification.safe.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(receipt))
