"""Public source/metadata hashes and AST only; no target imports or native execution."""
import ast
import datetime
import hashlib
import json
from pathlib import Path, PurePosixPath
import stat
import zipfile

OUT=Path(__file__).parent
SOURCE=OUT.parent/'browser_webkit_native_prepare'
def sha(p):
    digest=hashlib.sha256()
    with Path(p).open('rb') as stream:
        for block in iter(lambda:stream.read(1048576),b''):digest.update(block)
    return digest.hexdigest()
def regular(p):
    p=Path(p)
    assert 'private' not in p.parts and p.suffix!='.env'
    assert stat.S_ISREG(p.lstat().st_mode)
    return p
manifest=SOURCE/'manifest.json'
assert sha(manifest)=='5de31368e2d41d803d54250487d83e5749728d385f38375e0db489fe7fbc01d8'
m=json.loads(manifest.read_text());members={}
for row in m['files']:
    p=regular(row['path']);s=p.stat()
    assert p.parent==SOURCE and s.st_size==row['bytes'] and sha(p)==row['sha256']
    if 'mode' in row:assert stat.S_IMODE(s.st_mode)==row['mode']
    if p.suffix=='.py':ast.parse(p.read_text())
    members[row['name']]=row['sha256']
members['manifest.json']=sha(manifest)
assert len(members)==26
assert sha(SOURCE/'safe-evidence.zip')=='b836c0daeca451312b57123e3a5f40c655a1665ec6c76e8dc5e38f2ea13c3c8f'
with zipfile.ZipFile(SOURCE/'safe-evidence.zip') as z:
    assert len(z.infolist())==26 and len(set(z.namelist()))==26
    for info in z.infolist():
        path=PurePosixPath(info.filename)
        assert not path.is_absolute() and '..' not in path.parts and not stat.S_ISLNK(info.external_attr>>16)
        assert hashlib.sha256(z.read(info)).hexdigest()==members[info.filename]
    assert z.testzip() is None
prior=[]
for seal in json.loads((SOURCE/'prior-authorities.safe.json').read_text())['seals']:
    p=regular(seal['path']);assert sha(p)==seal['sha256']
    rows=json.loads(p.read_text());entries=rows.get('files',rows.get('entries',[]))
    for row in entries:
        path=Path(row['path'])
        if not path.is_absolute():path=p.parent/path
        assert sha(regular(path))==row['sha256']
        if 'bytes' in row:assert path.stat().st_size==row['bytes']
    prior.append({'path':str(p),'sha256':seal['sha256'],'verified_members':len(entries)})
selection=json.loads((SOURCE/'selected-dso-headers.safe.json').read_text())
rows=selection['selected'];assert len(rows)==22
index={row['name']:row for row in rows};assert len(index)==22
reg=[r for r in rows if r['kind']=='regular'];links=[r for r in rows if r['kind']=='symlink']
assert len(reg)==14 and len(links)==8 and sum(r['declared_bytes'] for r in reg)==12231288
headers={}
for row in selection['header_inputs']:
    p=regular(row['path']);assert sha(p)==row['sha256']
    headers[p.name.removesuffix('-headers.safe.json')]=json.loads(p.read_text())['data']['rows']
for row in rows:
    actual=next(r for r in headers[row['package']] if r['name']==row['name'])
    assert actual=={k:v for k,v in row.items() if k!='package'}
for row in links:
    target=index[row['link']['normalized_target']]
    assert target['kind']=='regular' and target['package']==row['package']
    assert '/' not in row['link']['target'] and row['link']['hardlink'] is False
archive_rows=json.loads((SOURCE/'signed-archive-inputs.safe.json').read_text())['exact_archives']
approved=json.loads((SOURCE.parent/'browser_webkit_payload_context_correction/approved-packages.safe.json').read_text())['packages']
assert len(archive_rows)==len(approved)==11
archive_metadata=[]
for row in archive_rows:
    p=regular(row['path']);s=p.stat();expected=next(r for r in approved if r['package']==p.stem)
    assert sha(p)==row['archive_sha256']==expected['package_sha256']
    assert s.st_size==row['bytes']==expected['download_bytes']
    assert stat.S_IMODE(s.st_mode)==0o600 and s.st_uid==1000 and s.st_nlink==1
    archive_metadata.append({'package':p.stem,'sha256':sha(p),'bytes':s.st_size})
assert sum(r['bytes'] for r in archive_metadata)==6284816
procedure=json.loads((SOURCE/'native-validation-procedure.safe.json').read_text())
vendor=procedure['upstream25_ELF_4shell']
assert len(vendor)==29 and sum(r['elf'] for r in vendor)==25
for row in vendor:assert sha(row['path'])==row['sha256']
for row in json.loads((SOURCE/'native-tools.safe.json').read_text())['tools']:assert sha(row['path'])==row['sha256']
core=Path('/workspace/rutcampustrack/tests/e2e/node_modules/playwright-core')
api=json.loads((SOURCE.parent/'browser_webkit_signed_plan/custom-executable-api.safe.json').read_text())
for row in api['source_files']:assert sha(row['path'])==row['sha256']
assert json.loads((core/'package.json').read_text())['version']=='1.59.1'
assert stat.S_IMODE((SOURCE/'webkit-custom-exec.py').stat().st_mode)==0o555
assert sha(SOURCE/'custom-executable-proposal.py')==sha(SOURCE.parent/'browser_webkit_signed_plan/custom-executable-proposal.py')
cases=[(r['path'],'minibrowser-wpe' if '/minibrowser-wpe/' in r['path'] else 'minibrowser-gtk','loader') for r in vendor if r['elf']]
prefix=Path('/tmp/rct-webkit-native-deps-20261012')
cases += [(str(prefix/r['name']),'package','loader') for r in reg]
cases += [(str(prefix/'usr/lib/x86_64-linux-gnu/libGLESv2.so.2'),variant,'gles') for variant in ['minibrowser-wpe','minibrowser-gtk']]
cases += [('/usr/lib/x86_64-linux-gnu/libx264.so.164',variant,'x264') for variant in ['minibrowser-wpe','minibrowser-gtk']]
assert len(cases)==len(set(cases))==43
controls={}
for name in ['source-controls.safe.json','caller-controls.safe.json','copy-controls.safe.json']:
    receipt=json.loads((SOURCE/name).read_text())
    assert receipt['count']==len(receipt['checks']) and all(row.get('pass') is True for row in receipt['checks'])
    controls[name]=receipt['count']
assert sum(controls.values())==112
clock=[]
for name in ['extract-selected.py','validate-native.py','webkit-custom-exec.py']:
    tree=ast.parse((SOURCE/name).read_text());main=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='main')
    direct=[];nested=[]
    for node in main.body:
        if isinstance(node,ast.FunctionDef):
            nested.extend(n.lineno for n in ast.walk(node) if isinstance(n,ast.Call) and ast.unparse(n.func)=='datetime.datetime.now')
            continue
        direct.extend(n.lineno for n in ast.walk(node) if isinstance(n,ast.Call) and ast.unparse(n.func)=='datetime.datetime.now')
    clock.append({'source':name,'main_direct_clock_sample_lines':direct,'nested_observer_clock_sample_lines':nested})
start=datetime.datetime(2026,10,12,17,0,tzinfo=datetime.timezone.utc)
stop=start+datetime.timedelta(seconds=600)
entry=stop-datetime.timedelta(seconds=1)
use=entry+datetime.timedelta(seconds=2)
assert start<=entry<stop and use>=stop
finding={'id':'T005-GRANT-USE-TIME','priority':2,'source_only':True,'entry_utc':entry.isoformat(),'stop_utc':stop.isoformat(),'post_hash_first_mutation_or_exec_utc':use.isoformat(),'source_timeline':'Entry validation accepts; public seal/hash reads consume2s; no fresh deadline comparison precedes initial Namespace/Output allocation or final execve','AST_clock_samples':clock,'actual_clock_sleep_source_import_write_exec':False}
(OUT/'deadline-counterexample.safe.json').write_text(json.dumps(finding,indent=2)+'\n')
(OUT/'seal-selection-check.safe.json').write_text(json.dumps({'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'input_manifest_sha256':sha(manifest),'input_zip_sha256':sha(SOURCE/'safe-evidence.zip'),'members':len(members),'zip_CRC_hashes_paths_modes':'PASS','prior_seals':prior,'selected_exact_header_rows':22,'regular':14,'links':8,'selected_regular_bytes':12231288,'archive_sha_size_mode_metadata':archive_metadata,'vendor_ELF25_shell4_hashes':'PASS','four_public_tool_hashes':'PASS','all5_pinnedAPI_hashes':'PASS','case_inventory':cases,'case_count':43,'wrapper_0555_mapping_byte_exact':True,'author_controls_inspected_not_run':controls,'target_imports_loader_extract_dlopen_browser_network':False,'verdict':'CHANGES_REQUESTED','finding':'T005-GRANT-USE-TIME'},indent=2)+'\n')
print(json.dumps({'input25files_ZIP26':'PASS','prior_public_seals':len(prior),'selected_headers':22,'archives_sha':11,'inventory_cases':43,'author_pure_controls_not_reexecuted':112,'verdict':'CHANGES_REQUESTED','finding':'T005-GRANT-USE-TIME','native_runtime':'NOT_RUN'}))
