CHANGES_REQUESTED — узкая recheck T005-GRANT-USE-TIME

Исходная P2 закрыта на уровне SOURCE для первого prefix mkdir, первого native output mkdir и финального execve. Она остаётся открытой только для публикации native PASS. Новый blocking finding не добавлялся; широкий пакет повторно не проверялся и исходный24fec не изменён.

Frozen correction input: manifest7dfe76bcf892651a4b8265f64f2ef14bb75df500052157c8bffde4f99eadeeb4; deadline-correction.source.safe.zip4c7f7821f46b87a3a10f34c219866fe47622186d4a6de696c8eadc485cf06d4f. Независимо проверены все новые members/hash/size/mode/ZIPCRC, original5de25files и исходный review24fec6files. Wholepackage source5de/112originalcontrols и прежний review остаются immutable. Новый manifest использует size/relative_path/stringmode; reviewer helper нормализовал именно эту схему. Перестановка rows в прежних selection controls объясняется unordered set; normalized112 checks совпадают, это не author defect.

Оставшийся P2 fragment: browser_webkit_native_deadline_correction/validate-native.py120–121.

```python
gates.require_fresh(stop)
out.save('native-validation.safe.json', {..., 'resources': driver.resources(), ...})
```

Python вычисляет driver.resources() внутри аргумента второго statement после завершения первой gate, но до вызова out.save. Повторный filesystem/cgroup/proc ресурсный preflight может закончиться после stop_utc. В этой точке больше нет сравнения текущего времени, поэтому status PASS_EFFECTIVE_NATIVE_AVAILABILITY_ONLY всё ещё может быть опубликован поздно.

Независимый pure selected-source counterexample выполнен без import target module и без настоящих действий: скомпилированы только actual require_fresh FunctionDef и точные gate+FULL save-expression из нового source. Actor/resource/clock/output подменены. Gate при stop−1s проходит; следующий driver.resources() сдвигает mock clock на2s; mock save фиксирует PASS при stop+1s.43 synthetic success-case metadata используются только для порядка вычислений, не как ABI evidence. Результат и точные строки120/121 сохранены в recheck.safe.json. Это прямой counterpart оригинальной expiry-during-preflight проблемы, не требование атомарного clock/kernel-call fencing.

Author deadline-controls.py проверяет финальную публикацию только через один gate statement; сам save-expression с ресурсным argument не выполняется. Поэтому его18controls/4oldcounterexamples не ловят данный остаток. Они прочитаны, но целиком не reexecuted reviewer.

Минимальная correction: подготовить proof dictionary и resource snapshot до финальной fresh clock gate либо использовать ресурсный snapshot, возвращаемый require_fresh, чтобы после неё не повторять потенциально задерживающий resource preflight. Затем выполнить полноценный selected gate+save-expression control с delayed final-resource argument: entry/preflight успешны, expiry перед publication приводит к отсутствию PASS. Исходный stop_utc не продлевать. Обычные finalcomparison→kernel-call scheduling limits и безопасные partial/error cleanup receipts сохраняются.

Три остальные protected points independently SOURCE closed:

- extract-selected.py: actual LeasedNamespace.check сначала выполняет прежние path/FD checks, затем require_fresh(stop,CAP) при двух pinned ancestor identities; inherited Namespace вызывает check непосредственно перед первым mkdir. Pure delayed constructor mock отклонён до mkdir.
- validate-native.py/own-paths.py: require_fresh до Output, before_mutation callback непосредственно перед обоими реальными mkdir sites; expiry во время constructor metadata отклоняется before effect. Nofollow/fullidentity/owner/mode guards сохранены.
- webkit-custom-exec.py: use helper загружен только после sealed source/proof/mapping checks, fresh gate непосредственно перед единственным execve; pure expired-proof mock отклонён без exec. Actor/resources читаются до clock, исходный stop_utc используется напрямую.

selection.py/native-probe.py/custom-executable-proposal.py/source-controls.py/caller-controls.py/copy-controls.py, selected headers/signedarchives/tools и три procedure/boundary JSON byte exact5de. Реальный delta трёх callers плюс Output/helper сравнен и сохранён в source-delta.patch. Typed phase grants, source/self/helper/review/prior seals, exact14DSO+8links, native43case inventory, unsupported GUI/resource qualifications и separate browser authority не изменены. Новые effective launch-schema paths выбирают correction sibling; прежний5de не является разрешённым runtime entrypoint.

Scope/limits: FULL текущий contract/CURRENT/decisions/questions/resources перечитаны; Root4c checkpoint/prepared5ced source и отдельный текущий stand/browser lease не менялись. Root sole shared-doc writer, host sole source author; selectedSol6.1/high actualUNKNOWN. Никаких source fixes, настоящих namespace/alias/exec/probe/native loader/dlopen/extraction/API/Docker/browser/network/privategrant/ENV/key/data/cache/vendor/product действий. Только standard-library own helper, публичные seals/source read и selected AST с mock effects. Не повторялись old broad archive/native checks. Native ABI/capacity/browser readiness NOT_RUN/UNKNOWN. Свежие actual grants остаются у Root после полного закрытия P2 и отдельно от текущего stand.

Created: selected-static-recheck.py, recheck.safe.json, source-delta.patch, HANDOFF.md, CURRENT.json, manifest.json, safe-evidence.zip только в NEW native_deadline_recheck. Modified/deleted чужие/старые файлы:0. Helper terminal/no active process/heavy lease. Следующий шаг: sole author исправляет единственное post-gate resource collection место, immutable new source seal, узкая независимая recheck; actual phase grants сейчас не выдавались.
