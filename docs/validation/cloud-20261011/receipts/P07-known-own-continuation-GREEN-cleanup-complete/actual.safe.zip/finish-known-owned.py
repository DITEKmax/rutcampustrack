"""One existing no-mount consumer oracle, then exact known synthetic-resource cleanup."""
import datetime
import json
import os
from pathlib import Path
import stat
import subprocess
import sys
import time

IMAGE = "sha256:775f483016a7d128be2a6c6978785619990f9ac24abb5ff1868222020118b279"
LABEL = "20261013-01"
VOLUME = "p07-key-isolation-20261013-01"
IDS = ["a9105357ff47f26281be8e85dbc4061ad8f548dc4518ad4c1fe4f9757dda6b2c", "8bcec58eef9701cadeeee0de8ae038648eb1d5b4b7b9d919e792babd702df1cc", "8dc5bb9af2eee9e340a4fe3b2b3cb572bb241114c5a789a748aa211fd2ef031b"]
CREATED = ["2026-10-13T13:51:34.551424953Z", "2026-10-13T13:51:35.778749485Z", "2026-10-13T13:51:36.901875986Z"]
TEMP_NAME = "p07-key-isolation-20261013-01-wzsk09ux"
DIR_META = (33, 323971, 1000, 0o700, 2, 80)
LEAVES = {"private.key": (33, 323972, 1000, 0o600, 1, 2484), "public.key": (33, 323973, 1000, 0o644, 1, 625)}
DOCKER = ["docker", "--host=unix:///var/run/docker.sock"]
ENV = os.environ.copy()
for selector in ("DOCKER_HOST", "DOCKER_CONTEXT", "DOCKER_TLS", "DOCKER_TLS_VERIFY", "DOCKER_CERT_PATH"):
    ENV.pop(selector, None)


def free_bytes(path):
    stats = os.statvfs(path)
    return stats.f_bavail * stats.f_frsize


def resource_gate(initial_free, deadline, cleanup=False):
    # Cheap fresh probes are fail-closed; UTC is read last, immediately before the effect.
    for path in ("/workspace", "/tmp"):
        current = free_bytes(path)
        if current < 4 * 1024**3 or initial_free[path] - current > 32 * 1024**2:
            raise RuntimeError("disk budget")
    current = int(Path("/sys/fs/cgroup/memory.current").read_text().strip())
    maximum = int(Path("/sys/fs/cgroup/memory.max").read_text().strip())
    if current < 0 or maximum <= 0 or current > min(15 * 1024**3, maximum - 1024**3):
        raise RuntimeError("shared memory budget")
    remaining = deadline - time.time() - (0 if cleanup else 30)
    if remaining <= 0:
        raise RuntimeError("cleanup deadline")
    return min(30, remaining)


def metadata(info):
    return (info.st_dev, info.st_ino, info.st_uid, stat.S_IMODE(info.st_mode), info.st_nlink, info.st_size)


def main():
    os.umask(0o077)
    deadline = datetime.datetime.fromisoformat(sys.argv[1]).timestamp()
    output = Path(__file__).with_name("partial.safe.json")
    if output.exists() or output.is_symlink() or not 0 < deadline - time.time() <= 180:
        raise RuntimeError("fresh Root window and output required")
    initial_free = {path: free_bytes(path) for path in ("/workspace", "/tmp")}
    receipt_identity = None
    result = {"state": "STARTED", "original_run": "65486_RESOURCE_FAIL", "green": "NOT_RUN", "removed_container_ids": [], "volume_removed": False, "tmp_removed": False, "removed_tmp_leaves": [],
              "qualification": "Original growth cap failure and missing original birth/cleanup ID journals remain; old exit1 and Source-order marker admission only. No real key read or whole-run cap compliance claim."}

    def save():
        nonlocal receipt_identity
        resource_gate(initial_free, deadline, cleanup=True)
        flags = os.O_WRONLY | os.O_NOFOLLOW
        if receipt_identity is None:
            flags |= os.O_CREAT | os.O_EXCL
        descriptor = os.open(output, flags, 0o600)
        try:
            info = os.fstat(descriptor)
            identity = (info.st_dev, info.st_ino, info.st_uid)
            if not stat.S_ISREG(info.st_mode) or info.st_nlink != 1 or stat.S_IMODE(info.st_mode) != 0o600:
                raise RuntimeError("owned receipt metadata changed")
            if receipt_identity is not None and identity != receipt_identity:
                raise RuntimeError("owned receipt identity changed")
            receipt_identity = identity
            data = (json.dumps(result, indent=2) + "\n").encode()
            if os.write(descriptor, data) != len(data):
                raise RuntimeError("owned receipt short write")
            os.ftruncate(descriptor, len(data))
            os.fsync(descriptor)
        finally:
            os.close(descriptor)

    def run(arguments, cleanup=False):
        timeout = resource_gate(initial_free, deadline, cleanup)
        proc = subprocess.run(DOCKER + arguments, env=ENV, capture_output=True, timeout=timeout)
        if proc.returncode != 0:
            raise RuntimeError("known native operation failed")
        return proc.stdout.decode("ascii").strip()

    def admit(index, state, exit_code):
        value = run(["inspect", "--format", '[{{json .Id}},{{json .Created}},{{json .Config.Image}},{{json (index .Config.Labels "io.rutcampustrack.p07-isolation")}},{{json .State.Status}},{{json .State.ExitCode}}]', IDS[index]], cleanup=True)
        if json.loads(value) != [IDS[index], CREATED[index], IMAGE, LABEL, state, exit_code]:
            raise RuntimeError("known container identity or state changed")

    save()
    try:
        admit(0, "exited", 0)
        admit(1, "exited", 1)
        admit(2, "created", 0)
        configuration = run(["inspect", "--format", '[{{json .Config.Cmd}},{{json .Config.Entrypoint}},{{len .Mounts}},{{json .HostConfig.NetworkMode}},{{json .HostConfig.Memory}},{{json .HostConfig.PidsLimit}},{{len .HostConfig.PortBindings}},{{json .HostConfig.Privileged}}]', IDS[2]])
        if json.loads(configuration) != [["sh", "-c", "test ! -e /keys/private.key && test ! -e /keys/public.key"], None, 0, "none", 33554432, 32, 0, False]:
            raise RuntimeError("fixed no-mount oracle configuration changed")
        admit(2, "created", 0)
        result["state"] = "ADMITTED_EXACT_EXISTING_ORACLE"
        save()
        if run(["start", "--attach", IDS[2]]) != "":
            raise RuntimeError("unexpected oracle output")
        admit(2, "exited", 0)
        result.update(green="PASS_PRIVATE_AND_PUBLIC_FILE_ABSENT", state="GREEN_CLEANUP_PENDING")
        save()
        result["workspace_free_before_container_cleanup"] = free_bytes("/workspace")
        save()
        for index, expected_exit in ((2, 0), (1, 1), (0, 0)):
            admit(index, "exited", expected_exit)
            if run(["rm", IDS[index]], cleanup=True) != IDS[index]:
                raise RuntimeError("unexpected removal confirmation")
            result["removed_container_ids"].append(IDS[index])
            save()
        result["workspace_free_after_container_cleanup"] = free_bytes("/workspace")
        result["observed_net_workspace_recovery_bytes"] = result["workspace_free_after_container_cleanup"] - result["workspace_free_before_container_cleanup"]
        save()
        value = run(["volume", "inspect", "--format", '[{{json .Name}},{{json .CreatedAt}},{{json (index .Labels "io.rutcampustrack.p07-isolation")}}]', VOLUME], cleanup=True)
        if json.loads(value) != [VOLUME, "2026-10-13T13:51:34Z", LABEL]:
            raise RuntimeError("known volume identity changed")
        if run(["container", "ls", "--all", "--filter", "volume=" + VOLUME, "--format", "{{.ID}}"], cleanup=True):
            raise RuntimeError("unexpected volume consumer")
        if run(["volume", "rm", VOLUME], cleanup=True) != VOLUME:
            raise RuntimeError("unexpected volume removal confirmation")
        result["volume_removed"] = True
        save()
        parent = os.open("/tmp", os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
        directory = None
        try:
            directory = os.open(TEMP_NAME, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW, dir_fd=parent)
            if metadata(os.fstat(directory)) != DIR_META or set(os.listdir(directory)) != set(LEAVES):
                raise RuntimeError("known directory metadata changed")
            for name, expected in LEAVES.items():
                descriptor = os.open(name, os.O_RDONLY | os.O_NOFOLLOW, dir_fd=directory)
                try:
                    info = os.fstat(descriptor)
                    if not stat.S_ISREG(info.st_mode) or metadata(info) != expected:
                        raise RuntimeError("known leaf metadata changed")
                    if metadata(os.stat(name, dir_fd=directory, follow_symlinks=False)) != expected:
                        raise RuntimeError("known leaf binding changed")
                    resource_gate(initial_free, deadline, cleanup=True)
                    os.unlink(name, dir_fd=directory)
                    result["removed_tmp_leaves"].append(name)
                    save()
                finally:
                    os.close(descriptor)
            if os.listdir(directory) or metadata(os.stat(TEMP_NAME, dir_fd=parent, follow_symlinks=False))[:5] != DIR_META[:5]:
                raise RuntimeError("known directory binding changed")
            resource_gate(initial_free, deadline, cleanup=True)
            os.rmdir(TEMP_NAME, dir_fd=parent)
        finally:
            if directory is not None:
                os.close(directory)
            os.close(parent)
        result.update(tmp_removed=True, state="GREEN_AND_KNOWN_OWN_CLEANUP_COMPLETED")
        save()
    except BaseException as error:
        result.update(state="STOPPED_OR_FAILED", error_type=type(error).__name__)
        try:
            save()
        except BaseException:
            try:
                os.write(2, b"RCT_P07_FINISH_SAFE_SAVE_FAILED\n")
            except BaseException:
                pass
        raise


if __name__ == "__main__":
    main()
