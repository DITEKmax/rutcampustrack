"""Narrow independent source/selected-consumer check; no target module imports/native."""
import ast
import hashlib
import json
import stat
import types
from pathlib import Path,PurePosixPath
import zipfile

HERE=Path(__file__).parent
NEW=HERE.parent/'current_academic_refresh_pin_correction'
OLD=HERE.parent/'current_academic_refresh_prepare'
checks=[]
def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def passed(x): checks.append(x)
def denies(x,call):
    try:call()
    except RuntimeError:passed(x)
    else:raise AssertionError(x)
assert sha(OLD/'manifest.json')=='0b7d2d59eef1fee06f0a8416ef86751e3949a042d7a5007c23aea8e3c9d581bd'
assert sha(OLD/'current-academic-refresh-source.safe.zip')=='930ed856da1a1d442784bebe8f1d24d332d2542fcf9981e69c6246cb3afe5613'
assert sha(NEW/'manifest.json')=='d9efefedb1d3288ec186caaa70f4346d8366c3976ba4dde96e03b69d9867965e'
old=json.loads((OLD/'manifest.json').read_text())
new=json.loads((NEW/'manifest.json').read_text())
for m,d in [(old,OLD),(new,NEW)]:
    for r in m['files']:
        p=Path(r['path']); assert p.parent==d and p.stat().st_size==r['bytes'] and sha(p)==r['sha256']
passed('original18_and_NEW23_exact_hashes_originalZIP_preserved')
oldpin='e65d7f3bbf4c01671ea682c9a32152ba2f0744d533085769050ebda35f831bf3'
goodpin='7e7579ce554d6a94aaf79d331aeaccfa6611a989def97fa3ec2be7f261028d07'
for r in old['files']:
    name=Path(r['path']).name
    a=(OLD/name).read_bytes(); b=(NEW/name).read_bytes()
    if name=='run-academic-restart.py':
        assert a.count(oldpin.encode())==1 and b==a.replace(oldpin.encode(),goodpin.encode())
    else:assert a==b
passed('exact_one_pin_literal_delta_other17_BYTE_IDENTICAL')
assert sha(NEW/'runtime-binding.py')==goodpin
passed('helperactual_manifest_schema_runner_pin_equal')
zpath=NEW/'current-academic-refresh-pin-correction.safe.zip'
assert sha(zpath)=='da568143744df7e92fdd8a78df50da25a60e00d272f1292a9d025c6c587236cc'
with zipfile.ZipFile(zpath) as z:
    assert z.testzip() is None and len(z.infolist())==len(set(z.namelist()))==24
    for i in z.infolist():
        p=PurePosixPath(i.filename); assert not p.is_absolute() and '..' not in p.parts and str(p)==i.filename
        assert stat.S_IFMT(i.external_attr>>16) in (0,stat.S_IFREG)
        assert z.read(i)==(NEW/p.name).read_bytes()
passed('NEW_ZIP24_safe_CRC_content_exact')
schema=json.loads((NEW/'effective-launch-correction.safe.json').read_text())
for phase in ['build','stage']:
    assert schema[phase+'_command']==['/usr/bin/python3',str(NEW/(phase+'-academic.py')),'--grant',str(NEW/'private'/(phase+'-grant.json'))]
assert schema['academic_runtime_command']==['/usr/bin/python3',str(NEW/'run-academic-restart.py'),'--service','academic','--grant','/workspace/scratch/rct-validation/current_host_config_v5/private/restart-launch-grant-next02.json']
passed('effective_launch_NEW_callers_NEW_phase_grants_same_v5_next02')

def selected_prefix(source):
    main=next(n for n in ast.parse(source.read_text()).body if isinstance(n,ast.FunctionDef) and n.name=='main')
    start=next(i for i,n in enumerate(main.body) if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='helper' for t in n.targets))
    end=next(i for i,n in enumerate(main.body) if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='specs' for t in n.targets))
    return ast.Module(body=main.body[start:end+1],type_ignores=[])
def consumer(dir_,wrong=False):
    events=[]
    def mock_exec(code,globals_):
        # Exact consumer compiled actual pinned helper bytes; actual imports/bootstrap not run.
        assert globals_['__file__']==str(dir_/'runtime-binding.py')
        assert sha(dir_/'runtime-binding.py')==goodpin
        events.append('PINNED_HELPER_EXEC_DISPATCH_MOCK_ONLY')
        def verify(g,s):
            assert s==str(dir_/'run-academic-restart.py');events.append('VERIFY_MOCK_ONLY');return 'sentinel'
        globals_['verify']=verify
    ns={'REFRESH':dir_,'digest':lambda p:'0'*64 if wrong else sha(p),'types':types,'exec':mock_exec,'grant':{},'__file__':str(dir_/'run-academic-restart.py')}
    try:exec(compile(selected_prefix(dir_/'run-academic-restart.py'),'<selected consumer>','exec'),ns)
    except RuntimeError:assert not events;return False
    assert events==['PINNED_HELPER_EXEC_DISPATCH_MOCK_ONLY','VERIFY_MOCK_ONLY'] and ns['specs']=='sentinel';return True
assert consumer(OLD) is False;passed('exact_old_consumer_denies_before_helper_dispatch')
assert consumer(NEW) is True;passed('exact_new_consumer_reaches_mock_boundary_actual_bytepin')
assert consumer(NEW,True) is False;passed('exact_new_consumer_wrongdigest_denies_before_dispatch')

# Real readonly selected verify_package checks own executing source/manifest/members.
btree=ast.parse((NEW/'refresh-boundary.py').read_text())
fn=next(n for n in btree.body if isinstance(n,ast.FunctionDef) and n.name=='verify_package')
g={'OWN':NEW,'Path':Path,'json':json,'regular':lambda p:Path(p),'sha':sha}
exec(compile(ast.Module(body=[fn],type_ignores=[]),'<selected readonly package binding>','exec'),g)
grant={'academic_refresh_manifest_sha256':sha(NEW/'manifest.json'),
       'academic_refresh_review_manifest':str(HERE/'check.py'),'academic_refresh_review_manifest_sha256':sha(HERE/'check.py')}
g['verify_package'](grant,str(NEW/'stage-academic.py'));passed('actual_NEW_stage_self_manifest_member_package_bind')
g['verify_package'](grant,str(NEW/'run-academic-restart.py'));passed('actual_NEW_runtime_self_manifest_member_package_bind')
denies('OLD_manifest_grant_denied_for_NEW_STAGE',lambda:g['verify_package'](dict(grant,academic_refresh_manifest_sha256=sha(OLD/'manifest.json')),str(NEW/'stage-academic.py')))
denies('OLD_runner_source_denied_in_NEW_package',lambda:g['verify_package'](grant,str(OLD/'run-academic-restart.py')))

# Selected original/new STAGE build-receipt prefix using synthetic recorded-result fields only.
def stage_receipt_prefix():
    main=next(n for n in ast.parse((NEW/'stage-academic.py').read_text()).body if isinstance(n,ast.FunctionDef) and n.name=='main')
    body=next(n.body for n in main.body if isinstance(n,ast.Try))
    end=next(i for i,n in enumerate(body) if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='app' for t in n.targets))
    return ast.Module(body=body[:end+1],type_ignores=[])
PREFIX=Path('/tmp/rct-academic-refresh-20261012-attempt01')
REV=new['frozen_source_revision']
jar=PREFIX/'checkout/services/academic-service/academic-app/build/libs/academic-app-0.1.0.jar'
proof={'producer_revision':REV,'status':'CURRENT_ACADEMIC_PRODUCTION_JAR_ONLY','jar':str(jar),'jar_sha256':'a'*64}
class MockPath:
    def __init__(self,actual):self.actual=actual
    def __truediv__(self,name):return MockPath(self.actual/name)
    def __str__(self):return str(self.actual)
    def read_text(self):return json.dumps(proof)
def mocked_stage_prefix():
    bound=types.SimpleNamespace(PREFIX=MockPath(PREFIX),sha=lambda p:'b'*64 if str(p).endswith('build-result.safe.json') else 'a'*64)
    env={'boundary':bound,'g':{'frozen_source_revision':REV,'build_result_sha256':'b'*64},'json':json}
    exec(compile(stage_receipt_prefix(),'<selected STAGE receipt-only>','exec'),env)
    return env
assert str(mocked_stage_prefix()['jar'])==str(jar);passed('original_BUILD_namespace_receipt_path_new_STAGE_selected_positive_MOCK_ONLY')
proof['producer_revision']='538af12e280bc0e34b62c99c8823a7bb552d6ea6'
denies('new_STAGE_old_source_receipt_denies_before_app_mutation',mocked_stage_prefix)
proof['producer_revision']=REV;proof['jar']='/foreign/app.jar'
denies('new_STAGE_wrong_JAR_path_denies_before_app_mutation',mocked_stage_prefix)

stage=(NEW/'stage-academic.py').read_text(); runtime=(NEW/'runtime-binding.py').read_text()
assert "'academic_refresh_manifest_sha256': g['academic_refresh_manifest_sha256']" in stage
assert "proof['academic_refresh_manifest_sha256'] != grant['academic_refresh_manifest_sha256']" in runtime
assert (NEW/'refresh-boundary.py').read_bytes()==(OLD/'refresh-boundary.py').read_bytes()
passed('NEW_STAGE_result_manifest_NEW_runtime_grant_lineage_same_PREFIX_fixed96')
result={'verdict':'APPROVE_SOURCE','finding':'ACR-RUNTIME-PIN-001 CLOSED_SOURCE','checks':checks,
        'checks_count':len(checks),'original_review_manifest_sha256':'27ca0c46fa1649b96c95d004f5b70eb5b7584bb096aa77d5832f58ee86f621ba',
        'correction_manifest_sha256':sha(NEW/'manifest.json'),'original_BUILD_to_NEW_STAGE':'SOURCE_COHERENT; actualBUILD success/settlement/receiptSHA and fresh NEW STAGE grant separately required',
        'runtime_module_top_level_imports':0,'consumer_exec_and_verify':'MOCKED; author genuine helper-definition/bootstrap control inspected only',
        'BUILD32_controls_replayed':False,'native_build_stage_runtime':'NOT_RUN','private_ENV_key_data_reads':0,
        'selected_requested_model':'gpt-6.1-sol/high','actual_model_effort':'UNKNOWN'}
(HERE/'checks.safe.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'verdict':result['verdict'],'checks':len(checks),'native':False}))
