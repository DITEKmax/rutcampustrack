# Проверка до использования credentials

Scope: только фактическая конфигурация frozen r1 и самостоятельный Chromium с публичным HTML. Root19, исходники r1, reporter, protected fixture, assertions и third-party/browser cache неизменны. Три FAILED попытки77143 и причина UNKNOWN сохранены в отдельном immutable пакете; отсутствие BEGIN не доказывает, что beforeEach не был вызван.

1. Публичный pinned Playwright 1.59.1 configLoader загружает ровно r1 config с CLI overrides workers1/retries0 под тем же явным environment. Не загружает spec/dataset/users, не вызывает seed/login/API/global setup/webServer. Проверяются только число проектов/reporters, канонический путь reporter как boolean, off flags, supported flag, отсутствие debug env, metadata seed flag, loopback target, config-effective teachingInstant TYPE/validity и настоящий requirePrivateArtifacts. Worker-effective teachingInstant TYPE остаётся NOT_MEASURED_CONFIG_ONLY.
2. Поддерживаемый chromium.launch(headless:true) → newContext/newPage → about:blank → константный публичный heading → count/visible → context.close/browser.close. Только штатные настройки Playwright; нет route/mocks, vendor patch, reporter substitution или реального сайта. Даже если config guard отклонён, независимая публичная фаза позволяет отделить browser boot; общий PASS требует обе фазы.

Ошибки обрабатываются только в RAM: allowlisted class и закрытая стадия, никогда message/stack/cause/context/body. stdout/stderr всех children DEVNULL. Нет скриншотов/trace/video/HTML dumps. Только safe JSON: booleans/counts/type enums/stage/exit/PID birth/resource metadata. Browser/context закрываются в finally; b78 страхует таймаут/interrupt с точным pidfd/birth reap. SIGKILL самого supervisor не может выполнить finally: это явное ограничение, а не обещание cleanup при отключении машины.

Новый grant должен связать READY/helper/driver, frozen r1 READY78178/Root19/own13, текущий execution SHA, pinned sources/packages/cache/clock, срок и ресурсы. Deadline≤60s, Node512MiB, суммарный owned RSS≤1.5GiB, новая аллокация≤32MiB, общие floor/reserve из r1. Fresh namespace r1/runs/attempt-02 нужен исключительно для неизменённой проверки private config namespace; исходники r1 не меняются. TMP удаляется только после all-owned-reaped. Stand/readiness/API authority не требуется и не выводится из этого результата.

Команда после отдельного свежего Root grant:

`python3 /workspace/scratch/rct-validation/client_real_acceptance/precredential-probe-r1/run-probe.py /workspace/scratch/rct-validation/client_real_acceptance/precredential-probe-r1/private/root-grant-01.json`

Runtime сейчас NOT_RUN. Это диагностика harness/browser bootstrap, не клиентская приёмка и не доказанная причина старых трёх ошибок.
