"""Read-only inputs; own scratch output. No imported runner/child/signal tools."""
import ast
import copy
import datetime
import hashlib
import json
import os
from pathlib import Path
import stat
import types
import zipfile

OWN = Path(__file__).parent
BASE = Path('/workspace/scratch/rct-validation')
AUTHOR = BASE / 'current_artifact_corrections_v2'
RECEIPTS = Path('/workspace/rutcampustrack/docs/validation/cloud-20261011/receipts/current-artifact-correction-v2-author')

def digest(p):
    with Path(p).open('rb') as stream:
        h = hashlib.sha256()
        for chunk in iter(lambda: stream.read(65536), b''):
            h.update(chunk)
    return h.hexdigest()

def read(p):
    return json.loads(Path(p).read_text())

def save(name, value):
    (OWN / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')

def check_manifest(p):
    manifest = read(p)
    entries = manifest.get('safe_files', manifest.get('files'))
    for row in entries:
        q = Path(row.get('path', row.get('file', row.get('name'))))
        if not q.is_absolute():
            q = p.parent / q
        assert q.stat().st_size == row['bytes'] and digest(q) == row['sha256'], str(q)
    return {'path': str(p), 'sha256': digest(p), 'entries': len(entries), 'exact': True}

author_seal = check_manifest(AUTHOR / 'manifest.json')
assert author_seal['entries'] == 24 and author_seal['sha256'] == 'ff9f2c4121641cd7b530a9eb57919e83051492a666328ed9f649d91e2004c968'
assert digest(AUTHOR / 'bounded-child.py') == 'f539f126bb5591e89f1a9e1f6ac72fbb91ba0da39fccda02cd773ca515acf706'
root_manifest = RECEIPTS / 'manifest.json'
assert root_manifest.read_bytes() == (AUTHOR / 'manifest.json').read_bytes()
with zipfile.ZipFile(RECEIPTS / 'immutable-original-receipts.zip') as archive:
    names = archive.namelist()
    expected = {Path(row['path']).name for row in read(AUTHOR / 'manifest.json')['files']} | {'manifest.json'}
    assert set(names) == expected and len(names) == len(expected)
    for name in names:
        raw = archive.read(name)
        assert raw == (AUTHOR / name).read_bytes(), name
        assert (RECEIPTS / name).read_bytes() == raw, name
save('author24-root-original-identity.json', {'author': author_seal, 'archive_sha256': digest(RECEIPTS / 'immutable-original-receipts.zip'), 'archive_members': len(names), 'all_original_members_exact': True})

def functions(path, names):
    module = ast.parse(path.read_text())
    selected = [node for node in module.body if isinstance(node, ast.FunctionDef) and node.name in names]
    assert {node.name for node in selected} == names
    namespace = {}
    exec(compile(ast.Module(body=selected, type_ignores=[]), str(path), 'exec'), namespace)
    return namespace

old_path = BASE / 'current_artifact_corrections/bounded-child.py'
assert digest(old_path) == '7a5420cac523e3a93f671a1ae4839acdbfbb263f7083c61cc81653af5e353a0a'
old = functions(old_path, {'owned_records'})['owned_records']
new = functions(AUTHOR / 'bounded-child.py', {'owned_records', 'remember_identities'})
def row(pid, birth, ppid, group=100, session=100, state='S'):
    return {'pid':pid,'start_ticks':birth,'ppid':ppid,'pgrp':group,'session':session,'state':state}
parent, group = 200, 100
known = {100: 10}
foreign = {100: row(100,20,999)}
assert set(old(copy.deepcopy(foreign),parent,group,copy.deepcopy(known))) == {100}
assert new['owned_records'](foreign,parent,group,known) == {} and known == {100:10}
pure_cases = ['old_exact_witness_red_new_rejected']
for name, table in [
    ('unknown_same_group_and_session', {101:row(101,21,999)}),
    ('known_changed_birth_direct_parent', {100:row(100,20,parent)}),
    ('changed_birth_ancestor_denies_foreign_child', {100:row(100,20,999),101:row(101,21,100)}),
    ('unowned_ancestry_cycle', {101:row(101,21,102),102:row(102,22,101)})]:
    assert new['owned_records'](table,parent,group,known) == {}, name
    pure_cases.append(name)
owned = {100:row(100,10,parent),300:row(300,12,100,300,300),400:row(400,15,parent,400,400,'Z'),500:row(500,16,400,500,500),101:row(101,21,999)}
selected = new['owned_records'](owned,parent,group,known)
assert set(selected) == {100,300,400,500}
new['remember_identities'](selected,known)
assert known == {100:10,300:12,400:15,500:16}
assert set(new['owned_records']({300:row(300,12,999,900,900)},parent,group,known)) == {300}
pure_cases += ['escaped_and_adopted_Z_owned_positive', 'exact_recorded_identity_outside_numeric_group']
snapshot = known.copy()
try:
    new['remember_identities'](foreign,known)
except RuntimeError:
    pass
else:
    raise AssertionError('identity overwrite not denied')
assert known == snapshot
pure_cases.append('remember_identity_mismatch_denied_without_overwrite')
# Execute only nested refresh AST with synthetic collaborators. No real Popen,
# process table, waitpid, pidfd, subreaper or signal function can be reached.
tree = ast.parse((AUTHOR / 'bounded-child.py').read_text())
run = next(node for node in tree.body if isinstance(node,ast.FunctionDef) and node.name=='run_owned')
refresh = next(node for node in run.body if isinstance(node,ast.FunctionDef) and node.name=='refresh')
wait_calls = []
ns = {'child':types.SimpleNamespace(pid=100,poll=lambda:None), 'process_table':lambda:{100:row(100,20,parent)},
      'owned_records':new['owned_records'],'remember_identities':new['remember_identities'],
      'parent':parent,'known':{100:10},'reaped':[], 'os':types.SimpleNamespace(waitpid=lambda *args:wait_calls.append(args))}
exec(compile(ast.Module(body=[refresh],type_ignores=[]),'synthetic-refresh-only','exec'),ns)
try:
    ns['refresh']()
except RuntimeError as caught:
    assert str(caught) == 'ambiguous adopted child birth identity'
else:
    raise AssertionError('ambiguous adoption falsely empty')
assert ns['known'] == {100:10} and not wait_calls
pure_cases.append('ambiguous_adopted_birth_observation_error_without_reap_or_overwrite')
save('independent-pure-ownership.json', {'old_sha256':digest(old_path),'new_sha256':digest(AUTHOR/'bounded-child.py'),'cases':pure_cases,'pass':True,'actual_control_children':0,'actual_signals':0,'actual_PID_reuse':'NOT_RUN'})

control = read(AUTHOR / 'controls-result.json')
assert control['control_native_exit'] == 0
for name, sha in control['control_sources_SHA'].items():
    assert digest(AUTHOR/name) == sha, name
for name in ['ownership-controls.py','controls.py','signal-runner.py','harmless-tree.py','preserve.py','bounded-child.py']:
    ast.parse((AUTHOR/name).read_text())
ownership = read(AUTHOR/'ownership-controls-result.json')
assert ownership['native_exit'] == 0 and ownership['old_helper_SHA'] == digest(old_path) and ownership['new_helper_SHA'] == digest(AUTHOR/'bounded-child.py')
attempts = [json.loads(line) for line in (AUTHOR/'attempts.ndjson').read_text().splitlines()]
results = {}
identities = []
for name, action, expected_reason, expected_exit, expected_success in [
    ('normal','NORMAL_NATIVE_RESULT','NATIVE_TERMINAL',0,True),
    ('deadline','DEADLINE_NATIVE_RESULT','BOUNDED_DEADLINE',-9,False),
    ('status_failure_during_settlement','STATUS_FAILURE_NATIVE_RESULT','BOUNDED_DEADLINE',-9,False),
    ('two_signals_escaped_descendant','TWO_SIGNAL_CONTROL_SETTLED','STOP_REQUEST',-9,False)]:
    result = control[name]
    assert result['terminal_reason'] == expected_reason and result['native_exit'] == expected_exit and result['phase_success'] is expected_success
    assert result['settled'] and result['all_owned_processes_reaped'] and result['all_members_including_Z_after'] == []
    receipt = next(r for r in attempts if r['action']==action)
    assert all(receipt[k] == v for k,v in result.items())
    assert len(result['adopted_waitpid_receipts']) == 1 and result['adopted_waitpid_receipts'][0]['native_exit'] == expected_exit
    assert result['supervision_error_type'] == ('TypeError' if name=='status_failure_during_settlement' else None)
    identities.extend(result['known_owned_identities'])
    fixture = read(AUTHOR/({'normal':'normal-tree.json','deadline':'deadline-tree.json','status_failure_during_settlement':'status-failure-tree.json','two_signals_escaped_descendant':'signal-tree.json'}[name]))
    assert fixture['parent_pid'] == result['direct_pid'] and fixture['grandchild_pid'] == result['adopted_waitpid_receipts'][0]['pid']
    results[name] = result
assert control['two_signals_escaped_descendant']['signal_count'] == 2
assert read(AUTHOR/'signal-result.json') == control['two_signals_escaped_descendant']
assert read(AUTHOR/'signal-status.json')['state'] == 'REAPED'
assert control['dependent_false_grant'] == {'native_exit':2,'runtime_child_started':False}
assert control['old_counterexample']['actual_unreaped_owned_Z']['state'] == 'Z'
assert control['old_counterexample']['controller_waitpid_native_exit'] == 0
def proc(pid):
    try:
        fields = (Path('/proc')/str(pid)/'stat').read_text().rsplit(')',1)[1].split()
        return {'pid':pid,'state':fields[0],'ppid':int(fields[1]),'pgrp':int(fields[2]),'start_ticks':int(fields[19])}
    except FileNotFoundError:
        return None
for identity in identities:
    now = proc(identity['pid'])
    assert now is None or now['start_ticks'] != identity['start_ticks']
extra_pids = [r['supervisor_pid'] for r in attempts if 'supervisor_pid' in r] + [read(AUTHOR/'counter-tree.json')[k] for k in ['parent_pid','grandchild_pid']]
assert all(proc(pid) is None for pid in extra_pids)
save('actual-control-receipt-audit.json', {'source_vector_exact':control['control_sources_SHA'],'control_native_exit':0,'results':results,'pure_ownership_receipt_exact':True,'all_recorded_8_tree_identities_absent_now':True,'counter_and_supervisor_PIDs_absent_now':True,'reviewer_control_replay':'NOT_RUN','standalone_false_grant_exit':2})

preserved = read(AUTHOR/'preservation-and-old-process-qualification.json')
seals = []
for entry in preserved['original_seals']:
    check = check_manifest(Path(entry['manifest']))
    assert check['sha256'] == entry['sha256'] and check['entries'] == entry['safe_files']
    seals.append(check)
assert sum(r['entries'] for r in seals)==162
prior = [check_manifest(BASE/name/'manifest.json') for name in ['current_artifact_review','current_artifact_correction_review']]
assert [r['entries'] for r in prior] == [23,11]
ART=BASE/'current_client_artifacts'
source=read(ART/'source-inputs-before.json')
for entry in source['tracked']:
    q=Path(source['worktree'])/entry['path']
    assert digest(q)==entry['sha256'] and q.stat().st_size==entry['bytes'] and oct(stat.S_IMODE(q.stat().st_mode))==entry['mode']
deps=read(ART/'installed-deps-before.json')
expected=set()
for entry in deps['entries']:
    expected.add(entry['path'])
    q=Path(deps['source'])/entry['path']
    if entry.get('kind')=='symlink':
        assert q.is_symlink() and os.readlink(q)==entry['target']
    else:
        assert digest(q)==entry['sha256'] and q.stat().st_size==entry['bytes'] and oct(stat.S_IMODE(q.stat().st_mode))==entry['mode']
actual=set()
for directory,dirs,files in os.walk(deps['source'],followlinks=False):
    base=Path(directory)
    actual.update(str((base/name).relative_to(deps['source'])) for name in files)
    actual.update(str((base/name).relative_to(deps['source'])) for name in dirs if (base/name).is_symlink())
assert actual == expected
for entry in preserved['current8_and_old8_JARs']:
    q=Path(entry['path'])
    assert digest(q)==entry['sha256'] and oct(stat.S_IMODE(q.stat().st_mode))==entry['mode']
vue=read(ART/'production-vue-bundles.json')
vue_count=0
for bundle in vue['bundles']:
    for entry in bundle['files']:
        q=Path(bundle['directory'])/entry['path']
        assert digest(q)==entry['sha256'] and q.stat().st_size==entry['bytes'] and oct(stat.S_IMODE(q.stat().st_mode))==entry['mode']
        vue_count+=1
assert len(source['tracked'])==7350 and len(deps['entries'])==8272 and len(preserved['current8_and_old8_JARs'])==16 and vue_count==22
old_processes=[proc(201385),proc(201430)]
assert all(r is not None and r['state']=='Z' and r['ppid']==1 for r in old_processes)
save('independent-preservation.json', {'original_seals':seals,'original_safe_files':162,'old_reviews':prior,'tracked_source':7350,'installed_dependencies':8272,'dependency_pathset_exact':True,'jars':16,'vue_files':22,'full_byte_mode_target_identity':True,'old_processes_observed_only':old_processes,'old_process_mutations':False,'original_rebuild_or_mutation':False})
save('restored-root-inputs.json', {'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'files':[{'path':str(p),'bytes':p.stat().st_size,'sha256':digest(p)} for p in [Path('/workspace/rutcampustrack/docs/validation/cloud-20261011')/name for name in ['TASK-CONTRACT.md','CURRENT.md','decisions.md','questions.md','resources.md','packet-current-artifact-review.md']]]})
print(json.dumps({'status':'PASS_INDEPENDENT_READ_ONLY_AUDITS','author_safe24':True,'pure_cases':len(pure_cases),'actual_control_source_receipts_exact':True,'original_safe162':True,'old_reviews23_11':True,'source7350_deps8272_JAR16_Vue22':True,'new_control_PIDs_absent':True,'old_PID1_Z_observed_only':True}))
