#!/usr/bin/env python3
"""One ordinary bounded child. Preparation only; requires a separate sealed grant.

No daemon, scheduler, service manager, raw application output, or response body.
Use one invocation per manually selected host service. Java retains direct parent.
"""
import argparse
from contextlib import contextmanager
import hashlib
import json
import os
from pathlib import Path
import re
import signal
import subprocess
import time
import urllib.error
import urllib.request

OWN = Path('/workspace/scratch/rct-validation/host_runtime_prepare')
FLOOR = 4 * 1024**3
SERVICES = {'auth', 'academic', 'schedule', 'attendance', 'bff', 'gateway', 'notification'}
PROXY_CA_NAMES = frozenset({'HTTP_PROXY', 'HTTPS_PROXY', 'NO_PROXY',
                            'http_proxy', 'https_proxy', 'no_proxy',
                            'SSL_CERT_FILE', 'SSL_CERT_DIR'})
FIXED_OS_ENV = {'PATH': '/usr/bin:/bin', 'LANG': 'C.UTF-8', 'LC_ALL': 'C.UTF-8'}
FORBIDDEN_ENV = frozenset({'JDK_JAVA_OPTIONS', '_JAVA_OPTIONS', 'JAVA_OPTIONS',
                         'JAVA_HOME', 'CLASSPATH', 'LD_PRELOAD', 'LD_LIBRARY_PATH',
                         'BASH_ENV', 'ENV', 'PYTHONPATH', 'PYTHONHOME',
                         'SPRING_APPLICATION_JSON', 'SPRING_CONFIG_IMPORT',
                         'SPRING_CONFIG_LOCATION', 'SPRING_CONFIG_ADDITIONAL_LOCATION',
                         'SPRING_CONFIG_NAME', 'SPRING_PROFILES_INCLUDE'})


class StopRequest:
    """Signals request shutdown; repeated signals never unwind settlement."""
    def __init__(self):
        self.requested = False
        self.signal_count = 0

    def handler(self, signum, frame):
        self.requested = True
        self.signal_count = min(100, self.signal_count + 1)


@contextmanager
def stop_handlers(stop):
    previous = {value: signal.getsignal(value) for value in (signal.SIGINT, signal.SIGTERM)}
    try:
        for value in previous:
            signal.signal(value, stop.handler)
        yield
    finally:
        for value, handler in previous.items():
            signal.signal(value, handler)


def _wait_terminal(child, timeout):
    deadline = time.monotonic() + timeout
    while True:
        if child.poll() is not None:
            return True
        remaining = deadline - time.monotonic()
        if remaining <= 0:
            return False
        try:
            child.wait(timeout=remaining)
        except KeyboardInterrupt:
            # Defensive: a pending interrupt from outside this handler context
            # cannot spend a new timeout or falsely certify settlement.
            continue
        except (subprocess.TimeoutExpired, OSError):
            return child.poll() is not None


def settle_child(child, stop, terminate_timeout=20, kill_timeout=10):
    """Bounded, idempotent direct-child settlement with factual terminal outcome."""
    with stop_handlers(stop):
        if child.poll() is None:
            try:
                child.terminate()
            except (OSError, ProcessLookupError):
                pass
            if not _wait_terminal(child, terminate_timeout):
                try:
                    child.kill()
                except (OSError, ProcessLookupError):
                    pass
                _wait_terminal(child, kill_timeout)
        code = child.poll()
        return {'settled': code is not None, 'exit': code}


class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, request, fp, code, msg, headers, newurl):
        return None


def digest(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def owned(path):
    path = Path(path)
    if not path.is_absolute() or '..' in path.parts or not path.is_relative_to(OWN):
        raise ValueError('path')
    # Check EVERY existing component, including OWN ancestors, before using a
    # path. Lexical prefix alone accepts OWN/../foreign and is insufficient.
    for entry in [path, *path.parents]:
        if entry.is_symlink():
            raise ValueError('symlink')
    resolved_root = OWN.resolve(strict=True)
    resolved = path.resolve(strict=False)
    if resolved_root != OWN or not resolved.is_relative_to(resolved_root):
        raise ValueError('resolved-path')
    return resolved


def _safe_map(values):
    if not isinstance(values, dict) or len(values) > 128:
        raise ValueError('environment-map')
    for name, value in values.items():
        if (not isinstance(name, str) or not re.fullmatch('[A-Z][A-Z0-9_]{0,127}', name)
                or not isinstance(value, str) or len(value) > 8192 or '\0' in value
                or name in FORBIDDEN_ENV or name.startswith(('DYLD_', 'SPRING_MAIN_'))):
            raise ValueError('environment-channel')


def build_environment(parent, public, private, policy):
    """Lookup only sealed proxy/CA names. Never copy/iterate the real parent env."""
    _safe_map(public)
    _safe_map(private)
    public_names, private_names = policy['public_names'], policy['private_names']
    parent_names = policy['parent_names']
    if (not isinstance(parent_names, list) or not set(parent_names) <= PROXY_CA_NAMES
            or len(parent_names) != len(set(parent_names))
            or set(public_names) != set(public) or set(private_names) != set(private)
            or set(public) & set(private)
            or (set(public) | set(private)) & (PROXY_CA_NAMES | set(FIXED_OS_ENV))
            or 'JAVA_TOOL_OPTIONS' in private):
        raise ValueError('environment-policy')
    options = public.get('JAVA_TOOL_OPTIONS', '').split()
    allowed = [r'-Djava\.security\.egd=file:/dev/\./urandom',
               r'-XX:(?:Max|Initial)RAMPercentage=(?:[0-9]+(?:\.[0-9]+)?)',
               r'-XX:\+UseG1GC', r'-XX:MaxRAM=[0-9]+']
    if any(not any(re.fullmatch(rule, option) for rule in allowed) for option in options):
        raise ValueError('java-environment-options')
    if public.get('SPRING_PROFILES_ACTIVE') != 'prod':
        raise ValueError('profile')
    result = dict(FIXED_OS_ENV)
    for name in parent_names:
        # This selective lookup executes only after a real explicit runtime grant.
        if name in parent:
            value = parent[name]
            if not isinstance(value, str) or len(value) > 8192 or '\0' in value:
                raise ValueError('proxy-ca-value')
            result[name] = value
    result.update(private)
    result.update(public)
    if sum(len(name) + len(value) for name, value in result.items()) > 65536:
        raise ValueError('environment-size')
    return result


def free():
    value = os.statvfs(OWN)
    return value.f_bavail * value.f_frsize


def emit(state, service, **fields):
    print(json.dumps({'state': state, 'service': service, **fields}), flush=True)


def run(spec_path, grant_path, stop_request):
    spec_path, grant_path = owned(spec_path), owned(grant_path)
    spec = json.loads(spec_path.read_text())
    grant = json.loads(grant_path.read_text())
    service = spec['service']
    if service not in SERVICES or not all(grant.get(key) is True for key in
                                         ['app_launch_authorized', 'source_frozen',
                                          'tls_and_routes_reviewed', 'floor_reviewed']):
        raise ValueError('grant')
    if not re.fullmatch('[0-9a-f]{40}', grant.get('product_revision', '')):
        raise ValueError('revision')
    if grant.get('runner_sha256') != digest(Path(__file__)) or grant.get('spec_sha256') != digest(spec_path):
        raise ValueError('identity')
    cwd = owned(spec['cwd']).resolve(strict=True)
    argv = spec['argv']
    if not isinstance(argv, list) or not argv or argv[0] != '/usr/lib/jvm/java-21-openjdk-amd64/bin/java':
        raise ValueError('executable')
    if any(not isinstance(value, str) or re.search('(?i)(password|token|secret)=', value) for value in argv):
        raise ValueError('argv')
    if digest(Path(argv[0])) != grant['java_sha256']:
        raise ValueError('java')
    if not grant['artifacts']:
        raise ValueError('artifacts')
    for artifact in grant['artifacts']:
        path = owned(artifact['path'])
        if path.suffix == '.key' or '/private/' in str(path) or '/tls/' in str(path):
            raise ValueError('artifact-path')
        if digest(path) != artifact['sha256']:
            raise ValueError('artifact')
    env_path = owned(spec['private_environment_file'])
    if env_path.stat().st_uid != os.getuid() or env_path.stat().st_mode & 0o077:
        raise ValueError('private-env-mode')
    policy = grant['environment_policy']
    if (env_path.stat().st_size > 65536
            or digest(env_path) != policy['private_file_sha256']
            or set(policy['private_names']) != set(spec['required_private_names'])):
        raise ValueError('private-environment-identity')
    env = build_environment(os.environ, spec['public_environment'],
                            json.loads(env_path.read_text()), policy)
    # Local readiness bypasses the outbound HTTP proxy; no external URL allowed.
    url = spec['readiness_url']
    if not re.fullmatch(r'http://(127\.0\.0\.1|172\.29\.84\.1):[0-9]+/actuator/health/liveness', url):
        raise ValueError('readiness')
    duration = spec.get('duration_seconds', 600)
    if not isinstance(duration, int) or not 10 <= duration <= 1800:
        raise ValueError('duration')
    rss_stop = spec['rss_stop_bytes']
    if not isinstance(rss_stop, int) or not 256 * 1024**2 <= rss_stop <= 2 * 1024**3:
        raise ValueError('rss-stop')
    if free() < FLOOR:
        raise ValueError('floor')
    opener = urllib.request.build_opener(urllib.request.ProxyHandler({}), NoRedirect())
    start = time.monotonic()
    child = None
    polls = ready = 0
    stop_reason = 'DEADLINE'
    if stop_request.requested:
        emit('INTERRUPTED_NO_CHILD', service)
        return 130
    settlement = None
    try:
        child = subprocess.Popen(argv, cwd=cwd, env=env, stdin=subprocess.DEVNULL,
                                 stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        emit('STARTED', service, pid=child.pid)
        while time.monotonic() - start < duration:
            if stop_request.requested:
                stop_reason = 'INTERRUPT_REQUEST'
                break
            if child.poll() is not None:
                stop_reason = 'CHILD_EXIT'
                break
            if free() < FLOOR:
                stop_reason = 'DISK_FLOOR'
                break
            try:
                status = Path('/proc/' + str(child.pid) + '/status').read_text()
                rss = int(re.search(r'^VmRSS:\s+(\d+) kB$', status, re.MULTILINE)[1]) * 1024
                if rss > rss_stop:
                    stop_reason = 'RSS_SOFT_STOP'
                    break
                cgroup = Path('/sys/fs/cgroup')
                maximum = (cgroup / 'memory.max').read_text().strip()
                current = int((cgroup / 'memory.current').read_text().strip())
                if maximum != 'max' and current > int(maximum) - 1024**3:
                    stop_reason = 'SHARED_MEMORY_RESERVE'
                    break
            except (OSError, ValueError, TypeError):
                stop_reason = 'RESOURCE_OBSERVATION_UNAVAILABLE'
                break
            polls += 1
            try:
                with opener.open(url, timeout=2) as response:
                    code = response.status  # Deliberately never read/log the body.
            except urllib.error.HTTPError as error:
                code = error.code
                error.close()
            except (OSError, ValueError):
                code = 0
            if code == 200 and not ready:
                ready = 1
                emit('LIVENESS_HTTP_200', service, pid=child.pid)
            time.sleep(2)
    finally:
        if child is not None:
            settlement = settle_child(child, stop_request)
            emit('TERMINAL' if settlement['settled'] else 'CHILD_SETTLEMENT_FAILED',
                 service, pid=child.pid, exit=settlement['exit'], settled=settlement['settled'],
                 reason=stop_reason, polls=polls, liveness_http_200=bool(ready),
                 elapsed_seconds=round(time.monotonic() - start, 2))
    if not settlement or not settlement['settled']:
        return 3
    return 130 if stop_request.requested else 0


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--spec', required=True)
    parser.add_argument('--grant', required=True)
    arguments = parser.parse_args()
    stop_request = StopRequest()
    try:
        with stop_handlers(stop_request):
            code = run(arguments.spec, arguments.grant, stop_request)
        raise SystemExit(code)
    except KeyboardInterrupt:
        # A pending interrupt is not evidence that a child was ever settled.
        print('{"state":"INTERRUPT_SAFE_STATUS_UNKNOWN"}', flush=True)
        raise SystemExit(130)
    except (OSError, ValueError, KeyError, TypeError, subprocess.SubprocessError):
        # Exception text may contain environment/request content. Never emit it.
        print('{"state":"BLOCKED_SAFE_VALIDATION_OR_RUNTIME_FAILURE"}', flush=True)
        raise SystemExit(2)
