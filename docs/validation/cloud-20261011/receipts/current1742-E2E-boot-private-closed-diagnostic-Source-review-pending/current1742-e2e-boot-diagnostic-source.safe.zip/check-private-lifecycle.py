"""RAM fake-FD lifecycle only; no actual logs/files/syscalls touched."""
import importlib.util
import json
from pathlib import Path
from types import SimpleNamespace

ROOT=Path(__file__).parent
spec=importlib.util.spec_from_file_location('parser',ROOT/'closed-boot-parser.py')
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
b={'repo':'DITEKmax/rutcampustrack','head':m.HEAD,'run_id':m.RUN,'run_attempt':1,
 'job_id':m.JOB,'job_name':'Playwright E2E auth flow','step_number':9,
 'step_name':m.STEP,'step_conclusion':'failure','step_started_at':'2026-10-13T11:03:00Z',
 'step_completed_at':'2026-10-13T11:04:00Z','metadata_verified':True}
data=b'2026-10-13T11:03:10Z Container rct-e2e-redis-1 Healthy\n'
constants=m.os
checks=[]
def run(name,changes=None,body=data,replacement=False,denied=False,remove=True):
 row=dict(st_mode=0o100600,st_uid=1000,st_nlink=1,st_size=len(body),st_dev=1,
  st_ino=2,st_mtime_ns=3,st_ctime_ns=4);row.update(changes or {})
 st=SimpleNamespace(**row);reads=[];deleted=[];closed=[]
 def open_(name_,flags,dir_fd):
  assert name_=='job.log.private' and dir_fd==10 and flags & constants.O_NOFOLLOW
  return 20
 m.os=SimpleNamespace(O_RDONLY=constants.O_RDONLY,O_NOFOLLOW=constants.O_NOFOLLOW,
  open=open_,fstat=lambda _:st,read=lambda fd,n:(reads.append(fd) or body),
  close=lambda fd:closed.append(fd),
  stat=lambda *a,**k:SimpleNamespace(st_dev=1,st_ino=9 if replacement else 2),
  unlink=lambda name_,dir_fd:deleted.append((name_,dir_fd)))
 try:
  m.consume_private(10,b);assert not denied
 except m.Blocked:
  assert denied
 assert len(reads)<=1 and closed==[20]
 assert bool(deleted)==remove
 checks.append({'name':name,'passed':True})
run('private one-read successful cleanup')
run('malformed parse cleans own private capture',body=b'\xff',denied=True)
run('foreign owner never read or removed',changes={'st_uid':999},denied=True,remove=False)
run('hard alias never read or removed',changes={'st_nlink':2},denied=True,remove=False)
run('nonprivate mode never read or removed',changes={'st_mode':0o100644},denied=True,remove=False)
run('replacement inode denied never removed',replacement=True,denied=True,remove=False)
print(json.dumps({'state':'SOURCE_RAM_CHECKS_PASS','checks':checks,'actual_private_reads':False}))
