"""Public cache/ELF/loader inspection only. Never runs browser entrypoints."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import platform
import re
import stat
import subprocess
OUT=Path(__file__).parent
CACHE=Path('/tmp/rct-validation-browsers-20261012')
CORE=Path('/workspace/rutcampustrack/tests/e2e/node_modules/playwright-core')
ENV={'PATH':'/usr/bin:/bin','LANG':'C','LC_ALL':'C'}
def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return h.hexdigest()
def save(name,v):(OUT/name).write_text(json.dumps(v,indent=2)+'\n')
def snapshot():
 rows=[]
 for p in [CACHE]+sorted(CACHE.rglob('*')):
  s=p.lstat();rows.append({'path':str(p.relative_to(CACHE)),'mode':stat.S_IMODE(s.st_mode),'uid':s.st_uid,'gid':s.st_gid,'nlink':s.st_nlink,'bytes':s.st_size,'mtime_ns':s.st_mtime_ns,'link_target':os.readlink(p) if stat.S_ISLNK(s.st_mode) else None})
 return rows
before=snapshot();save('cache-metadata-before.safe.json',{'rows':before})
old=Path('/workspace/scratch/rct-validation/real_client_runtime/browser-binaries-ready.json')
prior=json.loads(old.read_text())
registry_path=Path('/workspace/scratch/rct-validation/current_host_config_v4/relocation/source-registry.safe.json')
registry={row['relative']:row for row in json.loads(registry_path.read_text())['entries']}
metadata=json.loads((CORE/'browsers.json').read_text())
versions=[row for row in metadata['browsers'] if row['name'] in ['webkit','chromium','chromium-headless-shell']]
osrelease=dict(line.split('=',1) for line in Path('/etc/os-release').read_text().splitlines() if '=' in line)
host={'id':osrelease['ID'].strip('"'),'version_id':osrelease['VERSION_ID'].strip('"'),'architecture':platform.machine()}
save('pinned-build-host.safe.json',{'playwright_core_version':json.loads((CORE/'package.json').read_text())['version'],
 'pinned_browsers':versions,'host':host,'source_derived_platform':'debian13-x64' if host=={'id':'debian','version_id':'13','architecture':'x86_64'} else 'UNKNOWN',
 'source_derived_official_platform':host=={'id':'debian','version_id':'13','architecture':'x86_64'},
 'actual_future_runtime_environment':'NOT_READ; explicit allowlist and no host platform override required',
 'browser_runtime_version_execution':'NOT_RUN; versions above are pinned metadata',
 'public_sources':[{'path':str(p),'sha256':sha(p)} for p in [CORE/'package.json',CORE/'browsers.json',CORE/'lib/server/utils/hostPlatform.js',CORE/'lib/server/registry/index.js',CORE/'lib/server/registry/dependencies.js',Path('/etc/os-release')]],
 'prior_receipt':{'path':str(old),'sha256':sha(old),'host_dependency_warning':prior['host_dependency_warning'],'missing_library_names':prior['missing_library_names']}})
loader=Path('/lib64/ld-linux-x86-64.so.2')
assert loader.exists()
# Exact selected paths from source wrapper; no shell launcher is executed.
variants={}
for name in ['minibrowser-wpe','minibrowser-gtk']:
 root=CACHE/'webkit-2272'/name
 paths=[]
 for d in [root,root/'bin',root/'lib',root/'sys/lib']:
  if not d.is_dir():continue
  for p in sorted(d.iterdir()):
   if p.is_file():
    with p.open('rb') as f:magic=f.read(4)
    if magic==b'\x7fELF':paths.append(p)
 variants[name]=(paths,[root/'lib',root/'sys/lib'])
variants['chromium']=([CACHE/'chromium-1217/chrome-linux64/chrome'],[])
variants['chromium-headless-shell']=([CACHE/'chromium_headless_shell-1217/chrome-headless-shell-linux64/chrome-headless-shell'],[])
result=[]
# Public ldconfig cache read only, equivalent to pinned Playwright's explicit dlopen-name check.
cache=subprocess.run(['/sbin/ldconfig','-p'],env=ENV,capture_output=True,text=True,timeout=10)
assert cache.returncode==0
host_names={m.group(1) for m in re.finditer(r'^\s*(\S+)\s+\(',cache.stdout,re.M)}
for variant,(targets,dirs) in variants.items():
 for p in targets:
  s=p.stat();row=registry.get(str(p.relative_to(CACHE)))
  content=sha(p)
  assert row and content==row['sha256'] and stat.S_IMODE(s.st_mode)==row['mode'] and s.st_uid==row['uid'] and s.st_gid==row['gid']
  d=subprocess.run(['/usr/bin/readelf','-dW',str(p)],env=ENV,capture_output=True,text=True,timeout=10)
  assert d.returncode==0
  needed=re.findall(r'\(NEEDED\).*\[(.*?)\]',d.stdout)
  h=subprocess.run(['/usr/bin/readelf','-lW',str(p)],env=ENV,capture_output=True,text=True,timeout=10)
  assert h.returncode==0
  interpreter=re.findall(r'Requesting program interpreter:\s*([^\]]+)',h.stdout)
  missing_direct=[n for n in needed if n not in host_names and not any((directory/n).is_file() for directory in dirs) and not (p.parent/n).is_file()]
  argv=[str(loader),'--library-path',':'.join(str(x) for x in dirs)] if dirs else [str(loader)]
  argv+=['--list',str(p)]
  native=subprocess.run(argv,env=ENV,capture_output=True,text=True,timeout=10)
  missing_actual=re.findall(r'error while loading shared libraries:\s*([A-Za-z0-9_.+-]+)',native.stderr)
  symbols_missing=bool(re.search(r"version `[^']+' not found",native.stderr))
  resolved=[{'soname':m.group(1),'public_path':m.group(2)} for m in re.finditer(r'^\s*(\S+) => (/\S+)\s+\(',native.stdout,re.M)]
  result.append({'variant':variant,'path':str(p),'mode':stat.S_IMODE(s.st_mode),'sha256':content,'original_vendor_sha_mode_owner_equal':True,'elf_interpreter':interpreter,'direct_needed_sonames':needed,'direct_missing_from_selected_dirs_and_ldcache':missing_direct,'loader_native_exit':native.returncode,'loader_missing_sonames':missing_actual,'version_symbol_error':symbols_missing,'resolved_public_libraries':resolved,'browser_entrypoint_executed':False})
  save('partial-loader-results.safe.json',{'status':'IN_PROGRESS','completed':len(result),'results':result})
dl=[{'name':n,'pinned_registry_ldconfig_substring_available':n.lower() in cache.stdout.lower()} for n in ['libGLESv2.so.2','libx264.so']]
after=snapshot();assert before==after
save('cache-metadata-after.safe.json',{'rows':after,'all_metadata_link_targets_unchanged':True,'selected_regular_sha_equal_relocation_proof':True,'old_browser_path':str(Path('/workspace/scratch/rct-validation/real_client_runtime/browsers')),'old_browser_path_resolves_to_same_CACHE':Path('/workspace/scratch/rct-validation/real_client_runtime/browsers').resolve()==CACHE})
save('loader-results.safe.json',{'status':'READ_ONLY_ELF_PREFLIGHT','loader_public_path':str(loader.resolve()),'loader_sha256':sha(loader),'results':result,'dlopen_name_checks':dl,'browser_launch':'NOT_RUN','current_client_acceptance':'NOT_RUN','cache_unchanged':True})
missing=sorted(set(n for r in result for n in r['loader_missing_sonames']+r['direct_missing_from_selected_dirs_and_ldcache'])|{r['name'] for r in dl if not r['pinned_registry_ldconfig_substring_available']})
save('CURRENT.json',{'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'READ_ONLY_PREFLIGHT_COMPLETE','selected_ELFs':len(result),'missing_sonames':missing,'browser_launch_or_install':'NONE','cache_unchanged':True,'next':'Return exact availability blockers and future source/resource/launch conditions to Root; no dependency mutation granted'})
print(json.dumps({'selected_ELFs':len(result),'missing_sonames':missing,'variants':{name:sum(r['variant']==name for r in result) for name in variants},'native_browser_launch':False,'cache_unchanged':True}))
