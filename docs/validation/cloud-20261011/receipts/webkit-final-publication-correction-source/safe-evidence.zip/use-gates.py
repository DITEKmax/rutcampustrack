"""Fresh ordinary use-time lease/resource checks; no resource mutation."""
import datetime
import os
from pathlib import Path

def resources():
    value={}
    for base in ['/workspace','/tmp']:
        fs=os.statvfs(base);value[base+'_available']=fs.f_bavail*fs.f_frsize
    value['shared_memory']=int(Path('/sys/fs/cgroup/memory.current').read_text())
    value['shared_limit']=int(Path('/sys/fs/cgroup/memory.max').read_text())
    lines=Path('/proc/self/status').read_text().splitlines()
    value['rss']=next((int(line.split()[1])*1024 for line in lines if line.startswith('VmRSS:')),0)
    return value

def require_fresh(stop, allocate_bytes=0):
    if os.getuid()!=1000 or os.getgid()!=1000:
        raise RuntimeError('Exact actor1000 at use required')
    r=resources()
    if (r['/workspace_available']<4294967296 or r['/tmp_available']<4294967296+allocate_bytes
            or r['shared_memory']>=16106127360 or r['shared_limit']-r['shared_memory']<1073741824
            or r['rss']>201326592):
        raise RuntimeError('Fresh resource barrier at use failed')
    # Read the clock last, after potentially delayed filesystem/cgroup preflight.
    if datetime.datetime.now(datetime.timezone.utc)>=stop:
        raise RuntimeError('Grant expired at use')
    return r
