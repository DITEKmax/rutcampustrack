const fs=require('node:fs'),path=require('node:path'),vm=require('node:vm'),crypto=require('node:crypto');
const ts=require('/workspace/rutcampustrack/frontends/node_modules/typescript/lib/typescript.js');
const B='/workspace/scratch/rct-validation/client_real_acceptance/ci-preobserver-diagnostic-b2b3';
const W='/workspace/rct-worktrees/client-ci-first3/tests/e2e';
const marker='RCT_PUBLIC_DIAGNOSTIC_'+crypto.randomUUID();let parsers=0;
function pair(dir){const cache={};function load(name){if(cache[name])return cache[name].exports;const file=path.join(dir,name+'.ts'),source=fs.readFileSync(file,'utf8');parsers+=ts.createSourceFile(file,source,ts.ScriptTarget.ES2022,true).parseDiagnostics.length;const emitted=ts.transpileModule(source,{compilerOptions:{target:ts.ScriptTarget.ES2022,module:ts.ModuleKind.CommonJS}}).outputText;const module={exports:{}};cache[name]=module;const localRequire=id=>id==='./safe-reporter'?load('safe-reporter'):id==='@playwright/test'?require(W+'/node_modules/@playwright/test'):require(id);vm.runInThisContext('(function(require,module,exports){'+emitted+'\n})',{filename:file})(localRequire,module,module.exports);return module.exports;}return{privacy:load('artifact-privacy'),reporter:load('safe-reporter')};}
const old=pair(B+'/before'),current=pair(W+'/fixtures');const rows=[];
function check(code,value){rows.push({code,passed:value===true});}
const message=x=>Object.defineProperty({},'message',{value:x,enumerable:true,configurable:true,writable:true});
const classify=current.reporter.classifySafeFailure;
const facts=(x,cause,status=0)=>{const v=classify(x);return v.cause===cause&&v.httpStatus===status&&!JSON.stringify(v).includes(marker);};
check('KNOWN_LOGIN_STATUS',facts(message('Synthetic actor login: HTTP 401'),'ACTOR_LOGIN_HTTP',401));
check('KNOWN_SESSION_STATUS',facts(message('Synthetic actor session: HTTP 503'),'ACTOR_SESSION_HTTP',503));
check('KNOWN_ROLE_STATUS',facts(message('Synthetic actor role ADMIN: HTTP 403'),'ACTOR_ROLE_HTTP',403));
check('KNOWN_PRIVACY_GUARD',facts(message('Real-mobile credentials require trace/video/screenshots off'),'ARTIFACT_CAPTURE_GUARD'));
check('PUBLIC_TIME_HINT_UNLOCATED',facts(message('Invalid time value'),'INVALID_TIME_VALUE')&&classify(message('Invalid time value')).stage==='UNKNOWN');
check('UNKNOWN_PRIVATE_PAYLOAD',facts(message(marker),'UNKNOWN'));
check('KNOWN_PREFIX_PRIVATE_SUFFIX',facts(message('Synthetic actor login: HTTP 401 '+marker),'UNKNOWN'));
check('MULTILINE_KNOWN_TAIL',facts(message(marker+'\nSynthetic actor login: HTTP 401'),'UNKNOWN'));
check('OVERSIZE_KNOWN_PREFIX',facts(message('Synthetic actor login: HTTP 401'+marker.repeat(100)),'UNKNOWN'));
check('UNKNOWN_STATUS',facts(message('Synthetic actor login: HTTP 599'),'UNKNOWN'));
let getters=0,conversions=0;const hostile={toString(){conversions++;return marker;}};Object.defineProperty(hostile,'message',{get(){getters++;return marker;},configurable:true});Object.defineProperty(hostile,'name',{get(){getters++;return marker;},configurable:true});check('GETTERS_AND_TOSTRING_NOT_CALLED',facts(hostile,'UNKNOWN')&&getters===0&&conversions===0);
check('STACK_NOT_PARSED',facts({message:marker,stack:'Synthetic actor login: HTTP 401'},'UNKNOWN'));
const tag=current.reporter.safeFailureAnnotation;
for(const [code,description]of [['INVALID_ANNOTATION',marker],['STATUS_WITH_WRONG_CAUSE','CLOCK_TARGET_GUARD:401'],['HTTP_WITH_ZERO_STATUS','ACTOR_LOGIN_HTTP:0'],['OVERSIZE_ANNOTATION',marker.repeat(30)]]){const values=current.reporter.safeFailureDiagnostics([{type:tag,description}],true);check(code,values.length===1&&values[0].cause==='UNKNOWN'&&!JSON.stringify(values).includes(marker));}
const annotation={};Object.defineProperty(annotation,'type',{get(){getters++;return tag;}});check('ANNOTATION_GETTER_NOT_CALLED',current.reporter.safeFailureDiagnostics([annotation],true)[0].cause==='UNKNOWN'&&getters===0);
function sanitize(pair,error){const info={annotations:[],errors:[error],file:'public-diagnostic.control.ts',line:1};pair.privacy.sanitizeTestErrors(info);return info;}
function report(pair,info){const reporter=new pair.reporter.default();reporter.onTestEnd({location:{file:'public-diagnostic.control.ts',line:1},parent:{project:()=>({name:'public-control'})},expectedStatus:'failed'},{status:'failed',duration:0,errors:info.errors,annotations:info.annotations,attachments:[]});return reporter.results[0];}
const original=sanitize(old,message('Synthetic actor login: HTTP 401')),corrected=sanitize(current,message('Synthetic actor login: HTTP 401'));const beforeRow=report(old,original),afterRow=report(current,corrected);check('OLD_REPORTER_CANNOT_DELIVER_LOST_CAUSE',beforeRow.diagnostics===undefined&&beforeRow.errorCount===1&&beforeRow.status==='failed');check('NEW_REPORTER_DELIVERS_VALIDATED_CAUSE_WITH_FAILURE',afterRow.diagnostics[0].cause==='ACTOR_LOGIN_HTTP'&&afterRow.errorCount===1&&afterRow.status==='failed');check('BEFORE_LOSES_CAUSE',original.annotations.length===0&&original.errors[0].message==='Check failed; source location and outcome are recorded in safe-results.json');check('AFTER_CAPTURES_BEFORE_WIPE',current.reporter.safeFailureDiagnostics(corrected.annotations,true)[0].cause==='ACTOR_LOGIN_HTTP');
current.privacy.sanitizeTestErrors(corrected);check('REPEATED_SANITIZER_PRESERVES_FIRST_CAUSE',corrected.annotations.length===1);
corrected.errors.push(message('Synthetic actor session: HTTP 503'));current.privacy.sanitizeTestErrors(corrected);check('LATE_ERROR_APPENDS_CLOSED_CAUSE',current.reporter.safeFailureDiagnostics(corrected.annotations,true).some(x=>x.cause==='ACTOR_SESSION_HTTP'));
const privateError=message(marker+'\nSynthetic actor login: HTTP 401');privateError.extra=marker;const privateInfo=sanitize(current,privateError);check('UNKNOWN_ERROR_WIPE_AND_ANNOTATION_NO_MARKER',!JSON.stringify(privateInfo).includes(marker));
const all=rows.every(x=>x.passed);const result={pass:all,count:rows.length,failed:rows.filter(x=>!x.passed).length,controls:rows,parserDiagnosticCount:parsers,qualification:'Actual source functions/public TestInfo adapters only; not worker transport, browser/API or currentCIcause.'};
if(process.argv.includes('--red')){result.pass=false;result.expectedCausalRed=all&&original.annotations.length===0;result.failedOracle='OLD_SOURCE_DIAGNOSTIC_MISSING';}
fs.writeFileSync(process.env.RCT_SAFE_DIAGNOSTIC_RECEIPT,JSON.stringify(result,null,2)+'\n',{mode:0o600});process.exitCode=result.pass?0:1;
