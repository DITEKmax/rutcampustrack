import hashlib
import json
import pathlib
import re
import subprocess

WT = '/workspace/rct-worktrees/np01-contract'
OUT = pathlib.Path('/workspace/scratch/rct-validation/np01_common_review')
OLD = '9757742e9c6baf75760c6cb5174fbdd0fd491a0c'
NEW = '6830731ca81cc03a546ae7a98e0ddfc89605c8c4'
TEST = 'services/academic-service/academic-app/src/test/java/ru/rutcampustrack/academic/migration/BotCredentialLifecycleMigrationIT.java'

def git(*args):
    return subprocess.check_output(['git', '-C', WT, *args])

def blob(revision, path):
    return git('show', revision + ':' + path)

def tree(revision):
    return {x.split('\t', 1)[1]: x.split('\t', 1)[0]
            for x in git('ls-tree', '-r', revision).decode().splitlines()}

def java_tokens(source):
    pattern = re.compile(r'\s+|//[^\n]*|/\*.*?\*/|"(?:[^"\\]|\\.)*"|\'(?:[^\'\\]|\\.)*\'|[A-Za-z_$][A-Za-z_$0-9]*|[0-9]+|>>>|>>|<<|==|!=|<=|>=|&&|\|\||\+\+|--|->|::|.', re.S)
    imports, tokens = [], []
    parts = [x.group() for x in pattern.finditer(source)]
    parts = [x for x in parts if not x.isspace() and not x.startswith('//') and not x.startswith('/*')]
    i = 0
    while i < len(parts):
        if parts[i] == 'import':
            j = parts.index(';', i)
            imports.append(tuple(parts[i:j + 1]))
            i = j + 1
            continue
        value = parts[i]
        if value.startswith('"'):
            value = ('STRING', json.loads(value))
            while i + 2 < len(parts) and parts[i + 1] == '+' and parts[i + 2].startswith('"'):
                value = ('STRING', value[1] + json.loads(parts[i + 2]))
                i += 2
        tokens.append(value)
        i += 1
    return sorted(imports), tokens

old_tree, new_tree = tree(OLD), tree(NEW)
changed = sorted(p for p in set(old_tree) | set(new_tree) if old_tree.get(p) != new_tree.get(p))
assert changed == [TEST], changed
old_test, new_test = blob(OLD, TEST), blob(NEW, TEST)
old_semantics, new_semantics = java_tokens(old_test.decode()), java_tokens(new_test.decode())
assert old_semantics == new_semantics
test_names = re.findall(r'@Test\s+void\s+(\w+)\(', new_test.decode())
assert len(test_names) == 14
source_inventory = json.loads((OUT / 'source-inventory.safe.json').read_text())
final_inputs = []
for entry in source_inventory['source_paths']:
    data = blob(NEW, entry['path'])
    final_inputs.append({'path': entry['path'], 'revision': NEW,
                         'sha256': hashlib.sha256(data).hexdigest(), 'bytes': len(data)})
result = {'status': 'PASS', 'source_before': OLD, 'source_after': NEW,
          'independent_git_tree_paths_compared': len(old_tree),
          'changed_paths': changed, 'imports_equal_after_sort': True,
          'java_tokens_equal_after_whitespace_comments_and_adjacent_string_literals_normalized': True,
          'retained_test_names': test_names, 'product_three_paths_identical': True,
          'final_source_inventory': final_inputs,
          'qualification': 'Independent exact committed source bridge; author Spotless outcome separately reported; no new runtime execution'}
(OUT / 'format-bridge-recheck.safe.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({'status': 'PASS', 'source_after': NEW, 'tracked_paths': len(old_tree),
                  'changed_paths': changed, 'retained_cases': len(test_names)}))
