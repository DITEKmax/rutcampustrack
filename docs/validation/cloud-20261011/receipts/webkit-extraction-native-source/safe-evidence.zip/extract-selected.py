"""Exact public DSO copy only, blocked without NEW reviewed Root grant."""
import argparse
import datetime
import hashlib
import io
import json
import os
from pathlib import Path
import stat
import tarfile
import types

OWN = Path(__file__).parent
PAYLOAD_SOURCE = OWN.parent / 'browser_webkit_payload_context_correction'
PREFIX = Path('/tmp/rct-webkit-native-deps-20261012')
CAP = 33554432
RSS = 201326592

def sha(path):
    digest = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for chunk in iter(lambda: stream.read(1048576), b''):
            digest.update(chunk)
    return digest.hexdigest()

def regular(path):
    raw = str(path)
    path = Path(raw)
    if not path.is_absolute() or str(path) != raw or '..' in path.parts:
        raise RuntimeError('Exact lexical input required')
    for parent in reversed(path.parents):
        if not stat.S_ISDIR(parent.lstat().st_mode):
            raise RuntimeError('Input symlink ancestor denied')
    if not stat.S_ISREG(path.lstat().st_mode):
        raise RuntimeError('Exact regular input required')
    return path

def load(path, name):
    module = types.ModuleType(name)
    module.__file__ = str(path)
    exec(compile(regular(path).read_bytes(), str(path), 'exec'), module.__dict__)
    return module

def validate_grant(grant, now):
    required = {'library_extraction_authorized': True, 'native_validation_authorized': False,
                'browser_launch_authorized': False, 'prefix': str(PREFIX),
                'prefix_allocated_cap': CAP, 'rss_stop_bytes': RSS,
                'execution_actor_uid': 1000, 'execution_actor_gid': 1000,
                'selected_regular_count': 14, 'selected_symlink_count': 8,
                'selected_regular_bytes': 12231288}
    if any(type(grant.get(key)) is not type(value) or grant[key] != value
           for key, value in required.items()):
        raise RuntimeError('NEW exact extraction-only Root grant required')
    start = datetime.datetime.fromisoformat(grant['not_before_utc'])
    stop = datetime.datetime.fromisoformat(grant['stop_utc'])
    if (start.utcoffset() != datetime.timedelta(0) or stop.utcoffset() != datetime.timedelta(0)
            or not start <= now < stop or not 0 < (stop-start).total_seconds() <= 600):
        raise RuntimeError('Fresh finite600s UTC grant required')
    return stop

def main():
    if os.getuid() != 1000 or os.getgid() != 1000:
        raise RuntimeError('Exact approved actor1000 required')
    parser = argparse.ArgumentParser()
    parser.add_argument('--grant', required=True)
    args = parser.parse_args()
    grant_path = regular(args.grant)
    metadata = grant_path.lstat()
    if (grant_path != OWN / 'private/extract-grant.json' or metadata.st_uid != 1000
            or stat.S_IMODE(metadata.st_mode) != 0o600 or metadata.st_nlink != 1
            or metadata.st_size > 65536):
        raise RuntimeError('Exact NEW own private grant600 required')
    grant = json.loads(grant_path.read_text())
    stop = validate_grant(grant, datetime.datetime.now(datetime.timezone.utc))
    manifest_path = regular(OWN / 'manifest.json')
    if sha(manifest_path) != grant['source_manifest_sha256']:
        raise RuntimeError('Exact reviewed source seal required')
    manifest = json.loads(manifest_path.read_text())
    if not any(row['path'] == str(Path(__file__).absolute()) and row['sha256'] == sha(__file__)
               for row in manifest['files']):
        raise RuntimeError('Actual executing source must be sealed')
    for row in manifest['files']:
        if sha(regular(row['path'])) != row['sha256']:
            raise RuntimeError('Source input changed')
    if sha(regular(grant['source_review_manifest'])) != grant['source_review_manifest_sha256']:
        raise RuntimeError('Fresh independent source review required')
    for row in json.loads((OWN / 'prior-authorities.safe.json').read_text())['seals']:
        if sha(regular(row['path'])) != row['sha256']:
            raise RuntimeError('Prior exact authority changed')
        prior = json.loads(Path(row['path']).read_text())
        for member in prior.get('files', prior.get('entries', [])):
            path = Path(member['path'])
            if not path.is_absolute():
                path = Path(row['path']).parent / path
            if sha(regular(path)) != member['sha256']:
                raise RuntimeError('Prior source/header/package authority changed')
    selected = json.loads((OWN / 'selected-dso-headers.safe.json').read_text())['selected']
    selection = load(OWN / 'selection.py', 'selected')
    selection.validate_selection(selected)
    driver = load(PAYLOAD_SOURCE / 'download-headers.py', 'namespace_source')
    headers = load(PAYLOAD_SOURCE / 'public-headers.py', 'public_headers')
    archives = json.loads((OWN / 'signed-archive-inputs.safe.json').read_text())['exact_archives']
    expected_archives = {row['package']: row for row in json.loads((PAYLOAD_SOURCE / 'approved-packages.safe.json').read_text())['packages']}
    for archive in archives:
        path = regular(archive['path'])
        meta = path.lstat()
        expected = expected_archives[path.stem]
        if (meta.st_uid != 1000 or meta.st_nlink != 1 or stat.S_IMODE(meta.st_mode) != 0o600
                or meta.st_size != expected['download_bytes'] or sha(path) != expected['package_sha256']):
            raise RuntimeError('Exact signed archive changed')
    before = driver.resources()
    if driver.resource_stop(before) or before['/tmp_available'] < 4294967296 + CAP:
        raise RuntimeError('Fresh floor plus exactprefix budget required')
    ns = driver.Namespace(PREFIX)
    directories = {'.': (ns.fds[-1], None)}
    copied = []
    stage = 'PREFIX_CREATED'
    def check():
        ns.check()
        now = datetime.datetime.now(datetime.timezone.utc)
        if now >= stop or driver.resource_stop(driver.resources()):
            raise RuntimeError('Finite grant or resource stop')
        allocated = 0
        def fail(error):
            raise error
        permitted = {row['name'] for row in selected} | {'launch.safe.json', 'partial.safe.json', 'terminal.safe.json', 'error.safe.json'}
        permitted |= {str(parent) for row in selected for parent in Path(row['name']).parents if str(parent) != '.'}
        for parent, dirs, files in os.walk(PREFIX, followlinks=False, onerror=fail):
            for name in dirs + files:
                path = Path(parent) / name
                info = path.lstat()
                if info.st_uid != 1000 or str(path.relative_to(PREFIX)) not in permitted:
                    raise RuntimeError('Foreign prefix entry denied')
                allocated += info.st_blocks * 512
        if allocated > CAP:
            raise RuntimeError('Ownprefix allocated cap')
        for name, (fd, identity) in directories.items():
            if name == '.':
                continue
            if driver.Namespace.identity(os.fstat(fd)) != identity or driver.Namespace.identity((PREFIX / name).lstat()) != identity:
                raise RuntimeError('Pinned exact extraction ancestor changed')
        return allocated
    def parent_fd(name):
        current = '.'
        for part in Path(name).parts[:-1]:
            previous = directories[current][0]
            current = part if current == '.' else current + '/' + part
            if current not in directories:
                check()
                os.mkdir(part, 0o700, dir_fd=previous)
                fd = os.open(part, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW | os.O_CLOEXEC, dir_fd=previous)
                identity = driver.Namespace.identity(os.fstat(fd))
                if identity['uid'] != 1000 or identity['mode'] != 0o700:
                    raise RuntimeError('Exact own extraction ancestor700 required')
                directories[current] = (fd, identity)
        return directories[current][0]
    try:
        ns.save('launch.safe.json', {'utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
                                    'pid': os.getpid(), 'resources_before': before,
                                    'extraction_only': True, 'native_children': 0})
        for archive in archives:
            package = Path(archive['path']).stem
            wanted = {row['name']: row for row in selected if row['package'] == package}
            if not wanted:
                continue
            stage = 'VERIFY_PUBLIC_HEADERS'
            check()
            blob = Path(archive['path']).read_bytes()
            signed = expected_archives[package]
            if len(blob)!=signed['download_bytes'] or hashlib.sha256(blob).hexdigest()!=signed['package_sha256']:
                raise RuntimeError('Actual public bytes read must match signed archive')
            inspected = headers.inspect_deb(blob)
            full = {row['name']: row for row in inspected['data']['rows']}
            for name, row in wanted.items():
                if full.get(name) != {key: value for key, value in row.items() if key != 'package'}:
                    raise RuntimeError('Exact selected public header changed')
            members, control_name, data_name = headers.ar_members(blob)
            raw = headers.tar_bytes(data_name, members[data_name])
            del blob, members
            with tarfile.open(fileobj=io.BytesIO(raw), mode='r:') as tar:
                for member in tar:
                    name = headers.clean_name(member.name, member.isdir())
                    row = wanted.get(name)
                    if row is None or row['kind'] != 'regular':
                        continue
                    if not member.isreg() or member.size != row['declared_bytes'] or member.mode != 0o644:
                        raise RuntimeError('Exact bounded regular payload member required')
                    stage = 'COPY_EXACT_REGULAR_DSO'
                    check()
                    parent = parent_fd(name)
                    fd = os.open(Path(name).name, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW | os.O_CLOEXEC,
                                 0o644, dir_fd=parent)
                    created = os.fstat(fd)
                    if not stat.S_ISREG(created.st_mode) or created.st_uid != 1000 or created.st_nlink != 1:
                        os.close(fd)
                        raise RuntimeError('New unaliased own payload FD required')
                    os.fchmod(fd, 0o644)
                    written = 0
                    digest = hashlib.sha256()
                    with os.fdopen(fd, 'wb') as target, tar.extractfile(member) as stream:
                        for chunk in iter(lambda: stream.read(65536), b''):
                            written += len(chunk)
                            if written > row['declared_bytes']:
                                raise RuntimeError('Declared payload size exceeded')
                            digest.update(chunk)
                            target.write(chunk)
                            check()
                        target.flush()
                        os.fsync(target.fileno())
                    if written != row['declared_bytes']:
                        raise RuntimeError('Exact copied member bytes required')
                    meta = (PREFIX / name).lstat()
                    if (not stat.S_ISREG(meta.st_mode) or meta.st_uid != 1000 or meta.st_nlink != 1
                            or stat.S_IMODE(meta.st_mode) != 0o644 or sha(PREFIX / name) != digest.hexdigest()):
                        raise RuntimeError('Exact copied regular identity required')
                    copied.append({'name': name, 'bytes': written, 'sha256': digest.hexdigest()})
                    ns.save('partial.safe.json', {'copied': copied, 'allocated': check()})
            del raw
        if len(copied) != 14 or {row['name'] for row in copied} != {row['name'] for row in selected if row['kind'] == 'regular'}:
            raise RuntimeError('Exact14 genuineDSO copies required')
        stage = 'CREATE_EXACT_CONTAINED_SONAME_LINKS'
        for row in selected:
            if row['kind'] != 'symlink':
                continue
            check()
            target = PREFIX / row['link']['normalized_target']
            expected = next(item for item in copied if item['name'] == row['link']['normalized_target'])
            if sha(regular(target)) != expected['sha256']:
                raise RuntimeError('Exact copied link target required')
            os.symlink(row['link']['target'], Path(row['name']).name, dir_fd=parent_fd(row['name']))
            if os.readlink(PREFIX / row['name']) != row['link']['target']:
                raise RuntimeError('Exact relative link target required')
        ns.save('terminal.safe.json', {'status': 'EXACT14_DSO_8_RELATIVE_LINKS_COPIED', 'copied': copied,
                                      'actual_allocated_bytes': check(), 'resources': driver.resources(),
                                      'nativeABI_dlopen_browser': 'NOT_RUN'})
        print(json.dumps({'status': 'EXACT_DSO_COPY_COMPLETE', 'regular': 14, 'relative_symlinks': 8,
                          'native_validation_or_browser': False}))
        return 0
    except BaseException as caught:
        ns.save('error.safe.json', {'status': 'PARTIAL_STOPPED', 'stage': stage,
                                   'error_type': type(caught).__name__, 'completed_regular': len(copied),
                                   'native_validation_or_browser': False})
        print(json.dumps({'status': 'PARTIAL_STOPPED', 'stage': stage, 'error_type': type(caught).__name__}))
        return 1
    finally:
        for name, (fd, identity) in directories.items():
            if name != '.':
                os.close(fd)
        ns.close()

if __name__ == '__main__':
    raise SystemExit(main())
