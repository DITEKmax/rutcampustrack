"""Copy the original runner with one exact-child bootstrap gate correction."""
from pathlib import Path

OWN = Path(__file__).parent
BASE = OWN.parent / 'current_host_config_v5'

HELPER = '''def exact_live_child(record, table):
    pid = record.get('child_pid')
    if type(pid) is not int or pid <= 0:
        return False
    rows = [row for row in record.get('members_including_Z', []) if row.get('pid') == pid]
    if len(rows) != 1:
        return False
    birth = rows[0].get('start_ticks')
    if type(birth) is not int or birth <= 0:
        return False
    current = table.get(pid)
    return (current is not None and current.get('pid') == pid
            and current.get('start_ticks') == birth
            and current.get('state') in {'R', 'S', 'D', 'T', 't', 'I', 'W'})

'''

def main():
    source = (BASE / 'run-mongo.py').read_text()
    source = source.replace('OWN = Path(__file__).parent',
        'CORRECTION = Path(__file__).parent\nOWN = Path(' + repr(str(BASE)) + ')', 1)
    old = """        owned = [r for r in record.get('members_including_Z', []) if table.get(r['pid'], {}).get('start_ticks') == r['start_ticks']
                 and table[r['pid']]['state'] != 'Z']
        if not owned or not db.is_dir() or db.is_symlink() or not runtime.is_dir() or runtime.is_symlink():"""
    new = """        if not exact_live_child(record, table) or not db.is_dir() or db.is_symlink() or not runtime.is_dir() or runtime.is_symlink():"""
    assert source.count(old) == 1
    source = source.replace(old, new)
    source = source.replace('def main():', HELPER + 'def main():', 1)
    source = source.replace("    spec = json.loads((OWN / 'mongo-spec.json').read_text())", """    if digest(CORRECTION / 'manifest.json') != grant.get('mongo_identity_correction_manifest_sha256'):
        raise RuntimeError('New exact reviewed Mongo identity correction grant required')
    correction_manifest = json.loads((CORRECTION / 'manifest.json').read_text())
    corrected_source = exact_regular(Path(__file__).absolute())
    self_row = next((row for row in correction_manifest['files'] if row['path'] == str(corrected_source)), None)
    if self_row is None or digest(corrected_source) != self_row['sha256']:
        raise RuntimeError('Executing corrected source must be an exact sealed correction member')
    for row in correction_manifest['files']:
        if digest(exact_regular(row['path'])) != row['sha256']:
            raise RuntimeError('Sealed identity correction input changed')
    spec = json.loads((OWN / 'mongo-spec.json').read_text())""", 1)
    (OWN / 'run-mongo.py').write_text(source)

if __name__ == '__main__':
    main()
