"""Exact Docker6 CLI in the accepted foreground guard; NEW Root grant required."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import stat
import types

OWN = Path('/workspace/scratch/rct-validation/current_host_config_v5')
OUT = Path(__file__).parent
ROOT = OWN.parent
IDENTITY = ROOT / 'current_host_config_v5_mongo_identity_correction'
REDIRECT = ROOT / 'current_host_config_v5_redirect_query_correction'
os.umask(0o077)

def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def save(name, value):
    (OUT / name).write_text(json.dumps(value, indent=2) + '\n')

def resources():
    result = {'utc': datetime.datetime.now(datetime.timezone.utc).isoformat()}
    for base in ['/workspace', '/tmp']:
        f = os.statvfs(base)
        result[base + '_available'] = f.f_bavail * f.f_frsize
    result['shared_memory'] = int(Path('/sys/fs/cgroup/memory.current').read_text())
    result['shared_limit'] = int(Path('/sys/fs/cgroup/memory.max').read_text())
    return result

def main():
    grant_path = OWN / 'private/launch-grant.json'
    metadata = grant_path.lstat()
    assert stat.S_ISREG(metadata.st_mode) and stat.S_IMODE(metadata.st_mode) == 0o600 and metadata.st_uid == os.getuid()
    grant = json.loads(grant_path.read_text())
    assert grant.get('launch_authorized') is True and grant.get('native_mongo_authorized') is True
    assert grant.get('heavy_leases_released') == {'NP01_BROKER1': True, 'FORMAT_JAVA': True, 'FORMAT_NODE': True}
    exact = [(OWN / 'launch-manifest.json', 'e3b6e2c80d819e758bd54722a0d348764dcee5ce64a1ede0cd20df16adc96378'),
             (REDIRECT / 'manifest.json', '75e4107b7053de13feb12d5cdbecfdae67124b1cdd01fee1ab52140c0439ab73'),
             (IDENTITY / 'manifest.json', '077de277ed0dd9182e36da132c0e82611d65504382a9e45692d07ffe9d0a0e95'),
             (IDENTITY / 'launch-schema-addendum-manifest.json', 'b3c273ecf189f33c484945513dd5fd8ccc1bc20257b768da51e695a57c5846ec')]
    for path, sha in exact:
        assert digest(path) == sha
        for row in json.loads(path.read_text())['files']:
            assert digest(row['path']) == row['sha256']
    assert grant['config_manifest_sha256'] == exact[0][1]
    assert grant['mongo_identity_correction_manifest_sha256'] == exact[2][1]
    assert digest(grant['config_review_manifest']) == grant['config_review_manifest_sha256'] == '8dd93948d3faf69df5aa5b671726c1083b9f8539aa547dccff780d47c14eb8f4'
    assert digest(grant['guard_review_manifest']) == grant['guard_review_manifest_sha256'] == 'c61b4647f8467726d2fdc308c2fb046fa1e3552c99e2b2294f1c8524c1c6fb36'
    guard_path = ROOT / 'guard_proc_race_correction/bounded-child.py'
    body = guard_path.read_bytes()
    assert hashlib.sha256(body).hexdigest() == grant['reviewed_guard_sha256'] == 'b78c61293568d9941692e0b92ee34fd0b84db6d532b4a2c9a5ad42ccbf2204a0'
    guard = types.ModuleType('reviewed_guard')
    guard.__file__ = str(guard_path)
    exec(compile(body, str(guard_path), 'exec'), guard.__dict__)
    argv = json.loads((IDENTITY / 'effective-launch-inputs-v2.json').read_text())['docker_argv']
    assert argv.count('-f') == 2 and '--no-build' in argv and argv[argv.index('--pull') + 1] == 'never'
    assert argv == json.loads((REDIRECT / 'effective-launch-inputs.json').read_text())['docker_argv']
    initial = resources()
    assert initial['/workspace_available'] >= 9380818650
    assert initial['/tmp_available'] >= 4294967296 + 1073741824

    def observe():
        now = resources()
        save('resources-live.safe.json', now)
        if now['/workspace_available'] < 4294967296 or now['/tmp_available'] < 4294967296:
            return 'DISK_FLOOR'
        if now['shared_memory'] >= 16106127360 or now['shared_limit'] - now['shared_memory'] < 1073741824:
            return 'SHARED_MEMORY_STOP'
        return None

    identity = guard.process_table()[os.getpid()]
    save('docker-up-launch.safe.json', {'utc': initial['utc'], 'wrapper_identity': identity, 'argv': argv,
        'resources_before': initial, 'four_seals_verified': True, 'stdio': 'DEVNULL, no private values or Health.Log'})
    save('CURRENT.json', {'status': 'DOCKER6_UP_IN_PROGRESS', 'wrapper_pid': os.getpid(),
        'wrapper_birth_ticks': identity['start_ticks'], 'next': 'Actual Docker allocation/floor plus1GiB growth barrier before nativeMongo/Host7'})
    result = guard.run_owned(argv, str(OWN), {'PATH': '/usr/local/bin:/usr/bin:/bin', 'HOME': str(OWN / 'runtime'),
        'LANG': 'C.UTF-8', 'LC_ALL': 'C.UTF-8'}, deadline_seconds=min(600, grant['deadline_seconds']),
        observe=observe, status=lambda value: save('docker-up-process.safe.json', value))
    save('docker-up-terminal.safe.json', {'utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'guard': result, 'resources_after': resources()})
    print(json.dumps({'native_exit': result['native_exit'], 'settled': result['settled'], 'phase_success': result['phase_success'],
                      'reason': result['terminal_reason'], 'resources': resources()}))
    return 0 if result['phase_success'] else 1

if __name__ == '__main__':
    raise SystemExit(main())
