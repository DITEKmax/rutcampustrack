# P06 cleanup correction — independent narrow recheck

APPROVE_SOURCE_CORRECTION. P06-TEST-CLEANUP-001 is resolved in Source; no new blocking finding.

[InternalSessionAdmissionIT.java:293](/workspace/rct-worktrees/shared-validator-execution-20261013/services/auth-service/auth-app/src/test/java/ru/rutcampustrack/auth/integration/InternalSessionAdmissionIT.java:293) attempts unpause for the exact owned fixture after any attempted pause, without an inspect gate. The catch preserves and rethrows the primary failure. A distinct cleanup failure is suppressed onto it; cleanup-only failure propagates; identity guard prevents self-suppression. Normal release retains all original recovery oracles.

Six independently derived current-Source V8 RAM branch controls passed: lost pause response, primary plus cleanup failure, cleanup failure alone, no attempt, same error identity, normal recovery. These are logical Source controls with synthetic callbacks, not Java/JVM/Docker/PG execution. Java precise-rethrow rules make both effectively final Throwable catch parameters plausible under the method's throws Exception; actual compile remains NOT_RUN.

All10 pins match. New test64df4a761c29e99870e49400b67bd07c0497e285ca54861c32e25982a0598c3d; READY3fee6aea7d42471f791170feee143254b67cd7a238cc1c5aa952a6a3d8fcdb63. Only cleanup delta; inverse restores36bb. Whole inverse restores baseline ed055; helpers/assertions/clocks/timeouts/fixture defaults unchanged. Prior complete independent critical-test assessment and focused503→401 mutation proposal are reused.

Actual format/compile/selected PG run and focused mutation remain pending. Full OS restart, Gateway/client/all-role acceptance and parentP06 remain UNKNOWN. Created only this own safe narrow review receipt/manifest/archive; no source/shareddocs/private artifacts/native actions/children.
