"""Full selected publication expression; delayed metadata is mocked, no native calls."""
import ast
import datetime
import json
import types
from pathlib import Path

OWN = Path(__file__).parent
OLD = OWN.parent / 'browser_webkit_native_deadline_correction'
stop = datetime.datetime(2026, 10, 12, 17, 0, tzinfo=datetime.timezone.utc)
clock = {'now': stop}
gates = types.ModuleType('gates')
exec(compile((OWN / 'use-gates.py').read_bytes(), 'selected_use_gates', 'exec'), gates.__dict__)

class Clock:
    @classmethod
    def now(cls, tz):
        return clock['now']

gates.datetime = types.SimpleNamespace(datetime=Clock, timezone=datetime.timezone)
gates.os = types.SimpleNamespace(getuid=lambda: 1000, getgid=lambda: 1000)
gates.resources = lambda: {'/workspace_available': 10000000000, '/tmp_available': 10000000000,
    'shared_memory': 3000000000, 'shared_limit': 17179869184, 'rss': 12000000}

def selected(path, count):
    tree = ast.parse(path.read_text())
    main = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == 'main')
    body = next(n for n in main.body if isinstance(n, ast.Try)).body
    index = next(i for i, n in enumerate(body) if isinstance(n, ast.Expr)
        and isinstance(n.value, ast.Call) and ast.unparse(n.value.func) == 'out.save'
        and isinstance(n.value.args[0], ast.Constant) and n.value.args[0].value == 'native-validation.safe.json')
    assert ast.unparse(body[index-1]).startswith('gates.require_fresh(stop)')
    nodes = body[index-count+1:index+1]
    return compile(ast.Module(body=nodes, type_ignores=[]), str(path), 'exec')

checks = []
for label, path, count, delay, already_expired, want_save in [
    ('old_full_resource_argument_delay_publishes_after_stop', OLD / 'validate-native.py', 2, 2, False, True),
    ('new_full_resource_argument_delay_rejected_before_save', OWN / 'validate-native.py', 3, 2, False, False),
    ('new_complete_payload_fresh_positive_saves_before_stop', OWN / 'validate-native.py', 3, 0, False, True),
    ('new_already_expired_never_saves', OWN / 'validate-native.py', 3, 0, True, False),
]:
    clock['now'] = stop + datetime.timedelta(seconds=1 if already_expired else -1)
    events = []
    def slow_resources():
        clock['now'] += datetime.timedelta(seconds=delay)
        return {'public_metadata': True}
    def save(name, payload):
        events.append({'saved_at_or_after_stop': clock['now'] >= stop, 'status': payload['status']})
    ns = {'gates': gates, 'stop': stop, 'driver': types.SimpleNamespace(resources=slow_resources),
        'out': types.SimpleNamespace(save=save), 'g': {'source_manifest_sha256': 'public-test-source',
        'extraction_receipt_sha256': 'public-test-extraction'}, 'results': [], 'vendor': [],
        'identities': [], 'selected': []}
    rejected = False
    try:
        exec(selected(path, count), ns)
    except RuntimeError:
        rejected = True
    assert bool(events) == want_save, label
    if want_save:
        assert events[0]['saved_at_or_after_stop'] == (path.parent == OLD), label
    else:
        assert rejected and events == [], label
    checks.append({'case': label, 'pass': True, 'mock_save_events': events,
        'actual_native_payload_files_or_proof_publication': False})
(OWN / 'publication-controls.safe.json').write_text(json.dumps({'status': 'PASS_SELECTED_FULL_PUBLICATION_EXPRESSION',
    'count': len(checks), 'checks': checks, 'old_late_success_counterexample': True,
    'new_DELAY_DURING_full_payload_construction_denied': True}, indent=2) + '\n')
print(json.dumps({'full_publication_controls': len(checks), 'actual_native_or_extraction': False}))
