const fs = require('node:fs'), path = require('node:path'), vm = require('node:vm'), crypto = require('node:crypto');
const ts = require('/workspace/rutcampustrack/frontends/node_modules/typescript/lib/typescript.js');
const W = '/workspace/rct-worktrees/client-ci-first3/tests/e2e';
const { serializeError } = require(W + '/node_modules/playwright/lib/util.js');
const marker = 'RCT_PUBLIC_HINT_PRIORITY_' + crypto.randomUUID();
let parserDiagnosticCount = 0;
function pair(dir) {
  const cache = {};
  function load(name) {
    if (cache[name]) return cache[name].exports;
    const file = path.join(dir, name + '.ts'), source = fs.readFileSync(file, 'utf8');
    parserDiagnosticCount += ts.createSourceFile(file, source, ts.ScriptTarget.ES2022, true).parseDiagnostics.length;
    const output = ts.transpileModule(source, { compilerOptions: { target: ts.ScriptTarget.ES2022, module: ts.ModuleKind.CommonJS } }).outputText;
    const box = { exports: {} }; cache[name] = box;
    const local = id => id === './safe-reporter' ? load('safe-reporter') : id === '@playwright/test' ? require(W + '/node_modules/@playwright/test') : require(id);
    vm.runInThisContext('(function(require,module,exports,__dirname){' + output + '\n})', { filename: file })(local, box, box.exports, dir);
    return box.exports;
  }
  return { privacy: load('artifact-privacy'), reporter: load('safe-reporter') };
}
const baseline = pair(__dirname + '/before'), broken = pair(__dirname + '/before-hints'), current = pair(W + '/fixtures');
const selected = process.argv[2] === 'old' ? broken : current;
const statuses = [400,401,403,404,409,422,423];
const annotation = (p, cause, status = 0) => ({ type: p.reporter.safeFailureAnnotation, description: cause + ':' + status });
const coreAnnotations = p => [annotation(p, 'UNKNOWN'), ...statuses.map(status => annotation(p, 'ACTOR_LOGIN_HTTP', status))];
const hintError = () => {
  const error = new TypeError(marker);
  error.stack = 'TypeError: ' + marker + '\n    at Actor.call (' + W + '/fixtures/mobile-dataset.ts:38:13)';
  return serializeError(error);
};
const httpError = status => serializeError(new Error('Synthetic actor login: HTTP ' + status));
function outcome(p, kind) {
  const info = { annotations: kind === 'CORE_BEFORE_HINTS' ? coreAnnotations(p) : [], errors: [], file: 'priority.control.spec.ts', line: 1 };
  let sequence;
  if (kind === 'CORE_BEFORE_HINTS') sequence = [hintError(), hintError()];
  else if (kind === 'HINTS_BEFORE_CORES') sequence = [hintError(), ...statuses.map(httpError)];
  else if (kind === 'REPEATED_HINTS_BEFORE_LATE_CORE') sequence = [hintError(), hintError(), ...statuses.flatMap(status => [httpError(status), hintError()]), hintError()];
  else sequence = [hintError(), ...statuses.flatMap(status => [hintError(), httpError(status), hintError()])];
  for (const error of sequence) {
    info.errors.push(error);
    p.privacy.sanitizeTestErrors(info);
    p.privacy.sanitizeTestErrors(info);
  }
  const diagnostics = p.reporter.safeFailureDiagnostics(info.annotations, true);
  return { diagnostics, annotationCount: info.annotations.length, markerAbsent: !JSON.stringify(info).includes(marker), errorsRetained: info.errors.length === sequence.length };
}
const core = values => values.filter(value => !value.cause.startsWith('REPORTED_'));
const tuple = values => JSON.stringify(core(values).map(value => [value.stage, value.cause, value.httpStatus]));
const rows = [];
for (const code of ['CORE_BEFORE_HINTS','HINTS_BEFORE_CORES','REPEATED_HINTS_BEFORE_LATE_CORE','INTERLEAVED_HINTS_CORES']) {
  const original = outcome(baseline, code), actual = outcome(selected, code);
  rows.push({ code, passed: core(original.diagnostics).length === 8 && tuple(actual.diagnostics) === tuple(original.diagnostics) && actual.diagnostics.length <= 8 && actual.annotationCount <= 8 && actual.markerAbsent && actual.errorsRetained, baselineCoreCount: core(original.diagnostics).length, selectedCoreCount: core(actual.diagnostics).length, totalCount: actual.diagnostics.length, annotationCount: actual.annotationCount, markerAbsent: actual.markerAbsent, errorsRetained: actual.errorsRetained });
}
const direct = p => p.reporter.safeFailureDiagnostics([annotation(p,'REPORTED_CLASS_TYPE_ERROR'), annotation(p,'REPORTED_FRAME_DATASET_CALL'), ...coreAnnotations(p)], true);
rows.push({ code: 'DIRECT_DECODER_CORE_PRIORITY', passed: tuple(direct(selected)) === tuple(direct(baseline)) && core(direct(selected)).length === 8 && direct(selected).length === 8, baselineCoreCount: core(direct(baseline)).length, selectedCoreCount: core(direct(selected)).length, totalCount: direct(selected).length });
const failed = rows.filter(row => !row.passed);
const causalCodes = ['HINTS_BEFORE_CORES','REPEATED_HINTS_BEFORE_LATE_CORE','INTERLEAVED_HINTS_CORES','DIRECT_DECODER_CORE_PRIORITY'];
const expectedCausalRed = process.argv[2] === 'old' && failed.length === 4 && failed.every(row => causalCodes.includes(row.code) && row.baselineCoreCount === 8 && row.selectedCoreCount === 6) && rows.find(row => row.code === 'CORE_BEFORE_HINTS')?.passed === true && parserDiagnosticCount === 0;
const receipt = { pass: failed.length === 0 && parserDiagnosticCount === 0, expectedCausalRed, count: rows.length, failed: failed.length, parserDiagnosticCount, controls: rows, reportedHintsUntrusted: true, originalCorePriorityRequired: true, nativeClientAcceptance: false, actualCIcause: 'UNKNOWN' };
fs.writeFileSync(process.env.RCT_SAFE_DIAGNOSTIC_RECEIPT, JSON.stringify(receipt, null, 2) + '\n', { mode: 0o600 });
process.exitCode = receipt.pass ? 0 : 1;
