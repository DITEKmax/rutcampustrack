// Synthetic native protocol checks. Publish booleans only; no users/passwords/data contents.
const admin = db.getSiblingDB('admin');
function authenticate(user, password) {
    const result = admin.auth(user, password);
    if (result !== 1 && result?.ok !== 1) throw new Error('Synthetic authentication failed');
}
authenticate(process.env.MONGO_ROOT_USER, process.env.MONGO_ROOT_PASSWORD);
const hello = admin.runCommand({hello: 1});
if (hello.setName !== 'rs0' || hello.isWritablePrimary !== true) throw new Error('Replica readiness failed');
for (const [name, database] of [[process.env.MONGO_USER, 'attendance_db'],
                              [process.env.MONGO_NOTIFICATION_USER, 'notification_db']]) {
    const user = admin.getUser(name);
    const roles = user.roles.map(x => x.db + ':' + x.role).sort();
    if (JSON.stringify(roles) !== JSON.stringify([database + ':dbAdmin', database + ':readWrite'].sort()))
        throw new Error('Accepted app roles differ');
}
admin.logout();
for (const [user, password, own, other] of [
    [process.env.MONGO_USER, process.env.MONGO_PASSWORD, 'attendance_db', 'notification_db'],
    [process.env.MONGO_NOTIFICATION_USER, process.env.MONGO_NOTIFICATION_PASSWORD, 'notification_db', 'attendance_db']]) {
    authenticate(user, password);
    if (db.getSiblingDB(own).runCommand({listCollections: 1, nameOnly: true}).ok !== 1)
        throw new Error('Own database read denied');
    let forbidden = false;
    try { db.getSiblingDB(other).runCommand({listCollections: 1, nameOnly: true}); }
    catch (error) { forbidden = error.code === 13; }
    if (!forbidden) throw new Error('Foreign app database unexpectedly permitted');
    admin.logout();
}
require('fs').writeFileSync(process.env.RCT_RESTART_READINESS_OUTPUT,
    JSON.stringify({status: 'PASS_SELECTED_NATIVE_PROTOCOL', rs0_primary: true, root_auth: true,
        accepted_app_roles_exact: true, both_app_auth: true, own_database_read: true,
        foreign_app_database_denied: true, credentials_or_data_values_published: false,
        current_client_acceptance: 'SEPARATE'}, null, 2) + '\n');
