import fs from 'node:fs'
import { spawnSync } from 'node:child_process'
import { createRequire } from 'node:module'
import { createHash } from 'node:crypto'
import { ESLint } from '/workspace/rutcampustrack/frontends/node_modules/eslint/lib/api.js'
import * as prettier from '/workspace/rct-worktrees/client-current-artifacts/frontends/node_modules/prettier/index.mjs'
const require=createRequire('/workspace/rutcampustrack/frontends/package.json')
const sfc=require('@vue/compiler-sfc'), dom=require('@vue/compiler-dom')
process.argv[2]='library'
const {vue,firstDelta}=await import('../prettier-final/verify-meaning.mjs')
const root='/workspace/rct-worktrees/ci-academic-heap'
const scratch='/workspace/scratch/rct-validation/authored_format_current/vue-eslint-correction'
const targets=JSON.parse(fs.readFileSync(`${scratch}/vue-targets.json`,'utf8'))
const eslint=new ESLint({cwd:`${root}/frontends`,fix:true,cache:false})
const hash=v=>createHash('sha256').update(typeof v==='string'?v:JSON.stringify(v)).digest('hex')
async function format(text,path) {
 const parsed=sfc.parse(text,{filename:path})
 if(parsed.errors.length)throw new Error('SFC_PARSE')
 const d=parsed.descriptor, options=await prettier.resolveConfig(path)
 const blocks=[d.script,d.scriptSetup,...d.styles].filter(b=>b?.content.trim())
 for(const block of blocks.sort((a,b)=>b.loc.start.offset-a.loc.start.offset)) {
  const parser=block.type==='style'?'css':block.lang==='ts'?'typescript':'babel'
  const content='\n'+await prettier.format(block.content,{...options,parser,filepath:path})
  text=text.slice(0,block.loc.start.offset)+content+text.slice(block.loc.end.offset)
 }
 const result=(await eslint.lintText(text,{filePath:path}))[0]
 return {text:result.output??text,errors:result.errorCount,warnings:result.warningCount}
}
function stringDeltas(a,b,path='',result=[]) {
 if(JSON.stringify(a)===JSON.stringify(b))return result
 if(a?.type==='StringLiteral'&&b?.type==='StringLiteral'&&a.value!==b.value) {
  result.push({path,original:a.value,candidate:b.value});return result
 }
 if(a&&b&&typeof a==='object'&&typeof b==='object')
  for(const key of new Set([...Object.keys(a),...Object.keys(b)]))stringDeltas(a[key],b[key],`${path}/${key}`,result)
 return result
}
function preserveText(text,pairs,path) {
 const descriptor=sfc.parse(text,{filename:path}).descriptor
 const template=descriptor.template
 if(!template)throw new Error('NO_TEMPLATE')
 const tree=dom.parse(template.content,{comments:false,whitespace:'condense'})
 const nodes=[]
 function visit(node) {if(node.type===2)nodes.push(node);for(const child of node.children??[])visit(child)}
 visit(tree)
 const edits=new Map()
 for(const pair of pairs) {
  const matches=nodes.filter(n=>n.content===pair.candidate)
  if(!matches.length)throw new Error(`TEXT_LOCATION ${path} ${JSON.stringify(pair)}`)
  for(const n of matches) {
   const start=template.loc.start.offset+n.loc.start.offset,end=template.loc.start.offset+n.loc.end.offset
   const value=`{{ ${JSON.stringify(pair.original)} }}`
   if(edits.has(start)&&edits.get(start).value!==value)throw new Error('AMBIGUOUS_TEXT')
   edits.set(start,{start,end,value,original:pair.original,candidate:pair.candidate})
  }
 }
 for(const edit of [...edits.values()].sort((a,b)=>b.start-a.start))text=text.slice(0,edit.start)+edit.value+text.slice(edit.end)
 return {text,edits:[...edits.values()]}
}
function foldConstantDisplay(value,bindings) {
 if(Array.isArray(value))return value.map(v=>foldConstantDisplay(v,bindings))
 if(!value||typeof value!=='object')return value
 if(value.type==='CallExpression'&&value.callee?.type==='Identifier'&&bindings.has(value.callee.name)&&value.arguments?.length===1&&value.arguments[0]?.type==='StringLiteral')return value.arguments[0]
 return Object.fromEntries(Object.entries(value).map(([k,v])=>[k,foldConstantDisplay(v,bindings)]))
}
function normalizeConstantDisplay(ast) {
 const bindings=new Set()
 for(const statement of ast.template?.render.program.body??[]) {
  if(statement.type==='ImportDeclaration'&&statement.source.value==='vue')
   for(const specifier of statement.specifiers)if(specifier.imported?.name==='toDisplayString')bindings.add(specifier.local.name)
 }
 const result=structuredClone(ast)
 if(result.template)result.template.render=foldConstantDisplay(result.template.render,bindings)
 const used=new Set()
 function visit(node) {
  if(!node||typeof node!=='object'||node.type==='ImportDeclaration')return
  if(node.type==='Identifier')used.add(node.name)
  for(const value of Object.values(node))if(Array.isArray(value))value.forEach(visit);else visit(value)
 }
 visit(result.template?.render)
 for(const statement of result.template?.render.program.body??[]) {
  if(statement.type!=='ImportDeclaration'||statement.source.value!=='vue')continue
  statement.specifiers=statement.specifiers.filter(s=>!bindings.has(s.local.name)||used.has(s.local.name))
  statement.specifiers.sort((a,b)=>a.imported.name.localeCompare(b.imported.name))
 }
 return result
}
const rows=[],preservations=[]
fs.mkdirSync(`${scratch}/block-candidate`,{recursive:true,mode:0o700})
for(const path of targets) {
 const absolute=`${root}/${path}`,current=fs.readFileSync(absolute,'utf8')
 const before=spawnSync('git',['show',`cd3f237acffd4f0b9dd2a74babb2ee822376f0cb:${path}`],{cwd:'/workspace/rutcampustrack',encoding:'utf8'}).stdout
 const original=await vue(before,path)
 let a=await format(current,absolute)
 const initial=await vue(a.text,path)
 const pairs=stringDeltas(original.template?.render,initial.template?.render)
 if(pairs.length) {
  const preserved=preserveText(a.text,pairs,path)
  preservations.push({path,edits:preserved.edits})
  a=await format(preserved.text,absolute)
 }
 const b=await format(a.text,absolute)
 const candidate=await vue(a.text,path)
 const delta=firstDelta(normalizeConstantDisplay(original),normalizeConstantDisplay(candidate))
 const file=`${scratch}/block-candidate/${path}`
 fs.mkdirSync(file.slice(0,file.lastIndexOf('/')),{recursive:true,mode:0o700});fs.writeFileSync(file,a.text,{mode:0o600})
 rows.push({path,changed:current!==a.text,lintErrors:a.errors,lintWarnings:a.warnings,fixedpoint:a.text===b.text,
   meaningEqual:delta===null,firstMeaningDelta:delta,originalMeaningHash:hash(normalizeConstantDisplay(original)),candidateMeaningHash:hash(normalizeConstantDisplay(candidate)),candidateSourceHash:hash(a.text)})
}
const result={targets:targets.length,changed:rows.filter(r=>r.changed).length,lintNotGreen:rows.filter(r=>r.lintErrors||r.lintWarnings).length,
 fixedpointFailures:rows.filter(r=>!r.fixedpoint).length,meaningFailures:rows.filter(r=>!r.meaningEqual).length,
 preservedFiles:preservations.length,preservedTextNodes:preservations.reduce((n,r)=>n+r.edits.length,0),preservations,rows,
 constantFoldingQualification:'Only generated render calls to the Vue import toDisplayString with exactly one StringLiteral argument. Generated Vue named helper imports sorted; only the display helper left unused by this constant folding removed. No dynamic/non-string calls, raw literals, operators, flags, modules, other helpers or render structure ignored.'}
fs.writeFileSync(`${scratch}/block-pipeline-probe.safe.json`,JSON.stringify(result,null,2)+'\n',{mode:0o600})
console.log(JSON.stringify({targets:result.targets,changed:result.changed,lintNotGreen:result.lintNotGreen,fixedpointFailures:result.fixedpointFailures,meaningFailures:result.meaningFailures,preservedFiles:result.preservedFiles,preservedTextNodes:result.preservedTextNodes}))
