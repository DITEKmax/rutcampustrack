"""Exact two public dependency pulls; reuse the unchanged reviewed b78 guard."""
import argparse
import datetime as dt
import hashlib
import json
import os
from pathlib import Path
import stat
import subprocess
import time
import types

OWN = Path(__file__).parent
REFS = ['alpine:3.17', 'testcontainers/ryuk:0.12.0']
GUARD = Path('/workspace/scratch/rct-validation/guard_proc_race_correction/bounded-child.py')
GUARD_SHA = 'b78c61293568d9941692e0b92ee34fd0b84db6d532b4a2c9a5ad42ccbf2204a0'
DOCKER = ['docker', '--host=unix:///var/run/docker.sock']
CAPS = {'phase_seconds': 90, 'total_seconds': 180, 'cleanup_seconds': 60,
        'disk_growth_bytes': 268435456, 'workspace_floor': 4294967296,
        'shared_stop': 16106127360, 'shared_reserve': 1073741824,
        'private_raw_log_bytes': 65536, 'own_cli_rss_bytes': 268435456}
ANCHORS = [('/', 0, 27, 1310721), ('/workspace', 1000, 27, 9223372036854775866),
           ('/workspace/scratch', 1000, 27, 9223372036856222969),
           ('/workspace/scratch/rct-validation', 1000, 27, 1835185)]

def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def safe_path(path, regular=False):
    path = Path(path)
    if not path.is_absolute() or '..' in path.parts:
        raise RuntimeError('EXACT_PATH_REQUIRED')
    for parent in list(reversed(path.parents)) + ([] if regular else [path]):
        value = parent.lstat()
        if not stat.S_ISDIR(value.st_mode) or value.st_uid not in (0, 1000):
            raise RuntimeError('OWN_NOFOLLOW_DIRECTORY_REQUIRED')
    if regular:
        value = path.lstat()
        if not stat.S_ISREG(value.st_mode) or value.st_uid != 1000 or value.st_nlink != 1 or stat.S_IMODE(value.st_mode) != 0o600:
            raise RuntimeError('OWN_PRIVATE_REGULAR600_REQUIRED')

def validate(grant, now):
    if grant.get('scope') != 'IT01_PUBLIC_DEPENDENCY_PULL' or grant.get('pull_authorized') is not True:
        raise RuntimeError('EXACT_PULL_GRANT_REQUIRED')
    if grant.get('refs') != REFS or grant.get('caps') != CAPS or grant.get('attempt') != 'attempt01':
        raise RuntimeError('EXACT_REFS_CAPS_ATTEMPT_REQUIRED')
    start, stop = (dt.datetime.fromisoformat(grant[key]) for key in ['not_before_utc', 'stop_utc'])
    if start.utcoffset() != dt.timedelta(0) or stop.utcoffset() != dt.timedelta(0) or not 0 < (stop-start).total_seconds() <= 240:
        raise RuntimeError('EXACT_UTC_WINDOW_REQUIRED')
    if now < start or now >= stop-dt.timedelta(seconds=60):
        raise RuntimeError('GRANT_USE_TIME_DENIED')
    return (stop-dt.timedelta(seconds=60)-now).total_seconds()

def main():
    parser = argparse.ArgumentParser(); parser.add_argument('--grant', required=True); args = parser.parse_args()
    if os.getuid() != 1000 or os.getgid() != 1000:
        raise RuntimeError('ACTOR1000_REQUIRED')
    for path, uid, dev, inode in ANCHORS:
        value = Path(path).lstat()
        if not stat.S_ISDIR(value.st_mode) or (value.st_uid, value.st_dev, value.st_ino) != (uid, dev, inode):
            raise RuntimeError('EXACT_NATIVE_CONTEXT_ANCHOR_REQUIRED')
    safe_path(OWN)
    private = OWN / 'private' / 'pull-grant.json'
    if str(Path(args.grant)) != str(private):
        raise RuntimeError('EXACT_PRIVATE_GRANT_PATH_REQUIRED')
    safe_path(private, regular=True)
    grant = json.loads(private.read_text())
    validate(grant, dt.datetime.now(dt.timezone.utc))
    if grant.get('source_sha256') != digest(__file__) or grant.get('guard_sha256') != GUARD_SHA or digest(GUARD) != GUARD_SHA:
        raise RuntimeError('EXACT_SELF_GUARD_REQUIRED')
    guard = types.ModuleType('existing_b78'); guard.__file__ = str(GUARD)
    exec(compile(GUARD.read_bytes(), str(GUARD), 'exec'), guard.__dict__)
    env = {'PATH': '/usr/local/bin:/usr/bin:/bin', 'HOME': str(Path.home()), 'LANG': 'C.UTF-8', 'LC_ALL': 'C.UTF-8'}
    # Preserve configured Docker credential selector in RAM, never open/dump its contents.
    if 'DOCKER_CONFIG' in os.environ:
        env['DOCKER_CONFIG'] = os.environ['DOCKER_CONFIG']
    out = OWN / 'attempt01'
    if out.exists() or out.is_symlink():
        raise RuntimeError('NEW_ATTEMPT_ONLY')
    initial_free = os.statvfs('/workspace').f_bavail * os.statvfs('/workspace').f_frsize
    started = time.monotonic(); latest = {}
    def observe():
        free = os.statvfs('/workspace').f_bavail * os.statvfs('/workspace').f_frsize
        used = int(Path('/sys/fs/cgroup/memory.current').read_text()); limit = int(Path('/sys/fs/cgroup/memory.max').read_text())
        if free < CAPS['workspace_floor']: return 'WORKSPACE_FLOOR'
        if initial_free-free > CAPS['disk_growth_bytes']: return 'SAMPLED_DISK_GROWTH'
        if used >= CAPS['shared_stop'] or limit-used < CAPS['shared_reserve']: return 'SHARED_MEMORY_STOP'
        table = guard.process_table()
        for row in latest.get('members_including_Z', []):
            if row['pid'] not in table or table[row['pid']]['start_ticks'] != row['start_ticks']: continue
            try: lines = Path('/proc', str(row['pid']), 'status').read_text().splitlines()
            except OSError as caught:
                if caught.errno in (2, 3): continue
                raise
            rss = next((int(line.split()[1])*1024 for line in lines if line.startswith('VmRSS:')), 0)
            if rss > CAPS['own_cli_rss_bytes']: return 'OWN_CLI_RSS_STOP'
        if time.monotonic()-started >= CAPS['total_seconds']: return 'TOTAL_PHASE_TIME_STOP'
        validate(grant, dt.datetime.now(dt.timezone.utc))  # UTC LAST after resource work.
        return None
    def gate():
        reason = observe()
        if reason: raise RuntimeError(reason)
    def save(name, value):
        payload = json.dumps(value, indent=2)+'\n'; gate()
        descriptor = os.open(out/name, os.O_WRONLY|os.O_CREAT|os.O_TRUNC|os.O_NOFOLLOW, 0o600)
        try: os.write(descriptor, payload.encode())
        finally: os.close(descriptor)
    gate(); out.mkdir(mode=0o700)
    save('launch.safe.json', {'utc': dt.datetime.now(dt.timezone.utc).isoformat(), 'supervisor': guard.process_table()[os.getpid()], 'refs': REFS, 'initial_workspace_free': initial_free, 'guard_sha256': GUARD_SHA, 'raw_log_bytes': 0})
    images = []
    for index, ref in enumerate(REFS):
        latest.clear()
        def status(value):
            latest.clear(); latest.update(value); save('phase'+str(index+1)+'-process.safe.json', value)
        gate(); remaining = validate(grant, dt.datetime.now(dt.timezone.utc))
        result = guard.run_owned(DOCKER+['pull', ref], str(OWN), env, deadline_seconds=min(90, remaining), observe=observe, status=status)
        # Terminal settlement must remain recordable after a stop gate; no new Docker effect.
        descriptor = os.open(out/('phase'+str(index+1)+'-terminal.safe.json'), os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW, 0o600)
        try: os.write(descriptor, (json.dumps(result, indent=2)+'\n').encode())
        finally: os.close(descriptor)
        if not result['settled'] or not result['phase_success']:
            print(json.dumps({'phase': index+1, 'native_exit': result['native_exit'], 'settled': result['settled'], 'reason': result['terminal_reason']})); return 1
        gate()
        selected = subprocess.run(DOCKER+['image', 'inspect', ref, '--format', '{{json .Id}} {{json .Size}} {{json .RepoDigests}}'], env=env, stdin=subprocess.DEVNULL, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, timeout=10, text=True)
        if selected.returncode: raise RuntimeError('SELECTED_IMAGE_METADATA_FAILED')
        ident, size, repos = selected.stdout.strip().split(' ', 2)
        images.append({'ref': ref, 'id': json.loads(ident), 'logical_size_bytes': json.loads(size), 'repo_digests': json.loads(repos)})
        save('images-progress.safe.json', images)
    report = {'utc': dt.datetime.now(dt.timezone.utc).isoformat(), 'images': images, 'elapsed_seconds': time.monotonic()-started, 'workspace_free_after': os.statvfs('/workspace').f_bavail*os.statvfs('/workspace').f_frsize, 'raw_log_bytes': 0, 'containers_networks_volumes_created': False, 'qualifier': 'Sampled workspace delta and CLI RSS; daemon allocation is not a hard per-pull cap. Tags resolved during actual pull; no image execution.'}
    save('result.safe.json', report); print(json.dumps({'images': len(images), 'settled': True, 'workspace_free_after': report['workspace_free_after']})); return 0

if __name__ == '__main__':
    try: raise SystemExit(main())
    except Exception as caught:
        print(json.dumps({'closed_exception_class': type(caught).__name__, 'raw_error_or_private_output': False})); raise SystemExit(1)
