# Current real-client acceptance harness — corrected source handoff

SOURCE_FROZEN_NOT_ACCEPTED. Current author commit `cf067a008d732ca77f385a3eb1f53e0a79234687` atop8fe/099/a847, exact basecd3. Sole NEW7 tests/harness only; current correction modifies OWN4 new paths. Foreign default config exact1b4/a4625 remains unstaged verification context, never authored or staged here. Sol6.1/xhigh selected; actual UNKNOWN. Angular/product/API/locks/existingfixtures unchanged.

CRA-EXPORT-T01/P2: old downloaded-body inclusion assertions could false-green despite ignored filters or missing ordinary fields. Current NEW pure in-memory oracle constrains one table, closed6/LIMITED or7/FULL headers, exactlyone target body row, every ordinary value and no known nonmatch. Target has STUDENT+TEACHER active grants/nonempty group/staff/bound Telegram; a known other user exists before export. Original real Vue→gateway→durable job→ticket→HTML/browser download/livegrant/foreign/revoke/TG/privacy behavior stays present. Audit fact is accepted product source; this finite client test does not independently claim audit storage PASS.

Native source-oracle controls20:2positive/18specific rejects (ignoredfilter,4ordinarycolumns,4ordinaryvalues eachmode); actual8fe sevenbodyassertions false-green on all18. Generated HTML and personaldata stay in memory; outputs booleans/counts only. One initial scratch probe extraction failure selected MIME expression; corrected AST identifier selection before oracle controls. Final probe rerun followed actual table-opening-count hardening, not an unmotivated repeat. These controlled test-oracle counterexamples are not real renderer/backend/client or product fault sensitivity PASS.

TMA prerequisite: Root/runtime owner must align stand-v4 Auth to the existing public CI synthetic signer; no real bot/private value inspected here. Eachfive date-negative now has same-target separate-page valid proof200/teacherowner/refresh positive first, then owncookie cleanup; negative requires401/current tma-validation-failed URI and current parser/age-specific safe detail. Native extracted problem predicates reject wrong-hash-guard/unrelated401; actual positive/negative browser/auth branches NOT_RUN. Reusable D003/unbind case preserved, no duplicate-proof policy invented or existinghelperchanged.

Actual final scoped TS5.9.3 native0/0diagnostics, pinnedPrettier3.6.2 sevenNEW check0; exact actual explicit --list28=14Chromium+14WebKit, allafterEach1. Previous actual default57/new0 remains qualified to byte-unchanged defaultconfig/default-loaded sources; NEW excluded paths not loaded. Own currentnamespace7 thirdparty same-lock links under realignorednode_modules; no sourcealiases/dependency/lock changes. Final checked byte hashes and native commands/logs: review-corrections-final.safe.json; current discovered opaque IDs→scenario IDs: current-type-discovery-final.safe.json; canonical inputs→scenario/oracle map: scenario-oracle-map.json.

CRA-VIEWPORT-T02/P2 corrected in NEWconfig: actual native list before1280x720 and after390x844 for bothselectedprojects, privacyflags/hook1 retained. No browserlayoutPASS. Independent narrow correction recheck pending. Shared real-server/browser/renderer/artifactprivacy/faults NOT_RUN; all11CLIENTparents UNKNOWN. Root runtime capacity and stand readiness handled independently. No host apps/API/HTTP/browser/JVM/Docker/network/children/push/main/integration/deploy actions here. Ownscratch under8MiB extra budget.

Original a847 and type/privacy8fe safe archives remain unchanged at their previous paths/manifests; current correction transfer archive is separate. The previous handoff below is preserved historical provenance, with earlier frozen SHA/check claims explicitly scoped to that phase.

---

# Current real-client acceptance harness — source handoff

SOURCE_PREPARED_NOT_ACCEPTED. Branch `codex/client-real-acceptance-20261012`, commit `8fe9fe946ded3174796778b33f84385c6f98473b`, exact frozen base `cd3f237acffd4f0b9dd2a74babb2ee822376f0cb`. Requested Sol6.1/xhigh; actual model metadata UNKNOWN. Sole sparse worktree `/workspace/rct-worktrees/client-real-acceptance`; receipt directory `/workspace/scratch/rct-validation/client_real_acceptance`.

The change adds 14 finite current-Vue/real-server browser scenarios. No application code, API, lock, existing fixture or Root task document was authored/changed. The ONE existing default config hunk is an exact foreign-author read-only source context from 1b4d, separately qualified. Full current TypeScript and list-only discovery native0; browser/backend runtime and fault sensitivity NOT_RUN, independent review PENDING. All eleven CLIENT groups remain UNKNOWN; this package does not close a family or claim DONE.

## Observable finite operations

- A synthetic account really has STUDENT/HEADMAN/TEACHER/FULL-ADMIN grants. Login defaults to STUDENT. An assistant command is denied before selecting HEADMAN and leaves no assistant grant; the same command succeeds after the actual role switch. A stale expected session version returns exactly409/SESSION_VERSION_CONFLICT. HEADMAN/ADMIN survive PWA reload.
- Four separate synthetic STUDENT helpers receive only VIEW_STATS, MANAGE_HOMEWORK, CANCEL_LESSONS or MANAGE_EXCUSES. They render their current Vue surface, perform their permitted read/edit/cancel/decision, and retain no marking capability. Revoked requests return403 with retained homework revision/title, CANCELLED lesson, or PENDING request/decision revision. Existing MARK_ATTENDANCE case is reused, not copied.
- A LIMITED admin edits an ordinary user through Vue with USERS_VIEW+USERS_MANAGE, has no credential controls/password text, and cannot issue a reset link. Removing management denies the old bearer and retains profile fields; reload recovers as a viewer.
- FULL and LIMITED USERS_VIEW admins select HTML in the actual export component. Real durable job202, ready ticket200, MIME/content/filename and actual browser download are observed. One filtered synthetic row, FULL-only TelegramID and zero passwords/reset links are checked in memory. Foreign job/file requests and LIMITED later status/ticket/file/capability fetch after grant removal return403. Only HTML bytes are covered; the five-format catalogue is checked without pretending other four formats were executed.
- Five correctly signed negative TMA proofs isolate absent/non-numeric/overflow/future/expired auth_date. Actual TMA401, rendered failure, absent role/navigation/cookie and empty browser-context refresh401 are required. A fresh linked teacher first opens the real Vue owner, then real Academic PUT clears binding; reusing the signed proof returns401 with no new owner/cookie. Existing signed reuse/tampered cases are reused. Exact86400 age boundary, duplicate parameter policy and native provider remain separate.

`scenario-oracle-map.json` contains exact IDs, source references/hashes, data preparation and oracle for every named finite case. It uses scenarios.csv, boundary-scenarios.csv and dated decisions; historical flattened source_paths were not used as paths.

## Source coverage and remaining work

`assessment.json` records the eight existing real-mobile cases against eleven groups. Existing source intent covers own completion/reload/foreign denial; journal/PNG and teacher read/write denial; MARK_ATTENDANCE/revoke; LIMITED viewer/create denial; empty/retry; two-session revoke; D003 reuse/suspended neutral bootstrap; D002 warm service-worker homework/read-only/reconnect/A→B/logout.

Significant remaining slices include password/change/reset/OTP/history/terminal roles and token expiry; successful geo/manual/automatic student request UI and teaching-clock boundaries; homework publication/next lesson/transfer/archive/order/links; schedule construction/subject lifecycle/roster and full helper exports; teacher full journal/stats/export scopes; other FULL/LIMITED grant families, maps/semesters/credentials; map version/SVG safety, four other registry formats/distinct report models; inbox/preferences/actions and open WS revocation; offline schedule/date rollover/no new attachment/no role switch/TMA offline/late callbacks; install/update/push and available native provider. The new request setup is HTTP preparation, not student browser acceptance. No native device gate is invented.

## Integration dependency and future command

Root must coordinate one existing config hunk before integration: in `tests/e2e/playwright.config.ts`, extend
`testIgnore: /mobile-real-server\.spec\.ts/` to
`testIgnore: /mobile-real-server\.spec\.ts|cloud-accepted-.*\.spec\.ts/`.
The new package is explicitly opt-in. That existing file remains owned by ci_academic_heap. Root granted exact read-only source import for this phase; source commit1b4d8bdafe59e227bfc26cd8fd6eeed98e10f099, SHA256a4625d4a5c8f5ff8deac9381d26e3feaadb77e750eea7ab7208fbc419222b8e0. Without it, ordinary default discovery can pick up these source-only cases; the canonical privacy guard refuses the unsafe default reporter before generating credentials.

After independent review, correct current-namespace E2E dependencies, current relevant producer hashes, shared healthy genuine production Vue/server/DB/queue/native renderer/edge configuration, exact synthetic seed/clock/TLS review and Root runtime grant:

```sh
cd /workspace/rutcampustrack/tests/e2e
RCT_E2E_SYNTHETIC_SEED=true E2E_BASE_URL=https://localhost:8443 node node_modules/playwright/cli.js test --config fixtures/cloud-accepted-playwright.ts --project=chromium
```

The new config has one worker, no retries/parallel dataset writers, 390×844 viewport, canonical safe reporter, traces/video/screenshots off. It inherits the exact HTTPS loopback:8443 + opt-in guard and RNG synthetic credentials from current MobileDataset. WebKit is a separate actual capability admission. Existing browser metadata lists Chromium1217/WebKit2272 cache entries, browser_launch=false and prior WebKit library warnings; it is not a launch/dependency PASS. No downloads, installs, app/browser/JVM/Docker/key/network actions were performed here.

## Verification and quality

Current-source TypeScript5.9.3 createSourceFile/transpileModule:7 files,0 diagnostics. Source policy inspection:0 page.route API mocks, skip/fail/fixme/only declarations, attachments, logging or waitForTimeout; all relative current-source imports resolve. The subsequent Root-granted current namespace full typecheck passed native0. Seven exact same-lock third-party package symlinks live under an OWN real ignored tests/e2e/node_modules directory; no whole-directory link, historical source/fixture/@rct aliases, dependency install or lock change. See current-dependency-validation.json and actual-type-resolution.safe.json.

Pinned Prettier3.6.2 cache was used as a read-only tool only, with formatter-owner current config; check native0. Staged diff whitespace check native0. See `source-verification.json`, `verification-receipt.json`, `format-check-final.log`. Rechecks followed concrete source corrections; there was no browser run/retry. Common Git hooks contain samples only; no mandatory gate was changed or disabled.

`counterexamples.json` records author corrections: negative TMA refresh moved off seeded API cookie; stale-version request ordered before reload; roster restriction limited to accepted export rule; cancellation isolates lesson8 so later mark oracles remain meaningful. Failures report only sanitized metadata through the inherited policy. Credentials, bearer values, signed proof, Telegram identity and download capability/body stay in memory; no body/secret assertion value is exported. The public CI signing placeholder is the existing synthetic adapter contract.

## Controlled sensitivity plan — no mutations executed

Under a future separate Root resource/fault grant, use an isolated exact-source fault worktree and NEW synthetic data, one narrow fault at a time, with recorded red→restored green and relevant producer hashes:

1. `ActiveRolePolicy.evaluate`: temporarily select ADMIN in the default branch instead of STUDENT. CRA-ROLE-01 must fail its default and wrong-selected-role oracle; restore and rerun only that case with the positive HEADMAN command.
2. `TmaService.authenticateWithInitData`: bypass only the future/max-age condition. CRA-TMA-FUTURE/EXPIRED must fail at200/exposed owner; restore, rerun them plus existing valid D003 control. Malformed parser controls must still deny.
3. `HomeworkService` assistant admission: temporarily ignore revoked MANAGE_HOMEWORK for the synthetic group. CRA-HELPER-HW must fail403/no-effect and expose changed durable revision/title; restore and rerun that case.
4. `LessonService` CANCEL_LESSONS admission: temporarily ignore revoked permission for the synthetic lesson. CRA-HELPER-CANCEL must fail denied restore/retained cancellation; restore and recheck it.
5. `StudentRequestService` MANAGE_EXCUSES admission: temporarily ignore revocation for the synthetic pending request. CRA-HELPER-EXCUSE must fail403/unchanged decision revision; restore and recheck it.
6. `AdminAccessProfile`/live permission lookup: narrowly allow USERS_MANAGE or credentials after removed/absent grant. CRA-ADMIN-GRANT must fail exact403/retained profile or credential state; restore and recheck it.
7. `AdminRegistryExportService.users`: temporarily include the Telegram column for LIMITED. CRA-EXPORT-LIMITED must fail the in-memory field oracle. Separately bypass only `RegistryExportAdmission.requireCurrent` USERS_VIEW check to exercise retained capability denial. Restore and rerun LIMITED plus FULL field positive control.

These are plans, not product defects or executed sensitivity PASS. Privacy controls themselves remain the existing dedicated browser-free suite; do not run credential-bearing browser tests with an ordinary reporter.

## Inventory and resources

Created, tests/harness only:

- `/workspace/rct-worktrees/client-real-acceptance/tests/e2e/fixtures/cloud-accepted-playwright.ts`
- `/workspace/rct-worktrees/client-real-acceptance/tests/e2e/fixtures/cloud-accepted-support.ts`
- `/workspace/rct-worktrees/client-real-acceptance/tests/e2e/specs/cloud-accepted-admin-grants.spec.ts`
- `/workspace/rct-worktrees/client-real-acceptance/tests/e2e/specs/cloud-accepted-helper-capabilities.spec.ts`
- `/workspace/rct-worktrees/client-real-acceptance/tests/e2e/specs/cloud-accepted-registry-export.spec.ts`
- `/workspace/rct-worktrees/client-real-acceptance/tests/e2e/specs/cloud-accepted-role-authority.spec.ts`
- `/workspace/rct-worktrees/client-real-acceptance/tests/e2e/specs/cloud-accepted-tma-proof.spec.ts`

Modified existing authored by me: none. Foreign verification context only: tests/e2e/playwright.config.ts exact1b4d. Deleted: none. Product: none. Root CSV/docs/config/locks/API untouched. Receipt/inventory/source hashes are in this own scratch directory and the safe transfer archive; Root owns persistence into task docs/PR. Sparse WT7.8MiB, receipt package bounded below64MiB. No processes, containers or child agents retained. No push/main integration/deploy.

## Current namespace type/discovery phase — exact source freeze

099585ffe3e19b04b890c96d30438961ab39f8c4 adds only the test-only type correction on top of original a8477-file package. Original source archive/receipts remain preserved; this new phase has a separate archive. The actual checked context is this authored commit plus exact foreign default config1b4d, not an unqualified whole-repository SHA.

Full TypeScript5.9.3/native0, diagnostics0, inherited E2E NodeNext/options unchanged. Attempt1 native2/TS2835 came only from the NEW type-only import dragging existing Vue Bundler imports into NodeNext. The corrected NEW local closed union exactly equals the current canonical five wire codes; existing assistantPermissionCodes is a function returning open string[], so it cannot supply an asconst union. Old/new emitted helper JavaScript (ES2022/CommonJS/removeComments) is byte-identical. No accepted permission or API rule changed. Actual compiler paths:14 own current source,111 third-party type/cache and63 compiler-lib files; no historical source/fixture aliases.

Actual --list/native0: explicit NEW lane28 registrations=14 Chromium+14 WebKit. Default list/native0:57 registrations, NEW0 and existing real-mobile opt-in0. The first default list native1/8 load errors was missing @axe-core/playwright required by actual old default spec imports. Verified same-lock @axe4.11.2/axe-core4.11.3 links fixed only that dependency namespace; the targeted default recheck passed. These old default Angular-targeting test sources were diagnostic reads, with zero Angular mutations and no execution.

Only scratch metadata reporter ran during discovery; it emits file/line/project/opaque IDs/counts and error locations/counts, never titles/body/errors. Canonical credential-bearing runtime reporter and trace policy remain unchanged. PWTEST_CACHE_DIR is own scratch (under1MiB), excluded from transfer. No dataset fixture, HTTP/API, application or browser was executed. onTestBegin would reject execution. Native discovery status 'passed' means source registration only.

current-type-discovery-final.safe.json maps every actual discovered opaque ID/location to the accepted finite case ID. Full TS and discovery were run on the byte-identical working sources immediately before the metadata-only source commit freeze. Independent review and controlled relevant faults remain pending. A bookkeeping script's Git subprocess was denied EPERM; Git source read was moved to a separate ordinary tool command and the Node-only seal then passed, without escalation or additional runtime.

## PRIV-HOOK01 correction — final source freeze

Final authored source8fe9fe94 follows099 type correction and originala847 NEW7. A native list-only source registration check found the shared module-level sanitizer hook only on the first spec: admin1/helper0/export0/role0/TMA0. This was an actual harness registration defect; no raw credential or browser artifact was created or examined.

NEW registerPrivateSuite() now registers the same existing off-artifact/default/afterEach sanitizer policy once from each NEW spec. Current native --list28 registrations now have exactly one afterEach in every suite chain, across all five files/two projects. Full current TS/native0 and format/native0 passed after this six-file correction. The 14 scenario semantics/accepted permission set/API/config/old fixtures remain unchanged. This actual before→after registration evidence is source validation, not actual browser artifact privacy PASS. Browser artifact control and critical authorization fault sensitivity remain pending under future Root runtime grants.

Original a847 archive remains intact;099 type-only emitted JavaScript equivalence is qualified strictly to the type-only step, not to the later intentional privacy-hook correction. Actual checked final context is final authored8fe + exactforeign1b4 default config. Default57/NEW0 evidence remains qualified to unchanged config/unchanged default-loaded source inputs; NEWopt-in files are excluded and not loaded by that suite. Only final explicit source discovery was repeated after privacy changes. Current-type-discovery-final.safe.json maps current actual locations/IDs and records the privacy correction separately.
