"""HOSTCFG-G01: replace only four NEW synthetic directional values; no app runs."""
import ast
import base64
import datetime
import hashlib
import json
import os
from pathlib import Path
import re
import secrets
import stat

OWN = Path(__file__).parent
ORIGINAL = OWN.parent / 'current_host_config'
PRODUCT = Path('/workspace/rutcampustrack')
NAMES = ['ACADEMIC_TO_SCHEDULE_SERVICE_TOKEN', 'SCHEDULE_TO_ACADEMIC_SERVICE_TOKEN',
         'BOT_TO_ACADEMIC_SERVICE_TOKEN', 'BOT_TO_NOTIFICATION_SERVICE_TOKEN']
os.umask(0o077)

def save(name, data):
    (OWN / name).write_text(json.dumps(data, indent=2) + '\n')

def generate_directional_token():
    return base64.urlsafe_b64encode(secrets.token_bytes(32)).decode('ascii').rstrip('=')

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def selected_canonical(path):
    source = path.read_text()
    tree = ast.parse(source)
    node = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == 'canonical_token')
    selected = ast.Module(body=[node], type_ignores=[])
    namespace = {'base64': base64, 're': re}
    exec(compile(selected, str(path), 'exec'), namespace)
    return namespace['canonical_token'], {'path': str(path), 'source_sha256': sha(path),
        'selected_function_source_sha256': hashlib.sha256(ast.get_source_segment(source, node).encode()).hexdigest()}

canon_grpc, grpc_source = selected_canonical(PRODUCT / 'services/notification-bot/bot/grpc_client/bot_service_credentials.py')
canon_prefs, prefs_source = selected_canonical(PRODUCT / 'services/notification-bot/bot/services/notification_prefs.py')
java_path = PRODUCT / 'services/shared/shared-security/src/main/java/ru/rutcampustrack/shared/security/grpc/DirectedServiceCredential.java'
java = java_path.read_text()
chars = int(re.search(r'TOKEN_CHARACTERS = (\d+);', java).group(1))
byte_count = int(re.search(r'TOKEN_BYTES = (\d+);', java).group(1))
pattern = re.search(r'encodedToken.matches\("([^"]+)"\)', java).group(1)
for exact in ['encodedToken == null', 'encodedToken.length() != TOKEN_CHARACTERS',
              'Base64.getUrlDecoder().decode(encodedToken)', 'decoded.length != TOKEN_BYTES',
              'Base64.getUrlEncoder().withoutPadding().encodeToString(decoded)',
              'canonical.equals(encodedToken) ? decoded : null']:
    assert exact in java
# Source-derived Java boundary counterpart; JVM execution is explicitly NOT_RUN.
def java_source_boundary(value):
    if value is None or len(value) != chars or not re.fullmatch(pattern, value):
        return False
    try:
        decoded = base64.urlsafe_b64decode(value + '=')
        return len(decoded) == byte_count and base64.urlsafe_b64encode(decoded).decode().rstrip('=') == value
    except (ValueError, TypeError):
        return False

manifest_path = ORIGINAL / 'launch-manifest.json'
assert sha(manifest_path) == 'abc478d49ee558d8c42fed6368bb003e35b42b3031a820617dec7fed0709ba12'
manifest = json.loads(manifest_path.read_text())
for row in manifest['files']:
    assert sha(Path(row['path'])) == row['sha256']
old_private = {}
private_metadata = {}
for path in (ORIGINAL / 'private').iterdir():
    st = path.lstat()
    assert stat.S_ISREG(st.st_mode) and st.st_uid == os.getuid() and stat.S_IMODE(st.st_mode) == 0o600
    old_private[path.name] = path.read_bytes()  # Authorized existing OWN synthetic ENV only.
    private_metadata[path.name] = (st.st_ino, st.st_size, st.st_mode, st.st_uid, st.st_gid, st.st_mtime_ns, st.st_ctime_ns)
keys = [*ORIGINAL.glob('tls/**/*.key'), ORIGINAL / 'jwt-auth/private.key', ORIGINAL / 'jwt-auth/kid.txt']
key_metadata = {str(path): tuple(getattr(path.lstat(), attr) for attr in ['st_ino', 'st_size', 'st_mode', 'st_uid', 'st_gid', 'st_mtime_ns', 'st_ctime_ns']) for path in keys}
old_env = {name: json.loads(body) for name, body in old_private.items() if name.endswith('.json')}
old_tokens = {}
for name in NAMES:
    values = [data[name] for data in old_env.values() if name in data]
    assert values and len(set(values)) == 1
    old_tokens[name] = values[0]
    assert not canon_grpc(values[0]) and not canon_prefs(values[0]) and not java_source_boundary(values[0])
new_tokens = {name: generate_directional_token() for name in NAMES}
assert len(set(new_tokens.values())) == 4
(OWN / 'private').mkdir(mode=0o700)
(OWN / 'runtime').mkdir(mode=0o700)
changes = []
for name, body in old_private.items():
    if name.endswith('.json'):
        previous = old_env[name]; current = dict(previous)
        changed = [key for key in NAMES if key in current]
        for key in changed:
            current[key] = new_tokens[key]
        assert set(current) == set(previous)
        assert [key for key in previous if current[key] != previous[key]] == [key for key in previous if key in NAMES]
        if changed:
            content = (json.dumps(current, indent=2) + '\n').encode()
        else:
            content = body
    else:
        changed = []; content = body
    target = OWN / 'private' / name
    with target.open('xb') as stream:
        stream.write(content)
    assert stat.S_IMODE(target.stat().st_mode) == 0o600
    changes.append({'original_path': str(ORIGINAL / 'private' / name), 'new_path': str(target),
                    'changed_value_names_only': changed, 'other_values_and_names_equal': True,
                    'unchanged_file_byte_equal': not changed, 'new_mode': '600', 'uid': target.stat().st_uid})
# Exact new private pointers: all other specification fields are identical.
previous_specs = json.loads((ORIGINAL / 'host-service-specs.json').read_text())
specs = json.loads((ORIGINAL / 'host-service-specs.json').read_text())
for old, new in zip(previous_specs, specs):
    new['private_environment_file'] = str(OWN / 'private' / Path(old['private_environment_file']).name)
    restored = dict(new); restored['private_environment_file'] = old['private_environment_file']
    assert restored == old
save('host-service-specs.json', specs)
for name in ['tool-provenance.json', 'data-renderer-edge.compose.yml', 'launch-grant.template.json']:
    with (OWN / name).open('xb') as stream:
        stream.write((ORIGINAL / name).read_bytes())
runner = (ORIGINAL / 'run-service-v2.py').read_text()
assert "'run-service-v2.py'" in runner
new_runner = runner.replace("'run-service-v2.py'", "'run-service-v3.py'")
(OWN / 'run-service-v3.py').write_text(new_runner)
ast.parse(new_runner)
assert new_runner.replace("'run-service-v3.py'", "'run-service-v2.py'") == runner
commands = json.loads((ORIGINAL / 'launch-commands-v2.json').read_text())
for service in commands['host7_each_in_separate_bounded_foreground_exec_session']:
    service['argv'][1] = str(OWN / 'run-service-v3.py')
    service['argv'][-1] = str(OWN / 'private/launch-grant.json')
for key in ['Docker9_start_only_after_review_and_actual_resource_lease', 'Docker9_cleanup_only_exact_owned_project_after_label_ID_recheck']:
    argv = commands[key]
    argv[argv.index('--env-file') + 1] = str(OWN / 'private/docker.env')
    argv[argv.index('-f') + 1] = str(OWN / 'data-renderer-edge.compose.yml')
commands['launch_manifest'] = str(OWN / 'launch-manifest.json')
commands['supersedes'] = 'HOSTCFG-G01 original39 directional representation only; original39 remains immutable'
save('launch-commands-v3.json', commands)
# Meaningful public counterexamples: padding, alphabet, encoded/decoded length, alias bits, roundtrip.
public_good = base64.urlsafe_b64encode(bytes(range(32))).decode().rstrip('=')
alias = 'A' * 42 + 'B'
assert base64.urlsafe_b64decode(alias + '=') == base64.urlsafe_b64decode('A' * 43 + '=')
cases = [('valid32', public_good, True), ('valid32allzero', 'A' * 43, True),
         ('empty', '', False), ('hex64', '0' * 64, False), ('padding', public_good + '=', False),
         ('short42', public_good[:-1], False), ('long44', public_good + 'A', False),
         ('decoded31', base64.urlsafe_b64encode(bytes(31)).decode().rstrip('='), False),
         ('decoded33', base64.urlsafe_b64encode(bytes(33)).decode().rstrip('='), False),
         ('wrongAlphabet', '+' + public_good[1:], False), ('slashAlphabet', '/' + public_good[1:], False),
         ('space', ' ' + public_good[1:], False), ('nonASCII', 'я' + public_good[1:], False),
         ('noncanonicalAliasSameDecoded32', alias, False)]
controls = []
for label, value, expected in cases:
    results = [canon_grpc(value), canon_prefs(value), java_source_boundary(value)]
    assert results == [expected] * 3
    controls.append({'case': label, 'expected': expected, 'actual_selected_grpc': results[0], 'actual_selected_prefs': results[1], 'Java_source_counterpart': results[2]})
pairs = []
new_env = {name: json.loads((OWN / 'private' / name).read_text()) for name in old_env}
for name in NAMES:
    values = [data[name] for data in new_env.values() if name in data]
    assert len(set(values)) == 1 and values[0] == new_tokens[name]
    assert all(fn(values[0]) for fn in [canon_grpc, canon_prefs, java_source_boundary])
    assert len(base64.urlsafe_b64decode(values[0] + '=')) == 32
    pairs.append({'name': name, 'old_actual_all_three_rejected': True, 'new_actual_all_three_accepted': True,
                  'encoded_chars': 43, 'decoded_bytes': 32, 'sender_receiver_and_reserved_bot_equal': True})
for name, body in old_private.items():
    path = ORIGINAL / 'private' / name; st = path.lstat()
    assert path.read_bytes() == body
    assert (st.st_ino, st.st_size, st.st_mode, st.st_uid, st.st_gid, st.st_mtime_ns, st.st_ctime_ns) == private_metadata[name]
for path, metadata in key_metadata.items():
    assert tuple(getattr(Path(path).lstat(), attr) for attr in ['st_ino', 'st_size', 'st_mode', 'st_uid', 'st_gid', 'st_mtime_ns', 'st_ctime_ns']) == metadata
for row in manifest['files']:
    assert sha(Path(row['path'])) == row['sha256']
save('directional-validation.safe.json', {'utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'status': 'PASS_SOURCE_AND_SYNTHETIC_INPUT_CORRECTION_ONLY',
    'finding': 'HOSTCFG-G01', 'source_functions': [grpc_source, prefs_source], 'Java_source': {'path': str(java_path), 'sha256': sha(java_path), 'execution': 'SOURCE_COUNTERPART_ONLY_NO_JVM'},
    'old_actual_red_new_actual_green': pairs, 'four_values_distinct': True, 'controls': controls,
    'canonical_generator': 'urlsafe_b64encode(secrets.token_bytes(32)).decode(ascii).rstrip(=)',
    'private_changes': changes, 'original39_safe_and_private_inputs_unchanged': True,
    'original_RSA_TLS_VAPID_keys_reused_metadata_unchanged_no_reads_regeneration': True,
    'seven_specs_only_private_path_changed': True, 'runner_v2_byte_roundtrip_only_self_filename': True,
    'private_values_or_hashes_disclosed': False, 'apps_JVM_Docker_network': 'NOT_RUN'})
print('HOSTCFG-G01 corrected: four canonical32 token pairs; actual old red/new green; 14 controls x3 pass; original39 and private inputs preserved; no values/digests')
