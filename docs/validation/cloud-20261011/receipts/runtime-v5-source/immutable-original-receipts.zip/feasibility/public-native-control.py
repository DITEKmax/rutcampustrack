"""Public --version/ELF dependency controls only, no database/server/network."""
import datetime,hashlib,json,os,re,subprocess
from pathlib import Path
OUT=Path(__file__).parent;NATIVE=Path('/tmp/rct-native-mongo-20261012');os.umask(0o077)
home=NATIVE/'version-home';home.mkdir(mode=0o700)
env={'PATH':'/usr/bin:/bin','LANG':'C.UTF-8','LC_ALL':'C.UTF-8','HOME':str(home),'XDG_CONFIG_HOME':str(home),'MONGOSH_FORCE_DISABLE_TELEMETRY':'true'}
results=[]
for name in ['mongod','mongosh']:
 binary=NATIVE/name
 header=subprocess.run(['/usr/bin/readelf','-h',str(binary)],env=env,stdin=subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=15)
 dynamic=subprocess.run(['/usr/bin/readelf','-d',str(binary)],env=env,stdin=subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=15)
 listing=subprocess.run(['/lib64/ld-linux-x86-64.so.2','--list',str(binary)],env=env,stdin=subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=15)
 verified=subprocess.run(['/lib64/ld-linux-x86-64.so.2','--verify',str(binary)],env=env,stdin=subprocess.DEVNULL,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,timeout=15)
 argv=[str(binary),'--version'] if name=='mongod' else [str(binary),'--norc','--version']
 version=subprocess.run(argv,env=env,stdin=subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=20)
 paths=sorted(set(re.findall(r'(/[^\s()]+)',listing.stdout.decode())))
 dependencies=[]
 for path in paths:
  item=Path(path)
  if item.is_file():
   dependencies.append({'effective_public_library':str(item.resolve()),'public_sha256':hashlib.sha256(item.read_bytes()).hexdigest(),'bytes':item.stat().st_size})
 result={'name':name,'binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'version_argv':argv,'native_version_exit':version.returncode,
 'public_version_output':version.stdout.decode()[:8192] if version.returncode==0 else None,
 'public_ELF_dependency_error':listing.stderr.decode()[:4096] if listing.returncode else None,
 'readelf_exit':header.returncode,'dynamic_exit':dynamic.returncode,'loader_verify_exit':verified.returncode,'loader_list_exit':listing.returncode,
 'ELF_machine':[line.strip() for line in header.stdout.decode().splitlines() if 'Machine:' in line or 'Class:' in line],
 'ELF_needed':re.findall(r'Shared library: \[([^]]+)\]',dynamic.stdout.decode()),'effective_host_dependencies':dependencies,
 'host_libs_versus_original_image_libs':'EXPLICIT_HOST_ABI_QUALIFICATION; no claim original-container DSO byte identity',
 'server_listen_auth_replica_transactions':'NOT_RUN'}
 results.append(result)
(OUT/'native-version-ELF.safe.json').write_text(json.dumps({'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'results':results,'no_server_or_provider_call':True,'no_inherited_ENV':True},indent=2)+'\n')
assert all(r['native_version_exit']==0 and r['loader_verify_exit']==0 and r['loader_list_exit']==0 for r in results)
print(json.dumps({'native_version_ELF':'PASS','versions':[{'name':r['name'],'public_version':r['public_version_output']} for r in results],'database_server':'NOT_RUN'}))
