import datetime
import io
import json
from pathlib import Path
import tarfile
import types
import gzip
from unittest.mock import patch
import stat
import os
P=Path(__file__).parent
header=types.ModuleType('headers');exec(compile((P/'public-headers.py').read_bytes(),'headers','exec'),header.__dict__)
driver=types.ModuleType('driver');driver.__file__=str(P/'download-headers.py');exec(compile((P/'download-headers.py').read_bytes(),'driver','exec'),driver.__dict__)
checks=[]
def check(name,fn,accept):
 try:fn();actual=True
 except (ValueError,RuntimeError,OSError,KeyError):actual=False
 assert actual==accept,(name,actual)
 checks.append({'name':name,'expected_accept':accept,'pass':True})
def tar(entries):
 output=io.BytesIO()
 with tarfile.open(fileobj=output,mode='w') as t:
  for name,kind,mode,target in entries:
   info=tarfile.TarInfo(name);info.mode=mode;info.uid=0;info.gid=0
   if kind=='dir':info.type=tarfile.DIRTYPE
   elif kind=='sym':info.type=tarfile.SYMTYPE;info.linkname=target
   elif kind=='hard':info.type=tarfile.LNKTYPE;info.linkname=target
   elif kind=='fifo':info.type=tarfile.FIFOTYPE
   else:info.size=1
   t.addfile(info,io.BytesIO(b'x') if kind=='file' else None)
 return output.getvalue()
def inspect(entries):return header.inspect_tar(tar(entries),'data')
check('canonical library and internal symlink777 accepted as header metadata',lambda:inspect([('./usr/lib/libx.so.1','file',0o644,None),('./usr/lib/libx.so','sym',0o777,'libx.so.1')]),True)
check('absolute documentation target classified header-only, never followed',lambda:inspect([('./usr/share/doc/x/license','sym',0o777,'/usr/share/doc/y/license')]),True)
for name in ['/usr/lib/x','usr/lib/../../home/private','./usr//lib/x','C:/x','usr\\lib\\x','root/.ssh/key','usr/lib/./x']:
 check('reject unsafe member '+name,lambda name=name:inspect([(name,'file',0o644,None)]),False)
for kind,mode,target in [('file',0o4755,None),('file',0o2664,None),('dir',0o777,None),('fifo',0o600,None),('sym',0o777,'/tmp/foreign'),('sym',0o777,'../../../foreign'),('hard',0o644,'../../foreign')]:
 check('reject runtime type/mode/link '+str((kind,mode,target)),lambda:inspect([('usr/lib/x',kind,mode,target)]),False)
check('duplicate canonical header path rejected',lambda:inspect([('./usr/lib/x','file',0o644,None),('usr/lib/x','file',0o644,None)]),False)
check('link ancestor rejected regardless ordering',lambda:inspect([('usr/lib/x/y','file',0o644,None),('usr/lib/x','sym',0o777,'z')]),False)
# Debian ar exact synthetic framing and compressed public metadata. No payload files extracted.
def ar(rows):
 blob=b'!<arch>\n'
 for name,data in rows:
  h=(name+'/').ljust(16)+'0'.ljust(12)+'0'.ljust(6)+'0'.ljust(6)+'100644'.ljust(8)+str(len(data)).ljust(10)+'`\n'
  blob+=h.encode()+data+(b'\n' if len(data)%2 else b'')
 return blob
control=tar([('control','file',0o644,None),('postinst','file',0o755,None)])
data=tar([('usr/lib/x','file',0o644,None)])
good=ar([('debian-binary',b'2.0\n'),('control.tar.gz',gzip.compress(control)),('data.tar.gz',gzip.compress(data))])
result=header.inspect_deb(good);assert result['extract_or_execute'] is False
assert all(r['execution']=='NEVER_EXECUTE_CONTROL_SCRIPTS_HOOKS_TRIGGERS' for r in result['control']['rows'])
checks.append({'name':'actual inspect_deb gzip/control script names only; never extract/execute','pass':True})
check('ar duplicate member rejected',lambda:header.ar_members(ar([('debian-binary',b'2.0\n'),('debian-binary',b'2.0\n')])),False)
check('gzip output cap rejects compressed amplification',lambda:header.tar_bytes('data.tar.gz',gzip.compress(b'x'*4096),cap=100),False)
check('unsupported compression fails closed',lambda:header.tar_bytes('data.tar.zst',b'public'),False)
now=datetime.datetime(2026,10,12,16,0,tzinfo=datetime.timezone.utc)
grant={'payload_download_headers_authorized':True,'library_extraction_authorized':False,'browser_launch_authorized':False,'signed_plan_manifest_sha256':driver.PLAN_SHA,'source_review_manifest_sha256':driver.REVIEW_SHA,'reviewed_guard_sha256':driver.GUARD_SHA,'exact_archive_bytes':6284816,'payload_namespace_allocated_cap':driver.PAYLOAD_CAP,'driver_rss_stop_bytes':driver.RSS_CAP,'payload_namespace':'/tmp/rct-webkit-payloads-20261012-attempt01','not_before_utc':now.isoformat(),'stop_utc':(now+datetime.timedelta(seconds=600)).isoformat()}
check('exact new finite headers-only grant accepted',lambda:driver.validate_grant(grant,now),True)
for key,value in [('payload_download_headers_authorized',False),('library_extraction_authorized',True),('browser_launch_authorized',True),('signed_plan_manifest_sha256','changed'),('source_review_manifest_sha256','changed'),('reviewed_guard_sha256','changed'),('exact_archive_bytes',1),('payload_namespace_allocated_cap',99999999),('driver_rss_stop_bytes',999999999),('payload_namespace','/tmp/foreign'),('payload_namespace','/tmp/rct-webkit-payloads-20261012-a/../b')]:
 bad=dict(grant);bad[key]=value
 check('false grant denies '+key,lambda:driver.validate_grant(bad,now),False)
check('expired grant denied',lambda:driver.validate_grant(grant,now+datetime.timedelta(seconds=601)),False)
check('noncredential session proxy allowed only explicit memory env',lambda:driver.network_env({'public_session_proxy_url':'http://proxy.example:8080'}),True)
for proxy in ['http://user:password@proxy.example:8080','http://proxy.example/?token=x','file:///private','http://proxy.example/private']:
 check('credential/ambiguous proxy denied without output',lambda:driver.network_env({'public_session_proxy_url':proxy}),False)
# Pure namespace metadata/FD mocks, no actual tmp creation or foreign writes.
anchors=json.loads((P/'namespace-anchors.safe.json').read_text())['anchors']
path=Path(grant['payload_namespace'])
def info(i):return types.SimpleNamespace(st_mode=stat.S_IFDIR|i['mode'],st_dev=i['device'],st_ino=i['inode'],st_uid=i['uid'],st_gid=i['gid'])
base={r['path']:info(r['identity']) for r in anchors}
class FakeOS:
 O_RDONLY=os.O_RDONLY;O_WRONLY=os.O_WRONLY;O_DIRECTORY=os.O_DIRECTORY;O_NOFOLLOW=os.O_NOFOLLOW;O_CLOEXEC=os.O_CLOEXEC;O_CREAT=os.O_CREAT;O_EXCL=os.O_EXCL
 def __init__(self,table):self.table=table;self.fds={};self.serial=10;self.created=[]
 def getuid(self):return 1000
 def open(self,p,flags,dir_fd=None):
  target=str(Path(self.fds[dir_fd][0])/p) if dir_fd is not None else p
  value=self.table[target]
  if not stat.S_ISDIR(value.st_mode):raise OSError('mock nofollow')
  self.serial+=1;self.fds[self.serial]=(target,value);return self.serial
 def mkdir(self,name,mode,dir_fd=None):
  assert dir_fd is not None
  p=str(Path(self.fds[dir_fd][0])/name)
  if p in self.table:raise FileExistsError(p)
  self.table[p]=info({'mode':mode,'device':33,'inode':9001,'uid':1000,'gid':1000});self.created.append(p)
 def fstat(self,fd):return self.fds[fd][1]
 def close(self,fd):self.fds.pop(fd)
for name,mutation,accept in [('valid pinned parent and atomic unique own leaf',None,True),('symlink shared parent',('st_mode',stat.S_IFLNK|0o777),False),('foreign parent identity',('st_uid',999),False),('replaced parent inode',('st_ino',777),False)]:
 import copy
 table=copy.deepcopy(base)
 if mutation:setattr(table['/tmp'],*mutation)
 fake=FakeOS(table);actual=False;obj=None
 with patch.object(driver,'os',fake),patch.object(Path,'lstat',lambda p:fake.table[str(p)]):
  try:obj=driver.Namespace(path);actual=True
  except (RuntimeError,OSError):pass
  finally:
   if obj:obj.close()
 assert actual==accept
 if not accept:assert fake.created==[]
 checks.append({'name':'pure namespace '+name,'pass':True,'actual_tmp_writes':False})
(P/'source-controls.safe.json').write_text(json.dumps({'status':'PASS_SELECTED_DRIVER_HEADER_GRANT_NAMESPACE_CONTROLS','count':len(checks),'checks':checks,'native_download_headers_of_real_packages_extract_or_browser':False,'synthetic_ar_tar_in_memory_only':True,'foreign_or_existing_resource_writes':False},indent=2)+'\n')
print(json.dumps({'source_controls':len(checks),'actual_payload_or_browser':False,'synthetic_only':True}))
