"""T004 source preparation only. Does not start any application."""
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import stat

OWN = Path(__file__).parent
OLD = OWN.parent / 'current_host_config_v4'
REPO = Path('/workspace/rutcampustrack')

def public(name, content):
    p = OWN / name
    p.parent.mkdir(parents=True, exist_ok=True)
    assert not p.exists()
    p.write_text(content)
    p.chmod(0o644)

def main():
    private = OWN / 'private'
    private.mkdir(mode=0o700)
    copied = []
    for name in ['docker.env', 'inactive-bot-pair.json', 'auth.json', 'gateway.json', 'attendance.json',
                 'schedule.json', 'academic.json', 'notification.json', 'bff.json']:
        src = OLD / 'private' / name
        assert stat.S_IMODE(src.stat().st_mode) == 0o600 and src.stat().st_uid == os.getuid()
        dst = private / name
        shutil.copyfile(src, dst)
        dst.chmod(0o600)
        copied.append({'name': name, 'byte_equal': src.read_bytes() == dst.read_bytes(), 'mode': '0600'})
    public('private-copy.safe.json', json.dumps(copied, indent=2) + '\n')
    specs = json.loads((OLD / 'host-service-specs.json').read_text())
    for s in specs:
        s['private_environment_file'] = str(private / Path(s['private_environment_file']).name)
    public('host-service-specs.json', json.dumps(specs, indent=2) + '\n')
    runner = (OLD / 'run-service-v4.py').read_text().replace('run-service-v4.py', 'run-service-v5.py')
    runner = runner.replace("{'NP01_BROKER1': True, 'FORMAT_JAVA': True}",
                            "{'NP01_BROKER1': True, 'FORMAT_JAVA': True, 'FORMAT_NODE': True}")
    runner = runner.replace("        raise RuntimeError('Fresh guard review receipt identity required')",
        "        raise RuntimeError('Fresh guard review receipt identity required')\n"
        "    if digest(grant['config_review_manifest']) != grant['config_review_manifest_sha256']:\n"
        "        raise RuntimeError('Fresh independent v5 config review receipt required')")
    public('run-service-v5.py', runner)
    public('tool-provenance.json', (OLD / 'tool-provenance.json').read_text())
    compose = (OLD / 'data-renderer-edge.compose.yml').read_text()
    for service in ['mongo-attendance', 'pwa-nginx', 'mini-app-nginx']:
        compose, n = re.subn(r'(?m)^  ' + service + r':\n.*?(?=^  [\w-]+:|^networks:)', '', compose, flags=re.S)
        assert n == 1
    compose = compose.replace(str(REPO / 'tests/e2e/infra/nginx/default.conf'), str(OWN / 'edge-default.conf'))
    start = compose.index('    depends_on:\n', compose.index('  nginx:\n'))
    end = compose.index('\nnetworks:', start)
    compose = compose[:start] + compose[end:]
    extra = ''
    for app, frontend in [('app', 'pwa-vue'), ('mini-app', 'tma-vue')]:
        extra += ('    - type: bind\n      source: /workspace/scratch/rct-validation/current_vue_stage/frontend/'
                  + frontend + '/dist\n      target: /var/www/clients/' + app
                  + '\n      read_only: true\n      bind:\n        create_host_path: false\n')
    compose = compose.replace('\nnetworks:', extra + '\nnetworks:', 1)
    public('data-renderer-edge.compose.yml', compose)
    edge = (REPO / 'tests/e2e/infra/nginx/default.conf').read_text()
    start = edge.index('    location /app/ {')
    end = edge.index('    location = / {', start)
    static = '    root /var/www/clients;\n    index index.html;\n'
    static += '    location = /app { return 301 /app/; }\n    location = /mini-app { return 301 /mini-app/; }\n'
    static += '''    location ~* ^/(?:app|mini-app)/.*\\.(js|css|png|jpg|jpeg|svg|ico|woff|woff2)$ {
        client_max_body_size 1m;
        add_header Cache-Control "public, max-age=31536000, immutable" always;
        try_files $uri =404;
    }
'''
    no_cache = '''        client_max_body_size 1m;
        add_header Cache-Control "no-store, no-cache, must-revalidate, max-age=0" always;
        add_header Pragma "no-cache" always;
        expires off;
'''
    for url in ['/app/sw.js', '/app/sw-assets.js', '/app/version.json', '/app/index.html', '/mini-app/index.html']:
        static += '    location = ' + url + ' {\n' + no_cache + '        try_files $uri =404;\n    }\n'
    for app in ['app', 'mini-app']:
        static += '    location /' + app + '/ {\n' + no_cache + '        try_files $uri $uri/ /' + app + '/index.html;\n    }\n'
    public('edge-default.conf', edge[:start] + static + edge[end:])
    public('mongo-init-app-users.js', (REPO / 'infra/mongo/init-mongo.js').read_text())
    public('mongo-bootstrap.js', '''// Public script: credentials only from the explicitly supplied own synthetic environment.
const admin = db.getSiblingDB('admin');
const result = admin.runCommand({replSetInitiate: {_id: 'rs0', members: [{_id: 0, host: '127.0.0.1:28417'}]}});
if (result.ok !== 1) throw new Error('Fresh replica initialization failed');
let primary = false;
for (let i = 0; i < 160; i++) {
    if (admin.runCommand({hello: 1}).isWritablePrimary === true) { primary = true; break; }
    sleep(250);
}
if (!primary) throw new Error('Replica primary deadline');
admin.createUser({user: process.env.MONGO_ROOT_USER, pwd: process.env.MONGO_ROOT_PASSWORD,
    roles: [{role: 'root', db: 'admin'}]});
const authenticated = admin.auth(process.env.MONGO_ROOT_USER, process.env.MONGO_ROOT_PASSWORD);
if (authenticated !== 1 && authenticated?.ok !== 1)
    throw new Error('Synthetic root authentication failed');
''' + 'load(' + repr(str(OWN / 'mongo-init-app-users.js')) + ');\n')
    native = Path('/tmp/rct-native-mongo-20261012')
    spec = {'status': 'SOURCE_PREPARED_SERVER_NOT_RUN', 'image': 'sha256:cc6e50c173ff2cf38ffb812fb582450e9b40fc1f67eadd63e81071f18fc8cc96',
            'mongod': str(native / 'mongod'), 'mongosh': str(native / 'mongosh'),
            'db_path': str(native / 'fresh-db'), 'runtime': str(native / 'runtime'),
            'port': 28417, 'bind_ip': '127.0.0.1', 'replica_set': 'rs0', 'rss_stop_bytes': 1073741824,
            'tmp_growth_reserve_bytes': 1073741824,
            'old_volume_preserved_not_mounted': 'rct-client-host-config-20261012_owned-mongo-attendance',
            'required_private_names': ['MONGO_ROOT_USER', 'MONGO_ROOT_PASSWORD', 'MONGO_USER', 'MONGO_PASSWORD',
                                       'MONGO_NOTIFICATION_USER', 'MONGO_NOTIFICATION_PASSWORD', 'MONGODB_REPLICA_SET_KEY']}
    public('mongo-spec.json', json.dumps(spec, indent=2) + '\n')
    (OWN / 'CURRENT.json').write_text(json.dumps({'status': 'NATIVE_FEASIBILITY_PASS_V5_SOURCE_PREPARED',
        'applications_started': 0, 'remaining': 'minimal Mongo runner, source controls and independent review'}, indent=2) + '\n')
    print(json.dumps({'private_copies': len(copied), 'all_equal': all(r['byte_equal'] for r in copied), 'source_prepared': True}))

if __name__ == '__main__':
    main()
