"""Own disposable Docker resources for the bounded NP02 probe, no shared state."""
import datetime
import json
import os
from pathlib import Path
import subprocess
import time
import uuid

ROOT = Path('/workspace/rct-worktrees/notification-provider')
SCRATCH = Path('/workspace/scratch/rct-validation/notification_provider_developer')
DOCKER = ['docker', '--host=unix:///var/run/docker.sock']
RUN_ID = 'rct-notify3-' + uuid.uuid4().hex[:10]
OWNED = []
ENV = dict(os.environ)
for key in ('DOCKER_HOST', 'DOCKER_CONTEXT', 'DOCKER_TLS', 'DOCKER_TLS_VERIFY', 'DOCKER_CERT_PATH'):
    ENV.pop(key, None)


def command(args, *, check=True):
    result = subprocess.run(DOCKER + args, env=ENV, capture_output=True, text=True)
    if check and result.returncode:
        raise RuntimeError('owned Docker boundary failed: ' + args[0])
    return result


def receipt(data):
    data['time'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    with (SCRATCH / 'attempts.ndjson').open('a') as file:
        file.write(json.dumps(data) + '\n')


try:
    for suffix, image, ports in [('rabbit', 'rabbitmq:3.13-management-alpine', [5672, 15672]),
                                 ('redis', 'redis:7.2', [6379])]:
        name = RUN_ID + '-' + suffix
        args = ['run', '-d', '--name', name, '--label', 'rct.validation.scope=notify3',
                '--label', 'rct.validation.run=' + RUN_ID]
        for port in ports:
            args.extend(['-p', f'127.0.0.1::{port}'])
        if suffix == 'rabbit':
            args.extend(['-e', 'RABBITMQ_SERVER_ADDITIONAL_ERL_ARGS=-rabbit collect_statistics_interval 1000'])
        args.append(image)
        identity = command(args).stdout.strip()
        OWNED.append(identity)
        receipt({'action': 'NP02_owned_resource_started', 'name': name, 'id': identity, 'image': image})
    deadline = time.monotonic() + 60
    while True:
        rabbit_ready = command(['exec', OWNED[0], 'rabbitmq-diagnostics', '-q', 'ping'], check=False).returncode == 0
        redis_ready = command(['exec', OWNED[1], 'redis-cli', 'ping'], check=False).stdout.strip() == 'PONG'
        if rabbit_ready and redis_ready:
            break
        if time.monotonic() > deadline:
            raise TimeoutError('owned synthetic containers readiness')
        time.sleep(1)
    def mapped(identity, port):
        data = json.loads(command(['inspect', '--format', '{{json .NetworkSettings.Ports}}', identity]).stdout)
        return int(data[str(port) + '/tcp'][0]['HostPort'])
    argv = ['/workspace/rct-cloud-setup/bot-venv/bin/python',
            'tests/harness/otp_delivery_ack_probe.py',
            '--rabbit-port', str(mapped(OWNED[0], 5672)),
            '--redis-port', str(mapped(OWNED[1], 6379)),
            '--management-port', str(mapped(OWNED[0], 15672))]
    if os.getenv('NOTIFY3_RECOVERY') == '1':
        argv.append('--recover')
    launch = {'action': 'NP02_actual_probe_launch', 'argv': argv, 'cwd': str(ROOT / 'services/notification-bot'),
              'head': 'e093eb988785ed48f26c4f3a561f168ed4d96401', 'owned_ids': OWNED,
              'lease': 'NOTIFY3', 'env': {'PYTHONPATH': str(ROOT / 'services/notification-bot')}}
    (SCRATCH / 'NP02-command.json').write_text(json.dumps(launch, indent=2) + '\n')
    receipt(launch)
    probe_env = dict(ENV, PYTHONPATH=str(ROOT / 'services/notification-bot'))
    probe = subprocess.run(argv, cwd=ROOT / 'services/notification-bot', env=probe_env,
                           capture_output=True, text=True, timeout=45)
    # Raw exceptions/request bodies are never written. Probe stdout is safe counts/booleans JSON.
    result = json.loads(probe.stdout.strip())
    result['exit'] = probe.returncode
    result['stderr_lines_not_persisted'] = len(probe.stderr.splitlines())
    (SCRATCH / 'NP02-result.json').write_text(json.dumps(result, indent=2) + '\n')
    receipt(dict(result, action='NP02_actual_probe_terminal'))
    print(json.dumps(result))
except Exception as error:
    result = {'result': 'INFRA_ERROR', 'error_type': type(error).__name__}
    (SCRATCH / 'NP02-result.json').write_text(json.dumps(result, indent=2) + '\n')
    receipt(dict(result, action='NP02_wrapper_infra_terminal'))
    print(json.dumps(result))
finally:
    cleanup = []
    for identity in OWNED:
        removed = command(['rm', '-f', identity], check=False)
        cleanup.append({'id': identity, 'remove_exit': removed.returncode})
    (SCRATCH / 'NP02-cleanup.json').write_text(json.dumps(cleanup, indent=2) + '\n')
    receipt({'action': 'NP02_owned_resources_cleanup', 'resources': cleanup})
