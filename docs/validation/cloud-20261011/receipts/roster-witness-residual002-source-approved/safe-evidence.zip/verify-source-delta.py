"""Inverse exact source delta only: no JS/helper import or runtime."""
from pathlib import Path
import hashlib,json,os
A=Path('/workspace/scratch/rct-validation/client_real_acceptance')
OUT=Path(__file__).parent
old=(A/'roster-witness-correction-r1/witness-detail-lookup.cjs').read_bytes()
new=(A/'roster-witness-correction-r2/witness-detail-lookup.cjs').read_bytes()
assert hashlib.sha256(old).hexdigest()=='bf115103115a8cbb5379398f53903b62cc3523078557e9c2fff291c62fc84b9c'
assert hashlib.sha256(new).hexdigest()=='4c4ad5626636b50d3183052ded3d4f342ce8bb15ab2b9645fd3b60d45cc997be'
deltas=[(b"  // Playwright can store Set-Cookie before fetch rejects while reading its body.\n  if (method === 'POST' && route === '/api/auth/login') handle.loginAttempted = true;\n",b''),
 (b'let logoutConfirmed = !handle.loginIssued && !handle.loginAttempted;',b'let logoutConfirmed = !handle.loginIssued;'),
 (b'if (handle.loginIssued || handle.loginAttempted) {',b'if (handle.loginIssued) {'),
 (b'loginIssued: false, loginAttempted: false',b'loginIssued: false')]
inverse=new
for before,after in deltas:
    assert inverse.count(before)==1
    inverse=inverse.replace(before,after)
assert inverse==old
s=new.decode();call=s[s.index('async function call('):s.index('async function admit(')];cleanup=s[s.index('async function cleanup('):s.index('async function run(')]
assert call.index('handle.loginAttempted = true')<call.index('await handle.context.fetch')
assert 'let logoutConfirmed = !handle.loginIssued && !handle.loginAttempted;' in cleanup
assert cleanup.index('if (handle.loginIssued || handle.loginAttempted)')<cleanup.index('await handle.context.storageState()')
assert 'logoutConfirmed = ownsAuth && status === 204 && !ownsRefresh(after);' in cleanup
assert 'await handle.context.dispose(); contextDisposed = true;' in cleanup
v={'verdict':'APPROVE_SOURCE','residual':'ROSTER-WITNESS-ADMISSION-CLEANUP-002','old_helper_sha256':hashlib.sha256(old).hexdigest(),'new_helper_sha256':hashlib.sha256(new).hexdigest(),'inverse_whole_source_exact':True,'exact_delta_count':len(deltas),'classifier_pagination_and_all_other_logic_exact':True,'attempt_before_fetch':True,'attempted_or_issued_owned_state_inspection':True,'existing_owned_logout204_cookie_removal_dispose_checks_preserved':True,'native':False,'JS_helper_import_API_Node':False}
fd=os.open(OUT/'source-delta.safe.json',os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
with os.fdopen(fd,'w') as f:json.dump(v,f,indent=2);f.write('\n')
print(json.dumps(v))
