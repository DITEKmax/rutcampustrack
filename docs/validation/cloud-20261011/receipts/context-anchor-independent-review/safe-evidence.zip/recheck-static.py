"""Static source/seal comparison only; never imports or executes target modules."""
import ast
import copy
import datetime
import difflib
import hashlib
import json
from pathlib import Path, PurePosixPath
import stat
import zipfile

OUT = Path(__file__).parent
ROOT = OUT.parent
PAY = ROOT/'browser_webkit_payload_context_correction'
REST = ROOT/'current_host_restart_context_correction'
OLDPAY = ROOT/'browser_webkit_payload_prepare'
OLDREST = ROOT/'current_host_restart_ancestor_correction_v2'
EXPECTED = {PAY:'58986163c28a691e7fd5aeb982feb9bb98f777ad3f99b0e4310cf637d8960334',REST:'7c03e6cb7cb1c200c7e788e8b7c28b0d6cabb8b5b8bfc29d37f906739ad68236'}
def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def tree(path): return ast.parse(Path(path).read_text())
def dump(node): return ast.dump(node,include_attributes=False)
def function(t,name): return next(n for n in t.body if isinstance(n,(ast.FunctionDef,ast.ClassDef)) and n.name==name)
def callverify(node):
    return isinstance(node,ast.Expr) and isinstance(node.value,ast.Call) and ast.unparse(node.value.func)=='verify_execution_actor'
results = {}
for directory, expected in EXPECTED.items():
    assert sha(directory/'manifest.json') == expected
    manifest=json.loads((directory/'manifest.json').read_text())
    assert manifest['private_values_payload_data_or_rawlogs_included'] is False
    members={}
    for row in manifest['files']:
        p=Path(row['path'])
        assert p.parent==directory and row['name']==p.name and 'private' not in p.parts
        s=p.lstat();assert stat.S_ISREG(s.st_mode)
        assert s.st_size==row['bytes'] and sha(p)==row['sha256']
        if 'mode' in row:assert stat.S_IMODE(s.st_mode)==row['mode']
        members[p.name]=row['sha256']
        if p.suffix=='.py':ast.parse(p.read_text())
    members['manifest.json']=expected
    with zipfile.ZipFile(directory/'safe-evidence.zip') as z:
        assert len(z.infolist())==len(members) and len(z.namelist())==len(set(z.namelist()))
        for item in z.infolist():
            p=PurePosixPath(item.filename)
            assert not p.is_absolute() and '..' not in p.parts and not stat.S_ISLNK(item.external_attr>>16)
            assert item.filename in members and hashlib.sha256(z.read(item)).hexdigest()==members[item.filename]
        assert z.testzip() is None
    preserved=[]
    for row in json.loads((directory/'preservation.safe.json').read_text())['checks']:
        mpath=Path(row['manifest']);assert sha(mpath)==row['sha256']
        m=json.loads(mpath.read_text())
        entries=m.get('files',m.get('entries'))
        assert len(entries)==row['member_count']
        for entry in entries:
            path=Path(entry['path'])
            if not path.is_absolute():path=mpath.parent/path
            assert 'private' not in path.parts and path.suffix!='.env'
            assert sha(path)==entry['sha256']
            if 'bytes' in entry:assert path.stat().st_size==entry['bytes']
        preserved.append({'manifest':str(mpath),'sha256':row['sha256'],'members':len(entries)})
    native=json.loads((directory/'native-context-metadata.safe.json').read_text())
    dual=json.loads((directory/'dual-context.safe.json').read_text())
    assert native['actor_uid']==native['actor_gid']==dual['actor_uid']==dual['actor_gid']==1000
    for row in native['rows']:
        assert row['lstat']==row['nofollow_fstat'] and row['lstat']['is_directory'] is True
        corresponding=next(r for r in dual['rows'] if r['path']==row['path'])
        n={k:v for k,v in row['lstat'].items() if k!='is_directory'}
        assert n==corresponding['approved_native']
        for key in ('device','inode','mode'):assert n[key]==corresponding['default_sandbox'][key]
        assert (n['uid'],n['gid'])==((0,0) if row['path'] in {'/','/tmp'} else (1000,1000))
        assert (corresponding['default_sandbox']['uid'],corresponding['default_sandbox']['gid'])==((65534,65534) if row['path'] in {'/','/tmp'} else (1000,1000))
    results[directory.name]={'manifest_sha256':expected,'zip_sha256':sha(directory/'safe-evidence.zip'),'zip_bytes':(directory/'safe-evidence.zip').stat().st_size,'zip_members':len(members),'preserved_seals':preserved,'native_context_receipt_consistent':True,'native_context_evidence':'AUTHOR_METADATA_READBACK; reviewer does not repeat approved-context call'}

for new, old, anchor_name in [(PAY,OLDPAY,'namespace-anchors.safe.json'),(REST,OLDREST,'runtime-ancestor-anchors.safe.json')]:
    before=json.loads((old/anchor_name).read_text())['anchors']
    after=json.loads((new/anchor_name).read_text())['anchors']
    altered=copy.deepcopy(before)
    for row in altered:
        if row['path'] in {'/','/tmp'}:
            d=row['identity'] if 'identity' in row else row
            assert d['uid']==d['gid']==65534
            d['uid']=d['gid']=0
    assert after==altered
    results[new.name]['anchors_exact_only_root_tmp_uid_gid_changed']=True

payload_new=tree(PAY/'download-headers.py');payload_old=tree(OLDPAY/'download-headers.py')
restart_new=tree(REST/'restart-boundary.py');restart_old=tree(OLDREST/'restart-boundary.py')
for name in ['sha','regular','resources','resource_stop','network_env']:
    assert dump(function(payload_new,name))==dump(function(payload_old,name)),name
for name in ['regular','sha','validate_restart_fields','metadata','matching','verify_existing_data','dir_identity']:
    assert dump(function(restart_new,name))==dump(function(restart_old,name)),name
for newer,older,cname in [(payload_new,payload_old,'Namespace'),(restart_new,restart_old,'CohortDirectory')]:
    c=copy.deepcopy(function(newer,cname));init=function(c,'__init__')
    assert callverify(init.body[0]);init.body.pop(0)
    assert dump(c)==dump(function(older,cname))
for name in ['docker-up-restart.py','run-mongo-restart.py','run-service-restart.py']:
    t=tree(REST/name);main=function(t,'main')
    assert isinstance(main.body[0],ast.If)
    assert ast.unparse(main.body[0].test)=='os.getuid() != 1000 or os.getgid() != 1000'
    main.body.pop(0)
    assert dump(t)==dump(tree(OLDREST/name)),name
    original_main=function(tree(REST/name),'main')
    flat=ast.unparse(original_main)
    assert flat.index('restart_ancestor_correction_manifest_sha256')<flat.index("types.ModuleType('restart_boundary')")<flat.index('boundary.__file__ =')<flat.index('exec(')<flat.index('boundary.verify_restart')<flat.index('boundary.CohortDirectory')

# Independently compare exact actual source delta to sealed patch; no target execution.
for new,old,names in [(PAY,OLDPAY,['download-headers.py','source-controls.py']),(REST,OLDREST,['restart-boundary.py','docker-up-restart.py','run-mongo-restart.py','run-service-restart.py','ancestor-controls.py'])]:
    text=''.join(''.join(difflib.unified_diff((old/name).read_text().splitlines(keepends=True),(new/name).read_text().splitlines(keepends=True),fromfile=str(old/name),tofile=str(new/name))) for name in names)
    assert text==(new/'source-delta.patch').read_text()
    results[new.name]['actual_source_patch_exact']=True
assert sha(PAY/'public-headers.py')==sha(OLDPAY/'public-headers.py')
assert sha(PAY/'approved-packages.safe.json')==sha(OLDPAY/'approved-packages.safe.json')
assert sha(PAY/'public-tool-identity.safe.json')==sha(OLDPAY/'public-tool-identity.safe.json')

# Pure comparison counterexamples based on literal exact identity checks, no module import.
predicate_checks=[]
for new,anchor_name in [(PAY,'namespace-anchors.safe.json'),(REST,'runtime-ancestor-anchors.safe.json')]:
    for row in json.loads((new/anchor_name).read_text())['anchors']:
        expected=row['identity'] if 'identity' in row else {k:v for k,v in row.items() if k!='path'}
        assert all(type(v) is int for v in expected.values())
        assert expected==dict(expected)
        for field in ('uid','gid','device','inode','mode'):
            candidate=dict(expected);candidate[field]+=1
            assert candidate!=expected
            predicate_checks.append({'overlay':new.name,'path':row['path'],'changed':field,'exact_comparison_rejects':True})
        candidate=dict(expected);candidate['uid']=candidate['gid']=65534
        assert candidate!=expected
    counts={}
    names=['source-controls.safe.json','context-controls.safe.json','actor-controls.safe.json'] if new==PAY else ['ancestor-controls.safe.json','helper-import-controls.safe.json','context-controls.safe.json','actor-controls.safe.json']
    for name in names:
        receipt=json.loads((new/name).read_text())
        assert receipt['count']==len(receipt['checks'])
        assert all(r.get('pass',True) is True for r in receipt['checks'])
        counts[name]=receipt['count']
    results[new.name]['author_pure_controls_counts_not_reexecuted']=counts
    results[new.name]['unchanged_guards_class_receipts_data_AST']=True
results['reviewer']={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'literal_identity_counterexamples':predicate_checks,'counterexample_count':len(predicate_checks),'target_modules_imported_or_executed':False,'native_actions_payload_network_stand_browser_private_reads':False,'source_AST_and_seal_checks':'PASS'}
(OUT/'static-recheck.safe.json').write_text(json.dumps(results,indent=2)+'\n')
print(json.dumps({'new_overlay_seals_exact':2,'prior_public_seals_exact_each':5,'identity_counterexamples':len(predicate_checks),'target_runtime_imports':False,'result':'PASS_STATIC'},indent=2))
