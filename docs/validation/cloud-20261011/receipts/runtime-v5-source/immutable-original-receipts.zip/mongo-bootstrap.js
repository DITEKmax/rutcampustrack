// Public script: credentials only from the explicitly supplied own synthetic environment.
const admin = db.getSiblingDB('admin');
const result = admin.runCommand({replSetInitiate: {_id: 'rs0', members: [{_id: 0, host: '127.0.0.1:28417'}]}});
if (result.ok !== 1) throw new Error('Fresh replica initialization failed');
let primary = false;
for (let i = 0; i < 160; i++) {
    if (admin.runCommand({hello: 1}).isWritablePrimary === true) { primary = true; break; }
    sleep(250);
}
if (!primary) throw new Error('Replica primary deadline');
admin.createUser({user: process.env.MONGO_ROOT_USER, pwd: process.env.MONGO_ROOT_PASSWORD,
    roles: [{role: 'root', db: 'admin'}]});
const authenticated = admin.auth(process.env.MONGO_ROOT_USER, process.env.MONGO_ROOT_PASSWORD);
if (authenticated !== 1 && authenticated?.ok !== 1)
    throw new Error('Synthetic root authentication failed');
load('/workspace/scratch/rct-validation/current_host_config_v5/mongo-init-app-users.js');
