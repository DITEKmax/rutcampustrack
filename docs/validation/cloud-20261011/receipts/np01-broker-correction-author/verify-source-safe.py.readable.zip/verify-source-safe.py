"""Source-only oracle counterexamples; never import the broker runner or read parent ENV."""

import ast
import datetime
import hashlib
import json
from pathlib import Path

ROOT = Path('/workspace/rct-worktrees/np01-domain-bot')
OUT = Path('/workspace/scratch/rct-validation/np01_domain_bot/broker-corrections')
JAVA = 'services/academic-service/academic-app/src/test/java/ru/rutcampustrack/academic/botcredentials/BotCredentialBrokerBridgeIT.java'
PYTHON = 'services/notification-bot/tests/np01_broker_bridge_runner.py'
source = (ROOT / PYTHON).read_text()
tree = ast.parse(source)
names = {'BridgeFailure', 'check', 'require_exact_card', 'capture_new_card', 'worker_environment'}
body = [node for node in tree.body if isinstance(node, (ast.ClassDef, ast.FunctionDef)) and node.name in names]
body += [node for node in tree.body if isinstance(node, ast.Assign)
         and any(isinstance(target, ast.Name) and target.id == '_WORKER_INPUTS' for target in node.targets)]
namespace = {'_checks': 0}
exec(compile(ast.Module(body=body, type_ignores=[]), '<extracted-pure-source-only>', 'exec'), namespace)
old_key, new_key = (11, 1), (22, 2)
old_text, new_text = 'synthetic foreign same marker old full text', 'synthetic foreign same marker NEW full text'
cards = {old_key: old_text, new_key: new_text}
assert namespace['capture_new_card'](cards, {old_key}, 22, 'same marker') == (new_key, new_text)
deleted = {old_key: old_text}
old_accepts = any('same marker' in text for text in deleted.values())
assert old_accepts

def rejected(state):
    try:
        namespace['require_exact_card'](state, new_key, new_text)
    except namespace['BridgeFailure']:
        return True
    raise AssertionError('wrong NEW card state did not fail exact oracle')

assert rejected(deleted)
assert rejected({old_key: old_text, new_key: new_text + ' changed'})
namespace['require_exact_card'](cards, new_key, new_text)
needed = namespace['_WORKER_INPUTS']
parent = dict.fromkeys(needed, 'synthetic-needed-input')
unrelated = ('AWS_ACCESS_KEY_ID', 'JAVA_TOOL_OPTIONS', 'JDK_JAVA_OPTIONS', '_JAVA_OPTIONS', 'LD_PRELOAD',
             'PYTHONHOME', 'PYTHONSTARTUP', 'UNRELATED_CREDENTIAL', 'NP01_CONTROL_TOKEN', 'NP01_FIXTURES')
parent.update(dict.fromkeys(unrelated, 'synthetic-unrelated-sentinel'))
parent['PYTHONPATH'] = 'synthetic-untrusted-parent-path'
environment = namespace['worker_environment']('http://127.0.0.1:1', parent, '/synthetic/trusted/module')
assert not any(name in environment for name in unrelated)
assert environment['PYTHONPATH'] == '/synthetic/trusted/module'
missing = dict(parent)
del missing['NP01_RABBIT_PASSWORD']
try:
    namespace['worker_environment']('http://127.0.0.1:1', missing, '/synthetic/trusted/module')
except KeyError:
    pass
else:
    raise AssertionError('missing required worker input accepted')
java = (ROOT / JAVA).read_text()
guards = {
    'BR_G01_java_closed_environment': 'environment.clear();' in java and java.count('minimalEnvironment(launch);') == 2,
    'BR_G01_no_worker_parent_copy': 'dict(os.environ)' not in source and 'source[name] for name in _WORKER_INPUTS' in source,
    'BR_G02_graceful_parent_before_force': java.index('process.destroy();') < java.index('awaitOwnedWorkers(descendants, process.pid());') < java.index('if (process.isAlive()) process.destroyForcibly();'),
    'BR_G02_registered_workers_future_reap': 'worker.onExit()' in java and 'worker.exit().get(5, TimeUnit.SECONDS)' in java and 'worker_reaped?pid=' in source,
    'BR_G02_repeated_signals_do_not_cancel_cleanup': 'if not stopping:' in source and 'stopping = True' in source and 'task.cancel()' in source,
    'BR_R01_source_bind_all_declared': 'getExposedPorts().stream()' in java and 'bindIpAndPort("127.0.0.1", 0)' in java and 'withPublishAllPorts(false)' in java,
    'BR_R01_native_inspect_required': 'inspectContainerCmd(container.getContainerId()).exec()' in java and 'isEqualTo("127.0.0.1")' in java and 'Set.copyOf(container.getExposedPorts())' in java,
    'held_default_300_explicit': 'DEFAULT_TTL_SECONDS == 300' in source and '270_000 < held_pttl <= 300_000' in source,
    'held_native_redelivery_no_ack': 'stopped["redeliver"] + 2' in source and 'facts["ack"] == baseline["ack"]' in source,
    'held_exact_card_before_after': 'require_exact_card(provider.cards, held_card_key, held_card_text)' in source and 'held_card_key not in provider.cards' in source,
    'held_natural_expiry_clock_and_deadline': '_held_lease_elapsed_ms >= held_pttl - 2_000' in source and 'child.waitFor(600, TimeUnit.SECONDS)' in java,
    'supervisor_redis_observation_only': all(not (isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute)
                                              and isinstance(node.func.value, ast.Name) and node.func.value.id in {'redis', 'guard'}
                                              and node.func.attr in {'set', 'delete', 'expire', 'pexpire', 'eval', 'claim', 'complete', 'release', 'renew'})
                                             for node in ast.walk(next(node for node in tree.body if isinstance(node, ast.AsyncFunctionDef) and node.name == 'supervisor'))),
}
assert all(guards.values()), guards
inputs = {path: hashlib.sha256((ROOT / path).read_bytes()).hexdigest() for path in (JAVA, PYTHON)}
clock = datetime.datetime.now(datetime.timezone.utc).isoformat()
counterexamples = {
    'utc': clock, 'source_only': True, 'real_parent_env_read': False,
    'network_jvm_docker_signals': 'NOT_RUN', 'source_inputs': inputs, 'python_ast': 'PASS',
    'BR_T01': {'original_global_marker_oracle_accepts_wrong_new_deletion': old_accepts,
               'corrected_exact_new_oracle_rejects_wrong_deletion': True, 'old_card_still_exact': deleted[old_key] == old_text,
               'corrected_exact_new_oracle_rejects_text_change': True, 'correct_card_positive_control': True},
    'BR_G01': {'old_copy_would_include_unrelated': True, 'new_worker_env_omits_all_unrelated': True,
               'trusted_module_path_overrides_parent_channel': True, 'missing_needed_input_denied': True,
               'worker_env_count': len(environment)},
}
(OUT / 'source-safe-counterexamples.safe.json').write_text(json.dumps(counterexamples, indent=2) + '\n')
(OUT / 'source-guards.safe.json').write_text(json.dumps({'utc': clock, 'source_only': True, 'source_inputs': inputs,
                                                       'java_compile': 'NOT_RUN', 'python_ast': 'PASS',
                                                       'source_controls': guards, 'runtime': 'NOT_RUN'}, indent=2) + '\n')
print(json.dumps({'pure_oracle_counterexamples': 'PASS', 'python_ast': 'PASS', 'source_controls': len(guards),
                  'java_compile_broker_runtime': 'NOT_RUN', 'parent_env_read': False}))
