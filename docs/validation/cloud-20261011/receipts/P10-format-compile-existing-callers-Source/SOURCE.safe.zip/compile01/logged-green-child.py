"""Existing NP01 private-Gradle-output pattern, narrowed to one coherent main/test compile and targeted unit invocation."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import stat
import subprocess
import sys

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def private_json(path):
    if path.resolve() != path.absolute():
        raise ValueError("No-follow private input required")
    descriptor = os.open(path, os.O_RDONLY | os.O_NOFOLLOW)
    with os.fdopen(descriptor, "rb") as stream:
        info = os.fstat(stream.fileno())
        if not stat.S_ISREG(info.st_mode) or info.st_mode & 0o777 != 0o600 or info.st_size > 65536:
            raise ValueError("Bounded mode600 private input required")
        return json.loads(stream.read(65537))

def identity(pid):
    fields = (Path("/proc") / str(pid) / "stat").read_text().rsplit(")", 1)[1].split()
    if fields[0] == "Z":
        raise ValueError("Live process required")
    return {"pid": pid, "ppid": int(fields[1]), "start_ticks": int(fields[19])}

def admit_child(scope):
    plan_path = scope / "green-plan.safe.json"
    plan = json.loads(plan_path.read_text())
    run = Path(plan["run"])
    if not (os.getcwd() == plan["worktree"] and run.resolve() == run.absolute()
            and run.is_dir() and run.stat().st_mode & 0o777 == 0o700):
        raise ValueError("Exact owned private run and worktree required")
    witness = private_json(run / "parent-authority.private.json")
    parent = identity(os.getppid())
    child = identity(os.getpid())
    driver = scope / "run-green-owned.py"
    if not (witness["parent"]["pid"] == parent["pid"]
            and witness["parent"]["start_ticks"] == parent["start_ticks"]
            and child["ppid"] == parent["pid"] and witness["run"] == str(run)
            and witness["driver_sha256"] == digest(driver)
            and witness["child_sha256"] == digest(Path(__file__))
            and witness["plan_sha256"] == digest(plan_path)):
        raise ValueError("Exact live direct parent and source witness required")
    expected_args = [str(driver).encode(), witness["grant_path"].encode(), witness["grant_sha256"].encode()]
    actual_args = (Path("/proc") / str(parent["pid"]) / "cmdline").read_bytes().split(b"\0")
    if actual_args[1:4] != expected_args or any(actual_args[4:]):
        raise ValueError("Exact granted parent caller required")
    grant_path = Path(witness["grant_path"])
    grant = private_json(grant_path)
    if not (digest(grant_path) == witness["grant_sha256"] and grant["authorized"] is True
            and grant["lease"] == plan["lease"] and grant["source_review_approved"] is True
            and grant["driver_sha256"] == witness["driver_sha256"]
            and grant["child_sha256"] == witness["child_sha256"]
            and grant["plan_sha256"] == witness["plan_sha256"]
            and grant["guard_sha256"] == plan["guard_sha256"]
            and digest(Path(plan["guard_path"])) == plan["guard_sha256"]
            and grant["test_sha256"] == plan["test_sha256"]
            and digest(Path(plan["worktree"]) / plan["test_path"]) == plan["test_sha256"]):
        raise ValueError("Fresh Root grant and exact source required")
    manifest_path = scope / plan["source_manifest"]
    if not (digest(manifest_path) == plan["source_manifest_sha256"]
            and grant["source_manifest_sha256"] == plan["source_manifest_sha256"]):
        raise ValueError("Pinned formatted source manifest required")
    manifest = json.loads(manifest_path.read_text())
    for path, expected in {**manifest["files"], **manifest["protected_files"]}.items():
        if digest(Path(plan["worktree"]) / path) != expected:
            raise ValueError("Formatted source manifest mismatch")
    issued = datetime.datetime.fromisoformat(grant["issued_utc"])
    stop = datetime.datetime.fromisoformat(grant["stop_utc"])
    now = datetime.datetime.now(datetime.timezone.utc)
    if not (issued.tzinfo and stop.tzinfo and issued <= now
            < stop-datetime.timedelta(seconds=grant["limits"]["cleanup_margin_seconds"])):
        raise ValueError("Current grant with cleanup margin required")
    if identity(parent["pid"]) != parent or identity(child["pid"]) != child:
        raise ValueError("Live parent/child identity changed")
    return plan, run

scope = Path(__file__).resolve().parent
plan, run = admit_child(scope)
log = run / "native.raw.private.log"
with log.open("xb") as output:
    log.chmod(0o600)
    result = subprocess.run(
        ["bash", "./gradlew", *plan["gradle_arguments"]],
        stdin=subprocess.DEVNULL, stdout=output, stderr=subprocess.STDOUT,
    )
(run / "child-exit.safe.json").write_text(json.dumps({"native_exit": result.returncode}) + "\n")
raise SystemExit(result.returncode)
