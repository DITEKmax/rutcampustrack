# Пакет реального запуска: existing8 + NEW14

PREPARATION_ONLY_NOT_RUN. Автор/browser owner — client_real_acceptance, Sol6.1/xhigh selected, actual UNKNOWN. Root source integration `690324a1d9b56962b323a9ecec260aa430fbec79`, текущий прочитанный docs-only Root `2774ccbd8513fd7244c2c4df1cca428b59a6ddb3`; NEW7 byte-exact reviewed author `cf067a008d732ca77f385a3eb1f53e0a79234687`. Independent correction review APPROVE_SOURCE, оба P2 закрыты; это не runtime PASS. JAR/Vue producer остаётся `908fc8c27be82e4a0d7db7bf4d7b2c4a62225916`, отдельно от checkout тестов. Перед фактическим запуском Root указывает новый exact checkout и подтверждает применимую source equivalence.

Сейчас разрешена только подготовка. Нужны отдельно v5 source approval, реальная host/data/API readiness и Root browser/Node resource grant. Никакие команды ниже ещё не выполнялись. Все 11 CLIENT groups UNKNOWN.

## Что host owner должен подготовить

- Exact reviewed v5 Docker6 + native Mongo rs0 + seven genuine Java services, HTTPS loopback8443; actual settled workspace/tmp floors и shared-memory reserve. Старые пять volumes сохраняются, никакого reset/clean для получения PASS.
- Academic стартует/применяет собственные migrations перед Auth: V2 создаёт синтетические seed users, V24 durable grants/session authority, V51 explicit assigned FULL admin profile, V56 export jobs, V57 current schema. На текущем disposable academic DB должен существовать seed actor из `tests/e2e/fixtures/users.ts#TEST_USERS.admin`, с текущим ACTIVE ADMIN grant/FULL profile. Реальный безопасный login/session/active-role probe должен подтвердить200 и ADMIN/FULL; credentials/tokens/body не сохраняются. Этот статус пока NOT_RUN. Отдельное прямое изменение password hash или grant в SQL не требуется.
- `tests/e2e/infra/seed-telegram.sql` только связывает фиксированного старого CI teacher. Он не создаёт bootstrap admin и не нужен для этих22: оба suite создают пользователей и случайные Telegram bindings через реальный API. Не запускать этот seed вслепую ради случайных generated teachers.
- Native Mongo bootstrap/authenticated app users: attendance_db и notification_db readWrite+dbAdmin из существующего init script; replicaSet PRIMARY и authSource=admin реально подтверждены owner. PostgreSQL academic/schedule, Redis, Rabbit actual ready. Schedule adoption/Academic publication, Attendance, BFF, Auth export worker и genuine Renderer доступны без mocks. Health одного процесса недостаточно для этих зависимостей.
- HTTPS edge реально отдаёт `/app/`, `/mini-app/`, exact PWA SW/version/index и bundle bytes; API routes reach Gateway/Auth/BFF/domain with accepted TLS/internal directed identity/.10 trust. Root/host owner делает отдельно actual TLS/spoof/direct-call readiness, не browser author.
- Auth synthetic TMA signer matches existing PUBLIC CI fixture signer; только безопасный equality boolean и корректный valid-proof admission, никакого private ENV/key dump. Auth/security clock реальный. Academic/Schedule/Attendance/BFF читают один accepted clock `/workspace/scratch/rct-validation/current_host_config_v4/teaching-clock/current-instant` = `2026-10-12T06:00:00.000Z` (Monday09 Europe/Moscow); marker bounded `RCT_E2E_DISPOSABLE`. v5 SOURCE сохраняет этот путь, actual loaded/read clock ещё должен подтвердить owner.

Fixture сам создаёт/выбирает active semester, покрывающий today+tomorrow; создаёт две группы, generated credentials/users, headman, published subject/teacher assignment, lesson1, DATE homework и MARK_ATTENDANCE helper через реальный API. Worker setup timeout180s; publication/homework polls60s. Не обходить эти fences seed SQL. Каждый из четырёх отдельных runs получает собственный RNG worker dataset; тесты одного run идут serial. Данные остаются task-owned; stack/data disposal — Root owner, не test cleanup чужих volumes.

## Runner namespace и clock override

Root разрешил и подготовлена настоящая ignored directory `/workspace/rutcampustrack/tests/e2e/node_modules`0700, только семь package symlinks; package targets сохранены0700, link modes120777. @playwright/test/playwright/playwright-core1.59.1; @types/node22.19.17; undici-types6.21.0; @axe-core/playwright4.11.2; axe-core4.11.3. Exact links/targets/modes/lock SHA: `actual-run-root-dependency-namespace.safe.json`. Whole-directory/source/@rct aliases отсутствуют; no install/lock/cache mutation, Node не запускался.

Использовать existing migrated `/tmp/rct-validation-browsers-20261012`: static metadata Chromium/headless-shell1217, WebKit2272, ffmpeg1011 matches installed1.59.1 package. Cache existence/version не доказывает native launch/ELF effectiveness. WebKit libraries/admission проверяются в отдельной granted phase, без download/install/fallback в Chromium.

Оба existing configs не задают `teachingInstant`. Без override fixture берёт host Date.now Moscow и может разойтись с fixed server day. Поддерживается existing worker option `teachingInstant: [undefined, {scope:'worker', option:true}]`: Playwright1.59.1 `poolBuilder.js` передаёт project.use как optionOverrides; `fixtures.js` выбирает option marker; `config.js` merge global→project→CLI. Поэтому программный runtime override задаёт Date отдельно в каждом project.use. Не подменяет глобальный Date.now, auth_date/expiry security clock или fixture/source implementation.

После Root grant сохранить следующую runtime-only config в OWN scratch `actual-runs/client-runtime.config.ts` (сейчас этого source file нет). Только absolute testDir/reporter/output и existing fixture option; no tracked config/source edits:

```ts
import { defineConfig } from '/workspace/rutcampustrack/tests/e2e/node_modules/@playwright/test/index.js'
import { resolve } from 'node:path'
import old from '/workspace/rutcampustrack/tests/e2e/playwright.real-mobile.config.ts'
import accepted from '/workspace/rutcampustrack/tests/e2e/fixtures/cloud-accepted-playwright.ts'
import { readTeachingInstant } from '/workspace/rutcampustrack/tests/e2e/fixtures/teaching-clock.ts'

const lane = process.env.RCT_CLIENT_RUN_LANE
if (lane !== 'existing8' && lane !== 'new14') throw new Error('Explicit finite client lane required')
const inherited = lane === 'existing8' ? old : accepted
const requestedOutput = process.env.RCT_CLIENT_RUN_OUTPUT_DIR
if (!requestedOutput) throw new Error('Own unique output required')
const outputDir = resolve(requestedOutput)
if (!outputDir.startsWith('/workspace/scratch/rct-validation/client_real_acceptance/actual-runs/')) {
  throw new Error('Own runtime output required')
}
const teachingInstant = readTeachingInstant('/workspace/scratch/rct-validation/current_host_config_v4/teaching-clock')
export default defineConfig<{}, { teachingInstant: Date | undefined }>({
  ...inherited,
  testDir: '/workspace/rutcampustrack/tests/e2e/specs',
  outputDir,
  reporter: [['/workspace/rutcampustrack/tests/e2e/fixtures/safe-reporter.ts']],
  fullyParallel: false,
  workers: 1,
  retries: 0,
  use: { ...inherited.use, teachingInstant, timezoneId: 'Europe/Moscow' },
  projects: inherited.projects?.map((project) => ({
    ...project,
    use: { ...project.use, teachingInstant, timezoneId: 'Europe/Moscow' },
  })),
})
```

Inherited testMatch/testIgnore select exactlyexisting8 orNEW14. Existing8 retains its Desktop1280×720 selected projects; NEW14 retains approved390×844. Chromium/WebKit engine on Linux does not prove native Safari/iOS/Telegram/provider/install/push. Clock override source support inspected; runtime config load/effective worker option remains NOT_RUN. No redundant default57/type/whole-source discovery repeat needed; any future bounded check must address this NEW runtime-only override itself.

## Последовательность после grant

Payloads запускаются под назначенным Root foreground/resource guard. Один worker/один browser project, без retries; Root задаёт elapsed/RSS/disk budget и fresh capacity barrier. Записать runner PID/birth/session и cleanup всех своих browser/worker descendants. Перед каждым run новый output directory; не перезаписывать logs/reports предыдущей попытки.

Общие ENV: `CI=true`, `RCT_E2E_SYNTHETIC_SEED=true`, `E2E_BASE_URL=https://localhost:8443`, `PLAYWRIGHT_BROWSERS_PATH=/tmp/rct-validation-browsers-20261012`, `PWTEST_CACHE_DIR=/workspace/scratch/rct-validation/client_real_acceptance/actual-runs/transform-cache`. Удалить только из command environment DEBUG/DEBUG_FILE/PWDEBUG/PW_TEST_REPORTER; не добавлять reporters. Private own artifacts `umask077`.

В отдельном granted runner shell:

```bash
umask 077
unset DEBUG DEBUG_FILE PWDEBUG PW_TEST_REPORTER
export CI=true RCT_E2E_SYNTHETIC_SEED=true E2E_BASE_URL=https://localhost:8443
export PLAYWRIGHT_BROWSERS_PATH=/tmp/rct-validation-browsers-20261012
export PWTEST_CACHE_DIR=/workspace/scratch/rct-validation/client_real_acceptance/actual-runs/transform-cache
```

Из `/workspace/rutcampustrack/tests/e2e`, каждый payload отдельно (RUN_ID — новый Root attempt ID, shell variable не secret):

```bash
RCT_CLIENT_RUN_LANE=existing8 RCT_CLIENT_RUN_OUTPUT_DIR=/workspace/scratch/rct-validation/client_real_acceptance/actual-runs/RUN_ID/chromium-existing8 \
  node --max-old-space-size=512 node_modules/playwright/cli.js test \
  --config /workspace/scratch/rct-validation/client_real_acceptance/actual-runs/client-runtime.config.ts --project=chromium
RCT_CLIENT_RUN_LANE=new14 RCT_CLIENT_RUN_OUTPUT_DIR=/workspace/scratch/rct-validation/client_real_acceptance/actual-runs/RUN_ID/chromium-new14 \
  node --max-old-space-size=512 node_modules/playwright/cli.js test \
  --config /workspace/scratch/rct-validation/client_real_acceptance/actual-runs/client-runtime.config.ts --project=chromium
RCT_CLIENT_RUN_LANE=existing8 RCT_CLIENT_RUN_OUTPUT_DIR=/workspace/scratch/rct-validation/client_real_acceptance/actual-runs/RUN_ID/webkit-existing8 \
  node --max-old-space-size=512 node_modules/playwright/cli.js test \
  --config /workspace/scratch/rct-validation/client_real_acceptance/actual-runs/client-runtime.config.ts --project=webkit
RCT_CLIENT_RUN_LANE=new14 RCT_CLIENT_RUN_OUTPUT_DIR=/workspace/scratch/rct-validation/client_real_acceptance/actual-runs/RUN_ID/webkit-new14 \
  node --max-old-space-size=512 node_modules/playwright/cli.js test \
  --config /workspace/scratch/rct-validation/client_real_acceptance/actual-runs/client-runtime.config.ts --project=webkit
```

Сначала Chromiumexisting8, затем ChromiumNEW14; WebKit только после native readiness/resource admission и disposition конкретных Chromium failures. Не делать blanket rerun при FAIL: сохранить sanitized location/status и классифицировать fixture/infra/product cause. Релевантный исправленный case повторять с его positive control, не подгонять ожидания. Ни один PASS заранее не записывается; expected44 отдельных finite результатов — не новая whole-family готовность.

## Безопасное evidence

Оба lanes используют exact canonical SafeReporter и trace/video/screenshots off. Existing8 имеет собственный sanitizer; каждый из fiveNEW specs вызывает registerPrivateSuite один раз. Runtime guard before credentials проверяет exact reporter path, отсутствие debug/extra reporter и offflags. Existing production offline case alone permits serviceWorker; остальное inherited deterministic block. TMA shim only synthetic external host; server APIs remain real. Download HTML/identities/tickets/passwords remain in memory; test does not saveAs/attach body, successful download deletes ephemeral browser file; context teardown handles failed download lifetime.

Разрешённые SafeReporter fields: file basename, line, project, status, expectedStatus, durationMs, errorCount, errorLocations(file,line). Summary: status, runnerErrors, unsafeArtifact, suppressedStdoutBytes/suppressedStderrBytes, results. Сохранить exact native exit отдельно плюс UTC start/end, source/artifact/config SHA, project/lane, expected count8/14, actual counts/outcomes, viewport, public teaching instant, real security clock, readiness/grant reference и relevant case IDs from source-map. Никаких raw request/response bodies, titles/step arguments, bearer/cookies/initData/TGID/generated names/logins/passwords, export HTML/filename body, screenshots/traces/video/private ENV/key.

Native0 + statuspassed + exact8/14 passed/expectedpassed + errors0 + no skips/flaky + privacy flags/unsafeArtifact=false — квалификация только этих конечных cases при exact source/producer. Missing renderer/server/browser or failed launch before effect = BLOCKED_ENV/UNKNOWN criterion, не product PASS и не skip. Действительные expected403/401/409 — успешные negative oracle, если остальные durable/UI checks выполняются. Existing native privacy control may be reused by exact applicable source receipt; не повторять его без конкретного изменённого privacy risk. Контроль leak/error artifacts на actual output должен быть безопасным и сохранять only booleans/counts; unsafe raw files не публиковать.

После каждой phase Root получает safe-results/native exit/source qualification; все собственные процессы settled/reaped, stand ownership остаётся host owner. Root также отдельно принимает actual critical fault sensitivity/audit DB/fiveformat bytes/11families; source20 export counterexamples/date5 predicates/22finite browser cases этого не заменяют.
