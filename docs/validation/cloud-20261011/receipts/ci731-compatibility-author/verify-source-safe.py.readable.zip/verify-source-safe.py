"""AST/preservation controls for the exact CI731 source-only compatibility scope."""

import ast
import datetime
import hashlib
import json
import re
import subprocess
from pathlib import Path

ROOT = Path('/workspace/rct-worktrees/np01-domain-bot')
OUT = Path('/workspace/scratch/rct-validation/np01_domain_bot/ci731-compatibility')
scope = json.loads((OUT / 'scope-before.safe.json').read_text())
python = scope['paths'][2:]
equivalence = []
for path in python:
    before = ast.parse((OUT / 'before-source' / path).read_text())
    after = ast.parse((ROOT / path).read_text())
    def imports(module):
        return sorted(ast.dump(node, include_attributes=False) for node in module.body
                      if isinstance(node, (ast.Import, ast.ImportFrom)))
    def behavior(module):
        return ast.dump(ast.Module(body=[node for node in module.body
                                        if not isinstance(node, (ast.Import, ast.ImportFrom))],
                                   type_ignores=[]), include_attributes=False)
    assert imports(before) == imports(after), path
    assert behavior(before) == behavior(after), path
    equivalence.append({'path': path, 'same_import_multiset': True, 'same_nonimport_ast': True,
                        'before_sha256': hashlib.sha256((OUT / 'before-source' / path).read_bytes()).hexdigest(),
                        'after_sha256': hashlib.sha256((ROOT / path).read_bytes()).hexdigest()})
reset_path, auth_path = scope['paths'][1], scope['paths'][0]
reset = (ROOT / reset_path).read_text()
before_reset = (OUT / 'before-source' / reset_path).read_text()
assert reset.count('            "bot_credential_messages",\n') == 1
assert reset.replace('            "bot_credential_messages",\n', '', 1) == before_reset
auth = (ROOT / auth_path).read_text()
before_auth = (OUT / 'before-source' / auth_path).read_text()
first_start = auth.index('        assertThat(passwordChanged.path("event_version").asInt()).isEqualTo(2);')
first_end = auth.index('        assertThat(changedPayload.has("password")).isFalse();', first_start)
first_block = auth[first_start:first_end]
restored = auth[:first_start] + '        assertThat(changedPayload.size()).isEqualTo(1);\n' + auth[first_end:]
second_start = restored.index('        assertThat(storedEvent.path("event_version").asInt()).isEqualTo(2);')
second_end = restored.index('        assertThat(storedEvent.path("payload").path("telegram_id").asLong()).isEqualTo(TELEGRAM_ID);', second_start)
second_block = restored[second_start:second_end]
restored = restored[:second_start] + '        assertThat(storedEvent.path("payload").size()).isEqualTo(1);\n' + restored[second_end:]
assert restored == before_auth, 'Auth changes escaped the two approved expectation blocks'
expected_fields = {'user_id', 'credentials_version', 'telegram_binding_version', 'telegram_id'}
for block, prefix in [(first_block, 'changed'), (second_block, 'stored')]:
    fields = re.search(r'containsExactlyInAnyOrder\((.*?)\);', block, re.S)
    assert set(re.findall(r'"([a-z_]+)"', fields.group(1))) == expected_fields
    assert f'{prefix}Identity.get("id")' in block
    for field in ('credentials_version', 'telegram_binding_version', 'telegram_id'):
        assert f'{prefix}Identity.get("{field}")' in block
    assert block.count('.isPositive()') == 2
    assert 'FROM users WHERE login = \'student\'' in block
assert 'passwordChangedJson.contains(resetTicket)' in first_block
for item in scope['immutable_broker2']:
    assert hashlib.sha256((ROOT / item['path']).read_bytes()).hexdigest() == item['sha256']
for item in scope['immutable_seals']:
    assert hashlib.sha256(Path(item['path']).read_bytes()).hexdigest() == item['sha256']
source_proofs = []
for path in [
    'services/auth-service/auth-app/src/main/java/ru/rutcampustrack/auth/event/PasswordChangedEvent.java',
    'services/auth-service/auth-app/src/main/java/ru/rutcampustrack/auth/event/PasswordChangedOutbox.java',
    'services/auth-service/auth-app/src/main/java/ru/rutcampustrack/auth/session/jdbc/JdbcSessionAuthority.java',
    'services/auth-service/auth-app/src/test/java/ru/rutcampustrack/auth/events/PasswordChangedContractTest.java',
    'services/auth-service/auth-app/src/test/java/ru/rutcampustrack/auth/session/jdbc/JdbcSessionAuthorityIT.java',
    'event-schemas/password.changed.json',
]:
    original = subprocess.check_output(['git', 'show', 'aa713963941f10b32b00f1ca9cb7b7c369dd8947:' + path], cwd=ROOT)
    current = (ROOT / path).read_bytes()
    assert original == current, path
    source_proofs.append({'path': path, 'sha256': hashlib.sha256(current).hexdigest(), 'exact_frozen_aa713': True})
schema = json.loads((ROOT / 'event-schemas/password.changed.json').read_text())
v2 = next(branch for branch in schema['oneOf'] if branch['properties']['event_version']['const'] == 2)
assert set(v2['properties']['payload']['properties']) == expected_fields
assert v2['properties']['payload']['additionalProperties'] is False
receipt = {
    'utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'source_only': True,
    'python_ast_import_equivalence': equivalence,
    'AcademicFixtureResetListener_only_one_explicit_V57_table': True,
    'AuthOtpFlowIT_only_two_approved_expectation_blocks': True,
    'Auth_v2_exact_fields_values_current_DB_generations_recipient': True,
    'Auth_purpose_race_atomicity_revoke_brokerretry_history_rest_unchanged': True,
    'unchanged_producer_and_v1_schema_consumer_proof_inputs': source_proofs,
    'immutable_broker2_and20_65_seals': True,
    'Java_compile_tests_Docker_network_broker': 'NOT_RUN',
    'prior_finite_proof_disposition': 'DOMAIN1 historical13unit/22PG/71Python PASS preserved. Six listed producer/contract proof sources exactaa713; four Python bodies/importmultisets equivalent. New AuthOtp assertions/reset fixture have NOT_RUN runtime, require full current suites; source/AST equivalence is not a new runtime receipt.',
}
(OUT / 'source-guards-and-finite-proof-disposition.safe.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps({'python_ast_equivalent': 4, 'exact_Auth_two_blocks': True, 'exact_reset_one_entry': True,
                  'producer_and_legacy_proof_sources_exact': len(source_proofs), 'broker2_seals_exact': True,
                  'runtime': 'NOT_RUN'}))
