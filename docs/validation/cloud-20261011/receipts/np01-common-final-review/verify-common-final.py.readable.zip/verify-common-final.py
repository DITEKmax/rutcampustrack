import ast
import hashlib
import json
import pathlib
import re
import subprocess
import xml.etree.ElementTree as ET
import zipfile

from google.protobuf import descriptor_pb2, descriptor_pool

OUT = pathlib.Path('/workspace/scratch/rct-validation/np01_common_review')
AUTHOR = pathlib.Path('/workspace/scratch/rct-validation/np01_contract')
WT = pathlib.Path('/workspace/rct-worktrees/np01-contract')
PRODUCER = '6830731ca81cc03a546ae7a98e0ddfc89605c8c4'
FINAL = '28ed54bba56dc3fb2cdacffdcd56b0e102958087'
BASE = '2bca095380f72e8908a2511f2b10f0e795607f05'
OUTPUTS = ['services/notification-bot/bot/grpc_client/academic_pb2.py',
           'services/notification-bot/bot/grpc_client/academic_pb2_grpc.py']

def git(*args):
    return subprocess.check_output(['git', '-C', str(WT), *args])

def tree(revision):
    return {line.split('\t')[1]: line.split('\t')[0]
            for line in git('ls-tree', '-r', revision).decode().splitlines()}

def public_descriptor(revision):
    source = git('show', revision + ':' + OUTPUTS[0])
    serialized = next(ast.literal_eval(n.args[0]) for n in ast.walk(ast.parse(source.decode()))
                      if isinstance(n, ast.Call) and isinstance(n.func, ast.Attribute)
                      and n.func.attr == 'AddSerializedFile')
    return descriptor_pb2.FileDescriptorProto.FromString(serialized)

def effective_json_names(descriptor):
    # Native descriptor_set explicitly encodes default json_name fields; Python
    # generated descriptors omit them. Compare their effective reflected names,
    # preserving explicit/custom names and every other descriptor field.
    normalized = descriptor_pb2.FileDescriptorProto()
    normalized.CopyFrom(descriptor)
    pool = descriptor_pool.DescriptorPool()
    pool.Add(descriptor)
    def visit(message, prefix):
        full_name = prefix + '.' + message.name
        reflected = pool.FindMessageTypeByName(full_name)
        for field in message.field:
            field.json_name = reflected.fields_by_name[field.name].json_name
        for child in message.nested_type:
            visit(child, full_name)
    for message in normalized.message_type:
        visit(message, normalized.package)
    normalized.ClearField('source_code_info')
    return normalized.SerializeToString(deterministic=True)

a, b = tree(PRODUCER), tree(FINAL)
changed = sorted(p for p in set(a) | set(b) if a.get(p) != b.get(p))
assert changed == OUTPUTS and len(a) == len(b) == 7032
bridge = json.loads((AUTHOR / 'final-source-bridge.safe.json').read_text())
inventory = []
for entry in bridge['final_owned_paths']:
    data = git('show', FINAL + ':' + entry['path'])
    assert len(data) == entry['bytes'] and hashlib.sha256(data).hexdigest() == entry['sha256']
    inventory.append({k: entry[k] for k in ['path', 'sha256', 'bytes']})
for path in OUTPUTS:
    data = git('show', FINAL + ':' + path)
    assert data == (AUTHOR / 'python-reproduction' / pathlib.Path(path).name).read_bytes()
    assert data == pathlib.Path('/workspace/scratch/rct-validation/np01_config/generation-prep/academic-output-1', pathlib.Path(path).name).read_bytes()

def native_descriptor(name):
    parsed = descriptor_pb2.FileDescriptorSet.FromString((AUTHOR / name).read_bytes())
    assert len(parsed.file) == 1
    return parsed.file[0]

old = native_descriptor('baseline-academic.descriptor')
new = native_descriptor('current-academic.descriptor')
old_python = public_descriptor(BASE)
legacy_python_shape = descriptor_pb2.FileDescriptorProto()
legacy_python_shape.CopyFrom(old)
subject = next(m for m in legacy_python_shape.message_type if m.name == 'SubjectInfo')
extras = [(f.name, f.number, f.type) for f in subject.field if f.number in (4, 5)]
assert extras == [('group_id', 4, 3), ('lesson_types', 5, 9)]
kept = [f for f in subject.field if f.number not in (4, 5)]
del subject.field[:]
subject.field.extend(kept)
assert effective_json_names(legacy_python_shape) == effective_json_names(old_python)
assert effective_json_names(new) == effective_json_names(public_descriptor(FINAL))
messages = {m.name for m in new.message_type} - {m.name for m in old.message_type}
enums = {e.name for e in new.enum_type} - {e.name for e in old.enum_type}
assert len(messages) == 9 and len(enums) == 6
stripped = descriptor_pb2.FileDescriptorProto()
stripped.CopyFrom(new)
kept = [m for m in stripped.message_type if m.name not in messages]
del stripped.message_type[:]
stripped.message_type.extend(kept)
kept = [e for e in stripped.enum_type if e.name not in enums]
del stripped.enum_type[:]
stripped.enum_type.extend(kept)
for service in stripped.service:
    if service.name == 'AcademicGrpcService':
        methods = {'GetOwnBotInitialCredentials', 'ManageOwnBotCredentialMessages'}
        assert methods.issubset({m.name for m in service.method})
        kept = [m for m in service.method if m.name not in methods]
        del service.method[:]
        service.method.extend(kept)
stripped.ClearField('source_code_info')
old.ClearField('source_code_info')
assert stripped.SerializeToString(deterministic=True) == old.SerializeToString(deterministic=True)

runtime = []
for name in ['bad-identity', 'restored-green4']:
    directory = AUTHOR / 'runtime' / name
    summary = json.loads((directory / 'summary.safe.json').read_text())
    cases = []
    for entry in summary['native_xml']:
        data = (directory / entry['file']).read_bytes()
        assert len(data) == entry['bytes'] and hashlib.sha256(data).hexdigest() == entry['sha256']
        root = ET.fromstring(data)
        assert {k: int(root.attrib[k]) for k in ['tests', 'failures', 'errors', 'skipped']} == summary['counts']
        for case in root.findall('testcase'):
            assert case.find('error') is None and case.find('skipped') is None
            failure = case.find('failure')
            if name == 'bad-identity':
                assert failure is not None and failure.attrib['type'] == 'java.lang.AssertionError'
                text = failure.attrib.get('message', '') + '\n' + (failure.text or '')
                assert 'Expecting code to raise a throwable' in text
                assert sorted({int(x) for x in re.findall(r'BotCredentialLifecycleMigrationIT.java:(\d+)', text)}) == [318]
            else:
                assert failure is None
            cases.append(case.attrib['name'])
    assert sorted(cases) == sorted(e['case'] for e in summary['cases'])
    expected = {'tests': 1, 'failures': 1, 'errors': 0, 'skipped': 0} if name == 'bad-identity' else {'tests': 4, 'failures': 0, 'errors': 0, 'skipped': 0}
    assert summary['counts'] == expected and summary['native_exit_code'] == (1 if name == 'bad-identity' else 0)
    runtime.append({k: summary[k] for k in ['name', 'source_commit', 'native_session_id', 'native_exit_code', 'counts']})
    if name == 'restored-green4':
        previous = json.loads((OUT / 'runtime-three-faults-recheck.safe.json').read_text())
        assert set(cases) == {x['method'] for x in previous['completed_faults']} | {'identityAttemptCasAndTerminalReceiptsCannotBeRewritten()'}

archive = AUTHOR / 'common-final-safe-evidence.zip'
data = archive.read_bytes()
digest = hashlib.sha256(data).hexdigest()
assert digest == 'cfe34f4955ca07a13b7f0bd13aec03a0f1f441412cb8b38b1d073a73ee699083'
members = []
with zipfile.ZipFile(archive) as z:
    assert len(z.infolist()) == 27
    for entry in z.infolist():
        assert not entry.filename.startswith('/') and '..' not in pathlib.PurePosixPath(entry.filename).parts
        content = z.read(entry)
        if entry.filename.endswith('.json'):
            json.loads(content)
        elif entry.filename.endswith('.ndjson'):
            for line in content.decode().splitlines():
                json.loads(line)
        else:
            assert entry.filename == 'CURRENT.md'
        members.append({'path': entry.filename, 'bytes': len(content), 'sha256': hashlib.sha256(content).hexdigest()})
terminal = json.loads((AUTHOR / 'terminal-summary.safe.json').read_text())
result = {'status': 'PASS_FINAL_COMMON_RECEIPT_AND_GENERATED_BRIDGE_RECHECK',
          'final_commit': FINAL, 'actual_DB_compile_producer': PRODUCER,
          'changed_since_producer': changed, 'unchanged_other_git_paths': 7030,
          'final_source_inventory': inventory,
          'canonical2bca_preserves_all_actual_old_Python_schema_except_additive_prior_canonical_SubjectInfo_fields': extras,
          'actual_old_Python_qualification': 'Tracked2bca Python SubjectInfo lacked already-canonical group_id4/lesson_types5. Normal28ed regeneration includes these additive existing canonical fields; all old fields/numbers/types and other descriptor structure preserved.',
          'current_descriptor_matches_actual_28ed_generated_effective_schema': True,
          'native_descriptor_representation_qualification': 'Native descriptor_set explicitly encodes308 default json_name fields; Python generated descriptor omits them. Effective JSON names verified via reflection; no other normalization.',
          'subtract_9_messages_6_enums_2_RPCs_leaves_old_native_descriptor_byte_identical': True,
          'Python_outputs_match_normal_reproduction_and_reviewed84d_prep': True,
          'remaining_native_runtime': runtime,
          'identity_fault_qualification': 'Intended missing rejection at source318; SQL returned normally, no separately queried poststate claim',
          'restored_same_four_accepted_methods': True,
          'author_wire_cases': json.loads((AUTHOR / 'descriptor-wire-checks.safe.json').read_text())['legacy_roundtrip_cases'],
          'author_import_proof': json.loads((AUTHOR / 'python-import-checks.safe.json').read_text()),
          'sealed_author_metadata_zip': {'sha256': digest, 'bytes': len(data), 'members': members},
          'resource_release_author_receipt': terminal['resource_release'], 'reviewer_heavy_reruns': 0,
          'limits': ['17DB and4restored tests ran at683, not28ed; final twoPython inputs checked separately.',
                     'No actual TLS/live grants/production Auth/bot/provider or hostedCI acceptance.',
                     'Unknown protobuf enums parse as integers; domain rejection separate.',
                     'Per-file generator replacement only; final committed pair is coherent.']}
(OUT / 'common-final-independent-check.safe.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({'status': result['status'], 'final': FINAL, 'identity_native': 76358,
                  'restored_native': 23469, 'old_native_descriptor_exact': True,
                  'tracked_bridge': '2changed/7030unchanged', 'sealed_metadata_members': 27}))
