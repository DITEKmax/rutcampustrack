"""Only selected eight-key loop with synthetic mapping, plus exact Source checks."""
import ast
import hashlib
import json
from pathlib import Path
from types import SimpleNamespace

HERE = Path(__file__).resolve().parent
NEW = Path('/workspace/scratch/rct-validation/client_session_offline_acceptance/p10-current1742-failure-frame-source-network-r1')
OLD = NEW.with_name('p10-current1742-failure-frame-source-operation-r2')
text = (NEW / 'run-green-owned.py').read_text()
tree = ast.parse(text)
loop = next(n for n in tree.body if isinstance(n, ast.For) and isinstance(n.target, ast.Name) and n.target.id == 'network_context_key')
allowed = ('HTTP_PROXY', 'HTTPS_PROXY', 'NO_PROXY', 'http_proxy', 'https_proxy', 'no_proxy', 'SSL_CERT_FILE', 'SSL_CERT_DIR')
assert tuple(n.value for n in loop.iter.elts) == allowed
code = compile(ast.Module(body=[loop], type_ignores=[]), '<approved-loop-exact-AST>', 'exec')
baseline = {'PATH': '/RAM/bin', 'LANG': 'C.UTF-8', 'TMPDIR': '/RAM/private', 'TZ': 'UTC'}
class PrivateContext:
    def __init__(self, data):
        self.data, self.lookups = data, []
    def get(self, key):
        assert key in allowed
        self.lookups.append(key)
        return self.data.get(key)
    def __iter__(self):
        raise AssertionError('FULL_ENV_ITERATION')
    def keys(self):
        raise AssertionError('FULL_ENV_KEYS')
    def items(self):
        raise AssertionError('FULL_ENV_ITEMS')
    def __str__(self):
        raise AssertionError('ENV_RENDERING')
    def __repr__(self):
        raise AssertionError('ENV_RENDERING')

def run(data):
    context = PrivateContext(data)
    ns = {'environment': dict(baseline), 'os': SimpleNamespace(environ=context)}
    exec(code, ns)
    assert context.lookups == list(allowed)
    return ns['environment']

canary = 'RAM_PRIVATE_NETWORK_CONTEXT'
synthetic = {key: canary + key for key in allowed}
synthetic.update({key: canary for key in ['HOME', 'AUTH_TOKEN', 'ALL_PROXY', 'all_proxy', 'REQUESTS_CA_BUNDLE', 'CURL_CA_BUNDLE', 'UNKNOWN_PROXY', 'PATH', 'LANG']})
result = run(synthetic)
checks = {
    'exact8_string_values_preserved': all(result[key] == synthetic[key] for key in allowed),
    'unknown_HOME_auth_allENV_alternateclient_keys_absent': set(result) == set(baseline) | set(allowed),
    'baseline_PATH_LANG_TMPDIR_TZ_not_overwritten': all(result[key] == value for key, value in baseline.items()),
    'empty_context_no_invention': run({}) == baseline,
    'sparse_lowercase_CA_only': run({'https_proxy': canary, 'SSL_CERT_DIR': canary}) == {**baseline, 'https_proxy': canary, 'SSL_CERT_DIR': canary},
    'empty_existing_strings_preserved_without_coercion': run({key: '' for key in allowed}) == {**baseline, **{key: '' for key in allowed}},
    'case_variants_preserved_independently': run({'HTTP_PROXY': 'RAM_UPPER', 'http_proxy': 'RAM_LOWER'}) == {**baseline, 'HTTP_PROXY': 'RAM_UPPER', 'http_proxy': 'RAM_LOWER'},
    'get_only_fixed_keys_no_iteration_render_hash_or_output': True,
}
pins = {}
source_manifest = json.loads((NEW / 'manifest.safe.json').read_text())
for name, sha in source_manifest['files'].items():
    pins['seal_' + name] = hashlib.sha256((NEW / name).read_bytes()).hexdigest() == sha
lines = text.splitlines(keepends=True)
assert lines[loop.lineno - 2].strip() == '# Keep only the approved normal urllib proxy/CA context private in the child environment.'
del lines[loop.lineno - 2:loop.end_lineno]
pins['parent_inverse_only_loop_comment'] = ''.join(lines) == (OLD / 'run-green-owned.py').read_text()
pins['old_parent_c5af'] = hashlib.sha256((OLD / 'run-green-owned.py').read_bytes()).hexdigest() == 'c5afaa7d6fd4bb6fe98a609d19694e66f9819a560df5beb9afdbf8d51e7d563a'
pins['new_parent461134'] = hashlib.sha256((NEW / 'run-green-owned.py').read_bytes()).hexdigest() == '4611344f9af8a48b0e695545c4053994c1f72591929553b3336df4e2a8d311c9'
pins['child94e957_identical'] = (NEW / 'logged-green-child.py').read_bytes() == (OLD / 'logged-green-child.py').read_bytes() and hashlib.sha256((NEW / 'logged-green-child.py').read_bytes()).hexdigest() == '94e957778be9f03cbe6ec4320aae64050d9764a15e6a8c0f72006c3eb2e5cac7'
pins['metadata_manifest_admission_exact'] = all((NEW / n).read_bytes() == (OLD / n).read_bytes() for n in ['metadata.safe.json', 'source-manifest.safe.json', 'admission-reused.py.source'])
pins['caps_exact'] = json.loads((NEW / 'grant-template.private.json').read_text())['limits'] == json.loads((OLD / 'grant-template.private.json').read_text())['limits']
plan = json.loads((NEW / 'green-plan.safe.json').read_text())
manifest = json.loads((NEW / 'source-manifest.safe.json').read_text())
wt = Path(plan['worktree'])
pins['18_public_inputs'] = all(hashlib.sha256((wt / n).read_bytes()).hexdigest() == sha for n, sha in {**manifest['files'], **manifest['protected_files']}.items())
guard = Path(plan['guard_path']).read_text()
pins['b78_exact'] = hashlib.sha256(guard.encode()).hexdigest() == plan['guard_sha256']
pins['b78_requires_str_values_before_spawn'] = "type(env) is not dict or not all(type(k) is str and type(v) is str for k, v in env.items())" in guard
grant = json.loads((NEW / 'grant-template.private.json').read_text())
pins['false_grant'] = all(grant[key] is False for key in ['authorized', 'source_review_approved', 'original_artifact_observation_authorized'])
pins['manifest_exact'] = hashlib.sha256((NEW / 'manifest.safe.json').read_bytes()).hexdigest() == 'abf5a431f27cdab759248557f120caaef4ac9ff2cd9c8d84a3954f6da0a43c5f'
assert all(checks.values()) and all(pins.values()), {k: v for k, v in {**checks, **pins}.items() if not v}
out = {'schema': 'P10_NETWORK_R1_NARROW_INDEPENDENT_LOOP_REVIEW_V1', 'verdict': 'APPROVE_SOURCE',
    'synthetic8_controls': checks, 'source_pins': pins, 'approved_public_keys': list(allowed),
    'unchanged19_8_15_13_17plus6': 'REUSED_NOT_RERUN', 'native': 'NOT_RUN', 'actual03_nestedreason_and_P10_cause': 'UNKNOWN',
    'privacy': 'No actual environment lookup; no real/synthetic values, presence maps or value digests exported',
    'effects': 'Public Source + selected loop AST/private synthetic mapping only; no network/native/URL/API/XML/log/test/Source edits/children/B013'}
assert canary not in json.dumps(out) and 'RAM_UPPER' not in json.dumps(out) and 'RAM_LOWER' not in json.dumps(out)
(HERE / 'controls.safe.json').write_text(json.dumps(out, indent=2) + '\n')
print(json.dumps({'verdict': 'APPROVE_SOURCE', 'synthetic_controls': len(checks), 'source_pins': 'PASS', 'actual_environment_read': False, 'native': 'NOT_RUN'}))
