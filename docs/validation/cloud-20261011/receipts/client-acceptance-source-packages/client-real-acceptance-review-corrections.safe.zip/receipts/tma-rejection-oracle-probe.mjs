import fs from 'node:fs'
import crypto from 'node:crypto'
import vm from 'node:vm'
import { createRequire } from 'node:module'
const require = createRequire(import.meta.url)
const ts = require('/workspace/rutcampustrack/frontends/node_modules/typescript')
const sourcePath = '/workspace/rct-worktrees/client-real-acceptance/tests/e2e/specs/cloud-accepted-tma-proof.spec.ts'
const text = fs.readFileSync(sourcePath, 'utf8')
const source = ts.createSourceFile(sourcePath, text, ts.ScriptTarget.Latest, true)
const samples = source.statements.find((statement) => ts.isVariableStatement(statement) && statement.declarationList.declarations.some((node) => node.name.getText(source) === 'invalidDates'))
if (!samples) throw new Error('Finite TMA samples absent')
const sampleContext = { exports: {} }
vm.runInNewContext(ts.transpileModule(samples.getText(source), { compilerOptions: { target: ts.ScriptTarget.ES2022 } }).outputText + '\nexports.samples=invalidDates', sampleContext, { timeout: 1000 })
const expressions = []
function visit(node) {
  if (ts.isCallExpression(node) && ts.isPropertyAccessExpression(node.expression) && node.expression.name.text === 'toBe' && node.arguments[0]?.getText(source) === 'true') {
    const call = node.expression.expression
    if (ts.isCallExpression(call) && call.expression.getText(source) === 'expect' && call.arguments[0]?.getText(source).includes('problem.')) expressions.push(call.arguments[0].getText(source))
  }
  ts.forEachChild(node, visit)
}
visit(source)
if (expressions.length !== 2 || sampleContext.exports.samples.length !== 5) throw new Error('Unexpected TMA problem oracle inventory')
const cases = []
for (let index=0; index < sampleContext.exports.samples.length; index++) {
  const sample=sampleContext.exports.samples[index]
  const evaluate = (problem) => expressions.map((expression) => vm.runInNewContext(expression, { problem, sample }, { timeout: 1000 }))
  const positive=evaluate({ type:'https://controlled.invalid/problems/tma-validation-failed', detail:sample.detail })
  const hashGuard=evaluate({ type:'https://controlled.invalid/problems/tma-validation-failed', detail:'Invalid or tampered initData' })
  const unrelated=evaluate({ type:'https://controlled.invalid/problems/invalid-credentials', detail:sample.detail })
  if (!positive.every(Boolean) || hashGuard[1] !== false || unrelated[0] !== false) throw new Error('TMA branch-oracle control failed')
  cases.push({ slice:index, accepted_date_rejection_matches:true, same_status_wrong_hash_guard_rejected:true, same_status_unrelated_problem_rejected:true })
}
const receipt = { kind:'NATIVE_NEW_TEST_RESPONSE_ORACLE_CONTROL', source_path:sourcePath, source_sha256:crypto.createHash('sha256').update(text).digest('hex'), timestamp:new Date().toISOString(), actual_expressions_extracted_from_current_new_spec:true, finite_slices:5, cases, positive_same_target_browser_admission:'SOURCE_PRESENT_RUNTIME_NOT_RUN', prepared_signer_alignment:'ROOT_STAND_V4_PREREQUISITE', no_init_data_or_cookies_or_credentials_or_personal_data_persisted:true, backend_browser_runtime:'NOT_RUN', limits:{ node_heap_mib:1024, child_processes:false, network:false } }
fs.writeFileSync('/workspace/scratch/rct-validation/client_real_acceptance/TMA-date-branch.controls.safe.json', JSON.stringify(receipt,null,2)+'\n')
process.stdout.write(JSON.stringify({finite_slices:5, matching_problem_controls:5, wrong_hash_guard_rejections:5, unrelated_problem_rejections:5, browser_runtime:'NOT_RUN'})+'\n')
