#!/usr/bin/env python3
"""One ordinary bounded child. Preparation only; requires a separate sealed grant.

No daemon, scheduler, service manager, raw application output, or response body.
Use one invocation per manually selected host service. Java retains direct parent.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import signal
import subprocess
import time
import urllib.error
import urllib.request

OWN = Path('/workspace/scratch/rct-validation/host_runtime_prepare')
FLOOR = 4 * 1024**3
SERVICES = {'auth', 'academic', 'schedule', 'attendance', 'bff', 'gateway', 'notification'}


class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, request, fp, code, msg, headers, newurl):
        return None


def interrupted(signum, frame):
    raise KeyboardInterrupt


def digest(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def owned(path):
    path = Path(path)
    if not path.is_absolute() or not path.is_relative_to(OWN):
        raise ValueError('path')
    for entry in [path, *path.parents]:
        if entry.is_symlink():
            raise ValueError('symlink')
        if entry == OWN:
            break
    return path


def free():
    value = os.statvfs(OWN)
    return value.f_bavail * value.f_frsize


def emit(state, service, **fields):
    print(json.dumps({'state': state, 'service': service, **fields}), flush=True)


def run(spec_path, grant_path):
    spec_path, grant_path = owned(spec_path), owned(grant_path)
    spec = json.loads(spec_path.read_text())
    grant = json.loads(grant_path.read_text())
    service = spec['service']
    if service not in SERVICES or not all(grant.get(key) is True for key in
                                         ['app_launch_authorized', 'source_frozen',
                                          'tls_and_routes_reviewed', 'floor_reviewed']):
        raise ValueError('grant')
    if not re.fullmatch('[0-9a-f]{40}', grant.get('product_revision', '')):
        raise ValueError('revision')
    if grant.get('runner_sha256') != digest(Path(__file__)) or grant.get('spec_sha256') != digest(spec_path):
        raise ValueError('identity')
    cwd = owned(spec['cwd']).resolve(strict=True)
    argv = spec['argv']
    if not isinstance(argv, list) or not argv or argv[0] != '/usr/lib/jvm/java-21-openjdk-amd64/bin/java':
        raise ValueError('executable')
    if any(not isinstance(value, str) or re.search('(?i)(password|token|secret)=', value) for value in argv):
        raise ValueError('argv')
    if digest(Path(argv[0])) != grant['java_sha256']:
        raise ValueError('java')
    if not grant['artifacts']:
        raise ValueError('artifacts')
    for artifact in grant['artifacts']:
        path = owned(artifact['path'])
        if path.suffix == '.key' or '/private/' in str(path) or '/tls/' in str(path):
            raise ValueError('artifact-path')
        if digest(path) != artifact['sha256']:
            raise ValueError('artifact')
    env_path = owned(spec['private_environment_file'])
    if env_path.stat().st_uid != os.getuid() or env_path.stat().st_mode & 0o077:
        raise ValueError('private-env-mode')
    env = os.environ.copy()
    env.update(json.loads(env_path.read_text()))
    env.update(spec['public_environment'])
    # Local readiness bypasses the outbound HTTP proxy; no external URL allowed.
    url = spec['readiness_url']
    if not re.fullmatch(r'http://(127\.0\.0\.1|172\.29\.84\.1):[0-9]+/actuator/health/liveness', url):
        raise ValueError('readiness')
    duration = spec.get('duration_seconds', 600)
    if not isinstance(duration, int) or not 10 <= duration <= 1800:
        raise ValueError('duration')
    rss_stop = spec['rss_stop_bytes']
    if not isinstance(rss_stop, int) or not 256 * 1024**2 <= rss_stop <= 2 * 1024**3:
        raise ValueError('rss-stop')
    if free() < FLOOR:
        raise ValueError('floor')
    opener = urllib.request.build_opener(urllib.request.ProxyHandler({}), NoRedirect())
    start = time.monotonic()
    child = None
    polls = ready = 0
    stop = 'DEADLINE'
    try:
        child = subprocess.Popen(argv, cwd=cwd, env=env, stdin=subprocess.DEVNULL,
                                 stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        emit('STARTED', service, pid=child.pid)
        while time.monotonic() - start < duration:
            if child.poll() is not None:
                stop = 'CHILD_EXIT'
                break
            if free() < FLOOR:
                stop = 'DISK_FLOOR'
                break
            try:
                status = Path('/proc/' + str(child.pid) + '/status').read_text()
                rss = int(re.search(r'^VmRSS:\s+(\d+) kB$', status, re.MULTILINE)[1]) * 1024
                if rss > rss_stop:
                    stop = 'RSS_SOFT_STOP'
                    break
                cgroup = Path('/sys/fs/cgroup')
                maximum = (cgroup / 'memory.max').read_text().strip()
                current = int((cgroup / 'memory.current').read_text().strip())
                if maximum != 'max' and current > int(maximum) - 1024**3:
                    stop = 'SHARED_MEMORY_RESERVE'
                    break
            except (OSError, ValueError, TypeError):
                stop = 'RESOURCE_OBSERVATION_UNAVAILABLE'
                break
            polls += 1
            try:
                with opener.open(url, timeout=2) as response:
                    code = response.status  # Deliberately never read/log the body.
            except urllib.error.HTTPError as error:
                code = error.code
                error.close()
            except (OSError, ValueError):
                code = 0
            if code == 200 and not ready:
                ready = 1
                emit('LIVENESS_HTTP_200', service, pid=child.pid)
            time.sleep(2)
    finally:
        if child is not None:
            if child.poll() is None:
                child.terminate()
                try:
                    child.wait(timeout=20)
                except subprocess.TimeoutExpired:
                    child.kill()
                    child.wait(timeout=10)
            emit('TERMINAL', service, pid=child.pid, exit=child.returncode,
                 reason=stop, polls=polls, liveness_http_200=bool(ready),
                 elapsed_seconds=round(time.monotonic() - start, 2))


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--spec', required=True)
    parser.add_argument('--grant', required=True)
    arguments = parser.parse_args()
    signal.signal(signal.SIGTERM, interrupted)
    try:
        run(arguments.spec, arguments.grant)
    except KeyboardInterrupt:
        print('{"state":"INTERRUPTED_CHILD_SETTLED"}', flush=True)
        raise SystemExit(130)
    except (OSError, ValueError, KeyError, TypeError, subprocess.SubprocessError):
        # Exception text may contain environment/request content. Never emit it.
        print('{"state":"BLOCKED_SAFE_VALIDATION_OR_RUNTIME_FAILURE"}', flush=True)
        raise SystemExit(2)
