"""Only closed identifier candidates; no log/body input."""
import hashlib,json,re,subprocess,sys
from pathlib import Path
d=json.loads(sys.argv[1])
head='96c7aee0a114e978ce3ed2976127a2a59c1a69e3'
base=['git','-C','/workspace/rutcampustrack']
env={'PATH':'/usr/bin:/bin','LANG':'C.UTF-8','GIT_OPTIONAL_LOCKS':'0'}
def git(args):return subprocess.run(base+args,env=env,capture_output=True,check=True).stdout
paths=git(['ls-tree','-r','--name-only',head,'services/schedule-service']).decode().splitlines()
simple=d['classname'].split('.')[-1]
outer=simple.split('$')[0]
found=[p for p in paths if p.endswith('/'+outer+'.java') and '/src/test/' in p]
if len(found)!=1:
    print(json.dumps({'status':'SOURCE_IDENTITY_UNQUALIFIED','path_match_count':len(found)}));raise SystemExit(1)
body=git(['show',head+':'+found[0]])
if not re.search(rb'\bvoid\s+'+re.escape(d['method'].encode())+rb'\s*\(',body):
    print(json.dumps({'status':'SOURCE_METHOD_UNQUALIFIED'}));raise SystemExit(1)
first=None;frameSHA=None
for f in d['frames']:
    matches=[p for p in paths if p.endswith('/'+f['filename']) and '/src/' in p]
    if len(matches)==1:
        b=git(['show',head+':'+matches[0]])
        if 1<=f['line']<=len(b.splitlines()):
            first={'path':matches[0],'line':f['line'],'filename':f['filename']}
            frameSHA=hashlib.sha256(b).hexdigest();break
result={'status':'SOURCE_IDENTITY_QUALIFIED','producer':head,'sourceDeclaredClass':simple,'sourceDeclaredMethod':d['method'],
    'source':found[0],'sourceSHA256':hashlib.sha256(body).hexdigest(),'firstSourceKnownFrame':first,'frameSourceSHA256':frameSHA}
print(json.dumps(result))
