SOURCE-ready companion for independent Root review; not approved for use.

Only the nine T009 reported diagnostic enums are added to the strict validator: six serialized-class codes and three public dataset-frame codes. Each requires existing exact keys `stage`, `cause`, `httpStatus`, with `UNKNOWN` and integer0. Unknown code/field/stage/status, duplicates, multiple class/frame category entries, more than8 diagnostics, invalid fallback and duplicate JSON keys fail closed. Core15,14 HTTP values, existing case/result fields, optional absence and producer metadata interface remain unchanged.

These reported hints are untrusted text matches, not class/source/cause/operation authentication. The collector validates; it cannot repair producer core-cap eviction. That author correction needs its separate independent review and actual controls.

Old current481/source-preparation manifests and archives remain immutable. Existing Java/browser SAFE archive readers are unchanged; this companion preserves their Python interface. No remote collection, raw artifact/log/XML, Node or product runtime was performed. Original b78 ownership helper was not modified or executed.

All three future source pins are deliberately UNBOUND. `load_binding` rejects use even if an old current481 binding is supplied. After independent review and final producer integration/actual push, bind only the existing three source constants to the verified reviewed integration SHA and exact two fixture SHA256 values, retain the parameter delta and normal run metadata. Reuse the existing exact8-key actual binding; do not add a new artifact/schema/framework. No new credentials, private values or network permissions are introduced.
