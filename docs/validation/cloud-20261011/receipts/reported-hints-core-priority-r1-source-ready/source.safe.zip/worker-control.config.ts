import { defineConfig } from '/workspace/rct-worktrees/client-ci-first3/tests/e2e/node_modules/@playwright/test';
process.env.PLAYWRIGHT_NO_COPY_PROMPT = '1';
export default defineConfig({
  testDir: '/workspace/scratch/rct-validation/client_real_acceptance/ci-reported-hints-core-priority-r1/controls',
  testMatch: 'reported-hints.control.spec.ts',
  outputDir: process.env.RCT_SAFE_FAILURE_CONTROL_OUTPUT,
  reporter: [['/workspace/rct-worktrees/client-ci-first3/tests/e2e/fixtures/safe-reporter.ts']],
  workers: 1, retries: 0, timeout: 10000, forbidOnly: true,
  use: { trace: 'off', video: 'off', screenshot: 'off' },
});
