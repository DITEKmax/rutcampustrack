"""Provided Node-only delta; metadata/hash/X_OK, never execute the binary."""
import ast
import copy
import hashlib
import json
import os
from pathlib import Path
import stat
import zipfile

OWN=Path(__file__).parent
BASE=OWN.parent/'client_real_acceptance'
NEW=BASE/'webkit-public-boot-r2'
OLD=BASE/'webkit-public-boot-r1'
def sha(p):
    h=hashlib.sha256()
    with p.open('rb') as f:
        for b in iter(lambda:f.read(1048576),b''):h.update(b)
    return h.hexdigest()
def dump(node):return ast.dump(node,include_attributes=False)
assert sha(NEW/'READY.safe.json')=='157fcf615e954c9bd7efd11f125ddc5721c04e9fe107a5b45681aa1851f64c44'
assert sha(NEW/'run-probe.py')=='9db59ed47a6caef42d462f0c5c3bda3e47b0fb093c0992c50be179443452cca6'
assert sha(NEW/'source.safe.zip')=='98f1eda4c4dc66e864961d53459c14d8e5cc87de2b05dab7aaccdc5c62ecf58c'
manifest=json.loads((NEW/'manifest.safe.json').read_text());expected={}
for row in manifest['files']:
    p=NEW/row['path'];s=p.lstat()
    assert p.parent==NEW and stat.S_ISREG(s.st_mode) and s.st_nlink==row['nlink']==1
    assert s.st_size==row['bytes'] and stat.S_IMODE(s.st_mode)==int(row['mode'],0) and sha(p)==row['sha256']
    expected[row['path']]=row['sha256']
expected['manifest.safe.json']=sha(NEW/'manifest.safe.json')
with zipfile.ZipFile(NEW/'source.safe.zip') as z:
    assert len(z.infolist())==10 and z.testzip() is None and set(z.namelist())==set(expected)
    for name in z.namelist():assert hashlib.sha256(z.read(name)).hexdigest()==expected[name]
for name in ['probe.cjs','launch-cause.cjs','check-use-time.py']:
    assert (NEW/name).read_bytes()==(OLD/name).read_bytes()
assert sha(OLD/'READY.safe.json')=='8aae65d1ceb1fd0c6fa6cc8d43932aea6dec021f493abcfbc76722538bd5dc6f'
assert sha(OLD/'source.safe.zip')=='f33a52b5c085767025972aa2173785a5eefe3ede80231933399a6dbf2fbaafcd'
assert sha(OWN.parent/'webkit_public_boot_recheck/manifest.json')=='43d69de48cd63691ba84802d33f7f9f4eedfd416794fa01d4a8d6566333bbc65'
node_path='/opt/codex/runtimes/codex-primary-runtime/dependencies/node/bin/node'
oldtree=ast.parse((OLD/'run-probe.py').read_text());newtree=ast.parse((NEW/'run-probe.py').read_text())
normalized=copy.deepcopy(newtree)
base=next(n for n in normalized.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='BASE' for t in n.targets))
assert dump(base.value)==dump(ast.parse("Path('/workspace/scratch/rct-validation/client_real_acceptance/webkit-public-boot-r2')",mode='eval').body)
base.value=ast.parse("Path('/workspace/scratch/rct-validation/client_real_acceptance/webkit-public-boot-r1')",mode='eval').body
node=next(n for n in normalized.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='NODE' for t in n.targets))
assert dump(node.value)==dump(ast.parse('Path('+repr(node_path)+')',mode='eval').body)
normalized.body.remove(node)
main=next(n for n in normalized.body if isinstance(n,ast.FunctionDef) and n.name=='main')
pos=next(i for i,n in enumerate(main.body) if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='node_identity' for t in n.targets))
selected=main.body[pos:pos+4]
canonical=ast.parse("""node_identity = own_ready['provided_node_binary']
node_metadata = NODE.lstat()
require(str(NODE) == node_identity['path'] and stat.S_ISREG(node_metadata.st_mode)
        and not NODE.is_symlink() and os.access(NODE, os.X_OK), 'PROVIDED_NODE_UNREACHABLE')
require({'bytes': node_metadata.st_size, 'mode': stat.S_IMODE(node_metadata.st_mode),
         'uid': node_metadata.st_uid, 'gid': node_metadata.st_gid, 'device': node_metadata.st_dev,
         'inode': node_metadata.st_ino, 'nlink': node_metadata.st_nlink} == node_identity['metadata']
        and digest(NODE) == node_identity['sha256'], 'PROVIDED_NODE_IDENTITY_CHANGED')
""").body
assert [dump(n) for n in selected]==[dump(n) for n in canonical]
del main.body[pos:pos+4]
argv=next(n for n in main.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='argv' for t in n.targets))
assert dump(argv.value.elts[0])==dump(ast.parse('str(NODE)',mode='eval').body)
argv.value.elts[0]=ast.Constant(value='node')
assert dump(normalized)==dump(oldtree)
ready=json.loads((NEW/'READY.safe.json').read_text());pin=ready['provided_node_binary']
assert pin['path']==node_path and pin['sha256']=='bc17c508ffeed0ec622934f9b7fa72f8e78da65350e63c3eceb56fa688aa5e12'
for path,digest in ready['pinned_source_hashes'].items():
    assert 'private' not in Path(path).parts and sha(Path(path))==digest
p=Path(node_path);s=p.lstat()
actual=dict(bytes=s.st_size,mode=stat.S_IMODE(s.st_mode),uid=s.st_uid,gid=s.st_gid,device=s.st_dev,inode=s.st_ino,nlink=s.st_nlink)
assert os.getuid()==os.getgid()==1000 and Path('/').lstat().st_uid==Path('/').lstat().st_gid==0
assert stat.S_ISREG(s.st_mode) and not p.is_symlink() and os.access(p,os.X_OK)
assert actual==pin['metadata'] and sha(p)==pin['sha256']
def require(condition,stage):
    if not condition:raise RuntimeError(stage)
scope=dict(NODE=p,own_ready=ready,stat=stat,os=os,digest=sha,require=require)
# Only the exact four metadata statements are executed; no driver import or dispatch.
exec(compile(ast.Module(body=selected,type_ignores=[]),'selected_real_readonly_Node_pin','exec'),scope)
failure=json.loads((NEW/'ancestor-failure-cleanup.safe.json').read_text())
assert failure['direct_pid'] is None and failure['known_owned_births']==[] and failure['original_settled_false_preserved'] is True
assert failure['same_birth_live_after'] is False and failure['signals']==0 and failure['native_browser']=='NOT_RUN'
for name,key in [('launch.safe.json','original_launch_sha256'),('terminal.safe.json','original_terminal_sha256')]:
    assert sha(OLD/'runs/attempt-01/supervision'/name)==failure[key]
result=dict(outcome='APPROVE_SOURCE',blocking_findings=0,scope='Provided Node-only source delta and readonly actual pin',source_ready=sha(NEW/'READY.safe.json'),source_manifest=sha(NEW/'manifest.safe.json'),source_zip=sha(NEW/'source.safe.zip'),driver_sha=sha(NEW/'run-probe.py'),source_files=9,zip_members=10,
 full_r1_AST_equal_after_exact_delta=True,exact_four_pin_statements=True,helper_classifier_use_time_controls_identical=True,provided_node=dict(path=node_path,metadata=actual,sha256=pin['sha256'],X_OK=True,actor=[os.getuid(),os.getgid()],context='require_escalated ordinary actor1000/root0; readonly inspection'),
 ancestor_failed_no_Node_receipts_preserved=True,Node_execution_target_import_native43_browser_API_network_calls=0,static_reachability='PASS_EXISTING_REGULAR_EXECUTABLE_AND_IDENTITY_ONLY',dynamic_loader_protocol_runtime='NOT_RUN')
(OWN/'checks.safe.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(dict(outcome=result['outcome'],full_AST_delta_exact=True,real_readonly_pin_match=True,Node_executed=False)))
