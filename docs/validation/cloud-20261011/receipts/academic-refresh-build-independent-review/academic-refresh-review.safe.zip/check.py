"""Independent readonly packet checks and selected pure functions. No target imports."""
import ast
import copy
import datetime
import hashlib
import json
import re
import stat
import subprocess
from pathlib import Path, PurePosixPath
import zipfile

OUT = Path(__file__).parent
SRC = OUT.parent / 'current_academic_refresh_prepare'
ROOT = Path('/workspace/rutcampustrack')
checks = []
def passed(label):
    checks.append(label)
def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def select(file, names, globals_):
    tree = ast.parse((SRC / file).read_text())
    nodes = [n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name in names]
    assert {n.name for n in nodes} == set(names)
    exec(compile(ast.Module(body=nodes, type_ignores=[]), file, 'exec'), globals_)
    return globals_
def deny(label, call):
    try:
        call()
    except (RuntimeError, ValueError):
        passed(label)
    else:
        raise AssertionError(label)

assert digest(SRC / 'manifest.json') == '0b7d2d59eef1fee06f0a8416ef86751e3949a042d7a5007c23aea8e3c9d581bd'
manifest = json.loads((SRC / 'manifest.json').read_text())
assert len(manifest['files']) == 18
expected = {}
for row in manifest['files']:
    p = Path(row['path'])
    assert p.parent == SRC and not p.is_symlink()
    assert p.stat().st_size == row['bytes'] and digest(p) == row['sha256']
    expected[p.name] = p.read_bytes()
passed('all18_source_member_hashes')
zpath = SRC / 'current-academic-refresh-source.safe.zip'
assert digest(zpath) == '930ed856da1a1d442784bebe8f1d24d332d2542fcf9981e69c6246cb3afe5613'
with zipfile.ZipFile(zpath) as z:
    assert z.testzip() is None
    assert len(z.infolist()) == len(set(z.namelist())) == 19
    for info in z.infolist():
        p = PurePosixPath(info.filename)
        assert not p.is_absolute() and '..' not in p.parts and str(p) == info.filename
        assert stat.S_IFMT(info.external_attr >> 16) in (0, stat.S_IFREG)
        content = z.read(info)
        assert content == ((SRC / 'manifest.json').read_bytes() if p.name == 'manifest.json' else expected[p.name])
passed('ZIP19_unique_canonical_CRC_and_exact_content')
for row in json.loads((SRC / 'tool-inputs.safe.json').read_text())['files']:
    assert digest(row['path']) == row['sha256']
passed('all5_original_tool_and_public_spec_map_pins')
for p in SRC.glob('*.py'):
    ast.parse(p.read_text())
passed('all7_python_sources_AST_parse_without_import')

def git(*args):
    return subprocess.run(['/usr/bin/git','-C',str(ROOT),*args], check=True,
                          stdout=subprocess.PIPE, stderr=subprocess.DEVNULL,
                          timeout=30, env={'PATH':'/usr/bin:/bin','LANG':'C.UTF-8'}).stdout
prefix = Path('/tmp/rct-academic-refresh-20261012-attempt01')
revision = manifest['frozen_source_revision']
fix_path = 'services/academic-service/academic-app/src/main/java/ru/rutcampustrack/academic/user/UserSpecifications.java'
mods = ['services/academic-service/academic-app','services/academic-service/academic-api-contract'] + ['services/shared/' + n for n in ['shared-web','shared-web-api','shared-events','shared-logback','shared-outbox','shared-security','shared-observability']]
b = select('refresh-boundary.py', ['selected','validate_fields','require_resources','fresh','gate'],
           {'Path':Path,'re':re,'MODULES':mods,'PREFIX':prefix,'FIX_REVISION':revision,
            'FIX_SHA':manifest['fixed_UserSpecifications_sha256'],'datetime':datetime})
rows = []
for entry in git('ls-tree','-rlz',revision).split(b'\0'):
    if not entry:
        continue
    meta, raw = entry.split(b'\t',1)
    path = raw.decode()
    if b['selected'](path):
        mode, kind, oid, size = meta.decode().split()
        assert kind == 'blob' and mode in ('100644','100755')
        rows.append(dict(path=path,git_blob=oid,git_mode=mode,bytes=int(size)))
rows.sort(key=lambda r:r['path'])
ledger = json.loads((SRC / 'tracked-inputs96.safe.json').read_text())
assert rows == ledger['tracked'] and ledger['revision'] == revision
assert len(rows) == 525 and sum(r['bytes'] for r in rows) == 2630739
assert hashlib.sha256(git('show',revision+':'+fix_path)).hexdigest() == manifest['fixed_UserSpecifications_sha256']
passed('actual_frozen96_public_Git_tree525_exact_2630739B_fixed49db')
assert not any('/src/test/' in r['path'] or r['path'].startswith('frontends/') for r in rows)
assert not any(r['path'].startswith('services/auth-service/auth-app/src/') for r in rows)
passed('no_Auth_source_tests_or_Angular_inputs')

now = datetime.datetime(2026,10,12,20,0,tzinfo=datetime.timezone.utc)
grant = json.loads((SRC / 'build-grant.template.safe.json').read_text())
grant.update(not_before_utc=now.isoformat(),stop_utc=(now+datetime.timedelta(seconds=900)).isoformat())
assert b['validate_fields'](grant,'BUILD',now) == now+datetime.timedelta(seconds=900)
passed('exact_BUILD_fields_positive')
for key, value in [('tests_authorized',True),('product_start_authorized',True),('heavy_leases_released',False),('frozen_source_revision','538af12e280bc0e34b62c99c8823a7bb552d6ea6'),('workspace_cache_growth_cap',8388609)]:
    deny('grant_denies_'+key,lambda key=key,value=value:b['validate_fields'](dict(grant,**{key:value}),'BUILD',now))
r = {'workspace_free':9396199424,'tmp_free':7757000704,'shared':4853493760,'maximum':17179869184,'new_tmp_allocated':0}
assert b['require_resources'](grant,r['workspace_free'],r) == r
passed('resource_measured_example_positive_NOT_future_capacity')
for key, value in [('workspace_free',4294967295),('tmp_free',5368709119),('shared',16106127360),('maximum',4853493761),('new_tmp_allocated',1610612737)]:
    deny('resources_deny_'+key,lambda key=key,value=value:b['require_resources'](grant,r['workspace_free'],dict(r,**{key:value})))
assert b['require_resources'](grant,r['workspace_free']+8388608,r) == r
passed('net8MiB_cache_exact_cap_positive')
deny('net8MiB_plus1_denies',lambda:b['require_resources'](grant,r['workspace_free']+8388609,r))
stop = now+datetime.timedelta(seconds=900)
clock = {'now':stop-datetime.timedelta(seconds=61)}
class Clock:
    @staticmethod
    def now(zone):
        return clock['now']
class Dates:
    timedelta = datetime.timedelta
    timezone = datetime.timezone
    datetime = Clock
def delayed(*args):
    clock['now'] += datetime.timedelta(seconds=2)
    return r
b['datetime'] = Dates
b['require_resources'] = delayed
deny('expiry_DURING_resource_before_gate_return_no_effects',lambda:b['gate'](grant,stop,r['workspace_free']))

s = select('stage-academic.py',['rebind_specs'],{'copy':copy,'re':re,'OLD_APP':SRC.parent/'current_host_stage/payload/academic/app','CLOCK':SRC.parent/'real_client_runtime/teaching-clock-eec3/clock-fixture.jar'})
specs = json.loads((SRC.parent/'current_host_config_v5/host-service-specs.json').read_text())
new = s['rebind_specs'](specs,prefix/'app',['BOOT-INF/lib/new.jar'])
assert [r for r in new if r['service']!='academic'] == [r for r in specs if r['service']!='academic']
old_ac = next(r for r in specs if r['service']=='academic')
new_ac = next(r for r in new if r['service']=='academic')
assert {k:v for k,v in old_ac.items() if k not in ('cwd','argv')} == {k:v for k,v in new_ac.items() if k not in ('cwd','argv')}
passed('six_other_host_specs_and_Academic_ENV_pointer_settings_exact')
for libs in [[],['../evil.jar'],['BOOT-INF/lib/a.jar','BOOT-INF/lib/a.jar']]:
    deny('closed_library_constraints_'+repr(libs),lambda libs=libs:s['rebind_specs'](specs,prefix/'app',libs))
i = select('inspect-academic.py',['member'],{'PurePosixPath':PurePosixPath})
for name in ['../bad','/bad','a//b','a\\b','a:b']:
    deny('ZIP_member_denies_'+repr(name),lambda name=name:i['member'](name))

runner_ast = ast.parse((SRC/'run-academic-restart.py').read_text())
pin_comparison = next(n for n in ast.walk(runner_ast) if isinstance(n,ast.Compare) and isinstance(n.left,ast.Call) and isinstance(n.left.func,ast.Name) and n.left.func.id=='digest' and isinstance(n.left.args[0],ast.Name) and n.left.args[0].id=='helper')
claimed = ast.literal_eval(pin_comparison.comparators[0])
actual = digest(SRC/'runtime-binding.py')
assert claimed == 'e65d7f3bbf4c01671ea682c9a32152ba2f0744d533085769050ebda35f831bf3'
assert actual == '7e7579ce554d6a94aaf79d331aeaccfa6611a989def97fa3ec2be7f261028d07'
assert claimed != actual
passed('exact_runtime_helper_pin_mismatch_confirmed_no_import_effect')
assert 'runtime-binding.py' not in (SRC/'build-academic.py').read_text()
assert 'runtime-binding.py' not in (SRC/'stage-academic.py').read_text()
passed('runtime_wrong_pin_not_used_by_BUILD_or_STAGE')
result = {'verdict':'CHANGES_REQUESTED','BUILD_source_verdict':'APPROVE_SOURCE_BUILD_ONLY',
          'STAGE_source':'No additional material blocker found; actualBUILD receipt and separate grant still required',
          'runtime_source_verdict':'CHANGES_REQUESTED', 'finding':{'id':'ACR-RUNTIME-PIN-001','priority':2,'file':str(SRC/'run-academic-restart.py'),'line':49,'expected_helper_sha256':claimed,'actual_sealed_helper_sha256':actual},
          'checked_source_manifest_sha256':digest(SRC/'manifest.json'),'checked_source_zip_sha256':digest(zpath),
          'checks':checks,'checks_count':len(checks),'target_imports':0,'native_build_stage_runtime':'NOT_RUN',
          'readonly_Git_metadata':'Synchronous wait only, no birth capture claim','private_ENV_key_data_reads':0,
          'requested_selected_model':'gpt-6.1-sol/high','actual_model_effort':'UNKNOWN'}
(OUT/'checks.safe.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'verdict':result['verdict'],'BUILD':result['BUILD_source_verdict'],'checks':len(checks),'findings':1}))
