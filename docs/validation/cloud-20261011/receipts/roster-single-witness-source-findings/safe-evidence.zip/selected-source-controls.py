"""Source-selected public constants only. No helper import, JS, API, credentials, or runtime."""
from pathlib import Path
import hashlib,json,os,re
SRC=Path('/workspace/scratch/rct-validation/client_real_acceptance/focused3-roster-witness-source/witness-detail-lookup.cjs')
OUT=Path(__file__).parent
b=SRC.read_bytes();assert hashlib.sha256(b).hexdigest()=='23541187a3b90525f90666601ef78759e71229ddd859d6b3cde375ff727c6769'
s=b.decode();pattern=re.search(r'const dep = /(.*?)/\.exec\(detail\);',s)[1];rx=re.compile(pattern)
rows=[]
def classify(status,body):
    boundary='GATEWAY_ISSUER' if body.get('code')=='DEPENDENCY_UNAVAILABLE' else 'ATTENDANCE_DEPENDENCY' if body.get('type')=='https://api.rutcampustrack.ru/problems/service-unavailable' else 'OTHER'
    m=rx.search(body.get('detail',''));return {'status':status,'boundary':boundary,'dependency':('ACADEMIC' if m[1]=='Academic' else 'SCHEDULE') if m else 'OTHER','rpc':m[2] if m else 'OTHER'}
valid='Academic Service unavailable: Status{code=UNAUTHENTICATED, description=synthetic, cause=null}'
cases=[('valid_canonical_positive',503,{'type':'https://api.rutcampustrack.ru/problems/service-unavailable','detail':valid},False),
 ('trailing_malformed_negative',503,{'type':'https://api.rutcampustrack.ru/problems/service-unavailable','detail':valid+' trailing'},True),
 ('unterminated_status_negative',503,{'type':'https://api.rutcampustrack.ru/problems/service-unavailable','detail':'Academic Service unavailable: Status{code=UNAUTHENTICATED,'},True),
 ('duplicate_code_field_negative',503,{'type':'https://api.rutcampustrack.ru/problems/service-unavailable','detail':'Academic Service unavailable: Status{code=UNAUTHENTICATED, description=synthetic, code=FAILED_PRECONDITION, cause=null}'},True),
 ('non503_negative',200,{'type':'https://api.rutcampustrack.ru/problems/service-unavailable','detail':valid},True),
 ('unknown_issuer_negative',503,{'detail':valid},True),
 ('gateway_wrong_detail_negative',503,{'code':'DEPENDENCY_UNAVAILABLE','detail':'synthetic unexpected'},True)]
assert "facts.boundary = witness.body.code === 'DEPENDENCY_UNAVAILABLE'" in s and "if (dep) { facts.dependency" in s
for name,status,body,negative in cases:
    actual=classify(status,body)
    admitted=actual['boundary']!='OTHER' or actual['dependency']!='OTHER'
    assert admitted
    rows.append({'case':name,'source_prefix_classification':actual,'negative_counterexample':negative,'qualification':'Python projection of exact extracted JS regex/ternaries; not JS/helper/API/native execution.'})
assert "need(!read.body.page || read.body.page.totalPages <= 1)" in s
assert "const selected = items(lessons.body, 'lessonResponseList').map(unwrap); need(selected.length === 1)" in s
rows.extend([{'case':'missing_user_page_metadata','source_guard_accepts':True,'expected_fail_closed':True},
 {'case':'first_lesson_page_one_row_totalPages_two','source_guard_accepts':True,'expected_fail_closed':True}])
admit=s[s.index('async function admit'):s.index('(async () =>')]
assert 'let token = login.body.accessToken;' in admit and 'adminToken =' not in admit and 'actorToken =' not in admit
assert admit.index('let token =')<admit.index("need(session.status === 200)")<admit.index('return { token, session: value }')
assert "for (const token of [actorToken, adminToken])" in s
rows.append({'case':'login_success_session_gate_failure','local_token_exists':True,'outer_cleanup_token_assigned':False,'qualification':'Exact source control-flow disposition, not actual auth mutation.'})
v={'source_sha256':hashlib.sha256(b).hexdigest(),'verdict':'CHANGES_REQUESTED','controls':rows,'control_count':len(rows),'privacy':'Only synthetic public source constants evaluated; raw constants/messages not serialized.','runtime_helper_import_API_Node':False,'actual503cause':'UNKNOWN'}
fd=os.open(OUT/'selected-source-controls.safe.json',os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
with os.fdopen(fd,'w') as f:json.dump(v,f,indent=2);f.write('\n')
print(json.dumps({'source_sha256':v['source_sha256'],'selected_controls':len(rows),'negative_classifier_counterexamples':sum(c.get('negative_counterexample',False) for c in rows),'native':False,'verdict':v['verdict']}))
