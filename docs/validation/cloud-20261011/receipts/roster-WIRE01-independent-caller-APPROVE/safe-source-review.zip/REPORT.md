APPROVE_SOURCE — bounded WIRE01 caller/effects review, no remaining blocker.

Nine source pins, source13+protected2, unchanged test and exact single old-RPC wrapper mutant match. Both stages require fresh private live-parent authority; parent and child finally restore exact original source, and native phase success plus original compiled hash gate parent acceptance. Fourteen independent actual selected-AST/public synthetic controls pass. Actual mutant RED and freshly compiled restored GREEN remain NOT_RUN.

Initial TERM-handler hypothesis is withdrawn: inherited b78 registers SIGINT/SIGTERM before spawning child and settles owned children before returning through parent finally. No caller correction is requested. Abrupt SIGKILL/host loss and any interrupted/missing compiled restore remain UNKNOWN/no integration until exact recovery evidence.

Closed401 proves method-specific causal failed positive; exact underlying TLS description remains source-qualified. Actual compile/task/class freshness, fresh1case XML, exact restoration, cleanup and resources still need real bounded evidence under Root grant. No native/DB/Docker/private reads or mutation.
