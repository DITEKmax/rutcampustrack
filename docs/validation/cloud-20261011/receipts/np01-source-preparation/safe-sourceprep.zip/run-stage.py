"""Prepared foreground launcher; only a later exact Root grant may execute it."""

import argparse
import datetime
import errno
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import sys
import time

HERE = Path(__file__).resolve().parent
WT = Path('/workspace/rct-worktrees/np01-broker-sensitivity')
ROOT_RECEIPTS = Path('/workspace/rutcampustrack/docs/validation/cloud-20261011/receipts')
GUARD = Path('/workspace/scratch/rct-validation/guard_proc_race_correction/bounded-child.py')
GUARD_SHA = 'b78c61293568d9941692e0b92ee34fd0b84db6d532b4a2c9a5ad42ccbf2204a0'
GIB = 1024**3
BASE = 'eb0e02aaf6c7cfb3b80db2d3a3c81b8a2dd79553'


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def utc():
    return datetime.datetime.now(datetime.timezone.utc)


def output(path, value):
    temporary = path.with_name(path.name + '.next')
    with temporary.open('x') as stream:
        stream.write(json.dumps(value, indent=2) + '\n')
    temporary.chmod(0o600)
    temporary.replace(path)


def grant_input(path, expected_sha, phase):
    if path.is_symlink() or ROOT_RECEIPTS not in path.resolve().parents:
        raise ValueError('Root receipt grant path required')
    if digest(path) != expected_sha or path.stat().st_mode & 0o777 != 0o600:
        raise ValueError('exact private Root grant required')
    grant = json.loads(path.read_text())
    procedure = json.loads((HERE / 'native-procedure.safe.json').read_text())
    source = json.loads((HERE / 'sourceprep.safe.json').read_text())
    if not (grant['authorized'] is True and grant['phase'] == phase
            and grant['source_base'] == BASE and grant['driver_sha256'] == digest(Path(__file__))
            and grant['procedure_sha256'] == digest(HERE / 'native-procedure.safe.json')
            and grant['sourceprep_sha256'] == digest(HERE / 'sourceprep.safe.json')
            and grant['guard_sha256'] == GUARD_SHA and digest(GUARD) == GUARD_SHA):
        raise ValueError('grant/source/driver/guard identity mismatch')
    expiry = datetime.datetime.fromisoformat(grant['expires_utc'])
    issued = datetime.datetime.fromisoformat(grant['issued_utc'])
    if expiry.tzinfo is None or issued.tzinfo is None or not issued <= utc() < expiry:
        raise ValueError('grant is not currently valid')
    for entry in source['changes']:
        file = WT / entry['path']
        if digest(file) != entry['candidate_sha256'] or oct(file.stat().st_mode & 0o777) != entry['mode']:
            raise ValueError('mutant source changed')
    selected = {entry['path'] for entry in source['changes']}
    baseline = json.loads((HERE / 'complete-sparse-baseline.safe.json').read_text())
    for entry in baseline['entries']:
        if entry['path'] in selected:
            continue
        file = WT / entry['path']
        if digest(file) != entry['sha256'] or oct(file.stat().st_mode & 0o777) != entry['mode']:
            raise ValueError('unselected tracked input changed')
    if phase == 'fault' and (WT / 'services/academic-service/academic-app/build/test-results/integrationTest').exists():
        raise ValueError('fresh native integration outputs required')
    limits = grant['limits']
    if not (0 < limits['disk_delta_cap_bytes'] <= 2 * GIB
            and limits['workspace_floor_bytes'] >= 4 * GIB
            and 0 < limits['shared_growth_cap_bytes'] <= 4 * GIB
            and limits['shared_stop_bytes'] <= 15 * GIB
            and limits['shared_reserve_bytes'] >= GIB
            and 0 < limits['owned_tree_rss_cap_bytes'] <= 4 * GIB
            and limits['cleanup_margin_seconds'] >= 60
            and 0 < limits['deadline_seconds'] <= (600 if phase == 'compile' else 900)):
        raise ValueError('bounded resource specification required')
    argv = procedure['commands'][phase]
    remaining = (expiry - utc()).total_seconds() - limits['cleanup_margin_seconds']
    if remaining <= 0:
        raise ValueError('cleanup margin unavailable')
    return grant, argv, min(limits['deadline_seconds'], remaining)


def environment(directory):
    return {'PATH': '/workspace/rct-cloud-setup/jdk21/bin:/usr/local/bin:/usr/bin:/bin',
            'JAVA_HOME': '/workspace/rct-cloud-setup/jdk21', 'GRADLE_USER_HOME': '/workspace/.gradle',
            'LANG': 'C.UTF-8', 'LC_ALL': 'C.UTF-8', 'TZ': 'UTC', 'TMPDIR': str(directory),
            'NP01_PYTHON_EXECUTABLE': '/workspace/rct-cloud-setup/bot-venv/bin/python3.12',
            'PYTHONDONTWRITEBYTECODE': '1', 'PYTHONNOUSERSITE': '1', 'PYTHONSAFEPATH': '1',
            'DOCKER_HOST': 'unix:///var/run/docker.sock', 'TESTCONTAINERS_HOST_OVERRIDE': '127.0.0.1'}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('phase', choices=['compile', 'fault'])
    parser.add_argument('--grant', type=Path, required=True)
    parser.add_argument('--grant-sha256', required=True)
    parser.add_argument('--child', action='store_true')
    args = parser.parse_args()
    os.umask(0o077)
    grant, argv, deadline = grant_input(args.grant, args.grant_sha256, args.phase)
    directory = HERE / grant['run_id']
    if not grant['run_id'].startswith('np01-') or '/' in grant['run_id'] or '..' in grant['run_id']:
        raise ValueError('own unique run identity required')
    if args.child:
        if not directory.is_dir():
            raise ValueError('owned parent run directory missing')
        descriptor = os.open(directory / 'native.raw.private.log', os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
        os.dup2(descriptor, 1)
        os.dup2(descriptor, 2)
        os.close(descriptor)
        os.chdir(WT)
        os.execvpe(argv[0], argv, environment(directory))
    directory.mkdir(mode=0o700, exist_ok=False)
    spec = importlib.util.spec_from_file_location('reviewed_np01_guard', GUARD)
    guard = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(guard)
    limits = grant['limits']
    known = {}
    last = 0.0
    peak_rss = 0
    expiry = datetime.datetime.fromisoformat(grant['expires_utc'])

    def status(value):
        nonlocal last
        for row in value['members_including_Z']:
            if row['pid'] in known and known[row['pid']] != row['start_ticks']:
                raise ValueError('recorded birth changed')
            known[row['pid']] = row['start_ticks']
        now = time.monotonic()
        if value['state'] != 'RUNNING' or now - last >= 1:
            output(directory / 'active-process.safe.json', {'utc': utc().isoformat(), **value})
            last = now

    def observe():
        nonlocal peak_rss
        stat = os.statvfs('/workspace')
        free = stat.f_bavail * stat.f_frsize
        memory = int(Path('/sys/fs/cgroup/memory.current').read_text())
        maximum = int(Path('/sys/fs/cgroup/memory.max').read_text())
        if utc() >= expiry - datetime.timedelta(seconds=limits['cleanup_margin_seconds']):
            return 'ABSOLUTE_DEADLINE_MARGIN'
        if free <= limits['workspace_floor_bytes']:
            return 'WORKSPACE_FLOOR_STOP'
        if grant['cohort_initial_workspace_available_bytes'] - free >= limits['disk_delta_cap_bytes']:
            return 'COHORT_DISK_DELTA_STOP'
        if memory >= min(limits['shared_stop_bytes'], maximum - limits['shared_reserve_bytes']):
            return 'SHARED_RESERVE_STOP'
        if memory - grant['cohort_initial_shared_memory_bytes'] >= limits['shared_growth_cap_bytes']:
            return 'SHARED_GROWTH_STOP'
        rss = 0
        for pid, ticks in list(known.items()):
            try:
                proc = Path('/proc') / str(pid)
                fields = (proc / 'stat').read_text().rsplit(')', 1)[1].split()
                if int(fields[19]) != ticks or fields[0] == 'Z':
                    continue
                rss += int((proc / 'statm').read_text().split()[1]) * os.sysconf('SC_PAGE_SIZE')
            except OSError as caught:
                if caught.errno not in (errno.ENOENT, errno.ESRCH):
                    raise
        peak_rss = max(peak_rss, rss)
        if rss >= limits['owned_tree_rss_cap_bytes']:
            return 'OWNED_RSS_SOFT_STOP'
        return None

    child_argv = [sys.executable, '-B', str(Path(__file__).resolve()), args.phase,
                  '--grant', str(args.grant), '--grant-sha256', args.grant_sha256, '--child']
    result = guard.run_owned(child_argv, str(WT), environment(directory), deadline_seconds=deadline,
                             observe=observe, status=status, term_seconds=15, kill_seconds=5)
    output(directory / 'terminal-process.safe.json', {'utc': utc().isoformat(), 'phase': args.phase,
                                                     'peak_owned_rss_bytes': peak_rss, **result})
    # Fault nonzero is retained as native RED. Unique XML oracle and container cleanup are separate.
    return 0 if result['phase_success'] else 1


if __name__ == '__main__':
    try:
        sys.exit(main())
    except Exception as failure:
        print(json.dumps({'stage': 'PRELAUNCH_OR_DRIVER_BLOCKED', 'type': type(failure).__name__}))
        sys.exit(2)
