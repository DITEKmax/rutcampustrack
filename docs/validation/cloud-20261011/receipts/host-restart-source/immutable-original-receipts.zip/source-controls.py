import ast
import copy
import datetime
import json
from pathlib import Path
import types
P=Path(__file__).parent
ns={};exec(compile((P/'restart-boundary.py').read_bytes(),'restart-boundary.py','exec'),ns)
checks=[]
def check(name,condition):
    if not condition: raise AssertionError(name)
    checks.append({'name':name,'pass':True})
def denied(fn):
    try:fn()
    except (RuntimeError,ValueError,KeyError):return True
    return False
now=datetime.datetime(2026,10,12,14,0,tzinfo=datetime.timezone.utc)
grant=dict(durable_restart_authorized=True,launch_authorized=True,native_mongo_authorized=True,
 reuse_existing_mongo_db=str(ns['DB']),reuse_existing_mongo_key=str(ns['KEY']),
 repeat_bootstrap_authorized=False,data_reset_authorized=False,cohort_name='restart-02',
 deadline_seconds=900,not_before_utc=now.isoformat(),stop_utc=(now+datetime.timedelta(seconds=900)).isoformat())
check('exact new finite grant accepted',ns['validate_restart_fields'](grant,now)==900)
for key,value in [('durable_restart_authorized',False),('launch_authorized',False),('native_mongo_authorized',False),
 ('reuse_existing_mongo_db','/tmp/other'),('reuse_existing_mongo_key','/tmp/other'),('repeat_bootstrap_authorized',True),
 ('data_reset_authorized',True),('cohort_name','../old'),('deadline_seconds',True),('deadline_seconds',1801),
 ('stop_utc',(now-datetime.timedelta(seconds=1)).isoformat()),('not_before_utc',(now+datetime.timedelta(seconds=1)).isoformat())]:
 bad=dict(grant);bad[key]=value
 check('denies '+key+' '+str(value),denied(lambda:ns['validate_restart_fields'](bad,now)))
check('old v5 fresh-only grant denied',denied(lambda:ns['validate_restart_fields']({'launch_authorized':True},now)))
check('expired exact grant denied',denied(lambda:ns['validate_restart_fields'](grant,now+datetime.timedelta(seconds=901))))
fence=json.loads((P/'stopped-native-data-fence.safe.json').read_text())
ns['verify_existing_data'](fence,True)
check('actual stopped 156 nodes metadata-only fence unchanged',len(fence['stopped_db_metadata_nodes'])==156)
for key in ['device','inode','uid','gid','mode','bytes','nlink','mtime_ns','ctime_ns','kind','path']:
 bad=copy.deepcopy(fence);row=bad['exact_key_metadata'];row[key]=row[key]+1 if isinstance(row[key],int) else row[key]+'-changed'
 check('actual selected gate denies changed key '+key,denied(lambda:ns['verify_existing_data'](bad,True)))
for key in ['inode','ctime_ns','mode','uid','nlink']:
 bad=copy.deepcopy(fence);bad['stopped_db_metadata_nodes'][1][key]+=1
 check('actual selected gate denies DB '+key,denied(lambda:ns['verify_existing_data'](bad,True)))
bad=copy.deepcopy(fence);bad['stopped_db_metadata_nodes'].pop()
check('missing DB member denied',denied(lambda:ns['verify_existing_data'](bad,True)))
bad=copy.deepcopy(fence);bad['stopped_db_metadata_nodes'].append(dict(bad['stopped_db_metadata_nodes'][0],path=str(ns['DB']/'extra')))
check('extra DB member denied',denied(lambda:ns['verify_existing_data'](bad,True)))
# Actual identity function selected directly from new runner source, no main/runtime launch.
tree=ast.parse((P/'run-mongo-restart.py').read_text())
fn=next(x for x in tree.body if isinstance(x,ast.FunctionDef) and x.name=='exact_live_child')
idns={};exec(compile(ast.Module(body=[fn],type_ignores=[]),'selected-exact-child','exec'),idns)
record={'child_pid':100,'members_including_Z':[{'pid':100,'start_ticks':10},{'pid':101,'start_ticks':11}]}
for name,table,expected in [('exact', {100:{'pid':100,'start_ticks':10,'state':'S'}},True),
 ('absent child live descendant',{101:{'pid':101,'start_ticks':11,'state':'S'}},False),
 ('reused child live descendant',{100:{'pid':100,'start_ticks':20,'state':'S'},101:{'pid':101,'start_ticks':11,'state':'S'}},False),
 ('zombie child live descendant',{100:{'pid':100,'start_ticks':10,'state':'Z'},101:{'pid':101,'start_ticks':11,'state':'S'}},False)]:
 check('exact identity '+name,idns['exact_live_child'](record,table)==expected)
# Inspect selected actual server branch, not a mirrored model.
server=next(x for x in ast.walk(tree) if isinstance(x,ast.If) and ast.unparse(x.test)=="phase == 'server'")
branch=ast.unparse(ast.Module(body=server.body,type_ignores=[]))
check('server contains no secret reads/creation/bootstrap',all(x not in branch for x in ['read_text','read_bytes','os.open','mkdir','write','credentials','private','bootstrap']))
check('server retains keyFile/auth/rs0/db/loopback port',all(x in branch for x in ['--keyFile','--auth','rs0','--dbpath','127.0.0.1','28417']))
js=(P/'mongo-restart-readiness.js').read_text()
check('readiness has no repeat role/replica bootstrap',all(x not in js for x in ['createUser','updateUser','rs.initiate','rs.reconfig','dropDatabase']))
check('readiness verifies exact roles and foreign denial',all(x in js for x in ['user.roles','readWrite','dbAdmin','error.code === 13','isWritablePrimary']))
for name in ['run-mongo-restart.py','run-service-restart.py']:
 src=(P/name).read_text();check(name+' seals helper before execution',src.index("restart_manifest_path =")<src.index("exec(compile((PLAN / 'restart-boundary.py')"))
 check(name+' has new exact self source check',"row['path'] == str(source)" in src)
 check(name+' writes new cohort receipts only',"OWN / 'runtime' /" not in src)
src=(P/'docker-up-restart.py').read_text()
check('Docker runner exact new grant filename', 'private/restart-launch-grant.json' in src and 'private/launch-grant.json' not in src)
check('Docker source seals itself before helper execution', src.index('manifest_path =') < src.index("exec(compile((PLAN / 'restart-boundary.py')"))
check('Docker unchanged two-file command and no-build/pullnever gate', "argv.count('-f') == 2" in src and "'--no-build' in argv" in src and "== 'never'" in src)
check('all native launch deadlines re-evaluate UTC grant', all('boundary.validate_restart_fields' in (P/name).read_text() for name in ['docker-up-restart.py','run-mongo-restart.py','run-service-restart.py']))
check('old fresh-only explicitly rejects existing dirs',"if runtime.exists() or db.exists():" in Path('/workspace/scratch/rct-validation/current_host_config_v5_mongo_identity_correction/run-mongo.py').read_text())
(P/'source-controls.safe.json').write_text(json.dumps({'status':'PASS_SELECTED_SOURCE_CONTROLS','checks':checks,
 'count':len(checks),'native_children':0,'server_or_DB_protocol':'NOT_RUN','private_content_reads':False,
 'existing_data_mutation':False},indent=2)+'\n')
print(json.dumps({'source_controls':len(checks),'native':'NOT_RUN','existing_data':'METADATA_ONLY_UNCHANGED'}))
