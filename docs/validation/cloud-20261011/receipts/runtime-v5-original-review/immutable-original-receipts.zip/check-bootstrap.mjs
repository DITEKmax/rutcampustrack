import fs from 'node:fs';
import vm from 'node:vm';
const base='/workspace/scratch/rct-validation/current_host_config_v5/';
const bootstrap=fs.readFileSync(base+'mongo-bootstrap.js','utf8');
const app=fs.readFileSync(base+'mongo-init-app-users.js','utf8');
const checks=[];
function check(name,pass){checks.push({name,pass:!!pass});if(!pass)throw Error(name);}
function probe(mode){
 const events=[];let hello=0;let slept=0;let context;
 const admin={getSiblingDB(n){events.push(['db',n]);return this;},runCommand(q){if(q.replSetInitiate){events.push(['init',q.replSetInitiate]);return {ok:mode==='init-fail'?0:1};}if(q.hello){hello++;return {isWritablePrimary:mode==='primary-fail'?false:hello>=2};}throw Error('Unexpected command');},createUser(u){events.push(['user',u]);if(mode==='create-fail')throw Error('Synthetic create failure');},auth(u,p){events.push(['auth',u,p]);return mode==='auth-fail'?0:mode==='auth-object'?{ok:1}:1;}};
 const env={MONGO_ROOT_USER:'PUBLIC_FAKE_ROOT',MONGO_ROOT_PASSWORD:'PUBLIC_FAKE_PASSWORD',MONGO_USER:'PUBLIC_FAKE_ATTEND',MONGO_PASSWORD:'PUBLIC_FAKE_ATTEND_PASSWORD',MONGO_NOTIFICATION_USER:'PUBLIC_FAKE_NOTIFY',MONGO_NOTIFICATION_PASSWORD:'PUBLIC_FAKE_NOTIFY_PASSWORD'};
 context=vm.createContext({db:admin,process:{env},sleep(ms){slept+=ms;},load(p){events.push(['load',p]);if(mode==='load-fail')throw Error('Synthetic load failure');if(p!==base+'mongo-init-app-users.js')throw Error('Foreign script');vm.runInContext(app,context,{timeout:1000});}});
 let error=null;try{vm.runInContext(bootstrap,context,{timeout:1000});}catch(e){error=e.message;}
 return {events,hello,slept,error};
}
for(const mode of ['positive','auth-object']){
 const r=probe(mode);check(mode+'_completed',r.error===null);check(mode+'_single_fresh_init',r.events.filter(e=>e[0]==='init').length===1);
 const init=r.events.find(e=>e[0]==='init')[1];check(mode+'_exact_rs0_loopback',JSON.stringify(init)===JSON.stringify({_id:'rs0',members:[{_id:0,host:'127.0.0.1:28417'}]}));
 const users=r.events.filter(e=>e[0]==='user').map(e=>e[1]);check(mode+'_three_users',users.length===3);
 check(mode+'_root_admin_only',JSON.stringify(users[0].roles)===JSON.stringify([{role:'root',db:'admin'}]));
 for(let i=1;i<3;i++)check(mode+'_least_privilege_'+i,JSON.stringify(users[i].roles)===JSON.stringify([{role:'readWrite',db:i===1?'attendance_db':'notification_db'},{role:'dbAdmin',db:i===1?'attendance_db':'notification_db'}]));
 check(mode+'_auth_before_app_load',r.events.findIndex(e=>e[0]==='auth')<r.events.findIndex(e=>e[0]==='load'));
 check(mode+'_bounded_primary_poll',r.hello===2&&r.slept===250);
}
for(const mode of ['init-fail','primary-fail','create-fail','auth-fail','load-fail']){
 const r=probe(mode);check(mode+'_reject',typeof r.error==='string');
 if(mode==='primary-fail')check('primary_160x250_deadline',r.hello===160&&r.slept===40000);
 if(['init-fail','primary-fail'].includes(mode))check(mode+'_no_user_creation',r.events.every(e=>e[0]!=='user'));
 if(mode==='auth-fail')check('failed_auth_no_app_load',r.events.every(e=>e[0]!=='load'));
 check(mode+'_no_fake_credential_in_error',!r.error.includes('PUBLIC_FAKE'));
}
check('no_destructive_bootstrap',!(/dropDatabase|dropUser|deleteMany|remove\(|updateUser|catch\s*\(/.test(bootstrap+app)));
check('no_print_or_console',!(/print\s*\(|console\./.test(bootstrap+app)));
fs.writeFileSync('/workspace/scratch/rct-validation/hostcfg_v5_independent_recheck/independent-bootstrap-controls.safe.json',JSON.stringify({status:'PASS_SOURCE_ONLY',checks,count:checks.length,failed:0,synthetic_mock_only:true,mongo_process_or_network:false,qualification:'Mocked JS execution verifies command/order/roles/rejection only; actual Mongo authorization, replica initiation and primary election NOT_RUN.'},null,2)+'\n');
console.log(JSON.stringify({checks:checks.length,failed:0,mongo_process_or_network:false}));
