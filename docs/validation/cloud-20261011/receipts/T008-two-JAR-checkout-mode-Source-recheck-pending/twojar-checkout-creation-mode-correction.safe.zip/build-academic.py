"""Future exact Academic+Attendance bootJar only; actual work requires fresh Root BUILD grant."""
import argparse
import datetime
import hashlib
import json
import os
from pathlib import Path
import stat
import subprocess
import types

OWN = Path(__file__).parent
boundary = types.ModuleType('refresh_boundary')
boundary.__file__ = str(OWN / 'refresh-boundary.py')
if hashlib.sha256((OWN / 'refresh-boundary.py').read_bytes()).hexdigest() != 'a6b018ca3246f5cc63de40ba8d843cd53a0507a8f93dd965c0235ca77acf8568':
    raise RuntimeError('Exact reviewed refresh boundary bytes required')
exec(compile((OWN / 'refresh-boundary.py').read_bytes(), boundary.__file__, 'exec'), boundary.__dict__)


def git_read(*args):
    # Public immutable Git objects only; synchronously waited, fast births not claimed captured.
    p = subprocess.run(['/usr/bin/git', '-C', str(boundary.ROOT), *args],
                       env={'PATH': '/usr/bin:/bin', 'LANG': 'C.UTF-8'},
                       stdin=subprocess.DEVNULL, stdout=subprocess.PIPE,
                       stderr=subprocess.DEVNULL, timeout=30, check=True)
    if len(p.stdout) > 4194304:
        raise RuntimeError('Bounded public Git metadata required')
    return p.stdout


def tracked_inputs(revision):
    rows = []
    for entry in git_read('ls-tree', '-rlz', revision).split(b'\0'):
        if not entry:
            continue
        meta, raw = entry.split(b'\t', 1)
        path = raw.decode('utf8')
        if not boundary.selected(path):
            continue
        mode, kind, oid, size = meta.decode().split()
        if kind != 'blob' or mode not in ['100644', '100755']:
            raise RuntimeError('Tracked source symlink/gitlink denied')
        rows.append({'path': path, 'git_blob': oid, 'git_mode': mode, 'bytes': int(size)})
    if not any(r['path'] == boundary.FIX_PATH for r in rows):
        raise RuntimeError('Exact Academic fixed source required')
    if hashlib.sha256(git_read('show', revision + ':' + boundary.FIX_PATH)).hexdigest() != boundary.FIX_SHA:
        raise RuntimeError('Frozen Git tree must contain reviewed fixed source')
    required = json.loads((OWN / 'required-journal-inputs.safe.json').read_text())
    if required['revision'] != revision:
        raise RuntimeError('Exact required journal source producer')
    for row in required['files']:
        if hashlib.sha256(git_read('show', revision + ':' + row['path'])).hexdigest() != row['sha256']:
            raise RuntimeError('Reviewed signed journal source changed')
    return sorted(rows, key=lambda r: r['path'])


def verify_checkout(checkout, rows):
    result = []
    for row in rows:
        p = boundary.regular(checkout / row['path'])
        s = p.lstat()
        expected_mode = 0o755 if row['git_mode'] == '100755' else 0o644
        if (s.st_uid != 1000 or s.st_gid != 1000 or s.st_nlink != 1
                or s.st_size != row['bytes'] or stat.S_IMODE(s.st_mode) != expected_mode):
            raise RuntimeError('Exact own unaliased frozen source required')
        content = p.read_bytes()
        oid = hashlib.sha1(('blob ' + str(len(content)) + '\0').encode() + content).hexdigest()
        if oid != row['git_blob']:
            raise RuntimeError('Frozen source Git object mismatch')
        result.append(dict(row, sha256=hashlib.sha256(content).hexdigest()))
    return result


def checkout_with_creation_modes(run, checkout, revision):
    # Only this ordinary process and its NEW Git working-file creation inherit022.
    # Existing source, masks of other processes, and global configuration never change.
    previous = os.umask(0o022)
    try:
        run('checkout', ['/usr/bin/git', '-C', str(checkout), 'checkout', '--detach', revision], checkout)
    finally:
        os.umask(previous)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--grant', required=True)
    args = parser.parse_args()
    g, stop = boundary.verify_grant(args.grant, 'BUILD', __file__)
    initial = boundary.resource_snapshot(force=True)
    baseline = initial['workspace_free']
    rows = tracked_inputs(g['frozen_source_revision'])
    pinned = json.loads((OWN / 'tracked-inputs597.safe.json').read_text())
    if pinned['revision'] != g['frozen_source_revision'] or rows != pinned['tracked']:
        raise RuntimeError('Exact immutable597 two-module sparse production input ledger required')
    if sum(r['bytes'] for r in rows) > 134217728:
        raise RuntimeError('Selected sparse source logical cap128MiB')
    guard = boundary.load(boundary.GUARD, 'guard')
    # No parent Java/Spring/credential overrides, no proxy required in offline build.
    env = {'PATH': '/workspace/rct-cloud-setup/jdk21/bin:/usr/bin:/bin',
           'LANG': 'C.UTF-8', 'LC_ALL': 'C.UTF-8', 'CI': 'true',
           'JAVA_HOME': '/workspace/rct-cloud-setup/jdk21',
           'JAVA_OPTS': '', 'GRADLE_OPTS': '',
           'HOME': str(boundary.PREFIX / 'home'), 'TMPDIR': str(boundary.PREFIX / 'tmp'),
           'GRADLE_USER_HOME': '/workspace/.gradle'}
    use = lambda: boundary.gate(g, stop, baseline)
    ns = boundary.Namespace(use, create=True)
    supervisor = guard.process_table()[os.getpid()]
    ns.save('build-supervisor.safe.json', supervisor, new=True)
    print(json.dumps({'phase': 'BUILD', 'supervisor': supervisor, 'namespace': str(boundary.PREFIX)}), flush=True)
    latest = {}
    phases = []

    def observe():
        try:
            ns.check()
            use()
            table = guard.process_table()
            rss = 0
            for row in latest.get('members_including_Z', []):
                if table.get(row['pid'], {}).get('start_ticks') != row['start_ticks']:
                    continue
                try:
                    lines = Path('/proc/' + str(row['pid']) + '/status').read_text().splitlines()
                except OSError as e:
                    if e.errno in (2, 3):
                        continue
                    raise
                rss += next((int(line.split()[1]) * 1024 for line in lines if line.startswith('VmRSS:')), 0)
            if rss > 2147483648:
                return 'OWN_COMBINED_RSS_2GiB'
        except RuntimeError:
            return 'REFRESH_RESOURCE_OR_DEADLINE_STOP'
        return None

    def run(phase, argv, cwd):
        latest.clear()
        def status(value):
            latest.clear()
            latest.update(value)
            ns.save(phase + '-process.safe.json', value)
        ns.check()
        use()
        remaining = (stop - datetime.datetime.now(datetime.timezone.utc)).total_seconds() - 60
        result = guard.run_owned(argv, str(cwd), env, deadline_seconds=min(900, remaining),
                                 observe=observe, status=status)
        phases.append({'phase': phase, 'native_exit': result['native_exit'],
                       'settled': result['settled'], 'phase_success': result['phase_success']})
        # Settlement has already occurred even if resource/deadline publication is denied.
        print(json.dumps({'phase': phase, 'native_exit': result['native_exit'],
                          'settled': result['settled'],
                          'all_owned_processes_reaped': result['all_owned_processes_reaped'],
                          'known_owned_identities': result['known_owned_identities'],
                          'all_members_including_Z_after': result['all_members_including_Z_after'],
                          'terminal_reason': result['terminal_reason']}), flush=True)
        ns.save(phase + '-terminal.safe.json', result, new=True)
        if not result['phase_success'] or not result['settled']:
            raise RuntimeError('Bounded own native phase failed')

    try:
        for name in ['home', 'tmp']:
            ns.check()
            use()
            os.mkdir(name, 0o700, dir_fd=ns.fds[-1])
        checkout = boundary.PREFIX / 'checkout'
        run('clone', ['/usr/bin/git', 'clone', '--shared', '--no-checkout',
                      str(boundary.ROOT), str(checkout)], boundary.PREFIX)
        # Only Git immutable object sharing; no hardlinked working source files.
        run('sparse-config', ['/usr/bin/git', '-C', str(checkout), 'config',
                              'core.sparseCheckout', 'true'], checkout)
        # Prepare bytes before fresh use-time gates; raw close cannot flush stale buffered data.
        sparse = ''.join('/' + r['path'] + '\n' for r in rows).encode()
        sparse_path = checkout / '.git/info/sparse-checkout'
        for parent in reversed(sparse_path.parents):
            if not stat.S_ISDIR(parent.lstat().st_mode):
                raise RuntimeError('Sparse path symlink ancestor denied')
        ns.check(); use()
        fd = os.open(sparse_path, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600)
        try:
            offset = 0
            while offset < len(sparse):
                ns.check(); use()
                written = os.write(fd, sparse[offset:offset+262144])
                if type(written) is not int or not 0 < written <= min(262144, len(sparse)-offset):
                    raise RuntimeError('Sparse raw write failed')
                offset += written
            ns.check(); use(); os.fsync(fd)
        finally:
            os.close(fd)
        checkout_with_creation_modes(run, checkout, g['frozen_source_revision'])
        inputs = verify_checkout(checkout, rows)
        ns.save('source-before.safe.json', {'revision': g['frozen_source_revision'], 'tracked': inputs}, new=True)
        run('academic-attendance-bootjar', boundary.BUILD_ARGV, checkout)
        if verify_checkout(checkout, rows) != inputs:
            raise RuntimeError('Tracked build source changed')
        inspector = boundary.load(OWN / 'inspect-academic.py', 'inspector')
        artifacts = [inspector.inspect(checkout, g['frozen_source_revision'], service)
                     for service in boundary.SERVICES]
        proof = {'producer_revision': g['frozen_source_revision'], 'artifacts': artifacts}
        proof.update({'status': 'CURRENT_ACADEMIC_ATTENDANCE_PRODUCTION_JARS_ONLY', 'phases': phases,
                      'resource_after': boundary.require_resources(g, baseline, boundary.resource_snapshot(force=True)),
                      'fixture_inspector_hash': boundary.sha(checkout / 'tests/e2e/backend-clock/verify-jar-isolation.py'),
                      'tracked_source_after': 'EXACT', 'stage_app_browser': 'NOT_RUN',
                      'fast_public_Git_metadata_children': 'SYNCHRONOUS_WAIT; birth ticks not captured',
                      'shared_git_objects': 'Readonly alternate to Root; all working inputs nlink1; source objects must stay retained',
                      'global_gradle_cache': 'Existing pinned cache reused; net workspace growth stop8MiB is measured, not exact cache-isolation proof'})
        ns.check()
        use()
        ns.save('build-result.safe.json', proof, new=True)
        print(json.dumps({'phase': 'BUILD', 'native': 0, 'artifact': 'CURRENT_ACADEMIC_ATTENDANCE_JARS_ONLY', 'runtime': False}))
        return 0
    except BaseException as e:
        try:
            ns.save('build-error.safe.json', {'status': 'PARTIAL_STOPPED', 'error_type': type(e).__name__,
                                             'phases': phases, 'runtime': False})
        except RuntimeError:
            # Keep numeric gates closed; never bypass them to write an error receipt.
            print(json.dumps({'phase': 'BUILD', 'error_receipt': 'GATE_DENIED',
                              'error_type': type(e).__name__, 'phases': phases}), flush=True)
        print(json.dumps({'phase': 'BUILD', 'status': 'PARTIAL_STOPPED', 'error_type': type(e).__name__}))
        return 1
    finally:
        ns.close()


if __name__ == '__main__':
    raise SystemExit(main())
