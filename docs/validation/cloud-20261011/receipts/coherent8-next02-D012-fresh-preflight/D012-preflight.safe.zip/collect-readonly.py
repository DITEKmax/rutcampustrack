import ast, datetime, errno, hashlib, ipaddress, json, os, re, stat, subprocess, types
from pathlib import Path
OWN=Path(__file__).parent
BASE=OWN.parents[1]
PROJECT='rct-client-host-config-20261012'
RESTART=BASE/'current_host_restart_data157_docker_correction'
SOURCE=BASE/'current_academic_stage_completion_prepare'
state={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'ACTUAL_READONLY_METADATA_PREFLIGHT','runtime':'NOT_RUN','actor_uid':os.getuid(),'actor_gid':os.getgid(),'checks':{},'blockers':[]}
def save():
 (OWN/'preflight.safe.json').write_text(json.dumps(state,indent=2)+'\n')
def check(name, good):
 state['checks'][name]=bool(good)
 if not good:state['blockers'].append(name)
 save()
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def cli(argv):
 r=subprocess.run(['docker']+argv,stdout=subprocess.PIPE,stderr=subprocess.DEVNULL,text=True,timeout=15,env={'PATH':'/usr/local/bin:/usr/bin:/bin','HOME':str(OWN)})
 if r.returncode:raise RuntimeError('DOCKER_METADATA_EXIT_'+str(r.returncode))
 return r.stdout
check('actor1000',os.getuid()==1000 and os.getgid()==1000)
state['resources']={'workspace_free':os.statvfs('/workspace').f_bavail*os.statvfs('/workspace').f_frsize,'tmp_free':os.statvfs('/tmp').f_bavail*os.statvfs('/tmp').f_frsize,'shared':int(Path('/sys/fs/cgroup/memory.current').read_text()),'maximum':int(Path('/sys/fs/cgroup/memory.max').read_text())}
r=state['resources'];check('resource_barrier',r['workspace_free']>=9380818650 and r['tmp_free']>=5368709120 and r['shared']<16106127360 and r['maximum']-r['shared']>=1073741824)
state['project_containers']=cli(['ps','-aq','--filter','label=com.docker.compose.project='+PROJECT]).split();state['project_networks']=cli(['network','ls','-q','--filter','label=com.docker.compose.project='+PROJECT]).split();check('project_empty',not state['project_containers'] and not state['project_networks'])
prior=json.loads((BASE/'current_host_restart_ready_20261012/native-preflight.safe.json').read_text())
vols=[]
for old in prior['existing5volume_identities_exact']:
 row=json.loads(cli(['volume','inspect','--format','{"Name":{{json .Name}},"Driver":{{json .Driver}},"Labels":{{json .Labels}}}',old['name']]))
 vols.append({'name':row['Name'],'driver':row['Driver'],'labels':row['Labels'],'same_prior':row['Name']==old['name'] and row['Driver']==old['driver'] and row['Labels']==old['labels']})
state['old5_volumes']=vols;check('old5_volume_names_driver_labels',len(vols)==5 and all(x['same_prior'] for x in vols))
images=[]
for old in prior['retained5unique_images_for6containers']:
 row=json.loads(cli(['image','inspect','--format','{"id":{{json .Id}},"size":{{json .Size}},"user":{{json .Config.User}},"cwd":{{json .Config.WorkingDir}},"entrypoint":{{json .Config.Entrypoint}},"cmd":{{json .Config.Cmd}}}',old['id']]))
 images.append(row)
state['images']=images;check('all5_exact_images',len(images)==5 and {i['id'] for i in images}=={i['id'] for i in prior['retained5unique_images_for6containers']})
networks=[]
for nid in cli(['network','ls','-q']).split():
 row=json.loads(cli(['network','inspect','--format','{"id":{{json .Id}},"name":{{json .Name}},"IPAM":{{json .IPAM.Config}}}',nid]));networks.append(row)
state['network_IPAM']=networks;planned=ipaddress.ip_network('172.29.84.0/24');overlap=[n['name'] for n in networks for c in (n['IPAM'] or []) if c.get('Subnet') and planned.overlaps(ipaddress.ip_network(c['Subnet'],strict=False))];state['IPAM_overlap']=overlap;check('IPAM_no_overlap',not overlap)
ports=set(prior['exact_ports']);busy=[]
for name in ['tcp','tcp6']:
 for line in (Path('/proc/net')/name).read_text().splitlines()[1:]:
  fields=line.split()
  if fields[3]=='0A' and int(fields[1].rsplit(':',1)[1],16) in ports:busy.append(int(fields[1].rsplit(':',1)[1],16))
state['ports']=sorted(ports);state['listening_conflicts']=sorted(set(busy));check('ports_not_listening',not busy)
fence=json.loads((RESTART/'stopped-native-data-fence157.safe.json').read_text())
d={'Path':Path,'stat':stat,'os':os,'DB':Path('/tmp/rct-native-mongo-20261012/fresh-db'),'KEY':Path('/tmp/rct-native-mongo-20261012/runtime/replica-key')}
nodes=[n for n in ast.parse((RESTART/'restart-boundary.py').read_text()).body if isinstance(n,ast.FunctionDef) and n.name in ['metadata','matching','verify_existing_data']]
exec(compile(ast.Module(body=nodes,type_ignores=[]),'exact_readonly_restart_data_metadata','exec'),d)
try:d['verify_existing_data'](fence,stopped=True);check('stopped157_key_metadata_exact',True)
except RuntimeError:check('stopped157_key_metadata_exact',False)
state['data_metadata_nodes']=len(fence['stopped_db_metadata_nodes']);state['data_key_ENV_content_or_hash_reads']=False
anchors=json.loads((RESTART/'runtime-ancestor-anchors.safe.json').read_text())['anchors'];ok=True
for row in anchors:
 s=Path(row['path']).lstat();actual={'device':s.st_dev,'inode':s.st_ino,'uid':s.st_uid,'gid':s.st_gid,'mode':stat.S_IMODE(s.st_mode)};ok &= stat.S_ISDIR(s.st_mode) and actual=={k:v for k,v in row.items() if k!='path'}
check('runtime_ancestor_anchors_exact',ok)
refs=json.loads((OWN.parent/'bound-authorities.safe.json').read_text())['refs'];check('all_bound_source_guard_review_seals',all(sha(x['path'])==x['sha256'] for x in refs))
check('JDK_exact_small_binary_hash',sha('/workspace/rct-cloud-setup/jdk21/bin/java')=='2a207f5e7d075afa01d97f8048389a64432a44c4a5af0f5e77d6e286ec5f401d')
prefix=Path('/tmp/rct-academic-refresh-20261012-attempt01');actual=SOURCE/'actual-completion01';check('actual_result_commit_spec_SHA',all(sha(prefix/n)==sha(actual/n) for n in ['stage-result.safe.json','stage-committed.safe.json','host-service-specs.safe.json']))
artifacts=json.loads((actual/'stage-result.safe.json').read_text())['effective8_artifacts'];rows=[]
for row in artifacts:
 path=Path(row['jar']);s=path.lstat();rows.append({'service':row['service'],'path':str(path),'device':s.st_dev,'inode':s.st_ino,'bytes':s.st_size,'uid':s.st_uid,'gid':s.st_gid,'mode':stat.S_IMODE(s.st_mode),'nlink':s.st_nlink,'retained_producer_SHA':row['sha256'],'fresh_full_JAR_rehash':'NOT_REPEATED_IMMUTABLE_PRODUCER_FENCE'})
state['artifact8_JAR_metadata']=rows;check('artifact8_present_ordinary_owned',len(rows)==8 and all(Path(x['path']).is_file() and x['uid']==1000 and x['gid']==1000 for x in rows))
specs=json.loads((actual/'host-service-specs.safe.json').read_text());classrows=[]
for spec in specs:
 args=spec['argv'];cp=None
 if '-cp' in args:cp=args[args.index('-cp')+1]
 else:cp=next((arg.split('=',1)[1] for arg in args if arg.startswith('--class-path=')),None)
 good=Path(spec['cwd']).is_dir();style='separate-cp' if '-cp' in args else 'inline-class-path'
 if cp is None:
  loader=Path(spec['cwd'])/'org/springframework/boot/loader/launch/JarLauncher.class';m=loader.lstat();style='genuine-default-cwd-JarLauncher'
  good &= 'org.springframework.boot.loader.launch.JarLauncher' in args and stat.S_ISREG(m.st_mode) and os.access(loader,os.R_OK)
 else:
  for entry in cp.split(':'):
   path=Path(entry);path=path if path.is_absolute() else Path(spec['cwd'])/path
   if path.name=='*':path=path.parent
   m=path.lstat();good &= (stat.S_ISREG(m.st_mode) or stat.S_ISDIR(m.st_mode)) and os.access(path,os.R_OK)
 classrows.append({'service':spec['service'],'cwd':spec['cwd'],'classpath_style':style,'available_readable_nosymlink':bool(good)})
state['host7_classpath_metadata']=classrows;check('host7_app_cwds_and_declaredclasspath_readable',all(x['available_readable_nosymlink'] for x in classrows))
mounts=json.loads((BASE/'current_host_restart_ready_20261012/IPAM-mounts.safe.json').read_text())['exact_existing_readonly_bind_mounts'];mountrows=[]
for row in mounts:
 source=Path(row['source']);source=BASE/'current_host_config_v5_redirect_query_correction/edge-default.conf' if source.name=='edge-default.conf' else source;s=source.lstat();mountrows.append({'source':str(source),'device':s.st_dev,'inode':s.st_ino,'mode':stat.S_IMODE(s.st_mode),'uid':s.st_uid,'gid':s.st_gid,'nofollow_kind_ok':stat.S_ISDIR(s.st_mode) or stat.S_ISREG(s.st_mode)})
state['readonly_mount_metadata']=mountrows;check('exact_mounts_present_nosymlink_owned',all(x['nofollow_kind_ok'] and x['uid']==1000 for x in mountrows))
active=[];unreadable=[]
for path in Path('/proc').glob('[0-9]*/stat'):
 try:
  text=path.read_text();comm=text[text.index('(')+1:text.rindex(')')];fields=text.rsplit(')',1)[1].split()
  if comm in {'java','node','mongod','MiniBrowser','chrome','headless_shell'} and fields[0]!='Z':active.append({'pid':int(path.parent.name),'comm':comm,'start_ticks':int(fields[19]),'state':fields[0]})
 except OSError as e:
  if e.errno not in (errno.ENOENT,errno.ESRCH):unreadable.append({'pid':int(path.parent.name),'errno':e.errno})
state['visible_live_known_app_browser_names']=active;state['process_metadata_unreadable']=unreadable;check('no_visible_live_app_browser_and_root_heavy_released',not active and not unreadable)
check('new_cohort_absent',not(BASE/'current_host_restart_plan/runtime/restart-20261012-next02').exists());grant_path=BASE/'current_host_config_v5/private/restart-launch-grant-next02.json'
check('old_grant_absent_or_explicitly_revoked',not grant_path.exists() or json.loads(grant_path.read_text()).get('launch_authorized') is False)
state['governing_D012_task_sha256']='44172878e580f00712d9e13a796cfd181a3b2456c034422318fc2433e98ff78c'
state['old_rejection_preserved']=True
state['finished_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();state['disposition']='READY_READONLY_METADATA_ONLY' if not state['blockers'] else 'BLOCKED_EXACT_METADATA_GATE';save();print(json.dumps({'disposition':state['disposition'],'blockers':state['blockers'],'resources':state['resources'],'checks':state['checks'],'receipt':str(OWN/'preflight.safe.json')}))
