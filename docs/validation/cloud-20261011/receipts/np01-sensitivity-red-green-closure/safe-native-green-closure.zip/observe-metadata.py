import datetime,json,os,subprocess,time
from pathlib import Path
HERE=Path(__file__).resolve().parent
RUN=Path('/workspace/scratch/rct-validation/np01_broker_sensitivity_green_caller/np01-green-20261012-attempt01')
env={'PATH':'/usr/local/bin:/usr/bin:/bin','LANG':'C.UTF-8','LC_ALL':'C.UTF-8','DOCKER_HOST':'unix:///var/run/docker.sock'}
fmt='{"id":{{json .Id}},"name":{{json .Name}},"image":{{json .Config.Image}},"image_id":{{json .Image}},"created":{{json .Created}},"started":{{json .State.StartedAt}},"host_pid":{{json .State.Pid}},"state":{{json .State.Status}},"owner":{{json (index .Config.Labels "rct.validation.owner")}},"session":{{json (index .Config.Labels "org.testcontainers.sessionId")}},"testcontainers":{{json (index .Config.Labels "org.testcontainers")}},"ports":{{json .NetworkSettings.Ports}},"networks":{{json .NetworkSettings.Networks}},"mounts":{{json .Mounts}}}'
os.umask(0o077)
start=time.monotonic();seen={};snapshots=0;errors=[]
f=HERE/'docker-native-observations.safe.ndjson'
with f.open('x') as log:
 while time.monotonic()-start<900:
  utc=datetime.datetime.now(datetime.timezone.utc).isoformat()
  try:
   ids=subprocess.check_output(['docker','ps','-a','-q','--no-trunc'],env=env,text=True,timeout=10).splitlines()
   for i in ids:
    r=subprocess.run(['docker','inspect','--format',fmt,i],env=env,capture_output=True,text=True,timeout=10)
    if r.returncode:continue
    a=json.loads(r.stdout)
    a['networks']={n:{'network_id':v.get('NetworkID'),'endpoint_id':v.get('EndpointID')} for n,v in a['networks'].items()}
    a['mounts']=[{'type':v.get('Type'),'name':v.get('Name'),'destination':v.get('Destination'),'read_write':v.get('RW')} for v in a['mounts']]
    pid=a['host_pid'];q=Path('/proc')/str(pid)/'stat'
    if pid and q.exists():
     v=q.read_text().rsplit(')',1)[1].split();a['host_process_birth']=int(v[19]);a['host_process_state']=v[0]
    if i not in seen or seen[i]!=a:
     log.write(json.dumps({'utc':utc,'container':a})+'\n');log.flush();seen[i]=a
   s=os.statvfs('/workspace');t=os.statvfs('/tmp');m=int(Path('/sys/fs/cgroup/memory.current').read_text())
   log.write(json.dumps({'utc':utc,'container_ids':ids,'workspace_available_bytes':s.f_bavail*s.f_frsize,'tmp_available_bytes':t.f_bavail*t.f_frsize,'shared_memory_bytes':m,'terminal_exists':(RUN/'terminal-process.safe.json').exists()})+'\n');log.flush();snapshots+=1
   if (RUN/'terminal-process.safe.json').exists() and not ids:break
  except Exception as ex:
   errors.append({'utc':utc,'type':type(ex).__name__})
  time.sleep(5)
q=Path('/proc')/str(os.getpid())/'stat';birth=int(q.read_text().rsplit(')',1)[1].split()[19])
terminal={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'observer_pid':os.getpid(),'observer_birth':birth,'duration_seconds':time.monotonic()-start,'snapshots':snapshots,'captured_container_ids':sorted(seen),'errors':errors,'native_terminal_observed':(RUN/'terminal-process.safe.json').exists(),'metadata_only_no_container_or_volume_mutations':True}
(HERE/'observer-terminal.safe.json').write_text(json.dumps(terminal,indent=2)+'\n')
print(json.dumps({'observer_terminal':True,'snapshots':snapshots,'containers':len(seen),'native_terminal_observed':terminal['native_terminal_observed'],'error_count':len(errors)}))
