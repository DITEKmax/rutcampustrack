Только correction публичного Source adapter

Native78037 завершился1 / acceptedfalse. Четыре регрессии сработали, но capture cases показали8→7 вместо ожидаемых8→6; direct decoder показал8→6. Исходный helper передавал __dirname каталога snapshot. Reader вычислял другой canonical datasetFile, поэтому публичный frame W не совпадал и оставалась одна class hint. Native FAIL сохранён: оба PIDbirth отсутствуют, все owned процессы reaped, TMP удалён, Source pins целы, lease RELEASED.

Созданы canonical-копии двух shared-loader helpers. Единственная правка каждой: VM argument dirname → W/fixtures для всех before/current вариантов. Чтение snapshot, caching, TS, classifier, datasetFile policy, emit policy и oracle6→8 прежние. Exact inverse byte checks PASS. Worker helper уже использовал canonical W и не изменён. Source570d/40f8 не менялась.

Четыре selected-reader Source controls в tool V8 RAM прошли: snapshot context даёт одну hint; canonical context — две; bounded reader совпадает побайтно; все reported metadata имеют UNKNOWN/0. Это не Node и не исполнение полного recorder. 7/6 slots — derived old-cap model. Fresh native RED/GREEN остаются NOT_RUN; старый FAIL не переименован в PASS.

Driver изменён только в двух PLAN filename parameters. Callbacks, acceptance и caps byteexact. Следующий шаг: ci731 narrow binding recheck, затем fresh Root grant и новый namespace attempt02. Old3528 grant не использовать. Нет API, браузера, credentials, сети, сервисов, новой политики или Root/vendor writes. Actual CI cause UNKNOWN.
