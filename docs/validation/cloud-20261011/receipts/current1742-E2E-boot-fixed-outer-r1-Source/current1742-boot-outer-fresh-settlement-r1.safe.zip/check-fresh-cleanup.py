"""Targeted full old/new caller RAM case; no real PID/FS/log/API activity."""
import ast,datetime,hashlib,json,os,stat,types
from pathlib import Path

OWN=Path(__file__).parent
OLD=OWN.with_name('current1742_e2e_boot_outer_caller_source')
adapter=(OLD/'check-caller-ram.py').read_text()
# Use accepted public OS adapters; only change the native metadata/result
# scenario and the assertions. Executed caller AST is unchanged for each source.
adapter=adapter.replace("proc_active[0]=False\n            failed=", "proc_active[0]=case=='LIVE_KNOWN_BIRTH_AFTER_RETURN'\n            failed=",1)
adapter=adapter.replace("'supervision_error_type':None}", "'supervision_error_type':'UNKNOWN' if case=='UNKNOWN_SETTLEMENT_STATUS' else None}",1)
adapter=adapter.replace("if case=='SUCCESS':assert", "if case in {'LIVE_KNOWN_BIRTH_AFTER_RETURN','UNKNOWN_SETTLEMENT_STATUS'}:\n        assert native==1 and counts['private_reads']==0\n        assert counts['unlink']==(1 if source_old else 0)\n        assert leaf[0] is (not source_old)\n    elif case=='SUCCESS':assert",1)
adapter=adapter.replace("'FAILED_CAPTURE','FAILED_CAPTURE_FOREIGN'}", "'FAILED_CAPTURE','FAILED_CAPTURE_FOREIGN','UNKNOWN_SETTLEMENT_STATUS'}",1)
run_node=next(n for n in ast.parse(adapter).body if isinstance(n,ast.FunctionDef) and n.name=='run')
results=[]
for case in ['LIVE_KNOWN_BIRTH_AFTER_RETURN','FAILED_CAPTURE','UNKNOWN_SETTLEMENT_STATUS']:
    row={'case':case,'old':None,'new':None}
    for label,source in [('old',OLD/'read-existing-boot.py'),('new',OWN/'read-existing-boot.py')]:
        def load(path,name):
            g={'Path':Path,'dt':datetime,'re':__import__('re'),'os':os,'stat':stat,
                'sys':__import__('sys'),'hashlib':hashlib,'json':json,'__file__':str(path)}
            nodes=[n for n in ast.parse(path.read_bytes()).body if isinstance(n,(ast.FunctionDef,ast.ClassDef,ast.Assign))]
            mod=types.ModuleType(name)
            mod.__dict__.update(g)
            exec(compile(ast.Module(body=nodes,type_ignores=[]),str(path),'exec'),mod.__dict__)
            return mod
        raw=source.read_bytes()
        g={'ast':ast,'datetime':datetime,'hashlib':hashlib,'json':json,'os':os,
            'stat':stat,'types':types,'Path':Path,'OWN':source.parent,'SOURCE':source,
            'raw':raw,'nodes':[n for n in ast.parse(raw).body if isinstance(n,(ast.FunctionDef,ast.ClassDef,ast.Assign))],
            'load':load,'checks':[],'source_old':label=='old'}
        exec(compile(ast.Module(body=[run_node],type_ignores=[]),'PUBLIC_RAM_ADAPTER','exec'),g)
        g['run'](case)
        row[label]=g['checks'][0]
    results.append(row)
print(json.dumps({'state':'TARGETED_SOURCE_RAM_PASS','cases':results,
    'old_manifest_unchanged':hashlib.sha256((OLD/'manifest.json').read_bytes()).hexdigest()=='d3992a842e95ccb2a5998877d313c9253b54c6b06ceeaa040d7a7066a313b207',
    'actual_private_API_FS_native':False}))
