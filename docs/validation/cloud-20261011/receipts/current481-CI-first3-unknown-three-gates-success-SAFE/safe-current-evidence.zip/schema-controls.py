"""Bounded pure Python schema checks. No Node, runtime/helper, artifact/API or native tests."""
from pathlib import Path
import copy,hashlib,importlib.util,json,os,re
OUT=Path(__file__).parent
spec=importlib.util.spec_from_file_location('own_closed_schema',OUT/'strict-browser-schema.py');module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
source=Path('/workspace/rutcampustrack/tests/e2e/fixtures/safe-reporter.ts').read_bytes();assert hashlib.sha256(source).hexdigest()==module.REPORTER_SHA
text=source.decode();block=re.search(r'const failureStages = \{(.*?)\} as const;',text,re.S)[1]
actual=dict(re.findall(r"([A-Z_]+): '([A-Z_]+)'",block));assert actual==module.STAGES and len(actual)==15
statuses={int(x) for x in re.findall(r'\d+',re.search(r'const failureHttpStatuses = \[(.*?)\] as const;',text,re.S)[1])};assert statuses==module.HTTP and len(statuses)==14
controls=[]
def checked(code,fn,allowed):
    try:fn();accepted=True
    except module.SchemaBlocked:accepted=False
    controls.append({'code':code,'passed':accepted==allowed})
base={'file':'mobile-real-server.spec.ts','line':14,'project':'chromium','status':'failed','expectedStatus':'passed','durationMs':81,'errorCount':1,'errorLocations':[{'file':'mobile-real-server.spec.ts','line':14}]}
for cause,stage in module.STAGES.items():
    status=401 if cause in module.HTTP_CAUSES else 0
    checked('VALID_'+cause,lambda c=cause,s=stage,h=status:module.validate_diagnostics([{'cause':c,'stage':s,'httpStatus':h}],1),True)
for status in module.HTTP-{0}:checked('VALID_HTTP_'+str(status),lambda h=status:module.validate_diagnostics([{'cause':'ACTOR_SESSION_HTTP','stage':'ACTOR_SESSION','httpStatus':h}],1),True)
good={'cause':'ACTOR_LOGIN_HTTP','stage':'ACTOR_LOGIN','httpStatus':401}
for code,value in [('UNKNOWN_CAUSE',{'cause':'NOT_A_SOURCE_ENUM','stage':'UNKNOWN','httpStatus':0}),('MISMATCHED_STAGE',{**good,'stage':'TEACHING_CLOCK'}),('HTTP_ZERO',{**good,'httpStatus':0}),('NONHTTP_NONZERO',{'cause':'CLOCK_TARGET_GUARD','stage':'TEACHING_CLOCK','httpStatus':401}),('RAW_EXTRA_FIELD',{**good,'message':'SYNTHETIC_PUBLIC_CANARY'}),('STRING_HTTP',{**good,'httpStatus':'401'}),('FLOAT_HTTP',{**good,'httpStatus':401.0}),('BOOL_HTTP',{'cause':'UNKNOWN','stage':'UNKNOWN','httpStatus':False})]:
    checked(code,lambda v=value:module.validate_diagnostics([v],1),False)
checked('DUPLICATE_DIAGNOSTIC',lambda:module.validate_diagnostics([good,good],1),False)
checked('DIAGNOSTIC_OVER_EIGHT',lambda:module.validate_diagnostics([good]*9,1),False)
checked('ERROR_WITH_EMPTY_DIAGNOSTICS',lambda:module.validate_diagnostics([],1),False)
checked('NO_ERROR_EMPTY_DIAGNOSTICS',lambda:module.validate_diagnostics([],0),True)
checked('DUPLICATE_JSON_KEY',lambda:module.decode(b'{"cause":"SYNTHETIC_PUBLIC_CANARY","cause":"UNKNOWN"}'),False)
checked('NONFINITE_JSON',lambda:module.decode(b'{"durationMs":NaN}'),False)
def report(row):return {'status':'failed','runnerErrors':0,'unsafeArtifact':False,'suppressedStdoutBytes':0,'suppressedStderrBytes':0,'results':[row]}
checked('LEGACY_OPTIONAL_ABSENT',lambda:module.validate_results(report(base),{'mobile-real-server.spec.ts'}),True)
checked('NEW_VALID_DIAGNOSTIC',lambda:module.validate_results(report({**base,'diagnostics':[good]}),{'mobile-real-server.spec.ts'}),True)
checked('CASE_EXTRA_RAW_FIELD',lambda:module.validate_results(report({**base,'rawError':'SYNTHETIC_PUBLIC_CANARY'}),{'mobile-real-server.spec.ts'}),False)
checked('UNPUSHED_BINDING_BLOCKS',lambda:module.load_binding(OUT),False)
assert all(row['passed'] for row in controls)
v={'state':'PASS_SOURCE_SCHEMA_CHECKS','count':len(controls),'failed':0,'controls':controls,'canonical_source_sha256':module.REPORTER_SHA,'cause_count':15,'http_status_count':14,'Root_schema_mapping_exact':True,'Node_artifact_API_network_native':'NOT_RUN','actual_current_CI_failure_cause':'UNKNOWN'}
fd=os.open(OUT/'schema-controls.safe.json',os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
with os.fdopen(fd,'w') as f:json.dump(v,f,indent=2);f.write('\n')
print(json.dumps({'count':len(controls),'failed':0,'state':v['state'],'actualCI':'NOT_FETCHED_NOT_PUSHED'}))
