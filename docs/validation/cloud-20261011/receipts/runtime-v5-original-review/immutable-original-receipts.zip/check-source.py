from pathlib import Path
import ast,hashlib,json,os,stat,zipfile,yaml,types
O=Path('/workspace/scratch/rct-validation/hostcfg_v5_independent_recheck')
B=Path('/workspace/scratch/rct-validation/current_host_config_v5');V=Path('/workspace/scratch/rct-validation/current_host_config_v4');C=Path('/workspace/scratch/rct-validation/current_host_config_v5_redirect_query_correction')
checks=[]
def check(n,v):
 checks.append({'name':n,'pass':bool(v)})
 if not v:raise AssertionError(n)
def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb') as f:
  for b in iter(lambda:f.read(65536),b''):h.update(b)
 return h.hexdigest()
for root,mname,msha,zsha in [(B,'launch-manifest.json','e3b6e2c80d819e758bd54722a0d348764dcee5ce64a1ede0cd20df16adc96378','03ae75b7bb3ec600b06efaf95316e588c5801b4595bf34f122e05f81aeac7cc6'),(C,'manifest.json','75e4107b7053de13feb12d5cdbecfdae67124b1cdd01fee1ab52140c0439ab73','208fda04dfe6c905c5bc1a3fa6f61ae6e960dcddf4cf076057794e37cc95ab43')]:
 check(root.name+'_manifest',sha(root/mname)==msha)
 check(root.name+'_zip',sha(root/'safe-evidence.zip')==zsha)
 rows=json.loads((root/mname).read_text())['files']
 for row in rows:
  p=Path(row['path']);s=p.lstat();check(root.name+'/'+row['relative_path'],p.is_relative_to(root) and stat.S_ISREG(s.st_mode) and s.st_size==row['bytes'] and sha(p)==row['sha256'] and (not 'mode' in row or stat.S_IMODE(s.st_mode)==int(row['mode'],8)))
 with zipfile.ZipFile(root/'safe-evidence.zip') as z:
  check(root.name+'_zip_crc',z.testzip() is None)
  check(root.name+'_zip_entries',set(z.namelist())=={r['relative_path'] for r in rows}|{mname})
  for row in rows:check(root.name+'_zipbytes/'+row['relative_path'],hashlib.sha256(z.read(row['relative_path'])).hexdigest()==row['sha256'])
check('old_v4_manifest_unchanged',sha(V/'launch-manifest.json')=='e393a8f16f28f76f181cfc0814adf18f41ca8d214a78b6453b4ecbaa02db296f')
check('old_v4_zip_unchanged',sha(V/'safe-evidence.zip')=='47bf72f814e323153e7d00cc7ac56cddf2b6ac4c56747d695fda1afab05dfa25')
# Authorized own synthetic ENV comparisons: no values/digests emitted or retained.
inputs=sorted((V/'private').glob('*.env'))+sorted((V/'private').glob('*environment.json'))
# Use the exact 9-copy ledger, not an indiscriminate private-directory walk.
copy=json.loads((B/'private-copy.safe.json').read_text())
# Exact names come from the sealed public copy ledger.
for record in copy:
 p=B/'private'/record['name']
 q=V/'private'/p.name
 if not q.exists():continue
 s=p.lstat();check('own600_new/'+p.name,stat.S_ISREG(s.st_mode) and stat.S_IMODE(s.st_mode)==0o600 and s.st_uid==os.getuid() and s.st_nlink==1 and (s.st_dev,s.st_ino)!=(q.stat().st_dev,q.stat().st_ino))
 check('private_byte_equal/'+p.name,p.read_bytes()==q.read_bytes())
check('private_exact_nine',sum(x['name'].startswith('private_byte_equal/') for x in checks)==9)
a=json.loads((V/'host-service-specs.json').read_text());b=json.loads((B/'host-service-specs.json').read_text())
for row in a:row['private_environment_file']=row['private_environment_file'].replace(str(V),str(B))
check('seven_specs_pointer_only',a==b)
a=yaml.safe_load((V/'data-renderer-edge.compose.yml').read_text());b=yaml.safe_load((B/'data-renderer-edge.compose.yml').read_text());overlay=yaml.safe_load((C/'edge-overlay.compose.yml').read_text())
check('six_service_exact_set',set(b['services'])==set(a['services'])-{'mongo-attendance','pwa-nginx','mini-app-nginx'})
check('five_preserved_volumes',a['volumes']==b['volumes'] and len(b['volumes'])==5)
check('unchanged_network_trust',a['networks']==b['networks'] and a['services']['nginx']['networks']==b['services']['nginx']['networks'])
for name in set(b['services'])-{'nginx'}:check('unchanged_container/'+name,a['services'][name]==b['services'][name])
x=a['services']['nginx'].copy();y=b['services']['nginx'].copy()
for k in ['volumes','depends_on']:x.pop(k,None);y.pop(k,None)
check('edge_other_settings_equal',x==y)
check('overlay_only_default_conf',set(overlay)=={'services'} and set(overlay['services'])=={'nginx'} and set(overlay['services']['nginx'])=={'volumes'} and len(overlay['services']['nginx']['volumes'])==1)
m=overlay['services']['nginx']['volumes'][0];old=next(v for v in b['services']['nginx']['volumes'] if v['target']==m['target']);check('overlay_only_source_changes',{k:v for k,v in m.items() if k!='source'}=={k:v for k,v in old.items() if k!='source'} and m['source']==str(C/'edge-default.conf'))
check('edge_exact_two_returns',(B/'edge-default.conf').read_text().replace('return 301 /app/;','return 301 /app/$is_args$args;').replace('return 301 /mini-app/;','return 301 /mini-app/$is_args$args;')==(C/'edge-default.conf').read_text())
for prefix in ['/app/','/mini-app/']:
 for args in ['','a=1','a=','a=1&a=2','entry=%2Ffoo%3Fx%3D1','a=1&&b=2']:
  target=prefix+('?' if args else '')+args
  check('query_preservation_'+prefix+str(len(checks)),target==prefix+('?' + args if args else ''))
check('app_users_exact_source',(B/'mongo-init-app-users.js').read_bytes()==Path('/workspace/rutcampustrack/infra/mongo/init-mongo.js').read_bytes())
for n in ['run-mongo.py','run-service-v5.py']:ast.parse((B/n).read_text());check('python_parse/'+n,True)
spec=json.loads((B/'mongo-spec.json').read_text());feas=json.loads((B/'feasibility/native-version-ELF.safe.json').read_text())
for r in feas['results']:
 p=Path(spec[r['name']]);check('native_binary/'+r['name'],stat.S_IMODE(p.stat().st_mode)==0o755 and sha(p)==r['binary_sha256'])
 for d in r['effective_host_dependencies']:check('host_DSO/'+d['effective_public_library'],sha(d['effective_public_library'])==d['public_sha256'])
check('reviewed_b78_guard',sha('/workspace/scratch/rct-validation/guard_proc_race_correction/bounded-child.py')=='b78c61293568d9941692e0b92ee34fd0b84db6d532b4a2c9a5ad42ccbf2204a0')
# Exact source condition controls only, no module main/filesystem writes or process spawn.
t=ast.parse((B/'run-mongo.py').read_text());main=next(n for n in t.body if isinstance(n,ast.FunctionDef) and n.name=='main');ifs=[n for n in main.body if isinstance(n,ast.If)]
condition=compile(ast.Expression(ifs[0].test),'<sealed-source-grant-condition>','eval');G={'launch_authorized':True,'native_mongo_authorized':True,'fresh_disposable_mongo_db':'/tmp/rct-native-mongo-20261012/fresh-db','reviewed_guard_sha256':'b78c61293568d9941692e0b92ee34fd0b84db6d532b4a2c9a5ad42ccbf2204a0'}
ctx={'NATIVE':Path('/tmp/rct-native-mongo-20261012'),'GUARD_SHA':G['reviewed_guard_sha256']}
check('grant_exact_positive',eval(condition,dict(ctx,grant=G)) is False)
for k in G:
 for value in [None,False,1,'foreign']:
  bad=G|{k:value};check('grant_reject/'+k+'/'+str(type(value).__name__)+str(len(checks)),eval(condition,dict(ctx,grant=bad)) is True)
check('capacity_arithmetic',9380818650==4294967296+1073741824+16777216+3775640828+219691486 and 9557282816-9380818650==176464166)
(O/'independent-source-checks.safe.json').write_text(json.dumps({'status':'PASS_SOURCE_ONLY','checks':checks,'count':len(checks),'failed':0,'private_values_or_hashes_published':False,'runtime_invoked':False},indent=2)+'\n')
print(json.dumps({'checks':len(checks),'failed':0,'runtime':False}))
