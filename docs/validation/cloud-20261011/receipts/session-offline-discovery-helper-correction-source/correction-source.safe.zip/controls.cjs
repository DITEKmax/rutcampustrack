// Three negative public reporter-boundary controls; no Playwright or fixtures are loaded.
const fs = require('node:fs');
const path = require('node:path');
const mode = process.argv[2];
if (!['before', 'after'].includes(mode)) throw new Error('Control mode is required');
const base = '/workspace/scratch/rct-validation/client_session_offline_acceptance';
const Reporter = require(mode === 'before'
  ? path.join(base, 'discovery-gate-correction/discovery-reporter.before.cjs')
  : path.join(base, 'discovery-reporter.cjs'));
const run = process.env.RCT_SESSION_OFFLINE_RUN;
if (run !== path.join(base, 'runs/attempt-91')) throw new Error('Private control namespace is required');
const output = path.join(run, 'supervision', mode + '-controls.safe.json');
process.env.RCT_SESSION_OFFLINE_LIST_OUTPUT = path.join(run, 'supervision', 'list.safe.json');
const test = (line) => ({
  location: { file: '/workspace/rutcampustrack/tests/e2e/specs/mobile-real-server.spec.ts', line },
  parent: { project: () => ({ name: 'chromium' }) },
});
const cases = [
  ['ZERO_CASES', []],
  ['ONE_CASE', [test(260)]],
  ['WRONG_LINE', [test(260), test(368)]],
];
const results = cases.map(([code, tests]) => {
  const reporter = new Reporter();
  reporter.onBegin({}, { allTests: () => tests });
  const discovered = JSON.parse(fs.readFileSync(process.env.RCT_SESSION_OFFLINE_LIST_OUTPUT, 'utf8'));
  const rejected = discovered.pass === false && reporter.onEnd().status === 'failed';
  return { code, discoveryPass: discovered.pass === true, rejected };
});
const failedControls = results.filter((row) => !row.rejected).length;
const knownBeforeCounterexample = mode === 'before' && failedControls === 3 && results.every((row) => !row.discoveryPass);
fs.writeFileSync(output, JSON.stringify({ phase: 'DISCOVERY_GATE_THREE_CONTROLS', mode,
  count: results.length, failedControls, pass: failedControls === 0,
  knownBeforeCounterexample, results }, null, 2) + '\n', { mode: 0o600 });
process.exit(failedControls === 0 ? 0 : 1);
