'use strict';
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const ts = require('/workspace/rutcampustrack/frontends/node_modules/typescript/lib/typescript.js');
const own = __dirname;
const wt = '/workspace/rct-worktrees/client-privacy-boundary-eb';
const root = '/workspace/rutcampustrack';
const files = JSON.parse(fs.readFileSync(path.join(own, 'READY.safe.json'))).changedPaths.map((row) => row.path);
const hash = (x) => crypto.createHash('sha256').update(x).digest('hex');
const canonical = (source, file) => {
  const ast = ts.createSourceFile(file, source, ts.ScriptTarget.ES2022, true);
  const visit = (node) => {
    const children = [];
    ts.forEachChild(node, (child) => { children.push(visit(child)); });
    return { kind: node.kind, text: ts.isSourceFile(node) ? undefined : node.text, children };
  };
  return { parseErrors: ast.parseDiagnostics.length, tree: JSON.stringify(visit(ast)) };
};
(async () => {
  const prettier = await import('/workspace/rct-worktrees/client-current-artifacts/frontends/node_modules/prettier/index.mjs');
  const rows = [];
  for (const relative of files) {
    const filename = path.join(wt, relative);
    const logical = path.join(root, relative);
    const before = fs.readFileSync(filename, 'utf8');
    const config = await prettier.resolveConfig(logical);
    const after = await prettier.format(before, { ...config, filepath: logical });
    const oldAST = canonical(before, relative);
    const newAST = canonical(after, relative);
    const astEqual = oldAST.tree === newAST.tree && oldAST.parseErrors === 0 && newAST.parseErrors === 0;
    if (!astEqual) throw new Error('Mechanical AST comparison failed');
    fs.writeFileSync(filename, after);
    const formatted = await prettier.check(after, { ...config, filepath: logical });
    rows.push({ path: relative, beforeSha256: hash(before), afterSha256: hash(after), astEqual, parseErrors: newAST.parseErrors, formatted });
  }
  fs.writeFileSync(path.join(own, 'format.safe.json'), JSON.stringify({ prettierVersion: prettier.version, typescriptToolVersion: ts.version, actualRootConfigSha256: hash(fs.readFileSync(path.join(root, '.prettierrc.json'))), logicalRootFilenames: true, rows }, null, 2) + '\n');
})().catch(() => { fs.writeFileSync(path.join(own, 'format.safe.json'), JSON.stringify({ state: 'FORMAT_PROOF_FAILED', rawErrorSuppressed: true }) + '\n'); process.exit(1); });
