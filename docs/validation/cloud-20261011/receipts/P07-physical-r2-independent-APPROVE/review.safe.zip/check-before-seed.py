"""Three integration-of-admission actual-AST RAM controls, no daemon/files/keys."""
import ast
import datetime
import json
import math
from pathlib import Path
from types import SimpleNamespace

source = Path("/workspace/scratch/rct-validation/notification_key_isolation/caller-r2/prove-key-volume.py")
tree = ast.parse(source.read_text())
main = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == "main")
flow = next(n for n in main.body if isinstance(n, ast.Try))
admit = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == "admit_volume")
index = next(i for i,n in enumerate(flow.body) if isinstance(n, ast.Assign) and any(isinstance(t,ast.Name) and t.id=="created_volume" for t in n.targets))
end = next(i for i in range(index,len(flow.body)) if isinstance(flow.body[i],ast.Assign) and any(isinstance(t,ast.Name) and t.id=="user" for t in flow.body[i].targets))
stage = ast.Module(body=flow.body[index:end+1],type_ignores=[])
volume = "p07-key-isolation-20261013-01"
now = datetime.datetime(2026,10,13,13,45,tzinfo=datetime.timezone.utc).timestamp()
results=[]
for name,stamp,allowed in (
    ("raced_historical_metadata_denied_before_seed","2020-01-01T00:00:00Z",False),
    ("raced_invalid_metadata_denied_before_seed","INVALID",False),
    ("fresh_creation_admitted_before_seed","2026-10-13T13:45:00Z",True),
):
    events=[]
    candidate=volume+" "+stamp+" 20261013-01"
    def run(argv):
        events.append("metadata_native_model")
        return candidate if "inspect" in argv else volume
    def seed(*a,**kw):
        events.append("seed")
        return "1000:1000"
    ns={"datetime":datetime,"math":math,"VOLUME":volume,"DOCKER":[],"LABEL":"model-label",
        "time":SimpleNamespace(time=lambda:now+.1),"run":run,"container":seed,
        "IMAGE":"model-image","NAMES":["model-seed"],"synthetic":"RAM_ONLY_DIRECTORY",
        "volume_identity":None}
    exec(compile(ast.Module(body=[admit],type_ignores=[]),str(source),"exec"),ns)
    try:
        exec(compile(stage,str(source),"exec"),ns)
    except (ValueError,RuntimeError):
        assert not allowed and "seed" not in events and ns["volume_identity"] is None
    else:
        assert allowed and events[-1]=="seed" and ns["volume_identity"]==candidate
    results.append({"case":name,"status":"PASS","native":False})
Path(__file__).with_name("before-seed-join.safe.json").write_text(json.dumps({
    "scope":"EXACT_MAIN_ADMISSION_ASSIGNMENT_BEFORE_SEED_RAM_ONLY","cases":results,
    "same_second_foreign_matching_label_ownership":"NOT_PROVEN_EXCLUDED_BY_NAMESPACE_COORDINATION_ONLY"
},indent=2)+"\n")
print(json.dumps({"before_seed_actual_AST_controls":len(results),"native":"NOT_RUN"}))
