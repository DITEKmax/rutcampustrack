import fs from 'node:fs'
import { createRequire } from 'node:module'
import { createHash } from 'node:crypto'
const root='/workspace/rct-worktrees/ci-academic-heap'
const scratch='/workspace/scratch/rct-validation/authored_format_current/vue-eslint-correction'
const require=createRequire(`${root}/frontends/package.json`)
const sfc=require('@vue/compiler-sfc'),dom=require('@vue/compiler-dom')
process.argv[2]='library'
const {vue,firstDelta}=await import('../prettier-final/verify-meaning.mjs')
const code=fs.readFileSync(`${scratch}/probe-block-pipeline.mjs`,'utf8')
const section=code.slice(code.indexOf('function foldConstantDisplay'),code.indexOf('const rows='))
const {normalizeConstantDisplay}=new Function(section+';return {normalizeConstantDisplay}')()
const proposal=JSON.parse(fs.readFileSync(`${scratch}/block-pipeline-probe.safe.json`,'utf8'))
const rows=[]
for(const entry of proposal.preservations) {
 const file=`${root}/${entry.path}`,original=fs.readFileSync(file,'utf8'),stat=fs.statSync(file)
 if(stat.nlink!==1)throw new Error(`COW_REQUIRED ${entry.path}`)
 const template=sfc.parse(original,{filename:file}).descriptor.template
 const tree=dom.parse(template.content,{comments:false,whitespace:'condense'}),nodes=[]
 const visit=node=>{if(node.type===2)nodes.push(node);for(const child of node.children??[])visit(child)}
 visit(tree)
 const counts=new Map()
 for(const edit of entry.edits)counts.set(edit.original,(counts.get(edit.original)??0)+1)
 const edits=[]
 for(const [value,count] of counts) {
  const found=nodes.filter(n=>n.content===value)
  if(found.length!==count)throw new Error(`COUNT ${entry.path} ${value}: ${found.length} != ${count}`)
  for(const n of found)edits.push({start:template.loc.start.offset+n.loc.start.offset,end:template.loc.start.offset+n.loc.end.offset,value:`{{ ${JSON.stringify(value)} }}`})
 }
 let updated=original
 for(const edit of edits.sort((a,b)=>b.start-a.start))updated=updated.slice(0,edit.start)+edit.value+updated.slice(edit.end)
 const a=normalizeConstantDisplay(await vue(original,entry.path)),b=normalizeConstantDisplay(await vue(updated,entry.path))
 const delta=firstDelta(a,b)
 if(delta)throw new Error(`MEANING ${entry.path} ${delta}`)
 fs.mkdirSync(`${scratch}/literal-before/${entry.path}`.slice(0,`${scratch}/literal-before/${entry.path}`.lastIndexOf('/')),{recursive:true,mode:0o700})
 fs.writeFileSync(`${scratch}/literal-before/${entry.path}`,original,{mode:0o600})
 fs.writeFileSync(file,updated)
 rows.push({path:entry.path,nodes:edits.length,nlink:stat.nlink,modeBefore:stat.mode&0o777,modeAfter:fs.statSync(file).mode&0o777,meaningEqual:true,
 before_sha256:createHash('sha256').update(original).digest('hex'),after_sha256:createHash('sha256').update(updated).digest('hex')})
}
fs.writeFileSync(`${scratch}/literal-preservation-source.safe.json`,JSON.stringify({files:rows.length,nodes:rows.reduce((n,r)=>n+r.nodes,0),rows},null,2)+'\n',{mode:0o600})
console.log(JSON.stringify({files:rows.length,nodes:rows.reduce((n,r)=>n+r.nodes,0)}))
