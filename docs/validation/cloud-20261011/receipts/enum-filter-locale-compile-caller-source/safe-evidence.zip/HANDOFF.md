COMPILE_ONLY_SOURCE_READY, nativeNOT_GRANTED/NOT_RUN.
Driver run-compile.py SHA74806f5b77c15514c05006cf6941908f7dd9c369bf1876d7518b001590ffac2e.
Exactargv in READY; cached offline Gradle8.12 task-specific compileTestJava --rerun, no --rerun-tasks/fullsuite/test/API/Docker.
Pinned b78 guard; direct foreground DEVNULL stdout/stderr; one Gradle/maxworker1.
JDK21 ENV pin21.0.12.1 release/java bytes +JDKpinSHA d09ca2db...;1898 Gradle/API/services/proto/build inputs, two protected ENV/key metadataonly.
WT4c test5a4a/sourceprod4f62 andRoottwo original bytechecks before/after; actualtargetmethod name proven.
Fresh targetclass+two record classes absentbefore and SHA/mtime/mode/nlink afterrequired, allowned b78 births/reap terminal preserved; postflight source failure retains actualnative status.
Root must write NEW exact private600 grant under receipts and remeasurecaps/floors. TemplateauthorizedFALSE is not a grant.
Command: python3 run-compile.py /absolute/Root/receipts/private-grant.json GRANT_SHA256
No test/Docker/API native until later separateRootgrant; originalprod staysoriginal untilmeaningfulcausalRED.
Current syntax PythonAST only; no helper/Gradle/JVM run. New actualRED caller/projection+volumecapture preparation will follow separately; this driver cannot run it.
