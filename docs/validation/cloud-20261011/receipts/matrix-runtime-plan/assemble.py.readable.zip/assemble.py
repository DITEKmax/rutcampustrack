import csv
import hashlib
import json
from pathlib import Path
import zipfile

ROOT = Path('/workspace/rutcampustrack')
TASK = ROOT / 'docs/validation/cloud-20261011'
OLD = TASK / 'receipts/matrix-evidence-reconciliation'
OUT = Path('/workspace/scratch/rct-validation/matrix_runtime_plan')
REV = '2a23969a69fee28bb5adc51ee7d4c0ef6baf6362'

def read_json(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))

def read_csv(path):
    return list(csv.DictReader(path.open(encoding='utf-8-sig')))

def save(name, value):
    (OUT / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')

families = read_csv(TASK / 'scenarios.csv')
boundaries = read_csv(TASK / 'boundary-scenarios.csv')
cases = read_csv(TASK / 'verified-cases.csv')
queue = read_json(OLD / 'remaining-execution-queue.json')['entries']
boundary_map = read_json(OLD / 'boundary-coverage.json')
with zipfile.ZipFile(OLD / 'large-reconciliation-outputs.zip') as archive:
    family_map = json.loads(archive.read('family-coverage.json'))
    assertions = json.loads(archive.read('known-test-assertion-catalog.json'))
requests = read_json(OLD / 'request-scope-reconciliation.json')
research = read_json(OLD / 'research-dispositions.json')
stories = read_json(ROOT / 'docs/product/job-stories.yaml')['stories']
raw_requests = read_json(ROOT / 'docs/implementation/backend-delta.yaml')['requests']
story_links = read_json(ROOT / 'docs/implementation/story-backend-map.yaml')['links']

# Slices are finite observable invariants, not a role x client x format campaign.
SLICES = {
 'AUTH-SESSION': ['multi-role explicit selection/default and terminal-role independence', 'refresh rotation winner/foreign-session isolation', 'committed grant/password revoke + durable restart + unavailable authority'],
 'AUTH-PASSWORD-OTP': ['OTP login versus password_reset purpose/120s/attempts/one consume', 'wrong-old and successful change/reset hash + clear initial + revoke all sessions', 'accepted display grant boundary; safe errors/logs/no-store; Unicode/byte limits'],
 'AUTH-QR-TMA': ['QR issuer proof/approver live grant/one exchange/expired superseded proof', 'remaining duplicate/tampered TMA parser and revoked-binding admission', 'public fixed/chunked 4096-byte bound and rate controls'],
 'AUTH-WS-TICKET': ['one ticket concurrent winner/30s/expiry/logout-before-consume', 'issue/clear cookie attributes and applicable Origin/CORS/CSRF'],
 'ACADEMIC-ADMIN': ['12 distinct capability guards/dependencies + protected active ADMIN target', 'stale actor/last FULL concurrent winner', 'single stable login/add role/collision + archive/restore without grants'],
 'ACADEMIC-GROUPS': ['dated transfer/backfill retains explicit marks', 'headman replacement/natural departure atomically revokes helpers', 'filter/order/count/ties + once-only spring promotion/catchup/new-group exclusion'],
 'ACADEMIC-SEMESTER': ['zero/one activation and archive/restore/extension invariants', 'each distinct accepted archive writer/participant barrier', 'delete preview/proof/digest/durable same-key retry with real Schedule/Attendance'],
 'ACADEMIC-ASSIGNMENT': ['current merged teacher subject publication query + typed-RPC transfer fence', 'overlap one winner + replacement/terminal close/history + real participant retry', 'subject/type delete intent and live current teacher-group scope versus historical-only denial'],
 'ACADEMIC-HOMEWORK': ['STUDENT MANAGE_HOMEWORK helper nonauthor gateway→Schedule→Academic create/edit/history', 'cutoff/binding/transfer/archive/replay preserves completion; local rollback/outbox', 'own completion race and foreign owner denial'],
 'ACADEMIC-MAP': ['real upload/read/history/old link + partial replace/delete failure without data loss', 'D008 exact decoded bytes/pass-row/Adam7/overflow boundaries without publication; reuse existing accepted IT', 'actual browser sanitized SVG no script/external fetch and PNG download'],
 'ACADEMIC-CACHE-DTO': ['actual allowed DTO/date/collection roundtrip and foreign @class rejection', 'actor-scoped cold/warm/mutation/rollback/revoke isolation', 'remaining enum unknown/null/legacy/transition consumers; no L05 performance target'],
 'SCHEDULE-CLOCK-GENERATION': ['8 Moscow slots/parity/date exact bounds and retrospective generation', 'remove/re-add gap keeps old lesson IDs + one-off unique winner', 'actual scheduled start/close/catchup using educational clock separate from security clock'],
 'SCHEDULE-TRANSFER-CANCEL': ['real transfer epoch/participant partial failure/same-key recovery', 'cancel/history/excluded metric/homework archive + restore empty current teacher', 'room ID/history/ETag + protective per-item mutable snapshot guard'],
 'ATTENDANCE-CHECKIN': ['public geo success/far/GPS/error/inclusive window + no optimistic mark', 'D005 manual ABSENT rejects before geofence/automatic-request and snapshot disables', 'geo/manual/close race + one durable receipt + state/outbox rollback'],
 'ATTENDANCE-REQUESTS': ['automatic no-quota/no-expiry versus manual five submissions/one charge/no refund/increase', 'MANAGE_EXCUSES delayed decision/terminal/retry/present-preservation/cancel races', 'own/teacher/headman permitted attachment bytes versus foreign/expired/traversal denial'],
 'ATTENDANCE-READ-REPORT': ['zero denominator/rounding/dated cohort/rank/type journal alignment', 'named VIEW_STATS helper statistics allowed but roster denied', 'active teacher group full history + foreign/historical-only scope denial'],
 'ATTENDANCE-PARTICIPANTS': ['real Mongo/Rabbit transfer/archive/delete receipt/ACK/retry/DLQ/epoch', 'mismatched key/payload + owner-only file/history purge', 'resume interrupted durable operation after fresh restore'],
 'ATTENDANCE-CACHE': ['real Academic DB activation/archive with absent event then current Attendance command/read', 'geofence cold/TTL/stale/outage control', 'client explicit degraded state; existing L02 seam not rerun'],
 'NOTIFICATION-PREFERENCES-HISTORY': ['Mongo durable preferences/adoption/revision race survives Redis restart', 'dated audience/history one recipient effect and foreign privacy', 'authority unavailable defers work; changed live binding before send'],
 'NOTIFICATION-WS-PUSH': ['real ticket handshake/private subscribe rejection + open socket revoke denies next event', 'reconnect and own push subscription/cleanup boundary', 'device push receipt separate from synthetic provider transport'],
 'BOT-DELIVERY': ['real Rabbit claim→durable effect→ACK + restart/redelivery/retry/DLQ', '429 then fresh audience/binding/preference authority; prepared-intent restart', 'NP01 first private /start own card actual TLS/Python/provider + denial boundaries', 'NP01 actual Auth password.changed v2→Rabbit→bot durable claim/cleanup/ACK; v1 compatibility', 'NP01 response loss/inflight edit/event-before-register/stale CAS/rebinding cleanup exact card state'],
 'BFF-CONTRACT-HTTP': ['deployed HTTP→signed actual domain gRPC with live grants, spoofed header denial', 'private ETag200→304→new scoped version + no-store', 'public DTO/null/unknown enums + forbidden read-only mutations + file metadata'],
 'RENDERER': ['current genuine native image/static-secret private edge + domain model→converter→download only; reuse accepted native/process proof'],
 'SHARED-SECURITY-ERRORS': ['actual targeted JWT algorithm/issuer/audience/purpose and caller→target→method/TLS', 'safe sensitive response/log RFC9457 + correlation; reachable oversized direct Auth', 'public Actuator/private native renderer boundary; no blanket protected RPC claim'],
 'SHARED-OUTBOX': ['distinct changed consumer durable claim/effect/ACK/redelivery/restart + transaction rollback; reuse academic broker acceptance'],
 'MIGRATIONS': ['disposable current clean schema + synthetic historical upgrade/constraints/index/sequence', 'stable DB/proto/TS enum roundtrip/unknown/legacy/transition and V57 NP01 state; selective meaningful sensitivity'],
 'HEALTH-OUTAGE': ['actual routed user failure/recovery for authority/Rabbit/DB/renderer', 'bounded deadline/status and private readiness/Actuator; no SLA invented'],
 'RECOVERY': ['actual quiesced capture/checksum/fresh PG+Mongo+files restore', 'restored app pending transfer resumes once with schema/index/sequence/history/file identity'],
 'SECURITY2-ACCEPTANCE': ['reconcile accepted SB01–SB06 finite cases/current relevant dependencies; no old pending-review rerun', 'remaining changed async proof/NP01 credential consumer checks via owning groups'],
 'SCHEMA-OWNER-L08': ['Academic sole migration owner/Auth consumer manifest including V57 tracker + Auth generations', 'reuse qualified local fence/rollback proofs; current historical upgrade and changed NP01 atomicity'],
 'DASHBOARD-ACTIVITY': ['FULL and LIMITED DASHBOARD_VIEW allowed + revoked/missing denied', 'actual composite counts/action-time Moscow yesterday/all-time/no false zero when source absent'],
 'PUBLIC-RETIRED-NEGATIVE': ['public retired FREE_ATTENDANCE/unknown enum typed4xx + no state/outbox; legacy410 and historic compatible row'],
 'EXPORT-ASYNC-CORE': ['actual accepted initiation/job→worker→native renderer→ready private event→authorised bytes', 'renderer fail/error/retry/foreign owner/live revoke at init/read/download', 'reconcile per-job audit correction before current full Auth remote gate'],
 'EXPORT-HEADMAN-MODELS': ['own HEADMAN and VIEW_STATS helper weekly distinct selectedweeks model', 'subject×actualtypes distinct journal dated roster/same-day/cancelled/future', 'five formats each distinct table model with content parity/context/order'],
 'EXPORT-STATS-TEACHER-MODELS': ['headman group/subject summary tables and PNG/HTML graph', 'teacher subject journal/student summary/group summary full semester blank future columns and current pastOnly selector', 'live active group scope/foreign and historical-only denied; full sorted filtered unpaged content'],
 'EXPORT-ROSTER-ADMIN-MODELS': ['HEADMAN exact own roster number/name/login/group-role/group/Moscowdate; VIEW_STATS helper denied', 'FULL users/groups versus LIMITED USERS_VIEW/GROUPS_VIEW filtered unpaged five formats', 'TelegramID FULL only; no password/recovery; actor/time/kind/rowcount audit + live revoke'],
 'CLIENT-AUTH-ROLES': ['production Vue PWA + synthetic signed TMA correct defaults/explicit role/reload', 'expiry/one refresh/logout/revocation/terminal role error recovery', 'change/reset/OTP/profile/session history and Telegram binding public flows'],
 'CLIENT-STUDENT-GEO-REQUESTS': ['Moscow in-window real success/server acknowledgement, GPS/network/disabled and D005', 'automatic/manual quota/reason/file request persists and actual headman decision'],
 'CLIENT-HOMEWORK': ['own completion/reload/foreign scope/optimistic failure/focus/order', 'HEADMAN or STUDENT MANAGE_HOMEWORK nonauthor create/edit/history/next lesson/transfer', 'escaped text and external primary-link policy'],
 'CLIENT-HEADMAN': ['real journal marking/geo block/queue decision/retry counters', 'recurring/oneoff/room/transfer/cancel/restore and subject/type/assignment', 'all five STUDENT helper capabilities separately including VIEW_STATS denial of roster/credentials; revoke after render', 'own roster/student reset-link (no adjacent student-profile edits)'],
 'CLIENT-TEACHER': ['today/day/catalog/full group historic journal/read-only request/bytes', 'sort/filter/page/stats/export selector; foreign/historical-only and any write denied'],
 'CLIENT-ADMIN': ['actual ready mobile FULL/LIMITED guardgroups/dashboard/users/groups/semester/maps/credentials/binding', 'missing/revoked/dependent grant/control targets and no server effect', 'no in-product admin-self recovery/new web panel'],
 'CLIENT-MAP-FILES-EXPORTS': ['actual map version/download/browser SVG safety + ticket expiry/foreign bytes', 'distinct export choose→ready hint/status→download filename/MIME/content; D004 legend excluded'],
 'CLIENT-NOTIFY': ['private inbox/read/settings/preferences/actions and open socket revoke', 'real scoped schedule version event refreshes Vue data'],
 'CLIENT-OFFLINE-D002': ['production service worker warm offline reload persistent own schedule/homework, security expiry still read-only', 'no writes/new attachments/role switching/TMA offline', 'authoritative reconnect after revoke + explicit logout + A→B late callback isolation'],
 'CLIENT-TMA-PROVIDER': ['real Vue synthetic signed host reuse/deep link/Back/download online', 'native Telegram launch/download actual external provider only when available; exact missing access receipt otherwise'],
 'CLIENT-INSTALL-PUSH': ['production manifest/SW install/update/standalone and iOS instruction/unsupported/optout', 'actual device private push/denial/unbind/current admission; Chromium does not prove Safari/native delivery'],
 'FINAL-FORMAT-PARSER-GATES': ['2663 current eligible authored inputs/37 exact preservation exclusions after semantic freeze', 'separate formatter/check/lint/parser/type/build and semantic review', 'all-three current remote gates + final local=remote=draftPRhead; D009 final-doc exact executable byte identity + handoff'],
}

entries = []
for q in queue:
    gid = q['id']
    routed_f = [f for f in family_map if gid in f['remaining_queue_ids']]
    routed_b = [b for b in boundary_map if gid in b['remaining_queue_ids']]
    proofs = []
    for c in q.get('known_assertion_candidates', []):
        path = ROOT / c['path']
        proofs.append({'path': str(path), 'class': c.get('class'), 'method': c.get('method'),
                       'source_exists': path.is_file(), 'method_text_exists': c.get('method','') in path.read_text(),
                       'level': c.get('level'), 'limits': c.get('fixture_resource_limits'), 'execution': 'NOT_RUN_BY_REVIEWER'})
    # Source roles are row-specific. Do not union grants into every routed story.
    entries.append({
        'id': gid, 'status': 'UNKNOWN', 'required': True, 'priority': q['priority'],
        'proof_revision_required': 'root final integrated semantic freeze + current relevant source/artifact dependency hashes',
        'input_revision': REV, 'source_family_ids': [f['id'] for f in routed_f],
        'source_boundary_ids': [b['id'] for b in routed_b],
        'source_request_ids': [r['request_id'] for r in requests if gid in r['associated_queue_ids']],
        'source_paths': sorted(set(ref for f in routed_f for ref in f['source'])),
        'source_ids_and_roles_states_risks': [{k:b[k] for k in ['id','source_ids','source_refs','actor_grants','client','prestate','action','expected_observable','forbidden_or_invariant']} for b in routed_b],
        'role_client_rule': 'Actor/client/state fields apply to the exact row only; no cartesian product, no granting combined capabilities to one helper.',
        'finite_execution_slices': SLICES[gid],
        'historical_remaining_oracle': q['remaining_observable_oracle'],
        'newproof_minimum': SLICES[gid],
        'candidate_existing_proof_paths': proofs,
        'historical_proposed_commands': q.get('proposed_commands_NOT_EXECUTED', []),
        'command_admission': 'NOT AUTHORIZED BY THIS REPORT. Root chooses exact selected methods; current heavy budget max-workers=1/768MiB overrides stale max-workers=2 proposals. Existing real-mobile launch covers exactly eight flows; never every CLIENT group.',
        'qualification': 'Historical finite cases are retained at their actual producer/seam. This report does not promote a family, boundary or current run to PASS.',
    })

ids = {q['id'] for q in queue}
checks = {
    'input_revision': REV, 'baseline': '3908fad9624f97aec8891fc79338ceb6b0616bf3',
    'families': len(families), 'boundaries': len(boundaries), 'finite_PASS_rows': len(cases),
    'story_source_rows': len(stories), 'request_source_rows': len(raw_requests), 'existing_story_links':len(story_links),
    'queue_groups': len(entries), 'required_family_map_rows': sum(x['required'] for x in family_map),
    'explicit_family_exclusions': [x['id'] for x in family_map if x['proposed_family_status']=='EXCLUDED'],
    'optional_research_rows': [x['id'] for x in family_map if not x['required'] and x['proposed_family_status']!='EXCLUDED'],
    'unmapped_required_families': [x['id'] for x in family_map if x['required'] and not x['remaining_queue_ids']],
    'unmapped_boundaries': [x['id'] for x in boundary_map if not x['remaining_queue_ids']],
    'dangling_queue_ids': sorted({i for x in family_map+boundary_map for i in x['remaining_queue_ids']} - ids),
    'L_P_ids': [x['id'] for x in research],
    'missing_L_P_ids': sorted(({f'L{i:02}' for i in range(1,9)} | {f'P{i:02}' for i in range(1,22)}) - {x['id'] for x in research}),
    'candidate_existing_proofs': sum(len(e['candidate_existing_proof_paths']) for e in entries),
    'missing_candidate_path_or_method': [x for e in entries for x in e['candidate_existing_proof_paths'] if not x['source_exists'] or not x['method_text_exists']],
    'whole_family_PASS_promotions': 0, 'whole_boundary_PASS_promotions': 0, 'runtime': 'NOT_RUN',
    'check_kind': 'read-only structured parsing/referential checks + critical source inspection; no product acceptance',
}

equivalence = []
inputs = read_json(OLD/'source-equivalence.json')
for x in inputs:
    p=ROOT/x['path']
    expected=x.get('latest_root_sha256', x['integrated_sha256'])
    actual=hashlib.sha256(p.read_bytes()).hexdigest()
    equivalence.append({'origin':'matrix42','path':str(p),'prior_qualified_sha256':expected,'current_sha256':actual,'equal':actual==expected})
fin=read_json(TASK/'receipts/finite-evidence-reconciliation/source-equivalence.json')
for x in fin['checks']:
    p=ROOT/x['path']; actual=hashlib.sha256(p.read_bytes()).hexdigest()
    equivalence.append({'origin':'finite','scope':x['scope'],'path':str(p),'prior_qualified_sha256':x['current_sha256'],'current_sha256':actual,'equal':actual==x['current_sha256']})
checks['qualified_direct_source_checks']=len(equivalence)
checks['qualified_direct_source_changes']=sum(not x['equal'] for x in equivalence)
checks['dependency_limit']='Direct source byte equality does not prove unchanged transitive Spring/classpath/config/generated/common consumers; changed teaching clocks/export/NP01 contracts require group-specific artifact/source manifests.'

save('remaining-groups.json', {'schema':1, 'scope':'48 finite group proposals enriched; NOT_RUN','entries':entries})
save('family-state-oracles.json', [{k:f[k] for k in ['id','kind','source','decision','role_grants','client','prestate','action','expected','forbidden','status','exclusion']} for f in families])
save('completeness-checks.json', checks)
save('qualified-direct-source-equivalence.json', equivalence)
save('finite-case-qualifications.json', [{'id':c['id'],'producer_revision':c['revision'],'parents':c['parent_family_ids'],'boundaries':c['parent_boundary_ids'],'evidence':c['evidence'],'limits':c['limits'],'current_reuse':'retain exact historical PASS; relevant transitive dependencies not globally qualified at current revision'} for c in cases])
save('research-dispositions.json', {'original_dispositions':research,'current_overlays':[
 {'ids':['L03','L04','P10','P17'],'change':'SB finite fixes now accepted; remove historical SECURITY2 pending-review blocker only, retain remaining public/provider/client/consumer oracles'},
 {'ids':['L05'],'change':'T001 source fixed/integrated, case actual c115 and source merge reviewed; two current merged query/RPC selected cases remain pending; optimization optional'},
 {'ids':['L08','P12','P18','P21'],'change':'T002/V57 changes add tracker/generation/current producer and bot-consumer compatibility/atomicity/broker/TLS seams; old source manifest alone insufficient'}]})

opened = [TASK/n for n in ['TASK-CONTRACT.md','CURRENT.md','decisions.md','questions.md','resources.md','packet-matrix-runtime-plan.md','scenarios.csv','boundary-scenarios.csv','verified-cases.csv','source-ledger.json']]
opened += [ROOT/n for n in ['AGENTS.md','.agent/orchestration-v2/RULES.md','docs/product/READINESS.md','docs/agent-workflow.md','docs/product/job-stories.yaml','docs/implementation/backend-delta.yaml','docs/implementation/story-backend-map.yaml','tests/e2e/REAL-MOBILE.md','tests/e2e/playwright.real-mobile.config.ts','tests/e2e/specs/mobile-real-server.spec.ts','docs/product/decisions/2026-10-08-limited-administrators.md','services/academic-service/academic-app/src/main/java/ru/rutcampustrack/academic/map/CampusMapAdminService.java','services/academic-service/academic-app/src/test/java/ru/rutcampustrack/academic/map/CampusMapFileBoundaryIT.java']]
save('input-source-manifest.json',[{'path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size,'read_kind':'structured full parse or critical fragments; hash proves byte identity only'} for p in opened])
print(json.dumps(checks,ensure_ascii=False))
