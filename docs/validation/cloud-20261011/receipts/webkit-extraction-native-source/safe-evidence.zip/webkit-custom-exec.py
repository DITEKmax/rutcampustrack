#!/usr/bin/python3 -I
"""Supported custom executablePath: one genuine MiniBrowser exec, fresh grant only."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import re
import stat
import sys
import types
OWN=Path(__file__).parent
PREFIX=Path('/tmp/rct-webkit-native-deps-20261012')
CACHE=Path('/tmp/rct-validation-browsers-20261012/webkit-2272')
SAFE_ENV={'PATH','LANG','LC_ALL','HOME','TMPDIR','XDG_CONFIG_HOME','XDG_CACHE_HOME'}
def sha(p):
    h=hashlib.sha256()
    with Path(p).open('rb') as f:
        for block in iter(lambda:f.read(1048576),b''):h.update(block)
    return h.hexdigest()
def regular(path):
    raw=str(path);path=Path(raw)
    if not path.is_absolute() or str(path)!=raw or '..' in path.parts:raise RuntimeError('Exact lexical wrapper input required')
    for p in reversed(path.parents):
        if not stat.S_ISDIR(p.lstat().st_mode):raise RuntimeError('Wrapper symlink ancestor denied')
    if not stat.S_ISREG(path.lstat().st_mode):raise RuntimeError('Wrapper exact regular input required')
    return path
def validate_browser_grant(g,now):
    expected={'browser_launch_authorized':True,'library_extraction_authorized':False,'native_validation_authorized':False,'execution_actor_uid':1000,'execution_actor_gid':1000}
    if any(type(g.get(k)) is not type(v) or g[k]!=v for k,v in expected.items()):raise RuntimeError('NEW exact browser-only Root grant required')
    start=datetime.datetime.fromisoformat(g['not_before_utc']);stop=datetime.datetime.fromisoformat(g['stop_utc'])
    if start.utcoffset()!=datetime.timedelta(0) or stop.utcoffset()!=datetime.timedelta(0) or not start<=now<stop or not 0<(stop-start).total_seconds()<=1800:raise RuntimeError('Fresh bounded browser grant required')
    env=g['declared_browser_environment']
    if not isinstance(env,dict) or set(env)-SAFE_ENV or not all(isinstance(v,str) for v in env.values()):raise RuntimeError('Explicit safe browser child environment required')
    return env
def validate_effective_proof(proof,expected_cases):
    if (proof.get('status')!='PASS_EFFECTIVE_NATIVE_AVAILABILITY_ONLY' or type(proof.get('loader_count')) is not int or proof.get('loader_count')!=39
            or proof.get('actual_GLES_dlopen') is not True or proof.get('actual_x264_dlopen_symbol') is not True
            or proof.get('version_errors') is not False):raise RuntimeError('Actual full native proof required')
    rows=proof.get('results',[])
    actual=[(r.get('target'),r.get('variant'),r.get('kind')) for r in rows]
    if len(rows)!=43 or len(set(actual))!=43 or set(actual)!=set(expected_cases) or any(r.get('pass') is not True for r in rows):raise RuntimeError('Exact39loader+fourvariantdlopen proofs required')
def main():
    if os.getuid()!=1000 or os.getgid()!=1000:raise RuntimeError('Exact actor1000 required')
    grant_path=regular(OWN/'private/browser-grant.json');metadata=grant_path.lstat()
    if metadata.st_uid!=1000 or metadata.st_nlink!=1 or stat.S_IMODE(metadata.st_mode)!=0o600 or metadata.st_size>65536:raise RuntimeError('NEW own Root browser grant600 required')
    grant=json.loads(grant_path.read_text());env=validate_browser_grant(grant,datetime.datetime.now(datetime.timezone.utc))
    if sha(OWN/'manifest.json')!=grant['source_manifest_sha256']:raise RuntimeError('Exact reviewed wrapper source seal required')
    files=json.loads((OWN/'manifest.json').read_text())['files']
    if not any(r['path']==str(Path(__file__).absolute()) and r['sha256']==sha(__file__) for r in files):raise RuntimeError('Actual wrapper must be sealed')
    for row in files:
        if sha(regular(row['path']))!=row['sha256']:raise RuntimeError('Wrapper/source/procedure changed')
    if sha(regular(grant['source_review_manifest']))!=grant['source_review_manifest_sha256']:raise RuntimeError('Fresh exact independent wrapper review required')
    proof_path=regular(grant['native_validation_receipt'])
    if proof_path.name!='native-validation.safe.json' or proof_path.parent.parent!=OWN/'runtime' or not re.fullmatch(r'native-[a-z0-9-]{1,32}',proof_path.parent.name):raise RuntimeError('Exact actual native proof namespace required')
    if sha(proof_path)!=grant['native_validation_receipt_sha256']:raise RuntimeError('Exact Root-bound actual native proof required')
    # Open proof output ancestors through exact nofollow descriptors before using it.
    paths=types.ModuleType('own_paths');paths.__file__=str(OWN/'own-paths.py');exec(compile((OWN/'own-paths.py').read_bytes(),paths.__file__,'exec'),paths.__dict__)
    out=paths.Output(proof_path.parent)
    try:
        out.check();proof=json.loads(proof_path.read_text())
        selected=json.loads((OWN/'selected-dso-headers.safe.json').read_text())['selected']
        vendor=json.loads((OWN/'native-validation-procedure.safe.json').read_text())['upstream25_ELF_4shell']
        expected=[(r['path'],'minibrowser-wpe' if '/minibrowser-wpe/' in r['path'] else 'minibrowser-gtk','loader') for r in vendor if r['elf']]
        expected += [(str(PREFIX/r['name']),'package','loader') for r in selected if r['kind']=='regular']
        expected += [(target,variant,kind) for variant in ['minibrowser-wpe','minibrowser-gtk'] for target,kind in [(str(PREFIX/'usr/lib/x86_64-linux-gnu/libGLESv2.so.2'),'gles'),('/usr/lib/x86_64-linux-gnu/libx264.so.164','x264')]]
        validate_effective_proof(proof,expected)
        if proof['source_manifest_sha256']!=grant['source_manifest_sha256']:raise RuntimeError('Native proof belongs to different source')
        for row in proof['results']:
            if sha(regular(row['safe_result']))!=row['sha256']:raise RuntimeError('Actual native subproof changed')
        for row in vendor:
            if sha(row['path'])!=row['sha256']:raise RuntimeError('Genuine browser bytes changed')
        for row in proof['copied_regular']:
            p=regular(row['path']);s=p.lstat()
            if s.st_uid!=1000 or s.st_nlink!=1 or stat.S_IMODE(s.st_mode)!=0o644 or s.st_size!=row['bytes'] or sha(p)!=row['sha256']:raise RuntimeError('Native DSO identity changed')
        for row in selected:
            if row['kind']=='symlink':
                p=PREFIX/row['name'];s=p.lstat()
                if not stat.S_ISLNK(s.st_mode) or s.st_uid!=1000 or os.readlink(p)!=row['link']['target']:raise RuntimeError('Native relativeSONAME link changed')
        for base in ['/workspace','/tmp']:
            f=os.statvfs(base)
            if f.f_bavail*f.f_frsize<4294967296:raise RuntimeError('Browser resource diskfloor')
        memory=int(Path('/sys/fs/cgroup/memory.current').read_text());limit=int(Path('/sys/fs/cgroup/memory.max').read_text())
        if memory>=16106127360 or limit-memory<1073741824:raise RuntimeError('Browser sharedresource reserve')
        for fd in [3,4]:os.fstat(fd)
        mapping=types.ModuleType('mapping');exec(compile((OWN/'custom-executable-proposal.py').read_bytes(),'mapping','exec'),mapping.__dict__)
        required={'all_upstream_ELF_closure','version_symbols','GLES_actual_dlopen','x264_actual_capability','package_signature_hashes_modes','cache_byte_identity'}
        executable,argv,child_env=mapping.prepare_child(sys.argv[1:],env,{k:True for k in required})
        out.check()
        os.execve(executable,argv,child_env)
    finally:out.close()
if __name__=='__main__':main()
