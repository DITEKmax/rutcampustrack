from pathlib import Path
import datetime,json,os,stat
OWN=Path(__file__).parent
BASE=OWN.parents[1]
r=json.loads((OWN/'preflight.safe.json').read_text())
specs=json.loads((BASE/'current_academic_stage_completion_prepare/actual-completion01/host-service-specs.safe.json').read_text())
for row in r['host7_classpath_metadata']:
 if not row['available_readable_nosymlink']:
  spec=next(s for s in specs if s['service']==row['service'])
  path=Path(spec['cwd'])/'org/springframework/boot/loader/launch/JarLauncher.class'
  m=path.lstat();row['classpath_style']='genuine-default-cwd-JarLauncher'
  row['available_readable_nosymlink']=('org.springframework.boot.loader.launch.JarLauncher' in spec['argv'] and stat.S_ISREG(m.st_mode) and os.access(path,os.R_OK))
  row['loader_device']=m.st_dev;row['loader_inode']=m.st_ino
ok=all(x['available_readable_nosymlink'] for x in r['host7_classpath_metadata'])
r['checks']['host7_app_cwds_and_declaredclasspath_readable']=ok
r['blockers']=[k for k,v in r['checks'].items() if not v]
r['finished_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat()
r['resources_final']={'workspace_free':os.statvfs('/workspace').f_bavail*os.statvfs('/workspace').f_frsize,'tmp_free':os.statvfs('/tmp').f_bavail*os.statvfs('/tmp').f_frsize,'shared':int(Path('/sys/fs/cgroup/memory.current').read_text()),'maximum':int(Path('/sys/fs/cgroup/memory.max').read_text())}
v=r['resources_final'];ok=v['workspace_free']>=9380818650 and v['tmp_free']>=5368709120 and v['shared']<16106127360 and v['maximum']-v['shared']>=1073741824
r['checks']['fresh_final_resource_barrier']=ok
if not ok:r['blockers'].append('fresh_final_resource_barrier')
r['disposition']='READY_READONLY_METADATA_ONLY' if not r['blockers'] else 'BLOCKED_EXACT_METADATA_GATE'
(OWN/'preflight.safe.json').write_text(json.dumps(r,indent=2)+'\n')
print(json.dumps({'disposition':r['disposition'],'blockers':r['blockers'],'resources_final':v,'checks':r['checks'],'finished_utc':r['finished_utc']}))
