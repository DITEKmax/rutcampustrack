import fs from 'node:fs';
import {extname} from 'node:path';
const source=fs.readFileSync('/workspace/rct-worktrees/ci-academic-heap/scripts/format-authored.mjs','utf8');
const code=source.slice(source.indexOf('// Exact source/evidence copies'),source.indexOf('const inventory = tracked.map(classify)')).replace('export function classify','function classify');
const classify=new Function('extname',code+'\nreturn classify;')(extname);
const old=JSON.parse(fs.readFileSync('/workspace/scratch/rct-validation/authored_format_current/angular-owner-exclusion/inventory-after-D010.json','utf8'));
fs.writeFileSync('/workspace/scratch/rct-validation/nonangular_format_review/correction_recheck/current-inventory.pure.json',JSON.stringify(old.map(r=>classify(r.path)),null,2)+'\n');
console.log(JSON.stringify({files:old.length,subprocesses:false,mode:'exact current classifier definition evaluated on unchanged frozen path set'}));
