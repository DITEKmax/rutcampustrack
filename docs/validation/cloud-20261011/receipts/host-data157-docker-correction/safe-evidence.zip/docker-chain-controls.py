"""Full selected verifyRestart -> consumed fence -> mkdir boundary, no runtime/private grant."""
import ast
import copy
import datetime
import hashlib
import json
import types
from pathlib import Path
from unittest.mock import patch

OWN = Path(__file__).parent
OLD = OWN.parent / 'current_host_restart_data157_correction'
READ_TEXT = Path.read_text
checks = []

def selected(path):
    tree = ast.parse(path.read_text())
    main = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == 'main')
    begin = next(i for i, n in enumerate(main.body) if isinstance(n, ast.Assign)
        and isinstance(n.value, ast.Call) and ast.unparse(n.value.func) == 'boundary.verify_restart')
    nodes = main.body[begin:begin+3]
    assert ast.unparse(nodes[-1]).startswith('cohort = boundary.CohortDirectory(OUT, create=True)')
    return compile(ast.Module(body=nodes, type_ignores=[]), str(path), 'exec')

def exercise(label, root, want, altered=None):
    source = root / 'docker-up-restart.py'
    module = types.ModuleType('selected_real_boundary')
    module.__file__ = str(root / 'restart-boundary.py')
    exec(compile((root / 'restart-boundary.py').read_bytes(), module.__file__, 'exec'), module.__dict__)
    # NEW source has not been sealed yet. Mock only its public manifest bytes; all
    # actual selected verify_restart/source/prior/review/fixed-fence gates execute.
    manifest = root / 'manifest.json'
    if root == OWN:
        rows = [{'path': str(p), 'sha256': hashlib.sha256(p.read_bytes()).hexdigest()}
            for p in sorted(root.iterdir()) if p.is_file() and p.name != 'manifest.json']
        public_manifest = json.dumps({'files': rows})
    else:
        public_manifest = READ_TEXT(manifest)
    def read(path, *args, **kwargs):
        if root == OWN and path == manifest:
            return public_manifest
        return READ_TEXT(path, *args, **kwargs)
    original_sha = module.sha
    def sha(path):
        if root == OWN and Path(path) == manifest:
            return hashlib.sha256(public_manifest.encode()).hexdigest()
        return original_sha(path)
    module.sha = sha
    now = datetime.datetime.now(datetime.timezone.utc)
    review = OWN.parent / 'context_correction_review/manifest.json'
    grant = {'durable_restart_authorized': True, 'launch_authorized': True,
        'native_mongo_authorized': True, 'reuse_existing_mongo_db': str(module.DB),
        'reuse_existing_mongo_key': str(module.KEY), 'repeat_bootstrap_authorized': False,
        'data_reset_authorized': False, 'cohort_name': 'restart-source-control',
        'deadline_seconds': 120, 'not_before_utc': (now-datetime.timedelta(seconds=1)).isoformat(),
        'stop_utc': (now+datetime.timedelta(seconds=120)).isoformat(),
        'execution_actor_uid': 1000, 'execution_actor_gid': 1000,
        'restart_manifest_sha256': original_sha(module.PLAN / 'manifest.json'),
        'restart_ancestor_correction_manifest_sha256': hashlib.sha256(public_manifest.encode()).hexdigest(),
        'restart_review_manifest': str(review), 'restart_review_manifest_sha256': original_sha(review),
        'stopped_mongo_data_fence_path': str(module.DATA_FENCE),
        'stopped_mongo_data_fence_sha256': module.DATA_FENCE_SHA}
    if altered:
        grant[altered[0]] = altered[1]
    events = []
    def mkdir_boundary(path, create=False):
        assert create is True
        events.append('WOULD_CREATE_COHORT_ONLY_MOCKED')
        return None
    module.CohortDirectory = mkdir_boundary
    globals = {'boundary': module, 'grant': grant, '__file__': str(source),
        'PLAN': module.PLAN, 'json': json, 'Path': Path}
    accepted = False
    with patch.object(Path, 'read_text', read):
        try:
            exec(selected(source), globals)
            accepted = True
        except RuntimeError:
            pass
    assert accepted == want, label
    assert bool(events) == want, label
    checks.append({'case': label, 'pass': True, 'accepted_selected_chain': accepted,
        'mock_cohort_boundary_events': events, 'actual_directory_container_or_child_creation': False,
        'private_grant_ENV_key_DB_contents_reads': False})

exercise('original_b254_NEW_binding_then_OLD156_consumption_rejects_current157', OLD, False)
exercise('corrected_full_chain_NEW_binding_and_consumed157_reaches_mock_boundary', OWN, True)
for label, field, value in [
    ('old_fixed_path_denied', 'stopped_mongo_data_fence_path', str(OLD / 'stopped-native-data-fence157.safe.json')),
    ('old156_path_denied', 'stopped_mongo_data_fence_path', str(OWN.parent / 'current_host_restart_plan/stopped-native-data-fence.safe.json')),
    ('wrong_SHA_denied', 'stopped_mongo_data_fence_sha256', '0'*64),
    ('missing_path_denied', 'stopped_mongo_data_fence_path', None),
    ('missing_SHA_denied', 'stopped_mongo_data_fence_sha256', None),
    ('wrong_actor_grant_denied', 'execution_actor_uid', 0),
]:
    exercise(label, OWN, False, (field, value))
tree = ast.parse((OWN / 'docker-up-restart.py').read_text())
assert any(isinstance(n, ast.Assert) and '9380818650' in ast.unparse(n.test) for n in ast.walk(tree))
(OWN / 'docker-chain-controls.safe.json').write_text(json.dumps({'status': 'PASS_FULL_SELECTED_DOCKER_FENCE_CALL_CHAIN',
    'count': len(checks), 'checks': checks, 'unchanged_workspace_budget': 9380818650,
    'selection': 'real verify_restart/all source-prior-review-fence gates -> actual consumed fence metadata equality -> mocked cohort boundary',
    'mocked_inputs': 'Only unsealed NEW public manifest bytes and CohortDirectory creation; grant is public synthetic control, not Root runtime grant',
    'capacity_or_runtime_PASS': False}, indent=2) + '\n')
print(json.dumps({'selected_full_chain_controls': len(checks), 'no_runtime_or_private_reads': True}))
