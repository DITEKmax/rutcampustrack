from pathlib import Path
import json,urllib.request,zipfile,io,hashlib
O=Path('/workspace/scratch/rct-validation/ci_eb0_receipts');INPUT=O/'.safe-download-inputs.private.json';summaries=json.loads((O/'safe-native-partial.json').read_text())['artifacts']
try:
 for a in json.loads(INPUT.read_text()):
  if not a['name'].startswith(('safe-unit-outcomes-','safe-integration-outcomes-')) or a['bytes']>1048576:raise ValueError('Unsafe artifact selection')
  with urllib.request.urlopen(a['url'],timeout=30) as r:b=r.read(1048577)
  if len(b)>1048576:raise ValueError('Artifact limit')
  digest=hashlib.sha256(b).hexdigest()
  if 'sha256:'+digest!=a['digest']:raise ValueError('Artifact digest mismatch')
  with zipfile.ZipFile(io.BytesIO(b)) as z:
   if z.testzip() is not None or len(z.infolist())!=1:raise ValueError('Safe single JSON required')
   item=z.infolist()[0]
   if not item.filename.endswith('.json') or item.file_size>1048576:raise ValueError('Safe JSON limit')
   d=json.loads(z.read(item))
  if d.get('schemaVersion')!=1 or d['metadata']['prHeadSha']!='eb0e02aaf6c7cfb3b80db2d3a3c81b8a2dd79553' or d['metadata']['runId']!='38253595173':raise ValueError('Current identity mismatch')
  (O/(a['name']+'.zip')).write_bytes(b);(O/(a['name']+'.json')).write_text(json.dumps(d,indent=2)+'\n')
  count={x:0 for x in ['PASSED','FAILED','ERROR','SKIPPED','NOT_EXECUTED']};consistent=True
  for x in d['xml']:
   for s in x.get('suites',[]):
    consistent=consistent and s['countsConsistent']
    for k,v in s['observed'].items():count[k]+=v
  summaries.append({'artifact_id':a['id'],'name':a['name'],'bytes':len(b),'digest':digest,'metadata':d['metadata'],'xml_count':len(d['xml']),'totals':count,'counts_consistent':consistent,'collection':d['collection']})
 (O/'safe-native-partial.json').write_text(json.dumps({'source':'eb0','artifacts':summaries,'acceptance':'NOT_ASSESSED'},indent=2)+'\n')
 print(json.dumps({'safe_artifacts':len(summaries),'checkouts':sorted(set(x['metadata']['checkoutSha'] for x in summaries)),'totals':{k:sum(s['totals'][k] for s in summaries) for k in ['PASSED','FAILED','ERROR','SKIPPED','NOT_EXECUTED']}}))
except Exception as e:
 print(json.dumps({'safe_error_type':type(e).__name__}));raise SystemExit(1)
finally:
 INPUT.unlink(missing_ok=True)
