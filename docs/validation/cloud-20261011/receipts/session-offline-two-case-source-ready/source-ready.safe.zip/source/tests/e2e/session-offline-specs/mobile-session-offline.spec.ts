import { test } from '/workspace/rutcampustrack/tests/e2e/fixtures/mobile-dataset';

// Register on the same protected test object before the original operations load.
test.beforeEach(async ({ page, teachingInstant }) => {
  if (!teachingInstant) throw new Error('Session/offline teaching instant is required');
  // Keep browser Date on the domain day; timers and backend security time stay real.
  await page.clock.setFixedTime(teachingInstant);
});

// Runtime require preserves hook order and every original test/assertion body.
require('/workspace/rutcampustrack/tests/e2e/specs/mobile-real-server.spec.ts');
