#!/usr/bin/env python3
"""One foreground compile command; native output stays private."""
import json
from pathlib import Path
import subprocess
import sys

scope = Path(__file__).resolve().parent
log = scope / "private" / "compile1-native.log"
arguments = json.loads((scope / "compile1-command.safe.json").read_text())["gradle_arguments"]
with log.open("wb") as output:
    log.chmod(0o600)
    result = subprocess.run(
        [sys.executable, "/workspace/rct-cloud-setup/run-gradle.py", *arguments],
        stdin=subprocess.DEVNULL, stdout=output, stderr=subprocess.STDOUT,
    )
(scope / "compile1-child-exit.safe.json").write_text(json.dumps({"native_exit": result.returncode}) + "\n")
raise SystemExit(result.returncode)
