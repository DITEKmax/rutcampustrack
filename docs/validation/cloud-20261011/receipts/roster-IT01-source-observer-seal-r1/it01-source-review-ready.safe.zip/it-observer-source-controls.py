"""Actual callback Source RAM with synthetic selected metadata; no Docker/process callback."""
import copy
import datetime
import hashlib
import json
from pathlib import Path
import types
import uuid

scope = Path(__file__).resolve().parent
source = scope / 'it_container_observer.py'
ns = {}; exec(compile(source.read_text(), str(source), 'exec'), ns)
ns['time'] = types.SimpleNamespace(sleep=lambda _: None)
C = ns['ContainerObserver']
roles = ['postgres', 'mongo', 'rabbitmq', 'redis', 'ryuk', 'probe']
ids = {role: 'sha256:' + str(i+1)*64 for i, role in enumerate(roles)}
base = {'id': 'a'*64, 'image': ids['postgres'], 'created': '2026-10-13T00:00:00Z',
        'name': '/synthetic-container', 'lang': 'java', 'sdk_version': '1.20.4',
        'session': str(uuid.UUID(int=1)), 'testcontainers': 'true', 'pid': 0, 'running': True,
        'mounts': [{'Type': 'volume', 'Name': 'b'*64, 'Destination': '/var/lib/postgresql/data', 'Source': '/anonymous/metadata-only'}]}

def instance():
    c = C.__new__(C); c.started=datetime.datetime(2026,10,13,tzinfo=datetime.timezone.utc); c.deadline=c.started+datetime.timedelta(days=1); c.allowed = {value: role for role, value in ids.items()}
    c.images = {role: [] for role in roles}; c.images['ryuk'] = [{'id':ids['ryuk'], 'tag':'testcontainers/ryuk:0.11.0'}]
    c.probe_class_hashes = {'1.20.4':'public-sdk-hash'}; c.known = {}; c.sessions = set()
    c.volumes = {'foreign-existing-volume'}; c.scope = scope; c.failure = None; return c

rows = []
def check(name, value, allow):
    c = instance()
    try: c.accept(value); actual = True
    except (ValueError, TypeError, AttributeError): actual = False
    assert actual is allow, name
    rows.append({'control': name, 'expected_admitted': allow, 'actual_admitted': actual, 'status':'PASS'})

check('fresh-data-session', copy.deepcopy(base), True)
v = copy.deepcopy(base); v.update(image=ids['ryuk'], session='', name='/testcontainers-ryuk-'+base['session'])
v['mounts'] = [{'Type':'bind','Source':'/var/run/docker.sock','Destination':'/var/run/docker.sock'}]
check('standard-ryuk-no-session-label', copy.deepcopy(v), True)
v['session'] = base['session']; check('standard-ryuk-matching-session-label', copy.deepcopy(v), True)
v['session'] = str(uuid.UUID(int=2)); check('ryuk-session-name-mismatch', v, False)
v = copy.deepcopy(base); v.update(image=ids['probe'], mounts=[]); check('standard-gateway-probe-labels', v, True)
for name, edit in [('unknown-image',lambda v:v.update(image='sha256:'+'f'*64)),
                   ('missing-data-session',lambda v:v.update(session='')),
                   ('non-Testcontainers',lambda v:v.update(testcontainers='false')),
                   ('pre-phase-container',lambda v:v.update(created='2026-10-12T00:00:00Z')),
                   ('post-stop-container',lambda v:v.update(created='2026-10-15T00:00:00Z')),
                   ('unknown-SDK',lambda v:v.update(sdk_version='future')),
                   ('non-Java-label',lambda v:v.update(lang='other')),
                   ('foreign-volume',lambda v:v['mounts'][0].update(Name='foreign-existing-volume')),
                   ('data-bind',lambda v:v['mounts'][0].update(Type='bind')),
                   ('unexpected-destination',lambda v:v['mounts'][0].update(Destination='/stand/data160'))]:
    v = copy.deepcopy(base); edit(v); check(name,v,False)
c = instance(); c.accept(copy.deepcopy(base)); v=copy.deepcopy(base);v['id']='c'*64
try: c.accept(v); raise AssertionError('duplicate-role admitted')
except ValueError: rows.append({'control':'duplicate-data-role','status':'PASS'})
c = instance(); c.accept(copy.deepcopy(base)); v=copy.deepcopy(base);v['session']=str(uuid.UUID(int=2))
try: c.accept(v); raise AssertionError('identity change admitted')
except ValueError: rows.append({'control':'owned-ID-session-change','status':'PASS'})
# Actual settle control: admitted own ID can be removed, newly unknown ID cannot.
c=instance(); c.accept(copy.deepcopy(base)); c.foreign={}; c.volumes=set();c.networks=set();c.cleanup_allowed=True
foreign_new={'id':'d'*64}; active={base['id']:copy.deepcopy(base),foreign_new['id']:foreign_new}; commands=[]
c.containers=lambda: copy.deepcopy(active)
c.save=lambda **kwargs: None
c.failure='PRESERVED_SOURCE_METADATA_DENIAL'
def call(args):
    commands.append(args)
    if args[:2]==['rm','-fv']: active.pop(args[2]); return ''
    if args in [['volume','ls','-q'],['network','ls','-q','--no-trunc']]: return ''
    raise AssertionError('Unexpected metadata command')
c.call=call
assert c.settle() is False
assert [args for args in commands if args[0]=='rm']==[['rm','-fv',base['id']]]
assert foreign_new['id'] in active and c.failure=='PRESERVED_SOURCE_METADATA_DENIAL'
rows.append({'control':'settle-known-only-after-observation-failure-preserves-unknown','status':'PASS'})
record={'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),
        'qualification':'Actual checking callback Source executed in Python RAM with synthetic selected metadata; subprocess/Docker/DB not called',
        'controls':rows,'native':'NOT_RUN'}
output=scope/'it-observer-source-controls.safe.json';output.write_text(json.dumps(record,indent=2)+'\n')
print('Actual observer Source RAM',len(rows),'PASS')
