"""Exact Output ancestor-prefix loop, read-only FD positive and mocked denials."""
import ast
import copy
import json
import os
import stat
import types
from pathlib import Path
from unittest.mock import patch

OWN = Path(__file__).parent
OLD = OWN.parent / 'browser_webkit_native_publication_correction'
tree = ast.parse((OWN / 'own-paths.py').read_text())
identity_node = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == 'identity')
cls = next(n for n in tree.body if isinstance(n, ast.ClassDef) and n.name == 'Output')
ctor = next(n for n in cls.body if isinstance(n, ast.FunctionDef) and n.name == '__init__')
tryblock = next(n for n in ctor.body if isinstance(n, ast.Try))
prefix_loop = next(n for n in tryblock.body if isinstance(n, ast.For) and ast.unparse(n.target) == 'row')
selected = compile(ast.Module(body=[identity_node, prefix_loop], type_ignores=[]), 'selected_unchanged_Output_prefix', 'exec')
rows = json.loads((OWN / 'runtime-anchors.safe.json').read_text())['anchors']
assert all(set(row) == {'path', 'identity'} and set(row['identity']) == {'device', 'inode', 'uid', 'gid', 'mode'} for row in rows)
checks = []

def exercise(label, actual_rows, want, symlink=False):
    obj = types.SimpleNamespace(fds=[], identities=[])
    globals = {'self': obj, 'rows': actual_rows, 'Path': Path, 'os': os, 'stat': stat,
        'flags': os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW | os.O_CLOEXEC}
    original = Path.lstat
    last_path = actual_rows[-1]['path']
    def mocked_lstat(path):
        value = original(path)
        if symlink and str(path) == last_path:
            return types.SimpleNamespace(st_mode=stat.S_IFLNK | 0o777)
        return value
    accepted = False
    try:
        with patch.object(Path, 'lstat', mocked_lstat):
            exec(selected, globals)
        accepted = True
    except RuntimeError:
        pass
    finally:
        for fd in reversed(obj.fds):
            os.close(fd)
    assert accepted == want, label
    checks.append({'case': label, 'pass': True, 'accepted': accepted,
        'readonly_FDs_closed': True, 'mkdir_save_alias_native_or_private_reads': False})

exercise('old_flat_metadata_with_stale_nested_OWN_inode_denied', json.loads((OLD / 'runtime-anchors.safe.json').read_text())['anchors'], False)
exercise('new_actual_native_context_all5_canonical_nested_IDs_and_FDs_equal', rows, True)
for field in ['device', 'inode', 'uid', 'gid', 'mode']:
    altered = copy.deepcopy(rows)
    altered[-1]['identity'][field] += 1
    exercise('wrong_' + field + '_denied', altered, False)
exercise('ancestor_symlink_metadata_denied_without_real_alias', rows, False, symlink=True)
assert not (OWN / 'runtime').exists()
(OWN / 'anchor-controls.safe.json').write_text(json.dumps({'status': 'PASS_ACTUAL_SELECTED_READONLY_ANCESTOR_PREFIX',
    'count': len(checks), 'checks': checks, 'canonical_nested_table_no_flat_metadata': True,
    'output_runtime_never_created': True, 'native_ABI_browser_calls': 0}, indent=2) + '\n')
print(json.dumps({'controls': len(checks), 'readonly_prefix_FD_positive': True, 'native_or_runtime_allocations': False}))
