"""AST-extracted pure caller predicates; no helper imports/process launch."""

import ast
import copy
import hashlib
import hmac
import json
from pathlib import Path, PurePosixPath
import re
import stat
from types import SimpleNamespace

HERE = Path(__file__).resolve().parent
ORIGINAL = Path('/workspace/scratch/rct-validation/np01_broker_sensitivity_sourceprep')
tree = ast.parse((HERE / 'caller-boundary.py').read_text())
names = {'safe_relative', 'pathset_hash', 'validate_ledger', 'validate_manifest_shape',
         'validate_body_identities', 'validate_child_witness', 'file_metadata'}
pure = [node for node in tree.body if isinstance(node, ast.Assign)
        or isinstance(node, ast.FunctionDef) and node.name in names]
namespace = {'hashlib': hashlib, 'hmac': hmac, 'json': json, 'PurePosixPath': PurePosixPath, 're': re,
             'stat': stat, 'os': SimpleNamespace(getuid=lambda: 1000)}
exec(compile(ast.Module(body=pure, type_ignores=[]), '<pure-caller-predicates>', 'exec'), namespace)
ledger = json.loads((ORIGINAL / 'complete-sparse-baseline.safe.json').read_text())
source = json.loads((ORIGINAL / 'sourceprep.safe.json').read_text())
selected = {entry['path']: entry for entry in source['changes']}
grant = {key: namespace[constant] for key, constant in [
    ('sourceprep_manifest_sha256', 'MANIFEST_SHA'), ('baseline_sha256', 'BASELINE_SHA'),
    ('baseline_entry_count', 'COUNT'), ('baseline_pathset_sha256', 'PATHSET_SHA'),
    ('index_scope_sha256', 'INDEX_SHA'),
]}
current = {row['path']: row['sha256'] for row in ledger['entries']}
dirty = current | {'gradlew': '0' * 64}


def old_accept(rows, values):
    return all(row['path'] in selected or values.get(row['path']) == row['sha256']
               for row in rows['entries'])


def corrected_accept(rows, values, authority=grant):
    try:
        valid = namespace['validate_ledger'](rows, authority)
        namespace['validate_body_identities'](valid, selected, values)
        return True
    except ValueError:
        return False


cases = []
def record(name, actual, expected):
    assert actual is expected, name
    cases.append({'id': name, 'actual_accepted': actual, 'expected_accepted': expected})


empty = {'base': ledger['base'], 'entries': []}
minimal = {'base': ledger['base'], 'entries': [row for row in ledger['entries'] if row['path'] in selected][:1]}
record('OLD_dirty_gradlew_authentic_ledger_rejected', old_accept(ledger, dirty), False)
record('OLD_dirty_gradlew_empty_ledger_bypass_observed', old_accept(empty, dirty), True)
record('OLD_dirty_gradlew_selected_only_bypass_observed', old_accept(minimal, dirty), True)
record('NEW_authentic_clean_ledger_accepted', corrected_accept(ledger, current), True)
record('NEW_dirty_gradlew_authentic_rejected', corrected_accept(ledger, dirty), False)
record('NEW_dirty_gradlew_empty_rejected', corrected_accept(empty, dirty), False)
record('NEW_dirty_gradlew_selected_only_rejected', corrected_accept(minimal, dirty), False)
for label, change in [
    ('missing_unselected', lambda rows: rows['entries'].pop()),
    ('duplicate_path', lambda rows: rows['entries'].__setitem__(-1, rows['entries'][0])),
    ('extraneous_path', lambda rows: rows['entries'][-1].__setitem__('path', 'unexpected.txt')),
    ('unsafe_parent_path', lambda rows: rows['entries'][0].__setitem__('path', '../escape')),
    ('wrong_mode', lambda rows: rows['entries'][0].__setitem__('mode', '0o644')),
    ('aliased_nlink', lambda rows: rows['entries'][0].__setitem__('nlink', 2)),
]:
    candidate = copy.deepcopy(ledger)
    change(candidate)
    record('NEW_' + label + '_rejected', corrected_accept(candidate, current), False)
for key in grant:
    candidate = grant.copy()
    candidate[key] = 0 if key == 'baseline_entry_count' else '0' * 64
    record('NEW_changed_' + key + '_rejected', corrected_accept(ledger, current, candidate), False)

manifest = json.loads((ORIGINAL / 'manifest.safe.json').read_text())
def manifest_accept(value):
    try:
        namespace['validate_manifest_shape'](value)
        return True
    except ValueError:
        return False
record('NEW_complete_manifest_shape_accepted', manifest_accept(manifest), True)
record('NEW_empty_manifest_rejected', manifest_accept({'entries': []}), False)
partial = copy.deepcopy(manifest)
partial['entries'][-1] = partial['entries'][0]
record('NEW_duplicate_manifest_member_rejected', manifest_accept(partial), False)
record('NEW_dot_relative_path_rejected', namespace['safe_relative']('.'), False)
typed = copy.deepcopy(ledger)
typed['entries'][0]['nlink'] = True
record('NEW_boolean_nlink_rejected', corrected_accept(typed, current), False)

class MetaPath:
    def __init__(self, fields=None, ancestor_symlink=False):
        self.fields = fields or {'st_mode': stat.S_IFREG | 0o600, 'st_nlink': 1, 'st_uid': 1000, 'st_size': 10}
        self.parents = [SimpleNamespace(is_symlink=lambda: ancestor_symlink)]
    def is_absolute(self):
        return True
    def is_relative_to(self, anchor):
        return True
    def lstat(self):
        return SimpleNamespace(**self.fields)

def metadata_accept(fields=None, ancestor_symlink=False):
    try:
        namespace['file_metadata'](MetaPath(fields, ancestor_symlink), MetaPath(), 0o600, 10)
        return True
    except ValueError:
        return False
record('NEW_regular_own_metadata_accepted', metadata_accept(), True)
record('NEW_ancestor_symlink_rejected_before_body', metadata_accept(ancestor_symlink=True), False)
for label, delta in [('directory', {'st_mode': stat.S_IFDIR | 0o600}),
                     ('linked', {'st_nlink': 2}), ('foreign_uid', {'st_uid': 1001}),
                     ('changed_mode', {'st_mode': stat.S_IFREG | 0o644}), ('changed_size', {'st_size': 9})]:
    fields = {'st_mode': stat.S_IFREG | 0o600, 'st_nlink': 1, 'st_uid': 1000, 'st_size': 10} | delta
    record('NEW_' + label + '_metadata_rejected_before_body', metadata_accept(fields), False)

# Public fixed control token only; no actual nonce/credential is generated, read, logged or hashed.
token = '0' * 64
parent = {'pid': 101, 'birth': 1001}
child = {'pid': 102, 'birth': 1002}
witness = {'guard_started': True, 'parent_pid': 101, 'parent_birth': 1001,
           'child_pid': 102, 'child_birth': 1002, 'phase': 'green',
           'driver_sha256': '1' * 64, 'nonce': token}
def child_accept(value, parent_value=parent, child_value=child, nonce=token, outer=True):
    try:
        namespace['validate_child_witness'](value, parent_value, child_value, nonce, 'green', '1' * 64, outer)
        return True
    except ValueError:
        return False
old_driver = ast.parse((ORIGINAL / 'run-stage.py').read_text())
old_branch = next(node for node in ast.walk(old_driver) if isinstance(node, ast.If) and ast.unparse(node.test) == 'args.child')
attempted = []
fake_os = SimpleNamespace(O_WRONLY=1, O_CREAT=2, O_EXCL=4,
    open=lambda *args: 99, dup2=lambda *args: None, close=lambda *args: None,
    chdir=lambda *args: None, execvpe=lambda *args: attempted.append('NATIVE_EXEC_WOULD_OCCUR'))
fake_directory = SimpleNamespace(is_dir=lambda: True)
class ExistingDirectory:
    def is_dir(self):
        return True
    def __truediv__(self, name):
        return name
exec(compile(ast.Module(body=old_branch.body, type_ignores=[]), '<old-actual-internal-branch>', 'exec'),
     {'os': fake_os, 'directory': ExistingDirectory(), 'WT': 'PUBLIC_CONTROL_DIRECTORY',
      'argv': ['PUBLIC_CONTROL_COMMAND'], 'environment': lambda directory: {}})
record('OLD_actual_standalone_branch_with_existing_directory_would_exec', attempted == ['NATIVE_EXEC_WOULD_OCCUR'], True)
record('NEW_live_guard_parent_witness_accepted', child_accept(witness), True)
record('NEW_standalone_without_witness_rejected', child_accept({}), False)
record('NEW_standalone_without_nonce_rejected', child_accept(witness, nonce=None), False)
record('NEW_other_parent_rejected', child_accept(witness, parent_value={'pid': 111, 'birth': 1001}), False)
record('NEW_reused_parent_pid_birth_rejected', child_accept(witness, parent_value={'pid': 101, 'birth': 9999}), False)
record('NEW_other_child_rejected', child_accept(witness, child_value={'pid': 103, 'birth': 1002}), False)
record('NEW_reused_child_birth_rejected', child_accept(witness, child_value={'pid': 102, 'birth': 9999}), False)
record('NEW_wrong_nonce_rejected', child_accept(witness, nonce='2' * 64), False)
record('NEW_internal_parent_cmdline_rejected', child_accept(witness, outer=False), False)
record('NEW_not_guard_started_rejected', child_accept(witness | {'guard_started': False}), False)
record('NEW_wrong_phase_rejected', child_accept(witness | {'phase': 'fault'}), False)
record('NEW_wrong_driver_identity_rejected', child_accept(witness | {'driver_sha256': '3' * 64}), False)

driver_source = (HERE / 'run-stage.py').read_text()
driver = ast.parse(driver_source)
child_branch = next(node for node in ast.walk(driver) if isinstance(node, ast.If) and ast.unparse(node.test) == 'args.child')
calls = [node for node in ast.walk(child_branch) if isinstance(node, ast.Call)]
validation_line = next(node.lineno for node in calls if isinstance(node.func, ast.Attribute) and node.func.attr == 'validate_child_witness')
exec_line = next(node.lineno for node in calls if isinstance(node.func, ast.Attribute) and node.func.attr == 'execvpe')
assert validation_line < exec_line
assert 'NP01_CALLER_NONCE' not in ast.unparse(next(node for node in driver.body if isinstance(node, ast.FunctionDef) and node.name == 'environment'))

# The prior fault boundary is intentionally incompatible with restored source.
old_tree = ast.parse(Path('/workspace/scratch/rct-validation/np01_broker_sensitivity_caller_correction/caller-boundary.py').read_text())
old_function = next(n for n in old_tree.body if isinstance(n, ast.FunctionDef) and n.name == 'validate_body_identities')
old_namespace = dict(namespace)
exec(compile(ast.Module(body=[old_function], type_ignores=[]), '<old-mutant-boundary-pure>', 'exec'), old_namespace)
mutant = current | {name: entry['candidate_sha256'] for name, entry in selected.items()}
def old_fault_boundary_accept(values):
    try:
        old_namespace['validate_body_identities'](ledger['entries'], selected, values)
        return True
    except ValueError:
        return False
record('OLD_fault_boundary_accepts_actual_mutant_identities', old_fault_boundary_accept(mutant), True)
record('OLD_fault_boundary_rejects_restored_baseline', old_fault_boundary_accept(current), False)
record('GREEN_boundary_accepts_complete_restored_BASE_identities', corrected_accept(ledger, current), True)
record('GREEN_boundary_rejects_original_two_mutants', corrected_accept(ledger, mutant), False)
for name, entry in selected.items():
    record('GREEN_rejects_each_remaining_mutant_' + name.rsplit('/', 1)[-1],
           corrected_accept(ledger, current | {name: entry['candidate_sha256']}), False)
parser = next(node for node in ast.walk(driver) if isinstance(node, ast.Call)
              and isinstance(node.func, ast.Attribute) and node.func.attr == 'add_argument'
              and node.args and isinstance(node.args[0], ast.Constant) and node.args[0].value == 'phase')
assert next(ast.literal_eval(k.value) for k in parser.keywords if k.arg == 'choices') == ['green']
procedure = json.loads((HERE / 'native-procedure.safe.json').read_text())
command = procedure['commands']['green']
assert set(procedure['commands']) == {'green'} and command[2:5] == [':services:academic-service:academic-app:integrationTest', '--rerun', '--tests']
assert command.count('--tests') == 1 and '--rerun-tasks' not in command
assert command[5] == 'ru.rutcampustrack.academic.botcredentials.BotCredentialBrokerBridgeIT.actualProducerBrokerClaimAckRetryRestartAndDlqPreserveExactCards'
assert command.count('--offline') == 1

receipt = {'status': 'PASS_RESTORED_GREEN_CALLER_PURE_CONTROLS_NATIVE_NOT_RUN', 'controls': cases,
           'controls_count': len(cases), 'green_only_phase_and_exact_single_task_rerun_command': True, 'caller_and_boundary_ast_parse': True,
           'child_witness_before_exec': True, 'nonce_removed_from_gradle_environment': True,
           'helper_imports': False, 'guard_or_runtime_execution': False,
           'tracked_source_or_ledger_mutation': False,
           'qualifications': ['Only AST-extracted pure predicates and synthetic metadata maps.',
                              'Green live protocol NOT_RUN; unchanged fault caller protocol already passed actual native launch, new context requires Root grant.',
                              'Same UID handshake rejects accidental standalone entry; no cryptographic/OS isolation claim.',
                              'Three protected ENV/public-key bodies not reread; exact metadata-only exception retained.']}
target = HERE / 'pure-controls-final.safe.json'
assert not target.exists()
target.write_text(json.dumps(receipt, indent=2) + '\n')
target.chmod(0o600)
print(json.dumps({'status': receipt['status'], 'controls': len(cases), 'native': 'NOT_RUN'}))
