import ast
import json
from pathlib import Path
import types
V=Path(__file__).parent
C=V.parent/'current_host_restart_ancestor_correction'
checks=[]
for name in ['docker-up-restart.py','run-mongo-restart.py','run-service-restart.py']:
 def selected(path):
  tree=ast.parse(path.read_text());main=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='main')
  nodes=[];active=False
  for n in main.body:
   if isinstance(n,ast.Assign) and ast.unparse(n.targets[0])=='boundary':active=True
   if active:nodes.append(n)
   if active and isinstance(n,ast.Expr) and isinstance(n.value,ast.Call) and ast.unparse(n.value.func)=='exec':break
  return compile(ast.Module(body=nodes,type_ignores=[]),str(path),'exec')
 old={'types':types,'CORRECTION':C,'ANCESTOR_CORRECTION':C,'Path':Path};caught=None
 try:exec(selected(C/name),old)
 except NameError:caught='NameError'
 assert caught=='NameError'
 new={'types':types,'CORRECTION':V,'ANCESTOR_CORRECTION':V,'Path':Path}
 exec(selected(V/name),new)
 assert new['boundary'].__file__==str(V/'restart-boundary.py')
 assert new['boundary'].CORRECTION==V
 assert new['boundary'].PLAN==V.parent/'current_host_restart_plan'
 assert callable(new['boundary'].CohortDirectory)
 checks.append({'runner':name,'old_actual_selected_import':'NameError_BEFORE_CHILD','new_actual_selected_import':'PASS_EXACT_HELPER_FILE_CONTEXT','native_children':0})
(V/'helper-import-controls.safe.json').write_text(json.dumps({'status':'PASS_SELECTED_IMPORT_RED_GREEN','count':len(checks),'checks':checks,'private_data_or_foreign_writes':False,'runtime':'NOT_RUN'},indent=2)+'\n')
print(json.dumps({'selected_import_controls':len(checks),'old_red':3,'new_green':3,'native_runtime':'NOT_RUN'}))
