import json
from pathlib import Path

O=Path('/workspace/scratch/rct-validation/matrix_runtime_plan')
entries=json.loads((O/'remaining-groups.json').read_text())['entries']
checks=json.loads((O/'completeness-checks.json').read_text())
changed=json.loads((O/'qualified-direct-source-equivalence.json').read_text())
lines=['''# Independent matrix runtime plan

Scope complete as a read-only planning/referential review, **not product acceptance**. Requested Sol6.1/high; actual metadata UNKNOWN. Input root `2a23969a69fee28bb5adc51ee7d4c0ef6baf6362`, last reported remote `25668e10ffcdcda1848c6fda38429dea7e22a793`, baseline `3908fad9624f97aec8891fc79338ceb6b0616bf3`. No Gradle/Docker/network/apps/browser/product/shared-doc writes or children. Only assigned scratch report files were created. Future runtime needs the root's current source/resource/TLS/floor admission.

All 218 source families and 52 boundaries were parsed in full, alongside all 147 canonical registered story records, 175 request records, 62 existing links, all 48 queue groups, 39 finite PASS rows and all 29 L/P dispositions. The mapping has no missing required family, boundary or dangling group. All 181 historical candidate test paths/method text still exist. These are source facts, not tests executed by this reviewer.

The historical routing denominator contains 211 required rows, five explicit exclusions and two nonmandatory research rows (L05 optimization and P01 architecture adoption). These are overlapping story/research/client views, **not 211 or 218 independent features**. Retired positive free-attendance JS-STUDENT-04 is excluded but its current denial remains required through PUBLIC-RETIRED-NEGATIVE. D004 excludes only the textual legend; teacher/student map operations remain mandatory.

## Completeness findings

1. **MPLAN01/P2 — NP01 execution detail missing from the old queue.** BOT-DELIVERY described generic retries but did not state the accepted T002 credential lifecycle or actual Auth producer→Rabbit→bot cleanup/claim/ACK seam. The new report gives five finite BOT slices and exact role/state/identity rules. Required proof includes event-before-register, render response loss, in-flight edit, confirmed exact delete/absence, unsettled cleanup retention, stale CAS, unlink/rebind/later card isolation, v2/v1 compatibility and no credential content in metadata/evidence. Source-ready code and the actual Academic TLS/PG/Python/provider bridge do not close the broker/producer seam. NP01 remains GAP at the task input.

2. **MPLAN02/P2 — 48 routing groups are not 48 runnable acceptance cases.** Twenty original groups had missing-oracle placeholders; each CLIENT group repeated the same eight-case command. Eight actual named browser cases cannot establish the union of student/headman/helper/teacher/FULL/LIMITED flows. SECURITY2-ACCEPTANCE and SCHEMA-OWNER-L08 originally had no reverse family/boundary mapping; the report gives explicit source links and marks them acceptance audits, with real oracles owned by the existing domain groups. FINAL-FORMAT-PARSER-GATES is a task gate through BOUNDARY-52. These three entries add no duplicate product runtime. The new JSON gives row-specific roles, client/state/risk, source IDs, exact finite slices and current candidate proof paths. Missing accepted browser/broker/restore oracles still need bounded source-derived harness extensions. A group has no inherited whole-family PASS. Existing Gradle proposals use max-workers=2; current max-workers=1/768MiB lease supersedes them. No old command is newly admitted by this report.

3. **MPLAN03/P2 — old evidence qualifications cannot be treated as current aggregate execution.** Of 145 direct-source comparisons against old accepted manifests, 135 match and ten comparison rows differ (seven distinct paths listed below). Changed SubjectRepository/test fixture, BFF query/advice, Academic config/GrpcIT and CI inputs invalidate blanket equivalence. The two current merged Academic query/RPC cases remain pending. Conversely an unchanged direct source does not prove unchanged Spring/classpath/generated/proto/clock dependencies. Preserve producer SHA, WIP-to-commit bridge, real seam and limitations for every existing PASS. The old CI232 browser receipt has serviceWorkers:block; it cannot close D002.

4. **MPLAN04/P2 — stale pending/failure language needs a current execution overlay.** SECURITY2 acceptance and L03/L04/P10/P17 text still refer to pending review although SB finite corrections are now accepted; L05 still calls T001 teacher exposure a candidate though it is fixed/integrated/source reviewed. Preserve the historical receipt, replace only the current blocker/oracle view. T002/V57 adds tracker/generation/event consumers to L08/P12/P18/P21 qualification. D009 permits final documentation byte equivalence only after actual sufficient acceptance/current all-three-green product revision; it does not close scenarios or rerun earlier CI at the new SHA.

5. **MPLAN05/P3 — D008 should be explicit, but its adequate accepted finite checks must be reused.** The old generic map group omits the numeric PNG resource boundary. Independent reading found approved c73ef evidence: actual 37-case CampusMapFileBoundaryIT suite with zero failures/errors/skips includes six exact at/over byte/row/Adam7/overflow budget cases. All five accepted map source blobs still equal current root bytes. The new group retains that qualified proof and requests only the missing gateway/live-actor/browser/version/download layer. No repeat inflation, billion-row run or new canvas policy is proposed.

No new owner question or new product defect was established by this scope. All Q001–Q009 are resolved. Native Telegram/device/iOS provider checks remain separate required seams; mark only an exact inaccessible seam BLOCKED after evidence of missing access, while synthetic real Vue/server work continues. Host T003 shared UID/key isolation, Debian OpenJDK versus Temurin Alpine, and lack of per-process cgroup hardcaps must remain explicit; a host run cannot claim production-container isolation PASS.

## Qualified existing evidence to retain

- All 39 current verified-cases rows retain their exact producer revisions and limits in `finite-case-qualifications.json`. No parent status changed.
- D008/MVR01–03: approved c73ef correction WIP-to-commit hash bridge, actual public MockMvc/PG/storage evidence and current five source identities; browser/gateway/live Auth remain separate.
- NTR: accepted d674 one-case 30s advertised/Redis lower-bound/expiry/HTTP404 result with meaningful shortened-1s red and restored green. Its test and five other package source blobs match current root. Old292 dependency identity is not claimed at current root. Reuse lifetime proof; retain missing combined Auth→open WS revoke/client seam.
- NP02: approved fa02 synthetic HTTP provider500 gives incomplete effect/released claim/mainACK0/DLQ1; manual same-event recovery+duplicate gives one success/two ACKs. Preserve controlled binding/audience and manual-recovery qualification; do not add an automatic provider retry or real Telegram promise.
- Export f09 scoped Auth/Gateway/job/private ticket controls remain historical qualified evidence. New per-job audit one-test correction needs its own transfer/review/current integration and current remote full Auth gates. Existing native converter proof does not establish distinct domain export models, filtered rows, private ready events or browser downloads.

## Next finite execution order

1. Finish/accept DOMAIN1 selective fault controls and exact restored source; finish export audit transfer/review and host guard independent recheck. Integrate reviewed domain24 and one audit-test delta under sole writers. Freeze common/config/generated/current consumer identity. Existing adequate finite evidence is reconciled, not repeated merely for counts.
2. Close the NP01 actual Auth producer/Rabbit/claim/cleanup/ACK seam on disposable resources; selected current Academic merged publication/query and transfer-RPC cases. Preserve TLS and typed teaching/security clock isolation.
3. Admit the genuine current seven BootJAR + nine Docker data/nativeRenderer/edge stack only after exact artifact/Manifest/current payload/TLS/ports/disk-floor budget review. Use one shared synthetic dataset and root sole schedule. Establish missing real routed auth/role/history/state/failure effects from the grouped invariant list below; select existing tests only for an uncovered or dependency-changed rule.
4. Run eight existing real-mobile cases with Chromium and the canonical safe reporter, then only source-derived missing accepted flows. Helper remains STUDENT; separately cover MARK_ATTENDANCE, MANAGE_EXCUSES, MANAGE_HOMEWORK, CANCEL_LESSONS, VIEW_STATS. For LIMITED cover distinct canonical guards/dependencies and live revocation, not an exhaustive permission combination. WebKit's missing host libraries/native providers are explicit capability limitations, not permission to claim PASS or block Chromium work.
5. Reuse native renderer engine proof; obtain distinct real domain model/file/download/private event evidence across five table formats and PNG/HTML graph. Verify a separate fresh disposable restore with real application pending-operation completion and exact DB/files inventory. Keep source/table/FULL Telegram-ID/credential exclusions explicit.
6. Finish separate authored-source formatting after semantic freeze; required checks/review/current all-three remote receipts; final D009 byte equivalence and final local=remote=draftPRhead/main unmerged handoff.

## Exact 48 groups

The JSON is authoritative for full role/client/state/risk/source/proof-path details. Boundary actor rules apply only to their own row; they are not merged grants or a Cartesian-product test plan. Each row below remains UNKNOWN as a broad group; accepted finite children are reused only for their own oracle.

| Group | Remaining finite execution slices |
| --- | --- |''']
for e in entries:
 lines.append('| '+e['id']+' | '+'; '.join(e['newproof_minimum']).replace('|',' / ')+' |')
lines.append('''
## Current direct-source changes against historical receipts

Different bytes require qualification or selected recheck for the affected invariant; they do not imply a runtime failure.
''')
for path in sorted({x['path'] for x in changed if not x['equal']}):lines.append('- `'+path+'`')
lines.append('''
## Artifacts and limits

- `remaining-groups.json`: 48 enriched groups, all IDs/source rows and row-specific roles/clients/states/risks, candidate paths, finite slices, qualification/admission rules and named NP01/D008/NTR/NP02 evidence.
- `family-state-oracles.json`: full218 structured source-family observable fields; decisions/overlays retained separately.
- `completeness-checks.json`: parsed counts/referential checks, not runtime acceptance.
- `finite-case-qualifications.json`: unchanged historical producer/evidence/limits for all39 PASS rows.
- `qualified-direct-source-equivalence.json`:145 exact direct-source comparisons,135 equal/10 changed comparison rows.
- `supplementary-qualified-evidence.json`: approved D008/NTR/NP02 exact limited reuse.
- `research-dispositions.json`: all29 original dispositions plus current source/acceptance overlays.
- `input-source-manifest.json`: opened/parsed input identities; hashing does not prove semantic reading beyond stated read kind.

No critical source was promoted from candidate to accepted behavior. No mock/static/green CI whole-family acceptance was introduced. No source-ready author/runtime claim was substituted for current real client or cross-service execution. Report-only completion leaves global IN_PROGRESS.
''')
(O/'REPORT.md').write_text('\n'.join(lines)+'\n')
print('report written', (O/'REPORT.md').stat().st_size)
