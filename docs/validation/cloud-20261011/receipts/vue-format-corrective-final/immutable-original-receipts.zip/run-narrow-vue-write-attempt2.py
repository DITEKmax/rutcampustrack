import pathlib,json,runpy,resource
resource.setrlimit(resource.RLIMIT_CORE,(0,0))
S=pathlib.Path(__file__).parent
x=runpy.run_path(str(S/'native-helper512-v2.py'))
R=x['R'];F=R/'frontends'
allow=json.loads((S/'exact111-native-write-allowlist.safe.json').read_text())
paths=allow['source_paths'];assert len(paths)==111
assert str(R)==allow['own_wt']
assert all(p.startswith('frontends/') and p.endswith('.vue') and not p.startswith('frontends/web-panel/') for p in paths)
before={p:x['row'](p) for p in x['git']('ls-files','-z').split('\0') if p and not p.startswith(('.agent/','.agents/','.codex/'))}
for p in paths:assert (R/p).stat().st_nlink==1
argv=[x['NODE'],str(F/'node_modules/eslint/bin/eslint.js'),'--fix','--max-warnings=0',*[p[len('frontends/'):] for p in paths]]
result=x['check']('native-exact111-eslint-write-attempt2',argv,F,300)
after={p:x['row'](p) for p in before}
changed=[p for p,b in before.items() if after[p]!=b]
unexpected=[p for p in changed if p not in paths]
proposal=json.loads((S/'block-pipeline-probe.safe.json').read_text())
mismatches=[r['path'] for r in proposal['rows'] if after[r['path']]['sha256']!=r['candidateSourceHash']]
x['save']('actual-candidate-equality-attempt2.safe.json',{'targets':127,'candidate_mismatches':mismatches,'unexpected_changes':unexpected,
 'native_writer_changed_paths':changed,'scope':111,'rows':[after[r['path']] for r in proposal['rows']],
 'reused_original127_compiler_proof':not mismatches,'protected8_proof':'protected-eight-raw-text.safe.json',
 'no_root_write':True,'initial_broad680_bundle':'Rejected BEFORElaunch; never executed'})
assert result['native_exit']==0 and not unexpected and not mismatches
x['save']('CURRENT.json',{'status':'RELEASED','narrow_writer_complete':True})
