"""Finite real local readiness/API/TLS/static/spoof checks; safe booleans only."""
import datetime
import hashlib
import http.cookiejar
import json
import re
import ssl
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path

OWN = Path(__file__).parent
BASE = Path('/workspace/scratch/rct-validation/current_host_config_v5')
class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, request, file, code, message, headers, newurl):
        return None

context = ssl.create_default_context(cafile='/workspace/scratch/rct-validation/current_host_config/tls/edge/server.crt')
jar = http.cookiejar.CookieJar()
opener = urllib.request.build_opener(urllib.request.ProxyHandler({}), urllib.request.HTTPSHandler(context=context),
                                    urllib.request.HTTPCookieProcessor(jar), NoRedirect())
def request(url, method='GET', body=None, headers=None):
    actual_headers = dict(headers or {})
    data = None if body is None else json.dumps(body).encode()
    if data is not None: actual_headers['Content-Type'] = 'application/json'
    req = urllib.request.Request(url, data=data, method=method, headers=actual_headers)
    try:
        response = opener.open(req, timeout=8)
    except urllib.error.HTTPError as caught:
        response = caught
    with response:
        payload = response.read(2097152)
        return response.status, response.headers, payload

def main():
    result = {'utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'credentials_tokens_cookies_bodies_published': False,
              'browser': 'NOT_RUN', 'checks': []}
    checks = result['checks']
    def record(name, passed, **safe):
        checks.append({'name': name, 'pass': passed, **safe})
        (OWN / 'stand-readiness.partial.safe.json').write_text(json.dumps(result, indent=2) + '\n')
    specs = json.loads((BASE / 'host-service-specs.json').read_text())
    for spec in specs:
        try: status, headers, data = request(spec['readiness_url'])
        except (urllib.error.URLError, TimeoutError) as caught:
            record('Boot_liveness_' + spec['service'], False, exception_class=type(caught).__name__)
            continue
        try: body = json.loads(data)
        except ValueError: body = {}
        record('Boot_liveness_' + spec['service'], status == 200 and body.get('status') == 'UP', HTTP=status)
    for frontend, prefix in [('pwa-vue', '/app'), ('tma-vue', '/mini-app')]:
        root = Path('/workspace/scratch/rct-validation/current_vue_stage/frontend') / frontend / 'dist'
        for relative in ['index.html'] + (['sw.js', 'sw-assets.js', 'version.json'] if frontend == 'pwa-vue' else []):
            status, headers, payload = request('https://localhost:8443' + prefix + '/' + relative)
            expected = hashlib.sha256((root / relative).read_bytes()).hexdigest()
            record('TLS_static_exact_' + prefix + '/' + relative,
                status == 200 and hashlib.sha256(payload).hexdigest() == expected and 'no-store' in headers.get('Cache-Control', ''),
                HTTP=status, TLS_verified=True, SHA_equal=hashlib.sha256(payload).hexdigest() == expected)
        status, headers, payload = request('https://localhost:8443' + prefix + '/synthetic-nonasset-route')
        record('SPA_fallback_' + prefix, status == 200 and payload == (root / 'index.html').read_bytes(), HTTP=status)
        for args in ['', 'recovery=synthetic-marker&next=%2Fapp%2Fprofile']:
            status, headers, payload = request('https://localhost:8443' + prefix + ('?' + args if args else ''))
            location = urllib.parse.urlsplit(headers.get('Location', ''))
            record('redirect_query_' + prefix + ('_nonempty' if args else '_none'),
                status == 301 and location.path == prefix + '/' and location.query == args,
                HTTP=status, raw_query_preserved=location.query == args, response_origin_port=location.port)
    status, headers, payload = request('https://localhost:8443/api/auth/public-key')
    data = json.loads(payload) if status == 200 else {}
    record('TLS_edge_to_gateway_to_Auth_public_key', status == 200 and data.get('algorithm') == 'RS256' and bool(data.get('publicKey')), HTTP=status)
    fixture = Path('/workspace/rutcampustrack/tests/e2e/fixtures/users.ts').read_text()
    match = re.search(r"admin:\s*\{\s*login:\s*(['\"])(.*?)\1,\s*password:\s*(['\"])(.*?)\3", fixture, re.S)
    if match is None: raise RuntimeError('Public synthetic fixture shape unsupported')
    credentials = {'login': match.group(2), 'password': match.group(4)}
    status, headers, payload = request('https://localhost:8443/api/auth/login', 'POST', credentials,
                                      {'Origin': 'https://localhost:8443'})
    del fixture, match, credentials
    record('real_synthetic_admin_login', status == 200, HTTP=status)
    if status != 200:
        result['status'] = 'BLOCKED_ACTUAL_LOGIN'
    else:
        login = json.loads(payload)
        token = login['accessToken']
        auth = {'Authorization': 'Bearer ' + token, 'Origin': 'https://localhost:8443'}
        status, headers, payload = request('https://localhost:8443/api/auth/session', headers=auth)
        session = json.loads(payload) if status == 200 else {}
        if status == 200 and session.get('activeRole') != 'ADMIN':
            status, headers, payload = request('https://localhost:8443/api/auth/session/active-role', 'PUT',
                {'role': 'ADMIN', 'expectedSessionVersion': session['sessionVersion']}, auth)
            selected = json.loads(payload) if status == 200 else {}
            token = selected.get('accessToken', token)
            auth['Authorization'] = 'Bearer ' + token
            session = selected.get('session', {})
        record('real_current_ADMIN_session', status == 200 and session.get('activeRole') == 'ADMIN', HTTP=status)
        status, headers, payload = request('https://localhost:8443/api/academic/admin-access/me', headers=auth)
        profile = json.loads(payload) if status == 200 else {}
        record('real_current_FULL_admin_profile', status == 200 and profile.get('mode') == 'FULL' and profile.get('assigned') is True, HTTP=status)
        status, headers, payload = request('https://localhost:8443/api/academic/users?page=0&size=1', headers=auth)
        record('trusted_edge_current_ADMIN_registry', status == 200, HTTP=status)
        spoof = {'X-User-Id': '1', 'X-Roles': 'ADMIN', 'X-Active-Role': 'ADMIN',
                 'X-Forwarded-For': '203.0.113.77', 'X-Forwarded-Proto': 'https',
                 'X-Forwarded-Host': 'localhost:8443', 'Forwarded': 'for=203.0.113.77;proto=https'}
        status, headers, payload = request('http://172.29.84.1:8080/api/academic/users?page=0&size=1', headers=spoof)
        record('direct_gateway_forged_identity_denied', status in (401, 403), HTTP=status)
        status, headers, payload = request('http://127.0.0.1:9091/academic/users?page=0&size=1', headers=spoof)
        record('direct_Academic_forged_identity_denied', status in (401, 403), HTTP=status)
        status, headers, payload = request('https://localhost:8443/api/auth/logout', 'POST', headers=auth)
        record('own_admin_session_logout', status == 204, HTTP=status)
        del token, login, auth, session, profile
        result['status'] = 'PASS_REQUIRED_READINESS_BARRIERS' if all(c['pass'] for c in checks if not c['name'].startswith('Boot_liveness_')) else 'ACTUAL_READINESS_FINDING'
    (OWN / 'stand-readiness.safe.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result))

if __name__ == '__main__':
    main()
