const fs = require('node:fs');
const path = require('node:path');
const ts = require('/workspace/rutcampustrack/frontends/node_modules/typescript/lib/typescript.js');
const { request } = require('/workspace/rutcampustrack/tests/e2e/node_modules/playwright');
const ROOT = '/workspace/rutcampustrack';

function need(value) {
  if (!value) throw new Error('CLOSED_GATE');
}
function unwrap(value) {
  return value && typeof value === 'object' && !Array.isArray(value)
    ? value.content ?? value
    : {};
}
/** These endpoints return Spring HATEOAS PagedModel, not an unpaged array/content fallback. */
function completePage(body, key) {
  const page = body?.page;
  const rows = body?._embedded?.[key];
  need(page && Array.isArray(rows));
  need(page.number === 0 && page.size === 100 && Number.isSafeInteger(page.totalElements));
  need(page.totalElements > 0 && page.totalElements <= 100 && page.totalPages === 1);
  need(rows.length === page.totalElements && body._links?.next === undefined);
  const values = rows.map(unwrap);
  need(values.every(value => Number.isSafeInteger(value.id) && value.id > 0));
  need(new Set(values.map(value => value.id)).size === values.length);
  return values;
}
function sourceModule(file) {
  const box = { exports: {} };
  const source = fs.readFileSync(file, 'utf8');
  const output = ts.transpileModule(source, {
    compilerOptions: { target: ts.ScriptTarget.ES2022, module: ts.ModuleKind.CommonJS },
  }).outputText;
  const localRequire = name => name === '@playwright/test'
    ? require(ROOT + '/tests/e2e/node_modules/@playwright/test')
    : require(name);
  new Function('require', 'module', 'exports', output)(localRequire, box, box.exports);
  return box.exports;
}
/** Reuse the reviewed current0a8f 8KiB/HTTP503/issuer/whole-Status-subset classifier exactly. */
function classifyWitness(httpStatus, bytes, contentLength) {
  const { classifyRosterProblem } = sourceModule(ROOT + '/tests/e2e/fixtures/first3-observer.ts');
  const value = classifyRosterProblem(httpStatus, bytes, contentLength);
  return {
    boundary: value.failureBoundary === 'UNKNOWN' ? 'OTHER' : value.failureBoundary,
    dependency: value.dependency === 'UNKNOWN' ? 'OTHER' : value.dependency,
    rpc: value.reportedCode,
    operationHint: value.operationHint,
    problemBodyState: value.problemBodyState,
  };
}
function ownsRefresh(state) {
  return Array.isArray(state?.cookies) && state.cookies.some(cookie => cookie.name === 'rct_refresh');
}
async function call(handle, method, route, data, roster = false) {
  // Playwright can store Set-Cookie before fetch rejects while reading its body.
  if (method === 'POST' && route === '/api/auth/login') handle.loginAttempted = true;
  const response = await handle.context.fetch(route, {
    method, headers: handle.token ? { Authorization: `Bearer ${handle.token}` } : {},
    data, timeout: 3000, maxRedirects: 0, maxRetries: 0,
  });
  const status = response.status();
  // Capture ownership before body parsing, session/role gates or any other fallible await.
  if (method === 'POST' && route === '/api/auth/login' && status === 200)
    handle.loginIssued = true;
  const contentLength = response.headers()['content-length'];
  try {
    if (roster && (status !== 503 || (contentLength !== undefined &&
      (!/^\d{1,10}$/.test(contentLength) || Number(contentLength) > 8192))))
      return { status, bytes: new Uint8Array(), contentLength, body: {} };
    const bytes = await response.body();
    need(bytes.length <= 1048576); // Post-buffer validation, not a hard allocation/transport bound.
    let body = {};
    if (!roster && bytes.length) {
      try { body = JSON.parse(new TextDecoder('utf-8', { fatal: true }).decode(bytes)); } catch {}
    }
    if (status === 200 && typeof body.accessToken === 'string' && body.accessToken.length > 0 &&
      ((method === 'POST' && route === '/api/auth/login') ||
       (method === 'PUT' && route === '/api/auth/session/active-role'))) {
      handle.token = body.accessToken;
      handle.tokens.add(body.accessToken);
    }
    return { status, body, bytes, contentLength };
  } finally {
    await response.dispose();
  }
}
async function admit(handle, user, role) {
  const login = await call(handle, 'POST', '/api/auth/login', {
    login: user.login, password: user.password,
  });
  need(login.status === 200 && typeof login.body.accessToken === 'string');
  const current = await call(handle, 'GET', '/api/auth/session');
  need(current.status === 200);
  let session = current.body;
  if (session.activeRole !== role) {
    const selected = await call(handle, 'PUT', '/api/auth/session/active-role', {
      role, expectedSessionVersion: session.sessionVersion,
    });
    need(selected.status === 200 && typeof selected.body.accessToken === 'string');
    need(selected.body.session?.sessionId === session.sessionId);
    session = selected.body.session;
  }
  need(session.activeRole === role);
  return session;
}
async function cleanup(handle) {
  let logoutConfirmed = !handle.loginIssued && !handle.loginAttempted;
  let contextDisposed = false;
  let logoutStatus = 'NOT_NEEDED';
  if (handle.loginIssued || handle.loginAttempted) {
    try {
      const before = await handle.context.storageState();
      const ownsAuth = !!handle.token || ownsRefresh(before);
      const response = await handle.context.post('/api/auth/logout', {
        headers: handle.token ? { Authorization: `Bearer ${handle.token}` } : {},
        timeout: 3000, maxRedirects: 0, maxRetries: 0,
      });
      const status = response.status();
      logoutStatus = [204, 401, 403, 409, 500, 502, 503, 504].includes(status) ? String(status) : 'OTHER';
      await response.dispose();
      const after = await handle.context.storageState();
      // One owned context admits only one session; role selection preserves SID, all retained tokens share it.
      logoutConfirmed = ownsAuth && status === 204 && !ownsRefresh(after);
    } catch { logoutStatus = 'UNCONFIRMED'; }
  }
  handle.token = undefined;
  handle.tokens.clear();
  try { await handle.context.dispose(); contextDisposed = true; } catch {}
  return { owner: handle.owner, logoutStatus, logoutConfirmed, contextDisposed };
}
async function run(output) {
  let stage = 'START';
  const handles = [];
  const facts = {
    stage, status: 'OTHER', boundary: 'OTHER', dependency: 'OTHER', rpc: 'UNKNOWN',
    operationHint: 'UNKNOWN', problemBodyState: 'UNKNOWN', actorRecovery: 'NOT_RUN',
    singleRosterGet: false, noReseedOrDomainWrites: true, clientAcceptance: false,
  };
  try {
    const oldRun = ROOT.replace('/rutcampustrack', '') + '/scratch/rct-validation/client_real_acceptance/focused3-next96-date-r2/runs/attempt-01/supervision';
    const launch = JSON.parse(fs.readFileSync(path.join(oldRun, 'launch.safe.json'), 'utf8'));
    const start = Date.parse(launch.issued_at);
    const finish = fs.statSync(path.join(oldRun, 'terminal.safe.json')).mtimeMs;
    need(Number.isFinite(start) && finish > start);
    const adminUser = sourceModule(ROOT + '/tests/e2e/fixtures/users.ts').TEST_USERS.admin;
    async function owned(owner) {
      const context = await request.newContext({ baseURL: 'https://localhost:8443',
        ignoreHTTPSErrors: true, timeout: 3000, maxRedirects: 0 });
      const handle = { owner, context, token: undefined, tokens: new Set(), loginIssued: false, loginAttempted: false };
      handles.push(handle); // Provisional context is owned before the first auth request.
      return handle;
    }
    stage = 'ADMIN_ADMISSION';
    const admin = await owned('ADMIN');
    await admit(admin, adminUser, 'ADMIN');
    stage = 'EXISTING_ACTOR_LOOKUP';
    const users = await call(admin, 'GET', '/api/academic/users?role=STUDENT&search=%D0%9F%D1%80%D0%BE%D0%B2%D0%B5%D1%80%D0%BA%D0%B0&page=0&size=100&sort=createdAt,desc');
    need(users.status === 200);
    const candidates = completePage(users.body, 'userResponseList').filter(value =>
      value.headman === true && value.firstName === 'Синтетика' &&
      typeof value.lastName === 'string' && /^Проверка[А-Я]{8}$/.test(value.lastName) &&
      Date.parse(value.createdAt) >= start && Date.parse(value.createdAt) < finish,
    ).sort((a, b) => Date.parse(a.createdAt) - Date.parse(b.createdAt));
    need(candidates.length === 2 && Date.parse(candidates[0].createdAt) < Date.parse(candidates[1].createdAt));
    const actor = candidates[0];
    need(Number.isSafeInteger(actor.groupId) && actor.groupId > 0);
    stage = 'EXISTING_ACTOR_CREDENTIAL_VIEW';
    const detail = await call(admin, 'GET', `/api/academic/users/${actor.id}`);
    need(detail.status === 200);
    const credential = unwrap(detail.body);
    need(credential.id === actor.id && credential.groupId === actor.groupId && credential.headman === true &&
      typeof credential.login === 'string' && typeof credential.initialPassword === 'string');
    facts.actorRecovery = 'SOURCE_QUALIFIED_FIRST_WORKER_CHRONOLOGY';
    stage = 'EXISTING_HEADMAN_ADMISSION';
    const headman = await owned('HEADMAN');
    const session = await admit(headman, { login: credential.login, password: credential.initialPassword }, 'HEADMAN');
    need(String(session.userId) === String(actor.id));
    stage = 'EXISTING_LESSON_LOOKUP';
    const lessons = await call(headman, 'GET', `/api/schedule/groups/${actor.groupId}/lessons?dateFrom=2026-10-12&dateTo=2026-10-12&page=0&size=100`);
    need(lessons.status === 200);
    const selected = completePage(lessons.body, 'lessonResponseList');
    need(selected.length === 1);
    const lesson = selected[0];
    need(lesson.groupId === actor.groupId && lesson.date === '2026-10-12');
    stage = 'ONE_ROSTER_GET';
    facts.singleRosterGet = true;
    const witness = await call(headman, 'GET', `/api/attendance/reports/lesson/${lesson.id}`, undefined, true);
    facts.status = [200, 401, 403, 404, 409, 422, 500, 502, 503, 504].includes(witness.status)
      ? String(witness.status) : 'OTHER';
    Object.assign(facts, classifyWitness(witness.status, witness.bytes, witness.contentLength));
    stage = 'CLASSIFIED';
  } catch { facts.failedClosed = true; }
  finally {
    facts.cleanup = [];
    for (const handle of handles.reverse()) facts.cleanup.push(await cleanup(handle));
    facts.cleanupConfirmed = facts.cleanup.every(value => value.logoutConfirmed && value.contextDisposed);
    facts.stage = stage;
    need(typeof output === 'string' && output.startsWith('/tmp/rct-roster-witness-') && output.endsWith('/witness.safe.json'));
    fs.writeFileSync(output, JSON.stringify(facts, null, 2) + '\n', { flag: 'wx', mode: 0o600 });
    process.stdout.write(JSON.stringify({ stage, classified: stage === 'CLASSIFIED', cleanupConfirmed: facts.cleanupConfirmed, failedClosed: facts.failedClosed === true }) + '\n');
    if (stage !== 'CLASSIFIED' || !facts.cleanupConfirmed) process.exitCode = 1;
  }
}
module.exports = { completePage, classifyWitness, call, admit, cleanup };
if (require.main === module) run(process.argv[2]).catch(() => { process.exitCode = 1; });
