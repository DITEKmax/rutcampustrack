import datetime
import hashlib
import json
import os
from pathlib import Path
import stat
import subprocess

OWN=Path(__file__).parent
ROOT=Path('/workspace/scratch/rct-validation')
ART=ROOT/'current_client_artifacts'
records=[]
for rel in ['current_client_artifacts/manifest.json','host_runtime_prepare/manifest.json',
            'host_runtime_prepare/renderer-addendum-manifest.json','host_runtime_prepare/guard-corrections/manifest.json',
            'host_capacity_plan/manifest.json','current_artifact_corrections/manifest.json','host_capacity_correction/manifest.json']:
    p=ROOT/rel
    manifest=json.loads(p.read_text())
    entries=manifest.get('safe_files',manifest.get('files'))
    for entry in entries:
        q=Path(entry['path'])
        assert q.stat().st_size==entry['bytes']
        with q.open('rb') as stream:assert hashlib.file_digest(stream,'sha256').hexdigest()==entry['sha256']
    records.append({'manifest':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),
                    'safe_files':len(entries),'all_exact':True})
source=json.loads((ART/'source-inputs-before.json').read_text())
for entry in source['tracked']:
    q=Path(source['worktree'])/entry['path']
    assert q.stat().st_size==entry['bytes'] and oct(stat.S_IMODE(q.stat().st_mode))==entry['mode']
    with q.open('rb') as stream:assert hashlib.file_digest(stream,'sha256').hexdigest()==entry['sha256']
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=source['worktree']).decode().strip()==source['revision']
deps=json.loads((ART/'installed-deps-before.json').read_text())
expected=set()
for entry in deps['entries']:
    expected.add(entry['path'])
    q=Path(deps['source'])/entry['path']
    if entry.get('kind')=='symlink':
        assert q.is_symlink() and os.readlink(q)==entry['target']
    else:
        assert q.stat().st_size==entry['bytes'] and oct(stat.S_IMODE(q.stat().st_mode))==entry['mode']
        with q.open('rb') as stream:assert hashlib.file_digest(stream,'sha256').hexdigest()==entry['sha256']
actual=set()
for parent,dirs,files in os.walk(deps['source'],followlinks=False):
    base=Path(parent)
    for name in files:actual.add(str((base/name).relative_to(deps['source'])))
    for name in dirs:
        if (base/name).is_symlink():actual.add(str((base/name).relative_to(deps['source'])))
assert actual==expected
jars=[]
for entry in json.loads((ART/'eight-production-jars.json').read_text())['jars']:
    q=Path(entry['jar'])
    with q.open('rb') as stream:sha=hashlib.file_digest(stream,'sha256').hexdigest()
    assert sha==entry['sha256'] and q.stat().st_size==entry['bytes'] and oct(stat.S_IMODE(q.stat().st_mode))==entry['mode']
    jars.append({'producer':'CURRENT908','path':str(q),'sha256':sha,'mode':entry['mode'],'exact':True})
old=Path('/workspace/rutcampustrack/docs/validation/cloud-20261011/receipts/owned-old-java-image-retirement-plan.json')
for entry in json.loads(old.read_text())['rows']:
    for path in entry['retained_exact_jar_paths']:
        q=Path(path)
        with q.open('rb') as stream:sha=hashlib.file_digest(stream,'sha256').hexdigest()
        assert sha==entry['jar_sha256']
        jars.append({'producer':'OLD eec3','path':str(q),'sha256':sha,
                     'mode':oct(stat.S_IMODE(q.stat().st_mode)),'exact':True})
vue=json.loads((ART/'production-vue-bundles.json').read_text())
vue_count=0
for bundle in vue['bundles']:
    for entry in bundle['files']:
        q=Path(bundle['directory'])/entry['path']
        assert q.stat().st_size==entry['bytes'] and oct(stat.S_IMODE(q.stat().st_mode))==entry['mode']
        with q.open('rb') as stream:assert hashlib.file_digest(stream,'sha256').hexdigest()==entry['sha256']
        vue_count+=1
old_processes=[]
for pid,group in [(201385,201350),(201430,201403)]:
    try:
        fields=(Path('/proc')/str(pid)/'stat').read_text().rsplit(')',1)[1].split()
        row={'pid':pid,'state':fields[0],'ppid':int(fields[1]),'pgrp':int(fields[2]),'start_ticks':int(fields[19])}
        assert row['state']=='Z' and row['ppid']==1 and row['pgrp']==group
    except FileNotFoundError:row={'pid':pid,'now_absent':True,'reaped_by_this_task':False}
    old_processes.append(row)
r={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'original_seals':records,
   'all_original_safe_files_exact':True,'safe_files_checked':sum(x['safe_files'] for x in records),
   'tracked_source_count':len(source['tracked']),'tracked_source_SHA_bytes_modes_exact':True,
   'installed_dependency_entry_count':len(deps['entries']),'installed_dependency_SHA_bytes_modes_symlinks_pathset_exact':True,
   'current8_and_old8_JARs':jars,'production_Vue_file_count':vue_count,'production_Vue_SHA_bytes_modes_exact':True,
   'old_processes_observed_only':old_processes,'old_process_mutations':False,'product_or_original_file_mutations':False}
(OWN/'preservation-and-old-process-qualification.json').write_text(json.dumps(r,indent=2)+'\n')
print(json.dumps({'native_exit':0,'original_safe_files_exact':r['safe_files_checked'],'source':len(source['tracked']),
                  'installed_deps':len(deps['entries']),'JARs':len(jars),'Vue_files':vue_count,'old_processes':old_processes}))
