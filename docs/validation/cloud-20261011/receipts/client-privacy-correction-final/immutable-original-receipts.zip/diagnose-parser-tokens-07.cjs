'use strict';
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const ts = require('/workspace/rutcampustrack/frontends/node_modules/typescript/lib/typescript.js');
const own = __dirname;
const wt = '/workspace/rct-worktrees/client-privacy-boundary-eb';
const root = '/workspace/rutcampustrack';
const granted = JSON.parse(fs.readFileSync(path.join(own, 'root-node-correction-grant-02.json'))).source_hashes;
const hash = (x) => crypto.createHash('sha256').update(x).digest('hex');
const exactGrouping = (node, parent) => ts.isParenthesizedExpression(node) &&
  parent && ts.isConditionalExpression(parent) && parent.condition === node &&
  ts.isBinaryExpression(node.expression) && node.expression.operatorToken.kind === ts.SyntaxKind.BarBarToken &&
  ts.isIdentifier(node.expression.left) && node.expression.left.text === 'red' &&
  ts.isIdentifier(node.expression.right) && node.expression.right.text === 'interrupted';
const canonical = (source, file, normalize) => {
  const ast = ts.createSourceFile(file, source, ts.ScriptTarget.ES2022, true);
  let normalized = 0;
  const visit = (node, parent) => {
    if (normalize && exactGrouping(node, parent)) { normalized++; return visit(node.expression, parent); }
    const children = [];
    ts.forEachChild(node, (child) => { children.push(visit(child, node)); });
    return { kind: node.kind, text: ts.isSourceFile(node) ? undefined : node.text,
      optionalChain: Boolean(node.flags & ts.NodeFlags.OptionalChain), children };
  };
  return { parseErrorCodes: ast.parseDiagnostics.map((x) => x.code), tree: JSON.stringify(visit(ast)), normalized };
};
const comments = (source) => {
  const scanner = ts.createScanner(ts.ScriptTarget.ES2022, false, ts.LanguageVariant.Standard, source);
  const result = [];
  for (let kind = scanner.scan(); kind !== ts.SyntaxKind.EndOfFileToken; kind = scanner.scan())
    if (kind === ts.SyntaxKind.SingleLineCommentTrivia || kind === ts.SyntaxKind.MultiLineCommentTrivia)
      result.push(scanner.getTokenText());
  return JSON.stringify(result);
};
const emit = (source, fileName, module, normalize) => {
  let normalized = 0;
  const transformer = (context) => {
    const visit = (node, parent) => {
      if (normalize && exactGrouping(node, parent)) { normalized++; return visit(node.expression, parent); }
      return ts.visitEachChild(node, (child) => visit(child, node), context);
    };
    return (file) => visit(file);
  };
  const text = ts.transpileModule(source, {
    fileName,
    compilerOptions: { target: ts.ScriptTarget.ES2022, module, removeComments: true },
    transformers: normalize ? { before: [transformer] } : undefined,
  }).outputText;
  return { text, normalized };
};

const tokens = (text) => {
  const file = ts.createSourceFile('emission.mjs', text, ts.ScriptTarget.ES2022, true);
  if (file.parseDiagnostics.length) throw new Error('Emitted token parse failed');
  const result = [];
  const visit = (node) => {
    const children = node.getChildren(file);
    if (children.length) { for (const child of children) visit(child); }
    else if (node.kind !== ts.SyntaxKind.EndOfFileToken && node.kind <= ts.SyntaxKind.LastToken)
      result.push({ kind: node.kind, text: node.getText(file) });
  };
  visit(file);
  return result;
};

(async () => {
  const prettier = await import('/workspace/rct-worktrees/client-current-artifacts/frontends/node_modules/prettier/index.mjs');
  const relative = 'tests/e2e/check-artifact-privacy.mjs';
  const before = fs.readFileSync(path.join(own, 'before-grant02', relative), 'utf8');
  const config = await prettier.resolveConfig(path.join(root, relative));
  const after = await prettier.format(before, { ...config, filepath: path.join(root, relative) });
  const rows = [];
  for (const [mode, module] of [['ESNext', ts.ModuleKind.ESNext], ['CommonJS', ts.ModuleKind.CommonJS]]) {
    const a = emit(before, relative, module, true); const b = emit(after, relative, module, true);
    const parseA = canonical(a.text, relative, false); const parseB = canonical(b.text, relative, false);
    const tokensA = tokens(a.text); const tokensB = tokens(b.text);
    let firstTokenDifference = null;
    for (let i = 0; i < Math.max(tokensA.length, tokensB.length); i++) {
      if (tokensA[i]?.kind !== tokensB[i]?.kind || tokensA[i]?.text !== tokensB[i]?.text) {
        firstTokenDifference = { index: i, beforeKind: tokensA[i]?.kind ?? null, afterKind: tokensB[i]?.kind ?? null, sameText: tokensA[i]?.text === tokensB[i]?.text }; break;
      }
    }
    let firstByteDifference = null;
    const charKind = (c) => c === undefined ? 'EOF' : c === '\n' ? 'NEWLINE' : /\s/.test(c) ? 'WHITESPACE' : /[A-Za-z0-9_$]/.test(c) ? 'WORD' : 'PUNCTUATION';
    for (let i = 0; i < Math.max(a.text.length, b.text.length); i++)
      if (a.text[i] !== b.text[i]) { firstByteDifference = { index: i, beforeCharKind: charKind(a.text[i]), afterCharKind: charKind(b.text[i]) }; break; }
    rows.push({ mode, exactSourceNormalizationBefore: a.normalized, exactSourceNormalizationAfter: b.normalized, rawEmissionEqual: a.text === b.text, rawBeforeSha256: hash(a.text), rawAfterSha256: hash(b.text), emittedParseCodesBefore: parseA.parseErrorCodes, emittedParseCodesAfter: parseB.parseErrorCodes, strictEmittedASTEqual: parseA.tree === parseB.tree, completeTokenKindTextEqual: firstTokenDifference === null, tokenCountBefore: tokensA.length, tokenCountAfter: tokensB.length, firstTokenDifference, firstByteDifference });
  }
  fs.writeFileSync(path.join(own, 'parser-token-diagnostic.safe.json'), JSON.stringify({ state: 'READONLY_PARSED_EMISSION_TOKEN_DIAGNOSIS', sourceChanged: false, preservesAllLiteralOperatorNameSemicolonTokens: true, rows }, null, 2) + '\n');
})().catch(() => { fs.writeFileSync(path.join(own, 'parser-token-diagnostic.safe.json'), JSON.stringify({ state: 'DIAGNOSTIC_FAILED', rawErrorSuppressed: true }) + '\n'); process.exit(1); });
