// Browser-free privacy counterexample controls; run ONLY after a fresh Root Node grant.
const fs = require('node:fs');
const path = require('node:path');
const Module = require('node:module');
const ts = require('/workspace/rutcampustrack/frontends/node_modules/typescript/lib/typescript.js');
const filename = path.join(__dirname, 'observer.ts');
const result = ts.transpileModule(fs.readFileSync(filename, 'utf8'), {
  compilerOptions: { target: ts.ScriptTarget.ES2022, module: ts.ModuleKind.CommonJS },
  reportDiagnostics: true,
  fileName: filename,
});
if (result.diagnostics?.some((item) => item.category === ts.DiagnosticCategory.Error)) {
  process.stdout.write('{"stage":"PARSER","pass":false}\n');
  process.exit(1);
}
const loaded = new Module(filename, module);
loaded.filename = filename;
loaded.paths = Module._nodeModulePaths(__dirname);
loaded._compile(result.outputText, filename);
const validate = loaded.exports.validateFacts;
const accepted = [{ httpStatus: '200', activeRole: 'STUDENT', targetPresent: true, itemCount: 1 },
  { domStatus: 'UNSUPPORTED', targetButtonEnabled: false, testStatus: 'failed' }];
// Public synthetic strings exist only in this source/control memory, never in output.
const rejected = [{ targetPresent: 'PUBLIC_SYNTHETIC_PRIVATE_VALUE' }, { name: 'PUBLIC_SYNTHETIC_PRIVATE_VALUE' },
  { activeRole: 'OPEN_UNKNOWN_ROLE' }, { targetStatus: 'NEW_UNACCEPTED_STATUS' },
  { body: { value: 'PUBLIC_SYNTHETIC_PRIVATE_VALUE' } }, { itemCount: -1 }, { itemCount: NaN }];
let positives = 0;
let negatives = 0;
for (const value of accepted) { try { validate(value); positives++; } catch {} }
for (const value of rejected) { try { validate(value); } catch { negatives++; } }
const pass = positives === accepted.length && negatives === rejected.length;
const safe = { stage: 'CLOSED_FIELD_ALLOWLIST', positives, negatives, pass };
const output = process.env.RCT_FOCUS3_FIELDS_OUTPUT;
if (output !== path.join(process.env.RCT_FOCUS3_RUN ?? '', 'supervision', 'fields.safe.json')) {
  throw new Error('Source field controls require their private safe output');
}
fs.writeFileSync(output, JSON.stringify(safe, null, 2) + '\n', { mode: 0o600 });
process.stdout.write(JSON.stringify(safe) + '\n');
process.exit(pass ? 0 : 1);
