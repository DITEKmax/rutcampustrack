"""Narrow independent source/date/path recheck; no target imports or runtime execution."""
import ast
import datetime as dt
import hashlib
import json
from pathlib import Path
import zipfile
from zoneinfo import ZoneInfo

BASE = Path('/workspace/scratch/rct-validation/client_real_acceptance/focused3-next96-date-r2')
OLD = BASE.with_name('focused3-next96-r1')
R1 = BASE.with_name('focused3-preparation-5ced-r1')
ROOT = Path('/workspace/rutcampustrack')
OWN = Path(__file__).parent
sha = lambda b: hashlib.sha256(b).hexdigest()
ready = json.loads((BASE/'READY.safe.json').read_bytes())
assert sha((BASE/'READY.safe.json').read_bytes()) == '0dcc8a2ac9b118d2cd1a57f6928b492b7077ef228d62646e2b0ef91542389ce8'
manifest = json.loads((BASE/'manifest.safe.json').read_bytes())
with zipfile.ZipFile(BASE/'focused3-date-source.safe.zip') as z:
    assert len(z.namelist()) == len(set(z.namelist())) == 8
    for row in manifest['files']:
        data = z.read(row['path'])
        assert data == (BASE/row['path']).read_bytes()
        assert len(data) == row['bytes'] and sha(data) == row['sha256']
    assert z.read('manifest.safe.json') == (BASE/'manifest.safe.json').read_bytes()
caller = (BASE/'run-focus3.py').read_text()
assert sha((OLD/'run-focus3.py').read_bytes()) == ready['parent_next96_driver_sha256'] == 'e7b5dca63157f50c4aceb0df08f905544ca9b68cd7ddde2e569973f6ccf24ee3'
assert caller.replace(str(BASE),str(OLD)).encode() == (OLD/'run-focus3.py').read_bytes()
ast.parse(caller)
config = (BASE/'focus3.config.ts').read_text()
old_config = (OLD/'focus3.config.ts').read_text()
reverse = config.replace("const root = '"+str(BASE)+"';", "const root = '"+str(R1)+"';").replace("const runRoot = '"+str(BASE)+"';", "const runRoot = '"+str(OLD)+"';")
assert reverse == old_config
wrapper = (BASE/'focus3.spec.ts').read_text()
before = 'test.beforeEach(async ({ page, dataset }, info) => {\n'
after = "test.beforeEach(async ({ page, dataset, teachingInstant }, info) => {\n  if (!teachingInstant) throw new Error('Focused FIRST3 teaching instant is required');\n  // Date shares the dataset/domain day; real timers and backend security time remain enabled.\n  await page.clock.setFixedTime(teachingInstant);\n"
assert wrapper.count(after) == 1
restored = wrapper.replace(after,before).replace("from '"+str(R1)+"/observer';", "from './observer';")
assert restored.encode() == (R1/'focus3.spec.ts').read_bytes()
for path,digest in ready['root_source_hashes'].items():
    assert sha((ROOT/path).read_bytes()) == digest
for path,digest in ready['r1_source_hashes'].items():
    assert sha((R1/path).read_bytes()) == digest
assert sha((R1/'READY.safe.json').read_bytes()) == ready['r1_ready_sha256']
assert sha((OLD/'READY.safe.json').read_bytes()) == ready['parent_next96_ready_sha256']
assert "new RegExp(`^${runRoot}/runs/attempt-[0-9]{2}$`)" in config
assert 'testDir: root,' in config and 'testMatch: \'focus3.spec.ts\'' in config
assert "(info.mode & 0o777) !== 0o700" in config
assert "stat.S_IMODE(value.st_mode) == 0o700" in caller and "runs.mkdir(mode=0o700)" in caller
assert "str(BASE / 'focus3.config.ts')" in caller
assert "grant_path.parent == BASE / 'private'" in caller
assert 'stat.S_IMODE(grant_stat.st_mode) == 0o600' in caller
assert "ready_sha256'] == digest(BASE / 'READY.safe.json')" in caller
assert wrapper.index('if (!teachingInstant)') < wrapper.index('await page.clock.setFixedTime') < wrapper.index('new FocusObserver') < wrapper.index('observer.start()') < wrapper.index("require('/workspace/rutcampustrack/tests/e2e/specs/mobile-real-server.spec.ts')")
assert "teachingInstant: [undefined, { scope: 'worker', option: true }]" in (ROOT/'tests/e2e/fixtures/mobile-dataset.ts').read_text()
assert 'keeps all the timers running.' in (ROOT/'tests/e2e/node_modules/playwright-core/types/types.d.ts').read_text()
moscow = ZoneInfo('Europe/Moscow')
retained = dt.datetime(2026,10,12,6,tzinfo=dt.timezone.utc)
rows=[]
for utc in ('2026-10-12T20:59:59+00:00','2026-10-12T21:00:00+00:00','2026-10-12T23:11:04+00:00'):
    day = dt.datetime.fromisoformat(utc).astimezone(moscow).date()
    teaching_day = retained.astimezone(moscow).date()
    rows.append({'utc':utc,'old_default_matches_domain':day==teaching_day,'fixed_default_matches_domain':True})
assert [r['old_default_matches_domain'] for r in rows] == [True,False,False]
auth = json.loads((BASE.with_name('ci-first3-db177-r1')/'correction-controls.safe.json').read_text())
for path in ('frontends/pwa-vue/src/auth.ts','frontends/pwa-vue/src/auth-client.ts','frontends/pwa-vue/src/session-coherence.ts','frontends/mobile-core/src/shared/session-owner.ts'):
    assert sha((ROOT/path).read_bytes()) == auth['sourcePins'][path]
result={'kind':'INDEPENDENT_CLOUD_FIRST3_FINITE_DATE_SOURCE_RECHECK','verdict':'APPROVE_SOURCE_ONLY','requested_selected':'gpt-6.1-sol/high','actual_model_effort':'UNKNOWN','checks':{'sealed_eight_members':True,'full_caller_BASE_reverse':True,'full_config_two_path_reverse':True,'full_wrapper_clock_import_reverse':True,'root19_r1sources13_and_parent_READY_preserved':True,'absolute_test_run_config_and_private_modes_bound':True,'clock_missing_guard_and_awaited_hook_order':True,'calendar':rows,'accepted_auth_source_pins_unchanged':True},'native_Node_browser_API_stand':'NOT_RUN','historical_three_failure_cause':'UNKNOWN','qualifications':['Browser Date CHANGED for FIRST3','Timers supported API SOURCE only','Backend security sources unchanged; full client expiry/recovery/cooldown not proven','Fresh ordinary-context Node metadata and current cohort/readiness/grant required']}
(OWN/'checks.safe.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'verdict':result['verdict'],'bounded_groups':len(result['checks']),'calendar_cases':len(rows)}))
