# DF-CLIENT-ROSTER-503-001 — source plan

Status: ROOT_APPROVED_ADDITIVE_CONTRACT; baseline wire fixture SOURCE_READY;
runtime NOT_RUN; actual model/effort UNKNOWN.
Base: 48124f576f51cc62fbdd95c7908b61d587f9e36d.
Sole Java writer: /workspace/rct-worktrees/roster-academic-auth-backend,
branch codex/roster-academic-auth-20261013. Root owns shared docs/config and is
contract decision owner/integrator. Root transferred exclusive proto/academic.proto
and assigned Java/tests writing to this author in this worktree.

## Causal argument

ReportService.getLessonAttendance fetches Schedule lesson, authorizes the live own-group
actor via signed CheckAssistantPermission, then buildLessonAttendance reads historical
GetGroupMembers followed by GetSemesterState for student/headman actors. Authorization
CheckAssistantPermission translates UNAUTHENTICATED to HTTP 401, not the witnessed 503.
GetGroupMembers is absent from the exact-method JWT and service policies; its historical
domain path has only validation/not-found/precondition failures. The common gRPC-secret
policy is shared by the preceding successful permission check on the same injected stub.

GetSemesterState is expressly protected by the global AssignmentCloseServiceIdentityInterceptor:
only SCHEDULE_SERVICE, directed Schedule→Academic token, authenticated TLS. The attendance
client uses its ordinary plaintext academic-service stub without service call credentials.
ServiceIdentityServerInterceptor rejects this method before inspecting a token and before
the handler. AcademicGrpcClient.getSemesterState translates the resulting UNAUTHENTICATED
to AcademicServiceUnavailableException/HTTP 503. This exactly matches the observed closed
boundary ATTENDANCE_DEPENDENCY/ACADEMIC/UNAUTHENTICATED. Real witness method is still UNKNOWN;
an isolated real Netty transport counterexample must validate the inference before fix.

## Frozen compatible contract (Root technical approval received)

Add only GetHeadmanJournalSemesterState(HeadmanJournalSemesterStateRequest) returning the
existing SemesterStateResponse. New request: int64 group_id = 1; int64 semester_id = 2.
Authenticate exact original x-internal-token at existing InternalJwtValidator boundary.
Academic rechecks current durable own-group capability and returns uncached state.
Current concrete-lesson journal admission is VIEW_STATS OR MARK_ATTENDANCE; repository
AssistantPermission and accepted JS-HEADMAN-14 have no VIEW_JOURNAL. No grant is invented.
The mark-only helper must remain admitted without requiring VIEW_STATS. Stats endpoints
retain their independent VIEW_STATS gate. Map INVALID_ARGUMENT→400, NOT_FOUND→404,
PERMISSION_DENIED→403, UNAUTHENTICATED→401, unavailable/internal→503.

Preserve existing GetSemesterState Schedule TLS/service admission byte-for-byte. Preserve
historical roster/date/semester echoes, all state/version/transition fields and archived /
writeBlocked behavior. No public REST/DTO changes, DB/migrations/ordinal changes, shared
credentials/configuration, frontend changes, role expansion or Schedule identity borrowing.
Related student-detail stats calls also use the same wrongly directed method and will use
the new signed state RPC after their existing VIEW_STATS admission, approved by Root.

## Verification strategy

Existing source patterns: shared-security ServiceIdentityTlsTransportTest for real Netty
socket admission; AcademicAssignmentGrpcIT for producer/interceptor gRPC integration;
HeadmanStatsScopeIT for fresh PostgreSQL own-group/helper/revocation fixtures;
SemesterArchiveStateIT for authoritative transition/writeBlocked checks;
ReportServiceTest/HeadmanStatsServiceTest for journal cells and archived disabled controls.

Minimal new significant regression checks: real plaintext GetGroupMembers succeeds while
GetSemesterState fails UNAUTHENTICATED before handler; new signed journal-state realwire
success, missing/tampered token denial, retained old method rejection; fresh DB HEADMAN and
mark-only/helper view-only admission, no-permission/revoked/foreign scope denial, invalid /
missing semester and archived/transition state echo. Meaningful known-bad restoring old
journal call must fail the journal-state transport expectation, then restore green.

No Gradle, Docker, DB or service/test process has been started. Need fresh Root resource
grant and exact approved tasks before any runtime. Final accepted roster200 remains OPEN.

Independent source review by ci731_reconcile: baseline fixture cfc9 meaningful expected
Netty causal RED, native compilation pending. Driver c78/child a987/plan b88 retained.
Launcher finding: direct or stale logged child entrypoint lacks fresh grant/live owned
parent gate. Root authorized caller-only correction; old scripts c78/a987 retained
immutable. New driver388007/child26ed3 write parent birth/source/grant envelope BEFORE
dispatch (no STARTED race or spin). Child independently checks no-follow mode600 private
grant, exact fresh clock/pins/private namespace, live direct parent PID/birth/cmdline,
live child PPID, and repeats identities before Gradle. b78 unchanged; all caps unchanged.
Actual selected RAM AST controls tool c06eba native0: old direct/no-grant admitted;
new missing/stale/foreign/reused-birth/wrong-source/unapproved denied; fresh parent allowed.
No Gradle/socket/DB/process launch; no product verdict. Independent narrow recheck
APPROVE_SOURCE aa7fb19b/140874f6 received: reviewer actual-source RAM12 PASS including
extra/wrong parent argv and wrong direct child PPID denials. Root fresh native grant pending.

## Prepared before fixture and task proposal

HeadmanJournalSemesterTransportTest.before.java retained SHA256
cfc9aa7dba0cc711d6c38b1cc40a9d6c28889204a6675e09d1a8ace2bab89268.
It first demonstrates signed permission+historical roster succeed, then the old protected
state RPC rejects before repository access. Last assertion expresses the intended journal
state success on the old method and must be RED UNAUTHENTICATED. Product base unchanged481.
Do not treat the expected failing intended assertion as a source/compiler failure.

Before product fix, grant requested for a single sequential wrapper invocation:
./gradlew --no-daemon --max-workers=1 -Dorg.gradle.jvmargs=-Xmx1g
:services:academic-service:academic-app:compileJava
:services:academic-service:academic-app:compileTestJava
:services:academic-service:academic-app:test
--tests ru.rutcampustrack.academic.grpc.HeadmanJournalSemesterTransportTest
Only ephemeral localhost Netty socket in worker; no Docker/DB/app service bootstrap.
Academic test's existing nontransitive Auth dependency may compile Auth main/plain jar;
no Auth tests are selected. Separate generated/build outputs are within own worktree.

After approved additive source fix, native generator tasks are existing per-consumer
:services:academic-service:academic-app:generateProto and
:services:attendance-service:attendance-app:generateProto, automatically dependencies
of the respective compileJava tasks. No manual generated files or generator changes.
Then both modules compileJava/compileTestJava, targeted wire/rights/state tests in a single
sequential invocation; exact class list will be frozen after source implementation.
