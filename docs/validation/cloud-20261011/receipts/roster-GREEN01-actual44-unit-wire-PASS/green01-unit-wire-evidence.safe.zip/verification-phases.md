# T008 finite checking phases

Current semantic Source commit895d404f23beb47c93ca210be6f9161cd09945ec from481.
Source whole review81ced/d423 APPROVE_SOURCE, no product PASS inferred.

1. FORMAT01: exact12Java target filter in checking-only init, existing formatJava then
   formatJavaCheck with original GoogleJavaFormat1.25.2/AOSP steps. Before/after git
   inventories differ only12Java; proto/policies/configs exact. Separate mechanical
   commit and token/string-preserving formatter diff proof. No compiler/test/socket/DB /
   Docker. Fresh Root grant required, not issued yet.

2. GREEN01: freeze formatted13-source manifest and new independent namespace. Existing
   wrapper/offline/JDK21/b78 guards. One sequential Gradle invocation, no parallel,
   max-workers1, compileJava and compileTestJava for Academic AND Attendance first;
   native generators are existing automatic dependencies, no manual generated outputs.
   Then Academic test filter HeadmanJournalSemesterTransportTest; Attendance test
   filters HeadmanJournalSemesterClientTransportTest, ReportServiceTest,
   HeadmanStatsServiceTest, all fully qualified. No DB/Docker. XML requires every selected
   class executed, counts>0, failures/errors/skips=0; native0 alone insufficient.

3. IT01: separate genuine NEW PostgreSQL and Mongo Testcontainers only after fresh Root
   resource grant permits owned container/namespace cleanup. Existing inheritance owns
   fresh random academic_ci_ database/non-reused resource; no retained stand volumes /
   Mongo key/data160 touched. Minimal classes: Academic HeadmanJournalSemesterStateIT
   and HeadmanStatsScopeIT; existing SemesterArchiveStateIT's
   getSemesterState_reportsTransitionsReplayAndWriteBlock for actual lifecycle commands.
   Attendance ReportIT plus MarkingIT.journal_historicalRoster_authorizedFileAndClear.
   Same sequential invocation; compiled outputs reused if unchanged. New SQLtest uses
   direct signed-claims handler with real repositories/rollback; actual signature and
   transport denial belongs to separate Netty check, not claimed by SQLtest.

4. MUTATION01: only actual AcademicGrpcClient.getHeadmanJournalSemesterState invocation
   newRPC/request to existing GetSemesterState/SemesterStateRequest, same semester.
   Keep JWT/deadline/mappings and ALL test expectations unchanged. Product mutation must
   compile; actual ServiceIdentityServerInterceptor in clientNetty test protects old
   method for Schedule/TLS, so original positive state expectation mustFAIL401. Retain
   exact mutant Source/compiler/class/XML/sourcepolicy join; TLS description Source-bound
   for this run unless closed native trace exists. Baseline RED01 independently observed
   exact TLS UNAUTH on real actualAcademic handler already. Restore exact original file
   bytes in finally; restore GREEN same targeted clienttest.

5. Root fresh independent implementation/runtime evidence review; integration into
   current designated branch, coherent updated Academic+Attendance artifacts, actual
   accepted roster200/data/role denial/revoke/archive guards and current gates. Own
   Source/isolated checks cannot claim realclientPASS.

Caps proposed per native phase: phase540seconds+60cleanup under fresh600 authorization,
ownedRSS4GiB/sharedstop15GiB/reserve1GiB/growth4GiB/workspacefloor4GiB/diskgrowth2GiB/log8MiB.
IT needs explicit container ownership/namespaces/resource allowance and sufficient measured
capacity; it is not included in FORMAT01/GREEN01. No new runner framework/control plane.
