COMPLETE_TEST_ONLY_SOURCE_READY; no active checkout/process.
WT exact4c3745f2 HEAD with one test WIP5a4a and productionoriginal4f62.
No Gradle/JVM/API/Docker/native test, no fix; fresh independent review pendingRoot.
Original prep seal preserved.
