'use strict';
// Source-derived controls. Only this public random marker reaches local synthetic adapters.
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const crypto = require('node:crypto');
const { createRequire } = require('node:module');
const root = '/workspace/rutcampustrack';
const own = __dirname;
const payload = path.join(own, 'control-payload');
const tsPath = '/workspace/rct-worktrees/client-current-artifacts/frontends/node_modules/typescript/lib/typescript.js';
const ts = require(tsPath);
const indexPath = path.join(root, 'tests/e2e/node_modules/playwright/lib/index.js');
const contextPath = path.join(root, 'tests/e2e/node_modules/playwright/lib/errorContext.js');
const privacyPath = path.join(root, 'tests/e2e/fixtures/artifact-privacy.ts');
const reporterPath = path.join(root, 'tests/e2e/fixtures/safe-reporter.ts');
const source = fs.readFileSync(indexPath, 'utf8');
const start = source.indexOf('class SnapshotRecorder {');
const end = source.indexOf('\nasync function installScreencastTitleUpdater', start);
if (start < 0 || end < 0) throw new Error('Producer extraction boundary changed');
const extracted = source.slice(start, end);
const helperStart = source.indexOf('function normalizeScreenshotMode(screenshot) {');
const helperEnd = source.indexOf('\nfunction attachConnectedHeaderIfNeeded', helperStart);
if (helperStart < 0 || helperEnd < 0) throw new Error('Producer helper boundary changed');
const helper = source.slice(helperStart, helperEnd);
const ArtifactsRecorder = vm.runInNewContext(helper + '\n' + extracted + '\nArtifactsRecorder;', {
  process,
  import_fs: { default: fs },
  import_errorContext: require(contextPath),
  kTracingStarted: Symbol('control-tracing'),
});
const compileCurrent = (filename) => {
  const output = ts.transpileModule(fs.readFileSync(filename, 'utf8'), {
    compilerOptions: { target: ts.ScriptTarget.ES2022, module: ts.ModuleKind.CommonJS },
    fileName: filename,
  }).outputText;
  const module = { exports: {} };
  vm.runInNewContext(output, { module, exports: module.exports, require: createRequire(filename), process });
  return module.exports;
};
const { sanitizeTestErrors } = compileCurrent(privacyPath);
const SafeReporter = compileCurrent(reporterPath).default;
const marker = 'RCT_PUBLIC_CONTROL_' + crypto.randomUUID();
const hash = (value) => crypto.createHash('sha256').update(value).digest('hex');
fs.mkdirSync(payload, { recursive: true, mode: 0o700 });
const rows = [];
let currentStage = 'INITIAL';
async function check(stage, entry, flag, errorMode, reporterCalled) {
  currentStage = stage;
  delete process.env.PLAYWRIGHT_NO_COPY_PROMPT;
  delete process.env.PW_TEST_DISABLE_ERROR_CONTEXT;
  if (flag === 'supported') process.env.PLAYWRIGHT_NO_COPY_PROMPT = '1';
  if (flag === 'unsupported') process.env.PW_TEST_DISABLE_ERROR_CONTEXT = '1';
  const out = path.join(payload, stage);
  fs.mkdirSync(out, { recursive: true, mode: 0o700 });
  let snapshotCalls = 0;
  const syntheticPage = {
    _wrapApiCall: async (callback) => callback(),
    ariaSnapshot: async () => { snapshotCalls++; return '- text: ' + marker; },
  };
  const context = {
    tracing: {},
    pages: () => [syntheticPage],
    _wrapApiCall: async (callback) => callback(),
  };
  const info = {
    file: path.join(root, 'tests/e2e/specs/mobile-real-server.spec.ts'),
    line: 14, column: 1, retry: 0,
    titlePath: ['public-source-control'],
    attachments: [],
    errors: [{ message: errorMode === 'early' ? marker : 'Check failed' }],
    outputPath: (name) => path.join(out, name),
    _attach: (attachment) => info.attachments.push(attachment),
    _tracing: { traceOptions: () => undefined },
  };
  sanitizeTestErrors(info);
  // Mirrors the independently read workerMain ordering: afterEach, then fixture teardown.
  // No claim that this adapter executes the complete real worker fixture runner.
  if (errorMode === 'late' || errorMode === 'resanitized') info.errors.push({ message: marker });
  if (errorMode === 'resanitized') sanitizeTestErrors(info);
  const recorder = new ArtifactsRecorder({ _allContexts: () => [context], request: { _contexts: [] } }, out, 'off');
  recorder._testInfo = info;
  if (entry === 'context-close') await recorder.willCloseBrowserContext(context);
  await recorder.didFinishTest();
  const artifact = path.join(out, 'error-context.md');
  const producerMarkerPresent = fs.readFileSync(artifact, 'utf8').includes(marker);
  const test = { location: { file: info.file, line: info.line }, parent: { project: () => ({ name: 'source-control' }) }, expectedStatus: 'passed' };
  const result = { status: 'failed', duration: 0, errors: info.errors, attachments: info.attachments };
  let markerAbsentAfterReporter = null;
  if (reporterCalled) {
    const reporter = new SafeReporter();
    reporter.onBegin({ projects: [{ outputDir: out }] });
    reporter.onTestEnd(test, result);
    markerAbsentAfterReporter = !fs.readFileSync(artifact, 'utf8').includes(marker);
  }
  const expectedMarker = flag !== 'supported' || errorMode === 'late';
  rows.push({ stage, entry, flag, errorMode, snapshotCalls, producerMarkerPresent, reporterCalled,
    markerAbsentAfterReporter,
    expectationMatched: producerMarkerPresent === expectedMarker && (flag !== 'supported' || snapshotCalls === 0) && (!reporterCalled || markerAbsentAfterReporter === true) });
}
(async () => {
  for (const entry of ['context-close', 'final-teardown']) {
    for (const flag of ['unset', 'supported', 'unsupported']) {
      await check(entry + '-' + flag, entry, flag, 'ordinary', true);
    }
  }
  await check('early-error-sanitized', 'final-teardown', 'supported', 'early', true);
  await check('late-error-after-afterEach', 'final-teardown', 'supported', 'late', true);
  await check('late-error-resanitized-before-producer', 'final-teardown', 'supported', 'resanitized', true);
  await check('interrupt-before-reporter-late-error', 'final-teardown', 'supported', 'late', false);
  const passed = rows.every((row) => row.expectationMatched);
  const receipt = {
    state: passed ? 'EXPECTED_COUNTEREXAMPLES_REPRODUCED' : 'CONTROL_EXPECTATION_FAILED',
    browser: 'NOT_STARTED', api: 'NOT_STARTED', network: 'NOT_USED',
    version: require(path.join(root, 'tests/e2e/node_modules/playwright/package.json')).version,
    typescriptToolVersion: ts.version,
    actualProducerClassExtraction: true,
    producerSourceSha256: hash(fs.readFileSync(indexPath)),
    extractedClassSha256: hash(extracted),
    extractedHelperSha256: hash(helper),
    actualErrorContextSourceSha256: hash(fs.readFileSync(contextPath)),
    currentPrivacySourceSha256: hash(fs.readFileSync(privacyPath)),
    currentReporterSourceSha256: hash(fs.readFileSync(reporterPath)),
    unsupportedFlagReferencedByProducer: source.includes('PW_TEST_DISABLE_ERROR_CONTEXT'),
    rows,
    markerValueLoggedOrArchived: false,
    lateErrorQualification: 'Exact actual producer + current sanitizer/reporter; worker teardown ordering source-derived, full fixture runner NOT_EXECUTED',
    interruption: 'Next action is actual SIGTERM before canonical onTestEnd callback for final control; all prior controls invoked actual current reporter.',
  };
  fs.writeFileSync(path.join(own, 'controls.safe.json'), JSON.stringify(receipt, null, 2) + '\n', { mode: 0o600 });
  if (!passed) process.exit(1);
  process.kill(process.pid, 'SIGTERM');
})().catch((error) => {
  const type = ['ReferenceError', 'TypeError', 'Error'].includes(error?.name) ? error.name : 'Other';
  fs.writeFileSync(path.join(own, 'controls.safe.json'), JSON.stringify({ state: 'CONTROL_EXECUTION_FAILED', stage: currentStage, errorType: type, rawErrorSuppressed: true }) + '\n', { mode: 0o600 });
  process.exit(1);
});
