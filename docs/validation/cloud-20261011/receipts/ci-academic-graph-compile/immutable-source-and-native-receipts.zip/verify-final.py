import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess

ROOT = Path('/workspace/rct-worktrees/ci-academic-heap')
OUT = Path('/workspace/scratch/rct-validation/ci_academic_graph_compile')


def read(name):
    return json.loads((OUT / name).read_text())


def write(name, value):
    (OUT / name).write_text(json.dumps(value, indent=2) + '\n')


baseline = read('baseline-graph.json')
candidate = read('candidate-graph.json')
classpath = read('candidate-classpath.json')
comparison = {}
security = {}
for name, previous in baseline['graphs'].items():
    current = candidate['graphs'][name]
    encode = lambda row: json.dumps(row, sort_keys=True)
    old = {encode(row): row for row in previous['artifacts']}
    new = {encode(row): row for row in current['artifacts']}
    added = [new[key] for key in sorted(new.keys() - old.keys())]
    removed = [old[key] for key in sorted(old.keys() - new.keys())]
    old_components = {encode(row): row for row in previous['components']}
    new_components = {encode(row): row for row in current['components']}
    added_components = [new_components[key] for key in sorted(new_components.keys() - old_components.keys())]
    removed_components = [old_components[key] for key in sorted(old_components.keys() - new_components.keys())]
    assert not removed and not removed_components, name
    if name in ['academic:testCompileClasspath', 'academic:testRuntimeClasspath']:
        assert len(added) == 1 and len(added_components) == 1, name
        assert added[0]['component'] == 'project :services:auth-service:auth-app', name
        assert added[0]['kind'] == 'file_sha256', name
        assert added_components[0]['id'] == added[0]['component'], name
    else:
        assert not added and not added_components, name
    added_paths = {row['file'] for row in added}
    assert [path for path in current['orderedFiles'] if path not in added_paths] == previous['orderedFiles'], name
    security_selector = lambda row: ('org.springframework.security:' in row['component']
                                    or ':spring-boot-starter-security:' in row['component']
                                    or 'io.jsonwebtoken:' in row['component']
                                    or 'shared-security' in row['component'])
    old_security = [row for row in previous['artifacts'] if security_selector(row)]
    new_security = [row for row in current['artifacts'] if security_selector(row)]
    assert old_security == new_security, name
    security[name] = old_security
    comparison[name] = {'before': len(old), 'after': len(new), 'added': added,
                        'added_components': added_components, 'removed': removed,
                        'retained_coordinates_variant_capabilities_sha_order': 'EXACT',
                        'declared_absent_outputs': [row for row in new.values()
                                                    if row['kind'] == 'declared_absent_output']}
assert len(classpath['duplicateCanonicalClasses']) == 360
assert not classpath['duplicateMismatches'] and not classpath['incorrectResourcePriority']
assert classpath['authProducerPresent'] and classpath['unitClasspathSameOrder']
assert classpath['integrationHeap'] == '1g' and classpath['maxParallelForks'] == 1
assert candidate['testResources']['unitMaxHeap'] is None
assert candidate['gradleJvm']['maxHeapBytes'] == 805306368
assert set(candidate['gradleJvm']['boundedArguments']) == {'-Xmx768m', '-XX:MaxMetaspaceSize=256m'}

before = read('source-inputs.before.json')
after = []
for row in before:
    path = ROOT / row['file']
    after.append({'file': row['file'], 'sha256': hashlib.sha256(path.read_bytes()).hexdigest(),
                  'mode': path.stat().st_mode & 0o777})
assert before == after
write('source-inputs.after.json', after)
assert subprocess.check_output(['git', 'status', '--porcelain'], cwd=ROOT) == b''
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip() == '18265e3932f9609b4cef4e156e21d310f2d3c63d'

own_pids = {}
for file in OUT.glob('*-own-processes.json'):
    for pid, info in json.loads(file.read_text()).items():
        own_pids[pid] = info
remaining = []
for pid, info in own_pids.items():
    path = Path('/proc') / pid / 'stat'
    if path.exists():
        fields = path.read_text().split(') ', 1)[1].split()
        if int(fields[19]) == info['start']:
            remaining.append({'pid': pid, 'state': fields[0]})
assert not remaining, remaining
metrics = []
for file in OUT.glob('*-metrics.ndjson'):
    metrics.extend(json.loads(row) for row in file.read_text().splitlines())
prelease = read('prelease.json')
assert all(row['free_bytes'] >= 4294967296 for row in metrics)
assert all(row['memory_max'] - row['memory_current'] >= 1073741824 for row in metrics)
assert max(row['allocation_bytes'] for row in metrics) - prelease['allocation_bytes'] <= 805306368
native_tasks = {}
for attempt in ['baseline-jdk', 'baseline-graphfix', 'candidate-jdk']:
    lines = (OUT / (attempt + '.raw.private.log')).read_text(errors='replace').splitlines()
    tasks = [line for line in lines if line.startswith('> Task ')]
    assert not any(line.split()[2].endswith(':test') or line.split()[2].endswith(':integrationTest') for line in tasks)
    native_tasks[attempt] = tasks
write('native-tasks.safe.json', native_tasks)
write('graph-comparison.final.json', comparison)
write('security-topology-identical.json', security)
write('terminal-proof.json', {
    'utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'status': 'GRAPH_COMPILE1_COMPLETE_LEASE_RELEASED',
    'source_sha': '18265e3932f9609b4cef4e156e21d310f2d3c63d',
    'root_equivalent_source_producer': '908fc8c27be82e4a0d7db7bf4d7b2c4a62225916',
    'tracked_source_count': len(before), 'source_sha_modes': 'ALL_EXACT', 'clean_worktree': True,
    'baseline_graph_native_exit': read('baseline-graphfix-outcome.json')['native_exit'],
    'candidate_native_exit': read('candidate-jdk-outcome.json')['native_exit'],
    'graph_delta': 'EXACT_AUTH_MAIN_PLAIN_ARTIFACT_ONLY',
    'existing_external_security_and_both_main_graphs': 'EXACT',
    'actual_compile': 'AUTH_MAIN_PLAIN_JAR_ACADEMIC_MAIN_CURRENT_TESTS_PASS',
    'duplicate_canonical_class_bytes': '360_EXACT', 'resource_priority': 'ACADEMIC_MAIN_4_FIRST',
    'unit_integration_resolved_classpaths': 'SAME_ORDER',
    'integration_heap_configuration': '1g', 'unit_heap_configuration': 'null_unchanged_default512m',
    'fork_configuration': 1, 'actual_test_JVM_flags': 'NOT_RUN_NO_TESTS_IN_LEASE',
    'actual_gradle_jvm': candidate['gradleJvm'],
    'min_free_bytes': min(row['free_bytes'] for row in metrics),
    'peak_shared_memory_bytes': max(row['memory_current'] for row in metrics),
    'peak_new_allocation_bytes': max(row['allocation_bytes'] for row in metrics) - prelease['allocation_bytes'],
    'owned_recorded_pids': sorted(int(pid) for pid in own_pids), 'owned_pids_remaining': remaining,
    'tests_executed': 0, 'new_broker_sources': 'NOT_IMPORTED_NOT_COMPILED',
    'full_academic_runtime': 'NOT_RUN_SEPARATE_FUTURE_LEASE',
    'raw_logs': 'PRIVATE600_NOT_IN_PUBLISHABLE_MANIFEST',
    'prior_infra_failures': 'Retained wrapper mode/localhostIPC/JRE capability failures plus corrected own observer NO-SOURCE handling'
})
write('CURRENT.json', read('terminal-proof.json'))
print(json.dumps(read('terminal-proof.json'), indent=2))
