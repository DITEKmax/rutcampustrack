"""Selected actual old/new checkout dispatch in RAM; no chmod/files/processes."""
import ast
import io
import json
from pathlib import Path
import types
from unittest.mock import patch

OWN = Path(__file__).parent
OLD = Path('/workspace/scratch/rct-validation/current_journal_twojar_refresh_prepare')
tree = ast.parse((OWN/'build-academic.py').read_text())
helper = next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='checkout_with_creation_modes')
checks = []
state = {'mask':0o077,'mask_calls':[],'dispatch':[],'failure':None}
def umask(value):
    before=state['mask'];state['mask']=value;state['mask_calls'].append(value);return before
def run(phase,argv,cwd):
    state['dispatch'].append({'phase':phase,'argv':argv,'cwd':str(cwd),'plain_creation_mode':0o666&~state['mask'],
                              'executable_creation_mode':0o777&~state['mask']})
    if state['failure'] is not None:raise state['failure']
revision='597716c3cae9f7d7f601cb5b5279baf598d841ef'
checkout=Path('/tmp/public-new-checkout')
oldtree=ast.parse((OLD/'build-academic.py').read_text());main=next(n for n in oldtree.body if isinstance(n,ast.FunctionDef) and n.name=='main')
body=next(n for n in main.body if isinstance(n,ast.Try)).body
oldcall=next(n for n in body if isinstance(n,ast.Expr) and isinstance(n.value,ast.Call)
             and isinstance(n.value.func,ast.Name) and n.value.func.id=='run'
             and isinstance(n.value.args[0],ast.Constant) and n.value.args[0].value=='checkout')
exec(compile(ast.Module(body=[oldcall],type_ignores=[]),'<actual old selected checkout>','exec'),
     {'run':run,'checkout':checkout,'g':{'frozen_source_revision':revision}})
assert state['dispatch'][0]['plain_creation_mode']==0o600 and not state['mask_calls']
checks.append({'name':'actual old unmasked dispatch reproduces600creation under077 RAM context','pass':True})
scope={'os':types.SimpleNamespace(umask=umask)}
exec(compile(ast.Module(body=[helper],type_ignores=[]),'<actual new selected helper>','exec'),scope)
expected=['/usr/bin/git','-C',str(checkout),'checkout','--detach',revision]
for mask in [0o077,0o027,0o002]:
    state.update(mask=mask,mask_calls=[],dispatch=[],failure=None)
    scope['checkout_with_creation_modes'](run,checkout,revision)
    row=state['dispatch'][0]
    assert row['argv']==expected and row['cwd']==str(checkout) and row['phase']=='checkout'
    assert row['plain_creation_mode']==0o644 and row['executable_creation_mode']==0o755
    assert state['mask']==mask and state['mask_calls']==[0o022,mask]
    checks.append({'name':'actual new exact644755creation andprior-maskrestore '+oct(mask),'pass':True})
for failure in [RuntimeError('public resource denial'),KeyboardInterrupt()]:
    state.update(mask=0o077,mask_calls=[],dispatch=[],failure=failure)
    try:scope['checkout_with_creation_modes'](run,checkout,revision)
    except BaseException as caught:assert caught is failure
    else:raise AssertionError('Failure not preserved')
    assert state['mask']==0o077 and state['mask_calls']==[0o022,0o077]
    checks.append({'name':'resource/signal failure preservesprimary andrestoresmask '+type(failure).__name__,'pass':True})
# Exact whole caller inverse after restoring declaration parameters.
old=(OLD/'build-academic.py').read_text();new=(OWN/'build-academic.py').read_text()
start=new.index('\ndef checkout_with_creation_modes(');end=new.index('\ndef main():',start)
normalized=new[:start]+new[end:]
normalized=normalized.replace("        checkout_with_creation_modes(run, checkout, g['frozen_source_revision'])",
"        run('checkout', ['/usr/bin/git', '-C', str(checkout), 'checkout', '--detach',\n                         g['frozen_source_revision']], checkout)")
import re
erase=lambda s:re.sub(r"!= '[0-9a-f]{64}':", "!= 'DECLARED_BOUNDARY_PIN':",s)
assert erase(normalized)==erase(old)
checks.append({'name':'whole BUILD caller inverse exact exceptdeclaredboundary pin andonecheckout helper/call','pass':True})
for name in ['inspect-academic.py','tool-inputs.safe.json','tmp-anchors.safe.json','tracked-inputs597.safe.json','required-journal-inputs.safe.json']:
    assert (OWN/name).read_bytes()==(OLD/name).read_bytes()
checks.append({'name':'inspector/tools/anchors/787inputs/required6pins byteexact inherited','pass':True})
oldb=(OLD/'refresh-boundary.py').read_text();newb=(OWN/'refresh-boundary.py').read_text()
assert newb.replace('rct-journal-twojar-refresh-20261013-attempt02','rct-journal-twojar-refresh-20261013-attempt01')==oldb
checks.append({'name':'whole boundary exactinverse newprefixparameter only no predicate/capschange','pass':True})
for name in ['build-academic.py','refresh-boundary.py','mode-correction-controls.py']:
    ast.parse((OWN/name).read_text())
print(json.dumps({'targeted_source_RAM_groups':len(checks),'all_pass':True,'checks':checks,
                  'actualumaskoffailedoldprocess':'NOT_CAPTURED; provenactual787modes600 separate receipt',
                  'nativecheckout/chmod/oldfiles/build':'NOT_RUN','mode_model':'POSIXnewfilecreation only, not actualGitprobe'},indent=2))
