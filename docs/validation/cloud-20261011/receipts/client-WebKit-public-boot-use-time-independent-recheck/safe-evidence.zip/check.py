"""Independent selected-source lease recheck, mocked effects only."""
import ast
import datetime as real_datetime
import hashlib
import json
from pathlib import Path
import stat
import types
import zipfile

OWN=Path(__file__).parent
BASE=OWN.parent/'client_real_acceptance'
NEW=BASE/'webkit-public-boot-r1'
OLD=BASE/'webkit-public-boot'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(NEW/'READY.safe.json')=='8aae65d1ceb1fd0c6fa6cc8d43932aea6dec021f493abcfbc76722538bd5dc6f'
assert sha(NEW/'run-probe.py')=='af6a0f3b219563322e0ffc953ed1e7b35a9af1beb0887636075765a8a5402a8e'
assert sha(NEW/'source.safe.zip')=='f33a52b5c085767025972aa2173785a5eefe3ede80231933399a6dbf2fbaafcd'
expected={}
manifest=json.loads((NEW/'manifest.safe.json').read_text())
for r in manifest['files']:
    p=NEW/r['path'];s=p.lstat()
    assert p.parent==NEW and stat.S_ISREG(s.st_mode) and s.st_nlink==r['nlink']==1
    assert s.st_size==r['bytes'] and stat.S_IMODE(s.st_mode)==int(r['mode'],0) and sha(p)==r['sha256']
    expected[r['path']]=r['sha256']
expected['manifest.safe.json']=sha(NEW/'manifest.safe.json')
with zipfile.ZipFile(NEW/'source.safe.zip') as z:
    assert len(z.infolist())==len(expected) and set(z.namelist())==set(expected) and z.testzip() is None
    for name in z.namelist():assert hashlib.sha256(z.read(name)).hexdigest()==expected[name]
for name in ['probe.cjs','launch-cause.cjs']:
    assert (NEW/name).read_bytes()==(OLD/name).read_bytes()
assert sha(OWN.parent/'webkit_public_boot_review/manifest.json')=='28b74a1f31e086745c578c6061e8032d5d7ec55ae41f5c55e8a4facb30c48538'
assert sha(OLD/'manifest.safe.json')=='ffb76a7b81f46d31c9ff33654a06830af05c7bff4d6b0cd2e768c06ece098498'
assert sha(OLD/'source.safe.zip')=='bead1b2be6fc92242ec78aae79965f77418f35b71e59d5e9e38b7f846c4ebe0d'
ready=json.loads((NEW/'READY.safe.json').read_text())
for path,digest in ready['pinned_source_hashes'].items():
    assert 'private' not in Path(path).parts and sha(Path(path))==digest
newtree=ast.parse((NEW/'run-probe.py').read_text());oldtree=ast.parse((OLD/'run-probe.py').read_text())
def fn(tree,name):return next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name==name)
def execute(nodes,scope):exec(compile(ast.Module(body=nodes,type_ignores=[]),'selected_review_boundary','exec'),scope)
checks=[]
def exercise(tree,kind,at=9,delay=False,low_disk=False,wrapper_stop=20):
    epoch=real_datetime.datetime(2026,1,1,tzinfo=real_datetime.timezone.utc);clock=[9];events={'mkdir':0,'dispatch':0}
    class Date(real_datetime.datetime):
        @classmethod
        def now(cls,zone):return epoch+real_datetime.timedelta(seconds=clock[0])
    class FakePath:
        def __init__(self,path):self.path=path
        def __truediv__(self,name):return FakePath(self.path+'/'+name)
        def exists(self):return False
        def mkdir(self,**kwargs):events['mkdir']+=1
        def rglob(self,pattern):return []
        def read_text(self):return {'/sys/fs/cgroup/memory.current':'1','/sys/fs/cgroup/memory.max':'17179869184','/proc/self/status':'VmRSS: 1 kB\n'}[self.path]
    def resources(filesystem):
        if delay:clock[0]=11
        return types.SimpleNamespace(f_bavail=1 if low_disk else 17179869184,f_frsize=1)
    def dispatch(*args,**kwargs):events['dispatch']+=1
    grant=dict(issued_at=epoch.isoformat(),absolute_stop_at=(epoch+real_datetime.timedelta(seconds=10)).isoformat(),expires_at=(epoch+real_datetime.timedelta(seconds=20)).isoformat(),disk_floor_bytes=4294967296,shared_stop_bytes=16106127360,shared_memory_reserve_bytes=1073741824,owned_total_rss_stop_bytes=1610612736,cache_stop_bytes=33554432)
    scope=dict(Path=FakePath,datetime=types.SimpleNamespace(datetime=Date),UTC=real_datetime.timezone.utc,grant=grant,BASE=FakePath('/mock/own'),attempt='attempt-01',private_directory=lambda p:None,
               os=types.SimpleNamespace(statvfs=resources),guard=types.SimpleNamespace(process_table=lambda:{},run_owned=dispatch),argv=[],ROOT=FakePath('/mock/root'),env={},seconds=1,status=None,observe=None,
               latest={},peaks={'owned_rss_bytes':0,'run_allocated_bytes':0,'shared_memory_bytes':0},run=FakePath('/mock/run'))
    execute([fn(tree,'require'),fn(tree,'instant')],scope)
    if any(isinstance(n,ast.FunctionDef) and n.name=='fresh_preflight' for n in tree.body):execute([fn(tree,'fresh_preflight')],scope)
    body=fn(tree,'main').body
    initial=next(i for i,n in enumerate(body) if isinstance(n,ast.Expr) and isinstance(n.value,ast.Call) and any(isinstance(a,ast.Constant) and a.value=='GRANT_EXPIRED' for a in n.value.args))
    execute(body[initial-2:initial+1],scope);clock[0]=at
    if kind=='mkdir':
        start=next(i for i,n in enumerate(body) if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='runs' for t in n.targets))
        end=next(i for i,n in enumerate(body) if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='supervision' for t in n.targets))
        nodes=body[start:end]
    elif kind=='binding':
        scope['browser_grant']=dict(not_before_utc=epoch.isoformat(),stop_utc=(epoch+real_datetime.timedelta(seconds=wrapper_stop)).isoformat())
        nodes=[n for n in body if isinstance(n,ast.Expr) and isinstance(n.value,ast.Call) and any(isinstance(a,ast.Constant) and a.value=='WRAPPER_GRANT_EXPIRED' for a in n.value.args)]
    elif kind=='dispatch':
        pos=next(i for i,n in enumerate(body) if isinstance(n,ast.Assign) and isinstance(n.value,ast.Call) and isinstance(n.value.func,ast.Attribute) and n.value.func.attr=='run_owned')
        nodes=body[pos-1:pos+1]
    else:
        observe=next(n for n in body if isinstance(n,ast.FunctionDef) and n.name=='observe')
        execute([observe],scope)
        result=scope['observe']();return dict(denied=result is not None,reason=result,clock=clock[0],**events)
    try:execute(nodes,scope);reason=None
    except RuntimeError as e:reason=e.args[0]
    return dict(denied=reason is not None,reason=reason,clock=clock[0],**events)
cases=[('oldExpiredSix',oldtree,'mkdir',dict(at=11),dict(denied=False,mkdir=6)),
       ('newExpiredZero',newtree,'mkdir',dict(at=11),dict(reason='GRANT_EXPIRED_AT_USE',mkdir=0)),
       ('newFreshSix',newtree,'mkdir',{},dict(denied=False,mkdir=6)),
       ('newDelayedResourcesZero',newtree,'mkdir',dict(delay=True),dict(reason='GRANT_EXPIRED_AT_USE',mkdir=0)),
       ('newLowDiskZero',newtree,'mkdir',dict(low_disk=True),dict(reason='DISK_FLOOR_AT_USE',mkdir=0)),
       ('oldLaterWrapperAccepted',oldtree,'binding',{},dict(denied=False)),
       ('newLaterWrapperDenied',newtree,'binding',{},dict(reason='WRAPPER_GRANT_EXPIRED')),
       ('newEqualWrapperAccepted',newtree,'binding',dict(wrapper_stop=10),dict(denied=False)),
       ('newExpiredDispatchZero',newtree,'dispatch',dict(at=11),dict(reason='GRANT_EXPIRED_AT_USE',dispatch=0)),
       ('newDelayedDispatchZero',newtree,'dispatch',dict(delay=True),dict(reason='GRANT_EXPIRED_AT_USE',dispatch=0)),
       ('newFreshDispatchOne',newtree,'dispatch',{},dict(denied=False,dispatch=1)),
       ('oldDelayedObserverLateAllows',oldtree,'observer',dict(delay=True),dict(denied=False,clock=11)),
       ('newDelayedObserverDenies',newtree,'observer',dict(delay=True),dict(reason='ABSOLUTE_DEADLINE',clock=11)),
       ('newFreshObserverAllows',newtree,'observer',{},dict(denied=False,clock=9))]
for label,tree,kind,args,want in cases:
    value=exercise(tree,kind,**args)
    assert all(value[k]==v for k,v in want.items()),(label,value)
    checks.append(dict(case=label,pass_result=True,actual=value))
record=dict(outcome='APPROVE_SOURCE',closed_finding='WEBKIT-PUBLIC-GRANT-USE-TIME',blocking_findings=0,source_manifest=sha(NEW/'manifest.safe.json'),source_ready=sha(NEW/'READY.safe.json'),source_zip=sha(NEW/'source.safe.zip'),source_driver=sha(NEW/'run-probe.py'),source_members=len(manifest['files']),zip_members=len(expected),helper_classifier_identical=True,controls=checks,qualification='Selected unchanged AST + mocked resources/clocks/mutations; no target imports/native/Node/browser',browser_native='NOT_RUN')
(OWN/'checks.safe.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(dict(outcome=record['outcome'],manifest=record['source_manifest'],controls=len(checks),native_calls=0)))
