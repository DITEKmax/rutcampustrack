from pathlib import Path
import ast,json
B=Path('/workspace/scratch/rct-validation/current_host_config_v5/run-mongo.py')
t=ast.parse(B.read_text());main=next(n for n in t.body if isinstance(n,ast.FunctionDef) and n.name=='main');phase=next(n for n in main.body if isinstance(n,ast.If) and ast.unparse(n.test)=="phase == 'server'");owned=next(n for n in phase.orelse if isinstance(n,ast.Assign) and any(isinstance(a,ast.Name) and a.id=='owned' for a in n.targets))
e=compile(ast.Expression(owned.value),'<exact-sealed-identity-expression>','eval')
record={'child_pid':101,'members_including_Z':[{'pid':101,'start_ticks':1001},{'pid':102,'start_ticks':1002}]}
rows=[]
for name,table,expect in [('exact_child_live',{101:{'start_ticks':1001,'state':'S'}},True),('child_absent_descendant_live',{102:{'start_ticks':1002,'state':'S'}},False),('child_reused_descendant_live',{101:{'start_ticks':9001,'state':'S'},102:{'start_ticks':1002,'state':'S'}},False),('child_zombie_descendant_live',{101:{'start_ticks':1001,'state':'Z'},102:{'start_ticks':1002,'state':'S'}},False),('all_absent',{},False)]:
 actual=bool(eval(e,{'record':record,'table':table}));rows.append({'name':name,'current_gate_accepts':actual,'exact_child_should_accept':expect,'matches_exact_server_requirement':actual==expect})
Path('/workspace/scratch/rct-validation/hostcfg_v5_independent_recheck/identity-counterexample.safe.json').write_text(json.dumps({'status':'SOURCE_GATE_COUNTEREXAMPLE','rows':rows,'synthetic_metadata_only':True,'real_process_or_port':False},indent=2)+'\n')
print(json.dumps({'controls':len(rows),'exact_child_gate_counterexamples':sum(not r['matches_exact_server_requirement'] for r in rows),'real_process_or_port':False}))
