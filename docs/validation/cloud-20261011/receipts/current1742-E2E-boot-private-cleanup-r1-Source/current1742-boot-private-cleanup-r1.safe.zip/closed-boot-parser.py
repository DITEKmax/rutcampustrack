"""Exact existing job diagnostic. Bytes remain private; only finite hints escape."""
import datetime as dt
import os
import re
import stat
import sys

HEAD = '1742d1e806faa5c39c6d182a3554daa8f4239801'
RUN = 38387263916
JOB = 115262001797
STEP = 'Boot isolated Vue auth stack'
MAX_BYTES = 32 * 1024 * 1024  # Existing SAFE reader envelope, not increased.
SERVICES = frozenset(('postgres-academic', 'postgres-schedule', 'mongo-attendance',
    'redis', 'rabbitmq', 'auth-service', 'academic-service', 'schedule-service',
    'attendance-service', 'document-renderer-service', 'mobile-bff', 'api-gateway',
    'notification-web', 'pwa-nginx', 'mini-app-nginx', 'nginx'))
STATES = frozenset(('Created', 'Starting', 'Started', 'Waiting', 'Healthy',
    'Unhealthy', 'Exited', 'Error'))
CODES = frozenset((1, 2, 125, 126, 127, 137, 143))

class Blocked(Exception):
    """Never include input-derived text in an error."""

def require(ok):
    if not ok:
        raise Blocked()

def instant(value):
    require(type(value) is str and re.fullmatch(
        r'\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d{1,7})?Z', value) is not None)
    try:
        return dt.datetime.fromisoformat(value.replace('Z', '+00:00'))
    except ValueError:
        raise Blocked() from None

def validate_binding(b):
    require(type(b) is dict and set(b) == {'repo', 'head', 'run_id', 'run_attempt',
        'job_id', 'job_name', 'step_number', 'step_name', 'step_conclusion',
        'step_started_at', 'step_completed_at', 'metadata_verified'})
    require(b['repo'] == 'DITEKmax/rutcampustrack' and b['head'] == HEAD
        and type(b['run_id']) is int and b['run_id'] == RUN
        and type(b['run_attempt']) is int and b['run_attempt'] == 1
        and type(b['job_id']) is int and b['job_id'] == JOB
        and b['job_name'] == 'Playwright E2E auth flow'
        and type(b['step_number']) is int and b['step_number'] == 9
        and b['step_name'] == STEP and b['step_conclusion'] == 'failure'
        and b['metadata_verified'] is True)
    start, stop = instant(b['step_started_at']), instant(b['step_completed_at'])
    require(start < stop and (stop - start).total_seconds() <= 1800)
    return start, stop

def parse(data, binding):
    start, stop = validate_binding(binding)
    require(type(data) is bytes and 0 < len(data) <= MAX_BYTES)
    try:
        text = data.decode('utf-8', errors='strict')
    except UnicodeError:
        raise Blocked() from None
    require('\x00' not in text and '\x1b' not in text)
    hints = set()
    unknown = False
    selected = 0
    # Do not persist input, individual lines, hashes, raw exceptions or excerpts.
    for line in text.splitlines():
        require(len(line) <= 65536)
        stamp, separator, message = line.partition(' ')
        require(bool(separator))
        when = instant(stamp)
        if not start <= when <= stop:
            continue
        selected += 1
        require(not any(ord(c) < 32 and c != '\t' for c in message))
        m = re.fullmatch(r'\s*Container rct-e2e-([a-z][a-z0-9-]*)-1\s+([A-Za-z]+)\s*', message)
        if m:
            service, state = m.groups()
            require(service in SERVICES and state in STATES)
            hints.add(('CONTAINER', service, state, None))
            continue
        m = re.fullmatch(r'dependency failed to start: container rct-e2e-([a-z][a-z0-9-]*)-1 is unhealthy', message)
        if m:
            require(m[1] in SERVICES)
            hints.add(('WAIT', m[1], 'Unhealthy', None))
            continue
        m = re.fullmatch(r'##\[error\]Process completed with exit code (\d+)\.', message)
        if m:
            code = int(m[1])
            require(code in CODES)
            hints.add(('STEP_EXIT', None, None, code))
            continue
        # BuildKit command/message content is discarded entirely. A fixed prefix
        # is only an untrusted build-stage hint, never proof of the causal command.
        if message.startswith('failed to solve: '):
            hints.add(('BUILD', None, 'REPORTED_FAILURE', None))
            continue
        unknown = True
    require(selected > 0)
    return {'schema': 1, 'state': 'CLOSED_REPORTED_HINTS' if hints else 'UNKNOWN',
        'hints': [{'phase': p, 'service': s, 'state': st, 'code': c}
            for p, s, st, c in sorted(hints, key=repr)],
        'unrecognized_selected_lines': unknown,
        'cause': 'UNKNOWN', 'actual_checkout': 'UNKNOWN',
        'original_smoke_and_FIRST3': 'NOT_RUN', 'raw_content_emitted': False,
        'qualification': 'Log-reported hints only; metadata binds job/step, not application cause. Second-resolution step timestamps may include adjacent boundary lines.'}

def consume_private(directory_fd, binding):
    """Caller first settles b78, then opens exact pinned own directory FD.

    No second read, retained hash or raw archive. Cleanup happens even if UTF8
    or closed-schema parsing fails. Caller must not retry the same job log.
    """
    fd = os.open('job.log.private', os.O_RDONLY | os.O_NOFOLLOW, dir_fd=directory_fd)
    owned = False
    try:
        st = os.fstat(fd)
        require(stat.S_ISREG(st.st_mode) and st.st_uid == 1000
            and stat.S_IMODE(st.st_mode) == 0o600 and st.st_nlink == 1
            and 0 < st.st_size <= MAX_BYTES)
        owned = True
        data = os.read(fd, MAX_BYTES + 1)
        require(len(data) == st.st_size)
        after = os.fstat(fd)
        require((st.st_dev, st.st_ino, st.st_size, st.st_mtime_ns, st.st_ctime_ns)
            == (after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns, after.st_ctime_ns))
        return parse(data, binding)
    finally:
        primary_error = sys.exc_info()[1]
        os.close(fd)
        # Never follow, remove or inspect a replacement/foreign file.
        if owned:
            try:
                current = os.stat('job.log.private', dir_fd=directory_fd, follow_symlinks=False)
                require((current.st_dev, current.st_ino) == (st.st_dev, st.st_ino)
                    and stat.S_ISREG(current.st_mode) and current.st_uid == 1000
                    and stat.S_IMODE(current.st_mode) == 0o600 and current.st_nlink == 1)
            except BaseException:
                # Denied or ambiguous leaf stays untouched for explicit later
                # reconciliation. Preserve an existing read/parse error.
                if primary_error is None:
                    raise
                primary_error.add_note('PRIVATE_CAPTURE_RETAINED_RECONCILIATION_REQUIRED')
            else:
                os.unlink('job.log.private', dir_fd=directory_fd)
