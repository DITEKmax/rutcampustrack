"""Read only the exact new Academic+Attendance standard BootJARs."""
import hashlib
from pathlib import Path, PurePosixPath
import re
import stat
import types
import zipfile


def headers(raw):
    unfolded = []
    for line in raw.decode('utf8').replace('\r\n', '\n').splitlines():
        if line.startswith(' '):
            if not unfolded:
                raise RuntimeError('Manifest continuation denied')
            unfolded[-1] += line[1:]
        else:
            unfolded.append(line)
    return dict(line.split(': ', 1) for line in unfolded if ': ' in line)


def member(name, directory=False):
    raw = name[:-1] if directory and name.endswith('/') else name
    p = PurePosixPath(raw)
    if not raw or p.is_absolute() or str(p) != raw or '..' in p.parts or '\\' in raw or ':' in raw or '\0' in raw:
        raise RuntimeError('Canonical contained ZIP member required')
    return p


SERVICES = {'academic': 'ru.rutcampustrack.academic.AcademicApplication',
            'attendance': 'ru.rutcampustrack.attendance.AttendanceApplication'}


def library_order(lines, entries, version):
    libraries = []
    for line in lines:
        match = re.fullmatch(r'- "(BOOT-INF/lib/[A-Za-z0-9_.+-]+\.jar)"', line)
        if match is None:
            raise RuntimeError('Canonical production classpath required')
        libraries.append(match.group(1))
    all_libraries = {row['path'] for row in entries
                     if row['path'].startswith('BOOT-INF/lib/') and row['path'].endswith('.jar')}
    tools = 'BOOT-INF/lib/spring-boot-jarmode-tools-' + version + '.jar'
    if (not libraries or len(set(libraries)) != len(libraries)
            or set(libraries) - all_libraries or all_libraries - set(libraries) != {tools}
            or tools in libraries):
        raise RuntimeError('Exact indexed library set plus sole canonical tools required')
    return libraries, tools


def inspect(checkout, revision, service):
    if service not in SERVICES or revision != '597716c3cae9f7d7f601cb5b5279baf598d841ef':
        raise RuntimeError('Exact reviewed two-service producer required')
    path = checkout / ('services/' + service + '-service/' + service + '-app/build/libs/' + service + '-app-0.1.0.jar')
    for parent in reversed(path.parents):
        if not stat.S_ISDIR(parent.lstat().st_mode):
            raise RuntimeError('Production JAR symlink ancestor denied')
    s = path.lstat()
    if not stat.S_ISREG(s.st_mode) or s.st_uid != 1000 or s.st_nlink != 1 or not 0 < s.st_size <= 268435456:
        raise RuntimeError('Bounded own fresh production JAR required')
    fixture = checkout / 'tests/e2e/backend-clock/verify-jar-isolation.py'
    isolation = types.ModuleType('isolation')
    exec(compile(fixture.read_bytes(), str(fixture), 'exec'), isolation.__dict__)
    files = []
    with zipfile.ZipFile(path) as archive:
        entries = archive.infolist()
        if len(entries) > 6000 or len({m.filename for m in entries}) != len(entries):
            raise RuntimeError('Bounded unique ZIP members required')
        if sum(m.file_size for m in entries) > 268435456 or archive.testzip() is not None:
            raise RuntimeError('Payload bound/ZIP CRC failed')
        for m in entries:
            member(m.filename, m.is_dir())
            kind = stat.S_IFMT(m.external_attr >> 16)
            if m.flag_bits & 1 or kind not in [0, stat.S_IFREG, stat.S_IFDIR]:
                raise RuntimeError('ZIP links/special/encrypted members denied')
            if not m.is_dir():
                with archive.open(m) as stream:
                    digest = hashlib.file_digest(stream, 'sha256').hexdigest()
                files.append({'path': m.filename, 'bytes': m.file_size, 'sha256': digest})
        isolation.require_fixture_absent(archive)
        manifest = headers(archive.read('META-INF/MANIFEST.MF'))
        expected = {'Main-Class': 'org.springframework.boot.loader.launch.JarLauncher',
                    'Start-Class': SERVICES[service], 'Spring-Boot-Version': '3.5.16', 'Build-Jdk-Spec': '21',
                    'Spring-Boot-Classes': 'BOOT-INF/classes/', 'Spring-Boot-Lib': 'BOOT-INF/lib/',
                    'Spring-Boot-Classpath-Index': 'BOOT-INF/classpath.idx',
                    'Spring-Boot-Layers-Index': 'BOOT-INF/layers.idx'}
        if any(manifest.get(k) != v for k, v in expected.items()):
            raise RuntimeError('Canonical current standard Boot layout required')
        if 'BOOT-INF/classes/' + SERVICES[service].replace('.', '/') + '.class' not in archive.namelist():
            raise RuntimeError('Genuine application entrypoint required')
        required_request = 'BOOT-INF/classes/ru/rutcampustrack/academic/grpc/HeadmanJournalSemesterStateRequest.class'
        required_grpc = 'BOOT-INF/classes/ru/rutcampustrack/academic/grpc/AcademicGrpcServiceGrpc.class'
        actual_boundary = ('BOOT-INF/classes/ru/rutcampustrack/academic/grpc/AcademicGrpcServiceImpl.class'
                           if service == 'academic' else
                           'BOOT-INF/classes/ru/rutcampustrack/attendance/grpc/AcademicGrpcClient.class')
        if (required_request not in archive.namelist() or required_grpc not in archive.namelist()
                or actual_boundary not in archive.namelist()
                or b'getHeadmanJournalSemesterState' not in archive.read(actual_boundary)):
            raise RuntimeError('Current additive RPC generated request and application boundary required')
        props = dict(line.split('=', 1) for line in archive.read('BOOT-INF/classes/git.properties').decode().splitlines()
                     if '=' in line and not line.startswith('#'))
        if props.get('git.commit.id') != revision:
            raise RuntimeError('Fresh embedded frozen producer revision required')
        libraries, tools = library_order(archive.read('BOOT-INF/classpath.idx').decode().splitlines(), files,
                                        manifest['Spring-Boot-Version'])
    with path.open('rb') as stream:
        digest = hashlib.file_digest(stream, 'sha256').hexdigest()
    return {'service': service, 'producer_revision': revision, 'jar': str(path), 'jar_sha256': digest,
            'jar_bytes': s.st_size, 'jar_allocated': s.st_blocks * 512,
            'unfolded_manifest': manifest, 'regular_entries': files,
            'recursive_fixture_absent': True, 'CRC': 'PASS',
            'library_order': libraries, 'application_index_library_count': len(libraries),
            'nested_library_count': len(libraries) + 1, 'unindexed_tools': tools,
            'signed_journal_RPC_classes_present': True, 'live_RPC_acceptance': 'SEPARATE_NOT_RUN',
            'classpath_idx_sha256': next(r['sha256'] for r in files if r['path'] == 'BOOT-INF/classpath.idx'),
            'layers_idx_sha256': next(r['sha256'] for r in files if r['path'] == 'BOOT-INF/layers.idx')}
