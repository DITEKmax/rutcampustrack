"""Independent selected actual-AST RAM counterexamples; no native or key filesystem."""
import ast
import json
from pathlib import Path
from types import SimpleNamespace

source = Path("/workspace/scratch/rct-validation/notification_key_isolation/prove-key-volume.py")
tree = ast.parse(source.read_text())
main = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == "main")
flow = next(n for n in main.body if isinstance(n, ast.Try))
cases = []
# Exact volume admission assignment/if/assignment, with historical public metadata.
nodes = [n for n in flow.body if n.lineno in (119, 120, 122)]
assert len(nodes) == 3
volume = "p07-key-isolation-20261013-01"
for label, candidate in (
    ("historical_matching_label_is_admitted", volume + " 2020-01-01T00:00:00Z 20261013-01"),
    ("invalid_createdAt_is_admitted", volume + " INVALID 20261013-01"),
):
    ns = {"VOLUME": volume, "DOCKER": [], "run": lambda argv, v=candidate: v}
    exec(compile(ast.Module(body=nodes, type_ignores=[]), str(source), "exec"), ns)
    assert ns["volume_identity"] == candidate
    cases.append({"case": label, "result": "COUNTEREXAMPLE_CONFIRMED", "native": False})

# Exact key generation sequence + original except/finally in a RAM-only namespace.
# First native operation creates its output; second native operation fails.
created = {"private.key": False, "public.key": False}
output = []
primary = OSError("synthetic selected operation failure")
class RamPath:
    def __init__(self, name): self.name = str(name).rsplit("/", 1)[-1]
    def __truediv__(self, name): return RamPath(name)
    def exists(self): return created[self.name]
    def stat(self, **kwargs): return SimpleNamespace(st_dev=1, st_ino=2, st_uid=3, st_nlink=1)
    def unlink(self): created[self.name] = False
    def rmdir(self): raise AssertionError("unexpected directory removal")
def native(argv, **kwargs):
    if argv[1] == "genpkey":
        created["private.key"] = True
        return ""
    raise primary
selected = ast.Try(
    body=[n for n in flow.body if n.lineno in (108, 109, 110)],
    handlers=flow.handlers, orelse=[], finalbody=flow.finalbody,
)
ast.fix_missing_locations(selected)
ns = {
    "private": RamPath("private.key"), "public": RamPath("public.key"),
    "run": native, "key_identities": {}, "created_containers": {},
    "created_volume": False, "synthetic": "RAM_ONLY_DIRECTORY", "synthetic_identity": (1,2,3),
    "Path": RamPath, "os": SimpleNamespace(stat=lambda *a, **kw: SimpleNamespace(st_dev=1,st_ino=2,st_uid=3)),
    "resource_gate": lambda *a, **kw: 30, "initial_free": {}, "deadline": 280,
    "result": {"state": "IN_PROGRESS"}, "start": 0,
    "time": SimpleNamespace(monotonic=lambda: 0),
    "OUTPUT": SimpleNamespace(write_text=lambda value: output.append(json.loads(value))),
    "json": json,
}
try:
    exec(compile(ast.Module(body=[selected], type_ignores=[]), str(source), "exec"), ns)
except RuntimeError as final:
    assert final.__context__ is primary
    assert created["private.key"] and ns["key_identities"] == {}
    assert output[-1]["state"] == "FAIL" and output[-1]["error_type"] == "OSError"
    assert output[-1]["cleanup_errors"] == 1
    cases.append({"case": "partial_key_generation_leaves_untracked_owned_private_file",
                  "result": "COUNTEREXAMPLE_CONFIRMED", "native": False,
                  "primary_type_retained_in_safe_receipt": True,
                  "primary_retained_as_exception_context": True,
                  "final_exception_is_primary": False})
else:
    raise AssertionError("partial generation unexpectedly cleaned")
Path(__file__).with_name("counterexamples.safe.json").write_text(json.dumps({
    "scope": "SELECTED_ACTUAL_AST_RAM_ONLY", "source_sha256": "5130de07f6d02be0ea427a1b98d91d76aacb8d0327578a350849dde7068615fb",
    "cases": cases, "no_docker_files_keys_native": True}, indent=2) + "\n")
print(json.dumps({"selected_actual_ast_counterexamples": len(cases), "native": "NOT_RUN"}))
