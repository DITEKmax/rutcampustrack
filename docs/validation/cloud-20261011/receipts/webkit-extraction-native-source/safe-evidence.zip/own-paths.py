"""Pinned ordinary scratch output descriptors, no child or runtime authority."""
import json
import os
from pathlib import Path
import re
import stat
OWN = Path(__file__).parent

def identity(s):
    if not stat.S_ISDIR(s.st_mode):
        raise RuntimeError('No-symlink directory required')
    return {'device': s.st_dev, 'inode': s.st_ino, 'uid': s.st_uid,
            'gid': s.st_gid, 'mode': stat.S_IMODE(s.st_mode)}

class Output:
    def __init__(self, path, create=False):
        if (os.getuid()!=1000 or os.getgid()!=1000 or path.parent!=OWN/'runtime'
                or not re.fullmatch(r'native-[a-z0-9-]{1,32}', path.name)):
            raise RuntimeError('Exact own native output namespace required')
        self.path=path; self.fds=[]; self.identities=[]
        flags=os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW|os.O_CLOEXEC
        rows=json.loads((OWN/'runtime-anchors.safe.json').read_text())['anchors']
        if [r['path'] for r in rows]!=[str(p) for p in list(reversed(OWN.parents))+[OWN]]:
            raise RuntimeError('Complete exact output anchors required')
        try:
            for row in rows:
                p=Path(row['path']);expected=row['identity']
                if identity(p.lstat())!=expected:raise RuntimeError('Pinned native output ancestor changed')
                fd=os.open(str(p) if not self.fds else p.name,flags,dir_fd=None if not self.fds else self.fds[-1])
                self.fds.append(fd)
                if identity(os.fstat(fd))!=expected:raise RuntimeError('Native ancestor switched')
                self.identities.append((p,expected))
            for p,new in [(OWN/'runtime',False),(path,create)]:
                self.check()
                if new:os.mkdir(p.name,0o700,dir_fd=self.fds[-1])
                else:
                    try:os.stat(p.name,dir_fd=self.fds[-1],follow_symlinks=False)
                    except FileNotFoundError:
                        if not create:raise
                        os.mkdir(p.name,0o700,dir_fd=self.fds[-1])
                before=identity(os.stat(p.name,dir_fd=self.fds[-1],follow_symlinks=False))
                if before['uid']!=1000 or before['gid']!=1000 or before['mode']!=0o700:raise RuntimeError('Own700 output directory required')
                fd=os.open(p.name,flags,dir_fd=self.fds[-1]);self.fds.append(fd)
                if identity(os.fstat(fd))!=before:raise RuntimeError('Output directory switched')
                self.identities.append((p,before));self.check()
        except BaseException:self.close();raise
    def check(self):
        if len(self.fds)!=len(self.identities):raise RuntimeError('Ambiguous output descriptors')
        for fd,(p,expected) in zip(self.fds,self.identities):
            if identity(p.lstat())!=expected or identity(os.fstat(fd))!=expected:raise RuntimeError('Pinned output changed')
    def save(self,name,value,new=False):
        self.check()
        if not re.fullmatch(r'[A-Za-z0-9_.+-]+\.json',name):raise RuntimeError('Closed receipt name required')
        flags=os.O_WRONLY|os.O_CREAT|os.O_NOFOLLOW|os.O_CLOEXEC|(os.O_EXCL if new else 0)
        fd=os.open(name,flags,0o600,dir_fd=self.fds[-1])
        try:
            s=os.fstat(fd)
            if not stat.S_ISREG(s.st_mode) or s.st_uid!=1000 or stat.S_IMODE(s.st_mode)!=0o600 or s.st_nlink!=1:raise RuntimeError('Own unaliased600 receipt required')
            self.check();os.ftruncate(fd,0)
            with os.fdopen(fd,'w') as stream:fd=None;stream.write(json.dumps(value,indent=2)+'\n')
        finally:
            if fd is not None:os.close(fd)
    def close(self):
        for fd in reversed(self.fds):os.close(fd)
        self.fds.clear();self.identities.clear()
