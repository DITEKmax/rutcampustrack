import datetime
import hashlib
import json
from pathlib import Path
import re
import subprocess

ROOT=Path('/workspace/rutcampustrack')
AUTHOR=Path('/workspace/rct-worktrees/ci-academic-heap')
DOMAIN=Path('/workspace/rct-worktrees/np01-domain-bot')
OWN=Path('/workspace/scratch/rct-validation/ci_academic_resource_review')
RECEIPTS=Path('/workspace/scratch/rct-validation/ci_academic_heap')
FINAL=RECEIPTS/'artifact-only-final'
BASE='2a23969a69fee28bb5adc51ee7d4c0ef6baf6362'
HEAD='74bca165963b5fd719ad1d817b326105c408e4eb'
PATH='services/academic-service/academic-app/build.gradle.kts'

def sha(b):return hashlib.sha256(b).hexdigest()
def git(*args,cwd=AUTHOR):
 return subprocess.run(['git','-C',str(cwd),*args],check=True,capture_output=True).stdout
def save(name,data):(OWN/name).write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n')

current=AUTHOR/PATH
before=git('show',BASE+':'+PATH)
after=current.read_bytes()
assert git('rev-parse','HEAD').decode().strip()==HEAD
assert not git('status','--porcelain=v1')
assert git('diff','--name-only',BASE,HEAD).decode().splitlines()==[PATH]
assert git('show',HEAD+':'+PATH)==after==(FINAL/'build.gradle.kts.final.txt').read_bytes()
heap=b'tasks.named<Test>("integrationTest") {\n    // Full Spring/Testcontainers suite and the ArchUnit test-class graph share this worker.\n    maxHeapSize = "1g"\n}\n\n'
dep=b'    // NP01 broker bridge exercises the real Auth credential producer and outbox sender.\n    testImplementation(project(":services:auth-service:auth-app")) {\n        isTransitive = false\n    }\n'
assert after.count(heap)==after.count(dep)==1
assert after.replace(heap,b'').replace(dep,b'')==before
assert sha(after)=='ad21eb3f554c465665b662714c62bdd15612e8cd2b5ff8c529b9508cd90f9454'
git('diff','--check',BASE,HEAD)

manifest_checks=[]
for root,filename in [(FINAL,'transfer-manifest.json'),(RECEIPTS,'transfer-manifest.json'),(RECEIPTS,'artifact-link-proposal-manifest.json')]:
 m=json.loads((root/filename).read_text())
 for x in m.get('files',[]):
  loc=root/x.get('file',x.get('path',''))
  record={'manifest':str(root/filename),'path':str(loc),'actual_sha256':sha(loc.read_bytes()),'expected_sha256':x['sha256'],'equal':sha(loc.read_bytes())==x['sha256']}
  manifest_checks.append(record)
  assert record['equal'],record
save('author-seal-audit.json',manifest_checks)

proof={
 'verdict':'APPROVE_SOURCE','scope':'one Academic module build.gradle.kts source only; no runtime or graph-resolution acceptance',
 'base':BASE,'author_final':HEAD,'root_input_revision':git('rev-parse','HEAD',cwd=ROOT).decode().strip(),
 'requested_model':'gpt-6.1-sol','requested_effort':'high','actual_metadata':'UNKNOWN',
 'owned_path':PATH,'before_sha256':sha(before),'after_sha256':sha(after),
 'net_change':'exact5lines IT1g heap block + exact4lines Auth artifact-only TEST edge; removing both restores baseline bytes',
 'source_inventory':[PATH],'unchanged_by_exact_removal':['unit/root/global heap','JUnit engines','test filters/discovery','integration naming/ArchUnit rules','reports/assertions/skips','all previous main/test dependencies/security/version declarations','API/generator/migration/locks'],
 'heap':'bounded1GiB candidate for Academic integrationTest only; source-evidenced prior default512MiB and native ArchUnit heap exhaustion, not a measured sufficient minimum',
 'dependency':'isTransitive=false affects only new Academic→Auth main TEST edge; actual Auth main compilation keeps its own unchanged production dependencies; no new application starters/security excludes/component-scan or auto-configuration disablement',
 'held_candidate':'34c0bd739e5092e693e35a19a144fb9df6970d91 full-transitive is not approved for root integration/run. Transfer finalnetbytes; original author history preserved.',
 'findings':[],'runtime':'NOT_RUN','children':0,'product_shared_source_writes':0,
 'author_final_manifest_sha256':sha((FINAL/'transfer-manifest.json').read_bytes()),
 'source_graph_limit':'Main artifact carries Auth classes/resources even without transitives. Actual external component/hash/security graph equality, resource order and duplicated canonical proto byte equality remain mandatory.',
}
save('source-verdict.json',proof)
(OWN/'reviewed-net.patch').write_bytes(git('diff',BASE,HEAD,'--',PATH))
(OWN/'reviewed-build.gradle.kts.txt').write_bytes(after)

closure_paths=[
 'services/auth-service/auth-app/src/main/java/ru/rutcampustrack/auth/event/PasswordChangedOutbox.java',
 'services/auth-service/auth-app/src/main/java/ru/rutcampustrack/auth/event/PasswordChangedEvent.java',
 'services/auth-service/auth-app/src/main/java/ru/rutcampustrack/auth/session/jdbc/JdbcSessionAuthority.java',
]
closure=[{'path':str(DOMAIN/p),'sha256':sha((DOMAIN/p).read_bytes()),'read_kind':'critical current NP01 v2 source/constructor/executed password transaction fragments'} for p in closure_paths]
auth_dir=ROOT/'services/auth-service/auth-app/src/main/java/ru/rutcampustrack/auth'
files=[auth_dir/'event'/n for n in ['DomainEvent.java','AuthOutboxEntity.java','AuthOutboxPublisherJob.java','RabbitOutboxEventSender.java','RabbitConfig.java']]
files += list((auth_dir/'session/model').glob('*.java'))+[auth_dir/'session/port/CredentialSessionTransactionPort.java',auth_dir/'session/port/SessionStatePort.java']
imports=sorted({m.group(1) for p in files for m in re.finditer(r'^import\s+([^;]+);',p.read_text(),re.MULTILINE)})
closure += [{'path':str(p),'sha256':sha(p.read_bytes()),'read_kind':'producer class source or ports/models signature import scan'} for p in files]
save('needed-auth-source-closure.json',{'domain_current_head':git('rev-parse','HEAD',cwd=DOMAIN).decode().strip(),'sources':closure,'imports':imports,
 'external_type_mapping':[
  {'types':'JDK time/sql/util/io','existing_provider':'Java21'},
  {'types':'Spring JDBC/Tx/context/annotations','existing_provider':'Academic Boot JPA/JDBC/web/context'},
  {'types':'Jackson mapper/core/annotations','existing_provider':'Academic Boot web + shared-outbox'},
  {'types':'RabbitTemplate/RabbitOperations/Message/ConnectionFactory/FanoutExchange','existing_provider':'Academic starter-amqp'},
  {'types':'Jakarta JPA/Hibernate JSONB','existing_provider':'Academic starter-data-jpa + shared-outbox'},
  {'types':'Micrometer/SLF4J/ShedLock','existing_provider':'Academic shared-observability/logback/ShedLock'},
  {'types':'shared event envelope/EventVersion/AbstractEventPublisher and outbox storage/publisher/sender/JPA','existing_provider':'Academic direct shared-events/shared-outbox'},
 ],'specific_missing_type':'None identified in needed constructor/signature/execution source closure. Actual compilation/linking NOT_RUN.',
 'cycle':'Auth main has AuthAPI/shared dependencies; Gateway dependency is Auth TEST-only and not exported by selected main variant. No Auth-main→Academic-app edge.',
 'auto_configuration':'Auth main resources have application/profile/logback files; no AutoConfiguration.imports or spring.factories. AcademicApplication scans its own academic package; no scan expanded by build edit.',
 'proto':'Both consume same canonical academic.proto/protoc/grpc generator version/root Java21 settings; actual variant/generated class/resource equality is still NOT_RUN.'})

plan=json.loads((FINAL/'verification-plan.json').read_text())
plan['reviewer_mandatory_addenda']=[
 'Record metadata-only baseline heap-only and candidate testCompileClasspath/testRuntimeClasspath resolved component coordinates, variants, versions, actual file SHA256 and order under identical final domain/common/config/generated inputs. Expected additive component exactly Auth main/plain artifact; no removed/changed existing artifact or new AuthAPI/Gateway/starter-security/config/web graph. Distinguish compile classes-directory variant from runtime jar/resources if Gradle selects each.',
 'Existing external/security/crypto/JWT artifacts and versions/hash remain identical. Main production classpaths and Auth own production dependencies remain identical. Do not treat classpath-proof.init.gradle (paths only) as that graph delta proof.',
 'Compile actual Auth main explicitly before current Academic compileJava+compileTestJava/new broker test. Resolve missing external symbols as findings; no silent broad starter or security weakening.',
 'After compile, observer may read actual classpath and duplicated canonical class hashes/resource first origins before test execution. It is unexecuted Groovy; if instrument fails, fix only own diagnostic resource or use equivalent read-only observer. No Test/source/filters/app changes.',
 'Capture actual Test Xmx1g and maxfork1 plus unchanged unit default512MiB and JDK provenance. Remeasure shared cgroupCPU4/memory/free disk before a lease; source author onlineCPU5/host MemAvailable do not alone prove current capacity.',
 'Full current unfiltered Academic test AND integrationTest must include naming rule, all old current IT, exact two merged query cases, direct NP01/new broker current cases; no new skips/executor errors. Previous safe CI skip identity is ORDINAL_ONLY/null; identify/qualify actual current XML skip and never mark mandatory skipped case PASS.',
 'Monitor Gradle768MiB/Test1GiB plus native/metaspace/DB/Rabbit/Redis RSS and >=4GiB disk floor; no concurrent full stacks/browser. Native exit0/nonempty native XML/no OOM required. Preserve partial failure/cleanup; further resource correction must have measured hypothesis.',
 'Later current remote CI/Coverage/Security gates on integrated product revision remain mandatory; D009 docs-only exception does not validate changed executable/config/test sources.'
]
plan['review_verdict']='ADEQUATE_MANDATORY_PLAN_NOT_EXECUTED'
save('mandatory-runtime-proof-plan.json',plan)

inputs=[ROOT/'build.gradle.kts',ROOT/'settings.gradle.kts',ROOT/'gradle/libs.versions.toml',ROOT/'gradle/wrapper/gradle-wrapper.properties',ROOT/'services/auth-service/auth-app/build.gradle.kts',ROOT/'services/shared/shared-security/build.gradle.kts',ROOT/'services/shared/shared-events/build.gradle.kts',ROOT/'services/shared/shared-outbox/build.gradle.kts',ROOT/'services/academic-service/academic-app/src/main/java/ru/rutcampustrack/academic/AcademicApplication.java',ROOT/'proto/academic.proto',ROOT/'docs/validation/cloud-20261011/receipts/checkpoint25668-academic-failure.safe.json',RECEIPTS/'gradle-default-heap-proof.json',RECEIPTS/'source-proof.json',FINAL/'source-proof.json',FINAL/'verification-plan.json',FINAL/'transfer-manifest.json']
inputs += [ROOT/'docs/validation/cloud-20261011'/n for n in ['TASK-CONTRACT.md','CURRENT.md','decisions.md','questions.md','resources.md','packet-ci-academic-resource-review.md']]
save('input-source-identities.json',[{'path':str(p),'sha256':sha(p.read_bytes()),'bytes':p.stat().st_size} for p in inputs])
print(json.dumps({'verdict':proof['verdict'],'manifest_entries_verified':len(manifest_checks),'source_SHA':sha(after),'runtime':'NOT_RUN'}))
