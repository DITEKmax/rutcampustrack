import datetime,hashlib,ipaddress,json,os,stat,subprocess
from pathlib import Path
import yaml
OWN=Path('/workspace/scratch/rct-validation/current_host_config_directional_v3');OUT=Path(__file__).parent
NAME='rct-client-host-config-20261012'
os.umask(0o077)
def call(argv):
 p=subprocess.run(argv,stdin=subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=subprocess.DEVNULL,timeout=25,check=False)
 if p.returncode:raise RuntimeError('Read-only metadata exit '+str(p.returncode))
 return p.stdout.decode()
compose=yaml.safe_load((OWN/'data-renderer-edge.compose.yml').read_text())
assert not call(['docker','container','ls','-aq','--filter','label=com.docker.compose.project='+NAME]).strip()
containers=call(['docker','container','ls','-a','--format','{{.Names}}']).splitlines()
assert not any(n.startswith(NAME+'-') or n.startswith(NAME+'_') for n in containers)
network_names=call(['docker','network','ls','--format','{{.Name}}']).splitlines()
volume_names=call(['docker','volume','ls','--format','{{.Name}}']).splitlines()
assert compose['networks']['private_net']['name'] not in network_names
assert not {v['name'] for v in compose['volumes'].values()} & set(volume_names)
ports={8080,9080,9090,9091,9092,9093,9094,19091,19092,19093,19095,28379,28417,28432,28433,28672,28488,8443}
listeners=[]
for name in ['tcp','tcp6']:
 for line in Path('/proc/net/'+name).read_text().splitlines()[1:]:
  fields=line.split()
  if fields[3]=='0A' and int(fields[1].split(':')[1],16) in ports:listeners.append(int(fields[1].split(':')[1],16))
assert not listeners
subnet=ipaddress.ip_network('172.29.84.0/24');overlaps=[]
for line in Path('/proc/net/route').read_text().splitlines()[1:]:
 cols=line.split();destination=int(cols[1],16);mask=int(cols[7],16)
 if mask:
  net=ipaddress.IPv4Network((str(ipaddress.IPv4Address(destination.to_bytes(4,'little'))),str(ipaddress.IPv4Address(mask.to_bytes(4,'little')))))
  if subnet.overlaps(net):overlaps.append(str(net))
assert not overlaps
images=[]
for image in sorted({s['image'] for s in compose['services'].values()}):
 raw=call(['docker','image','inspect',image,'--format','{{json .Id}} {{json .Size}} {{json .Config.User}} {{json .Config.WorkingDir}}'])
 # Field sequence consists only metadata scalar values; no Config.Env, labels, logs, or health bodies.
 import shlex
 parts=shlex.split(raw);assert parts[0]==image
 images.append({'id':parts[0],'logical_image_bytes':int(parts[1]),'user':parts[2],'cwd':parts[3]})
mounts=[]
for service,data in compose['services'].items():
 for item in data.get('volumes',[]):
  if isinstance(item,dict):
   p=Path(item['source']);st=p.lstat();assert not p.is_symlink() and p.exists() and item['read_only'] and item['bind']['create_host_path'] is False
   row={'service':service,'source':str(p),'target':item['target'],'mode':oct(stat.S_IMODE(st.st_mode)),'uid':st.st_uid,'read_only':True}
   if p.is_file():row['public_source_sha256']=hashlib.sha256(p.read_bytes()).hexdigest()
   mounts.append(row)
for row in json.loads((OWN/'launch-manifest.json').read_text())['files']:
 assert hashlib.sha256(Path(row['path']).read_bytes()).hexdigest()==row['sha256']
fs=os.statvfs('/workspace');free=fs.f_bavail*fs.f_frsize;mem=int(Path('/sys/fs/cgroup/memory.current').read_text());maximum=int(Path('/sys/fs/cgroup/memory.max').read_text())
logical=sum(next(i['logical_image_bytes'] for i in images if i['id']==s['image']) for s in compose['services'].values())
assert free>=4294967296+logical+1073741824 and mem<16106127360 and maximum-mem>=1073741824
receipt={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'PASS_ACTUAL_FRESH_READONLY_PREFLIGHT','project':NAME,'namespace_container_network_volume_conflicts':False,'occupied_projected_ports':listeners,'IPAM_route_overlaps':overlaps,'images':images,'mounts':mounts,'config_safe_files_exact':True,'free_available_bytes':free,'memory_current':mem,'memory_max':maximum,'Docker9_logical_copy_projection':logical,'after_projection_growth_floor_headroom':free-logical-1073741824-4294967296,'actual_copy_allocation':'NOT_YET_MEASURED','ENV_key_log_HealthLog_read':False}
(OUT/'preflight.safe.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({'status':receipt['status'],'free':free,'memory':mem,'Docker_logical':logical,'headroom':receipt['after_projection_growth_floor_headroom']}))
