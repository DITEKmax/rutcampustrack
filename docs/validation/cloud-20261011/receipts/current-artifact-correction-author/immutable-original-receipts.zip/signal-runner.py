import importlib.util
import json
from pathlib import Path
import sys

OWN = Path(__file__).parent
spec = importlib.util.spec_from_file_location('bounded_child', OWN/'bounded-child.py')
helper = importlib.util.module_from_spec(spec)
spec.loader.exec_module(helper)
minimal_env = {'PATH':'/usr/bin:/bin', 'LANG':'C.UTF-8', 'LC_ALL':'C.UTF-8'}


def status(value):
    (OWN/'signal-status.json').write_text(json.dumps(value,indent=2)+'\n')


result = helper.run_owned([sys.executable,'-I','-S','-B',str(OWN/'harmless-tree.py'),
                          'signal',str(OWN/'signal-tree.json')], str(OWN),minimal_env,
                         deadline_seconds=8,term_seconds=1,kill_seconds=3,status=status)
(OWN/'signal-result.json').write_text(json.dumps(result,indent=2)+'\n')
raise SystemExit(0 if result['settled'] else 1)
