"""Selected source predicates only: no child, network, private file or syscall effect."""
import datetime as real_dt
import importlib.util
import json
from pathlib import Path
from types import SimpleNamespace

ROOT = Path(__file__).parent
spec = importlib.util.spec_from_file_location('capture', ROOT/'capture-job-private.py')
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)
now = real_dt.datetime.now(real_dt.timezone.utc)
class Clock:
    delay = 0
    fromisoformat = staticmethod(real_dt.datetime.fromisoformat)
    @staticmethod
    def now(tz):
        return now + real_dt.timedelta(seconds=Clock.delay)
class WS:
    f_bavail = 10 * 1024**3
    f_frsize = 1
shared = [4 * 1024**3]
m.os = SimpleNamespace(statvfs=lambda _: WS())
m.Path = lambda _: SimpleNamespace(read_text=lambda: str(shared[0]))
m.dt = SimpleNamespace(datetime=Clock, timezone=real_dt.timezone)
g = {'authorized': True, 'scope': 'EXACT1742_JOB_LOG_READ_ONLY',
    'head': '1742d1e806faa5c39c6d182a3554daa8f4239801', 'run_id':38387263916,
    'job_id':115262001797, 'run_attempt':1, 'capture_sha256':'own',
    'max_bytes':m.CAP, 'phase_seconds':45,
    'not_before':(now-real_dt.timedelta(seconds=1)).isoformat(),
    'cleanup_gate':(now+real_dt.timedelta(seconds=60)).isoformat(),
    'hard_stop':(now+real_dt.timedelta(seconds=90)).isoformat()}
checks=[]
def case(name,fn,denied=False):
    try:
        fn()
        assert not denied
    except RuntimeError:
        assert denied
    checks.append({'name':name,'passed':True})
case('exact grant permitted',lambda:m.validate_grant(g,'own'))
for key,value in [('authorized',False),('scope','wrong'),('head','0'*40),
    ('run_id',1),('job_id',2),('run_attempt',2),('capture_sha256','foreign'),
    ('max_bytes',m.CAP+1),('phase_seconds',46),('run_id',True)]:
    case('false grant '+key,lambda key=key,value=value:m.validate_grant(dict(g,**{key:value}),'own'),True)
case('cleanup margin denied',lambda:m.validate_grant(dict(g,hard_stop=g['cleanup_gate']),'own'),True)
case('fresh resources allowed',lambda:m.fresh(g))
case('entry expired denied',lambda:m.fresh(dict(g,cleanup_gate=(now-real_dt.timedelta(seconds=1)).isoformat())),True)
WS.f_bavail=1
case('workspace floor denied',lambda:m.fresh(g),True)
WS.f_bavail=10*1024**3
shared[0]=15*1024**3
case('shared reserve denied',lambda:m.fresh(g),True)
shared[0]=4*1024**3
Clock.delay=70
case('measurement-delay clock LAST denies before effect',lambda:m.fresh(g),True)
print(json.dumps({'state':'SOURCE_RAM_CHECKS_PASS','checks':checks,
    'native_children':0,'actual_capture':False}))
