# Узкая correction witness3P2

Исходный2354 сохранён. Новый helper использует текущий canonical0a8f classifier вместо своего regex; только HTTP503 и известная форма могут дать причинные closed enums, Academic prefix оставляет RPC operation UNKNOWN.

Два provisional auth handles получают отдельные APIRequestContext до login. Токен/успешный login учитываются до fallible session/role gates и dispose. Logout использует собственные cookie и последний bearer того же SID; требуется204, удаление refresh cookie и dispose. Ошибка cleanup не становится PASS.

Users и lessons требуют известный HATEOAS page0/size100/totalPages1/точное число/уникальные positive IDs без next. Исходная хронология двух HEADMAN, дата12Oct и ровно один существующий lesson сохранены. Результат содержит только closed fields; никаких сохранённых IDs/токенов/тел/паролей/detail.

Controls проверяют actual corrected JS functions и извлечённые old source seams на публичных adapters: неправильный HTTP/malformed classifier; отсутствующая/неполная пагинация; post-login gate с потерей old token; два cookie/bearer владельца и подтверждение logout/dispose. Это SOURCE/native-план, не доказательство HTTP/browser или причины503. Native пока NOT_RUN; старые grant не используются.
