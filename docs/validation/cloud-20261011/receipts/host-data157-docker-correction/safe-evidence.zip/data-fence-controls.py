"""Actual selected metadata reader and finite pure negative controls; no data contents."""
import copy
import hashlib
import json
import types
from pathlib import Path
from unittest.mock import patch

OWN = Path(__file__).parent
module = types.ModuleType('exact_restart_metadata')
module.__file__ = str(OWN / 'restart-boundary.py')
exec(compile((OWN / 'restart-boundary.py').read_bytes(), module.__file__, 'exec'), module.__dict__)
grant = {'stopped_mongo_data_fence_path': str(module.DATA_FENCE),
    'stopped_mongo_data_fence_sha256': module.DATA_FENCE_SHA}
fence = module.load_existing_data_fence(grant)
module.verify_existing_data(fence, stopped=True)
checks = [{'case': 'NEW canonical157 actual stopped metadata accepted', 'pass': True, 'data_contents_read': False}]
old = json.loads((module.PLAN / 'stopped-native-data-fence.safe.json').read_text())
try:
    module.verify_existing_data(old, stopped=True)
except RuntimeError:
    checks.append({'case': 'old156 rejected after genuine retained-data restart', 'pass': True})
else:
    raise AssertionError('Old156 must not be silently reused')

for name, field, value in [
    ('wrong path', 'stopped_mongo_data_fence_path', str(module.PLAN / 'stopped-native-data-fence.safe.json')),
    ('wrong digest', 'stopped_mongo_data_fence_sha256', '0' * 64),
    ('missing path', 'stopped_mongo_data_fence_path', None),
    ('missing digest', 'stopped_mongo_data_fence_sha256', None),
]:
    bad = dict(grant)
    bad[field] = value
    try:
        module.load_existing_data_fence(bad)
    except RuntimeError:
        checks.append({'case': name + ' denied before mutation', 'pass': True})
    else:
        raise AssertionError(name)

for name, field in [('key inode changed', 'exact_key_metadata'), ('runtime inode changed', 'runtime_directory_identity')]:
    bad = copy.deepcopy(fence)
    bad[field]['inode'] += 1
    try:
        module.verify_existing_data(bad, stopped=True)
    except RuntimeError:
        checks.append({'case': name + ' denied', 'pass': True})
    else:
        raise AssertionError(name)

bad = copy.deepcopy(fence)
bad['stopped_db_metadata_nodes'][-1]['bytes'] += 1
try:
    module.verify_existing_data(bad, stopped=True)
except RuntimeError:
    checks.append({'case': 'changed stopped node rejected', 'pass': True})
else:
    raise AssertionError('Changed metadata accepted')
with patch.object(module.os, 'getuid', return_value=0):
    try:
        module.load_existing_data_fence(grant)
    except RuntimeError:
        checks.append({'case': 'wrong actor denied before fence reads', 'pass': True})
    else:
        raise AssertionError('Wrong actor accepted')

(OWN / 'data-fence-controls.safe.json').write_text(json.dumps({'status': 'PASS_READONLY_METADATA_AND_PURE_DENIAL_CONTROLS',
    'count': len(checks), 'checks': checks, 'native_launch_or_private_key_ENV_DB_content_reads': False,
    'existing_db_key_not_copied_reset_deleted_or_bootstrapped': True}, indent=2) + '\n')
print(json.dumps({'controls': len(checks), 'canonical157_actual_metadata_equal': True, 'native_launch': False}))
