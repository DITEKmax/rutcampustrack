"""Execute only the exact new exclusion function AST on safe synthetic paths."""
import ast
import hashlib
import json
from pathlib import Path, PurePosixPath
import re

OWN=Path(__file__).parent
source=(OWN/'strict-source-plan.py').read_text()
tree=ast.parse(source)
body=[node for node in tree.body if isinstance(node,ast.Assign)
      and any(isinstance(target,ast.Name) and target.id in ['EXCLUDED','PRIVATE','EXECUTABLE_OUTPUT_SUFFIXES'] for target in node.targets)]
body+=[node for node in tree.body if isinstance(node,ast.FunctionDef) and node.name=='exclusion']
namespace={'PurePosixPath':PurePosixPath,'re':re}
exec(compile(ast.Module(body=body,type_ignores=[]),'exact_strict_filter','exec'),namespace)
function=namespace['exclusion']
negative=['.agent/orchestration-v2/metrics/packages.csv','.AGENT/runtime/report.json',
          'docs/design/evidence/example.png','docs/design/current-evidence/example.png',
          'docs/validation/cloud-20261011/CURRENT.md','old/receipts/index.json',
          'build/classes/Test.class','target/output/file.txt','frontends/mobile-core/src/api/generated/client.ts',
          'frontends/landing/dist/index.html','frontends/web-panel/dist/browser/file.js',
          'node_modules/pkg/index.js','.gradle/caches/value.bin','cache/file.txt','coverage/result.json',
          'docs/openapi/mobile-bff.json','DOCS/OPENAPI/mobile-bff.json','infra/.env.private','x/.npmrc',
          'certs/tls.pem','private/keys/key.txt','private/secrets/value.json','archive/program.jar']
positive=['docs/presentations/student-final.html','docs/product/job-stories.yaml',
          'services/auth-service/auth-app/src/main/java/ru/rutcampustrack/auth/AuthApplication.java',
          'frontends/mobile-core/src/features/homework.ts']
assert all(function(path) is not None for path in negative)
assert all(function(path) is None for path in positive)
diagnosis=json.loads((OWN/'strict-source-diagnosis.json').read_text())
total=0
for scope in diagnosis['scopes']:
    rows=json.loads((OWN/(scope['scope']+'-strict-candidates.json')).read_text())
    assert all(function(row['relative_path']) is None for row in rows)
    total+=len(rows)
peer=json.loads(Path('/workspace/scratch/rct-validation/host_capacity_review/strict-selection-review.json').read_text())
rejected=peer['excluded_paths']
assert all(function(row['relative_path']) is not None for row in rejected)
result={'new_source_filter_SHA':hashlib.sha256(source.encode()).hexdigest(),
        'negative_synthetic_paths':negative,'positive_public_source_paths':positive,
        'all_negatives_rejected':True,'all_positives_accepted':True,
        'actual_selected_rows_checked':total,'all_selected_satisfy_strict_filter':True,
        'all_peer847_excluded_paths_now_rejected':True,'peer_excluded_rows':len(rejected),
        'resource_mutation':False,'native_exit':0}
(OWN/'filter-proof.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({key:value for key,value in result.items() if not isinstance(value,list)}))
