'use strict';

// No specs, dataset, users, API requests, reporters or test runner are loaded.
const fs = require('node:fs');
const path = require('node:path');
const e2e = '/workspace/rutcampustrack/tests/e2e';
const r1 = '/workspace/scratch/rct-validation/client_real_acceptance/focused3-preparation-5ced-r1';
const stages = new Set(['CONFIG_LOAD', 'CONFIG_GUARD', 'BROWSER_LAUNCH', 'ABOUT_BLANK', 'PUBLIC_HEADING', 'CONTEXT_CLOSE', 'BROWSER_CLOSE']);
const classes = new Set(['Error', 'TypeError', 'RangeError', 'ReferenceError', 'SyntaxError', 'TimeoutError']);
const errorClass = (error) => classes.has(error?.name) ? error.name : 'OTHER';
const typeOfClock = (value) => value instanceof Date ? 'DATE' : value === undefined ? 'UNDEFINED' : typeof value === 'string' ? 'STRING' : 'OTHER';

async function configFacts(full) {
  const projects = full.config.projects;
  const project = projects.find((item) => item.name === 'chromium');
  const use = project?.use ?? {};
  const facts = {
    projectCount: projects.length,
    singleChromium: projects.length === 1 && project?.name === 'chromium',
    reporterCount: full.config.reporter.length,
    canonicalReporter: full.config.reporter.length === 1 && full.config.reporter[0][0] === path.join(e2e, 'fixtures/safe-reporter.ts'),
    traceOff: use.trace === 'off',
    videoOff: use.video === 'off',
    screenshotOff: use.screenshot === 'off',
    supportedFlag: process.env.PLAYWRIGHT_NO_COPY_PROMPT === '1',
    debugFlagsAbsent: !['PW_TEST_REPORTER', 'DEBUG', 'DEBUG_FILE', 'PWDEBUG'].some((name) => process.env[name]),
    syntheticMetadataFlag: process.env.RCT_E2E_SYNTHETIC_SEED === 'true',
    loopbackTarget: use.baseURL === 'https://localhost:8443',
    oneWorker: full.config.workers === 1,
    zeroRetries: project?.retries === 0,
    noWebServer: full.webServers.length === 0,
    noGlobalHooks: full.globalSetups.length === 0 && full.globalTeardowns.length === 0,
    teachingInstantType: typeOfClock(use.teachingInstant),
    teachingInstantValid: use.teachingInstant instanceof Date && Number.isFinite(use.teachingInstant.getTime()),
    requireResolveAvailable: typeof require.resolve === 'function',
    privateGuardPassed: false,
    guardErrorClass: null,
  };
  const transform = require(path.join(e2e, 'node_modules/playwright/lib/transform/transform.js'));
  const privacy = await transform.requireOrImport(path.join(e2e, 'fixtures/artifact-privacy.ts'));
  try {
    privacy.requirePrivateArtifacts({ config: full.config, project });
    facts.privateGuardPassed = true;
  } catch (error) {
    facts.guardErrorClass = errorClass(error);
  }
  return facts;
}

function factsPass(facts) {
  return facts.projectCount === 1 && facts.reporterCount === 1 && facts.teachingInstantType === 'DATE' &&
    Object.entries(facts).every(([key, value]) => ['projectCount', 'reporterCount', 'teachingInstantType', 'guardErrorClass'].includes(key) || value === true);
}

async function main() {
  const output = path.join(process.env.RCT_FOCUS3_RUN, 'supervision/precredential.safe.json');
  const result = { schema: 'RCT_PRECREDENTIAL_PROBE_V1', scope: 'CONFIG_AND_PUBLIC_BROWSER_ONLY', stages: [], passed: false, clientAcceptance: false, workerEffectiveTeachingInstantType: 'NOT_MEASURED_CONFIG_ONLY' };
  function save() {
    fs.writeFileSync(output + '.next', JSON.stringify(result, null, 2) + '\n', { mode: 0o600 });
    fs.renameSync(output + '.next', output);
  }
  function record(stage, passed, facts = null, error = null) {
    if (!stages.has(stage)) throw new Error('Invalid closed stage');
    result.stages.push({ stage, passed, facts, errorClass: error ? errorClass(error) : null });
    save();
  }
  save();
  let full;
  try {
    const loader = require(path.join(e2e, 'node_modules/playwright/lib/common/configLoader.js'));
    full = await loader.loadConfigFromFile(path.join(r1, 'focus3.config.ts'), { workers: 1, retries: 0 });
    record('CONFIG_LOAD', true);
    const facts = await configFacts(full);
    record('CONFIG_GUARD', factsPass(facts), facts);
  } catch (error) {
    record(full ? 'CONFIG_GUARD' : 'CONFIG_LOAD', false, null, error);
  }
  let browser;
  let context;
  let stage = 'BROWSER_LAUNCH';
  try {
    const { chromium } = require(path.join(e2e, 'node_modules/playwright'));
    browser = await chromium.launch({ headless: true, timeout: 20000 });
    record(stage, true);
    context = await browser.newContext({ viewport: { width: 1280, height: 720 }, serviceWorkers: 'block' });
    const page = await context.newPage();
    stage = 'ABOUT_BLANK';
    await page.goto('about:blank', { timeout: 5000 });
    record(stage, page.url() === 'about:blank');
    stage = 'PUBLIC_HEADING';
    await page.setContent('<!doctype html><html><body><h1>Public diagnostic heading</h1></body></html>', { timeout: 5000 });
    const heading = page.getByRole('heading', { name: 'Public diagnostic heading', exact: true });
    const facts = { headingCount: await heading.count(), headingVisible: await heading.isVisible() };
    record(stage, facts.headingCount === 1 && facts.headingVisible, facts);
  } catch (error) {
    record(stage, false, null, error);
  } finally {
    if (context) {
      try { await context.close(); record('CONTEXT_CLOSE', true); }
      catch (error) { record('CONTEXT_CLOSE', false, null, error); }
    }
    if (browser) {
      try { await browser.close(); record('BROWSER_CLOSE', true); }
      catch (error) { record('BROWSER_CLOSE', false, null, error); }
    }
  }
  result.passed = result.stages.length === 7 && result.stages.every((item) => item.passed);
  save();
  process.exitCode = result.passed ? 0 : 1;
}

main().catch(() => { process.exitCode = 2; });
