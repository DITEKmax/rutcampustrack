from pathlib import Path
import ast, contextlib, hashlib, io, json, os, runpy, zipfile
P=Path(__file__).parent
A=Path('/workspace/scratch/rct-validation/roster_academic_auth_backend')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
previous=json.loads((P.parent/'review.safe.json').read_text())
for old,current in [('before-c78-run-red-owned.py','run-red-owned.py'),('before-a987-logged-red-child.py','logged-red-child.py')]:
 row=next(r for r in previous['sources'] if r['path']==str(A/current));assert sha(A/old)==row['sha256']
assert sha(A/'run-red-owned.py')=='3880070bcd013c2ac60a7a9aa602d5ef913207750877ccf186fa411d81661615'
assert sha(A/'logged-red-child.py')=='26ed3d33e305d2f8720e8bd8f922600e0452a21227fda5cc933057bd5fa02624'
for row in previous['sources']:
 if row['path'] not in [str(A/'run-red-owned.py'),str(A/'logged-red-child.py')]:assert sha(Path(row['path']))==row['sha256']
for name in ['observe','status','digest','utc','write']:
 def segment(p):return ast.get_source_segment(p.read_text(),next(n for n in ast.parse(p.read_text()).body if isinstance(n,ast.FunctionDef) and n.name==name))
 assert segment(A/'before-c78-run-red-owned.py')==segment(A/'run-red-owned.py')
with contextlib.redirect_stdout(io.StringIO()):ns=runpy.run_path(str(A/'child-binding-source-controls.py'))
assert all(ns['results'].values()) and len(ns['results'])==9
controls=dict(ns['results'])
RamPath=ns['RamPath'];original=RamPath.read_bytes
for name,value in [('wrong_parent_argv_denied',b'python\0/OTHER\0/grant\0grant-hash\0'),('extra_parent_argv_denied',b'python\0/scope/run-red-owned.py\0/grant\0grant-hash\0EXTRA\0')]:
 RamPath.read_bytes=lambda self,v=value:v
 controls[name]=not ns['allowed'](ns['valid']);assert controls[name]
RamPath.read_bytes=original
ns['child']['ppid']=99;controls['wrong_child_ppid_denied']=not ns['allowed'](ns['valid']);assert controls['wrong_child_ppid_denied'];ns['child']['ppid']=11
driver=(A/'run-red-owned.py').read_text();child=(A/'logged-red-child.py').read_text()
assert driver.index('write("parent-authority.private.json"')<driver.index('result = guard.run_owned(')
assert child.index('plan, run = admit_child(scope)')<child.index('with log.open("xb")')<child.index('result = subprocess.run(')
assert 'os.O_RDONLY | os.O_NOFOLLOW' in child and 'info.st_size > 65536' in child and 'stream.read(65537)' in child
assert 'if identity(parent["pid"]) != parent or identity(child["pid"]) != child:' in child
assert '(run / "parent-authority.private.json").unlink()' in driver
result={'verdict':'APPROVE_SOURCE','scope':'WIRE-RED-CHILD-FRESH-OWNERSHIP_ONLY','driver_sha256':sha(A/'run-red-owned.py'),'child_sha256':sha(A/'logged-red-child.py'),'plan_sha256':sha(A/'red-plan.safe.json'),'test_sha256':next(r['sha256'] for r in previous['sources'] if r['path'].endswith('HeadmanJournalSemesterTransportTest.java')),'original_driver_child_seals_preserved':True,'other_previous_source_hashes_unchanged':True,'five_parent_functions_byte_exact':True,'selected_actual_ast_controls':controls,'native_helper_or_product_runtime_executed':False,'private_grant_credentials_logs_XML_read':False,'gate_order':'Parent private envelope written before dispatch. Child fresh bounded600/no-follow grant+source closure, exact live direct PPID/birth/cmdline and clock margin recheck finish before private log allocation and Gradle. No STARTED wait/spin.', 'limits':['This is accidental/direct/stale invocation containment, not cryptographic or adversarial same-UID isolation.','Source path resolution plus O_NOFOLLOW protects normal fixed private input admission; no hard hostile ancestor-race isolation claim.','Source approval is not native grant or actual capacity/RED evidence.','Existing test source APPROVE remains conditional on actual compilation and exact selected native causal outcome; native1/outer0 alone never proves causal RED.','Private authority envelope/logs must remain excluded from SAFE publication; actual exact owned reaping/source preservation and causal JUnit provenance required after runtime.']}
os.umask(0o077)
with (P/'recheck.safe.json').open('x') as f:json.dump(result,f,indent=2);f.write('\n')
with (P/'REPORT.md').open('x') as f:f.write('APPROVE_SOURCE, caller-only correction. Original c78/a987 copies and prior plan/test/policy source hashes exact. Parent authority envelope precedes dispatch; child fresh grant/source/clock/live-direct-parent/birth/cmdline checks precede log allocation/Gradle. Independently ran nine actual-source RAM controls plus three commandline/direct-parent denials; all12 PASS. No helper/Gradle/JVM/runtime/private data executed or read. Source approval is not Root native permission or causal RED. Same-UID hostile isolation is not claimed.\n')
files=[p for p in P.iterdir() if p.is_file()]
with (P/'manifest.safe.json').open('x') as f:json.dump({'verdict':'APPROVE_SOURCE','files':[{'path':p.name,'bytes':p.stat().st_size,'sha256':sha(p)} for p in sorted(files)]},f,indent=2);f.write('\n')
with zipfile.ZipFile(P/'safe-recheck.zip','x',zipfile.ZIP_DEFLATED) as z:
 for p in sorted(files)+[P/'manifest.safe.json']:z.write(p,p.name)
print(json.dumps({'verdict':'APPROVE_SOURCE','manifest_sha256':sha(P/'manifest.safe.json'),'zip_sha256':sha(P/'safe-recheck.zip'),'zip_bytes':(P/'safe-recheck.zip').stat().st_size,'controls':len(controls)}))
