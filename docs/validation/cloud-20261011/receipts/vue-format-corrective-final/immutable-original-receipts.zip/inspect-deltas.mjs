import fs from 'node:fs'
import { spawnSync } from 'node:child_process'
process.argv[2]='library'
const {vue}=await import('../prettier-final/verify-meaning.mjs')
const scratch='/workspace/scratch/rct-validation/authored_format_current/vue-eslint-correction'
const x=JSON.parse(fs.readFileSync(`${scratch}/pipeline-probe.safe.json`,'utf8'))
const out=[]
function lookup(obj,path){for(const key of path.split('/').slice(1))obj=obj?.[key];return obj}
for(const r of x.rows.filter(r=>!r.meaningEqual)) {
 const base=spawnSync('git',['show',`cd3f237acffd4f0b9dd2a74babb2ee822376f0cb:${r.path}`],{cwd:'/workspace/rutcampustrack',encoding:'utf8'}).stdout
 const candidate=fs.readFileSync(`${scratch}/candidate/${r.path}`,'utf8')
 const a=await vue(base,r.path),b=await vue(candidate,r.path)
 out.push({path:r.path,firstDelta:r.firstMeaningDelta,originalValue:lookup(a,r.firstMeaningDelta),candidateValue:lookup(b,r.firstMeaningDelta)})
}
fs.writeFileSync(`${scratch}/render-literal-deltas.safe.json`,JSON.stringify(out,null,2)+'\n',{mode:0o600})
console.log(JSON.stringify(out))
