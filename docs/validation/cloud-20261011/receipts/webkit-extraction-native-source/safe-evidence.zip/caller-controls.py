import ast,copy,datetime,json,os,stat,types
from pathlib import Path
from unittest.mock import patch
P=Path(__file__).parent
checks=[]
def load(name):
 m=types.ModuleType(name);m.__file__=str(P/name);exec(compile((P/name).read_bytes(),name,'exec'),m.__dict__);return m
extract=load('extract-selected.py');native=load('validate-native.py');wrapper=load('webkit-custom-exec.py');probe=load('native-probe.py');paths=load('own-paths.py')
def check(name,fn,want):
 ok=False
 try:fn();ok=True
 except (ValueError,RuntimeError,OSError,KeyError,TypeError):pass
 assert ok==want,(name,ok);checks.append({'name':name,'expected_accept':want,'pass':True,'native_or_payload_actions':False})
now=datetime.datetime(2026,10,12,17,0,tzinfo=datetime.timezone.utc)
ex={'library_extraction_authorized':True,'native_validation_authorized':False,'browser_launch_authorized':False,'prefix':str(extract.PREFIX),'prefix_allocated_cap':extract.CAP,'rss_stop_bytes':extract.RSS,'execution_actor_uid':1000,'execution_actor_gid':1000,'selected_regular_count':14,'selected_symlink_count':8,'selected_regular_bytes':12231288,'not_before_utc':now.isoformat(),'stop_utc':(now+datetime.timedelta(seconds=600)).isoformat()}
ng={'native_validation_authorized':True,'library_extraction_authorized':False,'browser_launch_authorized':False,'execution_actor_uid':1000,'execution_actor_gid':1000,'prefix_allocated_cap':33554432,'rss_stop_bytes':201326592,'cohort_name':'native-test','not_before_utc':ex['not_before_utc'],'stop_utc':ex['stop_utc']}
bg={'browser_launch_authorized':True,'library_extraction_authorized':False,'native_validation_authorized':False,'execution_actor_uid':1000,'execution_actor_gid':1000,'declared_browser_environment':{'PATH':'/usr/bin:/bin'},'not_before_utc':ex['not_before_utc'],'stop_utc':ex['stop_utc']}
for name,fn,g in [('extract',extract.validate_grant,ex),('native',native.validate_fields,ng),('browser',wrapper.validate_browser_grant,bg)]:
 check('exact finitephase '+name,lambda fn=fn,g=g:fn(g,now),True)
 for key,value in [('execution_actor_uid',0),('execution_actor_gid',0),('stop_utc',(now+datetime.timedelta(seconds=1801)).isoformat()),('not_before_utc',(now+datetime.timedelta(seconds=1)).isoformat())]:
  bad=dict(g);bad[key]=value;check('deny wrongactor/window '+name+' '+key,lambda fn=fn,bad=bad:fn(bad,now),False)
 check('deny expired '+name,lambda fn=fn,g=g:fn(g,now+datetime.timedelta(seconds=1801)),False)
for key,value in [('native_validation_authorized',True),('browser_launch_authorized',True),('library_extraction_authorized',False),('selected_regular_count',True),('selected_regular_bytes',0),('prefix','/tmp/foreign'),('prefix_allocated_cap',99999999),('rss_stop_bytes',99999999)]:
 g=dict(ex);g[key]=value;check('extractfalsegrant '+key,lambda g=g:extract.validate_grant(g,now),False)
for key,value in [('library_extraction_authorized',True),('browser_launch_authorized',True),('cohort_name','native-a/../b')]:
 g=dict(ng);g[key]=value;check('nativefalsegrant '+key,lambda g=g:native.validate_fields(g,now),False)
for key,value in [('library_extraction_authorized',True),('native_validation_authorized',True),('declared_browser_environment',{'https_proxy':'synthetic'}),('declared_browser_environment',{'LD_LIBRARY_PATH':'foreign'}),('declared_browser_environment',{'JAVA_TOOL_OPTIONS':'foreign'})]:
 g=dict(bg);g[key]=value;check('browserfalsegrant '+key,lambda g=g:wrapper.validate_browser_grant(g,now),False)
expected=[('public-'+str(i),'variant','loader' if i<39 else 'gles' if i<41 else 'x264') for i in range(43)]
proof={'status':'PASS_EFFECTIVE_NATIVE_AVAILABILITY_ONLY','loader_count':39,'actual_GLES_dlopen':True,'actual_x264_dlopen_symbol':True,'version_errors':False,'results':[{'target':t,'variant':v,'kind':k,'pass':True} for t,v,k in expected]}
check('pure complete43proof structure only, synthetic flagsNOTactualABI',lambda:wrapper.validate_effective_proof(proof,expected),True)
for key,value in [('loader_count',39.0),('loader_count',38),('actual_GLES_dlopen',False),('actual_x264_dlopen_symbol',False),('version_errors',True),('status','UNKNOWN')]:
 x=copy.deepcopy(proof);x[key]=value;check('reject unproved native '+key,lambda x=x:wrapper.validate_effective_proof(x,expected),False)
for name,mutation in [('missingloader',lambda x:x['results'].pop(0)),('duplicatedcase',lambda x:x['results'].__setitem__(-1,copy.deepcopy(x['results'][0]))),('falsecase',lambda x:x['results'][0].__setitem__('pass',False)),('foreigntarget',lambda x:x['results'][0].__setitem__('target','foreign'))]:
 x=copy.deepcopy(proof);mutation(x);check('exactproof '+name,lambda x=x:wrapper.validate_effective_proof(x,expected),False)
# Selected loader parser, all public path/byte reads mocked. No actual loader/CDLL/version checks.
for name,rc,text,want in [('valid',0,'libc.so.6 => /usr/lib/libc.so.6 (0x1)',True),('emptyzero',0,'',False),('garbagezero',0,'garbage',False),('missingSONAME',127,'error while loading shared libraries: libmissing.so.2: cannot open shared object file',False),('missingversion',1,'libc.so.6 => /usr/lib/libc.so.6 (0x1)\nversion GLIBC_999 not found',False),('warningversion',0,'libc.so.6 => /usr/lib/libc.so.6 (0x1)\nno version information available',False),('foreignresolvedpath',0,'libbad.so.1 => /workspace/foreign (0x1)',False)]:
 with patch.object(Path,'resolve',lambda self,**kw:self),patch.object(Path,'is_file',lambda self:True),patch.object(probe,'sha',lambda path:'synthetic-public-hash'):
  def classify(rc=rc,text=text):
   value=probe.classify_loader(types.SimpleNamespace(returncode=rc,stdout=text.encode()))
   if not value['pass']:raise ValueError('closed loader negative')
  check('actualselectedparser '+name,classify,want)
# Exact pre-private main actor gates, no grant reads.
for module,name in [(extract,'extract-selected.py'),(native,'validate-native.py'),(wrapper,'webkit-custom-exec.py')]:
 tree=ast.parse((P/name).read_text());main=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='main');first=main.body[0];code=compile(ast.Module(body=[first],type_ignores=[]),'selected actor','exec')
 for uid,gid,want in [(1000,1000,True),(0,1000,False),(1000,0,False)]:
  check('preprivate actor '+name+str((uid,gid)),lambda uid=uid,gid=gid:exec(code,{'os':types.SimpleNamespace(getuid=lambda:uid,getgid=lambda:gid)}),want)
def info(mode, uid, dev, ino, gid=1000, nlink=1):
    return types.SimpleNamespace(st_mode=mode, st_uid=uid, st_gid=gid, st_dev=dev, st_ino=ino, st_nlink=nlink)

class FakeOS:
    O_RDONLY = os.O_RDONLY
    O_WRONLY = os.O_WRONLY
    O_DIRECTORY = os.O_DIRECTORY
    O_NOFOLLOW = os.O_NOFOLLOW
    O_CLOEXEC = os.O_CLOEXEC
    O_CREAT = os.O_CREAT

    def __init__(self, table, swap=None):
        self.table = table
        self.fds = {}
        self.next = 10
        self.actions = []
        self.swap = swap

    def getuid(self):
        return 1000

    def getgid(self):
        return 1000

    def open(self, path, flags, mode=None, dir_fd=None):
        target = str(Path(self.fds[dir_fd][0]) / path) if dir_fd is not None else str(path)
        if self.swap == target:
            self.table[target] = info(stat.S_IFDIR | 448, 1000, 27, 8888)
            self.swap = None
        value = self.table.get(target)
        if value is None:
            if flags & os.O_CREAT:
                value = info(stat.S_IFREG | mode, 1000, 27, 9991)
                self.table[target] = value
                self.actions.append(('create', target))
            else:
                raise FileNotFoundError(target)
        if stat.S_ISLNK(value.st_mode):
            raise OSError(errno.ELOOP, 'mock nofollow')
        self.next += 1
        self.fds[self.next] = (target, copy.copy(value))
        return self.next

    def fstat(self, fd):
        return self.fds[fd][1]

    def stat(self, name, dir_fd=None, follow_symlinks=True):
        assert follow_symlinks is False
        target = str(Path(self.fds[dir_fd][0]) / name)
        if target not in self.table:
            raise FileNotFoundError(target)
        return self.table[target]

    def mkdir(self, name, mode, dir_fd=None):
        assert dir_fd is not None
        target = str(Path(self.fds[dir_fd][0]) / name)
        if target in self.table:
            raise FileExistsError(target)
        self.table[target] = info(stat.S_IFDIR | mode, 1000, 27, 9100 + len(self.actions))
        self.actions.append(('mkdir', target))

    def close(self, fd):
        self.fds.pop(fd)

    def ftruncate(self, fd, length):
        self.actions.append(('truncate', self.fds[fd][0]))

    def fdopen(self, fd, mode):
        outer = self

        class Stream:

            def __enter__(self):
                return self

            def write(self, value):
                outer.actions.append(('write', outer.fds[fd][0]))

            def __exit__(self, *args):
                outer.close(fd)
        return Stream()

# Complete output FD/ancestry mocked; no aliases, real mkdir or foreign writes.
anchors=json.loads((P/'runtime-anchors.safe.json').read_text())['anchors'];leaf=P/'runtime/native-test'
base={r['path']:info(stat.S_IFDIR|r['identity']['mode'],r['identity']['uid'],r['identity']['device'],r['identity']['inode'],r['identity']['gid']) for r in anchors}
base[str(P/'runtime')]=info(stat.S_IFDIR|0o700,1000,27,99001);base[str(leaf)]=info(stat.S_IFDIR|0o700,1000,27,99002)
def directory_case(table,create=False,swap=None,want=False):
 fake=FakeOS(copy.deepcopy(table),swap);obj=None;ok=False
 def ls(p):
  if str(p) not in fake.table:raise FileNotFoundError(str(p))
  return fake.table[str(p)]
 with patch.object(paths,'os',fake),patch.object(Path,'lstat',ls):
  try:obj=paths.Output(leaf,create=create);obj.save('public.safe.json',{'public':True},new=False);ok=True
  except (RuntimeError,OSError):pass
  finally:
   if obj:obj.close()
 assert ok==want
 if not want:assert not any(a[0] in ('write','truncate') for a in fake.actions)
 checks.append({'name':'selected nofollowOutput case','pass':True,'expected_accept':want,'actual_writes':False})
directory_case(base,want=True)
new=copy.deepcopy(base);new.pop(str(leaf));directory_case(new,create=True,want=True)
for path in [str(P),str(P/'runtime'),str(leaf)]:
 for item in [info(stat.S_IFLNK|0o777,1000,27,1),info(stat.S_IFDIR|0o700,999,27,1),info(stat.S_IFREG|0o600,1000,27,1)]:
  bad=copy.deepcopy(base);bad[path]=item;directory_case(bad)
directory_case(base,swap=str(P))
# Actualselected parent birth gate: no /proc read or native helper call.
tree=ast.parse((P/'native-probe.py').read_text());main=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='main');gate=next(n for n in main.body if isinstance(n,ast.If) and 'getppid' in ast.unparse(n.test));code=compile(ast.Module(body=[gate],type_ignores=[]),'selected parent birth','exec')
for pid,ticks,want in [(123,200,True),(999,200,False),(123,201,False)]:
 check('childparentbirth '+str((pid,ticks)),lambda pid=pid,ticks=ticks:exec(code,{'os':types.SimpleNamespace(getuid=lambda:1000,getgid=lambda:1000,getppid=lambda:123),'start_ticks':lambda pid:200,'args':types.SimpleNamespace(parent_pid=pid,parent_ticks=ticks)}),want)
(P/'caller-controls.safe.json').write_text(json.dumps({'status':'PASS_SELECTED_GRANT_PROOF_PARSER_ACTOR_PARENT_AND_DESCRIPTOR_CONTROLS','count':len(checks),'checks':checks,'actual_payload_nativeABI_dlopen_browser_or_children':False,'all_nativeprobe_and_FDpaths_mocked':True,'syntheticproof_not_runtimeauthority':True},indent=2)+'\n')
print(json.dumps({'selected_caller_controls':len(checks),'extraction_native_browser':False}))
