from pathlib import Path
import ast, hashlib, importlib.util, json, re, subprocess, sys
import yaml

sys.dont_write_bytecode = True
OWN = Path('/workspace/scratch/rct-validation/schedule_safe_fail_diagnostics_source')
WT = Path('/tmp/rct-schedule-safe-diagnostic-db177')
BASE = 'db177beeb9660f5a17d7fadf660e024e28f9f4b9'
ENV = {'PATH':'/usr/bin:/bin','LANG':'C','GIT_OPTIONAL_LOCKS':'0'}
PATHS = ['.github/workflows/coverage.yml','scripts/collect-ci-test-outcomes.py',
 'services/schedule-service/schedule-app/src/test/java/ru/rutcampustrack/schedule/integration/RecurringScheduleItemIT.java',
 'tests/harness/test_ci_test_outcomes.py']
def git(*args):
 return subprocess.run(['git','-C',str(WT),*args],env=ENV,capture_output=True,check=True,timeout=20).stdout
def sha(b): return hashlib.sha256(b).hexdigest()
old = {p:git('show',BASE+':'+p) for p in PATHS}
new = {p:(WT/p).read_bytes() for p in PATHS}
assert set(git('diff','--name-only').decode().splitlines()) == set(PATHS)
assert git('rev-parse','HEAD').decode().strip() == BASE
detached = subprocess.run(['git','-C',str(WT),'symbolic-ref','-q','HEAD'],env=ENV,capture_output=True,timeout=20).returncode == 1
assert detached
git('diff','--check')
t = new[PATHS[2]].decode()
helper = t[t.index('    private static String capFailureDiagnostic('):t.index('    private static void awaitBarrier(')]
restored = t.replace('import java.sql.SQLException;\n','').replace(helper,'').replace(
 '            Throwable capFailure = cap.get(10, TimeUnit.SECONDS);\n'
 '            assertThat(capFailure).withFailMessage(capFailureDiagnostic(capFailure)).isNull();',
 '            assertThat(cap.get(10, TimeUnit.SECONDS)).isNull();')
assert restored.encode() == old[PATHS[2]], 'CRITICAL_ORIGINAL_TEST_CHANGED'
assert sha(old[PATHS[2]]) == '155e101972daeec228def4dd5b89e1f405a21f24fbf6e1909e612e6418e74723'
before = yaml.load(old[PATHS[0]],Loader=yaml.BaseLoader)
after = yaml.load(new[PATHS[0]],Loader=yaml.BaseLoader)
steps = after['jobs']['java-coverage']['steps']
additions = [s for s in steps if s.get('name') in {'Collect safe coverage test outcomes','Upload safe coverage test outcomes'}]
assert len(additions)==2 and all(s.get('if')=='always()' for s in additions)
assert 'continue-on-error' not in str(after)
run = next(s for s in steps if s.get('name')=='Run tests with coverage')
assert run.pop('id')=='coverage-tests'
after['jobs']['java-coverage']['steps'] = [s for s in steps if s not in additions]
assert before==after, 'UNRELATED_WORKFLOW_CHANGE'
spec=importlib.util.spec_from_file_location('current_safe_collector',WT/PATHS[1]); module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
assert module.java_test_declarations(old[PATHS[2]].decode()) == module.java_test_declarations(t)
maps=dict(re.findall(r'case "([A-Za-z0-9_.]+)"\s*->\s*"([A-Za-z0-9_]+)";',helper))
assert set(maps.values()) == set(module.CAP_FAILURE_CLASSES)-{'OTHER'}
assert all('"'+s+'"' in helper for s in module.CAP_SQL_STATES)
assert 'cause != null && depth < 16' in helper and 'failure.getClass().getName()' in helper
assert '.toString(' not in helper and 'getMessage()' in helper
assert '"bounded coordination barrier timed out".equals(cause.getMessage())' in helper
assert '"bounded coordination barrier interrupted".equals(cause.getMessage())' in helper
# Finite source-derived model controls; this does NOT execute Java or validate bytecode/API.
def model(classname,chain):
 sql='NONE';barrier='NOT_OBSERVED'
 for c in chain[:16]:
  if c.get('sql') is not None and sql=='NONE':sql=c['sql'] if c['sql'] in module.CAP_SQL_STATES else 'OTHER'
  if c.get('assertion'):
   if c.get('message')=='bounded coordination barrier timed out':barrier='TIMED_OUT'
   elif c.get('message')=='bounded coordination barrier interrupted':barrier='INTERRUPTED'
 return f"CAP_FUTURE_DIAGNOSTIC_V1 class={maps.get(classname,'OTHER')} sqlState={sql} barrier={barrier}"
controls=[]
for name,cls,chain,expected in [
 ('database_deadlock','org.springframework.dao.CannotAcquireLockException',[{'sql':'40P01'}],('CannotAcquireLockException','40P01','NOT_OBSERVED')),
 ('barrier_timeout','java.lang.AssertionError',[{'assertion':True,'message':'bounded coordination barrier timed out'}],('AssertionError','NONE','TIMED_OUT')),
 ('barrier_interrupt','java.lang.AssertionError',[{'assertion':True,'message':'bounded coordination barrier interrupted'}],('AssertionError','NONE','INTERRUPTED')),
 ('unknown_class_and_private_values','synthetic.CREDENTIAL_SENTINEL',[{'sql':'CREDENTIAL_SENTINEL','assertion':True,'message':'CREDENTIAL_SENTINEL'}],('OTHER','OTHER','NOT_OBSERVED')),
 ('bounded_chain','java.lang.AssertionError',[{}]*16+[{'sql':'40P01'}],('AssertionError','NONE','NOT_OBSERVED')),
]:
 result=model(cls,chain);match=module.CAP_MARKER.fullmatch(result);assert match and match.groups()==expected and 'CREDENTIAL_SENTINEL' not in result
 controls.append({'name':name,'result':'PASS_SOURCE_MODEL_ONLY'})
for p in PATHS[1],PATHS[3]:ast.parse(new[p])
ledger=[]
for p in PATHS:
 s=(WT/p).lstat();assert (s.st_mode & 0o170000)==0o100000 and s.st_nlink==1
 ledger.append({'path':p,'before_sha256':sha(old[p]),'after_sha256':sha(new[p]),'before_bytes':len(old[p]),'after_bytes':len(new[p]),'mode':oct(s.st_mode & 0o777),'nlink':s.st_nlink})
size=sum(p.lstat().st_size for p in WT.rglob('*') if p.is_file())
assert size<=256*1024**2
report={'verdict':'AUTHOR_SOURCE_CHECKED_PENDING_INDEPENDENT_REVIEW','base':BASE,'tracked_diff_paths':4,
 'original_test_exact_after_removing_only_diagnostic':True,'all_original_assertions_fixture_waits_executor_unchanged':True,
 'workflow_original_exact_after_removing_only2always_steps_and_step_id':True,'triggers_gates_other_jobs_unchanged':True,
 'test_declarations_exact':True,'Java_emitter_and_Python_whitelists_match':True,'pure_source_model_controls':controls,
 'sparse_source_logical_bytes':size,'source_tree_cap_bytes':256*1024**2,'detached':detached,'files':ledger,
 'Java_compile_formatter_native_test':'NOT_RUN','raw_JUnit_upload_added':False,'history_underlying_cause':'UNKNOWN',
 'runtime_grant':False,'actual_model_effort':'UNKNOWN','requested_model_effort':'gpt-6.1-sol/high'}
p=OWN/'source-checks.safe.json';p.write_text(json.dumps(report,indent=2)+'\n');p.chmod(0o600)
(OWN/'source-delta.patch').write_bytes(git('diff','--binary','--',*PATHS));(OWN/'source-delta.patch').chmod(0o600)
print(json.dumps({'changed_paths':4,'workflow_and_original_test_equivalence':True,'pure_source_model_controls':len(controls),'source_bytes':size,'runtime':False}))
