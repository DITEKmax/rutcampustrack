"""Bounded Debian public archive/header inspection. Never extracts or executes."""
import io
import lzma
import posixpath
import re
import tarfile
import zlib

ARCHIVE_CAP = 8388608
TAR_CAP = 50331648
HEADER_CAP = 20000
NAME_BYTES_CAP = 4194304

def ar_members(blob):
    if len(blob) > ARCHIVE_CAP or not blob.startswith(b'!<arch>\n'):
        raise ValueError('Bounded Debian ar magic required')
    offset = 8
    members = {}
    while offset < len(blob):
        header = blob[offset:offset+60]
        if len(header) != 60 or header[58:60] != b'`\n':
            raise ValueError('Exact ar header required')
        name = header[:16].decode('ascii').strip().removesuffix('/')
        if name not in {'debian-binary','control.tar','control.tar.gz','control.tar.xz','data.tar','data.tar.gz','data.tar.xz'} or name in members:
            raise ValueError('Unsupported or duplicate Debian ar member')
        numeric = header[48:58].decode('ascii').strip()
        if not re.fullmatch(r'[0-9]{1,10}', numeric):
            raise ValueError('Bounded ar length required')
        size = int(numeric)
        start = offset + 60
        if size > ARCHIVE_CAP or start+size > len(blob):
            raise ValueError('Ar size exceeds signed archive boundary')
        members[name] = blob[start:start+size]
        if size % 2 and blob[start+size:start+size+1] != b'\n':
            raise ValueError('Exact ar alignment padding required')
        offset = start + size + (size % 2)
    if offset != len(blob) or members.get('debian-binary') != b'2.0\n':
        raise ValueError('Exact Debian ar format required')
    controls = [n for n in members if n.startswith('control.tar')]
    data = [n for n in members if n.startswith('data.tar')]
    if len(members) != 3 or len(controls) != 1 or len(data) != 1:
        raise ValueError('One control and one data tar required')
    return members, controls[0], data[0]

def tar_bytes(name, body, cap=TAR_CAP):
    if name.endswith('.xz'):
        decoder = lzma.LZMADecompressor(memlimit=33554432)
        raw = decoder.decompress(body, max_length=cap+1)
        if not decoder.eof or decoder.unused_data:
            raise ValueError('Bounded single xz tar stream required')
    elif name.endswith('.gz'):
        decoder = zlib.decompressobj(31)
        raw = decoder.decompress(body, cap+1)
        if not decoder.eof or decoder.unused_data:
            raise ValueError('Bounded single gzip tar stream required')
    elif name.endswith('.tar'):
        raw = body
    else:
        raise ValueError('Archive compression requires separate source disposition')
    if len(raw) > cap:
        raise ValueError('Tar decompression cap exceeded')
    return raw

def clean_name(raw, directory=False):
    if not isinstance(raw, str) or len(raw.encode('utf-8')) > 8192 or '\x00' in raw or '\\' in raw or raw.startswith('/'):
        raise ValueError('Bounded lexical relative tar name required')
    while raw.startswith('./'):
        raw = raw[2:]
    raw = raw.rstrip('/')
    if raw in ('', '.'):
        if directory:
            return '.'
        raise ValueError('Regular member needs nonroot name')
    parts = raw.split('/')
    if any(part in ('','.', '..') for part in parts) or re.match(r'^[A-Za-z]:',raw):
        raise ValueError('Tar traversal or ambiguous name denied')
    if parts[0] in {'etc','root','home','proc','sys','dev','tmp','var'} or any(p in {'.ssh','.aws','.codex','.env'} for p in parts):
        raise ValueError('Private/system target scope denied')
    return raw

def link_disposition(name, target, hard=False):
    if not isinstance(target,str) or not target or len(target.encode('utf-8')) > 8192 or '\x00' in target or '\\' in target:
        raise ValueError('Bounded public link metadata required')
    documentation = name.startswith(('usr/share/doc/','usr/share/man/'))
    if target.startswith('/'):
        if documentation:
            return {'class':'DOCUMENTATION_ABSOLUTE_EXTERNAL_LINK_HEADER_ONLY','future':'OMIT_LINK_UNLESS_SEPARATE_REVIEWED_SAFE_REPRESENTATION','target':target}
        raise ValueError('Absolute runtime link target denied')
    resolved = posixpath.normpath(target if hard else posixpath.join(posixpath.dirname(name),target))
    if resolved in ('','.', '..') or resolved.startswith('../') or resolved.startswith('/') or re.match(r'^[A-Za-z]:',resolved):
        if documentation:
            return {'class':'DOCUMENTATION_ESCAPE_LINK_HEADER_ONLY','future':'OMIT_LINK_UNLESS_SEPARATE_REVIEWED_SAFE_REPRESENTATION','target':target}
        raise ValueError('Runtime link escapes future prefix')
    clean_name(resolved)
    return {'class':'RELATIVE_CONTAINED_LINK_REQUIRES_TARGET_CHAIN_REVIEW','future':'NEVER_FOLLOW_DURING_HEADERS; VALIDATE_TARGET_GRAPH_BEFORE_EXTRACTION','target':target,'normalized_target':resolved,'hardlink':hard}

def inspect_tar(raw, scope):
    rows=[]
    seen={}
    name_bytes=0
    regular_bytes=0
    with tarfile.open(fileobj=io.BytesIO(raw),mode='r:') as archive:
        for member in archive:
            if len(rows)>=HEADER_CAP or member.issparse() or member.size<0 or member.size>TAR_CAP:
                raise ValueError('Bounded nonsparse public header required')
            name=clean_name(member.name,member.isdir())
            if name in seen:
                raise ValueError('Duplicate effective header path denied')
            if member.mode & 0o6000 or (member.mode & 0o002 and not member.issym()):
                raise ValueError('Setid/world-writable package member denied')
            if member.isreg():kind='regular'
            elif member.isdir():kind='directory'
            elif member.issym():kind='symlink'
            elif member.islnk():kind='hardlink'
            else:raise ValueError('Device/FIFO/special package member denied')
            if member.uid<0 or member.gid<0 or member.uid>4294967295 or member.gid>4294967295:
                raise ValueError('Bounded public package UID/GID metadata required')
            row={'name':name,'kind':kind,'mode':member.mode,'declared_bytes':member.size,'archive_uid':member.uid,'archive_gid':member.gid}
            name_bytes += len(name.encode('utf-8'))
            if kind in ('symlink','hardlink'):
                row['link']=link_disposition(name,member.linkname,kind=='hardlink')
                name_bytes+=len(member.linkname.encode('utf-8'))
            if kind=='regular':regular_bytes+=member.size
            if name_bytes>NAME_BYTES_CAP or regular_bytes>TAR_CAP:
                raise ValueError('Header metadata/logical byte cap exceeded')
            if scope=='control':row['execution']='NEVER_EXECUTE_CONTROL_SCRIPTS_HOOKS_TRIGGERS'
            seen[name]=row
            rows.append(row)
    links={r['name'] for r in rows if r['kind'] in ('symlink','hardlink')}
    for row in rows:
        parents=row['name'].split('/')[:-1]
        if any('/'.join(parents[:i]) in links for i in range(1,len(parents)+1)):
            raise ValueError('Member has link ancestor; no automatic extraction')
    return {'scope':scope,'rows':rows,'header_count':len(rows),'regular_declared_bytes':regular_bytes,'logical_tar_stream_bytes':len(raw),'type_counts':{k:sum(r['kind']==k for r in rows) for k in ['regular','directory','symlink','hardlink']},'regular_contents_not_interpreted_published_or_extracted':True}

def inspect_deb(blob):
    members,control,data=ar_members(blob)
    return {'ar_member_names':list(members),'control':inspect_tar(tar_bytes(control,members[control],1048576),'control'),'data':inspect_tar(tar_bytes(data,members[data]),'data'),'extract_or_execute':False}
