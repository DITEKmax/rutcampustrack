"""Pure selected actual AST; synthetic read errors, no real /proc or signals."""
import ast
import errno
import hashlib
import json
from pathlib import Path

OWN = Path(__file__).parent
OLD = Path('/workspace/scratch/rct-validation/current_artifact_corrections_v2/bounded-child.py')
NEW = OWN / 'bounded-child.py'


def raw(pid, parent, group, session, ticks, state='S'):
    # /proc field22=starttime; comm contains spaces and a closing parenthesis.
    fields = [state, str(parent), str(group), str(session)] + ['0'] * 15 + [str(ticks)]
    return str(pid) + ' (synthetic name ) inner) ' + ' '.join(fields)


class Entry:
    def __init__(self, name, text='', error=None):
        self.name = name
        self.text = text
        self.error = error
        self.reads = 0

    def __truediv__(self, name):
        assert name == 'stat'
        return self

    def read_text(self):
        self.reads += 1
        if self.error is not None:
            raise self.error
        return self.text


class Proc:
    def __init__(self, entries):
        self.entries = entries

    def iterdir(self):
        return iter(self.entries)


def reader(path, entries):
    def fake_path(name):
        assert name == '/proc'
        return Proc(entries)

    tree = ast.parse(path.read_text())
    function = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == 'process_table')
    namespace = {'Path': fake_path, 'errno': errno}
    exec(compile(ast.Module(body=[function], type_ignores=[]), str(path), 'exec'), namespace)
    return namespace['process_table']


def entries(failure=None):
    return [Entry('self', error=AssertionError('Non-numeric entry must never be read')),
            Entry('100', raw(100, 200, 100, 100, 10)),
            Entry('999', raw(999, 999, 100, 100, 99), failure),
            Entry('300', raw(300, 100, 300, 300, 12)),
            Entry('400', raw(400, 200, 400, 400, 15, 'Z'))]


outcomes = []
baseline = reader(NEW, entries())()
assert set(baseline) == {100, 999, 300, 400}
assert baseline[100] == {'pid': 100, 'state': 'S', 'ppid': 200, 'pgrp': 100, 'session': 100, 'start_ticks': 10}
assert baseline[300]['start_ticks'] == 12 and baseline[400]['state'] == 'Z'
outcomes.append({'case': 'actual parse positive including spaces/comm parentheses/Z and all birth fields', 'status': 'PASS'})

for number in (errno.ENOENT, errno.ESRCH):
    old_failure = OSError(number, 'synthetic disappearance only')
    old_rows = entries(old_failure)
    if number == errno.ESRCH:
        try:
            reader(OLD, old_rows)()
        except ProcessLookupError as caught:
            assert caught is old_failure and caught.errno == errno.ESRCH
            old_observed = {'type': type(caught).__name__, 'errno': caught.errno, 'specifically_failed': True}
        else:
            raise AssertionError('Original ESRCH counterexample did not fail specifically')
    else:
        assert set(reader(OLD, old_rows)()) == {100, 300, 400}
        old_observed = {'original_behavior': 'ENOENT already omitted only missing row'}
    new_rows = entries(OSError(number, 'synthetic disappearance only'))
    actual = reader(NEW, new_rows)()
    assert actual == {pid: row for pid, row in baseline.items() if pid != 999}
    assert new_rows[0].reads == 0
    outcomes.append({'case': 'gone stat read', 'injected_errno': number, 'original': old_observed,
                     'corrected': 'omit999only; preserve100/300/400 all parsed fields', 'status': 'PASS'})

for number in (errno.EPERM, errno.EACCES, errno.EIO, errno.EINVAL, errno.EBADF):
    for source in (OLD, NEW):
        failure = OSError(number, 'synthetic unexpected read failure')
        try:
            reader(source, entries(failure))()
        except OSError as caught:
            assert caught is failure and caught.errno == number
        else:
            raise AssertionError('Unexpected OS error swallowed')
    outcomes.append({'case': 'unexpected errno failclosed both original/corrected', 'errno': number, 'status': 'PASS'})

for failure in (RuntimeError('synthetic reader failure'), FileNotFoundError('missing errno must not be broadly swallowed')):
    try:
        reader(NEW, entries(failure))()
    except BaseException as caught:
        assert caught is failure
    else:
        raise AssertionError('Unknown failure swallowed')
    outcomes.append({'case': 'unexpected type/unknown errno propagated unchanged', 'type': type(failure).__name__, 'status': 'PASS'})

for malformed in ('no closing comm parenthesis', raw(100, 'not_numeric', 100, 100, 10)):
    try:
        reader(NEW, [Entry('100', malformed)])()
    except (IndexError, ValueError):
        pass
    else:
        raise AssertionError('Malformed identity accepted')
    outcomes.append({'case': 'malformed parse failclosed', 'status': 'PASS'})

functions = {}
tree = ast.parse(NEW.read_text())
selected = [n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name in {'owned_records', 'remember_identities'}]
exec(compile(ast.Module(body=selected, type_ignores=[]), str(NEW), 'exec'), functions)
known = {100: 10}
owned = functions['owned_records'](baseline, 200, 100, known)
assert set(owned) == {100, 300, 400}  # Same numeric group999 remains foreign.
functions['remember_identities'](owned, known)
assert known == {100: 10, 300: 12, 400: 15}
reused = {100: dict(baseline[100], start_ticks=20)}
assert functions['owned_records'](reused, 200, 100, known) == {}
outcomes.append({'case': 'parsed table fullowned ancestry/adoptedZ; numericforeign rejected/birthreuse denied', 'status': 'PASS'})

result = {'status': 'PURE_SELECTED_ACTUAL_AST_NATIVE0', 'original_guard_sha256': hashlib.sha256(OLD.read_bytes()).hexdigest(),
          'new_guard_sha256': hashlib.sha256(NEW.read_bytes()).hexdigest(), 'cases': outcomes,
          'actual_historical_runtime_errno_frame': 'UNKNOWN; only ProcessLookupError was retained',
          'synthetic_ESRCH_errno3_is_not_a_recorded_historical_errno': True,
          'actual_proc_reads': 0, 'actual_signals': 0, 'actual_children': 0, 'new_guard_runtime': 'NOT_RUN'}
(OWN / 'proc-race-controls-result.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({'status': result['status'], 'cases': len(outcomes), 'original_ESRCH_specific_red': True,
                  'new_ENOENT_ESRCH_omit_only_gone_row': True, 'unexpected_failclosed': True, 'actual_children_signals_proc_reads': 0}))
