import pathlib,json,runpy,resource
resource.setrlimit(resource.RLIMIT_CORE,(0,0))
S=pathlib.Path(__file__).parent
x=runpy.run_path(str(S/'native-helper512.py'))
y=runpy.run_path(str(S/'native-helper1024.py'))
R=x['R'];F=R/'frontends';NODE=x['NODE'];results=[]
source_before={p:x['row'](p) for p in x['git']('ls-files','-z').split('\0') if p and not p.startswith(('.agent/','.agents/','.codex/'))}
results.append(x['check']('native-combined-format-check',[NODE,'scripts/format-authored.mjs','prettier','--check'],timeout=300))
for pkg,args in [('mobile-core',['src','scripts','tests']),('pwa-vue',['src','vite.config.ts']),('tma-vue',['src','vite.config.ts'])]:
 results.append(x['check']('native-'+pkg+'-lint',[NODE,str(F/'node_modules/eslint/bin/eslint.js'),*args,'--max-warnings=0'],F/pkg,300))
for pkg in ['pwa-vue','tma-vue']:
 results.append(y['check']('native-'+pkg+'-typecheck1024',[NODE,str(F/'node_modules/vue-tsc/bin/vue-tsc.js'),'-p','tsconfig.json','--noEmit'],F/pkg,300))
changed=[p for p,b in source_before.items() if x['row'](p)!=b]
x['save']('native-final-summary.safe.json',{'results':results,'tracked_non_agent_source_changes':changed,
 'candidate127':'actual-candidate-equality.safe.json','original_meaning':'block-pipeline-probe.safe.json',
 'java_jvm':'NOT_RUN','lease':'RELEASED','remaining_owned_pids':sorted({p for r in results for p in r['remaining_owned_pids']})})
x['save']('CURRENT.json',{'status':'RELEASED','type_1024_lease':'RELEASED','all_native_complete':True})
assert all(r['native_exit']==0 for r in results) and not changed
print('ALL_NODE_LEASE_RELEASED',flush=True)
