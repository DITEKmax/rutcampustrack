"""Independent source seals/reverse and RAM-only collector controls. No native Java/XML reads."""
import ast,copy,hashlib,io,json,re,stat,subprocess
from pathlib import Path,PurePosixPath
from xml.etree import ElementTree as ET
import yaml

HERE=Path(__file__).parent
PACK=HERE.parent/'schedule_safe_fail_diagnostics_source'
ROOT=Path('/workspace/rutcampustrack')
checks=[]
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def passed(s):checks.append(s)
assert sha(PACK/'manifest.safe.json')=='9cafda102559d0f2b062fc0bfda816611d331121cee8e5c75a3412c761a0d3c9'
m=json.loads((PACK/'manifest.safe.json').read_text())
for r in m['files']:
 p=Path(r['path']);assert p.stat().st_size==r['bytes'] and sha(p)==r['sha256'] and not p.is_symlink()
passed('all13_sealed_source_and_proof_hashes')
import zipfile
zpath=PACK/'safe-source-package.zip'
assert sha(zpath)=='1628de2fef1f4d3eaadcd9444dc3fe75155bb3a1f9301e497d55deb3d68a59b8'
entries={r['relative_path']:Path(r['path']).read_bytes() for r in m['files']}
entries['manifest.safe.json']=(PACK/'manifest.safe.json').read_bytes()
with zipfile.ZipFile(zpath) as z:
 assert len(z.infolist())==len(set(z.namelist()))==14 and z.testzip() is None
 for info in z.infolist():
  p=PurePosixPath(info.filename);assert not p.is_absolute() and '..' not in p.parts and str(p)==info.filename
  assert stat.S_IFMT(info.external_attr>>16) in (0,stat.S_IFREG)
  assert z.read(info)==entries[info.filename]
passed('ZIP14_canonical_unique_CRC_exact_contents')
assigned=[r for r in m['files'] if r['kind']=='ASSIGNED_SOURCE']
assert len(assigned)==4
original={}
for r in assigned:
 content=subprocess.run(['/usr/bin/git','-C',str(ROOT),'show',m['base']+':'+r['repo_path']],env={'PATH':'/usr/bin:/bin','LANG':'C.UTF-8','GIT_OPTIONAL_LOCKS':'0'},stdout=subprocess.PIPE,stderr=subprocess.DEVNULL,check=True,timeout=30).stdout
 assert hashlib.sha256(content).hexdigest()==r['before_sha256']
 assert sha(ROOT/r['repo_path'])==r['before_sha256']
 original[r['repo_path']]=content
passed('all4_original_db177_Git_blobs_and_Root_unchanged')
paths={r['repo_path']:Path(r['path']) for r in assigned}
java=next(p for p in paths if p.endswith('RecurringScheduleItemIT.java'))
text=paths[java].read_text()
helper=text[text.index('    private static String capFailureDiagnostic('):text.index('    private static void awaitBarrier(')]
restored=text.replace('import java.sql.SQLException;\n','').replace(helper,'').replace('            Throwable capFailure = cap.get(10, TimeUnit.SECONDS);\n            assertThat(capFailure).withFailMessage(capFailureDiagnostic(capFailure)).isNull();','            assertThat(cap.get(10, TimeUnit.SECONDS)).isNull();')
assert restored.encode()==original[java]
passed('FULL_Java_reverse_exact_original108281B_all_fixture_assertions_waits_executor')
assert 'cause != null && depth < 16' in helper and '.toString(' not in helper
assert helper.count('getMessage()')==2 and 'sql.getSQLState()' in helper
passed('Java_output_finite_codes_bounded_cause_chain_no_Throwable_render')
before=yaml.load(original['.github/workflows/coverage.yml'],Loader=yaml.BaseLoader)
after=yaml.load(paths['.github/workflows/coverage.yml'].read_text(),Loader=yaml.BaseLoader)
steps=after['jobs']['java-coverage']['steps'];extra=[s for s in steps if s.get('name') in ['Collect safe coverage test outcomes','Upload safe coverage test outcomes']]
assert len(extra)==2 and all(s['if']=='always()' for s in extra)
assert next(s for s in steps if s.get('name')=='Run tests with coverage').pop('id')=='coverage-tests'
after['jobs']['java-coverage']['steps']=[s for s in steps if s not in extra]
assert before==after and 'continue-on-error' not in str(after)
assert extra[1]['with']['path'].endswith('/*/safe-outcomes.json')
passed('workflow_reverse_exact_original_gates_command_triggers_matrix_otherjobs_no_raw_JUnit')
wtext=paths['.github/workflows/coverage.yml'].read_text()
block=wtext[wtext.index('      - name: Collect safe coverage test outcomes\n'):wtext.index('      - name: Summarize JaCoCo report\n')]
assert wtext.replace(block,'').replace('        id: coverage-tests\n','').encode()==original['.github/workflows/coverage.yml']
passed('FULL_workflow_byte_reverse_exact9448B')
htree=ast.parse(paths['tests/harness/test_ci_test_outcomes.py'].read_text())
added={'schedule_fixture','collect_schedule','test_coverage_retains_target_fail_and_only_closed_diagnostic','test_cap_marker_unknown_values_and_conflicts_remain_unknown_without_leaks','test_barrier_marker_stack_header_fallback_and_other_case_isolation','test_cap_diagnostic_requires_source_identity_failed_status_and_selected_task','test_bounded_xml_read_never_hashes_truncated_carrier'}
for n in htree.body:
 if isinstance(n,ast.ClassDef):n.body=[x for x in n.body if not isinstance(x,ast.FunctionDef) or x.name not in added]
assert ast.dump(htree,include_attributes=False)==ast.dump(ast.parse(original['tests/harness/test_ci_test_outcomes.py']),include_attributes=False)
passed('all_original_harness_AST_controls_unchanged_after_removing7_additions')

tree=ast.parse(paths['scripts/collect-ci-test-outcomes.py'].read_text())
constants={'MODULES','CAP_CLASS','CAP_METHOD','CAP_FAILURE_CLASSES','CAP_SQL_STATES','CAP_MARKER','MAX_XML_BYTES'}
function_names={'number','cap_failure_diagnostic','collect','java_test_declarations'}
nodes=[n for n in tree.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id in constants for t in n.targets) or isinstance(n,ast.FunctionDef) and n.name in function_names]
g={'re':re,'Path':Path,'hashlib':hashlib,'ElementTree':ET,'IDENTIFIER':re.compile(r'[A-Za-z_$][A-Za-z0-9_$]*\Z'),'TEST_ANNOTATIONS':{'Test','ParameterizedTest','RepeatedTest','TestFactory','TestTemplate'}}
exec(compile(ast.Module(body=nodes,type_ignores=[]),'<selected pure collector>','exec'),g)
classes=dict(re.findall(r'case "([A-Za-z0-9_.]+)"\s*->\s*"([A-Za-z0-9_]+)";',helper))
assert set(classes.values())==set(g['CAP_FAILURE_CLASSES'])-{'OTHER'}
assert all('"'+s+'"' in helper for s in g['CAP_SQL_STATES'])
assert g['java_test_declarations'](text)==g['java_test_declarations'](original[java].decode())
passed('actual_Java_Python_code_whitelists_and_all_test_declarations_match')

secret='RCT_SYNTHETIC_REVIEW_DO_NOT_EMIT_98217'
good='CAP_FUTURE_DIAGNOSTIC_V1 class=AssertionError sqlState=NONE barrier=TIMED_OUT'
state={'cases':[],'raw':None,'present':True}
class VirtualPath(PurePosixPath):
 def glob(self,pattern):return [self/'TEST-virtual.xml'] if state['present'] else []
 def open(self,mode):assert mode=='rb';return io.BytesIO(state['raw'])
def carrier(cases):
 suite=ET.Element('testsuite',tests=str(len(cases)),failures=str(sum(any(c.tag=='failure' for c in x) for x in cases)),errors=str(sum(any(c.tag=='error' for c in x) for x in cases)),skipped='0',name=secret)
 for case in cases:suite.append(case)
 ET.SubElement(suite,'system-out').text=secret
 state['raw']=ET.tostring(suite)
def case(method=None,status='failure',message=good,text=secret):
 c=ET.Element('testcase',classname=g['CAP_CLASS'],name=(method or g['CAP_METHOD'])+'()')
 if status!='pass':ET.SubElement(c,status,message=message).text=text
 return c
registry={g['CAP_CLASS']:{'methods':{g['CAP_METHOD'],'otherBoundary'},'source':java,'sha256':sha(paths[java])}}
g['source_registry']=lambda *args:registry
g['metadata']=lambda *args:{'job':'java-coverage','testStepScope':'unit+integration+report','testStepOutcome':'failure'}
g['unlinked_scoped_path']=lambda *args:True
def report():
 r=g['collect'](VirtualPath('/VIRTUAL_NO_FS_ACCESS'),'schedule-service','integrationTest',{})
 assert secret not in json.dumps(r) and r['acceptance']=='NOT_ASSESSED'
 return r
carrier([case()]);r=report();assert r['cases'][0]['failureDiagnostic']['stage']=='AWAIT_BARRIER' and r['summary']['FAILED']==1
passed('RAM_target_failure_closed_marker_private_text_systemout_suppressed')
carrier([case(method='otherBoundary'),case(status='pass'),case(status='error')]);r=report();assert all('failureDiagnostic' not in c for c in r['cases'])
passed('RAM_other_case_pass_error_no_causal_marker')
carrier([case(message=good,text=good.replace('TIMED_OUT','INTERRUPTED'))]);r=report();assert r['cases'][0]['failureDiagnostic']['stage']=='UNKNOWN'
passed('RAM_conflicting_complete_markers_UNKNOWN')
carrier([case(message=good+secret,text=secret)]);r=report();assert r['cases'][0]['failureDiagnostic']['stage']=='UNKNOWN'
passed('RAM_malformed_marker_UNKNOWN_without_privacy_leak')
state['present']=False;r=report();assert r['collection']=='NO_RESULTS' and all(v==0 for v in r['summary'].values())
passed('RAM_missing_results_NOT_PASS_even_aggregate_failure')
state['present']=True;carrier([case()]);limit=g['MAX_XML_BYTES'];g['MAX_XML_BYTES']=8;r=report();g['MAX_XML_BYTES']=limit
assert r['xml'][0]['sha256'] is None and r['collection']=='UNINSPECTABLE_RESULTS'
passed('RAM_oversized_pre_read_bounded_NULL_SHA_not_prefixhash')

# Exact cutoff counterexample: a whole malformed line becomes a valid truncated marker.
bad=' '*(2048-len(good))+good+secret
assert g['CAP_MARKER'].fullmatch(bad.strip()) is None
carrier([case(message='',text=bad)]);r=report();diagnostic=r['cases'][0]['failureDiagnostic']
assert diagnostic['state']=='CLOSED_MARKER' and diagnostic['stage']=='AWAIT_BARRIER'
passed('P2_cutoff_malformed_full_line_FALSE_CLOSED_MARKER_reproduced_RAM')

# Relevant wrong-case mutation is detected by original meaningful case-isolation oracle.
mutated=copy.deepcopy(next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='collect'))
class WrongCase(ast.NodeTransformer):
 def visit_Compare(self,node):
  if isinstance(node.left,ast.Name) and node.left.id=='method' and any(isinstance(c,ast.Name) and c.id=='CAP_METHOD' for c in node.comparators):return ast.copy_location(ast.Constant(True),node)
  return self.generic_visit(node)
mutated=ast.fix_missing_locations(WrongCase().visit(mutated));mg=dict(g)
exec(compile(ast.Module(body=[mutated],type_ignores=[]),'<RAM wrongcase mutation>','exec'),mg)
carrier([case(method='otherBoundary')]);mr=mg['collect'](VirtualPath('/VIRTUAL_NO_FS_ACCESS'),'schedule-service','integrationTest',{})
assert 'failureDiagnostic' in mr['cases'][0]
passed('RAM_wrongcase_guard_mutation_killed_by_case_isolation_oracle')
pure_source=paths['tests/harness/test_ci_test_outcomes.py'].read_text()
assert 'self.assertNotIn(MARKER, json.dumps(report))' in pure_source
assert 'self.assertNotIn("failureDiagnostic", report["cases"][1])' in pure_source
passed('author_negative_privacy_case_controls_material_mutation_sensitive')

out={'verdict':'CHANGES_REQUESTED','finding':{'id':'SCD-MARKER-CUTOFF-001','priority':2,'file':str(paths['scripts/collect-ci-test-outcomes.py']),'line':206,'scope':'full failure.text line truncated before fullmatch gives false CLOSED_MARKER/AWAIT_BARRIER; rawtail not exported'},'checks':checks,'checks_count':len(checks),'source_manifest_sha256':sha(PACK/'manifest.safe.json'),'private_XML_or_log_reads':0,'nativeJava_build_test_DB_API':False,'target_top_level_imports':0,'RAM_mutations':'isolated AST only, original source unchanged','requested_selected_model':'gpt-6.1-sol/high','actual_model_effort':'UNKNOWN','historic_96_failure_cause':'UNKNOWN'}
(HERE/'checks.safe.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({'verdict':out['verdict'],'checks':len(checks),'findings':1,'native':False}))
