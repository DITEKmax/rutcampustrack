"""Pure return-variable controls; no native Nginx/HTTP assertion."""
import hashlib
import json
from pathlib import Path
import re
import yaml

OWN = Path(__file__).parent
BASE = OWN.parent / 'current_host_config_v5'

def literal_return(text, prefix):
    return re.search(r'location = /' + prefix + r' \{ return 301 ([^;]+); \}', text).group(1)

def evaluate_selected_return(text, prefix, args):
    expression = literal_return(text, prefix)
    return expression.replace('$is_args', '?' if args else '').replace('$args', args)

def main():
    old = (BASE / 'edge-default.conf').read_text()
    new = (OWN / 'edge-default.conf').read_text()
    reversed_new = new.replace('/app/$is_args$args;', '/app/;').replace('/mini-app/$is_args$args;', '/mini-app/;')
    assert old == reversed_new
    cases = []
    for prefix in ['app', 'mini-app']:
        for args in ['', 'recovery=synthetic-marker', 'next=%2Fapp%2Fprofile&mode=read', 'key=one&key=two', 'empty=&flag', 'v=%23fragment%26x%3D1']:
            expected = '/' + prefix + '/' + ('?' + args if args else '')
            before = evaluate_selected_return(old, prefix, args)
            after = evaluate_selected_return(new, prefix, args)
            assert after == expected
            assert (before == expected) is (args == '')
            cases.append({'prefix': prefix, 'synthetic_args': args, 'before': before, 'expected': expected,
                          'after': after, 'old_rejects_or_nonquery_preserves': (before != expected) if args else before == expected,
                          'new_preserves': True})
    base = yaml.safe_load((BASE / 'data-renderer-edge.compose.yml').read_text())
    overlay = yaml.safe_load((OWN / 'edge-overlay.compose.yml').read_text())
    assert set(overlay) == {'services'} and set(overlay['services']) == {'nginx'}
    assert set(overlay['services']['nginx']) == {'volumes'}
    selected = overlay['services']['nginx']['volumes']
    assert len(selected) == 1 and selected[0]['target'] == '/etc/nginx/conf.d/default.conf'
    assert selected[0]['source'] == str(OWN / 'edge-default.conf')
    assert selected[0]['read_only'] is True and selected[0]['bind']['create_host_path'] is False
    # Native Compose merges volume sequence entries by unique container target.
    merged = {mount['target']: mount for mount in base['services']['nginx']['volumes']}
    original = dict(merged)
    merged.update({mount['target']: mount for mount in selected})
    assert len(merged) == 5
    assert [name for name in merged if merged[name] != original[name]] == ['/etc/nginx/conf.d/default.conf']
    manifest = json.loads((BASE / 'launch-manifest.json').read_text())
    unchanged = all(hashlib.sha256(Path(row['path']).read_bytes()).hexdigest() == row['sha256'] for row in manifest['files'])
    assert unchanged
    result = {'status': 'PASS_SOURCE_ONLY', 'cases': cases, 'two_redirect_suffixes_only': old == reversed_new,
              'all_original_41_files_unchanged': unchanged, 'private_inputs_read_or_changed': False,
              'overlay_only_default_conf_target': True, 'runtime': 'NOT_RUN',
              'limitation': 'Selected Nginx variable expression modeled in pure Python. Native location redirect status/origin/query must be verified after new grant.'}
    (OWN / 'validation.safe.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({'query_cases': len(cases), 'red_old_query_cases': 10, 'green_new_cases': 12,
                      'original41_unchanged': unchanged, 'runtime': 'NOT_RUN'}))

if __name__ == '__main__':
    main()
