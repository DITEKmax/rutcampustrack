"""Future full Academic /app copies and exact seven-host spec binding; no child."""
import argparse
import copy
import hashlib
import json
import os
from pathlib import Path
import re
import stat
import types
import zipfile

OWN = Path(__file__).parent
boundary = types.ModuleType('refresh_boundary')
boundary.__file__ = str(OWN / 'refresh-boundary.py')
if hashlib.sha256((OWN / 'refresh-boundary.py').read_bytes()).hexdigest() != '5924346f1f56e270160ac4bd01918e55f3a577d198c0b1b67d45ad45b0a180f4':
    raise RuntimeError('Exact reviewed refresh boundary bytes required')
exec(compile((OWN / 'refresh-boundary.py').read_bytes(), boundary.__file__, 'exec'), boundary.__dict__)
BASE_SPECS = OWN.parent / 'current_host_config_v5/host-service-specs.json'
BASE_ARTIFACTS = OWN.parent / 'current_client_artifacts/eight-production-jars.json'
OLD_APP = OWN.parent / 'current_host_stage/payload/academic/app'
CLOCK = OWN.parent / 'real_client_runtime/teaching-clock-eec3/clock-fixture.jar'


def rebind_specs(specs, app, libraries):
    updated = copy.deepcopy(specs)
    original = next(row for row in specs if row['service'] == 'academic')
    target = next(row for row in updated if row['service'] == 'academic')
    argv = target['argv']
    index = argv.index('-cp') + 1
    old_cp = original['argv'][index].split(':')
    if (original['cwd'] != str(OLD_APP) or old_cp[0] != str(OLD_APP / 'BOOT-INF/classes')
            or old_cp[-1] != str(CLOCK)
            or any(not p.startswith(str(OLD_APP / 'BOOT-INF/lib') + '/') for p in old_cp[1:-1])
            or original['argv'][index + 1] != 'ru.rutcampustrack.academic.AcademicApplication'):
        raise RuntimeError('Exact existing genuine Academic host representation required')
    if not libraries or len(libraries) != len(set(libraries)):
        raise RuntimeError('Complete distinct canonical classpath libraries required')
    if any(not re.fullmatch(r'BOOT-INF/lib/[A-Za-z0-9_.+-]+\.jar', p) for p in libraries):
        raise RuntimeError('Canonical direct production library required')
    target['cwd'] = str(app)
    argv[index] = ':'.join([str(app / 'BOOT-INF/classes')]
                            + [str(app / n) for n in libraries] + [str(CLOCK)])
    if [s for s in updated if s['service'] != 'academic'] != [s for s in specs if s['service'] != 'academic']:
        raise RuntimeError('Other six host specs changed')
    if {k: v for k, v in target.items() if k not in ['cwd', 'argv']} != {k: v for k, v in original.items() if k not in ['cwd', 'argv']}:
        raise RuntimeError('Academic ENV/ports/resource/security settings changed')
    if [a for i, a in enumerate(argv) if i != index] != [a for i, a in enumerate(original['argv']) if i != index]:
        raise RuntimeError('Only Academic classpath/cwd may change')
    return updated


def copy_member(ns, use, app, name, stream):
    """No-follow descriptor traversal; never writes an old inode or follows ZIP links."""
    parts = Path(name).parts
    opened = []
    chain = []
    parent_fd = ns.fds[-1]
    try:
        p = boundary.PREFIX
        for component in ['app'] + list(parts[:-1]):
            ns.check()
            use()
            try:
                os.mkdir(component, 0o755, dir_fd=parent_fd)
            except FileExistsError:
                pass
            p = p / component
            before = boundary.identity(os.stat(component, dir_fd=parent_fd, follow_symlinks=False))
            if before['uid'] != 1000 or before['gid'] != 1000 or before['mode'] != 0o755:
                raise RuntimeError('Exact new public755 app directory required')
            fd = os.open(component, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW | os.O_CLOEXEC, dir_fd=parent_fd)
            opened.append(fd)
            chain.append((p, before, fd))
            if boundary.identity(os.fstat(fd)) != before:
                raise RuntimeError('Stage parent switched')
            parent_fd = fd
        ns.check()
        for p, expected, fd in chain:
            if boundary.identity(p.lstat()) != expected or boundary.identity(os.fstat(fd)) != expected:
                raise RuntimeError('Stage directory identity switched')
        use()
        fd = os.open(parts[-1], os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o644, dir_fd=parent_fd)
        with os.fdopen(fd, 'wb') as target:
            while block := stream.read(262144):
                ns.check()
                use()
                target.write(block)
            target.flush()
            os.fsync(target.fileno())
    finally:
        for fd in reversed(opened):
            os.close(fd)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--grant', required=True)
    args = parser.parse_args()
    g, stop = boundary.verify_grant(args.grant, 'STAGE', __file__)
    baseline = boundary.resource_snapshot()['workspace_free']
    use = lambda: boundary.gate(g, stop, baseline)
    ns = boundary.Namespace(use)
    previous_umask = os.umask(0o022)  # NEW public copies only; existing files never chmod.
    try:
        receipt = boundary.PREFIX / 'build-result.safe.json'
        if boundary.sha(receipt) != g['build_result_sha256']:
            raise RuntimeError('Exact actual fresh build receipt required')
        built = json.loads(receipt.read_text())
        if built['producer_revision'] != g['frozen_source_revision'] or built['status'] != 'CURRENT_ACADEMIC_PRODUCTION_JAR_ONLY':
            raise RuntimeError('Fresh exact source-bound build required')
        jar = boundary.PREFIX / 'checkout/services/academic-service/academic-app/build/libs/academic-app-0.1.0.jar'
        if built['jar'] != str(jar) or boundary.sha(jar) != built['jar_sha256']:
            raise RuntimeError('Exact new own production JAR identity required')
        app = boundary.PREFIX / 'app'
        ns.check()
        use()
        os.mkdir('app', 0o755, dir_fd=ns.fds[-1])
        inspector = boundary.load(OWN / 'inspect-academic.py', 'inspector')
        proof = inspector.inspect(boundary.PREFIX / 'checkout', g['frozen_source_revision'])
        if proof['regular_entries'] != built['regular_entries'] or proof['jar_sha256'] != built['jar_sha256']:
            raise RuntimeError('Production JAR changed since build')
        with zipfile.ZipFile(jar) as archive:
            for row in proof['regular_entries']:
                with archive.open(row['path']) as stream:
                    copy_member(ns, use, app, row['path'], stream)
            lines = archive.read('BOOT-INF/classpath.idx').decode('utf8').splitlines()
        libraries = []
        for line in lines:
            if not line.startswith('- "BOOT-INF/lib/') or not line.endswith('.jar"'):
                raise RuntimeError('Canonical standard classpath index required')
            libraries.append(line[3:-1])
        if set(libraries) != {r['path'] for r in proof['regular_entries'] if r['path'].startswith('BOOT-INF/lib/') and r['path'].endswith('.jar')}:
            raise RuntimeError('Exact complete classpath index required')
        metadata = []
        for row in proof['regular_entries']:
            path = boundary.regular(app / row['path'])
            s = path.lstat()
            if boundary.sha(path) != row['sha256'] or s.st_uid != 1000 or s.st_gid != 1000 or s.st_nlink != 1 or stat.S_IMODE(s.st_mode) != 0o644:
                raise RuntimeError('Full current copied bytes/readability required')
            metadata.append(dict(row, allocated=s.st_blocks * 512, device=s.st_dev, inode=s.st_ino, mode=0o644))
        specs = rebind_specs(json.loads(BASE_SPECS.read_text()), app, libraries)
        ns.check()
        use()
        ns.save('host-service-specs.safe.json', specs, new=True)
        old = json.loads(BASE_ARTIFACTS.read_text())
        mappings = []
        for row in old['jars']:
            if row['service'] == 'academic':
                mappings.append({'service': 'academic', 'producer': g['frozen_source_revision'], 'jar': str(jar), 'sha256': built['jar_sha256'], 'app': str(app)})
            else:
                mappings.append({'service': row['service'], 'producer': old['revision'], 'jar': row['jar'], 'sha256': row['sha256'], 'unchanged': True})
        result = {'status': 'FULL_CURRENT_ACADEMIC_APP_STAGED_ONLY', 'producer': g['frozen_source_revision'],
                  'academic_refresh_manifest_sha256': g['academic_refresh_manifest_sha256'],
                  'build_result_sha256': g['build_result_sha256'], 'app': str(app),
                  'jar': str(jar), 'jar_sha256': built['jar_sha256'], 'files': metadata,
                  'host_service_specs': str(boundary.PREFIX / 'host-service-specs.safe.json'),
                  'host_service_specs_sha256': boundary.sha(boundary.PREFIX / 'host-service-specs.safe.json'),
                  'library_order': libraries, 'effective8_artifacts': mappings,
                  'resources': boundary.require_resources(g, baseline), 'runtime': 'NOT_RUN'}
        ns.check()
        use()
        ns.save('stage-result.safe.json', result, new=True)
        print(json.dumps({'phase': 'STAGE', 'full_app': True, 'original7_artifacts_unchanged': True, 'runtime': False}))
        return 0
    except BaseException as e:
        ns.save('stage-error.safe.json', {'status': 'PARTIAL_STOPPED', 'error_type': type(e).__name__, 'runtime': False})
        print(json.dumps({'phase': 'STAGE', 'status': 'PARTIAL_STOPPED', 'error_type': type(e).__name__}))
        return 1
    finally:
        os.umask(previous_umask)
        ns.close()


if __name__ == '__main__':
    raise SystemExit(main())
