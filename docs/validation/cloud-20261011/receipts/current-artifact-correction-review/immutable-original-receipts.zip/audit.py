import ast
import datetime
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import stat
import zipfile

AUTHOR=Path('/workspace/scratch/rct-validation/current_artifact_corrections')
OWN=Path('/workspace/scratch/rct-validation/current_artifact_correction_review')
ROOT=Path('/workspace/rutcampustrack/docs/validation/cloud-20261011')
ART=Path('/workspace/scratch/rct-validation/current_client_artifacts')

def digest(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  while b:=f.read(65536):h.update(b)
 return h.hexdigest()
def save(n,v):(OWN/n).write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
def note(n,**v):
 r={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'phase':n,**v};(OWN/'attempts.ndjson').open('a').write(json.dumps(r)+'\n');print(json.dumps(r),flush=True)

manifest=AUTHOR/'manifest.json'
assert digest(manifest)=='486729fbf44eb6770a7504686831f614e15a2d949255a932c2b830b0da18a0a8'
rows=json.loads(manifest.read_text())['files'];checks=[]
root_archive=ROOT/'receipts/current-artifact-correction-author/immutable-original-receipts.zip'
with zipfile.ZipFile(root_archive) as z:
 for r in rows:
  p=Path(r['path']);assert p.is_relative_to(AUTHOR) and p.stat().st_size==r['bytes'] and digest(p)==r['sha256']
  matches=[n for n in z.namelist() if PurePosixPath(n).name==p.name];assert len(matches)==1
  h=hashlib.sha256()
  with z.open(matches[0]) as f:
   while b:=f.read(65536):h.update(b)
  assert h.hexdigest()==r['sha256'];checks.append({'path':str(p),'member':matches[0],'sha256':r['sha256'],'equal':True})
save('author23-seal-and-root-identity.json',{'manifest':str(manifest),'sha256':digest(manifest),'root_archive_sha256':digest(root_archive),'entries':checks})
for p in AUTHOR.glob('*.py'):ast.parse(p.read_text(),str(p))
note('correction23_rootoriginals_AST',files=len(checks))

control=json.loads((AUTHOR/'controls-result.json').read_text());inputs=control['control_sources_SHA']
assert all(digest(AUTHOR/name)==sha for name,sha in inputs.items())
normal=control['normal'];assert normal['settled'] and normal['phase_success'] and normal['native_exit']==0
assert len(normal['adopted_waitpid_receipts'])==1 and normal['adopted_waitpid_receipts'][0]['native_exit']==0
qualified=[]
for name in ['normal','deadline','status_failure_during_settlement','two_signals_escaped_descendant']:
 r=control[name];assert r['settled'] and r['all_owned_processes_reaped'] and not r['all_members_including_Z_after']
 if name!='normal':assert r['native_exit']==-9 and not r['phase_success']
 if name=='deadline':assert r['terminal_reason']=='BOUNDED_DEADLINE'
 if name=='status_failure_during_settlement':assert r['supervision_error_type']=='TypeError'
 if name=='two_signals_escaped_descendant':assert r['signal_count']==2 and r['terminal_reason']=='STOP_REQUEST'
 identity=[]
 for k in r['known_owned_identities']:
  p=Path('/proc')/str(k['pid'])/'stat'
  try:
   f=p.read_text().rsplit(')',1)[1].split();same=int(f[19])==k['start_ticks'];current={'state':f[0],'start_ticks':int(f[19])}
  except FileNotFoundError:same=False;current=None
  assert not same
  identity.append({'recorded':k,'current':current,'recorded_identity_absent':True})
 qualified.append({'name':name,'native_result':r,'current_identity_checks':identity,'runtime_by_reviewer':'NOT_RUN'})
counter=control['old_counterexample'];assert counter['exact_AST_old_group_members']==[] and counter['actual_unreaped_owned_Z']['state']=='Z' and counter['false_all_owned_empty'] and counter['controller_waitpid_native_exit']==0
env=json.loads((AUTHOR/'env-policy-control.json').read_text());assert env['explicit_env_None_rejected_before_launch'] and not env['own_child_before'] and not env['own_child_after']
assert control['dependent_false_grant']['native_exit']==2 and control['dependent_false_grant']['runtime_child_started'] is False
attempts=[json.loads(line) for line in (AUTHOR/'attempts.ndjson').read_text().splitlines() if line.strip()]
save('actual-stdlib-outcome-audit.json',{'source_hashes':inputs,'source_current_equals_final_actual_inputs':True,'cases':qualified,'old_exact_AST_counterexample':counter,'explicit_env_guard':env,'standalone_grant':control['dependent_false_grant'],'preserved_initial_failure':json.loads((AUTHOR/'controls-attempt1.json').read_text()),'append_only_attempt_count':len(attempts),'raw_synthetic_control_native_exit':control['control_native_exit'],'test_quality':'actual owned Z + independent /proc identity oracle, escaped SID, delayed second signal and reporting error with explicit negative phase_success; no app/runtime acceptance','limits':'actual wraps/unrelated PID ownership not covered; see new pure-source counterexample'})
note('actual_control_receipts',cases=len(qualified))

preserve=json.loads((AUTHOR/'preservation-and-old-process-qualification.json').read_text());preservation=[]
for m in preserve['original_seals']:
 p=Path(m['manifest']);assert digest(p)==m['sha256']
 blob=json.loads(p.read_text());entries=blob.get('safe_files',blob.get('files'))
 for r in entries:
  q=Path(r['path']);assert q.stat().st_size==r['bytes'] and digest(q)==r['sha256']
 preservation.append({'manifest':str(p),'SHA':m['sha256'],'entries':len(entries),'all_equal':True})
assert sum(r['entries'] for r in preservation)==108
source=json.loads((ART/'source-inputs-before.json').read_text())
for r in source['tracked']:
 p=Path(source['worktree'])/r['path'];assert p.stat().st_size==r['bytes'] and oct(stat.S_IMODE(p.stat().st_mode))==r['mode'] and digest(p)==r['sha256']
deps=json.loads((ART/'installed-deps-before.json').read_text())
for r in deps['entries']:
 p=Path(deps['source'])/r['path']
 if r.get('kind')=='symlink':assert p.is_symlink() and os.readlink(p)==r['target']
 else:assert p.stat().st_size==r['bytes'] and oct(stat.S_IMODE(p.stat().st_mode))==r['mode'] and digest(p)==r['sha256']
actual=set()
for parent,dirs,files in os.walk(deps['source'],followlinks=False):
 base=Path(parent)
 actual.update(str((base/n).relative_to(deps['source'])) for n in files)
 actual.update(str((base/n).relative_to(deps['source'])) for n in dirs if (base/n).is_symlink())
assert actual=={r['path'] for r in deps['entries']}
jars=[]
for r in preserve['current8_and_old8_JARs']:
 p=Path(r['path']);assert digest(p)==r['sha256'] and oct(stat.S_IMODE(p.stat().st_mode))==r['mode'];jars.append({'path':str(p),'SHA':r['sha256'],'mode':r['mode'],'equal':True})
assert len(jars)==16
vue=json.loads((ART/'production-vue-bundles.json').read_text());count=0
for b in vue['bundles']:
 for r in b['files']:
  p=Path(b['directory'])/r['path'];assert p.stat().st_size==r['bytes'] and oct(stat.S_IMODE(p.stat().st_mode))==r['mode'] and digest(p)==r['sha256'];count+=1
assert count==22
old=[]
for pid in [201385,201430]:
 try:
  f=(Path('/proc')/str(pid)/'stat').read_text().rsplit(')',1)[1].split();row={'pid':pid,'state':f[0],'ppid':int(f[1]),'pgrp':int(f[2]),'start_ticks':int(f[19])};assert row['state']=='Z' and row['ppid']==1
 except FileNotFoundError:row={'pid':pid,'current_absent':True,'reaped_by_reviewer':False}
 old.append(row)
save('independent-preservation.json',{'108original_safe_files':preservation,'source7350_SHA_size_modes_equal':True,'deps8272_SHA_size_modes_targets_pathset_equal':True,'jars16':jars,'Vue22_equal':True,'old_processes_read_only':old,'mutations':False,'private_raw_logs':'NOT_READ'})
note('original108_sources_deps_artifacts_preserved',source=len(source['tracked']),deps=len(deps['entries']),jars=len(jars),Vue=count)

provenance=json.loads((AUTHOR/'jdk-provenance-correction.json').read_text());wrapper=Path(provenance['canonical_wrapper_path']);release=Path(provenance['release_path']);java=Path(provenance['java_executable_path'])
assert digest(wrapper)==provenance['wrapper_sha256'] and digest(release)==provenance['release_sha256'] and digest(java)==provenance['java_executable_sha256_now']
assert "environment['JAVA_HOME'] = '/workspace/rct-cloud-setup/jdk21'" in wrapper.read_text()
fields={}
for line in release.read_text().splitlines():
 if '=' in line:
  k,v=line.split('=',1);fields[k]=v.strip('"')
assert all(fields[k]==v for k,v in provenance['public_release_fields'].items())
save('provenance-correction-audit.json',{'verdict':'AR-P01 CLOSED','actual_build_HOME':'/workspace/rct-cloud-setup/jdk21','vendor':'Eclipse Adoptium Temurin21.0.12.1+1/LinuxGNU','host_OS':'Debian13','future_runtime_JDK':'UNKNOWN/NOT_RUN','current_java_hash':digest(java),'historical_binary_hash':'not retroactively established by current observation','old_build8_artifact_and_inspection_proof':'unchanged exact908 receipt','JVM_run_by_reviewer':'NOT_RUN'})
note('recheck_audit_complete',new_source_counterexample='ownership_PIDstart_mismatch',runtime='NOT_RUN')
