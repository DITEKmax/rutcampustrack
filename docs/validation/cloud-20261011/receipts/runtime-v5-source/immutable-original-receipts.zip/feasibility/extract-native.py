"""Exact CREATED-only Mongo extraction; never starts the container or server."""
import datetime,hashlib,json,os,subprocess,types
from pathlib import Path
OWN=Path('/workspace/scratch/rct-validation/current_host_config_v5');OUT=Path(__file__).parent;TARGET=Path('/tmp/rct-native-mongo-20261012')
IMAGE='sha256:cc6e50c173ff2cf38ffb812fb582450e9b40fc1f67eadd63e81071f18fc8cc96';NAME='rct-native-mongo-feasibility-20261012'
os.umask(0o077)
def save(name,obj):(OUT/name).write_text(json.dumps(obj,indent=2)+'\n')
def metadata(argv):
 p=subprocess.run(argv,stdin=subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=subprocess.DEVNULL,timeout=25)
 if p.returncode:raise RuntimeError('Metadata command failed '+str(p.returncode))
 return p.stdout.decode().strip()
def free(path):
 st=os.statvfs(path);return st.f_bavail*st.f_frsize
start=free('/workspace');start_tmp=free('/tmp')
assert start-1717986918>=4294967296 and start_tmp-1073741824>=4294967296
body=(OWN.parent/'guard_proc_race_correction/bounded-child.py').read_bytes();assert hashlib.sha256(body).hexdigest()=='b78c61293568d9941692e0b92ee34fd0b84db6d532b4a2c9a5ad42ccbf2204a0'
guard=types.ModuleType('accepted_guard');exec(compile(body,str(OWN.parent/'guard_proc_race_correction/bounded-child.py'),'exec'),guard.__dict__)
env={'PATH':'/usr/local/bin:/usr/bin:/bin','HOME':str(OWN),'LANG':'C.UTF-8','LC_ALL':'C.UTF-8'}
steps=[]
def observe():
 used=int(Path('/sys/fs/cgroup/memory.current').read_text());maximum=int(Path('/sys/fs/cgroup/memory.max').read_text())
 if free('/workspace')<4294967296 or free('/tmp')<4294967296:return 'DISK_FLOOR'
 if start-free('/workspace')>1717986918:return 'WORKSPACE_EXTRACTION_CAP'
 if start_tmp-free('/tmp')>1073741824:return 'TMP_EXTRACTION_CAP'
 if used>=16106127360 or maximum-used<1073741824:return 'SHARED_MEMORY_STOP'
 return None
def run(name,argv):
 save('CURRENT.json',{'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'wrapper_pid':os.getpid(),'phase':name,'temporary_container':NAME,'workspace_free':free('/workspace'),'tmp_free':free('/tmp')})
 result=guard.run_owned(argv,str(OWN),env,deadline_seconds=120,observe=observe,status=lambda value:save('process-'+name+'.safe.json',value))
 steps.append({'operation':name,'argv':argv,'result':result});save('steps.safe.json',steps)
 return result['phase_success']
assert not metadata(['docker','container','ls','-aq','--filter','name=^/'+NAME+'$'])
volume_ids=metadata(['docker','volume','ls','-q','--filter','label=com.docker.compose.project=rct-client-host-config-20261012']).splitlines();assert len(volume_ids)==5
save('launch.safe.json',{'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'pid':os.getpid(),'workspace_start':start,'tmp_start':start_tmp,'image':IMAGE,'container_name':NAME,'preserved_data5_names':volume_ids,'no_start_no_app':True})
created=False
try:
 argv=['docker','create','--name',NAME,'--label','rct.owner=host_runtime_prepare','--label','rct.scope=T004','--network','none','--entrypoint','/usr/bin/true','--mount','type=bind,src='+str(OWN/'empty-image-volume')+',dst=/bitnami/mongodb,readonly',IMAGE]
 if not run('create',argv):raise RuntimeError('Exact CREATED-only allocation failed')
 created=True
 template='{"id":{{json .Id}},"image":{{json .Image}},"status":{{json .State.Status}},"pid":{{json .State.Pid}},"owner":{{json (index .Config.Labels "rct.owner")}},"scope":{{json (index .Config.Labels "rct.scope")}},"mounts":{{json .Mounts}}}'
 record=json.loads(metadata(['docker','container','inspect',NAME,'--format',template]));assert record['image']==IMAGE and record['status']=='created' and record['pid']==0 and record['owner']=='host_runtime_prepare' and record['scope']=='T004'
 assert len(record['mounts'])==1 and record['mounts'][0]['Type']=='bind' and record['mounts'][0]['Source']==str(OWN/'empty-image-volume')
 save('created-only.safe.json',record)
 entries=[('mongod','/opt/bitnami/mongodb/bin/mongod'),('mongosh','/opt/bitnami/mongodb/bin/mongosh'),('entrypoint.sh','/opt/bitnami/scripts/mongodb/entrypoint.sh'),('run.sh','/opt/bitnami/scripts/mongodb/run.sh')]
 copied=[]
 for name,remote in entries:
  destination=TARGET/name
  assert not destination.exists()
  success=run('copy-'+name.replace('.','-'),['docker','cp',record['id']+':'+remote,str(destination)])
  if not success:
   copied.append({'name':name,'remote':remote,'status':'EXACT_LOOKUP_FAILED_NATIVE_RECEIPT_RETAINED'})
  else:
   h=hashlib.sha256()
   with destination.open('rb') as stream:
    for block in iter(lambda:stream.read(1048576),b''):h.update(block)
   copied.append({'name':name,'image_path':remote,'local':str(destination),'bytes':destination.stat().st_size,'mode':oct(destination.stat().st_mode&0o777),'public_sha256':h.hexdigest()})
  save('copied-public-files.safe.json',copied)
 save('extraction-partial.safe.json',{'image':IMAGE,'public_entries':copied,'version_or_server_executed':False,'workspace_free':free('/workspace'),'tmp_free':free('/tmp')})
finally:
 if created:
  fresh=json.loads(metadata(['docker','container','inspect',NAME,'--format',template]));assert fresh['id']==record['id'] and fresh['owner']=='host_runtime_prepare' and fresh['scope']=='T004' and fresh['status']=='created' and fresh['pid']==0
  # Cleanup must remain possible if an extraction cap was crossed; no new allocation or -v.
  result=guard.run_owned(['docker','rm',fresh['id']],str(OWN),env,deadline_seconds=60,status=lambda value:save('process-cleanup.safe.json',value))
  assert result['phase_success'];save('cleanup.safe.json',{'guard':result,'exact_container_id':fresh['id'],'no_volume_flag':True})
 remaining=metadata(['docker','container','ls','-aq','--filter','name=^/'+NAME+'$']);assert not remaining
 assert set(metadata(['docker','volume','ls','-q','--filter','label=com.docker.compose.project=rct-client-host-config-20261012']).splitlines())==set(volume_ids)
 save('terminal.safe.json',{'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'temporary_container_absent':True,'all5data_volumes_preserved':True,'all_ordinary_CLI_owned_steps_terminal':True,'no_server_start':True,'workspace_free':free('/workspace'),'tmp_free':free('/tmp'),'image':IMAGE})
print('Exact native extraction terminal; temporary CREATED-only container removed, original5 volumes untouched; version probes next')
