// Source/adapter controls only. No browser, API, redirect, login or provider is contacted.
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const crypto = require('node:crypto');
const ts = require('/workspace/rutcampustrack/frontends/node_modules/typescript/lib/typescript.js');
const oldRoot = '/workspace/scratch/rct-validation/client_real_acceptance/focused3-preparation-5ced';
const mode = process.argv[2];
if (!['old', 'new'].includes(mode)) process.exit(2);
const source = mode === 'old' ? path.join(oldRoot, 'observer.ts') : path.join(__dirname, 'observer.ts');
if (mode === 'old') {
  const frozen = JSON.parse(fs.readFileSync(path.join(oldRoot, 'READY.safe.json'), 'utf8'));
  if (crypto.createHash('sha256').update(fs.readFileSync(source)).digest('hex') !== frozen.own_source_hashes['observer.ts']) process.exit(2);
}
function deferred() {
  let resolve;
  const promise = new Promise((value) => { resolve = value; });
  return { promise, resolve };
}
async function flush() { for (let step = 0; step < 160; step++) await Promise.resolve(); }
function clock() {
  let now = 0;
  let sequence = 0;
  const timers = new Map();
  return {
    setTimeout(callback, delay) { const id = ++sequence; timers.set(id, { callback, at: now + delay }); return id; },
    clearTimeout(id) { timers.delete(id); },
    advance(milliseconds) {
      now += milliseconds;
      for (const [id, item] of [...timers]) if (item.at <= now) { timers.delete(id); item.callback(); }
    },
  };
}
function fixture(kind = 'ordinary') {
  const time = clock();
  const responseDispose = deferred();
  const contextDispose = deferred();
  const lateBody = deferred();
  const lateGet = deferred();
  const lateDom = deferred();
  const writes = [];
  const calls = [];
  let contextCloses = 0;
  let responseCloses = 0;
  let domCalls = 0;
  let followed = false;
  const session = { userId: '1', activeRole: 'STUDENT', roles: [{ role: 'STUDENT', selectable: true }] };
  const response = (value, code = 200) => ({
    status: () => code,
    json: () => kind === 'lateBody' ? lateBody.promise : Promise.resolve(value),
    dispose: () => { responseCloses++; return kind === 'lateDispose' ? responseDispose.promise : Promise.resolve(); },
  });
  const context = {
    get(route, options) {
      calls.push({ session: route === '/api/auth/session', noRedirect: options.maxRedirects === 0,
        noRetry: options.maxRetries === 0, tokenUndefined: options.headers.Authorization === 'Bearer undefined' });
      if (kind === 'redirect' && options.maxRedirects !== 0) followed = true;
      if (kind === 'lateGet') return lateGet.promise;
      const code = kind === 'redirect' && options.maxRedirects === 0 ? 302 : 200;
      return Promise.resolve(response(route === '/api/auth/session' ? session : { items: [] }, code));
    },
    dispose() { contextCloses++; return kind === 'lateContextDispose' ? contextDispose.promise : Promise.resolve(); },
  };
  const locator = {
    count: () => { domCalls++; return kind === 'lateDom' ? lateDom.promise : Promise.resolve(0); },
    isVisible: () => { domCalls++; return Promise.resolve(false); },
    isEnabled: () => { domCalls++; return Promise.resolve(false); },
    first: () => locator,
  };
  const page = { request: context, on() {}, off() {}, locator: () => locator,
    getByRole: () => locator, getByText: () => locator };
  const fakeFs = { lstatSync: () => ({ isDirectory: () => true, isSymbolicLink: () => false, mode: 0o700 }),
    renameSync() {}, writeFileSync(_file, value) { writes.push(JSON.parse(value)); } };
  const code = ts.transpileModule(fs.readFileSync(source, 'utf8'), {
    fileName: source, compilerOptions: { target: ts.ScriptTarget.ES2022, module: ts.ModuleKind.CommonJS },
    reportDiagnostics: true,
  });
  if (code.diagnostics?.some((item) => item.category === ts.DiagnosticCategory.Error)) throw new Error('CONTROL_PARSER');
  const exported = {};
  const sandbox = { exports: exported, Buffer, URL, URLSearchParams, Intl, Date, AbortController,
    setTimeout: time.setTimeout, clearTimeout: time.clearTimeout,
    process: { env: { RCT_FOCUS3_RUN: '/PUBLIC_CONTROL', RCT_FOCUS3_OBSERVATIONS: '/PUBLIC_CONTROL/supervision/observations.safe.json' } },
    require(name) {
      if (name === 'node:fs') return fakeFs;
      if (name === 'node:path') return path;
      if (name === '/workspace/rutcampustrack/tests/e2e/node_modules/@playwright/test') return { request: { newContext: () => Promise.resolve(context) } };
      throw new Error('CONTROL_IMPORT');
    },
  };
  new vm.Script(code.outputText, { filename: source }).runInNewContext(sandbox, { timeout: 1000 });
  const actor = { id: 1, displayName: 'PUBLIC_SYNTHETIC_NAME' };
  const dataset = { student: actor, assistant: actor, headman: actor, teacher: { id: 2 },
    group: { id: 1 }, subject: { id: 1 }, semester: { id: 1 }, lesson: { physicalLessonId: 1 },
    homework: { id: 1 }, marker: 'PUBLIC_SYNTHETIC_MARKER', today: '2026-10-12', tomorrow: '2026-10-13' };
  const observer = new exported.FocusObserver(page, dataset, { title: exported.caseTitles.STUDENT });
  observer.token = 'PUBLIC_SYNTHETIC_BEARER';
  observer.start();
  const ended = () => writes.some((item) => item.events.some((event) => event.phase === 'END'));
  const lastEnd = () => writes.at(-1)?.events.at(-1)?.phase === 'END';
  return { observer, time, responseDispose, contextDispose, lateBody, lateGet, lateDom, writes, calls,
    response, ended, lastEnd, contextCloses: () => contextCloses, responseCloses: () => responseCloses,
    domCalls: () => domCalls, followed: () => followed };
}
async function oldCounterexample() {
  const test = fixture('lateDispose');
  const finished = test.observer.finish({ status: 'failed' });
  await flush();
  test.time.advance(12001);
  await flush();
  await finished;
  const before = test.writes.length;
  const endedBeforeRelease = test.ended();
  test.responseDispose.resolve();
  await flush();
  return { oldCounterexample: endedBeforeRelease && test.writes.length > before &&
    test.calls.some((item) => item.tokenUndefined), responseDisposeUsed: test.responseCloses() > 0 };
}
async function newControls() {
  const checks = {};
  const ordinary = fixture();
  await ordinary.observer.finish({ status: 'failed' });
  checks.ordinary = ordinary.lastEnd() && ordinary.calls.length === 3 &&
    ordinary.calls.every((item) => item.noRedirect && item.noRetry) && ordinary.observer.token === undefined;
  const late = fixture('lateContextDispose');
  const lateFinish = late.observer.finish({ status: 'failed' });
  await flush();
  checks.delayedOwnedCloseBeforeEnd = !late.ended() && late.observer.token === undefined;
  late.contextDispose.resolve();
  await lateFinish;
  const lateWrites = late.writes.length;
  const lateCalls = late.calls.length;
  late.time.advance(20000);
  await flush();
  checks.delayedOwnedCloseSettled = late.lastEnd() && late.writes.length === lateWrites &&
    late.calls.length === lateCalls && late.responseCloses() === 0 && late.contextCloses() === 1;
  for (const kind of ['lateBody', 'lateGet', 'lateDom']) {
    const item = fixture(kind);
    const finished = item.observer.finish({ status: 'failed' });
    await flush();
    item.time.advance(12001);
    await flush();
    await finished;
    const beforeWrites = item.writes.length;
    const beforeCalls = item.calls.length;
    const beforeDom = item.domCalls();
    item.lateBody.resolve({ userId: '1', activeRole: 'STUDENT' });
    item.lateGet.resolve(item.response({ userId: '1', activeRole: 'STUDENT' }));
    item.lateDom.resolve(0);
    await flush();
    checks[kind] = item.lastEnd() && item.observer.token === undefined && item.writes.length === beforeWrites &&
      item.calls.length === beforeCalls && item.domCalls() === beforeDom && item.calls.length <= 1;
  }
  const redirect = fixture('redirect');
  await redirect.observer.finish({ status: 'failed' });
  checks.redirect = redirect.calls.length === 1 && redirect.calls[0].noRedirect &&
    !redirect.followed() && redirect.lastEnd() && redirect.observer.token === undefined;
  const passed = fixture();
  await passed.observer.finish({ status: 'passed' });
  checks.noSuccessGet = passed.calls.length === 0 && passed.lastEnd() && passed.observer.token === undefined;
  const ui = fixture();
  const login = deferred();
  ui.observer.responseListener({ url: () => 'https://localhost:8443/api/auth/login', status: () => 200,
    request: () => ({ method: () => 'POST', headers: () => ({}) }), json: () => login.promise });
  await flush();
  ui.time.advance(1501);
  await flush();
  await ui.observer.finish({ status: 'failed' });
  const uiWrites = ui.writes.length;
  login.resolve({ accessToken: 'PUBLIC_SYNTHETIC_LATE_BEARER' });
  await flush();
  checks.lateUiCannotRefill = ui.observer.token === undefined && ui.writes.length === uiWrites && ui.calls.length === 0 && ui.lastEnd();
  return checks;
}
(async () => {
  const facts = mode === 'old' ? await oldCounterexample() : await newControls();
  const pass = Object.values(facts).every((value) => value === true);
  const value = { stage: mode === 'old' ? 'ORIGINAL_CAUSAL_COUNTEREXAMPLE' : 'CORRECTED_LIFETIME_AND_OPTIONS',
    facts, expectedCounterexample: mode === 'old' && pass, pass,
    qualification: 'SOURCE_ADAPTER_ONLY_NO_BROWSER_API_OR_REAL_TRANSPORT' };
  const file = process.env.RCT_FOCUS3_LIFETIME_OUTPUT;
  if (file !== path.join(process.env.RCT_FOCUS3_RUN ?? '', 'supervision',
    mode === 'old' ? 'lifetime-red.safe.json' : 'lifetime-green.safe.json')) throw new Error('CONTROL_OUTPUT');
  fs.writeFileSync(file, JSON.stringify(value, null, 2) + '\n', { mode: 0o600 });
  process.exit(mode === 'old' ? pass ? 1 : 2 : pass ? 0 : 1);
})().catch(() => { process.stdout.write('{"stage":"LIFETIME_CONTROL_INFRA","pass":false}\n'); process.exit(2); });
