# Combined narrow observer correction — source candidate

Frozen original review reports exactly two source-only P2 blockers: FOCUS3-ASYNC01 and
FOCUS3-NET01. Original source ZIP5fe, READY167b and native Node ZIP8f22 remain immutable.
This sibling changes diagnostic scratch only. Original tests/assertions, Root19, protected fixture,
canonical live reporter, privacy flag, viewport, teaching/security clocks and vendor remain unchanged.

ASYNC01 cause: the old outer Promise.race returned before a delayed response.dispose; later code
could append facts after END and start another GET with the cleared bearer. New code has explicit
stopping/ended checks, a shared cancellation signal and synchronous token clearing. Every DOM
operation and post-await reducer checks that observation is still running. Abort rejects the observer's
waits; late UI response/body completions are ignored and cannot refill the token or write facts.
These passive body reads do not start a new UI network request; the original page owns that request.

Failed-case GETs use a separate disposable request context and the same UI-issued bearer, without
new login/cookies/seed/write. Individual response.dispose is removed; the owned context releases
all cached bodies together. Stop starts supported owned-context disposal; all observer wait wrappers
and that disposal are awaited before END. Disposal failure marks diagnostics incomplete. A stuck
public channel can prevent END until the existing worker/Root absolute timeout; this is fail-closed
settlement, not a claim that Promise.race canceled a transport or that IPC is always timely. Token
clearing and stopping happen synchronously before any awaited disposal, so even a stalled close
cannot permit later GET, reducer, persist or token refill. Shared page/dataset request contexts remain
untouched. The Root foreground guard remains the final process deadline and reap boundary.

NET01 correction: context and each GET explicitly set maxRedirects0; GETs retain maxRetries0 and
their3000ms timeout. Unexpected301/302/303/307/308 are classified as closed statuses, never followed
or parsed for Location/body. Fresh own-session/actor matching still precedes target reads.

Prepared source/adapter controls evaluate the exact immutable old and new observer JavaScript
emitted by pinned TS5.9.3, with public synthetic marker data, a deterministic timer adapter, public
request/response adapters and a memory-only safe writer. They do not contact an API or execute
Playwright's real transport. Old red must preserve causal native1 and prove END before response
dispose release, then post-END write and later GET with an undefined bearer. New green covers:

- ordinary failed-case reads and preserved failed status;
- delayed owned-context disposal: no END before settlement, token already cleared;
- delayed body, GET and DOM callbacks: no later GET/DOM work/persist after stop/END;
- late login body cannot refill the token;
- explicit request options prevent the adapter's redirect branch and later target GET;
- successful original status performs no diagnostic GET.

Actual pinned client/server fetch source is a separately hashed source input: maxRedirects0 bypasses
the redirect-follow branch; context.dispose sets client close reason before await; server disposal
emits Dispose to destroy outstanding requests. This is source evidence, not new browser/API or
genuine transport cancellation acceptance. Old/current adapters prove observer lifetime/options only.

Future NEW Node grant phases: lifetime-red(expectednative1 with exact closed causal witness),
lifetime-green(native0), scoped types, field2positive/7reject, native --list3/original14/61/142 Chromium.
Stop on unexpected infrastructure, control or compiler outcome. All source/driver/old-source hashes
must be bound by a fresh READY/grant. No reuse of original grants after source changes.

Current status: source-only preparation. New red/green/types/fields/list, browser/API/login/network,
real context cancellation and original three failure causes are NOT_RUN/UNKNOWN. Review and actual
stand/browser grants remain separate. Requested Sol6.1/xhigh; actual UNKNOWN.
