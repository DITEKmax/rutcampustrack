package ru.rutcampustrack.academic.integration;

import com.fasterxml.jackson.databind.ObjectMapper;
import io.grpc.Server;
import io.grpc.ServerBuilder;
import io.grpc.ServerInterceptors;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.test.annotation.DirtiesContext;
import ru.rutcampustrack.academic.grpc.AcademicGrpcServiceImpl;
import ru.rutcampustrack.academic.grpc.GrpcAuthInterceptor;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.TimeUnit;

import static org.assertj.core.api.Assertions.assertThat;

/** Actual PG + production authenticated RPC + Python adapter + local HTTP provider. */
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT, properties = {
        "grpc.server.port=-1", "grpc.auth.secret=synthetic-notify3-grpc-service-credential"})
@DirtiesContext(classMode = DirtiesContext.ClassMode.AFTER_CLASS)
class BotAdmissionProviderBridgeIT extends AbstractAcademicIntegrationTest {

    @Autowired JdbcTemplate jdbc;
    @Autowired AcademicGrpcServiceImpl academic;
    @Autowired GrpcAuthInterceptor grpcAuthentication;

    @Test
    void currentBoundStudentReceivesAcceptedInitialCredentialAtPrivateFirstStart() throws Exception {
        long telegram = 987654321L;
        String marker = UUID.randomUUID().toString().replace("-", "");
        long user = jdbc.queryForObject("SELECT id FROM users WHERE login='student'", Long.class);
        jdbc.update("UPDATE users SET telegram_id=?, initial_password=?, password_hash=?, password_changed=false WHERE id=?",
                telegram, marker, new BCryptPasswordEncoder().encode(marker), user);
        assertThat(jdbc.queryForObject("""
                SELECT EXISTS(SELECT 1 FROM users u JOIN user_role_grants g ON g.user_id=u.id
                 WHERE u.id=? AND u.telegram_id=? AND u.initial_password IS NOT NULL
                   AND NOT u.password_changed AND u.status='active'
                   AND g.role='student' AND g.status='active' AND g.group_id=1)
                """, Boolean.class, user, telegram)).isTrue();
        Server server = ServerBuilder.forPort(0)
                .addService(ServerInterceptors.intercept(academic, grpcAuthentication)).build().start();
        Process python = null;
        try {
            Path root = repositoryRoot();
            Path bot = root.resolve("services/notification-bot");
            // Runtime must provide an interpreter with the unchanged pinned bot dependencies.
            // Missing interpreter/dependencies is an environment failure, never a product red.
            String executable = System.getProperty("notify3.bot.python",
                    System.getenv().getOrDefault("NOTIFY3_BOT_PYTHON", "python3"));
            ProcessBuilder command = new ProcessBuilder(executable,
                    "tests/harness/bot_admission_provider_probe.py");
            command.directory(bot.toFile());
            command.environment().put("PYTHONPATH", bot.toString());
            python = command.start();
            var json = new ObjectMapper();
            try (var input = python.getOutputStream()) {
                json.writeValue(input, Map.of("grpc_port", server.getPort(), "user_id", user,
                        "telegram_id", telegram, "initial_marker", marker,
                        "grpc_secret", "synthetic-notify3-grpc-service-credential"));
            }
            assertThat(python.waitFor(25, TimeUnit.SECONDS)).as("bounded Python probe terminated").isTrue();
            int exit = python.exitValue();
            // Never attach stdout/stderr bodies to assertions or test reports.
            assertThat(exit).as("probe infrastructure exit code").isZero();
            var result = json.readTree(python.getInputStream());
            assertThat(result.path("untrusted_lookup_denied").asBoolean()).isTrue();
            assertThat(result.path("current_bound_user").asBoolean()).isTrue();
            assertThat(result.path("provider_attempts").asInt()).isEqualTo(1);
            assertThat(result.path("exact_private_recipient").asBoolean()).isTrue();
            assertThat(result.path("delivered_initial").asBoolean())
                    .as("accepted private first-start initial credential delivered").isTrue();
        } finally {
            if (python != null && python.isAlive()) {
                python.destroyForcibly();
                python.waitFor(5, TimeUnit.SECONDS);
            }
            server.shutdownNow();
            server.awaitTermination(5, TimeUnit.SECONDS);
            jdbc.update("UPDATE users SET telegram_id=NULL, initial_password=NULL WHERE id=?", user);
        }
    }

    private static Path repositoryRoot() {
        Path current = Path.of(System.getProperty("user.dir")).toAbsolutePath();
        while (current != null) {
            if (Files.isDirectory(current.resolve("services/notification-bot/bot"))) return current;
            current = current.getParent();
        }
        throw new IllegalStateException("notification-bot source is unavailable");
    }
}
