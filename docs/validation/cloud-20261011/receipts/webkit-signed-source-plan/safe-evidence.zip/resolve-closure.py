"""Native apt simulation on already authenticated NEW metadata; no payload download."""
import datetime,hashlib,json,os,re,subprocess
from pathlib import Path
P=Path(__file__).parent;M=Path('/tmp/rct-webkit-signed-metadata-20261012')
ENV={'PATH':'/usr/sbin:/usr/bin:/sbin:/bin','LANG':'C','LC_ALL':'C'}
names=['libgles2','libgraphene-1.0-0','libgtk-4-1','libharfbuzz-icu0','libhyphen0','libmanette-0.2-0','libwoff1']
index=M/'lists/deb.debian.org_debian_dists_trixie_main_binary-amd64_Packages'
records={}
with index.open() as f:
 row={};key=None
 for line in f:
  if not line.strip():
   if row.get('Package'):records[row['Package']]=row
   row={};key=None
  elif line.startswith((' ','\t')):
   if key:row[key]+='\n'+line.rstrip()
  elif ': ' in line:
   key,value=line.rstrip().split(': ',1);row[key]=value
if row.get('Package'):records[row['Package']]=row
rootpins=[name+'='+records[name]['Version'] for name in names]
options=['-o','Dir::Etc::sourcelist='+str(M/'sources.list'),'-o','Dir::Etc::sourceparts=-','-o','Dir::State::lists='+str(M/'lists'),'-o','Dir::Cache::pkgcache=','-o','Dir::Cache::srcpkgcache=']
argv=['/usr/bin/apt-get']+options+['--simulate','--no-install-recommends','--no-upgrade','install']+rootpins
r=subprocess.run(argv,env=ENV,capture_output=True,text=True,timeout=30)
text=r.stdout+r.stderr
selected=[]
for line in r.stdout.splitlines():
 if not line.startswith('Inst '):continue
 match=re.fullmatch(r'Inst (\S+)(?: \[([^]]+)\])? \((\S+).*\)',line)
 assert match,line
 name,old,version=match.groups();candidate=records[name.split(':')[0]];assert candidate['Version']==version
 selected.append({'package':name,'version':version,'architecture':candidate['Architecture'],'old_installed_version':old,'download_bytes':int(candidate['Size']),'declared_installed_bytes':int(candidate['Installed-Size'])*1024,'official_pool_filename':candidate['Filename'],'package_sha256':candidate['SHA256'],'depends':candidate.get('Depends'),'pre_depends':candidate.get('Pre-Depends'),'provides':candidate.get('Provides'),'replaces':candidate.get('Replaces'),'breaks':candidate.get('Breaks')})
count=re.findall(r'(\d+) upgraded, (\d+) newly installed, (\d+) to remove and (\d+) not upgraded',r.stdout)
receipt={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'native_exit':r.returncode,'argv':argv,'pinned_roots':rootpins,'selected':selected,'count_summary':count,'remove_operations_present':bool(re.search(r'^Remv ',r.stdout,re.M)),'unresolvable_dependency_error':bool(re.search('Unable to|unmet dependencies|held broken packages',text)),'warning_count':len(re.findall(r'^W:',text,re.M)),'stderr_or_apt_sources_config_credentials_not_published':True,'simulated_only_no_download_extraction_or_systemmutation':True}
(P/'apt-simulation.safe.json').write_text(json.dumps(receipt,indent=2)+'\n')
if r.returncode!=0:raise RuntimeError('APT_METADATA_SIMULATION_FAILED')
assert count and count[0][0]=='0' and count[0][2]=='0' and not receipt['remove_operations_present']
assert all(row['old_installed_version'] is None for row in selected)
installed=subprocess.run(['/usr/bin/dpkg-query','-W','-f','${binary:Package}\t${Version}\t${Architecture}\t${Status}\n'],env=ENV,capture_output=True,text=True,timeout=10)
assert installed.returncode==0
host=[]
for line in installed.stdout.splitlines():
 fields=line.split('\t')
 if len(fields)==4 and fields[3]=='install ok installed':host.append({'package':fields[0],'version':fields[1],'architecture':fields[2]})
(P/'host-installed-public-package-versions.safe.json').write_text(json.dumps({'packages':host,'private_config_or_environment_read':False},indent=2)+'\n')
download=sum(row['download_bytes'] for row in selected);declared=sum(row['declared_installed_bytes'] for row in selected)
plan={'status':'SIGNED_EXACT_PACKAGE_CLOSURE_SOURCE_READY','roots':names,'closure':selected,'exact_archive_download_bytes':download,'exact_sum_vendor_declared_installed_bytes':declared,'actual_extracted_file_bytes_blocks_modes_and_count':'UNKNOWN; library payload download/extraction not yet granted','future_own_DSO_directory':'/tmp/rct-webkit-native-deps-20261012','full_package_extraction_proposal':'Retain standard Debian hierarchy and public resources/DSOs; never execute maintainer scripts or mutate host dpkg state','future_dependency_path_scope':'WebKit child only; add own usr/lib/x86_64-linux-gnu and lib/x86_64-linux-gnu to accepted child env before vendor wrapper; do not alter Node, Chromium, JVM, global environment or browser cache','wrapper_effective_environment_constraint':'Genuine MiniBrowser wrapper overwrites LD_LIBRARY_PATH with bundle lib/sys/lib; explicit env alone is insufficient. Must choose reviewed ordinary loader --library-path for exact WPE/GTK child binaries or standard loader-path mediation preserving native launcher semantics, or report representation blocker. NO wrapper/cache patch approved.','host_ABI_compatibility':'Native apt exact7 simulation resolves against installed Debian13 status with0upgrades/removals; actual new DSO ELF/version symbols and loader proof remain NOT_RUN until reviewed payload grant','capacity':{'new_archive_bytes':download,'vendor_declared_installed_bytes':declared,'metadata_already_charged_bytes':sum(p.stat().st_blocks*512 for p in M.rglob('*') if p.is_file()),'actual_extraction_allocated_upper_bound':'UNKNOWN pending package tar metadata; no invented exact blocks'},'signature_index_receipt':str(P/'signed-index-authenticity.safe.json'),'browser_or_actual_client':'NOT_RUN'}
(P/'package-closure-plan.safe.json').write_text(json.dumps(plan,indent=2)+'\n')
print(json.dumps({'selected_packages':len(selected),'native_apt_simulation':r.returncode,'upgrades':0,'removals':0,'exact_archive_bytes':download,'declared_installed_bytes':declared,'wrapper_overwrites_LD_path':True,'payload_or_browser':'NOT_RUN'}))
