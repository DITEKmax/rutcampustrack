"""Independent source/receipt checks. No runner imports, children, env reads or network."""
import ast
import copy
import hashlib
import json
from pathlib import Path
import re
from types import SimpleNamespace
import zipfile

HERE = Path(__file__).parent
AUTHOR = Path('/workspace/scratch/rct-validation/host_runtime_prepare')
NEW = AUTHOR / 'guard-corrections'
ROOT_DOC = Path('/workspace/rutcampustrack/docs/validation/cloud-20261011')


def sha(data):
    return hashlib.sha256(data).hexdigest()


def identity(path):
    data = path.read_bytes()
    return {'path': str(path), 'sha256': sha(data), 'bytes': len(data)}


def dump(node):
    return ast.dump(node, include_attributes=False)


def definition(tree, name):
    return next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == name)


def rejects(call):
    try:
        call()
    except ValueError:
        return True
    raise AssertionError('Expected validation rejection')


manifests = []
for relative, expected, count in [
    ('manifest.json', 'fac7de9671ce6338b0e28ddd8745918bb04cd2816cd708861685e2d4f3f521cf', 29),
    ('renderer-addendum-manifest.json', '8159e470b37267bb2e2142e5e772eb0b925e83b50f82a68cfb0842ba28389287', 6),
    ('guard-corrections/manifest.json', '04e6355b92c0cd24a6c6b574bde5099de2a26a4b7d87caaf08c9c8c71f4044ba', 13),
]:
    path = AUTHOR / relative
    item = identity(path)
    assert item['sha256'] == expected
    manifest = json.loads(path.read_text())
    assert len(manifest['files']) == count
    links = []
    for row in manifest['files']:
        target = Path(row['path'])
        actual = identity(target)
        assert actual['bytes'] == row['bytes'] and actual['sha256'] == row['sha256']
        if target.is_symlink():
            links.append({'path': str(target), 'target': str(target.readlink()),
                          'type': 'synthetic control fixture; content hash follows link'})
    manifests.append({**item, 'file_count': count, 'all_contents_byte_exact': True,
                      'symlink_fixtures': links})

# Root transfer of the original review must preserve exact original REPORT bytes.
original_review = ROOT_DOC / 'receipts/host-runtime-review-original'
original_manifest = json.loads((original_review / 'immutable-review-manifest.json').read_text())
original_index = json.loads((original_review / 'original-byte-index.json').read_text())
report_row = next(r for r in original_manifest['safe_publishable_receipts'] if r['path'] == 'REPORT.md')
report = identity(original_review / 'REPORT.md')
assert report['sha256'] == report_row['sha256'] and report['bytes'] == report_row['bytes']
with zipfile.ZipFile(original_review / 'immutable-original-receipts.zip') as archive:
    candidates = [n for n in archive.namelist() if n == 'REPORT.md' or n.endswith('/REPORT.md')]
    assert len(candidates) == 1
    assert archive.read(candidates[0]) == (original_review / 'REPORT.md').read_bytes()
assert next(r for r in original_index['files'] if r['path'] == 'REPORT.md')['original_sha256'] == report['sha256']

old_path, new_path = AUTHOR / 'safe-child-status.py', NEW / 'safe-child-status.py'
old_tree, new_tree = [ast.parse(p.read_text()) for p in (old_path, new_path)]
controls_tree = ast.parse((NEW / 'guard-controls.py').read_text())
child_tree = ast.parse((NEW / 'harmless-child.py').read_text())
old_run, new_run = [definition(t, 'run') for t in (old_tree, new_tree)]
assert identity(old_path)['sha256'] == '178b194097865cd682ed60fed0ab7ee1e1720da7552c4f22e58eaa56cd8f5b09'
assert identity(new_path)['sha256'] == '8d39ad71b7d508b59f688d4ca1aa7e77b08ef002d3330cd48b4ea076c6d9d98a'

# Exact AST guards before environment processing and unchanged readiness/resource controls.
assert [dump(n) for n in old_run.body[:16]] == [dump(n) for n in new_run.body[:16]]
assert [dump(n) for n in old_run.body[19:30]] == [dump(n) for n in new_run.body[19:30]]
for name in ['digest', 'free', 'emit']:
    assert dump(definition(old_tree, name)) == dump(definition(new_tree, name))
assert dump(next(n for n in old_tree.body if isinstance(n, ast.ClassDef) and n.name == 'NoRedirect')) == dump(next(n for n in new_tree.body if isinstance(n, ast.ClassDef) and n.name == 'NoRedirect'))

class NormalizeReason(ast.NodeTransformer):
    def visit_Name(self, node):
        if node.id == 'stop_reason':
            node.id = 'stop'
        return node

old_try = next(n for n in old_run.body if isinstance(n, ast.Try))
new_try = next(n for n in new_run.body if isinstance(n, ast.Try))
assert [dump(n) for n in old_try.body[:2]] == [dump(n) for n in new_try.body[:2]]
old_loop = next(n for n in old_try.body if isinstance(n, ast.While))
new_loop = copy.deepcopy(next(n for n in new_try.body if isinstance(n, ast.While)))
added_stop = new_loop.body.pop(0)
assert dump(added_stop.test) == dump(ast.parse('stop_request.requested', mode='eval').body)
new_loop = NormalizeReason().visit(new_loop)
assert dump(old_loop) == dump(new_loop)

# Extract only pure path/environment definitions; never import either runner or run().
constant_names = {'OWN', 'PROXY_CA_NAMES', 'FIXED_OS_ENV', 'FORBIDDEN_ENV'}
selected = [n for n in new_tree.body if
            (isinstance(n, ast.Assign) and any(isinstance(t, ast.Name) and t.id in constant_names for t in n.targets))
            or (isinstance(n, ast.FunctionDef) and n.name in {'owned', '_safe_map', 'build_environment'})]
ns = {'Path': Path, 're': re}
exec(compile(ast.Module(body=selected, type_ignores=[]), '<pure-selected-guard-source>', 'exec'), ns)
old_ns = {'OWN': AUTHOR, 'Path': Path}
exec(compile(ast.Module(body=[definition(old_tree, 'owned')], type_ignores=[]), '<old-owned-source>', 'exec'), old_ns)
escape = AUTHOR / '..' / 'host_runtime_review' / 'CURRENT.json'
assert old_ns['owned'](escape).is_relative_to(AUTHOR)
assert not escape.resolve().is_relative_to(AUTHOR)
rejects(lambda: ns['owned'](escape))
rejects(lambda: ns['owned']('relative/path'))
rejects(lambda: ns['owned']('/tmp/outside-owned'))
assert ns['owned'](NEW / 'synthetic-cases/public.json') == (NEW / 'synthetic-cases/public.json').resolve()
for name in ['symlink-public', 'symlink-outside']:
    link = NEW / 'synthetic-cases' / name
    assert link.is_symlink()
    rejects(lambda: ns['owned'](link))
    rejects(lambda: ns['owned'](link / 'nested-member'))

# Exact old env-copy/update AST evaluated against synthetic-only inputs, no files/env lookup.
old_env_statements = [n for n in old_run.body if
                     (isinstance(n, ast.Assign) and any(isinstance(t, ast.Name) and t.id == 'env' for t in n.targets))
                     or (isinstance(n, ast.Expr) and isinstance(n.value, ast.Call)
                         and isinstance(n.value.func, ast.Attribute)
                         and isinstance(n.value.func.value, ast.Name) and n.value.func.value.id == 'env')]
parent_values = {'JAVA_TOOL_OPTIONS': '-Dsynthetic.only=1', 'JDK_JAVA_OPTIONS': '-Dsynthetic.only=2',
                 'SPRING_APPLICATION_JSON': '{"synthetic_only":true}',
                 'AWS_SECRET_ACCESS_KEY': 'synthetic-unrelated-only',
                 'HTTP_PROXY': 'http://synthetic-only.invalid:8080'}
public = {'SPRING_PROFILES_ACTIVE': 'prod', 'SERVER_ADDRESS': '127.0.0.1'}
private = {'GRPC_SECRET': 'synthetic-own-only'}
old_env_ns = {'os': SimpleNamespace(environ=parent_values), 'json': json,
              'env_path': SimpleNamespace(read_text=lambda: json.dumps(private)),
              'spec': {'public_environment': public}}
exec(compile(ast.Module(body=old_env_statements, type_ignores=[]), '<old-synthetic-environment>', 'exec'), old_env_ns)
assert all(name in old_env_ns['env'] for name in parent_values)

class SelectiveParent:
    def __init__(self, values):
        self.values = values
        self.lookups = []
    def __contains__(self, key):
        self.lookups.append(['contains', key])
        return key in self.values
    def __getitem__(self, key):
        self.lookups.append(['get', key])
        return self.values[key]

policy = {'parent_names': ['HTTP_PROXY'], 'public_names': list(public), 'private_names': list(private)}
synthetic_parent = SelectiveParent(parent_values)
clean = ns['build_environment'](synthetic_parent, public, private, policy)
assert set(clean) == set(ns['FIXED_OS_ENV']) | set(public) | set(private) | {'HTTP_PROXY'}
assert synthetic_parent.lookups == [['contains', 'HTTP_PROXY'], ['get', 'HTTP_PROXY']]
environment_rejections = []
def rejected_case(name, pub=None, priv=None, pol=None, parents=None):
    rejects(lambda: ns['build_environment'](parent_values if parents is None else parents,
                                           public if pub is None else pub,
                                           private if priv is None else priv,
                                           policy if pol is None else pol))
    environment_rejections.append(name)

for name in sorted(ns['FORBIDDEN_ENV'] | {'DYLD_INSERT_LIBRARIES', 'SPRING_MAIN_WEB_APPLICATION_TYPE'}):
    rejected_case('forbidden_public:' + name, pub={**public, name: 'synthetic'},
                  pol={**policy, 'public_names': [*public, name]})
rejected_case('private_java_tool_options', priv={**private, 'JAVA_TOOL_OPTIONS': '-XX:+UseG1GC'},
              pol={**policy, 'private_names': [*private, 'JAVA_TOOL_OPTIONS']})
rejected_case('unsupported_java_tool_options', pub={**public, 'JAVA_TOOL_OPTIONS': '-Dspring.profiles.active=dev'},
              pol={**policy, 'public_names': [*public, 'JAVA_TOOL_OPTIONS']})
rejected_case('overlapping_public_private', priv={**private, 'SERVER_ADDRESS': 'synthetic'},
              pol={**policy, 'private_names': [*private, 'SERVER_ADDRESS']})
rejected_case('parent_unrelated_credential', pol={**policy, 'parent_names': ['AWS_SECRET_ACCESS_KEY']})
rejected_case('duplicate_parent_selection', pol={**policy, 'parent_names': ['HTTP_PROXY', 'HTTP_PROXY']})
rejected_case('unsealed_public_name', pol={**policy, 'public_names': []})
rejected_case('unsealed_private_name', pol={**policy, 'private_names': []})
rejected_case('non_prod_profile', pub={**public, 'SPRING_PROFILES_ACTIVE': 'dev'})
for name in ['PATH', 'LANG', 'LC_ALL', 'HTTP_PROXY', 'SSL_CERT_FILE']:
    rejected_case('os_proxy_override:' + name, pub={**public, name: 'synthetic'},
                  pol={**policy, 'public_names': [*public, name]})
rejected_case('nul_value', pub={**public, 'SERVER_ADDRESS': 'synthetic\x00value'})
rejected_case('oversized_value', pub={**public, 'SERVER_ADDRESS': 's' * 8193})
rejected_case('oversized_map', pub={**public, **{'KEY' + str(i): 's' for i in range(129)}})
oversized_total = {**public, **{'KEY' + str(i): 's' * 8192 for i in range(8)}}
rejected_case('oversized_total', pub=oversized_total,
              pol={**policy, 'public_names': list(oversized_total)})
rejected_case('oversized_parent_value', parents={**parent_values, 'HTTP_PROXY': 's' * 8193})

# Ensure all seven existing public templates are compatible without reading private files.
public_template_controls = []
for item in json.loads((AUTHOR / 'host-service-specs.template.json').read_text()):
    dummy_private = {name: 'synthetic-own-only' for name in item['required_private_names']}
    own_policy = {'parent_names': [], 'public_names': list(item['public_environment']),
                  'private_names': list(dummy_private)}
    environment = ns['build_environment']({}, item['public_environment'], dummy_private, own_policy)
    assert environment['SPRING_PROFILES_ACTIVE'] == 'prod'
    public_template_controls.append({'service': item['service'], 'public_count': len(item['public_environment']),
                                     'private_name_count': len(dummy_private), 'synthetic_only_PASS': True})
assert len(public_template_controls) == 7

controls = json.loads((NEW / 'controls-result.json').read_text())
verification = json.loads((NEW / 'verification.json').read_text())
assert verification['actual_native_exit'] == 0 and verification['AST_all_three'] == 'PASS'
assert verification['synthetic_guard_results_sha256'] == identity(NEW / 'controls-result.json')['sha256']
assert verification['runner_before_sha256'] == identity(old_path)['sha256']
assert verification['runner_after_sha256'] == identity(new_path)['sha256']
rows = controls['rows']
assert rows['HOST-G02']['before']['old_native_status'] == 130
assert rows['HOST-G02']['before']['old_claimed_settled'] is True
assert rows['HOST-G02']['before']['actual_child_still_alive_at_claim'] is True
assert rows['HOST-G02']['after']['signal_count'] == 2
assert rows['HOST-G02']['after']['native_exit'] == -9
assert rows['HOST-G02']['after']['settled'] and rows['HOST-G02']['after']['idempotent_second_settlement']
assert rows['HOST-G02']['after']['actual_pid_absent'] and rows['HOST-G02']['failure_reports_unsettled']
for label in ['before', 'after']:
    recorded = next(r for r in verification['children_readback'] if r['stage'] == label)
    assert recorded['pid'] == rows['HOST-G02'][label]['pid']
    assert recorded['actual_proc_pid_absent_readback'] is True
    assert json.loads((NEW / 'synthetic-cases' / (label + '-ready.json')).read_text())['pid'] == recorded['pid']
false_grant = json.loads((NEW / 'new-false-grant-result.json').read_text())
assert false_grant['native_exit'] == 2 and false_grant['safe_status_only'] and not false_grant['child_started']
template = json.loads((NEW / 'root-grant.template.json').read_text())
assert template['runner_sha256'] == identity(new_path)['sha256']
assert all(template[key] is False for key in ['app_launch_authorized', 'source_frozen', 'tls_and_routes_reviewed', 'floor_reviewed'])
assert 'private_file_sha256' in template['environment_policy']

out = {
    'status': 'PASS_READ_ONLY_SOURCE_AND_RECEIPT_CHECKS',
    'manifests': manifests,
    'original_review_report': report,
    'source_files': [identity(p) for p in [old_path, new_path, NEW / 'guard-controls.py', NEW / 'harmless-child.py']],
    'AST_all_three': 'PASS',
    'preservation': {'pre_environment_old_guard_16_statements_exact': True,
                     'readiness_resource_old_11_statements_exact': True,
                     'digest_free_emit_NoRedirect_exact': True,
                     'Popen_and_STARTED_exact': True,
                     'whole_active_loop_exact_after_only_new_stop_check_and_reason_rename': True},
    'path_controls': {'old_lexical_escape_accepts': True, 'corrected_traversal_rejects': True,
                      'relative_and_outside_paths_rejected': True, 'owned_positive_resolved': True,
                      'existing_and_dangling_links_and_nested_members_rejected': True,
                      'foreign_contents_read': False},
    'environment_controls': {'exact_old_copy_AST_synthetic_counterexample': True,
                             'corrected_selective_parent_lookup_only': synthetic_parent.lookups,
                             'rejection_count': len(environment_rejections),
                             'rejections': environment_rejections,
                             'all_seven_public_template_positive_controls': public_template_controls,
                             'real_parent_environment_values_read': False,
                             'actual_private_runtime_environment_or_key_files_read': False},
    'G02_author_receipt_review': {'source_exact_AST_counterexample': True,
                                 'before_and_after_PID_marker_metadata_matches': True,
                                 'author_native_controller_exit': 0,
                                 'old_exact_cleanup_AST_SystemExit': 130,
                                 'old_full_runner_CLI_executed': False,
                                 'old_child_live_at_false_claim_then_owned_cleanup_confirmed': True,
                                 'corrected_real_harmless_child_two_signals_exit': -9,
                                 'corrected_idempotence_and_author_PID_readbacks_confirmed': True,
                                 'synthetic_never_terminal_unsettled': True,
                                 'reviewer_new_child_or_signal_execution': False},
    'false_grant_author_receipts': {'old_template_native_exit': 2, 'new_template_native_exit': 2,
                                   'child_started': False, 'safe_status_only': True,
                                   'new_template_false_four_grants_and_runner_SHA_verified': True},
    'reviewer_runtime': 'NOT_RUN; no JVM/apps/network/containers/keys/child execution',
}
(HERE / 'verification.safe.json').write_text(json.dumps(out, indent=2, ensure_ascii=False) + '\n')
print(json.dumps({'status': out['status'], 'original29_and_renderer6': 'all byte exact',
                  'correction13': 'all content byte exact; one intended symlink fixture recorded',
                  'environment_rejections': len(environment_rejections), 'positive_templates': 7,
                  'reviewer_child_runtime': 'NOT_RUN'}))
