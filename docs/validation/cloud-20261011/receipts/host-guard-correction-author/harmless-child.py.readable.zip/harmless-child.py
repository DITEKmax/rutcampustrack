"""Synthetic settlement child: no network, no credentials, no subprocesses."""
import json
import os
from pathlib import Path
import signal
import sys
import time

signal.signal(signal.SIGTERM, signal.SIG_IGN)
Path(sys.argv[1]).write_text(json.dumps({'pid': os.getpid()}))
time.sleep(4)
