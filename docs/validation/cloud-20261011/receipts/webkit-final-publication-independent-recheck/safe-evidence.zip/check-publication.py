"""Narrow seals/AST plus selected pure publication mocks; no runtime module imports."""
import ast
import copy
import datetime
import hashlib
import json
from pathlib import Path
import stat
import types
import zipfile

OUT=Path(__file__).parent
ROOT=OUT.parent
NEW=ROOT/'browser_webkit_native_publication_correction'
OLD=ROOT/'browser_webkit_native_deadline_correction'
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def seal(directory,expected):
    assert sha(directory/'manifest.json')==expected
    m=json.loads((directory/'manifest.json').read_text());members={}
    for row in m['files']:
        path=Path(row['path']);s=path.lstat()
        assert 'private' not in path.parts and stat.S_ISREG(s.st_mode)
        assert sha(path)==row['sha256']
        size=row.get('bytes',row.get('size'))
        if size is not None:assert s.st_size==size
        if 'mode' in row:assert stat.S_IMODE(s.st_mode)==(int(row['mode'],0) if isinstance(row['mode'],str) else row['mode'])
        members[row.get('name',row.get('relative_path'))]=row['sha256']
        if path.suffix=='.py':ast.parse(path.read_text())
    members['manifest.json']=expected
    return members
members=seal(NEW,'5de233d48c60770701384c5464df6a58d4bb5210632ac3146ec7afdffff46e9f')
old=seal(OLD,'7dfe76bcf892651a4b8265f64f2ef14bb75df500052157c8bffde4f99eadeeb4')
original=seal(ROOT/'browser_webkit_native_prepare','5de31368e2d41d803d54250487d83e5749728d385f38375e0db489fe7fbc01d8')
review=seal(ROOT/'native_deadline_recheck','734f404baafd61ea0198af6839a84e439a19391301c57904160e34aa0cf8b569')
zpath=NEW/'publication-correction.source.safe.zip'
assert sha(zpath)=='fab03bc73dd779ecb883a7915d43e9e719ea1726a0aa2777139b6f3be673dd9f'
with zipfile.ZipFile(zpath) as z:
    assert len(z.infolist())==len(members) and len(z.namelist())==len(set(z.namelist()))
    for info in z.infolist():
        assert info.filename in members and '/' not in info.filename
        assert hashlib.sha256(z.read(info)).hexdigest()==members[info.filename]
    assert z.testzip() is None
unchanged=[]
for name in old:
    if name.endswith('.py') and name!='validate-native.py':
        assert sha(NEW/name)==sha(OLD/name);unchanged.append(name)
def tree(path):return ast.parse(path.read_text())
def main(t):return next(n for n in t.body if isinstance(n,ast.FunctionDef) and n.name=='main')
def publication(t):
    body=next(n for n in main(t).body if isinstance(n,ast.Try)).body
    index=next(i for i,n in enumerate(body) if isinstance(n,ast.Expr) and isinstance(n.value,ast.Call) and ast.unparse(n.value.func)=='out.save' and isinstance(n.value.args[0],ast.Constant) and n.value.args[0].value=='native-validation.safe.json')
    return body,index
ot=tree(OLD/'validate-native.py');nt=tree(NEW/'validate-native.py')
nb,ni=publication(nt);ob,oi=publication(ot)
assignment,gate,save=nb[ni-2:ni+1]
assert isinstance(assignment,ast.Assign) and ast.unparse(assignment.targets[0])=='final_proof'
assert ast.unparse(gate)=='gates.require_fresh(stop)'
assert isinstance(save.value.args[1],ast.Name) and save.value.args[1].id=='final_proof'
assert ast.dump(assignment.value,include_attributes=False)==ast.dump(ob[oi].value.args[1],include_attributes=False)
assert any(isinstance(n,ast.Call) and ast.unparse(n.func)=='driver.resources' for n in ast.walk(assignment))
assert not any(isinstance(n,ast.Call) and ast.unparse(n.func)=='driver.resources' for n in ast.walk(save))
normalized=copy.deepcopy(nt);body,index=publication(normalized)
body[index].value.args[1]=copy.deepcopy(body[index-2].value)
body.pop(index-2)
assert ast.dump(normalized,include_attributes=False)==ast.dump(ot,include_attributes=False)

fresh=next(n for n in tree(NEW/'use-gates.py').body if isinstance(n,ast.FunctionDef) and n.name=='require_fresh')
stop=datetime.datetime(2026,10,12,18,0,tzinfo=datetime.timezone.utc)
clock={'now':stop}
class Clock:
    @classmethod
    def now(cls,tz):return clock['now']
good={'/workspace_available':10000000000,'/tmp_available':10000000000,'shared_memory':3000000000,'shared_limit':17179869184,'rss':12000000}
globals={'os':types.SimpleNamespace(getuid=lambda:1000,getgid=lambda:1000),'resources':lambda:dict(good),'datetime':types.SimpleNamespace(datetime=Clock,timezone=datetime.timezone)}
exec(compile(ast.Module(body=[fresh],type_ignores=[]),'selected pure gate function','exec'),globals)
fresh_gate=globals['require_fresh']
controls=[]
for label,nodes,delay,already_expired,should_save,late in [
    ('OLD full expression reproduces late PASS',ob[oi-1:oi+1],2,False,True,True),
    ('NEW full payload resource delay denies before PASS',nb[ni-2:ni+1],2,False,False,False),
    ('NEW full payload fresh positive',nb[ni-2:ni+1],0,False,True,False),
    ('NEW already expired denies',nb[ni-2:ni+1],0,True,False,False),
]:
    clock['now']=stop+datetime.timedelta(seconds=1 if already_expired else -1);events=[]
    def resources(delay=delay):clock['now']+=datetime.timedelta(seconds=delay);return {'public_synthetic_metadata':True}
    def publish(name,payload):events.append({'name':name,'status':payload['status'],'at_or_after_stop':clock['now']>=stop,'utc':clock['now'].isoformat()})
    namespace={'gates':types.SimpleNamespace(require_fresh=fresh_gate),'stop':stop,'driver':types.SimpleNamespace(resources=resources),'out':types.SimpleNamespace(save=publish),'g':{'source_manifest_sha256':'public-synthetic','extraction_receipt_sha256':'public-synthetic'},'results':[{'pass':True,'target':'public-synthetic-'+str(i)} for i in range(43)],'vendor':[],'identities':[],'selected':[]}
    denied=False
    try:exec(compile(ast.Module(body=nodes,type_ignores=[]),'full actual selected publication','exec'),namespace)
    except RuntimeError:denied=True
    assert bool(events)==should_save
    if events:assert events[0]['at_or_after_stop']==late
    else:assert denied
    controls.append({'case':label,'pass':True,'events':events,'denied':denied,'actual_native_publication':False,'synthetic43_success_case_metadata':'NOT_ABI_PROOF'})
author=json.loads((NEW/'publication-controls.safe.json').read_text())
assert author['count']==len(author['checks'])==4 and all(r['pass'] for r in author['checks'])
for name in ['source-controls.safe.json','caller-controls.safe.json','copy-controls.safe.json','deadline-controls.safe.json']:
    receipt=json.loads((NEW/name).read_text());assert all(r['pass'] for r in receipt['checks'])
result={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'verdict':'APPROVE_SOURCE','closed_finding':'T005-GRANT-USE-TIME','scope':'ONLY finalpublication correction; previous3points inherit narrow734f closure','input_manifest_sha256':sha(NEW/'manifest.json'),'input_zip_sha256':sha(zpath),'input_files':len(members)-1,'zip_members':len(members),'original5de25_7dfe28_review734f5_preserved':True,'unchanged_python_helpers':unchanged,'native_caller_AST_equal_after_exact_three_statement_transform':True,'proof_payload_AST_equal_old_original_save_argument':True,'no_postclock_driver_resource_call':True,'assignment_line':assignment.lineno,'fresh_gate_line':gate.lineno,'save_line':save.lineno,'reviewer_selected_full_controls':controls,'author134_pure_controls_inspected_not_rerun':True,'actual_extract_loader_ABI_dlopen_browser_Docker_network_private_reads':False,'runtime_target_modules_imported':False}
(OUT/'publication-recheck.safe.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'verdict':'APPROVE_SOURCE','finding_closed':'T005-GRANT-USE-TIME','selected_full_controls':4,'remaining_blockers':0,'native':'NOT_RUN','new_members':len(members)-1,'zip_members':len(members)}))
