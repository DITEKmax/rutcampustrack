# P06 one-test SOURCE packet

One authorized InternalSessionAdmissionIT method plus two privatehelpers in ownfull481WT/branch codex/session-durability-validation-20261013. No otherfile/product/config/contract/lock/workflow/runner change. Removingtwoinsertions restoreswholeoldSource ed055 exactly; oldassertions/imports/fixturedefaults unchanged. Native/compiler/formatter NOT_RUN.

Method proves intendedfinitechain: sameownSTUDENT A/B realPG/RSA; revokeA; NEW DataSource/JDBC/transactionmanager/authority/admission/controller on SAMEPGstate/key; A bearer/refreshdenied, Bownsignedidentity/refreshpositive. PauseexactexistingnonreusablePOSTGRESfixture withtest-local2secondconnect/sockettimeouts, expectotherwisevalidB503/no-store/noJWT andrefreshAUTHORITY_UNAVAILABLE. Finallyunpauseevenuncertainpauseresponse; recoveryBpositive/Anegative; RAMstate/event/JTI tupleunchanged andknownBrefreshstillworks. Rawvalues neverlogged/written/assertionrendered bynewcode; rawframeworklogs/XML requireprivateclosedcollector later.

Full Source/proof/pins/oneclass-method nativeproposal/singlemeaningfulfaultproposal in READY.safe.json. Sensitivecheckproposal only: temporary AUTHORITY_UNAVAILABLE→INVALID_SESSION mapper fault shouldfailprecise503outageassertion afterpositivecontrols, then restoreexactSource→GREEN. Nofaultwritten/granted.

IndependentSource review, requiredtargetedformat/compile/selectedIT andfreshDocker/resource/platformgrant next. ExistingPGtestfixture lifecycle only; no newstand/shareddata/reset. ActualDBtimeout/Dockercleanup behavior remainsUNKNOWN. Thisisfreshauthority reconstruction+MockMvc productionreceiver, notfullOSAuthprocessrestart/Gateway/client/allroles/P06closure.
