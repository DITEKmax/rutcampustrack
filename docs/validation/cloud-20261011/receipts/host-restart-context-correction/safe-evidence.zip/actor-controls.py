import ast,json,types
from pathlib import Path
P=Path(__file__).parent
restart=P.name.startswith('current_host_restart')
checks=[]
for name in (['docker-up-restart.py','run-mongo-restart.py','run-service-restart.py'] if restart else ['download-headers.py']):
 tree=ast.parse((P/name).read_text());main=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='main')
 gate=main.body[0]
 nodes=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='verify_execution_actor']+[gate]
 selected=compile(ast.Module(body=nodes,type_ignores=[]),'selected pre-private actor gate','exec')
 for uid,gid,expected in [(1000,1000,True),(0,1000,False),(1000,0,False),(999,1000,False),(1000,999,False)]:
  ns={'os':types.SimpleNamespace(getuid=lambda:uid,getgid=lambda:gid)};ok=False
  try:exec(selected,ns);ok=True
  except RuntimeError:pass
  assert ok==expected,(name,uid,gid)
  checks.append({'runner':name,'actor_uid':uid,'actor_gid':gid,'expected_accept':expected,'pass':True,'private_grant_reads':0,'native_children':0})
(P/'actor-controls.safe.json').write_text(json.dumps({'status':'PASS_SELECTED_PRE_PRIVATE_ACTOR_GATE','count':len(checks),'checks':checks,'actual_private_reads_or_runtime':False},indent=2)+'\n')
print(json.dumps({'actor_controls':len(checks),'private_reads':0,'runtime':False}))
