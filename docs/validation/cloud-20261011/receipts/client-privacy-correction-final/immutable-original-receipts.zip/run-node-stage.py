import datetime, errno, hashlib, json, os, stat, types, sys, subprocess
from pathlib import Path
BASE=Path('/workspace/scratch/rct-validation/client_real_acceptance/privacy-correction-eb')
WT=Path('/workspace/rct-worktrees/client-privacy-boundary-eb')
GUARD=Path('/workspace/scratch/rct-validation/guard_proc_race_correction/bounded-child.py')
grant_path=Path(sys.argv[1]);stage=sys.argv[2]
g=json.loads(grant_path.read_text())
assert stat.S_IMODE(grant_path.stat().st_mode)==0o600 and g['authorized'] is True
assert subprocess.check_output(['git','-C',str(WT),'rev-parse','HEAD'],text=True).strip()==g['source_sha']
assert hashlib.sha256(GUARD.read_bytes()).hexdigest()==g['guard_sha256']
stop=datetime.datetime.fromisoformat(g['issued_at'])+datetime.timedelta(seconds=g['deadline_seconds'])
seconds=int((stop-datetime.datetime.now(datetime.timezone.utc)).total_seconds())
assert seconds>0, 'Expired grant: no launch'
commands={
 'red':['node','--max-old-space-size=512','check-artifact-privacy.mjs','--unprotected'],
 'green':['node','--max-old-space-size=512','check-artifact-privacy.mjs'],
 'format':['node','--max-old-space-size=512',str(BASE/'format-seven.cjs')],
 'types':['node','--max-old-space-size=512','/workspace/rutcampustrack/frontends/node_modules/typescript/bin/tsc','--noEmit','--project',str(BASE/'tsconfig.scoped.json')],
}
assert stage in commands
out=BASE/(stage+'-attempt01');out.mkdir(mode=0o700,exist_ok=False)
os.umask(0o077)
guard=types.ModuleType('reviewed_owned_guard');guard.__file__=str(GUARD)
exec(compile(GUARD.read_bytes(),str(GUARD),'exec'),guard.__dict__)
latest={}
def status(value):
 latest.clear();latest.update(value)
 (out/'process.safe.json').write_text(json.dumps(value,indent=2)+'\n')
def observe():
 if datetime.datetime.now(datetime.timezone.utc)>=stop:return 'ABSOLUTE_GRANT_DEADLINE'
 for filesystem in ['/workspace','/tmp']:
  v=os.statvfs(filesystem)
  if v.f_bavail*v.f_frsize<g['disk_floor_bytes']:return 'DISK_FLOOR'
 if int(Path('/sys/fs/cgroup/memory.current').read_text())>=g['shared_stop_bytes']:return 'SHARED_MEMORY_STOP'
 table=guard.process_table();rss=0
 for row in latest.get('members_including_Z',[]):
  current=table.get(row['pid'])
  if current is None or current['start_ticks']!=row['start_ticks']:continue
  try:lines=Path('/proc',str(row['pid']),'status').read_text().splitlines()
  except OSError as e:
   if e.errno in (errno.ENOENT,errno.ESRCH):continue
   raise
  rss+=next((int(line.split()[1])*1024 for line in lines if line.startswith('VmRSS:')),0)
 if rss>g['owned_rss_stop_bytes']:return 'OWN_RSS_STOP'
 size=sum(p.stat().st_blocks*512 for p in BASE.rglob('*') if p.is_file() and not p.is_symlink())
 if size>g['cache_stop_bytes']:return 'OWN_CACHE_STOP'
 return None
env=os.environ.copy()
for key in ['DEBUG','DEBUG_FILE','PWDEBUG','PW_TEST_REPORTER','PLAYWRIGHT_NO_COPY_PROMPT','PW_TEST_DISABLE_ERROR_CONTEXT','NODE_OPTIONS']:env.pop(key,None)
env.update(PWTEST_CACHE_DIR=str(BASE/'transform-cache'),RCT_E2E_CONTROL_RECEIPT_PATH=str(out/'controls.safe.json'))
result=guard.run_owned(commands[stage],str(WT/'tests/e2e'),env,deadline_seconds=seconds,observe=observe,status=status)
result.update(source=g['source_sha'],stage=stage,argv=commands[stage],absoluteStop=stop.isoformat())
(out/'terminal.safe.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'stage':stage,'nativeExit':result['native_exit'],'settled':result['settled'],'allOwnedReaped':result['all_owned_processes_reaped'],'childPid':result['direct_pid'],'knownOwnedBirths':len(result['known_owned_identities'])}))
raise SystemExit(0 if result['settled'] and result['supervision_error_type'] is None else 1)
