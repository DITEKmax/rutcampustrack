import { test } from '/workspace/rutcampustrack/tests/e2e/fixtures/mobile-dataset';
import { FocusObserver } from '/workspace/scratch/rct-validation/client_real_acceptance/focused3-preparation-5ced-r1/observer';

let observer: FocusObserver | undefined;

// Register against the SAME protected test object before loading the unchanged source tests.
test.beforeEach(async ({ page, dataset, teachingInstant }, info) => {
  if (!teachingInstant) throw new Error('Focused FIRST3 teaching instant is required');
  // Date shares the dataset/domain day; real timers and backend security time remain enabled.
  await page.clock.setFixedTime(teachingInstant);
  observer = new FocusObserver(page, dataset, info);
  observer.start();
});

test.afterEach(async ({}, info) => {
  const current = observer;
  observer = undefined;
  if (current) await current.finish(info);
});

// Runtime require preserves hook registration order. No test/assertion body is copied or replaced.
require('/workspace/rutcampustrack/tests/e2e/specs/mobile-real-server.spec.ts');
