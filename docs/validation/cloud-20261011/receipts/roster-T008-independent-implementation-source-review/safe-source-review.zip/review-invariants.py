from pathlib import Path
import hashlib,json,os,re,subprocess,zipfile
P=Path(__file__).parent;W=Path('/workspace/rct-worktrees/roster-academic-auth-backend');A=Path('/workspace/scratch/rct-validation/roster_academic_auth_backend')
BASE='48124f576f51cc62fbdd95c7908b61d587f9e36d';HEAD='895d404f23beb47c93ca210be6f9161cd09945ec'
def git(*args):return subprocess.check_output(['git','-C',str(W),*args])
def sha(b):return hashlib.sha256(b).hexdigest()
assert git('rev-parse','HEAD').decode().strip()==HEAD and not git('status','--porcelain')
files=git('diff','--name-only',BASE,HEAD).decode().splitlines();assert len(files)==13
rows=[]
for f in files:
 b=(W/f).read_bytes();assert git('show',HEAD+':'+f)==b
 rows.append({'path':f,'bytes':len(b),'sha256':sha(b),'git_mode':git('ls-tree',HEAD,'--',f).decode().split()[0]})
def text(f):return (W/f).read_text()
def old(f):return git('show',BASE+':'+f).decode()
checks={}
f='proto/academic.proto';s=text(f)
s=s.replace('  // Fresh own-group journal admission, separate from the Schedule-only state RPC.\n  rpc GetHeadmanJournalSemesterState (HeadmanJournalSemesterStateRequest) returns (SemesterStateResponse);\n','',1)
s=s.replace('message HeadmanJournalSemesterStateRequest {\n  int64 group_id = 1;\n  int64 semester_id = 2;\n}\n\n','',1)
checks['proto_only_additive_method_and_group1_semester2_request']=s==old(f)
academic='services/academic-service/academic-app/src/main/java/ru/rutcampustrack/academic/grpc/'
attendance='services/attendance-service/attendance-app/src/main/java/ru/rutcampustrack/attendance/'
f=academic+'AcademicGrpcServiceImpl.java';s=text(f)
start=s.index('    /**\n     * Uncached journal state for the exact signed actor,')
end=s.index('    /** Uncached authoritative semester state used by server-side write guards. */',start)
method=s[start:end];checks['academic_only_additive_handler_all_old_methods_byte_exact']=s[:start]+s[end:]==old(f)
checks['same_journal_capability_or']=('!assistantPermissionAuthority.allows(actor, groupId, "VIEW_STATS")\n                    && !assistantPermissionAuthority.allows(actor, groupId, "MARK_ATTENDANCE")' in method)
checks['current_active_group_and_uncached_nondeleting_global_semester']=all(x in method for x in ['.findById(groupId)','filter(Group::isActive)','.findByIdUncached(semesterId)','filter(value -> value.getDeletionPhase() == null)'])
checks['archive_release_transition_write_blocked']=all(x in method for x in ['semester.isArchived()','semester.isReleasePending()','SemesterTransition.NONE','.setWriteBlocked('])
f=academic+'StudentHomeworkGrpcIdentityInterceptor.java';s=text(f)
s=s.replace('    static final String HEADMAN_JOURNAL_STATE_METHOD_NAME =\n            AcademicGrpcServiceGrpc.SERVICE_NAME + "/GetHeadmanJournalSemesterState";\n','',1)
s=s.replace('&& !HEADMAN_STATS_SCOPE_METHOD_NAME.equals(methodName)\n                && !HEADMAN_JOURNAL_STATE_METHOD_NAME.equals(methodName)', '&& !HEADMAN_STATS_SCOPE_METHOD_NAME.equals(methodName)',1)
checks['identity_only_additive_exact_method_existing_validation_byte_exact']=s==old(f)
f=attendance+'grpc/AcademicGrpcClient.java';s=text(f);start=s.index('    /** Journal state using the original signed actor');end=s.index('    public ru.rutcampustrack.academic.grpc.HeadmanStatsScopeResponse resolveHeadmanStatsScope(',start)
checks['client_only_additive_wrapper_old_calls_byte_exact']=s[:start]+s[end:]==old(f)
wrapper=s[start:end];checks['original_actor_token_and_deadline_and_response_id']=all(t in wrapper for t in ['requestContext.getInternalToken()','metadata.put(INTERNAL_TOKEN, token)','withDeadlineAfter(3, TimeUnit.SECONDS)','response.getId() != semesterId'])
checks['typed_http_error_mapping']=all(t in wrapper for t in ['case INVALID_ARGUMENT','case NOT_FOUND','case PERMISSION_DENIED','case UNAUTHENTICATED','HttpStatus.UNAUTHORIZED'])
f=attendance+'report/HeadmanStatsService.java';s=text(f).replace('academicGrpcClient.getHeadmanJournalSemesterState(\n                                groupId, capture.context.semesterId())','academicGrpcClient.getSemesterState(capture.context.semesterId())',1);checks['stats_only_state_call_changed_existing_VIEW_STATS_gate_exact']=s==old(f)
f=attendance+'report/ReportService.java';s=text(f).replace('headmanActor\n                        ? academicGrpcClient.getHeadmanJournalSemesterState(\n                                lesson.getGroupId(), lesson.getSemesterId())\n                        : null','headmanActor ? academicGrpcClient.getSemesterState(lesson.getSemesterId()) : null',1);checks['report_only_state_call_changed_existing_teacher_journal_guards_exact']=s==old(f)
policy=[academic+'AssignmentCloseServiceIdentityInterceptor.java','services/shared/shared-security/src/main/java/ru/rutcampustrack/shared/security/grpc/ServiceIdentityServerInterceptor.java','services/shared/shared-security/src/main/java/ru/rutcampustrack/shared/security/grpc/ServiceTokenCallCredentials.java']
checks['directed_schedule_tls_policy_files_byte_exact']=all(text(f)==old(f) for f in policy)
changed_old_tests=[f for f in files if '/src/test/' in f and f not in git('diff','--diff-filter=A','--name-only',BASE,HEAD).decode().splitlines()]
count=0
for f in changed_old_tests:
 restored,n=re.subn(r'getHeadmanJournalSemesterState\([^,\n]+, ([^\n)]+)\)',r'getSemesterState(\1)',text(f));count+=n;assert restored==old(f)
checks['four_old_test_files_five_stubs_only_assertions_byte_exact']=len(changed_old_tests)==4 and count==5
assert all(checks.values()),[k for k,v in checks.items() if not v]
red=json.loads((A/'red01-accepted.safe.json').read_text());assert sha((A/'red01-accepted.safe.json').read_bytes())=='94d2fc79d44979bdbdece28893726e2af244656a425631fcaca03197618bf73c'
assert red['accepted_causal_red'] is True and red['actual_closed_status']=='UNAUTHENTICATED'
result={'verdict':'APPROVE_SOURCE','producer_base':BASE,'frozen_review_commit':HEAD,'source_rows':rows,'checks':checks,'original_causal_red_receipt_sha256':'94d2fc79d44979bdbdece28893726e2af244656a425631fcaca03197618bf73c','product_postfix_native':'NOT_RUN','test_quality':{'academic_real_netty':'Actual shared-secret/signed-JWT/new-method admission; retained old Schedule/TLS rejection and zero repository controls; unsigned/forged/foreign/invalid/missing and archive/release/deleting negatives. Authority repositories mocked, not live SQL proof.','fresh_SQL':'Real authority repositories with cleared persistence context after grant/assistant/group writes; MARK_ATTENDANCE-only journal allowed while stats denied; VIEW_STATS allowed; unknown/manage-excuses/inactive/revoked/foreign-group/forged-headman/invalid/missing/inactive-group/headman-revoke denied. Archived INSERT is legitimate fixture and transaction rolls back; no schema/trigger bypass. Direct handler context, not actual wire/HTTP.','attendance_real_netty':'Original signed token compared boolean-only; actor/group/semester serialization and response-ID mismatch tested; absent/forged/status401/400/404/403/503 mapping covered. Server uses real validator and old directed TLS policy, lightweight new service receiver.'},'mutation_source_plan':'Meaningful selected mutation changes only product wrapper new RPC/new request to existing GetSemesterState/SemesterStateRequest, retaining original JWT/deadline/maps/test. Real receiver old exact-method TLS policy should cause unchanged positive wire test to fail401; compilation/infra/mock-null failures are not sensitivity. Actual TLS description after status mapping is source-bound unless separately safely observed; do not invent runtime cause metadata.','limits':['No current native compile/green/mutation/real roster200 or client-family acceptance from source.','Global semesters legitimately have no per-group ownership relation; new response requires existing current own-group journal capability and nondeleting semester. No invented ownership or VIEW_JOURNAL permission.','Current SQL revocation controls use same test transaction plus persistence-context clear; later separate real calls/runtime remain required.','Test/server finally termination calls retain outer bounded ownership/reap requirement; no test-alone cleanup or hard resource isolation claim.','Next formatter revision requires mechanical equivalence to this frozen13-path semantic source and exact final native-source receipts.'],'findings':[]}
os.umask(0o077)
with (P/'review.safe.json').open('x') as f:json.dump(result,f,indent=2);f.write('\n')
with (P/'REPORT.md').open('x') as f:f.write('APPROVE_SOURCE: frozen895d404f,13paths781+/8-. Independent whole inverses prove old proto definitions, all old Academic handlers/client wrappers, canonical JWT interceptor validation, old Schedule TLS/service credentials and existing report/stats guards byte exact. New signed own-group journal RPC uses existing VIEW_STATS OR MARK_ATTENDANCE, active current group and uncached nondeleting global semester; archive/release/transition write blocking preserved.\n\nThree new wire/SQL tests are meaningful and complementary; five old stubs change method arguments only, old assertions byte exact. Old-call product-wrapper mutation selection is sensitive at the real receiver boundary; actual green/mutation/compile and roster200 still NOT_RUN. Original causal RED94d2 retained. No product/source/runtime/private data mutation by reviewer.\n')
files=[p for p in P.iterdir() if p.is_file()]
with (P/'manifest.safe.json').open('x') as f:json.dump({'verdict':'APPROVE_SOURCE','frozen_commit':HEAD,'files':[{'path':p.name,'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())} for p in sorted(files)]},f,indent=2);f.write('\n')
with zipfile.ZipFile(P/'safe-source-review.zip','x',zipfile.ZIP_DEFLATED) as z:
 for p in sorted(files)+[P/'manifest.safe.json']:z.write(p,p.name)
print(json.dumps({'verdict':'APPROVE_SOURCE','manifest_sha256':sha((P/'manifest.safe.json').read_bytes()),'zip_sha256':sha((P/'safe-source-review.zip').read_bytes()),'zip_bytes':(P/'safe-source-review.zip').stat().st_size,'source_checks':len(checks),'frozen_commit':HEAD}))
