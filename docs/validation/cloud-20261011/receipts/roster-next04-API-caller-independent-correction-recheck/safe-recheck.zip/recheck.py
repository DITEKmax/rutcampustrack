from pathlib import Path
import ast, hashlib, io, json, os, types, zipfile
OUT=Path(__file__).parent
OLD=Path('/workspace/scratch/rct-validation/client_real_acceptance/roster-witness-correction-r2/api-next04-proposal')
NEW=OLD.parent/'api-next04-correction'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
old=(OLD/'run-api-witness.py').read_text();new=(NEW/'run-api-witness.py').read_text()
inverse=new.replace('api-next04-correction','api-next04-proposal').replace('filename,expected_sha','filename,digest').replace('hexdigest()==expected_sha','hexdigest()==digest')
assert inverse==old
assert sha(OLD/'manifest.safe.json')=='d6394be058e809dfa9b7b210538e054b2057fdea1906101a8df4e5aef6bc0935'
assert sha(OLD/'api-source.safe.zip')=='0f41777d71cc181bd72d878aad984749aac8e9f0ab71141e23637ca847465517'
for row in json.loads((NEW/'manifest.safe.json').read_text())['files']:
 p=NEW/row['path'];assert p.stat().st_size==row['bytes'] and sha(p)==row['sha256']
with zipfile.ZipFile(NEW/'api-source.safe.zip') as z:assert z.testzip() is None;members=len(z.infolist())
for name in ['READY.safe.json','NATIVE-PLAN.safe.json','PLAN.safe.json']:assert (NEW/name).read_bytes()==(OLD/name).read_bytes()
before=json.loads((OLD/'grant.template.safe.json').read_text());after=json.loads((NEW/'grant.template.safe.json').read_text())
assert {k for k in before if before[k]!=after[k]}=={'caller_source_sha256','adapter_sha256'}
assert after['caller_source_sha256']==after['adapter_sha256']==sha(NEW/'run-api-witness.py')
DATA=b'public synthetic source'
class PublicPath:
 def __init__(self,name):pass
 def read_bytes(self):return DATA
 def open(self,mode):assert mode=='rb';return io.BytesIO(DATA)
 def is_symlink(self):return False
 def stat(self):return types.SimpleNamespace(st_nlink=1)
def selected(source,immutable,mutable):
 t=ast.parse(source)
 definition=next(n for n in t.body if isinstance(n,ast.FunctionDef) and n.name=='digest')
 loops=[n for n in t.body if isinstance(n,ast.For) and isinstance(n.target,ast.Tuple) and n.target.elts[0].id=='filename']
 assert len(loops)==2
 value=hashlib.sha256(DATA).hexdigest()
 ns={'Path':PublicPath,'hashlib':hashlib,'plan':{'immutablePins':{'PUBLIC_IMMUTABLE':value} if immutable else {},'mutableOnlyAfterExplicitFormatGrant':{'PUBLIC_MUTABLE':value} if mutable else {}}}
 exec(compile(ast.fix_missing_locations(ast.Module(body=[definition,*loops],type_ignores=[])),'<actual-selected-caller-AST>','exec'),ns)
 try:return 'HASH_CALL_PASS' if ns['digest'](PublicPath('PUBLIC_SOURCE'))==value else 'HASH_MISMATCH'
 except Exception as e:return type(e).__name__
controls=[]
for immutable,mutable in [(True,False),(False,True),(True,True),(False,False)]:
 a=selected(old,immutable,mutable);b=selected(new,immutable,mutable)
 assert a==('TypeError' if immutable or mutable else 'HASH_CALL_PASS') and b=='HASH_CALL_PASS'
 controls.append({'immutable_nonempty':immutable,'mutable_nonempty':mutable,'old':a,'new':b,'PASS':True})
result={'verdict':'APPROVE_SOURCE','scope':'API-CALLER-DIGEST-SHADOW_ONLY','runtime':'NOT_RUN','caller_sha256':sha(NEW/'run-api-witness.py'),'author_manifest_sha256':sha(NEW/'manifest.safe.json'),'author_zip_sha256':sha(NEW/'api-source.safe.zip'),'zip_members':members,'zip_crc_errors':0,'inverse_whole_source_byte_exact':True,'only_template_delta':['caller_source_sha256','adapter_sha256'],'selected_actual_ast_controls':controls,'original_seals_unchanged':True,'previous_full_finite_review_manifest':'2ca3d5fce74a129bc30c3d95457a1dce4cc861dcbe7d1cd7be3e21466e4d4cf1','all_previous_remaining_delta_qualifications_preserved':True,'grant_requirement':'Root must bind exact new caller6b0 plus READY3117/nativeplanf7b3/current481/fresh4facts/live16/resources/deadline before dispatch. This source approval is not API/native permission.','acceptance':'Native0 alone insufficient: CLASSIFIED, one GET, closed source-derived witness, no domain writes, both distinct owned actor logouts204+refresh-cookie removal+dispose confirmation required; no client PASS/cause inferred from source.','limitations':['Helper/R2 full review and native26 unchanged; not replayed.','Managed heap and sampled RSS/cache/post-buffer limits are not hard allocation isolation.','Chronological actor recovery is qualified and requires isolated retained data/no concurrent domainwriter.','Historical/root actual503 cause remains UNKNOWN.']}
os.umask(0o077)
with (OUT/'recheck.safe.json').open('x') as f:json.dump(result,f,indent=2);f.write('\n')
with (OUT/'REPORT.md').open('x') as f:f.write('APPROVE_SOURCE: exact two iterator/hash-reference renames plus new owned namespace. Whole inverse restores original d0b9. Independently executed selected original/corrected AST with public fake inputs: three old TypeError counterexamples become callable hash PASS; both-empty control PASS unchanged. No caller/helper/native/API executed. All previous source-only limits and fresh Root grant requirements remain.\n')
files=[p for p in OUT.iterdir() if p.is_file()]
with (OUT/'manifest.safe.json').open('x') as f:json.dump({'verdict':'APPROVE_SOURCE','files':[{'path':p.name,'bytes':p.stat().st_size,'sha256':sha(p)} for p in sorted(files)]},f,indent=2);f.write('\n')
with zipfile.ZipFile(OUT/'safe-recheck.zip','x',zipfile.ZIP_DEFLATED) as z:
 for p in sorted(files)+[OUT/'manifest.safe.json']:z.write(p,p.name)
print(json.dumps({'verdict':'APPROVE_SOURCE','manifest_sha256':sha(OUT/'manifest.safe.json'),'zip_sha256':sha(OUT/'safe-recheck.zip'),'zip_bytes':(OUT/'safe-recheck.zip').stat().st_size,'controls':4,'native_helpers_imported':False}))
