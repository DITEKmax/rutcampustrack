import datetime
import json
import os
import pathlib
import shutil
import subprocess
import sys
import time

ROOT = pathlib.Path('/workspace/rct-worktrees/ci-academic-heap')
OUT = pathlib.Path('/workspace/scratch/rct-validation/authored_format_current/python1')
NODE = '/opt/codex/runtimes/codex-primary-runtime/dependencies/node/bin/node'
phase = sys.argv[1]
attempt = sys.argv[2] if len(sys.argv)>2 else ''
label = phase + attempt
assert phase in ['inventory', 'write', 'check', 'semantic']
env = {'PATH': f'/workspace/scratch/rct-validation/authored_format_current/tools/bin:{pathlib.Path(NODE).parent}:/usr/bin:/bin', 'LANG': 'C.UTF-8', 'LC_ALL': 'C.UTF-8', 'NODE_OPTIONS': '--max-old-space-size=512'}
env['FORMAT_GUARD_PHASE'] = label
cmd = [NODE, 'scripts/format-authored.mjs', 'inventory'] if phase == 'inventory' else [NODE, 'scripts/format-authored.mjs', 'python', f'--{phase}'] if phase in ['write','check'] else [NODE,str(OUT/'verify-meaning.mjs')]
log = OUT / f'{label}.private.log'
fd = os.open(log, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
start_free = shutil.disk_usage('/workspace').free
samples = []
violation = None
with os.fdopen(fd, 'wb') as stream:
    child = subprocess.Popen(cmd, cwd=ROOT, env=env, stdout=stream, stderr=subprocess.STDOUT)
    birth = pathlib.Path(f'/proc/{child.pid}/stat').read_text().split(') ',1)[1].split()[19]
    (OUT/'CURRENT.json').write_text(json.dumps({'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':f'RUNNING_{phase.upper()}','own_pid':child.pid,'birth_ticks':birth,'runner_pid':os.getpid(),'command':cmd,'log':str(log)},indent=2)+'\n')
    print(json.dumps({'phase':phase,'pid':child.pid,'birth_ticks':birth}),flush=True)
    while child.poll() is None:
        free = shutil.disk_usage('/workspace').free
        shared = int(pathlib.Path('/sys/fs/cgroup/memory.current').read_text())
        samples.append({'elapsed_s':len(samples),'free_bytes':free,'shared_memory':shared})
        if free < 4294967296 or shared >= 16106127360:
            violation = 'DISK_FLOOR_OR_SHARED_MEMORY_CAP'
            child.terminate()
            break
        time.sleep(1)
    try:
        code = child.wait(timeout=10)
    except subprocess.TimeoutExpired:
        child.kill(); code = child.wait()
assert not pathlib.Path(f'/proc/{child.pid}').exists()
result = {'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'phase':phase,'attempt':attempt,'native_exit':code,'violation':violation,'own_pid':child.pid,'birth_ticks':birth,'own_pid_absent':True,'seconds_samples':len(samples),'min_free_bytes':min([s['free_bytes'] for s in samples]+[start_free]),'max_shared_memory':max([s['shared_memory'] for s in samples]+[0]),'disk_delta_shared_qualified':start_free-shutil.disk_usage('/workspace').free,'log':str(log),'raw_mode':oct(log.stat().st_mode&0o777),'samples':samples}
(OUT/f'{label}.safe.json').write_text(json.dumps(result,indent=2)+'\n')
(OUT/'CURRENT.json').write_text(json.dumps({'utc':result['utc'],'status':f'TERMINAL_{label.upper()}','own_pid':None,'result':str(OUT/f'{label}.safe.json'),'next':'Preserve result before next phase'},indent=2)+'\n')
with (OUT/'attempts.ndjson').open('a') as stream: stream.write(json.dumps({k:v for k,v in result.items() if k!='samples'})+'\n')
print(json.dumps({k:v for k,v in result.items() if k!='samples'}),flush=True)
raise SystemExit(code if not violation else 90)
