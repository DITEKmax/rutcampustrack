from pathlib import Path
import json,hashlib
O=Path('/workspace/scratch/rct-validation/ci_eb0_receipts');OLD=Path('/workspace/scratch/rct-validation/ci_format65_receipts');R=Path('/workspace/rutcampustrack');cache={};out=[]
def current(e):
 file=e['collector'];d=json.loads((O/file).read_text());old=e['case'];cases=[c for c in d['cases'] if c.get('classname')==old['classname'] and c.get('method')==old['method'] and c.get('identity')=='SOURCE_METHOD'];assert len(cases)==1;c=cases[0];p=R/c['source']
 if c['source'] not in cache:cache[c['source']]=hashlib.sha256(p.read_bytes()).hexdigest()
 assert c['status']=='PASSED' and c['sourceSha256']==cache[c['source']]==old['sourceSha256']
 xml=next(x for x in d['xml'] if x['ordinal']==c['xmlOrdinal'])
 return {'collector':file,'metadata':d['metadata'],'case':c,'xml_sha256':xml['sha256'],'current_source_sha_exact':True,'prior_review_source_sha_exact':True}
for row in json.loads((OLD/'current-23-finite-case-readback-final.json').read_text()):
 out.append({'id':row['id'],'current_native_pass':True,'evidence':[current(e) for e in row['evidence']],'meaning_qualification':'Previously source-qualified finite assertions retain byte-exact test identity; new EB native evidence collected. Existing mock/role/data/runtime limits unchanged. No new acceptance row or parent promotion.'})
(O/'current-23-finite-case-readback.json').write_text(json.dumps(out,indent=2)+'\n')
subject=[current(e) for e in json.loads((OLD/'current-subject-finite-cases.json').read_text())];(O/'current-subject-finite-cases.json').write_text(json.dumps(subject,indent=2)+'\n')
(O/'critical-test-source-readback-ledger.json').write_text(json.dumps({'files':[{'source':k,'sha256':v} for k,v in sorted(cache.items())],'scope':'Only already accepted23finite cases +3subject cases; no full historical340-file scan','parent_promotions':0},indent=2)+'\n')
print(json.dumps({'finite_existing_rows':len(out),'finite_native_identities':sum(len(r['evidence']) for r in out),'subject_native_identities':len(subject),'critical_unique_source_files':len(cache),'all_current_and_prior_review_source_sha_exact':True,'parent_promotions':0}))
