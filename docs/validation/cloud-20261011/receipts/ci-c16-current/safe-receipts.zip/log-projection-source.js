(function project(raw){
const lines=raw.replace(/\x1b\[[0-9;]*m/g,"").split("\n").map(l=>l.replace(/^\d{4}-\d\d-\d\dT[\d:.]+Z\s*/,"").trim());
const checkout=[];for(let i=0;i<lines.length;i++){if(/git log -1 --format=%H/.test(lines[i]))for(let j=i+1;j<Math.min(i+4,lines.length);j++)if(/^[0-9a-f]{40}$/.test(lines[j]))checkout.push(lines[j]);}
const native=[];for(const l of lines){
if(/^(?:=+\s*)?\d+ passed(?:,\s*\d+ (?:failed|skipped|xfailed|xpassed|warnings?))*(?: in [\d.]+s)?(?:\s*=+)?$/.test(l)||/^(?:All checks passed!|\d+ files? (?:already formatted|left unchanged)|Found \d+ errors?)$/.test(l)||/^(?:Test Files|Tests)\s+\d+ (?:passed|failed)(?:\s*[\|(]\s*\d+ (?:passed|failed|skipped)|\s*\(\d+\))*\)?$/.test(l)||/^Duration\s+[\d.]+s(?:\s+\([^)]{0,250}\))?$/.test(l)||/^> Task :[a-zA-Z0-9_:-]+:(?:compileJava|compileTestJava|compileIntegrationTestJava|test|integrationTest)(?: UP-TO-DATE| FROM-CACHE| NO-SOURCE| SKIPPED| FAILED)?$/.test(l)||/^BUILD (?:SUCCESSFUL|FAILED) in [\dmsh ]+$/.test(l)||/^\d+ (?:passed|failed|skipped)(?:\s+\([\d.ms ]+\))$/.test(l)||/^Running \d+ tests? using \d+ workers?$/.test(l))native.push(l);
}
return {checkoutSha:[...new Set(checkout)],native};
})
