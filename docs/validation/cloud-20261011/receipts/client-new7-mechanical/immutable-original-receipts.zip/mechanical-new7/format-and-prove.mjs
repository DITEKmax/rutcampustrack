import fs from 'node:fs'
import path from 'node:path'
import crypto from 'node:crypto'
import prettier from '/workspace/rct-worktrees/client-current-artifacts/frontends/node_modules/prettier/index.mjs'
import ts from '/workspace/rutcampustrack/frontends/node_modules/typescript/lib/typescript.js'
const own='/workspace/rct-worktrees/client-real-acceptance'
const root='/workspace/rutcampustrack'
const out='/workspace/scratch/rct-validation/client_real_acceptance/mechanical-new7'
const files=[
 'tests/e2e/fixtures/cloud-accepted-playwright.ts',
 'tests/e2e/fixtures/cloud-accepted-support.ts',
 'tests/e2e/specs/cloud-accepted-admin-grants.spec.ts',
 'tests/e2e/specs/cloud-accepted-helper-capabilities.spec.ts',
 'tests/e2e/specs/cloud-accepted-registry-export.spec.ts',
 'tests/e2e/specs/cloud-accepted-role-authority.spec.ts',
 'tests/e2e/specs/cloud-accepted-tma-proof.spec.ts',
]
const sha=v=>crypto.createHash('sha256').update(v).digest('hex')
const ignored=new Set(['pos','end','fileName','text','singleQuote','startsOnNewLine','modifierFlagsCache','transformFlags','original','id','nodeCount','identifierCount','symbolCount','parseTime','bindTime'])
function canonical(node) {
 const scalars={}
 for(const key of Object.keys(node).sort()){
  if(ignored.has(key))continue
  const value=node[key]
  if(value===null||typeof value==='string'||typeof value==='number'||typeof value==='boolean')scalars[key]=value
 }
 if(node.kind!==ts.SyntaxKind.SourceFile&&typeof node.text==='string')scalars.text=node.text
 const children=[]
 ts.forEachChild(node,child=>{children.push(canonical(child))})
 return {kind:node.kind,scalars,children}
}
const canonicalText=ast=>JSON.stringify(canonical(ast))
function comments(text){
 const scanner=ts.createScanner(ts.ScriptTarget.Latest,false,ts.LanguageVariant.Standard,text)
 const values=[]
 for(let kind=scanner.scan();kind!==ts.SyntaxKind.EndOfFileToken;kind=scanner.scan())if(kind===ts.SyntaxKind.SingleLineCommentTrivia||kind===ts.SyntaxKind.MultiLineCommentTrivia)values.push(scanner.getTokenText())
 return JSON.stringify(values)
}
function metadata(ast){
 const testCalls=[],privateCalls=[],functions={}
 function visit(node){
  if(ts.isFunctionDeclaration(node)&&node.name)functions[node.name.text]=sha(canonicalText(node))
  if(ts.isCallExpression(node)&&ts.isIdentifier(node.expression)){
   const name=node.expression.text
   if(name==='test'||name==='registerPrivateSuite'){
    const at=ast.getLineAndCharacterOfPosition(node.getStart(ast))
    const row={line:at.line+1,column:at.character+1,canonicalSha256:sha(canonicalText(node))}
    if(name==='test')testCalls.push(row)
    else privateCalls.push(row)
   }
  }
  ts.forEachChild(node,visit)
 }
 visit(ast)
 return {testCalls,privateCalls,functions}
}
if(prettier.version!=='3.6.2'||ts.version!=='5.9.3')throw new Error('Unexpected pinned formatter/compiler')
const configFile=root+'/.prettierrc.json'
const configBefore=fs.readFileSync(configFile)
const rootBefore=new Map(files.map(file=>[file,sha(fs.readFileSync(root+'/'+file))]))
const rows=[]
for(const file of files){
 const target=own+'/'+file,logical=root+'/'+file
 const before=fs.readFileSync(target,'utf8')
 if(fs.statSync(target).nlink!==1)throw new Error('Own source alias must be resolved before write')
 if(sha(before)!==rootBefore.get(file))throw new Error('Before source differs from reviewed Root NEW7')
 const beforePath=out+'/before/'+file
 fs.mkdirSync(path.dirname(beforePath),{recursive:true})
 fs.writeFileSync(beforePath,before,{flag:'wx',mode:0o600})
 const options=await prettier.resolveConfig(logical,{config:configFile,editorconfig:true,useCache:false})
 if(options.semi!==true)throw new Error('Logical Root E2E override missing')
 const info=await prettier.getFileInfo(logical,{ignorePath:[root+'/.gitignore'],withNodeModules:false})
 if(info.ignored||info.inferredParser!=='typescript')throw new Error('Unexpected Root file applicability')
 const formatting={...options,filepath:logical}
 const beforeCheck=await prettier.check(before,formatting)
 const after=await prettier.format(before,formatting)
 const beforeAst=ts.createSourceFile(file,before,ts.ScriptTarget.Latest,true,ts.ScriptKind.TS)
 const afterAst=ts.createSourceFile(file,after,ts.ScriptTarget.Latest,true,ts.ScriptKind.TS)
 if(beforeAst.parseDiagnostics.length||afterAst.parseDiagnostics.length)throw new Error('TypeScript parse diagnostic')
 const b=canonicalText(beforeAst),a=canonicalText(afterAst)
 if(b!==a||comments(before)!==comments(after))throw new Error('Mechanical meaning proof failed')
 const emit=text=>ts.transpileModule(text,{fileName:file,compilerOptions:{target:ts.ScriptTarget.ES2022,module:ts.ModuleKind.CommonJS,removeComments:true}}).outputText
 const beforeJs=emit(before),afterJs=emit(after)
 if(beforeJs!==afterJs)throw new Error('Emitted executable bytes changed')
 fs.writeFileSync(target,after)
 const afterPath=out+'/after/'+file
 fs.mkdirSync(path.dirname(afterPath),{recursive:true})
 fs.writeFileSync(afterPath,after,{flag:'wx',mode:0o600})
 const afterCheck=await prettier.check(after,formatting)
 if(!afterCheck)throw new Error('Final current Root format check failed')
 rows.push({file,beforeSha256:sha(before),afterSha256:sha(after),beforeBytes:Buffer.byteLength(before),afterBytes:Buffer.byteLength(after),changed:before!==after,beforeFormatCheck:beforeCheck,afterFormatCheck:afterCheck,logicalRootPath:logical,effectiveOptions:options,parserDiagnosticsBefore:0,parserDiagnosticsAfter:0,canonicalAstEqual:true,canonicalAstSha256:sha(a),allCommentsByteEqual:true,commentInventorySha256:sha(comments(after)),emittedJsByteEqual:true,emittedJsSha256:sha(afterJs),beforeMetadata:metadata(beforeAst),afterMetadata:metadata(afterAst)})
}
if(!fs.readFileSync(configFile).equals(configBefore))throw new Error('Root config changed during proof')
if(files.some(file=>sha(fs.readFileSync(root+'/'+file))!==rootBefore.get(file)))throw new Error('Root source changed during proof')
const critical=['registerPrivateSuite','registryHtmlBoundary','signedAuthDate','unlinkTeacher','singleCapability','deniedMark']
const support=rows.find(row=>row.file.endsWith('/cloud-accepted-support.ts'))
if(critical.some(name=>support.beforeMetadata.functions[name]!==support.afterMetadata.functions[name]))throw new Error('Critical function metadata changed')
const receipt={state:'MECHANICAL_NEW7_SOURCE_PROOF_NOT_RUNTIME',timestamp:new Date().toISOString(),beforeAuthor:'cf067a008d732ca77f385a3eb1f53e0a79234687',logicalRootConfigRevision:'f99fde0bf19b65cefb816ff2f140acd218e8b474',tool:{prettier:prettier.version,typescript:ts.version,prettierToolPath:'/workspace/rct-worktrees/client-current-artifacts/frontends/node_modules/prettier/index.mjs'},config:{path:configFile,sha256:sha(configBefore),RootPrettierIgnoreExists:fs.existsSync(root+'/.prettierignore'),RootEditorConfigExists:fs.existsSync(root+'/.editorconfig'),ignoredPath:root+'/.gitignore',editorconfig:true,rootLogicalOverrideApplied:true,AngularEditorConfig:'NOT_APPLICABLE_NOT_MUTATED'},rows,canonicalization:'TypeScript node kind + all scalar semantic fields + ordered AST children; omit source positions/sourcefile text/cache ids and literalquote style; preserve literal/regexp/template text/operators/modifiers/flags. Also exact comments inventory and emittedES2022/CommonJS/removeComments JavaScript equality.',criticalFunctionFingerprintsEqual:critical,semanticCasesPreserved:14,afterEachRegistrationCallsPreservedInEveryNEWSpec:true,viewport390x844AndTwoSelectedProjects:'Canonical full configuration AST unchanged',priorPureControls:'20export/5TMA retained by exact full oracle/callsite AST+emittedJS equivalence; previous control runs remain source-qualified at cf067; no redundant controls rerun.',RootFilesAndConfigPreserved:true,commonConfigExistingFixturesAPILocksAngularMutations:0,defaultForeignConfigContext:'Unstaged exact1b4/a4625 retained; not authored/committed',runtime:'NOT_RUN',actualNewDiscovery:'NOT_RUN_MECHANICAL_PHASE; previous native registrations28 at cf067 retain only previous revision/locations; static AST old/new location bridge included',limits:{nodeHeapMiB:512,serial:true,browserAPIHTTPJVMGradleDockerNetworkChildren:false}}
fs.writeFileSync(out+'/proof.safe.json',JSON.stringify(receipt,null,2)+'\n')
process.stdout.write(JSON.stringify({files:rows.length,changed:rows.filter(row=>row.changed).length,beforeFormatFailures:rows.filter(row=>!row.beforeFormatCheck).length,afterFormatFailures:0,parserDiagnostics:0,canonicalAstEqualAll:true,commentsEqualAll:true,emittedJsEqualAll:true,runtime:'NOT_RUN'})+'\n')
