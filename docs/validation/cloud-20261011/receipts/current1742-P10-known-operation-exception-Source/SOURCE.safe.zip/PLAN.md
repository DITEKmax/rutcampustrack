# P10 operation r1 — Source only

Actual02 used normal-approved sandbox_permissions=require_escalated. Its child operation and exception remain UNKNOWN. This sibling adds fixed last-started operation stage, an exact known standard exception enum, and HTTP status only for exact HTTPError with plain integer100–599. Unknown/subclass types stay OTHER; no reason/message/context/URI/rawclass export. Existing primary/cleanup/lifecycle cap and status decisions stay unchanged. Source policy comparison documents the explicit parent environment whitelist; no actual environment values/keypresence were read and no proxy/CA/TLS/approval change was made.

11 selected actual catch AST/RAM controls PASS. Original13 lifecycle and17+6 parser proofs are reused, not replayed. Initial fixture-construction getter-trap checking FAIL is retained; corrected fixture setup passed without Source change. Whole Source inverse is exact outside two stdlib imports and one observer function. Parentc5af/b78 and all18 pins/clean5dac104e remain frozen. See READY.safe.json for exact false template/argv/Source pins, added closed fields, qualifications and controls.

No network, private XML/log/body read, native observer, test/compiler/PG/browser or B013 action. Narrow risk-specific independent review and fresh Root grant remain required.
