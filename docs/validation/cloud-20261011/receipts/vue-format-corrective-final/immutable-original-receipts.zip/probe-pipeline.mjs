import fs from 'node:fs'
import { spawnSync } from 'node:child_process'
import { createHash } from 'node:crypto'
import { ESLint } from '/workspace/rutcampustrack/frontends/node_modules/eslint/lib/api.js'
import * as prettier from '/workspace/rct-worktrees/client-current-artifacts/frontends/node_modules/prettier/index.mjs'
process.argv[2] = 'library'
const { vue, firstDelta } = await import('../prettier-final/verify-meaning.mjs')
const root = '/workspace/rct-worktrees/ci-academic-heap'
const scratch = '/workspace/scratch/rct-validation/authored_format_current/vue-eslint-correction'
const config = '/workspace/rutcampustrack/frontends/eslint.config.mjs'
if (fs.readFileSync(config,'utf8') !== fs.readFileSync(`${root}/frontends/eslint.config.mjs`,'utf8')) throw new Error('CONFIG_IDENTITY')
const targets = JSON.parse(fs.readFileSync(`${scratch}/vue-targets.json`,'utf8'))
const eslint = new ESLint({cwd:`${root}/frontends`,overrideConfigFile:config,fix:true,cache:false})
const hash = (v) => createHash('sha256').update(typeof v === 'string' ? v : JSON.stringify(v)).digest('hex')
const rows = []
fs.mkdirSync(`${scratch}/candidate`,{recursive:true,mode:0o700})
async function format(text,path) {
  const options=await prettier.resolveConfig(path)
  const pretty=await prettier.format(text,{...options,filepath:path})
  const result=(await eslint.lintText(pretty,{filePath:path}))[0]
  return {text:result.output ?? pretty,errors:result.errorCount,warnings:result.warningCount,rules:result.messages.map(m=>m.ruleId)}
}
for (const path of targets) {
  const absolute=`${root}/${path}`
  const current=fs.readFileSync(absolute,'utf8')
  const baseline=spawnSync('git',['show',`cd3f237acffd4f0b9dd2a74babb2ee822376f0cb:${path}`],{cwd:'/workspace/rutcampustrack',encoding:'utf8'})
  if (baseline.status!==0) throw new Error(`BASELINE ${path}`)
  const a=await format(current,absolute)
  const b=await format(a.text,absolute)
  const before=await vue(baseline.stdout,path)
  const after=await vue(a.text,path)
  const delta=firstDelta(before,after)
  const candidate=`${scratch}/candidate/${path}`
  fs.mkdirSync(candidate.slice(0,candidate.lastIndexOf('/')),{recursive:true,mode:0o700})
  fs.writeFileSync(candidate,a.text,{mode:0o600})
  rows.push({path,changed:current!==a.text,lintErrors:a.errors,lintWarnings:a.warnings,rules:a.rules,
    fixedpoint:a.text===b.text,meaningEqual:delta===null,firstMeaningDelta:delta,
    originalMeaningHash:hash(before),candidateMeaningHash:hash(after),candidateSourceHash:hash(a.text)})
}
const result={targets:targets.length,changed:rows.filter(r=>r.changed).length,
  lintNotGreen:rows.filter(r=>r.lintErrors || r.lintWarnings).length,
  fixedpointFailures:rows.filter(r=>!r.fixedpoint).length,meaningFailures:rows.filter(r=>!r.meaningEqual).length,rows}
fs.writeFileSync(`${scratch}/pipeline-probe.safe.json`,JSON.stringify(result,null,2)+'\n',{mode:0o600})
console.log(JSON.stringify({targets:result.targets,changed:result.changed,lintNotGreen:result.lintNotGreen,fixedpointFailures:result.fixedpointFailures,meaningFailures:result.meaningFailures}))
