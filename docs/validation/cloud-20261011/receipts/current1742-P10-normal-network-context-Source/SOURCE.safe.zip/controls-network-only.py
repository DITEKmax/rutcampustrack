"""Execute only the added loop AST with synthetic context; never read actual os.environ."""
from pathlib import Path
import ast, json, os
from types import SimpleNamespace

scope = Path(__file__).parent
tree = ast.parse((scope/'run-green-owned.py').read_text())
loop = next(n for n in tree.body if isinstance(n, ast.For) and isinstance(n.target, ast.Name)
            and n.target.id == 'network_context_key')
allowed = tuple(n.value for n in loop.iter.elts)
assert allowed == ('HTTP_PROXY', 'HTTPS_PROXY', 'NO_PROXY', 'http_proxy', 'https_proxy', 'no_proxy', 'SSL_CERT_FILE', 'SSL_CERT_DIR')
assert len(allowed) == 8
code = compile(ast.Module(body=[loop], type_ignores=[]), '<approved-loop-Source>', 'exec')
baseline = {'PATH': '/synthetic/owned-bin', 'LANG': 'C.UTF-8', 'TMPDIR': '/synthetic/owned-tmp'}
def run(context):
    env = {'environment': dict(baseline), 'os': SimpleNamespace(environ=context)}
    exec(code, env)
    return env['environment']
canary = 'OWN_SYNTHETIC_PRIVATE_CONTEXT_CANARY'
context = {key: canary + key for key in allowed}
context.update({key: canary for key in ['HOME', 'AUTH_TOKEN', 'ALL_PROXY', 'all_proxy', 'REQUESTS_CA_BUNDLE', 'CURL_CA_BUNDLE', 'UNKNOWN_PROXY']})
old_result = dict(baseline)
new_result = run(context)
controls = {
    'old_explicit_context_drops_allowed_synthetic_network_settings': all(key not in old_result for key in allowed),
    'new_exact8_synthetic_string_values_preserved_privately': all(new_result[key] == context[key] for key in allowed),
    'unknown_HOME_auth_fullENV_alternate_proxy_not_forwarded': set(new_result) == set(baseline) | set(allowed),
    'baseline_fields_unchanged': all(new_result[key] == value for key, value in baseline.items()),
    'empty_context_preserves_exact_baseline': run({}) == baseline,
    'sparse_context_preserves_lowercase_and_CA_without_inventing_other_keys': run({'https_proxy': canary, 'SSL_CERT_FILE': canary}) == {**baseline, 'https_proxy': canary, 'SSL_CERT_FILE': canary},
}
assert all(controls.values())
out = {'schema': 'P10_NETWORK_R1_SELECTED_LOOP_AST_RAM_V1', 'controls': controls, 'all_pass': True,
       'actual_selected_loop_AST': True, 'actual_environment_values_keypresence_or_hash_read': False,
       'synthetic_values_keypresence_or_hash_exported': False,
       'effects': 'Synthetic RAM only; no parent/native/network/request/actualURL/credentials operation',
       'actual03_nestedreason_and_P10cause': 'UNKNOWN'}
assert canary not in json.dumps(out)
os.umask(0o077)
p = scope/'network-controls.safe.json'
p.write_text(json.dumps(out, indent=2)+'\n')
p.chmod(0o600)
print(json.dumps({'controls': len(controls), 'PASS': True}))
