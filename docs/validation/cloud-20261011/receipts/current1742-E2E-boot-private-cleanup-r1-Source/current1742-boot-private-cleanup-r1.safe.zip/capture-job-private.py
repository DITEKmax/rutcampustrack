"""One exact gh GET, private bounded stdout; b78 owns exec-replaced PID."""
import datetime as dt
import hashlib
import json
import os
from pathlib import Path
import resource
import stat
import sys

HERE = Path(__file__).absolute().parent
PRIVATE = HERE / 'private'
CAP = 32 * 1024 * 1024
ENDPOINT = 'repos/DITEKmax/rutcampustrack/actions/jobs/115262001797/logs'

def require(ok):
    if not ok:
        raise RuntimeError('CLOSED_GATE_DENIED')

def private_read(path, cap):
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW)
    try:
        st = os.fstat(fd)
        require(stat.S_ISREG(st.st_mode) and st.st_uid == 1000
            and stat.S_IMODE(st.st_mode) == 0o600 and st.st_nlink == 1
            and 0 < st.st_size <= cap)
        value = os.read(fd, cap + 1)
        require(len(value) == st.st_size)
        return value
    finally:
        os.close(fd)

def fresh(grant):
    ws = os.statvfs('/workspace')
    shared = int(Path('/sys/fs/cgroup/memory.current').read_text())
    require(ws.f_bavail * ws.f_frsize >= 4294967296
        and shared + 1073741824 < 16106127360)
    now = dt.datetime.now(dt.timezone.utc)  # LAST after measurements.
    start = dt.datetime.fromisoformat(grant['not_before'])
    stop = dt.datetime.fromisoformat(grant['cleanup_gate'])
    require(start.tzinfo is not None and stop.tzinfo is not None and start <= now < stop)

def validate_grant(grant, own_sha):
    require(grant['authorized'] is True and grant['scope'] == 'EXACT1742_JOB_LOG_READ_ONLY'
        and grant['head'] == '1742d1e806faa5c39c6d182a3554daa8f4239801'
        and type(grant['run_id']) is int and grant['run_id'] == 38387263916
        and type(grant['job_id']) is int and grant['job_id'] == 115262001797
        and type(grant['run_attempt']) is int and grant['run_attempt'] == 1
        and grant['capture_sha256'] == own_sha
        and grant['max_bytes'] == CAP and grant['phase_seconds'] == 45)
    start = dt.datetime.fromisoformat(grant['not_before'])
    cleanup = dt.datetime.fromisoformat(grant['cleanup_gate'])
    hard = dt.datetime.fromisoformat(grant['hard_stop'])
    require(start.tzinfo is not None and cleanup.tzinfo is not None and hard.tzinfo is not None
        and 0 < (hard-start).total_seconds() <= 120
        and (hard-cleanup).total_seconds() >= 30)

def main():
    require(len(sys.argv) == 3 and sys.argv[1] == '--grant'
        and Path(sys.argv[2]).absolute() == PRIVATE / 'read-grant.json'
        and os.getuid() == 1000)
    grant = json.loads(private_read(PRIVATE / 'read-grant.json', 16384))
    validate_grant(grant, hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
    # Root must supply the privately selected NORMAL gh auth/proxy environment
    # to b78. This program does not copy/read/print inherited environment values.
    fd = os.open('/', os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
    try:
        for part in PRIVATE.parts[1:]:
            nxt = os.open(part, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW, dir_fd=fd)
            os.close(fd)
            fd = nxt
        st = os.fstat(fd)
        require((st.st_dev, st.st_ino, st.st_uid, st.st_gid, stat.S_IMODE(st.st_mode))
            == tuple(grant['private_directory_identity']))
        require(st.st_uid == 1000 and stat.S_IMODE(st.st_mode) == 0o700)
        resource.setrlimit(resource.RLIMIT_FSIZE, (CAP, CAP))
        fresh(grant)
        output = os.open('job.log.private', os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW,
            0o600, dir_fd=fd)
        try:
            os.dup2(output, 1)
        finally:
            os.close(output)
        null = os.open('/dev/null', os.O_RDWR)
        try:
            os.dup2(null, 0)
            os.dup2(null, 2)
        finally:
            os.close(null)
        fresh(grant)
        # Fixed public argv, no key/credential/private route in argv.
        os.execv('/usr/bin/gh', ['gh', 'api', '--method', 'GET', ENDPOINT])
    finally:
        os.close(fd)

if __name__ == '__main__':
    try:
        main()
    except BaseException:
        raise SystemExit(2) from None
